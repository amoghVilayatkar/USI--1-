﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.Web.UI.WebControls;

namespace BenefitPointSummaryPortal.BAL.BPTimeLine
{
    public class TimelineDetail
    {
        #region Global Variables

        //Activity
        DataTable activity_table = new DataTable();
        DataTable activityrecord_table = new DataTable();
        DataTable activityrecord_salesOpportunityStages_table = new DataTable();
        DataTable activityrecord_activity_table = new DataTable();
        DataTable activityrecord_activity_details_table = new DataTable();
        DataTable activityCustomFieldValues_table = new DataTable();
        DataTable activitiestableForReports = new DataTable();

        DataTable customField_table = new DataTable();
        #endregion


        /// <summary>
        /// Get activity detail from  BP_BrokerConnectV4 web service using findActivityLogRecords webmethod. 
        /// </summary>
        /// <returns>Activity data</returns>

        public DataTable GetActivityInformation(int ClientID, string SessionId, int SubjectID, string reportName = "", string status = "")
        {
            BP_BrokerConnectV4.ActivityLogRecord new_activitylogrecord = new BP_BrokerConnectV4.ActivityLogRecord();

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.ActivityLogSearchCriteria new_activity_search = new BP_BrokerConnectV4.ActivityLogSearchCriteria();

            BP_BrokerConnectV4.ActivityLogRecordSummary[] new_activity_summary = new BP_BrokerConnectV4.ActivityLogRecordSummary[0];

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            DataTable activitiestable = new DataTable();

            activitiestable.Columns.Add("recordID", typeof(Int32));  // Row 0  
            activitiestable.Columns.Add("subject", typeof(string));  // Row 0  
            activitiestable.Columns.Add("name", typeof(string));  // Row 0  
            activitiestable.Columns.Add("createdon", typeof(string));  // Row 0   
            activitiestable.Columns.Add("dueon", typeof(string));  // Row 0  
            activitiestable.Columns.Add("status", typeof(string));  // Row 0  
            activitiestable.Columns.Add("priority", typeof(string));  // Row 0  
            activitiestable.Columns.Add("X", typeof(string));  // Row 0  
            activitiestable.Columns.Add("SubjectID", typeof(string));  // Row 0  

            int activity_row_counter = 0;
            int retries = 0;
            int i = 0;

            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;

            ListItem listitem = new ListItem();

            do
            {
                try
                {
                    new_activity_search = new BP_BrokerConnectV4.ActivityLogSearchCriteria();
                    new_activity_search.accountID = ClientID;
                    new_activity_summary = new_connection.findActivityLogRecords(new_activity_search);

                    if (new_activity_summary != null)
                    {
                        foreach (BP_BrokerConnectV4.ActivityLogRecordSummary alrs in new_activity_summary)
                        {
                            if (alrs != null)
                            {
                                //if (alrs.subjectText.Contains("Timeline"))
                                if (alrs.subjectID.Equals(SubjectID))
                                {
                                    if (reportName == "Reports1" && status == "open")
                                    {
                                        if (alrs.status.ToString().ToLower() == status.ToLower())
                                        {
                                            activitiestable.Rows.Add();

                                            activitiestable.Rows[activity_row_counter][0] = alrs.recordID;

                                            if (alrs.subjectText != null)
                                                activitiestable.Rows[activity_row_counter][1] = alrs.subjectText + " " + alrs.summary;

                                            if (alrs.assignedToFirstName != null && alrs.assignedToLastName != null)
                                                activitiestable.Rows[activity_row_counter][2] = alrs.assignedToFirstName + " " + alrs.assignedToLastName;

                                            if (alrs.createdOn != null && alrs.createdOn.Year != 1)
                                                activitiestable.Rows[activity_row_counter][3] = alrs.createdOn.ToShortDateString();

                                            if (alrs.dueOn != null && alrs.dueOn.Year != 1)
                                                activitiestable.Rows[activity_row_counter][4] = alrs.dueOn.ToShortDateString();

                                            if (alrs.status != null)
                                                activitiestable.Rows[activity_row_counter][5] = alrs.status.ToString();

                                            if (alrs.priority != null)
                                                activitiestable.Rows[activity_row_counter][6] = alrs.priority.ToString();
                                            activitiestable.Rows[activity_row_counter][8] = SubjectID.ToString();

                                            activity_row_counter++;
                                        }
                                    }
                                    else
                                    {
                                        activitiestable.Rows.Add();

                                        activitiestable.Rows[activity_row_counter][0] = alrs.recordID;

                                        if (alrs.subjectText != null)
                                            activitiestable.Rows[activity_row_counter][1] = alrs.subjectText + " " + alrs.summary;

                                        if (alrs.assignedToFirstName != null && alrs.assignedToLastName != null)
                                            activitiestable.Rows[activity_row_counter][2] = alrs.assignedToFirstName + " " + alrs.assignedToLastName;

                                        if (alrs.createdOn != null && alrs.createdOn.Year != 1)
                                            activitiestable.Rows[activity_row_counter][3] = alrs.createdOn.ToShortDateString();

                                        if (alrs.dueOn != null && alrs.dueOn.Year != 1)
                                            activitiestable.Rows[activity_row_counter][4] = alrs.dueOn.ToShortDateString();

                                        if (alrs.status != null)
                                            activitiestable.Rows[activity_row_counter][5] = alrs.status.ToString();

                                        if (alrs.priority != null)
                                            activitiestable.Rows[activity_row_counter][6] = alrs.priority.ToString();
                                        activitiestable.Rows[activity_row_counter][8] = SubjectID.ToString();

                                        activity_row_counter++;
                                    }

                                }
                            }
                        }

                        activitiestable = activitiestable.DefaultView.ToTable(true);
                    }
                    retries = 10;
                }

                catch (Exception ex)
                {
                    if (ex.Message.ToString() == "Unable to connect to the remote server" && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;

                        continue;
                    }
                    else if (ex.Message.ToString() == "The underlying connection was closed: The connection was closed unexpectedly." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else if (ex.Message.ToString() == "The session ID is not valid. Invoke the login operation on LoginServiceV2 to create a new session ID." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else
                    {
                        throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                    }
                }
                i++;
            } while (retries < 10);

            return activitiestable;

        }

        public DataSet Get_Activity_Detail(int acvtivityid, string SessionId)
        {
            BP_BrokerConnectV4.ActivityLogRecord new_activitylogrecord = new BP_BrokerConnectV4.ActivityLogRecord();




            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            activityrecord_table.Columns.Add("recordID", typeof(Int32));
            activityrecord_table.Columns.Add("accountID", typeof(Int32));
            activityrecord_table.Columns.Add("inquirerTypeID", typeof(Int32));
            activityrecord_table.Columns.Add("inquirerFirstName", typeof(string));
            activityrecord_table.Columns.Add("inquirerLastName", typeof(string));
            activityrecord_table.Columns.Add("inquirerEmail", typeof(string));
            activityrecord_table.Columns.Add("subjectID", typeof(Int32));
            activityrecord_table.Columns.Add("productID", typeof(Int32));
            activityrecord_table.Columns.Add("shortDescription", typeof(string));
            activityrecord_table.Columns.Add("longDescription", typeof(string));
            activityrecord_table.Columns.Add("createdOn", typeof(DateTime));
            activityrecord_table.Columns.Add("createdByUserID", typeof(Int32));
            activityrecord_table.Columns.Add("dueOn", typeof(DateTime));
            activityrecord_table.Columns.Add("status", typeof(string));
            activityrecord_table.Columns.Add("resolution", typeof(string));
            activityrecord_table.Columns.Add("assignedToUserID", typeof(Int32));
            activityrecord_table.Columns.Add("completedOn", typeof(DateTime));
            activityrecord_table.Columns.Add("notifyAssigneeViaEmail", typeof(bool));
            activityrecord_table.Columns.Add("minutesLogged", typeof(Int32));
            activityrecord_table.Columns.Add("ccTeamMemberUserIDs", typeof(Int32));
            activityrecord_table.Columns.Add("lastModifiedOn", typeof(DateTime));

            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_stageType", typeof(string));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_startedOn", typeof(DateTime));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_completedOn", typeof(DateTime));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_daysOpen", typeof(Int32));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_probability", typeof(Int32));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_estimatedCloseOn", typeof(DateTime));
            activityrecord_salesOpportunityStages_table.Columns.Add("salesOpportunityStages_lastModifiedOn", typeof(DateTime));

            activityrecord_activity_table.Columns.Add("activity_activityID", typeof(Int32));
            activityrecord_activity_table.Columns.Add("activity_description", typeof(string));

            activityrecord_activity_details_table.Columns.Add("activity_details_notes", typeof(string));
            activityrecord_activity_details_table.Columns.Add("activity_details_followupOn", typeof(DateTime));
            activityrecord_activity_details_table.Columns.Add("activity_details_createdOn", typeof(DateTime));
            activityrecord_activity_details_table.Columns.Add("activity_details_completedOn", typeof(DateTime));
            activityrecord_activity_details_table.Columns.Add("activity_details_createdByUserID", typeof(Int32));
            activityrecord_activity_details_table.Columns.Add("activity_details_minutesLogged", typeof(Int32));
            activityrecord_activity_details_table.Columns.Add("activity_details_statusID", typeof(Int32));

            activityCustomFieldValues_table.Columns.Add("customFieldValues_customFieldValueID", typeof(Int32));  // Row 1
            activityCustomFieldValues_table.Columns.Add("customFieldValues_customFieldID", typeof(Int32));  // Row 2
            activityCustomFieldValues_table.Columns.Add("customFieldValues_optionValueID", typeof(Int32));  // Row 3
            activityCustomFieldValues_table.Columns.Add("customFieldValues_valueText", typeof(string));  // Row 4
            activityCustomFieldValues_table.Columns.Add("custom_field_lable", typeof(string));  // Row 5



            int activitylogrecord_table_row_counter = 0;
            int salesOpportunityStages_table_row_counter = 0;
            int activityrecord_activity_table_row_counter = 0;
            int activityrecord_activity_details_table_row_counter = 0;
            int activityCustomFieldValues_table_row_counter = 0;
            int cnt = 0;

            int retries = 0;
            int i = 0;

            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;

            ListItem listitem = new ListItem();
            DataSet ds = new DataSet();

            do
            {
                try
                {
                    new_activitylogrecord = new BP_BrokerConnectV4.ActivityLogRecord();
                    new_activitylogrecord = new_connection.getActivityLogRecord(acvtivityid);
                    BP_BrokerConnectV4.CustomFieldStructure cust_struct = new BP_BrokerConnectV4.CustomFieldStructure();

                    cust_struct = new_connection.getCustomFieldStructure(BP_BrokerConnectV4.CustomizationArea.Activity_Log);



                    if (new_activitylogrecord != null)
                    {
                        activityrecord_table.Rows.Add();
                        if (new_activitylogrecord.recordID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][0] = new_activitylogrecord.recordID;
                        if (new_activitylogrecord.accountID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][1] = new_activitylogrecord.accountID;
                        if (new_activitylogrecord.inquirerTypeID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][2] = new_activitylogrecord.inquirerTypeID;
                        if (new_activitylogrecord.inquirerFirstName != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][3] = new_activitylogrecord.inquirerFirstName;
                        if (new_activitylogrecord.inquirerLastName != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][4] = new_activitylogrecord.inquirerLastName;
                        if (new_activitylogrecord.inquirerEmail != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][5] = new_activitylogrecord.inquirerEmail;
                        if (new_activitylogrecord.subjectID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][6] = new_activitylogrecord.subjectID;
                        if (new_activitylogrecord.productID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][7] = new_activitylogrecord.productID;
                        if (new_activitylogrecord.shortDescription != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][8] = new_activitylogrecord.shortDescription;
                        if (new_activitylogrecord.longDescription != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][9] = new_activitylogrecord.longDescription;
                        if (new_activitylogrecord.createdOn != null && new_activitylogrecord.createdOn.Year != 1) activityrecord_table.Rows[activitylogrecord_table_row_counter][10] = new_activitylogrecord.createdOn;
                        if (new_activitylogrecord.createdByUserID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][11] = new_activitylogrecord.createdByUserID;
                        if (new_activitylogrecord.dueOn != null && new_activitylogrecord.dueOn.Year != 1) activityrecord_table.Rows[activitylogrecord_table_row_counter][12] = new_activitylogrecord.dueOn;
                        if (new_activitylogrecord.status != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][13] = new_activitylogrecord.status;
                        if (new_activitylogrecord.resolution != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][14] = new_activitylogrecord.resolution;
                        if (new_activitylogrecord.assignedToUserID != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][15] = new_activitylogrecord.assignedToUserID;
                        if (new_activitylogrecord.completedOn != null && new_activitylogrecord.completedOn.Year != 1) activityrecord_table.Rows[activitylogrecord_table_row_counter][16] = new_activitylogrecord.completedOn;
                        if (new_activitylogrecord.notifyAssigneeViaEmail != null && new_activitylogrecord.notifyAssigneeViaEmail.ToString().ToUpper() != "NONE_SELECTED") activityrecord_table.Rows[activitylogrecord_table_row_counter][17] = new_activitylogrecord.notifyAssigneeViaEmail;
                        if (new_activitylogrecord.minutesLogged != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][18] = new_activitylogrecord.minutesLogged;
                        if (new_activitylogrecord.ccTeamMemberUserIDs != null) activityrecord_table.Rows[activitylogrecord_table_row_counter][19] = new_activitylogrecord.ccTeamMemberUserIDs;
                        if (new_activitylogrecord.lastModifiedOn != null && new_activitylogrecord.lastModifiedOn.Year != 1) activityrecord_table.Rows[activitylogrecord_table_row_counter][20] = new_activitylogrecord.lastModifiedOn;

                        activitylogrecord_table_row_counter++;

                        if (new_activitylogrecord.salesOpportunityStages != null)
                        {
                            foreach (BP_BrokerConnectV4.SalesOpportunityStage sos in new_activitylogrecord.salesOpportunityStages)
                            {
                                activityrecord_salesOpportunityStages_table.Rows.Add();
                                if (sos.stageTypeID != null) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][0] = sos.stageTypeID;
                                if (sos.startedOn != null && sos.startedOn.Year != 1) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][1] = sos.startedOn;
                                if (sos.completedOn != null && sos.completedOn.Year != 1) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][2] = sos.completedOn;
                                if (sos.daysOpen != null) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][3] = sos.daysOpen;
                                if (sos.probability != null) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][4] = sos.probability;
                                if (sos.estimatedCloseOn != null && sos.estimatedCloseOn.Year != 1) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][5] = sos.estimatedCloseOn;
                                if (sos.lastModifiedOn != null && sos.lastModifiedOn.Year != 1) activityrecord_salesOpportunityStages_table.Rows[salesOpportunityStages_table_row_counter][6] = sos.lastModifiedOn;
                                salesOpportunityStages_table_row_counter++;
                            }
                        }

                        if (new_activitylogrecord.activities != null)
                        {
                            foreach (BP_BrokerConnectV4.Activity activity in new_activitylogrecord.activities)
                            {
                                activityrecord_activity_table.Rows.Add();
                                if (activity.activityID != null) activityrecord_activity_table.Rows[activityrecord_activity_table_row_counter][0] = activity.activityID;
                                if (activity.description != null) activityrecord_activity_table.Rows[activityrecord_activity_table_row_counter][1] = activity.description;

                                activityrecord_activity_table_row_counter++;

                                if (activity.details != null)
                                {
                                    foreach (BP_BrokerConnectV4.ActivityDetail activity_detail in activity.details)
                                    {
                                        activityrecord_activity_details_table.Rows.Add();
                                        if (activity_detail.notes != null) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][0] = activity_detail.notes;
                                        if (activity_detail.followupOn != null && activity_detail.followupOn.Year != 1) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][1] = activity_detail.followupOn;
                                        if (activity_detail.createdOn != null && activity_detail.createdOn.Year != 1) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][2] = activity_detail.createdOn;
                                        if (activity_detail.completedOn != null && activity_detail.completedOn.Year != 1) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][3] = activity_detail.completedOn;
                                        if (activity_detail.createdByUserID != null) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][4] = activity_detail.createdByUserID;
                                        if (activity_detail.minutesLogged != null) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][5] = activity_detail.minutesLogged;
                                        if (activity_detail.statusID != null) activityrecord_activity_details_table.Rows[activityrecord_activity_details_table_row_counter][6] = activity_detail.statusID;
                                        activityrecord_activity_details_table_row_counter++;
                                    }
                                }
                            }
                        }



                        if (new_activitylogrecord.customFieldValues != null)
                        {

                            foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_activitylogrecord.customFieldValues)
                            {

                                activityCustomFieldValues_table.Rows.Add();
                                if (cfv.customFieldValueID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][0] = cfv.customFieldValueID;
                                if (cfv.customFieldID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][1] = cfv.customFieldID;

                                if (cfv.optionValueID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][2] = cfv.optionValueID;
                                if (cfv.valueText != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][3] = cfv.valueText;

                                //Code added to get all the customfields 
                                #region Getting all the Custom Fields
                                if (cust_struct.sections != null)
                                {
                                    foreach (BP_BrokerConnectV4.CustomSection cust_struct_sec in cust_struct.sections)
                                    {
                                        if (cust_struct_sec.customFields != null)
                                        {
                                            foreach (BP_BrokerConnectV4.CustomField cust_struct_sec_field in cust_struct_sec.customFields)
                                            {
                                                if (cust_struct_sec_field.customFieldID == cfv.customFieldID)
                                                {
                                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][4] = cust_struct_sec_field.label;
                                                }

                                            }
                                        }


                                    }
                                }
                                #endregion

                                activityCustomFieldValues_table_row_counter++;
                            }


                        }


                        //foreach (BP_BrokerConnectV4.CustomSection d in cust.sections)
                        //{
                        //    if (d.customFields!= null)
                        //    {
                        //        foreach (BP_BrokerConnectV4.CustomField cf in d.customFields)
                        //        {
                        //            customField_table.Rows.Add();
                        //            customField_table.Rows[cnt][0] = cf.customFieldID;
                        //            customField_table.Rows[cnt][1] = cf.label;
                        //            cnt++;
                        //        }
                        //    }


                        //}



                        retries = 10;
                    }


                    activityrecord_table.TableName = "activityrecord_table";
                    ds.Tables.Add(activityrecord_table);
                    activityrecord_salesOpportunityStages_table.TableName = "activityrecord_salesOpportunityStages_table";
                    ds.Tables.Add(activityrecord_salesOpportunityStages_table);
                    activityrecord_activity_table.TableName = "activityrecord_activity_table";
                    ds.Tables.Add(activityrecord_activity_table);
                    activityrecord_activity_details_table.TableName = "activityrecord_activity_details_table";
                    ds.Tables.Add(activityrecord_activity_details_table);
                    activityCustomFieldValues_table.TableName = "activityCustomFieldValues_table";
                    ds.Tables.Add(activityCustomFieldValues_table);



                    return ds;
                }

                catch (Exception ex)
                {
                    if (ex.Message.ToString() == "Unable to connect to the remote server" && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else if (ex.Message.ToString() == "The underlying connection was closed: The connection was closed unexpectedly." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else if (ex.Message.ToString() == "The session ID is not valid. Invoke the login operation on LoginServiceV2 to create a new session ID." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else
                    {
                        throw;
                    }
                }
                i++;
            } while (retries < 10);

            return ds;
        }

        public DataSet Get_Activity_Detail_For_Reports(int acvtivityid, string SessionId)
        {
            BP_BrokerConnectV4.ActivityLogRecord new_activitylogrecord = new BP_BrokerConnectV4.ActivityLogRecord();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            DataTable activityCustomFieldValues_table = new DataTable();

            activityCustomFieldValues_table.Columns.Add("customFieldValues_customFieldValueID", typeof(Int32));  // Row 1
            activityCustomFieldValues_table.Columns.Add("customFieldValues_customFieldID", typeof(Int32));  // Row 2
            activityCustomFieldValues_table.Columns.Add("customFieldValues_optionValueID", typeof(Int32));  // Row 3
            activityCustomFieldValues_table.Columns.Add("customFieldValues_valueText", typeof(string));  // Row 4

            int activityCustomFieldValues_table_row_counter = 0;

            int retries = 0;
            int i = 0;

            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;

            ListItem listitem = new ListItem();
            DataSet ds = new DataSet();

            do
            {
                try
                {
                    new_activitylogrecord = new BP_BrokerConnectV4.ActivityLogRecord();
                    new_activitylogrecord = new_connection.getActivityLogRecord(acvtivityid);

                    if (new_activitylogrecord != null)
                    {
                        if (new_activitylogrecord.customFieldValues != null)
                        {
                            foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_activitylogrecord.customFieldValues)
                            {
                                activityCustomFieldValues_table.Rows.Add();
                                if (cfv.customFieldValueID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][0] = cfv.customFieldValueID;
                                if (cfv.customFieldID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][1] = cfv.customFieldID;

                                if (cfv.optionValueID != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][2] = cfv.optionValueID;
                                if (cfv.valueText != null)
                                    activityCustomFieldValues_table.Rows[activityCustomFieldValues_table_row_counter][3] = cfv.valueText;

                                activityCustomFieldValues_table_row_counter++;
                            }
                        }

                        retries = 10;
                    }

                    activityCustomFieldValues_table.TableName = "activityCustomFieldValues_table";
                    ds.Tables.Add(activityCustomFieldValues_table);

                    return ds;
                }

                catch (Exception ex)
                {
                    if (ex.Message.ToString() == "Unable to connect to the remote server" && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else if (ex.Message.ToString() == "The underlying connection was closed: The connection was closed unexpectedly." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else if (ex.Message.ToString() == "The session ID is not valid. Invoke the login operation on LoginServiceV2 to create a new session ID." && retries < 10)
                    {
                        retries++;

                        SIH.sessionId = SessionId;//myloginresult.sessionID;
                        new_connection.SessionIdHeaderValue = SIH;
                        continue;
                    }
                    else
                    {
                        throw;
                    }
                }
                i++;
            } while (retries < 10);

            return ds;
        }

        public void BuildActivitiesTable()
        {
            try
            {
                activitiestableForReports.Columns.Add("recordID", typeof(Int32));  // Row 0  
                activitiestableForReports.Columns.Add("subject", typeof(string));  // Row 1  
                activitiestableForReports.Columns.Add("name", typeof(string));  // Row 2 
                activitiestableForReports.Columns.Add("createdon", typeof(string));  // Row 3  
                activitiestableForReports.Columns.Add("dueon", typeof(string));  // Row 4  
                activitiestableForReports.Columns.Add("status", typeof(string));  // Row 5  
                activitiestableForReports.Columns.Add("AccountID", typeof(Int32));  // Row 6
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public DataTable GetActivityInformation_For_Reports(int ClientID, string SessionId, int SubjectID)
        {
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.ActivityLogSearchCriteria new_activity_search = new BP_BrokerConnectV4.ActivityLogSearchCriteria();
            BP_BrokerConnectV4.ActivityLogRecordSummary[] new_activity_summary = new BP_BrokerConnectV4.ActivityLogRecordSummary[0];
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            activitiestableForReports.Clear();

            int activity_row_counter = 0;

            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;

            ListItem listitem = new ListItem();

            try
            {
                new_activity_search = new BP_BrokerConnectV4.ActivityLogSearchCriteria();
                new_activity_search.accountID = ClientID;
                new_activity_search.recordStatus = BP_BrokerConnectV4.RecordStatus.Open;
                new_activity_summary = new_connection.findActivityLogRecords(new_activity_search);

                if (new_activity_summary != null)
                {
                    foreach (BP_BrokerConnectV4.ActivityLogRecordSummary alrs in new_activity_summary)
                    {
                        if (alrs != null)
                        {
                            if (alrs.subjectID.Equals(SubjectID))
                            {
                                if (alrs.status.ToString().ToLower() == "open")
                                {
                                    activitiestableForReports.Rows.Add();

                                    activitiestableForReports.Rows[activity_row_counter][0] = alrs.recordID;

                                    if (alrs.subjectText != null)
                                        activitiestableForReports.Rows[activity_row_counter][1] = alrs.subjectText + " " + alrs.summary;

                                    if (alrs.assignedToFirstName != null && alrs.assignedToLastName != null)
                                        activitiestableForReports.Rows[activity_row_counter][2] = alrs.assignedToFirstName + " " + alrs.assignedToLastName;

                                    if (alrs.createdOn != null && alrs.createdOn.Year != 1)
                                        activitiestableForReports.Rows[activity_row_counter][3] = alrs.createdOn.ToShortDateString();

                                    if (alrs.dueOn != null && alrs.dueOn.Year != 1)
                                        activitiestableForReports.Rows[activity_row_counter][4] = alrs.dueOn.ToShortDateString();

                                    if (alrs.status != null)
                                        activitiestableForReports.Rows[activity_row_counter][5] = alrs.status.ToString();

                                    if (alrs.accountID != null)
                                        activitiestableForReports.Rows[activity_row_counter][6] = alrs.accountID;

                                    activity_row_counter++;
                                }

                            }
                        }
                    }

                    activitiestableForReports = activitiestableForReports.DefaultView.ToTable(true);
                }
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return activitiestableForReports;

        }
    }
}