﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;

using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;



using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Core;

namespace BenefitPointSummaryPortal.BAL.ExecutiveSummaryReport
{
    public class ExecutiveSummaryReport : System.Web.UI.Page
    {
        public void WriteFileds_ExecutiveSummaryReportFooter(Word.Document oWordDoc, Word.Application oWordApp, string ClientName)
        {
            #region MergeField With Footer
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentDate"))
                            {
                                field.Select();
                                string FooterCurrentDate = System.DateTime.Now.ToString("MM/dd/yyyy");
                                if (!string.IsNullOrEmpty(FooterCurrentDate))
                                {
                                    oWordApp.Selection.TypeText(FooterCurrentDate);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                string FooterCurrentDate = System.DateTime.Now.Year.ToString() ;
                                if (!string.IsNullOrEmpty(FooterCurrentDate))
                                {
                                    oWordApp.Selection.TypeText(FooterCurrentDate);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }


                        }
                    }
                }
            }
            #endregion
        }
    }
}