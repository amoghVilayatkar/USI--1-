﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Collections;
namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteVolumeCalculator
    {

        public void WriteActiveEnrollmentTally(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName, DataSet BenefitDS)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            wkSheet.Cells[1, 1] = ClientName;
            DateTime dateTime = DateTime.UtcNow.Date;
            wkSheet.Cells[3, 1] = dateTime.ToString("MM/dd/yyyy") + " Census";
            wkSheet.Application.Goto(wkSheet.Cells[1, 1], true);
        }
        public void WriteLifeFlatBenifites(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;
            #region Benifit plan ammount - 6/3
            DataRow drBenefitValues_BenifitAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186").FirstOrDefault();

            string BenefitValue_UOM = drBenefitValues_BenifitAmount["UOM"].ToString();
            if (drBenefitValues_BenifitAmount != null && BenefitValue_UOM == "dollars")
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenifitAmount);

            }
            wkSheet.Cells[6, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;

            #endregion
            #region  Reduction of Benefits

            #region 65-69 6/6
            //Reduction of Benefits - 65-69
            DataRow drBenefitValues_65_69 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 2").FirstOrDefault();
            if (drBenefitValues_65_69 != null)
            {

                strBenefitSummaryAttributeValue = drBenefitValues_65_69["value"].ToString().Trim() + drBenefitValues_65_69["suffix"].ToString();

            }
            wkSheet.Cells[6, BenefitStartIndex + 4] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 70-74 7/6
            DataRow drBenefitValues_70_74 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 3").FirstOrDefault();
            if (drBenefitValues_70_74 != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = drBenefitValues_70_74["value"].ToString().Trim() + drBenefitValues_70_74["suffix"].ToString();

            }
            wkSheet.Cells[7, BenefitStartIndex + 4] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 75-79 8/6
            DataRow drBenifitValue_45_49 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 4 ").FirstOrDefault();
            if (drBenifitValue_45_49 != null)
            {
                strBenefitSummaryAttributeValue = drBenifitValue_45_49["value"].ToString().Trim() + drBenifitValue_45_49["suffix"].ToString();

            }
            wkSheet.Cells[8, BenefitStartIndex + 4] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 80-84 9/6
            DataRow drBeniofitValue_80_85 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 5 ").FirstOrDefault();
            if (drBeniofitValue_80_85 != null)
            {
                strBenefitSummaryAttributeValue = drBeniofitValue_80_85["value"].ToString().Trim() + drBeniofitValue_80_85["suffix"].ToString();
            }
            wkSheet.Cells[9, BenefitStartIndex + 4] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 85 and greater 10/6
            DataRow drBenifitValue_85AndOlder = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 22").FirstOrDefault();
            if (drBenifitValue_85AndOlder != null)
            {
                strBenefitSummaryAttributeValue = drBenifitValue_85AndOlder["value"].ToString().Trim() + drBenifitValue_85AndOlder["suffix"].ToString();
            }
            wkSheet.Cells[10, BenefitStartIndex + 4] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #endregion

            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        public void WriteLifeMultipleOfSalary(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;
            #region Benifit plan ammount - 6/3
            DataRow drBenefitValues_BenifitAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186").FirstOrDefault();
            string BenefitValue_UOM = drBenefitValues_BenifitAmount["UOM"].ToString();
            if (drBenefitValues_BenifitAmount != null && BenefitValue_UOM == "X_salary")
            {
                string Value = Convert.ToString(drBenefitValues_BenifitAmount["value"]).Trim();
                if (!string.IsNullOrEmpty(Value))
                {
                    strBenefitSummaryAttributeValue = Value;
                }
                else
                {
                    strBenefitSummaryAttributeValue = "";// GetBenefitFormattedValue(drBenefitValues_BenifitAmount);
                }
                /*******************************OLD CODE COMMENTED BY AMOGH *********/
                //strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_BenifitAmount);
            }
            wkSheet.Cells[6, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            #endregion
            #region Benifit plan ammount - 7/3
            DataRow drBenifitValue_OverallMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
            if (drBenifitValue_OverallMaximum != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifitValue_OverallMaximum);

            }
            wkSheet.Cells[7, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;

            #endregion


            #region  Reduction of Benefits

            #region 65-69 6/6
            //Reduction of Benefits - 65-69
            DataRow drBenefitValues_65_69 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 2").FirstOrDefault();

            if (drBenefitValues_65_69 != null)
            {
                strBenefitSummaryAttributeValue = drBenefitValues_65_69["value"].ToString().Trim() + drBenefitValues_65_69["suffix"].ToString();

            }
            wkSheet.Cells[6, BenefitStartIndex + 6] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 70-74 7/6
            DataRow drBenefitValues_70_74 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 3").FirstOrDefault();
            if (drBenefitValues_70_74 != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = drBenefitValues_70_74["value"].ToString().Trim() + drBenefitValues_70_74["suffix"].ToString();

            }
            wkSheet.Cells[7, BenefitStartIndex + 6] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 75-79 8/6
            DataRow drBenifitValue_75_79 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 4 ").FirstOrDefault();
            if (drBenifitValue_75_79 != null)
            {
                strBenefitSummaryAttributeValue = drBenifitValue_75_79["value"].ToString().Trim() + drBenifitValue_75_79["suffix"].ToString();

            }
            wkSheet.Cells[8, BenefitStartIndex + 6] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 80-84 9/6
            DataRow drBeniofitValue_80_85 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 5 ").FirstOrDefault();
            if (drBeniofitValue_80_85 != null)
            {
                strBenefitSummaryAttributeValue = drBeniofitValue_80_85["value"].ToString().Trim() + drBeniofitValue_80_85["suffix"].ToString();
            }
            wkSheet.Cells[9, BenefitStartIndex + 6] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #region 85 and greater 10/6
            DataRow drBenifitValue_85AndOlder = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 22").FirstOrDefault();
            if (drBenifitValue_85AndOlder != null)
            {
                strBenefitSummaryAttributeValue = drBenifitValue_85AndOlder["value"].ToString().Trim() + drBenifitValue_85AndOlder["suffix"].ToString();
            }
            wkSheet.Cells[10, BenefitStartIndex + 6] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            #endregion
            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        public void WriteSTDCoverdBenifits(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS, bool WriteSummaryName = false)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (WriteSummaryName)
                wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;


            #region  STD Benifit overall(percentage)
            DataRow drBenefitValues_percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
            if (drBenefitValues_percentage != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_percentage);

            }
            wkSheet.Cells[9, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";

            // STD benifitBenifit maximum

            DataRow drBenifitValue_OverallMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 ").FirstOrDefault();
            if (drBenifitValue_OverallMaximum != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifitValue_OverallMaximum);

            }
            wkSheet.Cells[10, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;

            #endregion

            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        public void WriteSTDCoverdPayroll(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS, bool WriteSummaryName = false)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (WriteSummaryName)
                wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;


            #region  STD Benifit overall(percentage)
            DataRow drBenefitValues_percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 ").FirstOrDefault();
            if (drBenefitValues_percentage != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_percentage);

            }
            wkSheet.Cells[9, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";

            // STD benifitBenifit maximum

            DataRow drBenifitValue_OverallMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 ").FirstOrDefault();
            if (drBenifitValue_OverallMaximum != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifitValue_OverallMaximum);

            }
            wkSheet.Cells[10, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;

            #endregion
            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        public void WriteLTDCoverdBenifits(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS, bool WriteSummaryName = false)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (WriteSummaryName)
                wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;

            #region  Ltd Benifit percentage
            DataRow drBenifitValue_LtdPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71").FirstOrDefault();

            if (drBenifitValue_LtdPercentage != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifitValue_LtdPercentage);

            }
            wkSheet.Cells[9, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";

            //   Monthly benifit maximum 
            DataRow drBenifit_LtdOverallMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();

            if (drBenifit_LtdOverallMaximum != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifit_LtdOverallMaximum);

            }
            wkSheet.Cells[10, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        public void WriteLTDCoverdPayroll(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, string BenifitSummaryName, int BenefitSummaryID, int BenefitStartIndex, DataSet BenefitDS, bool WriteSummaryName = false)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            if (WriteSummaryName)
                wkSheet.Cells[1, BenefitStartIndex] = BenifitSummaryName;
            #region  Ltd Benifit percentage
            DataRow drBenifitValue_LtdPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71").FirstOrDefault();

            if (drBenifitValue_LtdPercentage != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifitValue_LtdPercentage);

            }
            wkSheet.Cells[9, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";

            //   Monthly benifit maximum 
            DataRow drBenifit_LtdOverallMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 ").FirstOrDefault();

            if (drBenifit_LtdOverallMaximum != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenifit_LtdOverallMaximum);

            }
            wkSheet.Cells[10, BenefitStartIndex + 1] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = "";
            #endregion
            wkSheet.Application.Goto(wkSheet.Cells[1, 2], true);
        }
        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
            {
                string Value = dr["value"].ToString().Trim();
                if (!Value.Contains(","))
                {
                    if (Value != string.Empty && dr["UOM"].ToString().ToLower() == "dollars")
                    {
                        if (Value.Contains('.'))
                            Value = string.Format("{0:#,0.##}", double.Parse(Value));
                        else
                            Value = string.Format("{0:#,0.##}", int.Parse(Value));
                    }
                }
                return (dr["prefix"].ToString() + Value + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            }
            return "";
        }
        public void HideWorkSheets(Excel.Application myExcelApp, Excel.Workbook myWorkbook, List<string> SheetNames)
        {
            for (int i = 1; i <= myWorkbook.Worksheets.Count; i++)
            {
                Excel.Worksheet wkSheetToCheck = (Excel.Worksheet)myWorkbook.Worksheets[i];
                if (wkSheetToCheck.Name != null)
                {
                    if (SheetNames.Contains(wkSheetToCheck.Name))
                    {
                        wkSheetToCheck.Visible = Excel.XlSheetVisibility.xlSheetHidden;
                    }
                }
            }

        }
        public Dictionary<int, int> CreateLifeFlatBenefitStructure(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 9;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;
            }

            return BenefitSummaryStartIndexes;
        }
        public Dictionary<int, int> CreateLifeMultipleSalaryStructure(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 10;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                Excel.Range To = wkSheet.Cells[1, SummaryEndColumnIndex + 1];
                //To.Select();
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;
            }

            return BenefitSummaryStartIndexes;

        }
        public Dictionary<int, int> CreateSTDCoverdBenifitsSruture(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 6;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                Excel.Range To = wkSheet.Cells[1, SummaryEndColumnIndex + 1];
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;

            }

            return BenefitSummaryStartIndexes;
        }
        public Dictionary<int, int> CreateSTDCoverdPayrollruture(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 6;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                Excel.Range To = wkSheet.Cells[1, SummaryEndColumnIndex + 1];
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;
            }

            return BenefitSummaryStartIndexes;

        }
        public Dictionary<int, int> CreateLTDCoverdBenifitsSruture(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 6;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                Excel.Range To = wkSheet.Cells[1, SummaryEndColumnIndex + 1];
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;

            }

            return BenefitSummaryStartIndexes;
        }
        public Dictionary<int, int> CreateLTDCoverdPayrollruture(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetName, List<int> BenefitSumaries)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetName];
            int TotalRows = wkSheet.Rows.Count;
            int TotalCellsPerSummary = 6;
            int SummaryRangeStartColumnIndex = 2;
            int SummaryEndColumnIndex = SummaryRangeStartColumnIndex + TotalCellsPerSummary; //11
            Excel.Range from = wkSheet.Range[wkSheet.Cells[1, SummaryRangeStartColumnIndex], wkSheet.Cells[TotalRows, SummaryEndColumnIndex]];//[1,2],[99,11]
            from.Copy();
            Dictionary<int, int> BenefitSummaryStartIndexes = new Dictionary<int, int>();
            BenefitSummaryStartIndexes[BenefitSumaries[0]] = SummaryRangeStartColumnIndex;


            for (int i = 1; i < BenefitSumaries.Count; i++)
            {
                BenefitSummaryStartIndexes[BenefitSumaries[i]] = SummaryEndColumnIndex + 1;
                Excel.Range To = wkSheet.Cells[1, SummaryEndColumnIndex + 1];
                wkSheet.Application.Goto(wkSheet.Cells[1, SummaryEndColumnIndex + 1], true);
                wkSheet.Paste();
                SummaryEndColumnIndex = SummaryEndColumnIndex + TotalCellsPerSummary + 1;
            }

            return BenefitSummaryStartIndexes;

        }
    }
}