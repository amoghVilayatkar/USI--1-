﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate6_ValueSummary_V2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;

        #region Colors
        ////public Word.WdColor textbox_color(string color)
        ////{
        ////    Color table_textbox = Color.FromArgb(79, 128, 189);
        ////    switch (color)
        ////    {
        ////        case "Blue": table_textbox = Color.FromArgb(79, 128, 189); break;
        ////        case "Green": table_textbox = Color.FromArgb(21, 95, 33); break;
        ////        case "Black": table_textbox = Color.FromArgb(0, 0, 0); break;
        ////        case "Maroon": table_textbox = Color.FromArgb(63, 17, 17); break;

        ////        case "USI Blue": table_textbox = Color.FromArgb(9, 84, 155); break;
        ////        case "True Blue": table_textbox = Color.FromArgb(0, 0, 255); break;
        ////        case "Dark Green": table_textbox = Color.FromArgb(0, 102, 0); break;
        ////        case "Bright Green": table_textbox = Color.FromArgb(0, 153, 0); break;
        ////        case "Olive Green": table_textbox = Color.FromArgb(131, 141, 9); break;
        ////        case "Dark Red": table_textbox = Color.FromArgb(128, 0, 0); break;
        ////        case "Red": table_textbox = Color.FromArgb(204, 0, 0); break;
        ////        case "Mustard": table_textbox = Color.FromArgb(212, 160, 15); break;
        ////        case "Orange": table_textbox = Color.FromArgb(255, 165, 0); break;
        ////        case "Purple": table_textbox = Color.FromArgb(102, 0, 102); break;
        ////        case "Light Brown": table_textbox = Color.FromArgb(153, 102, 51); break;
        ////        case "Dark Brown": table_textbox = Color.FromArgb(102, 51, 0); break;
        ////        case "Grey": table_textbox = Color.FromArgb(119, 119, 119); break;
        ////        default: table_textbox = Color.FromArgb(105, 29, 29); break;
        ////    }
        ////    int rgb_textbox = ColorTranslator.ToOle(table_textbox);
        ////    Word.WdColor wdColor_textbox = (Word.WdColor)rgb_textbox;
        ////    return wdColor_textbox;
        ////}

        ////public Word.WdColor border_color(string color)
        ////{
        ////    Color border = Color.FromArgb(79, 128, 189);

        ////    switch (color)
        ////    {
        ////        case "Blue": border = Color.FromArgb(79, 128, 189); break;
        ////        case "Green": border = Color.FromArgb(21, 95, 33); break;
        ////        case "Black": border = Color.FromArgb(0, 0, 0); break;
        ////        case "Maroon": border = Color.FromArgb(63, 17, 17); break;

        ////        case "USI Blue": border = Color.FromArgb(9, 84, 155); break;
        ////        case "True Blue": border = Color.FromArgb(0, 0, 255); break;
        ////        case "Dark Green": border = Color.FromArgb(0, 102, 0); break;
        ////        case "Bright Green": border = Color.FromArgb(0, 153, 0); break;
        ////        case "Olive Green": border = Color.FromArgb(131, 141, 9); break;
        ////        case "Dark Red": border = Color.FromArgb(128, 0, 0); break;
        ////        case "Red": border = Color.FromArgb(204, 0, 0); break;
        ////        case "Mustard": border = Color.FromArgb(212, 160, 15); break;
        ////        case "Orange": border = Color.FromArgb(255, 165, 0); break;
        ////        case "Purple": border = Color.FromArgb(102, 0, 102); break;
        ////        case "Light Brown": border = Color.FromArgb(153, 102, 51); break;
        ////        case "Dark Brown": border = Color.FromArgb(102, 51, 0); break;
        ////        case "Grey": border = Color.FromArgb(119, 119, 119); break;
        ////        default: border = Color.FromArgb(105, 29, 29); break;
        ////    }
        ////    int rgb_border = ColorTranslator.ToOle(border);
        ////    Word.WdColor wdColor_border = (Word.WdColor)rgb_border;
        ////    return wdColor_border;
        ////}

        ////public Word.WdColor font_color(string color)
        ////{
        ////    Color font = Color.FromArgb(0, 68, 123);
        ////    switch (color)
        ////    {
        ////        case "Blue": font = Color.FromArgb(0, 68, 123); break;
        ////        case "Green": font = Color.FromArgb(14, 62, 22); break;
        ////        case "Black": font = Color.FromArgb(38, 38, 38); break;
        ////        case "Maroon": font = Color.FromArgb(63, 17, 17); break;

        ////        case "USI Blue": font = Color.FromArgb(6, 58, 106); break;
        ////        case "True Blue": font = Color.FromArgb(0, 0, 192); break;
        ////        case "Dark Green": font = Color.FromArgb(0, 66, 0); break;
        ////        case "Bright Green": font = Color.FromArgb(0, 96, 0); break;
        ////        case "Olive Green": font = Color.FromArgb(63, 68, 4); break;
        ////        case "Dark Red": font = Color.FromArgb(84, 0, 0); break;
        ////        case "Red": font = Color.FromArgb(150, 0, 0); break;
        ////        case "Mustard": font = Color.FromArgb(118, 89, 8); break;
        ////        case "Orange": font = Color.FromArgb(172, 94, 0); break;
        ////        case "Purple": font = Color.FromArgb(100, 9, 125); break;
        ////        case "Light Brown": font = Color.FromArgb(81, 54, 27); break;
        ////        case "Dark Brown": font = Color.FromArgb(84, 42, 0); break;
        ////        case "Grey": font = Color.FromArgb(84, 84, 84); break;
        ////        default: font = Color.FromArgb(0, 68, 123); break;
        ////    }

        ////    int rgb_font = ColorTranslator.ToOle(font);
        ////    Word.WdColor wdColor_font = (Word.WdColor)rgb_font;
        ////    return wdColor_font;
        ////}

        ////public Word.WdColor cell_color(string color)
        ////{
        ////    Color table_cell = Color.FromArgb(211, 223, 238);

        ////    switch (color)
        ////    {
        ////        case "Blue": table_cell = Color.FromArgb(211, 223, 238); break;
        ////        case "Green": table_cell = Color.FromArgb(192, 239, 175); break;
        ////        case "Black": table_cell = Color.FromArgb(217, 217, 217); break;
        ////        case "Maroon": table_cell = Color.FromArgb(237, 177, 177); break;

        ////        case "USI Blue": table_cell = Color.FromArgb(140, 197, 248); break;
        ////        case "True Blue": table_cell = Color.FromArgb(163, 197, 251); break;
        ////        case "Dark Green": table_cell = Color.FromArgb(0, 188, 0); break;
        ////        case "Bright Green": table_cell = Color.FromArgb(121, 255, 121); break;
        ////        case "Olive Green": table_cell = Color.FromArgb(223, 247, 147); break;
        ////        case "Dark Red": table_cell = Color.FromArgb(255, 125, 125); break;
        ////        case "Red": table_cell = Color.FromArgb(255, 143, 143); break;
        ////        case "Mustard": table_cell = Color.FromArgb(245, 210, 11); break;
        ////        case "Orange": table_cell = Color.FromArgb(255, 199, 97); break;
        ////        case "Purple": table_cell = Color.FromArgb(224, 183, 255); break;
        ////        case "Light Brown": table_cell = Color.FromArgb(217, 178, 139); break;
        ////        case "Dark Brown": table_cell = Color.FromArgb(200, 144, 88); break;
        ////        case "Grey": table_cell = Color.FromArgb(196, 196, 196); break;
        ////        default: table_cell = Color.FromArgb(211, 223, 238); break;
        ////    }

        ////    int rgb_cell = ColorTranslator.ToOle(table_cell);
        ////    Word.WdColor wdColor_cell = (Word.WdColor)rgb_cell;

        ////    return wdColor_cell;
        ////}
        # endregion

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        ///public void WriteFieldToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, string selectedcolor, string IncomeProtectionPlanList, DropDownList ddlImageOption = null)
        public void WriteFieldToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, string selectedcolor, string IncomeProtectionPlanList, DropDownList ddlImageOption = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                int index = -1;

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 4")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[19].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[19].Range.Font.Color = wdColor_font;

                oWordDoc.Tables[20].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[20].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[20].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[20].Range.Font.Color = wdColor_font;

                /**********Commented by Amogh ****/
                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    #region img
                                    if (fieldName.Contains("Picture_1"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //  Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //  var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 1.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.75f);
                                        //shape.Height = oWordApp.InchesToPoints(2.05f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 3.95f, 2.27f);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture_2"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 2.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.63f, 4.04f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }

                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 3"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 3.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 3", 3.01f, 2.23f);
                                        continue;
                                    }
                                    //if (fieldName.Contains("Picture 4"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 4.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    //if (fieldName.Contains("Picture 5"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 5.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    if (fieldName.Contains("Picture 6"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);

                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 6.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 6", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(1.96f);
                                        //shape.Height = oWordApp.InchesToPoints(1.51f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 7"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);

                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 6.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 7", 1.62f, 1.4f);
                                        //shape.Width = oWordApp.InchesToPoints(1.96f);
                                        //shape.Height = oWordApp.InchesToPoints(1.51f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeCenter;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 13"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 7.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 13", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(4.22f);
                                        //shape.Height = oWordApp.InchesToPoints(1.12f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 17"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 7.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 17", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(4.22f);
                                        //shape.Height = oWordApp.InchesToPoints(1.12f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            //shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 8"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 8.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 8", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(2.67f);
                                        //shape.Height = oWordApp.InchesToPoints(5.2f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionBottomMarginArea;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    #endregion

                                    if (fieldName.Contains("Client_Name1"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());

                                        continue;
                                    }

                                    if (fieldName.Contains("Wellness Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("client website"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString()))
                                        {
                                            oWordApp.Selection.TypeText(" | " + AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date Of Medical Plan minus 1 day"))
                                    {
                                        myMergeField.Select();
                                        string renewDate = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime rDate = Convert.ToDateTime(renewDate).AddDays(-1);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(rDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(rDate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("First Medical Plan Renewal Year"))
                                    {
                                        myMergeField.Select();

                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("HSA Medical Plan Renewal Year"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                                        continue;
                                    }
                                    //if (fieldName.Contains("unmarriedchildtoage"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //}
                                    //if (fieldName.Contains("definitionofdomesticpartner"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    //        oWordApp.Selection.TypeText(domesticPartner);
                                    //        continue;
                                    //    }
                                    //}
                                    //if (Emp.Rows.Count > 0)
                                    //{
                                    //    if (fieldName.Contains("Employee Status"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("Working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                    //        continue;
                                    //    }

                                    //    if (fieldName.Contains("Frequency"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    if (fieldName.Contains("Employee Status"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("Working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }

                                    //    if (fieldName.Contains("Frequency"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //}
                                    //if (fieldName.Contains("Medical Plan Waiting Period"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().ToLower().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //    continue;
                                    //}

                                    ////if (ddlBRC.SelectedItem.Text != "None")
                                    if (ddlBRCSelectedValue == "YES")
                                    {
                                        if (fieldName.Contains("BRC_Details"))
                                        {
                                            myMergeField.Select();
                                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            //oWordApp.Selection.TypeText("\f"); // For page break
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }

                                    if (BRCList.Count > 0)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date of First Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(renewdate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewdate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    // For header and sub header field writing starts here
                                    if (fieldName.Contains("WHAT’S INSIDE THIS GUIDE?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("WHAT’S INSIDE THIS GUIDE?");
                                        continue;
                                    }

                                    if (fieldName.Contains("INTRODUCTION"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("INTRODUCTION");
                                        continue;
                                    }

                                    if (fieldName.Contains("Takes Your Wellness Seriously"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Takes Your Wellness Seriously");
                                        continue;
                                    }

                                    if (fieldName.Contains("EMPLOYEE CONTRIBUTION RATES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("EMPLOYEE CONTRIBUTION RATES");
                                        continue;
                                    }

                                    if (fieldName.Contains("GET MORE VALUE FROM YOUR PLANS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("GET MORE VALUE FROM YOUR PLANS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Minimize your out-of-pocket expenses"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Minimize your out-of-pocket expenses");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use the Emergency Room ONLY for emergencies"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Use the Emergency Room ONLY for emergencies");
                                        continue;
                                    }

                                    if (fieldName.Contains("Annual physical exams and cancer screening tests are 100% covered!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Annual physical exams and cancer screening tests are 100% covered!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Preventive dental care is covered 100%!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Preventive dental care is covered 100%!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Save tax dollars and enroll in a Flexible Spending Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Save tax dollars and enroll in a Flexible Spending Account");
                                        continue;
                                    }

                                    if (fieldName.Contains("Rates Effective"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Effective");
                                        continue;
                                    }

                                    if (fieldName.Contains("MEDICAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("MEDICAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("DENTAL BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DENTAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("In-network vs. out-of-network"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("In-network vs. out-of-network");
                                        continue;
                                    }

                                    if (fieldName.Contains("Be prepared and plan ahead"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Be prepared and plan ahead");
                                        continue;
                                    }

                                    if (fieldName.Contains("VISION BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF VISION BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Using your vision benefit is easy!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Using your vision benefit is easy!");
                                        continue;
                                    }

                                    if (fieldName.Contains("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use-it or lose-it benefit"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Use-it or lose-it benefit");
                                        continue;
                                    }

                                    if (fieldName.Contains("Example of tax savings"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Example of tax savings");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("INCOME PROTECTION BENEFIT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("INCOME PROTECTION BENEFIT");
                                        continue;
                                    }
                                    if (fieldName.Contains("IncomeProtectionPlanList"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(IncomeProtectionPlanList);

                                        continue;
                                    }
                                    if (fieldName.Contains("SUMMARY OF BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF BENEFITS");
                                        continue;
                                    }



                                    if (fieldName.Contains("VALUE-ADDED PROGRAMS AND SERVICES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("VALUE-ADDED PROGRAMS AND SERVICES");
                                        continue;
                                    }

                                    if (fieldName.Contains("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES");
                                        continue;
                                    }

                                    if (fieldName.Contains("CONTACT NUMBERS & WEBSITE LINKS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("CONTACT NUMBERS & WEBSITE LINKS");
                                        continue;
                                    }

                                    if (fieldName.Contains("THE BENEFIT RESOURCE CENTER"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("THE BENEFIT RESOURCE CENTER");
                                        continue;
                                    }

                                    if (fieldName.Contains("If you have any questions, please contact the following:"))
                                    {
                                        myMergeField.Select();
                                        // oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("If you have any questions, please contact the following:");
                                        continue;
                                    }

                                    if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call the BRC for assistance with:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call the BRC for assistance with:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call Toll Free"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call Toll Free");
                                        continue;
                                    }

                                    if (fieldName.Contains("or email"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("or email");
                                        continue;
                                    }

                                    if (fieldName.Contains("This guide is provided to you by"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("This guide is provided to you by");
                                        continue;
                                    }

                                    if (fieldName.Contains("and BRC"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("and");
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, string selectedcolor)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(11, "45");   //Calendar Year Deductible individual
                HashtableMedicalInNetwork1.Add(1, "44");    //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(22, "53");   //Calendar Year Out of Pocket Maximum (Individual)
                HashtableMedicalInNetwork1.Add(2, "52");    //Calendar Year Out of Pocket Maximum (Family)


                Hashtable HashtableMedicalInNetwork2 = new Hashtable();
                HashtableMedicalInNetwork2.Add(2, "112");   //General Plan Information Coinsurence
                HashtableMedicalInNetwork2.Add(3, "386");   //Physician Office Visit (Primary)
                HashtableMedicalInNetwork2.Add(4, "414");   //Specialists Office Visit
                HashtableMedicalInNetwork2.Add(5, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork2.Add(66, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalInNetwork2.Add(6, "971");            //Other Services[Complex Radiology]
                HashtableMedicalInNetwork2.Add(77, "295");  //Inpatient Hospitalization
                HashtableMedicalInNetwork2.Add(7, "409");   //Hospital/Facility [Outpatient Care]
                HashtableMedicalInNetwork2.Add(8, "184");   //Emergency Room
                HashtableMedicalInNetwork2.Add(9, "555");   //Urgent Care

                Hashtable HashtableMedicalOutNetwork2 = new Hashtable();
                HashtableMedicalOutNetwork2.Add(2, "112");   //General Plan Information Coinsurence
                HashtableMedicalOutNetwork2.Add(3, "386");   //Physician Office Visit (Primary)
                HashtableMedicalOutNetwork2.Add(4, "414");   //Specialists Office Visit
                HashtableMedicalOutNetwork2.Add(5, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalOutNetwork2.Add(66, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalOutNetwork2.Add(6, "971");            //Other Services[Complex Radiology]
                // HashtableMedicalOutNetwork2.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalOutNetwork2.Add(77, "295");  //Inpatient Hospitalization
                HashtableMedicalOutNetwork2.Add(7, "409");   //Hospital/Facility [Outpatient Care]
                HashtableMedicalOutNetwork2.Add(8, "184");   //Emergency Room
                HashtableMedicalOutNetwork2.Add(9, "555");   //Urgent Care
                #endregion
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int count = 1;
                string InNetwork_Indivisual_Plan1 = string.Empty;
                string InNetwork_Family_Plan1 = string.Empty;
                string OutOfPocket_Individual_Plan1 = string.Empty;
                string Inpatient_Hospitalization_Plan1 = string.Empty;
                string X_Ray_Services_Plan1 = string.Empty;

                int TableNo = 6;
                int TableNo_FirstTable = 5;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            TableNo_FirstTable = 5;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 6;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            TableNo_FirstTable = 7;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 8;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            TableNo_FirstTable = 9;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 10;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            TableNo_FirstTable = 11;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 12;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (count == 5)
                                        {
                                            TableNo_FirstTable = 13;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 14;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (count == 6)
                                        {
                                            TableNo_FirstTable = 15;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;

                                            TableNo = 16;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = wdColor_font;
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                            }
                                        }
                                        if (key == 22)
                                        {
                                            OutOfPocket_Individual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 2)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (OutOfPocket_Individual_Plan1 + " individual / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " family  \n";
                                        }
                                        else if (key == 11)
                                        {
                                            InNetwork_Indivisual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 1)
                                        {
                                            InNetwork_Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (InNetwork_Indivisual_Plan1 + " individual / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " family \n";
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalInNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork2[key].ToString())
                                    {
                                        if (key == 2)
                                        {
                                            if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " unless otherwise noted below";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = " ";
                                            }
                                        }
                                        else if (key == 77)
                                        {
                                            Inpatient_Hospitalization_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 7)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = Inpatient_Hospitalization_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 66)
                                        {
                                            X_Ray_Services_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 6)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = X_Ray_Services_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            #region Out of Network
                            foreach (int key in HashtableMedicalOutNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork2[key].ToString())
                                    {
                                        if (key == 2)
                                        {
                                            if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " unless otherwise noted below";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = " ";
                                            }
                                        }
                                        else if (key == 77)
                                        {
                                            Inpatient_Hospitalization_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 7)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = Inpatient_Hospitalization_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 66)
                                        {
                                            X_Ray_Services_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 6)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = X_Ray_Services_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Medical Carrier Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(" " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("HMO_Med_Plan_" + count))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical HMO")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("PPO_Med_Plan_" + count))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical PPO")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (count == 1)
                                    {
                                        if (fieldName.Contains("First Medical Plan Year"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            continue;
                                        }

                                        if (fieldName.Contains("First Medical Plan Expiry Date"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"]).ToShortDateString().ToString());
                                            continue;
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string Preferred_Specialty = "";
                string NoOfDaysSupply = "";
                int rowcount = 10;
                int colcount = 2;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "380");   //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");    //Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");     //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");     //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(4, "380");    //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs_OutNetwork.Add(5, "881");   //Prescription Categories[Preferred Specialty]

                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");   //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");    //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");    //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "378");   //Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                #region MailOrder_OutNetwork
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                HashtableMailOrder_OutNetwork.Add(1, "211");    //Mail Order[Generic]
                HashtableMailOrder_OutNetwork.Add(2, "76");     //Mail Order[Formulary]
                HashtableMailOrder_OutNetwork.Add(3, "82");     //Mail Order[Non Formulary]
                HashtableMailOrder_OutNetwork.Add(4, "378");    //Mail Order[Maximum Day Supply]
                HashtableMailOrder_OutNetwork.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    # region Priscription Drugs IN_Network

                    value = "";
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";
                    Preferred_Specialty = "";
                    NoOfDaysSupply = "";

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }
                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }
                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;


                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[12].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 5)
                            {
                                oWordDoc.Tables[14].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 6)
                            {
                                oWordDoc.Tables[16].Cell(10, 2).Range.Text = value;
                            }
                    #endregion

                            # region Priscription Drugs Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            NoOfDaysSupply = "";

                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }

                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[12].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 5)
                            {
                                oWordDoc.Tables[14].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 6)
                            {
                                oWordDoc.Tables[16].Cell(10, 3).Range.Text = value;
                            }
                            #endregion

                            #region Mail Order In_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            NoOfDaysSupply = "";
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }

                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;
                            Preferred_Specialty = "";


                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[12].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 5)
                            {
                                oWordDoc.Tables[14].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 6)
                            {
                                oWordDoc.Tables[16].Cell(11, 2).Range.Text = value;
                            }
                            #endregion

                            #region Mail Order Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            NoOfDaysSupply = "";

                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }

                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[12].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 5)
                            {
                                oWordDoc.Tables[14].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 6)
                            {
                                oWordDoc.Tables[16].Cell(11, 3).Range.Text = value;
                            }
                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            Preferred_Specialty = "";
                            NoOfDaysSupply = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, string selectedcolor)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(2, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalInNetwork.Add(4, "164");     //Preventive & Diagnostic Care 
                HashtableDentalInNetwork.Add(6, "64");      //Basic Restorative Care - Basic  
                HashtableDentalInNetwork.Add(8, "336");     //Major Restorative Care - Major 
                HashtableDentalInNetwork.Add(10, "314");     //Orthodontia [Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(88, "392");    //Orthodontic Services 
                HashtableDentalInNetwork.Add(11, "152");     //Orthodontia [Dependent Children]

                #endregion
                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(2, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalOutNetwork.Add(4, "164");     //Preventive & Diagnostic Care 
                HashtableDentalOutNetwork.Add(6, "64");      //Basic Restorative Care - Basic 
                HashtableDentalOutNetwork.Add(8, "336");     //Major Restorative Care - Major 
                HashtableDentalOutNetwork.Add(10, "314");     //Orthodontia [Lifetime Orthodontia Maximum]
                HashtableDentalOutNetwork.Add(88, "392");    //Orthodontic Services 
                //HashtableDentalOutNetwork.Add(11, "152");     //Orthodontia [Dependent Children]

                #endregion
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                string Orthodontia_Lifetime_Maximum = "";
                string Orthodontia_Dependent_Children = "";
                string Website = string.Empty;
                string Phone_Number = string.Empty;
                string value = "";
                int DentalTBL_number = 0;
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            Orthodontia_Dependent_Children = "";
                            Website = "";
                            Phone_Number = "";

                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (foundRows.Count() > 0)
                            {
                                Website = Convert.ToString(foundRows[0]["Website"].ToString());
                                Phone_Number = Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                            }

                            #region color
                            if (count == 1)
                            {
                                DentalTBL_number = 17;

                                //oWordDoc.Tables[17].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[17].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[17].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                //oWordDoc.Tables[17].Range.Font.Color = wdColor_font;
                                //for (int i = 3; i < oWordDoc.Tables[17].Rows.Count; i = i + 2)
                                //{
                                //    oWordDoc.Tables[17].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                //}
                            }
                            if (count == 2)
                            {
                                DentalTBL_number = 18;

                                //oWordDoc.Tables[18].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[18].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[18].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                //oWordDoc.Tables[18].Range.Font.Color = wdColor_font;
                                //for (int i = 3; i < oWordDoc.Tables[18].Rows.Count; i = i + 2)
                                //{
                                //    oWordDoc.Tables[18].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                //}
                            }
                            if (count == 3)
                            {
                                DentalTBL_number = 19;
                                //oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[19].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                //oWordDoc.Tables[19].Range.Font.Color = wdColor_font;
                                //for (int i = 3; i < oWordDoc.Tables[19].Rows.Count; i = i + 2)
                                //{
                                //    oWordDoc.Tables[19].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                //}
                            }


                            oWordDoc.Tables[DentalTBL_number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                            oWordDoc.Tables[DentalTBL_number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                            oWordDoc.Tables[DentalTBL_number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                            oWordDoc.Tables[DentalTBL_number].Range.Font.Color = wdColor_font;
                            for (int i = 3; i < oWordDoc.Tables[DentalTBL_number].Rows.Count; i = i + 2)
                            {
                                oWordDoc.Tables[DentalTBL_number].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                            }
                            #endregion
                            #region DentalTable

                            #region Dental InNetwork
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        //if (count == 1)
                                        //{
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 10: Orthodontia_Lifetime_Maximum = value; break;
                                            case 11: Orthodontia_Dependent_Children = value; break;
                                            case 88:
                                                oWordDoc.Tables[DentalTBL_number].Cell(10, 2).Range.Text = value + " up to a lifetime maximum of " + Orthodontia_Lifetime_Maximum;
                                                break;
                                        }

                                        if (key != 88 && key != 11 && key != 10)
                                        {
                                            oWordDoc.Tables[DentalTBL_number].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        //}
                                        //if (count == 2)
                                        //{
                                        //    value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //    switch (key)
                                        //    {
                                        //        case 10: Orthodontia_Lifetime_Maximum = value; break;
                                        //        case 11: Orthodontia_Dependent_Children = value; break;
                                        //        case 88:
                                        //            oWordDoc.Tables[DentalTBL_number].Cell(10, 2).Range.Text = value + " up to a lifetime maximum of " + Orthodontia_Lifetime_Maximum;
                                        //            break;
                                        //    }

                                        //    if (key != 88 && key != 11 && key != 10)
                                        //    {
                                        //        oWordDoc.Tables[DentalTBL_number].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        //    }
                                        //}
                                        //if (count == 3)
                                        //{
                                        //    value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //    switch (key)
                                        //    {
                                        //        case 10: Orthodontia_Lifetime_Maximum = value; break;
                                        //        case 11: Orthodontia_Dependent_Children = value; break;
                                        //        case 88:
                                        //            oWordDoc.Tables[DentalTBL_number].Cell(10, 2).Range.Text = value + " up to a lifetime maximum of " + Orthodontia_Lifetime_Maximum;
                                        //            break;
                                        //    }

                                        //    if (key != 88 && key != 11 && key != 10)
                                        //    {
                                        //        oWordDoc.Tables[DentalTBL_number].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        //    }
                                        //}
                                    }
                                }
                            }
                            #endregion

                            #region Dental OutOfNetwork
                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                                    {
                                        //if (count == 1)
                                        //{
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 88: Orthodontia_Lifetime_Maximum = value; break;
                                            case 10:
                                                oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = Orthodontia_Lifetime_Maximum + " up to a lifetime maximum of " + value;
                                                break;
                                        }

                                        if (key != 88 && key != 10)
                                        {
                                            oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        //}
                                        //if (count == 2)
                                        //{
                                        //    value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //    switch (key)
                                        //    {
                                        //        case 88: Orthodontia_Lifetime_Maximum = value; break;
                                        //        case 10:
                                        //            oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = Orthodontia_Lifetime_Maximum + " up to a lifetime maximum of " + value;
                                        //            break;
                                        //    }

                                        //    if (key != 88 && key != 10)
                                        //    {
                                        //        oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        //    }
                                        //}
                                        //if (count == 3)
                                        //{
                                        //    value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        //    switch (key)
                                        //    {
                                        //        case 88: Orthodontia_Lifetime_Maximum = value; break;
                                        //        case 10:
                                        //            oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = Orthodontia_Lifetime_Maximum + " up to a lifetime maximum of " + value;
                                        //            break;
                                        //    }

                                        //    if (key != 88 && key != 10)
                                        //    {
                                        //        oWordDoc.Tables[DentalTBL_number].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        //    }
                                        //}
                                    }
                                }
                            }
                            #endregion

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Carrier_" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("In Network – Orthodontia Services – Dependent Children " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Orthodontia_Dependent_Children.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Orthodontia_Dependent_Children.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Carrier Website " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Website.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Website);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental carrier phone number " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Phone_Number.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Phone_Number);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, DataTable CarrierSpecific, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(55, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(5, "194");      //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork.Add(71, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(72, "73");      //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitInNetwork.Add(73, "553");     //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitInNetwork.Add(74, "311");     //Covered Services – Lenses – Lenticular Lens
                HashtableVisionBenefitInNetwork.Add(7, "309");      //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitInNetwork.Add(99, "208");     //Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(9, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(16, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefitInNetwork.Add(15, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitInNetwork.Add(11, "122");     //General Plan Information – Benefit Frequency – Contacts


                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                Hashtable HashtableVisionBenefitOutNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitOutNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitOutNetwork.Add(55, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitOutNetwork.Add(5, "194");      //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitOutNetwork.Add(71, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitOutNetwork.Add(72, "73");      //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitOutNetwork.Add(73, "553");     //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitOutNetwork.Add(74, "311");     //Covered Services – Lenses – Lenticular Lens
                HashtableVisionBenefitOutNetwork.Add(7, "309");      //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitOutNetwork.Add(99, "208");     //Covered Services – Frames
                HashtableVisionBenefitOutNetwork.Add(9, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitOutNetwork.Add(16, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefitOutNetwork.Add(15, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitOutNetwork.Add(11, "122");     //General Plan Information – Benefit Frequency – Contacts

                ArrayList arrVisionBenefitOutNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitOutNetwork.Keys)
                {
                    arrVisionBenefitOutNetwork.Add(key);
                }

                arrVisionBenefitOutNetwork.Sort();
                arrVisionBenefitOutNetwork.Reverse();
                #endregion

                string Copay_Examination_Deductible = string.Empty;
                string CoveredServices_Lenses_Single_Vision = string.Empty;
                string CoveredServices_Lenses_Bifocal = string.Empty;
                string CoveredServices_Lenses_Trifocal = string.Empty;
                string CoveredServices_Lenses_Lenticular = string.Empty;
                string CoveredServices_Frames = string.Empty;
                string CoveredServices_ContactLenses_Elective = string.Empty;
                string CoveredServices_ContactLenses_MedicallyNecessary = string.Empty;

                string Website = string.Empty;
                string Phone_Number = string.Empty;
                int visionTbl_Number = 0;
                int iTotalFields = 0;
                int count = 1;

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (foundRows.Count() > 0)
                            {
                                Website = Convert.ToString(foundRows[0]["Website"].ToString());
                                Phone_Number = Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                            }
                            # region VisionBenefitTable

                            #region color
                            if (count == 1)
                            {
                                visionTbl_Number = 20;
                                //oWordDoc.Tables[visionTbl_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[visionTbl_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[visionTbl_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                //oWordDoc.Tables[visionTbl_Number].Range.Font.Color = wdColor_font;
                                //for (int i = 2; i < oWordDoc.Tables[visionTbl_Number].Rows.Count; i = i + 2)
                                //{
                                //    oWordDoc.Tables[visionTbl_Number].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                                //}
                            }
                            if (count == 2)
                            {
                                visionTbl_Number = 21;
                                //oWordDoc.Tables[14].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[14].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                //oWordDoc.Tables[14].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                //oWordDoc.Tables[14].Range.Font.Color = wdColor_font;
                                //for (int i = 2; i < oWordDoc.Tables[14].Rows.Count; i = i + 2)
                                //{
                                //    oWordDoc.Tables[14].Rows[i].Range.Shading.BackgroundPatternColor =comFunObj.cell_color(selectedcolor);
                                //}
                            }
                            oWordDoc.Tables[visionTbl_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                            oWordDoc.Tables[visionTbl_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                            oWordDoc.Tables[visionTbl_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                            oWordDoc.Tables[visionTbl_Number].Range.Font.Color = wdColor_font;
                            for (int i = 2; i < oWordDoc.Tables[visionTbl_Number].Rows.Count; i = i + 2)
                            {
                                oWordDoc.Tables[visionTbl_Number].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);
                            }
                            #endregion

                            if (count == 2)
                            {
                                Copay_Examination_Deductible = "";
                                CoveredServices_Lenses_Single_Vision = "";
                                CoveredServices_Lenses_Bifocal = "";
                                CoveredServices_Lenses_Trifocal = "";
                                CoveredServices_Lenses_Lenticular = "";
                                CoveredServices_Frames = "";
                                CoveredServices_ContactLenses_Elective = "";
                                CoveredServices_ContactLenses_MedicallyNecessary = "";
                            }

                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[visionTbl_Number].Cell(key, 2).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in arrVisionBenefitOutNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[visionTbl_Number].Cell(key, 3).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Vision Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Carrier Name_" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Carrier Website " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Website.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Website);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision carrier phone number " + count))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (!string.IsNullOrEmpty(Phone_Number.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Phone_Number);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlLTDNoOfPlan, DropDownList ddlClient, DropDownList ddlSTDPlanName, DropDownList ddlLifeADDNoOfPlan, DropDownList ddlSTDNoOfPlan, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(2, "505");     //STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");      //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment
                HashtableSTD.Add(6, "449");     //Benefits[Pre-Existing Condition Limitation]
                #endregion

                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string PreExisting_Condition_Limitations = string.Empty;

                string EliminationPeriod_Accident2 = string.Empty;
                string EliminationPeriod_Sickness2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Weekly_Benefit_Maximum2 = string.Empty;
                string Maximum_Period_of_Payment2 = string.Empty;
                string PreExisting_Condition_Limitations2 = string.Empty;
                string ProductName = "";
                int STD_TBL_Number = 23;
                string value = "";
                bool isSTDPlan_Selected = false;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        isSTDPlan_Selected = true;
                    }
                }

                oWordDoc.Tables[STD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[STD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[STD_TBL_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[STD_TBL_Number].Range.Font.Color = wdColor_font;

                //if (isSTDPlan_Selected == false)
                //{
                //    if (ddlLifeADDNoOfPlan.SelectedIndex > 0 || ddlSTDNoOfPlan.SelectedIndex > 0 || ddlLTDNoOfPlan.SelectedIndex > 0)
                //    {
                //        foreach (Word.Field myMergeField in oWordDoc.Fields)
                //        {
                //            iTotalFields++;

                //            Word.Range rngFieldCode = myMergeField.Code;

                //            String fieldText = rngFieldCode.Text;

                //            if (fieldText.StartsWith(" MERGEFIELD"))
                //            {
                //                Int32 endMerge = fieldText.IndexOf("\\");
                //                if (endMerge == -1)
                //                {
                //                    endMerge = fieldText.Length;
                //                }

                //                Int32 fieldNameLength = fieldText.Length - endMerge;

                //                String fieldName = fieldText.Substring(11, endMerge - 11);

                //                fieldName = fieldName.Trim();

                //                if (fieldName.Contains("Life_STD_LTD_Plan"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;

                //                    oWordApp.Selection.TypeText(" ");
                //                }

                //                if (fieldName.Contains("STD General Information – Elimination Period – Accident"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //                if (fieldName.Contains("STD General Information – Elimination Period – Sickness"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }

                //                if (fieldName.Contains("STD General Information – Maximum Period of Payment"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //            }
                //        }
                //    }
                //}
                //else
                //{
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 1:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Accident = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Accident = value.Trim();
                                                    }
                                                    break;
                                                case 2:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim();
                                                    }
                                                    break;
                                                case 3: Benefit_Percentage = value.Trim(); break;
                                                case 4: Weekly_Benefit_Maximum = value.Trim(); break;
                                                case 5: Maximum_Period_of_Payment = (dr["value"].ToString() + " " + dr["UOM"].ToString()).Trim(); break;
                                                case 6: PreExisting_Condition_Limitations = value.Trim(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 1:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Accident2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Accident2 = value.Trim();
                                                    }
                                                    break;
                                                case 2:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Sickness2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Sickness2 = value.Trim();
                                                    }
                                                    break;
                                                case 3: Benefit_Percentage2 = value.Trim(); break;
                                                case 4: Weekly_Benefit_Maximum2 = value.Trim(); break;
                                                case 5: Maximum_Period_of_Payment2 = (dr["value"].ToString() + " " + dr["UOM"].ToString()).Trim(); break;
                                                case 6: PreExisting_Condition_Limitations2 = value.Trim(); break;
                                            }
                                        }

                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    if (count == 1)
                                    {
                                        #region First_STD Plan
                                        fieldName = fieldName.Trim();
                                        if (fieldName.Contains("STD_Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[23].Cell(5, 1).Range.Text = oWordDoc.Tables[23].Cell(5, 1).Range.Text.Replace("STD_Plan1", " ");
                                            oWordDoc.Tables[23].Cell(11, 1).Range.Text = oWordDoc.Tables[23].Cell(11, 1).Range.Text.Replace("Delete_STD_LTD1", " ");
                                            oWordDoc.Tables[23].Cell(12, 1).Range.Text = oWordDoc.Tables[23].Cell(12, 1).Range.Text.Replace("Delete_STD_LTD2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("If STD is selected, include this sentence"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Accident1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Accident))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Accident);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Sickness1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Sickness))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Sickness);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("STD_General Plan Information – Benefit Percentage1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Weekly Benefit Maximum1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Weekly_Benefit_Maximum))
                                            {
                                                oWordApp.Selection.TypeText(Weekly_Benefit_Maximum);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Maximum Period of Payment1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                            {
                                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General_Plan_Information – Pre-Existing Condition Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                    if (count == 2)
                                    {
                                        #region Second STD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();

                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("STD_Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[23].Cell(6, 1).Range.Text = oWordDoc.Tables[23].Cell(6, 1).Range.Text.Replace("STD_Plan2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Accident2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Accident2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Accident2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Sickness2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Sickness2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Sickness2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("STD_General Plan Information – Benefit Percentage2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Weekly Benefit Maximum2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Weekly_Benefit_Maximum2))
                                            {
                                                oWordApp.Selection.TypeText(Weekly_Benefit_Maximum2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Maximum Period of Payment2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment2))
                                            {
                                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General_Plan_Information – Pre-Existing Condition Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations2))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
                // }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteLTDSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlLTDNoOfPlan, DropDownList ddlClient, DropDownList ddlLifeADDNoOfPlan, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableLTD
                HashtableLTD.Add(6, "71");  //General Plan Information – Benefit Percentage
                HashtableLTD.Add(5, "374"); //General Plan Information – Weekly Benefit Maximum
                HashtableLTD.Add(4, "181"); //LTD General Information – Elimination Period
                // HashtableLTD.Add(3, "351"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(7, "374");     // Benefits [Maximum Monthly Benefit]
                HashtableLTD.Add(3, "141"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(2, "449"); //General Plan Information – Pre-Existing Condition Limitations
                #endregion

                string EliminationPeriod = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit = string.Empty;
                string PreExisting_Condition_Limitations = string.Empty;

                string EliminationPeriod2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Monthly_Benefit2 = string.Empty;
                string PreExisting_Condition_Limitations2 = string.Empty;

                string ProductName = "";
                int LTD_TBL_Number = 23;
                string value = "";
                bool isLTDPlan_Selected = false;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        isLTDPlan_Selected = true;
                    }
                }

                oWordDoc.Tables[LTD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[LTD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[LTD_TBL_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[LTD_TBL_Number].Range.Font.Color = wdColor_font;

                //if (isSTDPlan_Selected == false)
                //{
                //    if (ddlLifeADDNoOfPlan.SelectedIndex > 0 || ddlSTDNoOfPlan.SelectedIndex > 0 || ddlLTDNoOfPlan.SelectedIndex > 0)
                //    {
                //        foreach (Word.Field myMergeField in oWordDoc.Fields)
                //        {
                //            iTotalFields++;

                //            Word.Range rngFieldCode = myMergeField.Code;

                //            String fieldText = rngFieldCode.Text;

                //            if (fieldText.StartsWith(" MERGEFIELD"))
                //            {
                //                Int32 endMerge = fieldText.IndexOf("\\");
                //                if (endMerge == -1)
                //                {
                //                    endMerge = fieldText.Length;
                //                }

                //                Int32 fieldNameLength = fieldText.Length - endMerge;

                //                String fieldName = fieldText.Substring(11, endMerge - 11);

                //                fieldName = fieldName.Trim();

                //                if (fieldName.Contains("Life_STD_LTD_Plan"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;

                //                    oWordApp.Selection.TypeText(" ");
                //                }

                //                if (fieldName.Contains("STD General Information – Elimination Period – Accident"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //                if (fieldName.Contains("STD General Information – Elimination Period – Sickness"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }

                //                if (fieldName.Contains("STD General Information – Maximum Period of Payment"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //            }
                //        }
                //    }
                //}
                //else
                //{
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 4:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod = value.Trim();
                                                    }
                                                    break;

                                                case 6: Benefit_Percentage = value.Trim(); break;
                                                case 7: Monthly_Benefit = value.Trim(); break;
                                                case 2: PreExisting_Condition_Limitations = value.Trim(); break;

                                            }
                                        }
                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 4:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod2 = value.Trim();
                                                    }
                                                    break;

                                                case 6: Benefit_Percentage2 = value.Trim(); break;
                                                case 7: Monthly_Benefit2 = value.Trim(); break;
                                                case 2: PreExisting_Condition_Limitations2 = value.Trim(); break;
                                            }
                                        }

                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    if (count == 1)
                                    {
                                        #region First LTD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("LTD_Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[23].Cell(7, 1).Range.Text = oWordDoc.Tables[23].Cell(7, 1).Range.Text.Replace("Delete_LTD1", " ");
                                            oWordDoc.Tables[23].Cell(11, 1).Range.Text = oWordDoc.Tables[23].Cell(11, 1).Range.Text.Replace("Delete_STD_LTD1", " ");
                                            oWordDoc.Tables[23].Cell(12, 1).Range.Text = oWordDoc.Tables[23].Cell(12, 1).Range.Text.Replace("Delete_STD_LTD2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("If LTD is selected, include this sentence"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                        }
                                        //LTD_General Plan Information – Elimination Period1
                                        //LTD_General Plan Information – Benefit Percentage1
                                        //LTD_General Plan Information – Monthly Benefit Maximum1
                                        if (fieldName.Contains("LTD_General Plan Information – Elimination Period1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("LTD_General Plan Information – Benefit Percentage1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General Plan Information – Monthly Benefit Maximum1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Monthly_Benefit))
                                            {
                                                oWordApp.Selection.TypeText(Monthly_Benefit);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General_Plan_Information – Pre-Existing Conditions Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                    if (count == 2)
                                    {
                                        #region Second LTD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();

                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("LTD_Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[23].Cell(8, 1).Range.Text = oWordDoc.Tables[23].Cell(8, 1).Range.Text.Replace("Delete_LTD2", " ");
                                            continue;
                                        }
                                        //LTD_General Plan Information – Elimination Period1
                                        //LTD_General Plan Information – Benefit Percentage1
                                        //LTD_General Plan Information – Monthly Benefit Maximum1
                                        if (fieldName.Contains("LTD_General Plan Information – Elimination Period2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("LTD_General Plan Information – Benefit Percentage2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General Plan Information – Monthly Benefit Maximum2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Monthly_Benefit2))
                                            {
                                                oWordApp.Selection.TypeText(Monthly_Benefit2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General_Plan_Information – Pre-Existing Conditions Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations2))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
                // }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLifeADDBenifitToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DropDownList ddlLifeADDNoOfPlan, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, string selectedcolor = "", ArrayList GroupTermLifeBenefitColumnIdList = null, ArrayList ADDBenefitColumnIdList = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                string Overall_Max_Employee = "";
                string Overall_Max_Employee2 = "";
                int count = 1;
                string value = string.Empty;
                int life_ADD_TBL_Number = 23;
                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                double benefitamount = 0;
                string age = "";
                string age_to = "";
                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(7, "517");//Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(8, "519");//Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(9, "518");//Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(10, "467"); // Reduction of Benefits
                HashtableGroupLifeADDBenifit.Add(11, "102");//Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(13, "103");//Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(14, "2");//age
                HashtableGroupLifeADDBenifit.Add(15, "3");//age
                HashtableGroupLifeADDBenifit.Add(16, "4");//age
                HashtableGroupLifeADDBenifit.Add(17, "5");//age

                #endregion
                int trcnt = oWordDoc.Tables[life_ADD_TBL_Number].Rows.Count;

                bool isLifeAdd_Is_Selected = false;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        isLifeAdd_Is_Selected = true;
                    }
                }

                oWordDoc.Tables[life_ADD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[life_ADD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[life_ADD_TBL_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[life_ADD_TBL_Number].Range.Font.Color = wdColor_font;
                //if (isLifeAdd_Is_Selected == false)
                //{
                //    if (ddlLifeADDNoOfPlan.SelectedIndex > 0 || ddlSTDNoOfPlan.SelectedIndex > 0 || ddlLTDNoOfPlan.SelectedIndex > 0)
                //    {
                //        foreach (Word.Field myMergeField in oWordDoc.Fields)
                //        {
                //            iTotalFields++;

                //            Word.Range rngFieldCode = myMergeField.Code;

                //            String fieldText = rngFieldCode.Text;

                //            if (fieldText.StartsWith(" MERGEFIELD"))
                //            {
                //                Int32 endMerge = fieldText.IndexOf("\\");
                //                if (endMerge == -1)
                //                {
                //                    endMerge = fieldText.Length;
                //                }

                //                Int32 fieldNameLength = fieldText.Length - endMerge;

                //                String fieldName = fieldText.Substring(11, endMerge - 11);

                //                fieldName = fieldName.Trim();

                //                if (fieldName.Contains("Life_STD_LTD_Plan"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //                if (fieldName.Contains("age_from"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //                if (fieldName.Contains("age_to"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //                if (fieldName.Contains("Life ADD General Plan Information – Overall Maximum – Employee"))
                //                {
                //                    myMergeField.Select();
                //                    oWordApp.Selection.TypeText(" ");
                //                }
                //            }
                //        }
                //    }
                //}
                //else
                //{
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            /* The following line changed beacause we merging the first cell of table to Display the carrier name in correct format*/
                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                    }
                                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                    }
                                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                    }



                                    //if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    //{
                                    if (count == 1)
                                    {
                                        if (key == 4)
                                        {
                                            Overall_Max_Employee = value;
                                        }
                                    }
                                    if (count == 2)
                                    {
                                        if (key == 4)
                                        {
                                            Overall_Max_Employee2 = value;
                                        }
                                    }
                                    //value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    int ch = int.Parse(dr["attributeID"].ToString());
                                    if (count == 1)
                                    {
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = value; } break;       // 65-69
                                            case 3: if (value.Trim() != string.Empty) { age = value; } break;       // 70-74
                                            case 4: if (value.Trim() != string.Empty) { age_to = value; } break;    // 75-79
                                            case 5: if (value.Trim() != string.Empty) { age = value; } break;       // 80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                    if (count == 2)
                                    {
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = value; } break;       // 65-69
                                            case 3: if (value.Trim() != string.Empty) { age = value; } break;       // 70-74
                                            case 4: if (value.Trim() != string.Empty) { age_to = value; } break;    // 75-79
                                            case 5: if (value.Trim() != string.Empty) { age = value; } break;       // 80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                    //}
                                }
                            }
                            #endregion
                            int rcnt = oWordDoc.Tables[life_ADD_TBL_Number].Rows.Count;
                            #region merge fields

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Life_STD_LTD_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(" ");
                                    }

                                    if (count == 1)
                                    {
                                        #region first  plan


                                        if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() || PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                        {
                                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["SummaryName"].ToString()))
                                            {
                                                if (fieldName.Contains("Basic_Life_Benefit Summary Description1"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                                    oWordDoc.Tables[life_ADD_TBL_Number].Cell(2, 1).Range.Text = oWordDoc.Tables[life_ADD_TBL_Number].Cell(2, 1).Range.Text.Replace("Delete_Life1", " ");
                                                    oWordDoc.Tables[life_ADD_TBL_Number].Cell(4, 1).Range.Text = oWordDoc.Tables[life_ADD_TBL_Number].Cell(4, 1).Range.Text.Replace("ADD_Plan", " ");
                                                    continue;
                                                }
                                                if (fieldName.Contains("age_from1"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(age.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(age.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                                if (fieldName.Contains("age_to1"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(age_to.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(age_to.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }

                                                if (fieldName.Contains("Life ADD General Plan Information – Overall Maximum – Employee"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(Overall_Max_Employee.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(Overall_Max_Employee.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                            }


                                        }

                                        if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                        {
                                            if (fieldName.Contains("ADD_Benefit Summary Description1"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                                continue;
                                            }
                                        }

                                        #endregion
                                    }
                                    if (count == 2)
                                    {
                                        #region Second  plan

                                        if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() || PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                        {
                                            if (!string.IsNullOrEmpty(PlanTable.Rows[k]["SummaryName"].ToString()))
                                            {
                                                if (fieldName.Contains("Basic Life Benefit Summary Description2"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                                    oWordDoc.Tables[life_ADD_TBL_Number].Cell(3, 1).Range.Text = oWordDoc.Tables[life_ADD_TBL_Number].Cell(3, 1).Range.Text.Replace("Delete_Life2", " ");
                                                    continue;
                                                }

                                                if (fieldName.Contains("age_from2"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(age.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(age.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                                if (fieldName.Contains("age_to2"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(age_to.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(age_to.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }

                                                if (fieldName.Contains("Life_ADD_General_Plan Information – Overall Maximum – Employee2"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    if (!string.IsNullOrEmpty(Overall_Max_Employee.Trim()))
                                                    {
                                                        oWordApp.Selection.TypeText(Overall_Max_Employee.Trim());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                            }


                                        }


                                        #endregion
                                    }
                                }
                            }
                        }
                            #endregion
                        count++;
                    }


                }




            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Table of contents information (Header and page numbers) based upon the plans selected
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ddlAnnualLegalNotice">Dropdown list for AnnualLegalNotice</param>
        /// <param name="ddlChipNotice">Dropdown list for ChipNotice</param>
        /// <param name="ddlBRC">Dropdown list for BRC</param>

        #region TOC
        ////public void WriteTableOfContentInformationToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlAnnualLegalNotice, DropDownList ddlChipNotice, DropDownList ddlBRC, string color, DataTable PlanInfoTable, bool isAllPlansSelected)
        public void WriteTableOfContentInformationToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlAnnualLegalNotice, DropDownList ddlChipNotice, List<BRCData> BRCDataList, string ddlBRCSelectedValue, string color, DataTable PlanInfoTable, bool isAllPlansSelected)
        {
            try
            {
                string plantype = "";

                // Update Table of Content
                int contentPageNo = 5;
                int contentRowCnt = 5;

                int medicalCnt = 0;
                int dentalCnt = 0;
                int visionCnt = 0;
                int volLifeCount = 0;

                bool isGetMoreValues = false;
                bool isMedical = false;
                bool isDental = false;
                bool isVision = false;
                bool isFSA = false;
                bool isHSA = false;
                bool isHRA = false;
                bool isLife_STD_LTD = false;
                bool isSummary = false;
                bool isValueAdded = false;
                bool isPatientAdvocacy = false;
                bool isTelemedicine = false;
                bool isWorksiteProducts = false;
                bool isAddition_Benefit_Taken = false;
                bool isContact_Info_Taken = false;
                bool isBRC = false;
                bool isRequiredNotification = false;
                bool isContributionTableOnNextPage = false;

                // Create the arraylist for the headers other than default headers in the table
                ArrayList arrTOC = new ArrayList();
                arrTOC.Add("Get More Value From Your Plans");
                arrTOC.Add("Medical Benefits");
                arrTOC.Add("Dental Benefits");
                arrTOC.Add("Vision Benefits");
                arrTOC.Add("Health and Dependent Care Spending Accounts");
                arrTOC.Add("Health Savings Account (HSA)"); // New
                arrTOC.Add("Health Reimbursement Account (HRA)"); // New
                arrTOC.Add("Income Protection Benefit");
                arrTOC.Add("Summary of Coverage For Voluntary Life Insurance");
                arrTOC.Add("Value-added Programs and Services");
                arrTOC.Add("Patient Advocacy Program");  // New
                arrTOC.Add("Telemidicine"); // New
                arrTOC.Add("Worksite Products"); // New
                arrTOC.Add("Additional Benefits for Eligible Employees");
                arrTOC.Add("Contact Numbers & Website Links");
                arrTOC.Add("The Benefit Resource Center");
                arrTOC.Add("Required Notifications");

                // Check for the number of medical, dental and vision plans so that we can adjust the page numbers accordingly
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    if (plantype == cv.MedicalLOC)
                    {
                        medicalCnt++;
                    }
                    if (plantype == cv.DentalLOC)
                    {
                        dentalCnt++;
                    }
                    if (plantype == cv.VisionLOC)
                    {
                        visionCnt++;
                    }
                    if (plantype == cv.VoluntaryLifeADDLOC)
                    {
                        volLifeCount++;
                    }
                }

                // If the contribution table goes to next page 
                if (oWordDoc.Tables[4].Rows.Count > 22)
                {
                    contentPageNo = 6;
                    isContributionTableOnNextPage = true;
                }

                int characterLength = 0;
                int lengthDifference = 0;
                string tmpVar = string.Empty;

                DataTable dtPlanType = new DataTable();
                dtPlanType = PlanTable.DefaultView.ToTable(true, "PlanType");

                for (int j = 0; j < arrTOC.Count; j++)
                {
                    for (int i = 0; i < dtPlanType.Rows.Count; i++)
                    {
                        plantype = dtPlanType.Rows[i]["PlanType"].ToString();

                        // For Get More Value From Your Plans
                        #region For Get More Value From Your Plans page Number
                        if (j == 0)
                        {
                            if (isGetMoreValues == false)
                            {
                                oWordDoc.Tables[3].Rows.Add();

                                // Calculate the character length for selected heading
                                characterLength = arrTOC[0].ToString().Length;
                                lengthDifference = 69 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 69 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 69 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                }

                                tmpVar = arrTOC[0].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isGetMoreValues = true;
                                break;
                            }
                            continue;
                        }
                        #endregion

                        // For Medical
                        #region For Medical page Number
                        if (j == 1)
                        {
                            if (plantype == cv.MedicalLOC)
                            {
                                if (isMedical == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();

                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[1].ToString().Length;
                                    lengthDifference = 81 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 81 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 81 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[1].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;

                                    // Based on the number of medical plans selected change the page number
                                    if (medicalCnt == 1)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 8;
                                        else
                                            contentPageNo = 7;
                                    }
                                    else if (medicalCnt == 2)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 9;
                                        else
                                            contentPageNo = 8;
                                    }
                                    else if (medicalCnt == 3)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 10;
                                        else
                                            contentPageNo = 9;
                                    }
                                    else if (medicalCnt == 4)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 11;
                                        else
                                            contentPageNo = 10;
                                    }
                                    else if (medicalCnt == 5)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 12;
                                        else
                                            contentPageNo = 11;
                                    }
                                    else if (medicalCnt == 6)
                                    {
                                        if (isContributionTableOnNextPage)
                                            contentPageNo = 13;
                                        else
                                            contentPageNo = 12;
                                    }
                                    isMedical = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For Dental
                        #region For Detal page Number
                        if (j == 2)
                        {
                            if (plantype == cv.DentalLOC)
                            {
                                if (isDental == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();

                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[2].ToString().Length;
                                    lengthDifference = 82 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 82 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 82 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[2].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;

                                    if (dentalCnt == 3)
                                    {
                                        contentPageNo = contentPageNo + 6;
                                    }
                                    else if (dentalCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 4;
                                    }
                                    else
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    isDental = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For Vision
                        #region For Vision Page Number
                        if (j == 3)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.VisionLOC)
                            {
                                if (isVision == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[3].ToString().Length;
                                    lengthDifference = 83 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 83 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 83 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[3].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    if (visionCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    isVision = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For FSA
                        #region For FSA Page Number
                        if (j == 4)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.FSAPlanType_CommonCriteria)
                            {
                                if (isFSA == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[4].ToString().Length;
                                    lengthDifference = 58 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 58 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 58 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[4].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isFSA = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For HSA
                        #region For HSA Page Number
                        if (j == 5)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.HSAPlanType_CommonCriteria)
                            {
                                if (isHSA == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[5].ToString().Length;
                                    lengthDifference = 72 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[5].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isHSA = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For HRA
                        #region For HRA Page Number
                        if (j == 6)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.HRAPlanType_CommonCriteria)
                            {
                                if (isHRA == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[6].ToString().Length;
                                    lengthDifference = 64 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 64 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 64 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[6].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isHRA = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For if Life ADD / LTD / STD is selected (Income Protectiion Plan)
                        #region For Income Protection Benefit Page Number
                        if (j == 7)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isLife_STD_LTD == false)
                            {
                                if (plantype == cv.LifeADDLOC || plantype == cv.STDPlanType_CommonCriteria || plantype == cv.LTDPlanType_CommonCriteria)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[7].ToString().Length;
                                    lengthDifference = 74 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 74 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 74 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[7].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;

                                    if (isAllPlansSelected == true)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    isLife_STD_LTD = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For Voluntary Life
                        #region For Voluntary Life Page Number
                        if (j == 8)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.VoluntaryLifeADDLOC)
                            {
                                if (isSummary == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[8].ToString().Length;
                                    lengthDifference = 57 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 57 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 57 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[8].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    if (volLifeCount == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    isSummary = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For EAP
                        #region For EAP Page Number
                        if (j == 9)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.EAPPlanType_CommonCriteria)
                            {
                                if (isValueAdded == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[9].ToString().Length;
                                    lengthDifference = 67 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 67 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 67 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[9].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isValueAdded = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // PATIENT ADVOCACY PROGRAM
                        #region For Patient Advocacy Program Page Number
                        if (j == 10)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (PlanInfoTable != null)
                            {
                                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                                {
                                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                                    {
                                        if (isPatientAdvocacy == false)
                                        {
                                            oWordDoc.Tables[3].Rows.Add();
                                            // Calculate the character length for selected heading
                                            characterLength = arrTOC[10].ToString().Length;
                                            lengthDifference = 73 - characterLength;

                                            if (contentPageNo.ToString().Length > 1)
                                            {
                                                //lengthDifference = 73 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                            }
                                            else
                                            {
                                                //lengthDifference = 73 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                            }

                                            tmpVar = arrTOC[10].ToString();

                                            // Append "." at the end of the header and after that the page number
                                            for (int len = 0; len < lengthDifference; len++)
                                            {
                                                tmpVar = tmpVar + ".";
                                            }

                                            oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                            contentRowCnt++;
                                            contentPageNo++;
                                            isPatientAdvocacy = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            continue;
                        }
                        #endregion

                        // TELEMEDICINE
                        #region For Telemedicine Page Number
                        if (j == 11)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (PlanInfoTable != null)
                            {
                                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                                {
                                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                                    {
                                        if (isTelemedicine == false)
                                        {
                                            oWordDoc.Tables[3].Rows.Add();
                                            // Calculate the character length for selected heading
                                            characterLength = arrTOC[11].ToString().Length;
                                            lengthDifference = 83 - characterLength;

                                            if (contentPageNo.ToString().Length > 1)
                                            {
                                                //lengthDifference = 83 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                            }
                                            else
                                            {
                                                //lengthDifference = 83 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                            }

                                            tmpVar = arrTOC[11].ToString();

                                            // Append "." at the end of the header and after that the page number
                                            for (int len = 0; len < lengthDifference; len++)
                                            {
                                                tmpVar = tmpVar + ".";
                                            }

                                            oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                            contentRowCnt++;
                                            contentPageNo++;
                                            isTelemedicine = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            continue;
                        }
                        #endregion

                        // WORKSITE PRODUCTS
                        #region For Worksite Products Page Number
                        if (j == 12)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (PlanInfoTable != null)
                            {
                                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                                {
                                    if ((Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                                        || (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                                        || (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness))
                                    {
                                        if (isWorksiteProducts == false)
                                        {
                                            oWordDoc.Tables[3].Rows.Add();
                                            // Calculate the character length for selected heading
                                            characterLength = arrTOC[12].ToString().Length;
                                            lengthDifference = 79 - characterLength;

                                            if (contentPageNo.ToString().Length > 1)
                                            {
                                                //lengthDifference = 79 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                            }
                                            else
                                            {
                                                //lengthDifference = 79 - characterLength;
                                                oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                            }

                                            tmpVar = arrTOC[12].ToString();

                                            // Append "." at the end of the header and after that the page number
                                            for (int len = 0; len < lengthDifference; len++)
                                            {
                                                tmpVar = tmpVar + ".";
                                            }

                                            oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                            contentRowCnt++;
                                            contentPageNo++;
                                            isWorksiteProducts = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For Additional Benefits for Eligible Employees
                        #region For Additionla Benefits Page Number
                        if (j == 13)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isAddition_Benefit_Taken == false)
                            {
                                oWordDoc.Tables[3].Rows.Add();
                                // Calculate the character length for selected heading
                                characterLength = arrTOC[13].ToString().Length;
                                lengthDifference = 66 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 66 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 66 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                }
                                tmpVar = arrTOC[13].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isAddition_Benefit_Taken = true;
                                break;
                            }
                            continue;
                        }
                        #endregion

                        // For Contact Information
                        #region For Contact Information Page Number
                        if (j == 14)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isContact_Info_Taken == false)
                            {
                                oWordDoc.Tables[3].Rows.Add();
                                // Calculate the character length for selected heading
                                characterLength = arrTOC[14].ToString().Length;
                                lengthDifference = 68 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 68 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 68 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                }
                                tmpVar = arrTOC[14].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isContact_Info_Taken = true;
                                break;
                            }
                            continue;
                        }
                        #endregion

                        // For BRC
                        #region For BRC Page Number
                        if (j == 15)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            ///if (ddlBRC.SelectedIndex > 1)
                            if (ddlBRCSelectedValue == "YES" && BRCDataList.Count > 0)
                            {
                                if (isBRC == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[15].ToString().Length;
                                    lengthDifference = 72 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[15].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isBRC = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion

                        // For Notification (Annual Legal Notices)
                        #region For Notification Page Number
                        if (j == 16)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                            {
                                if (isRequiredNotification == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[16].ToString().Length;
                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        lengthDifference = 77 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        lengthDifference = 77 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[16].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;

                                    if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex > 0)
                                    {
                                        contentPageNo++;
                                    }
                                    else if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex == 0)
                                    {
                                        contentPageNo++;
                                    }

                                    if (ddlChipNotice.SelectedIndex > 0)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }

                                    isRequiredNotification = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion



        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="selectedColor">Optional string selectedColor parameter is used to apply selected color.</param>
        /// <param name="BenefitDS">Optional Dataset BenefitDS.</param>
        public void WriteMonthlyPremiumSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, string selectedColor = "", DataSet BenefitDS = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int DentalCount = 0;
                int VisionCount = 0;

                DataTable PremiumTableWriteMedical = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteMedical);

                DataTable PremiumTableWriteDental = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteDental);

                DataTable PremiumTableWriteVision = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteVision);

                int premTableMedical1 = 4;
                string Summaryname = "Value Summary";
                ArrayList arrContributionID = new ArrayList();
                ArrayList arrContributionID_Vision = new ArrayList();
                ArrayList rowcount = new ArrayList();
                int medicalColumnNum = 1;
                int dentalColumnNum = 1;
                int visionColumnNum = 1;
                string strPlan_Contri1 = "";
                string strPlan_Contri2 = "";
                string strPlan_Header = "";
                int MedicalTableRowCounter = 2;
                int DentalTableRowCounter = 2;
                int VisionTableRowCounter = 2;
                int contributionId_1 = 0;
                int contributionId_2 = 0;
                int RowCounter = 1;
                string FrequencyMEdical1 = string.Empty;
                DataTable PremiumTable = new DataTable();



                oWordDoc.Tables[premTableMedical1].Range.Font.Color = wdColor_font;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {


                    PremiumTable.Clear();
                    PremiumTable = comFunObj.CreateContributionPremiumTable(PlanTable, ContributionDS, index);

                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId"].ToString()))
                    {
                        contributionId_1 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId"].ToString());
                    }
                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId_2"].ToString()))
                    {
                        contributionId_2 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId_2"].ToString());
                    }

                    DataTable dt1 = new DataTable();

                    PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt1 = PremiumTable.DefaultView.ToTable(true);

                    for (int k = 0; k < dt1.Rows.Count; k++)
                    {
                        if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                        {
                            dt1.Rows[k].Delete();
                            k = k - 1;
                        }
                    }

                    PremiumTable = dt1;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        //strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        //if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        //{
                        //    strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        //}
                        strPlan_Header = Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim());

                        strPlan_Contri1 = Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        }

                        if (index == 0)
                        {
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical1 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            rowcount.Add(2);
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (index == 1)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (index == 2)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (index == 3)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 4, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (index == 4)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 5, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (index == 5)
                        {
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 6, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }

                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        strPlan_Header = Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim());

                        strPlan_Contri1 = Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        }

                        if (DentalCount == 0)
                        {
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (DentalCount == 1)
                        {
                            PremiumTableWriteDental.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (DentalCount == 2)
                        {
                            PremiumTableWriteDental.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref dentalColumnNum, PremiumTableWriteDental, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        //strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[index]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[index]["description"]).Trim()).Trim() + " - " + Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString()); ;
                        //if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        strPlan_Header = Convert.ToString(PlanTable.Rows[index]["ProductTypeDescription"]).Trim() + " " + (Convert.ToString(PlanTable.Rows[index]["SummaryName"]).Trim());

                        strPlan_Contri1 = Convert.ToString(PlanTable.Rows[index]["ContributionName"].ToString());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString());
                        }

                        if (VisionCount == 0)
                        {
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteVision);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref visionColumnNum, PremiumTableWriteVision, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }
                        if (VisionCount == 1)
                        {
                            PremiumTableWriteVision.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteVision);
                            comFunObj.WriteContributionValues_Approach_2(oWordDoc, oWordApp, premTableMedical1, ref visionColumnNum, PremiumTableWriteVision, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, Summaryname, strPlan_Header);
                            rowcount.Add(RowCounter + 1);
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                // Approach 2
                #region Approach 2

                if (oWordDoc.Tables[premTableMedical1].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[premTableMedical1].Rows.Last.Delete();
                }
                if (oWordDoc.Tables[premTableMedical1].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[premTableMedical1].Rows.Last.Delete();
                }
                //oWordDoc.Tables[premTableMedical1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].Range.Font.Color = wdColor_font;




                //oWordDoc.Tables[premTableMedical1].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                //// oWordDoc.Tables[premTableMedical1].Rows.Borders[WdBorderType.wdBorderBottom].LineStyle = WdLineStyle.wdLineStyleSingle;
                //oWordDoc.Tables[premTableMedical1].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                //oWordDoc.Tables[premTableMedical1].PreferredWidth = oWordApp.InchesToPoints(7.65f);

                #endregion


                for (int rowNum = 2; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {

                    if (string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(rowNum, 1).Range.Text.ToString()) || oWordDoc.Tables[4].Cell(rowNum, 1).Range.Text == "\r\a")
                    {
                        oWordDoc.Tables[4].Rows[rowNum].Delete();
                        rowNum = rowNum - 1;
                    }
                }



                #region Code for Merging the rows
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                    {
                        // Check the remainder for the rownumber to merge
                        foreach (int rn in rowcount)
                        {
                            if (rowNum == rn)
                            {
                                oWordDoc.Tables[premTableMedical1].Rows[rowNum].Cells.Merge();
                                oWordDoc.Tables[premTableMedical1].Rows[rowNum].Cells[1].Range.Text = oWordDoc.Tables[premTableMedical1].Rows[rowNum].Cells[1].Range.Text.Replace("\r", " ");
                                oWordDoc.Tables[premTableMedical1].Rows[rowNum].Cells[1].Shading.BackgroundPatternColor = comFunObj.cell_color(selectedColor);
                                oWordDoc.Tables[premTableMedical1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                                oWordDoc.Tables[premTableMedical1].Rows[rowNum].Alignment = WdRowAlignment.wdAlignRowLeft;
                            }
                        }
                        break;
                    }
                }
                #endregion



                //   oWordDoc.Tables[premTableMedical1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);

                oWordDoc.Tables[premTableMedical1].Rows.First.Borders.Enable = 1;
                oWordDoc.Tables[premTableMedical1].Rows.First.Borders[Word.WdBorderType.wdBorderLeft].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.First.Borders[Word.WdBorderType.wdBorderRight].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.First.Borders[Word.WdBorderType.wdBorderVertical].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.First.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows.First.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders.Enable = 1;
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders[Word.WdBorderType.wdBorderTop].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders[Word.WdBorderType.wdBorderLeft].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders[Word.WdBorderType.wdBorderRight].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders[Word.WdBorderType.wdBorderVertical].Visible = false;
                oWordDoc.Tables[premTableMedical1].Rows.Last.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[premTableMedical1].PreferredWidth = oWordApp.InchesToPoints(7.65f);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteFSASectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DataTable CarrierSpecific, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();
                DataRow[] foundRows = null;
                DateTime FSA_Effective_Date;
                DateTime Fsa_Renewal_Date;

                #region HashtableFSA
                HashtableFSA.Add(1, "150");     //Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");     //Administration Services – Grace Period
                HashtableFSA.Add(3, "354");     //Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            FSA_Effective_Date = Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"]);
                            Fsa_Renewal_Date = Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"]);

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("MAIN_FSA_HRA"))
                                                {
                                                    myMergeField.Select();

                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText(" ");
                                                    continue;
                                                }

                                                if (key == 3)
                                                {
                                                    if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (key == 1)
                                                {
                                                    if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (fieldName.Contains("FSA_Plan"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText(" ");
                                                }
                                                if (fieldName.Contains("FSA Plan Effective date"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(FSA_Effective_Date.ToShortDateString());
                                                }

                                                if (fieldName.Contains("FSA Plan Renewal date minus 1 day"))
                                                {
                                                    myMergeField.Select();

                                                    oWordDoc.Tables[22].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                                    oWordDoc.Tables[22].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                                    oWordDoc.Tables[22].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                                    oWordDoc.Tables[22].Range.Font.Color = wdColor_font;

                                                    oWordDoc.Tables[22].Rows[9].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedcolor);

                                                    DateTime FSA_Renewal_Date_Minus_Day = Convert.ToDateTime(Fsa_Renewal_Date).AddDays(-1);
                                                    oWordApp.Selection.TypeText(FSA_Renewal_Date_Minus_Day.ToShortDateString());
                                                    continue;
                                                }

                                                if (fieldName.Contains("FSA Carrier Website"))
                                                {
                                                    myMergeField.Select();
                                                    if (foundRows.Count() > 0)
                                                    {
                                                        if (!string.IsNullOrEmpty(foundRows[0]["Website"].ToString().Trim()))
                                                        {
                                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                                        }
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                            }
                                        }

                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList, string clientName, DropDownList ddlHSAPlanName, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                string carrier = string.Empty;
                string employeeOnlyCoverage = " ";
                string familyCoverage = " ";
                string employeesOver55 = " ";

                Hashtable HashtableHSABenifit = new Hashtable();

                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string value = "";

                #region HashtablHashtableHSA

                HashtableHSABenifit.Add(1, "635");     //General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSABenifit.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family

                //HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                //HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                // IRS
                DataTable dt_IRS = new DataTable();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            // Get the renewal year for taking the IRS table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).Year);

                            dt_IRS = bp.GetIRCList(renewalDate);
                            carrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                            for (int j = 0; j < dt_IRS.Rows.Count; j++)
                            {
                                employeeOnlyCoverage = Convert.ToString(dt_IRS.Rows[j]["EmployeeOnlyCoverage"].ToString());

                                familyCoverage = Convert.ToString(dt_IRS.Rows[j]["FamilyCoverage"].ToString());
                                //employeesOver55 = Convert.ToString(dt_IRC.Rows[j]["EmployeesOver55"].ToString());
                            }

                            #region HSABenifitTable

                            foreach (int key in HashtableHSABenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSABenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value; break;
                                            case 2: Max_Annual_Contribution_Family1 = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion
                        }
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                if (ddlHSAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HSA_Plan"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");

                            }

                            if (fieldName.Contains("HSA Carrier"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(carrier))
                                {
                                    oWordApp.Selection.TypeText(carrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("IRS Employee Only coverage"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(employeeOnlyCoverage);
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                continue;
                            }
                            if (fieldName.Contains("IRS Family Coverage"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.TypeText(familyCoverage);
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                continue;
                            }


                            if (fieldName.Contains("Health Savings Account (HSA)"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Health Savings Account (HSA)");
                                continue;
                            }
                            if (fieldName.Contains("What is a Health Savings Account (HSA)?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("What is a Health Savings Account (HSA)?");
                                continue;
                            }
                            if (fieldName.Contains("Plus, you get extra tax advantages with an HSA because:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Plus, you get extra tax advantages with an HSA because:");
                                continue;
                            }
                            if (fieldName.Contains("HSA Contributions"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HSA Contributions");
                                continue;
                            } if (fieldName.Contains("FOR THE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("FOR THE");
                                continue;
                            }

                            if (fieldName.Contains("TAX YEAR:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("TAX YEAR:");
                                continue;
                            } if (fieldName.Contains("How do I get reimbursed for my eligible expenses?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("How do I get reimbursed for my eligible expenses?");
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                string HRACarrier = string.Empty;

                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "239"); // Health Reimbursement Account Tier 2

                #endregion

                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;

                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                HRACarrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                                foreach (int key in HashtableHRA.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HRA Carrier Name"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRACarrier))
                                {
                                    oWordApp.Selection.TypeText(HRACarrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA_Plan"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");

                            }
                            if (fieldName.Contains("HRA Tier One"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA Tier Two"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("Health Reimbursement Account (HRA)"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Health Reimbursement Account (HRA)");
                                continue;
                            }

                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        ///  Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteEAPSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, string selectedcolor)
        {
            try
            {
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string OldCarrier = "";

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                HashtableEAP.Add(1, "384"); //Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Number of Visit Item"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                }

                                                if (fieldName.Contains("EAP Plan Carrier"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                }
                                                if (fieldName.Contains("Employee Assistance Program"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText("Employee Assistance Program");
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS ">DataSet BenefitStructureDS  Object as optional parameter</param>
        //// public void WriteAdditionalProductsToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        public void WriteAdditionalProductsToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Accident_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Voluntary_Cancer_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Voluntary_Critical_Illness_Selected = true;
                        }
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("PATIENT ADVOCACY PROGRAM"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("PATIENT ADVOCACY PROGRAM");
                                continue;
                            }
                            if (fieldName.Contains("PA Plan Selected"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("COMPASS - YOUR PERSONAL HEALTHCARE ADVISORS"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("COMPASS - YOUR PERSONAL HEALTHCARE ADVISORS");
                                continue;
                            }
                            if (fieldName.Contains("WHY SHOULD YOU CONTACT COMPASS??"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHY SHOULD YOU CONTACT COMPASS??");
                                continue;
                            }
                            if (fieldName.Contains("YOUR HEALTH PROS CAN TELL YOU THE LOWER COST OPTIONS."))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("YOUR HEALTH PROS CAN TELL YOU THE LOWER COST OPTIONS.");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("TELEMEDICINE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("TELEMEDICINE");
                                continue;
                            }
                            if (fieldName.Contains("Telemedicine Plan Selected"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("HERE ARE SOME FREQUENTLY ASKED QUESTIONS REGARDING TELADOC:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HERE ARE SOME FREQUENTLY ASKED QUESTIONS REGARDING TELADOC:");
                                continue;
                            }

                            if (fieldName.Contains("WHAT KIND OF MEDICAL CARE DOES TELADOC PROVIDE?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHAT KIND OF MEDICAL CARE DOES TELADOC PROVIDE?");
                                continue;
                            }

                            if (fieldName.Contains("DOES TELADOC REPLACE MY DOCTOR?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("DOES TELADOC REPLACE MY DOCTOR?");
                                continue;
                            }
                            if (fieldName.Contains("HOW DO I REQUEST A CONSULT TO TALK TO A DOCTOR?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HOW DO I REQUEST A CONSULT TO TALK TO A DOCTOR?");
                                continue;
                            }
                            if (fieldName.Contains("HOW DO I SET UP MY TELADOC ACCOUNT?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HOW DO I SET UP MY TELADOC ACCOUNT?");
                                continue;
                            }
                            if (fieldName.Contains("HOW FREQUENTLY CAN I CALL TELADOC?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("HOW FREQUENTLY CAN I CALL TELADOC?");
                                continue;
                            }
                            if (fieldName.Contains("CAN TELADOC DOCTORS WRITE A PRESCRIPTION?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CAN TELADOC DOCTORS WRITE A PRESCRIPTION?");
                                continue;
                            }

                            if (fieldName.Contains("WHO ARE TELADOC DOCTORS?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHO ARE TELADOC DOCTORS?");
                                continue;
                            }
                            if (fieldName.Contains("WHAT IS THE COST TO USE TELADOC?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHAT IS THE COST TO USE TELADOC?");
                                continue;
                            }
                        }

                        if (is_Accident_Selected == true || is_Voluntary_Cancer_Selected == true || is_Voluntary_Critical_Illness_Selected == true)
                        {
                            if (fieldName.Contains("WORKSITE PRODUCTS"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WORKSITE PRODUCTS");
                                continue;
                            }
                            if (fieldName.Contains("worksite Plan Selected"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("SHORT TERM DISABILITY"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("SHORT TERM DISABILITY");
                                continue;
                            }
                            if (fieldName.Contains("ACCIDENT INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("ACCIDENT INSURANCE");
                                continue;
                            }
                            if (fieldName.Contains("CANCER INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CANCER INSURANCE");
                                continue;
                            }
                            if (fieldName.Contains("CRITICAL ILLNESS INSURANCE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CRITICAL ILLNESS INSURANCE");
                                continue;
                            }
                            if (fieldName.Contains("To find out more information or to apply for coverage ,leave a detailed message(name/contact information) or email at: Phone Number and/or E-mail Address"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("To find out more information or to apply for coverage, leave a detailed message (name/contact information) or email at:");
                                continue;
                            }
                            if (fieldName.Contains("Phone Number and/or E-mail Address"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Phone Number and/or E-mail Address");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, string selectedColor = "")
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int count = 1;
                DataTable PremiumTable = new DataTable();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                int tableNoVolLifeRates = 25;
                string dependent_child_rate_1 = " ";
                string dependent_child_rate_2 = " ";

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        PremiumTable.Clear();
                        premium_row_counter = 0;
                        if (count == 2)
                        {
                            tableNoVolLifeRates = 27;
                        }
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Range.Font.Color = wdColor_font;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Shading.BackgroundPatternColor = comFunObj.cell_color(selectedColor);

                        int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }

                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                        int StartValue = Start;
                        int RowCount = 4;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount + 1, 1).Range.Text = "Composite";

                        #region For EE NonSmoker
                        int ColumnCount = 0;
                        DataTable dt = new DataTable();
                        bool isUniSmokerValueExists = false;
                        bool isSmokerValueExists = false;
                        bool isNonSmokerColumnInserted = false;

                        PremiumTable.DefaultView.Sort = "[ageBandIndex], [rateTierID] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 3;

                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                isUniSmokerValueExists = true;
                                break;
                            }
                        }

                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (isUniSmokerValueExists == true)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    isUniSmokerValueExists = true;
                                    ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 2).Range.Text = "Uni-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }
                            else if (isUniSmokerValueExists == false)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE Smoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    ColumnCount = 2;
                                    isSmokerValueExists = true;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 2).Range.Text = "Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;

                                    if (isNonSmokerColumnInserted == false)
                                    {
                                        ColumnCount = 3;
                                        oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                        oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                        oWordDoc.Tables[tableNoVolLifeRates].Cell(2, ColumnCount).Range.Text = "Non-Smoker";
                                        isNonSmokerColumnInserted = true;
                                    }

                                }

                                else if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE NonSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    // For inserting extra column
                                    if (isSmokerValueExists == true)
                                    {
                                        RowCount = RowCount - 1;
                                        ColumnCount = 3;
                                        //if (isNonSmokerColumnInserted == false)
                                        //{
                                        //    oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                        //    oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                        //    isNonSmokerColumnInserted = true;
                                        //}
                                    }
                                    else
                                    {
                                        ColumnCount = 2;
                                    }

                                    //oWordDoc.Tables[tableNoVolLifeRates].Cell(2, ColumnCount).Range.Text = "Non-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }

                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                            {
                                if (count == 1)
                                {
                                    dependent_child_rate_1 = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                }
                                else if (count == 2)
                                {
                                    dependent_child_rate_2 = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                }
                            }
                        }

                        #endregion

                        #region For SpouseNonSmoker

                        int lastColCnt = oWordDoc.Tables[tableNoVolLifeRates].Columns.Count;
                        oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();

                        oWordDoc.Tables[tableNoVolLifeRates].Cell(1, lastColCnt + 1).Range.Text = "Spouse Monthly Cost per $1,000";
                        bool isSpouseUniSmokerValueExists = false;
                        bool isSpouseSmokerValueExists = false;
                        bool isSpouseNonSmokerColumnInserted = false;
                        RowCount = 3;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                isSpouseUniSmokerValueExists = true;
                                break;
                            }
                        }

                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (isSpouseUniSmokerValueExists == true)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    isSpouseUniSmokerValueExists = true;
                                    ColumnCount = lastColCnt + 1;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(2, lastColCnt + 1).Range.Text = "Uni-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }
                            else if (isSpouseUniSmokerValueExists == false)
                            {
                                if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse Smoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    ColumnCount = lastColCnt + 1;
                                    isSpouseSmokerValueExists = true;
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(2, lastColCnt + 1).Range.Text = "Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;

                                    ColumnCount = lastColCnt + 2;
                                    if (isSpouseNonSmokerColumnInserted == false)
                                    {
                                        oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                        oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                        isSpouseNonSmokerColumnInserted = true;
                                        oWordDoc.Tables[tableNoVolLifeRates].Cell(2, ColumnCount).Range.Text = "Non-Smoker";
                                    }
                                }

                                else if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse NonSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                {
                                    // For inserting extra column
                                    if (isSpouseSmokerValueExists == true)
                                    {
                                        RowCount = RowCount - 1;
                                        ColumnCount = lastColCnt + 2;
                                        //if (isSpouseNonSmokerColumnInserted == false)
                                        //{
                                        //    oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                        //    oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                        //    isSpouseNonSmokerColumnInserted = true;
                                        //}
                                    }
                                    else
                                    {
                                        ColumnCount = lastColCnt + 1;
                                    }

                                    //oWordDoc.Tables[tableNoVolLifeRates].Cell(2, ColumnCount).Range.Text = "Non-Smoker";
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                    RowCount++;
                                }
                            }

                        }


                        # endregion

                        if (isSmokerValueExists == true)
                        {
                            oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 2).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 3));
                            lastColCnt = lastColCnt - 1;
                        }
                        if (isSpouseSmokerValueExists == true)
                        {
                            oWordDoc.Tables[tableNoVolLifeRates].Cell(1, lastColCnt + 1).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(1, lastColCnt + 2));
                        }
                        oWordDoc.Tables[tableNoVolLifeRates].Range.Font.Color = comFunObj.font_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders.Enable = 1;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderTop].Visible = true;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderLeft].Visible = false;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderRight].Visible = false;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderVertical].Visible = false;
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[tableNoVolLifeRates].Rows.Last.Borders[Word.WdBorderType.wdBorderBottom].Visible = true;

                        oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 1).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 1));
                        oWordDoc.Tables[tableNoVolLifeRates].PreferredWidth = oWordApp.InchesToPoints(7.65f);


                        count++;
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dependent Child Rate 1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dependent_child_rate_1);
                            continue;
                        }
                        if (fieldName.Contains("Dependent Child Rate 2"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dependent_child_rate_2);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary ADnD Rates Selected"))
                        {
                            if (count == 3)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                int count1 = 1;
                string value = string.Empty;
                string Overall_Maximum_Employee = "";
                string Guarantee_Issue_Amt_Employee = "";
                string OverallMaximumSpouse = "";
                string GuarenteeIssueAmtSpouse = "";
                string OverallMaximumChild = "";
                string GuarenteeIssueAmtChild = "";
                string BenefitAmountSpouse = "";
                string BenefitAmountChild = "";


                string voluntary_Life_planType_plan1 = "";
                string voluntary_Life_planType_plan2 = "";
                string voluntary_Life_Rate_plan1 = "";
                string voluntary_Life_Rate_plan2 = "";
                string Vol_LifePlanTypeText1_plan1 = "";
                string Vol_LifePlanTypeText2_plan1 = "";
                string Vol_LifePlanTypeText1_plan2 = "";
                string Vol_LifePlanTypeText2_plan2 = "";

                string Overall_Maximum_Employee2 = "";
                string Guarantee_Issue_Amt_Employee2 = "";
                string OverallMaximumSpouse2 = "";
                string GuarenteeIssueAmtSpouse2 = "";
                string OverallMaximumChild2 = "";
                string GuarenteeIssueAmtChild2 = "";
                string BenefitAmountChild2 = "";
                string BenefitAmountSpouse2 = "";
                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string age = "";
                string age_to = "";
                double benefitamount = 0;
                int voluntaryLife_TblNmuber1 = 24;
                List<string> PlanList = new List<string>();
                string PlanListDisplay = "";
                #region HashtableVoluntaryLifeADDBenifit

                /*Delete Overall maximum row from all catagory--29/05/2014*/
                HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]4
                HashtableVoluntaryLifeADDBenifit.Add(6, "516");//Spouse[Benefit Amount]6
                HashtableVoluntaryLifeADDBenifit.Add(8, "519"); //Spouse[Overall Maximum]
                //HashtableVoluntaryLifeADDBenifit.Add(8, "467"); //Reduction of Benefits
                HashtableVoluntaryLifeADDBenifit.Add(7, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(9, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(15, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(10, "103"); //Child(ren)[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(11, "2");//age--
                HashtableVoluntaryLifeADDBenifit.Add(12, "3");//age
                HashtableVoluntaryLifeADDBenifit.Add(13, "4");//age
                HashtableVoluntaryLifeADDBenifit.Add(14, "5");//age

                #endregion
                string planType = string.Empty;

                #region PlanList
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count1 == 1)
                            {
                                if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                                {
                                    //isVolLife_Selected = true;
                                    PlanList.Add("Voluntary Life");
                                    voluntary_Life_planType_plan1 = "SUMMARY OF COVERAGE FOR VOLUNTARY LIFE INSURANCE";
                                    voluntary_Life_Rate_plan1 = "Voluntary Life Rates";
                                    Vol_LifePlanTypeText1_plan1 = "Voluntary Life";
                                    Vol_LifePlanTypeText2_plan1 = "Voluntary Life";
                                }
                                if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                                {
                                    //isVolADnD_Selected = true;
                                    PlanList.Add("Voluntary AD&D");
                                    voluntary_Life_planType_plan1 = "SUMMARY OF COVERAGE FOR VOLUNTARY AD&D INSURANCE";
                                    voluntary_Life_Rate_plan1 = "Voluntary AD&D Rates";
                                    Vol_LifePlanTypeText2_plan1 = "Voluntary AD&D";
                                    Vol_LifePlanTypeText1_plan1 = "Voluntary AD&D";
                                }
                            }
                            if (count1 == 2)
                            {
                                if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                                {
                                    if (!PlanList.Contains("Voluntary Life"))
                                    {
                                        PlanList.Add("Voluntary Life");
                                        voluntary_Life_planType_plan2 = "SUMMARY OF COVERAGE FOR VOLUNTARY LIFE INSURANCE";
                                        voluntary_Life_Rate_plan2 = "Voluntary Life Rates";
                                        Vol_LifePlanTypeText1_plan2 = "Voluntary Life";
                                        Vol_LifePlanTypeText2_plan2 = "Voluntary Life";
                                    }
                                }
                                if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                                {
                                    if (!PlanList.Contains("Voluntary AD&D"))
                                    {
                                        PlanList.Add("Voluntary AD&D");
                                        voluntary_Life_planType_plan2 = "SUMMARY OF COVERAGE FOR VOLUNTARY AD&D INSURANCE";
                                        voluntary_Life_Rate_plan2 = "Voluntary AD&D Rates";
                                        Vol_LifePlanTypeText2_plan2 = "Voluntary AD&D";
                                        Vol_LifePlanTypeText1_plan2 = "Voluntary AD&D";
                                    }
                                }
                            }

                            count1++;
                        }
                    }
                }

                #endregion PlanList
                PlanListDisplay = String.Join(" and ", PlanList.ToArray());
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Range.Font.Color = wdColor_font;
                            }
                            if (count == 2)
                            {
                                voluntaryLife_TblNmuber1 = 26;
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                                oWordDoc.Tables[voluntaryLife_TblNmuber1].Range.Font.Color = wdColor_font;
                            }
                            #region VoluntaryLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                            {
                                //isVolLife_Selected = true;
                                planType = cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower();
                            }
                            if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                            {
                                //isVolADnD_Selected = true;
                                planType = cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower().Trim().ToLower();
                            }
                            string planname = PlanTable.Rows[k]["ProductTypeDescription"].ToString();
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim().ToLower() == planType && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 4: Overall_Maximum_Employee = value; break;
                                                case 5: Guarantee_Issue_Amt_Employee = value; break;
                                                case 8: OverallMaximumSpouse = value; break;
                                                case 7: GuarenteeIssueAmtSpouse = value; break;
                                                case 15: OverallMaximumChild = value; break;
                                                case 10: GuarenteeIssueAmtChild = value; break;
                                                case 9: BenefitAmountChild = value; break;
                                                case 6: BenefitAmountSpouse = value; break;
                                                //case 187: EmployeeIssueAmt = value; break;
                                            }

                                        }
                                        if (count == 2)
                                        {
                                            //age = "";
                                            //age_to = "";
                                            switch (key)
                                            {
                                                case 4: Overall_Maximum_Employee2 = value; break;
                                                case 5: Guarantee_Issue_Amt_Employee2 = value; break;
                                                case 8: OverallMaximumSpouse2 = value; break;
                                                case 7: GuarenteeIssueAmtSpouse2 = value; break;
                                                case 15: OverallMaximumChild2 = value; break;
                                                case 10: GuarenteeIssueAmtChild2 = value; break;
                                                case 9: BenefitAmountChild2 = value; break;
                                                case 6: BenefitAmountSpouse2 = value; break;
                                                //case 187: EmployeeIssueAmt = value; break;
                                            }

                                        }

                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = value; } break;       // 65-69
                                            case 3: if (value.Trim() != string.Empty) { age = value; } break;       // 70-74
                                            case 4: if (value.Trim() != string.Empty) { age_to = value; } break;    // 75-79
                                            case 5: if (value.Trim() != string.Empty) { age = value; } break;       // 80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Voluntary Life Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    if (fieldName.Contains("VoluntaryPlanList"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanListDisplay);
                                    }

                                    if (count == 2)
                                    {
                                        if (fieldName.Contains("Second_Voluntary_Life_Plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("Voluntary Life and AD&D Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(planname.Trim());
                                    }



                                    if (fieldName.Contains("VoluntaryLifeADDTaxation"))
                                    {
                                        if (benefitamount > 50000)
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (count == 1)
                                    {
                                        #region Voluntary First plan


                                        if (fieldName.Contains("SUMMARY OF COVERAGE FOR VOLUNTARY LIFE INSURANCE"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(voluntary_Life_planType_plan1);
                                            continue;
                                        }

                                        if (fieldName.Contains("Voluntary Life Rates"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(voluntary_Life_Rate_plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("Vol_LifePlanTypeText1_plan1"))
                                        {
                                            myMergeField.Select();
                                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(Vol_LifePlanTypeText1_plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("Vol_LifePlanTypeText2_plan1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(Vol_LifePlanTypeText2_plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("voluntaryageto"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(age_to))
                                            {
                                                oWordApp.Selection.TypeText(age_to.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("voluntaryagefrom"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(age))
                                            {
                                                oWordApp.Selection.TypeText(age.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Voluntary General Plan information – Overall Maximum – Employee"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(Overall_Maximum_Employee.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Overall_Maximum_Employee.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Guarantee Issue Amount  Employee"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(Guarantee_Issue_Amt_Employee.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Guarantee_Issue_Amt_Employee.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("General Plan Information / Benefit Amount / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(BenefitAmountSpouse.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(BenefitAmountSpouse.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("General Plan Information / Overall Maximum / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(OverallMaximumSpouse.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumSpouse.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("General Plan Information / Guarantee Issue Amount / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(GuarenteeIssueAmtSpouse.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtSpouse.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("General PlInformation / Benefit Amount / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(BenefitAmountChild.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(BenefitAmountChild.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("General Plan Information / Overall Maximum / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(OverallMaximumChild.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumChild.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("General Plan Information / Guarantee Issue Amount / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(GuarenteeIssueAmtChild.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtChild.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }

                                    if (count == 2)
                                    {
                                        #region Voluntary Second plan
                                        if (fieldName.Contains("Second_SUMMARY_OF_COVERAGE_FOR_VOLUNTARY_LIFE_INSURANCE"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(voluntary_Life_planType_plan2);
                                            continue;
                                        }

                                        if (fieldName.Contains("Second_Voluntary_Life_Rates"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(voluntary_Life_Rate_plan2);
                                            continue;
                                        }
                                        if (fieldName.Contains("Vol_LifePlanTypeText1_plan2"))
                                        {
                                            myMergeField.Select();
                                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(Vol_LifePlanTypeText1_plan2);
                                            continue;
                                        }
                                        if (fieldName.Contains("Vol_LifePlanTypeText2_plan2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(Vol_LifePlanTypeText2_plan2);
                                            continue;
                                        }
                                        if (fieldName.Contains("Second_voluntary_ageto"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(age_to))
                                            {
                                                oWordApp.Selection.TypeText(age_to.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("Second_voluntary_agefrom"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(age))
                                            {
                                                oWordApp.Selection.TypeText(age.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_Voluntary_General Plan information – Overall Maximum – Employee"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(Overall_Maximum_Employee2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Overall_Maximum_Employee2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_Guarantee_Issue Amount  Employee"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(Guarantee_Issue_Amt_Employee2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Guarantee_Issue_Amt_Employee2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("Second_General_Plan Information / Benefit Amount / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(BenefitAmountSpouse2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(BenefitAmountSpouse2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_General_Plan Information / Overall Maximum / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(OverallMaximumSpouse2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumSpouse2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_General_Plan Information / Guarantee Issue Amount / Spouse"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(GuarenteeIssueAmtSpouse2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtSpouse2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("Second_General_PlInformation / Benefit Amount / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(BenefitAmountChild2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(BenefitAmountChild2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_General_Plan Information / Overall Maximum / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(OverallMaximumChild2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumChild2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("Second_General_Plan Information / Guarantee Issue Amount / Child(ren)"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (!string.IsNullOrEmpty(GuarenteeIssueAmtChild2.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtChild2.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                // Call common function to write the contact information page fields
                //Commented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true, selectedcolor, "Value Summary");
                //Added By Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor, "Value Summary");
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>

        public void WriteContactinformationToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor = "", DataTable dtPlanContactDetails = null)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                string summaryname = "";
                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;
                int rowCnt = 1;
                int count = 30;//Table Numbaer for contact information
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        //if (k > 0)
                        //{
                        //    oWordDoc.Tables[count].Rows.Add();
                        //}
                        carriername = PlanTable.Rows[i]["Carrier"].ToString().Replace("''", "'");
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        summaryname = PlanTable.Rows[i]["SummaryName"].ToString();
                        var planContactName = (from n in dtPlanContactDetails.AsEnumerable()
                                               where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                               select n.Field<string>("ContactName")).FirstOrDefault();
                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                        if (!string.IsNullOrEmpty(planContactName) || !string.IsNullOrEmpty(planContactPhone))
                        {
                            oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = ProductTypeDesc + " " + summaryname;
                            oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = carriername + "\nGroup Number: #" + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                            oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = planContactName + "\n" + planContactPhone;
                            // k++;
                            oWordDoc.Tables[count].Rows.Add();
                            rowCnt++;
                        }
                    }
                }
                if (oWordDoc.Tables[count].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[count].Rows.Last.Delete();
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            string domesticPartner = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("EmployeeStatus"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unitofmeasure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("definitionofdomesticpartner"))
                    {
                        myMergeField.Select();
                        if (domesticPartner != string.Empty)
                            oWordApp.Selection.TypeText(domesticPartner);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period.ToLower());
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }
    }
}