﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;

namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteCensusRequestTemplate
    {
        public void Write_CensusOver50_Template(Excel.Application myExcelApp,string ClientName, string SICCode)
        {
            Excel.Worksheet myWorksheet = null;
            myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets["CENSUS"];
            myWorksheet.Cells[1, 3] = ClientName;
            myWorksheet.Cells[11, 2] = SICCode;
        }

        public void Write_CensusUnder50_Template(Excel.Application myExcelApp, string ClientName, string SICCode)
        {
            Excel.Worksheet myWorksheet = null;
            myWorksheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets["CENSUS"];
            myWorksheet.Cells[1, 3] = ClientName;
            myWorksheet.Cells[11, 2] = SICCode;
        }
    }
}