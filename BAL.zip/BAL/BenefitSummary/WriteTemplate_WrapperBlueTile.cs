﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;
using System.Text.RegularExpressions;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_WrapperBlueTile : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string Renewaldate = string.Empty;
        Dictionary<string, List<int>> DictContactsPlanTypes = new Dictionary<string, List<int>>();
        private void BuiltDictContactsPlanTypes()
        {
            DictContactsPlanTypes.Clear();

            comFunObj.LoadPlanTypeIds();
            DictContactsPlanTypes.Add("Medical Insurance", CommonFunctionsBS.MedicalPlanTypeList);
            DictContactsPlanTypes.Add("Dental Insurance", CommonFunctionsBS.DentalPlanTypeList);
            DictContactsPlanTypes.Add("Vision Benefits", CommonFunctionsBS.VisionPlanTypeList);

            comFunObj.LoadPlanTypeIds_Pilot();
            DictContactsPlanTypes.Add("Life and AD&D Insurance", CommonFunctionsBS.LifeADDPlanTypeList);
            DictContactsPlanTypes.Add("Group Term Life Insurance", CommonFunctionsBS.GroupTermLifePlanTypeList);
            DictContactsPlanTypes.Add("Accidental Death & Dismemberment Insurance", CommonFunctionsBS.ADNDPlanTypeList);

            DictContactsPlanTypes.Add("Voluntary Life Insurance", CommonFunctionsBS.VoluntaryLifeADDPlanTypeList);
            DictContactsPlanTypes.Add("Voluntary AD&D Insurance", CommonFunctionsBS.VoluntaryADDPlanTypeList);

            DictContactsPlanTypes.Add("Short Term Disability Insurance", CommonFunctionsBS.STDPlanTypeList);
            DictContactsPlanTypes.Add("Long Term Disability Insurance", CommonFunctionsBS.LTDPlanTypeList);

            DictContactsPlanTypes.Add("Health Savings Account", CommonFunctionsBS.HSAPlanTypeList);
            DictContactsPlanTypes.Add("Health Reimbursement Account", CommonFunctionsBS.HRAPlanTypeList);

            DictContactsPlanTypes.Add("Flexible Spending Accounts", CommonFunctionsBS.FSAPlanTypeList);
            DictContactsPlanTypes.Add("Employee Assistance Program", CommonFunctionsBS.EAPPlanTypeList);

            DictContactsPlanTypes.Add("Patient Advocacy Program", new List<int> { ConstantValue.AdditionalProducts_Patient_Advocacy });
            DictContactsPlanTypes.Add("Telemedicine", new List<int> { ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine });
            DictContactsPlanTypes.Add("Wellness Plan", new List<int> { ConstantValue.AdditionalProducts_Wellness });
            DictContactsPlanTypes.Add("Accident Insurance", new List<int> { ConstantValue.AdditionalProducts_Accident });
            DictContactsPlanTypes.Add("Critical Illness Insurance", new List<int> { ConstantValue.AdditionalProducts_Voluntary_Critical_Illness });

            DictContactsPlanTypes.Add("401(k) Insurance", new List<int> { 340 });
            DictContactsPlanTypes.Add("Disability Insurance", new List<int> { 294, 293, 292 });
            DictContactsPlanTypes.Add("Business Travel Accident (BTA)", new List<int> { 320 });

            DictContactsPlanTypes.Add("Prescription Drug (Carve-Out)", new List<int> { 173 });
        }
        private bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        private DataTable AddColumnToPlanTable(DataTable PlanTable, string SessionId)
        {
            BuiltDictContactsPlanTypes();

            if (!PlanTable.Columns.Contains("contactPlanType"))
            {
                PlanTable.Columns.Add("contactPlanType", typeof(string));
            }

            foreach (DataRow row in PlanTable.Rows)
            {
                foreach (string plantype in DictContactsPlanTypes.Keys)
                {
                    if (DictContactsPlanTypes[plantype].Contains(Convert.ToInt32(row["ProductTypeId"])))
                    {
                        if (plantype == "Life and AD&D Insurance" && IsProductVoluntary(Convert.ToInt32(row["ProductId"]), SessionId))
                        {
                            row["contactPlanType"] = "Voluntary Life & AD&D Insurance";
                        }
                        else
                        {
                            row["contactPlanType"] = plantype;
                        }

                        break;
                    }
                }
            }
            if (!PlanTable.Columns.Contains("CarrierPlanType"))
            {
                PlanTable.Columns.Add("CarrierPlanType", typeof(string));
            } foreach (DataRow row in PlanTable.Rows)
            {
                row["CarrierPlanType"] = row["Carrier"] + " " + row["Name"];
            }
            return PlanTable;
        }
        #region ContactInformation Section
        public void WriteContactinformationToBlueTileWrapper(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, string SessionId, DropDownList ClientName, List<Contact> ContactList, ArrayList arrAcctContact)
        {
            string carriername = "";
            string carrier = string.Empty;
            string Policy_no = string.Empty;
            string ClientContact_Name = string.Empty;
            string PhoneNumber = string.Empty;
            string ClientContact_Email = string.Empty;

            Dictionary<string, string> DistinctPlanTypes = new Dictionary<string, string>();
            DistinctPlanTypes.Clear();

            DataTable DistinctPlanTable = AddColumnToPlanTable(PlanTable, SessionId);
            IList<string> bkList = new List<string>();
            bkList.Clear();
            #region Contact Name,Email,Phone
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    ClientContact_Name = ContactList[i].Name;
                                }
                                else
                                {
                                    ClientContact_Name = " ";
                                }
                                if (ContactList[i].Email != null)
                                {
                                    ClientContact_Email = ContactList[i].Email;
                                }
                                else
                                {
                                    ClientContact_Name = " ";
                                }
                                if (ContactList[i].Phone.Count > 0)
                                {
                                    PhoneNumber = ContactList[i].Phone[0];
                                }
                                else
                                {
                                    PhoneNumber = " ";
                                }
                            }
                        }
                    }
                }
            }
            #endregion
            #region Removing dulicate rows from table
            for (int rowindex = 0; rowindex < DistinctPlanTable.Rows.Count; rowindex++)
            {
                string CarrierPlanType = (DistinctPlanTable.Rows[rowindex]["CarrierPlanType"].ToString()).Replace(" ", string.Empty); ;
                if ((!DistinctPlanTypes.ContainsKey(CarrierPlanType)) && CarrierPlanType != "")
                {
                    DistinctPlanTypes.Add(CarrierPlanType, CarrierPlanType);
                }
                else
                {
                    DistinctPlanTable.Rows[rowindex].Delete();
                    rowindex--;
                }
            }
            #endregion
            #region writing Contacts
            Bookmark bk = oWordDoc.Bookmarks["UniqueBookmark"];
            Range r = bk.Range;
            r.FormattedText.Select();
            r.Copy();
            foreach (Word.Field myMergeField in r.Fields)
            {

                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();
                    if (fieldName.Contains("Space"))
                    {
                        myMergeField.Select();

                        myMergeField.Delete();
                    }
                    if (fieldName.Contains("UniquePlan"))
                    {
                        myMergeField.Select();
                        myMergeField.Delete();
                        r.FormattedText.Paste();
                        continue;
                    }

                }
            }
            for (int rowindex = 0; rowindex < DistinctPlanTable.Rows.Count; rowindex++)
            {

                if (DistinctPlanTable.Rows[rowindex]["contactPlanType"].ToString() == "Medical Insurance" && Renewaldate == string.Empty)
                {
                    Renewaldate = DistinctPlanTable.Rows[rowindex]["Effective"].ToString();


                }

                Bookmark bookmk = oWordDoc.Bookmarks["UniqueBookmark"];
                Range rang = bookmk.Range;
                string plantype = DistinctPlanTable.Rows[rowindex]["Name"].ToString();
                string benefit_Summary_desp = DistinctPlanTable.Rows[rowindex]["SummaryName"].ToString();

                carriername = DistinctPlanTable.Rows[rowindex]["Carrier"].ToString();
                Policy_no = Convert.ToString(DistinctPlanTable.Rows[rowindex]["PolicyNumber"].ToString());
                // string text = bk.Range.Text;
                //if (benefit_Summary_desp == "&nbsp;")
                //    benefit_Summary_desp = " ";
                if (Policy_no == "&nbsp;")
                    Policy_no = " ";
                //if (benefit_Summary_desp.Contains("amp;"))
                //    benefit_Summary_desp = benefit_Summary_desp.Replace("amp;", "");
                string plantypeSummary = plantype;//+ " - " + benefit_Summary_desp;
                foreach (Word.Field myMergeField in rang.Fields)
                {
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(carriername);
                            continue;
                        }

                        if (fieldName.Contains("Policy Number"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Policy_no);
                            continue;
                        }
                        if (fieldName.Contains("Summary_Desc"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(plantypeSummary);
                            continue;
                        }
                        if (rowindex < DistinctPlanTable.Rows.Count - 1)
                        {
                            if (fieldName.Contains("UniquePlan"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                // oWordApp.Selection.TypeText();
                                r.FormattedText.Paste();
                                continue;
                            }
                        }
                    }
                }


            }

            #endregion

            #region MergeField for first effective date,Contact Name,Phone,Email

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("First Medical Effective Date"))
                    {
                        myMergeField.Select();
                        if (Renewaldate != "" && Renewaldate != null)
                        {
                            oWordApp.Selection.TypeText(Convert.ToDateTime(Renewaldate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(Renewaldate.ToString()).Year.ToString());
                            continue;
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                    }


                    if (fieldName.Contains("Contact_Name"))
                    {
                        myMergeField.Select();
                        if (ClientContact_Name != string.Empty)
                            oWordApp.Selection.TypeText(ClientContact_Name);
                        else
                            oWordApp.Selection.TypeText(" ");// myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Client_Contact_Ph_Number"))
                    {
                        myMergeField.Select();
                        if (PhoneNumber != string.Empty)
                            oWordApp.Selection.TypeText(PhoneNumber);
                        else
                            oWordApp.Selection.TypeText(" ");// myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Client_Contact_Email"))
                    {
                        myMergeField.Select();
                        if (ClientContact_Email != string.Empty)
                            oWordApp.Selection.TypeText(ClientContact_Email);
                        else
                            oWordApp.Selection.TypeText(" ");//myMergeField.Delete();
                        continue;
                    }
                }
            }
            #endregion

        }
        #endregion
        #region Eligibility
        public void Write_CommonFieldToBlueTileWrapper(Word.Document oWordDoc, Word.Application oWordApp, DataSet EligibilityDS, DropDownList ddlHRContact, List<Contact> ContactList, DataTable EmpTable, DataSet AccountDS, ArrayList arrAcctContact, DropDownList ddlClient, DataTable PlanTable)
        {
            try
            {
                ////Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int count = 1;
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (EmpTable.Rows.Count > 0)
                {
                    Emp = EmpTable;
                }



                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Text))
                            {
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");

                            }
                            continue;
                        }


                        if (fieldName.Contains("UniquePlan"))
                        {
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();
                            if (count == 12)
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            count++;
                            continue;
                        }
                        if (Emp.Rows.Count > 0)
                        {
                            if (fieldName.Contains("EmployeeStatus"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                continue;
                            }

                            if (fieldName.Contains("Frequency_Eligibility"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("EmployeeStatus"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }

                            if (fieldName.Contains("Frequency"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("medicalplanwaitingperiod"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().ToLower().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
        #region Brc Section
        public void Write_BRCToBlueTileWrapper(Word.Document oWordDoc, Word.Application oWordApp, List<BRCData> BRCList)
        {
            int BRCindex = 0;


            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("BRCEmail"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCEmail != string.Empty)
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail);
                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                    if (fieldName.Contains("BRCPhone"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCPhone != string.Empty)
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone);
                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                    //BRCDaysHours
                    if (fieldName.Contains("BRCDaysHours"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours);
                        continue;
                    }
                    if (fieldName.Contains("BRC Time Zone"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCPhone != string.Empty)
                            oWordApp.Selection.TypeText((BRCList[BRCindex].BRCTimezone).ToLower());
                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;

                    }
                }
            }
            #endregion
        }
        #endregion
        #region Delete Individual Bookmark
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark1)
        {

            if (oWordDoc.Bookmarks.Exists(bookmark1))
            {
                oWordDoc.Bookmarks[bookmark1].Range.Delete();
            }

        }
        #endregion
        #region Notice Section
        public void WriteNoticeSectionToBlueTileWrapper(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.Font.Size = 30;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

    }
}