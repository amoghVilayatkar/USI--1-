﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Office.Interop.Word;
using System.Globalization;

namespace BenefitPointSummaryPortal.BAL.BenefitsPointTools
{
    public class WriteNewBusinessTemplate
    {
        public void WriteToReplaceRenewTemplate(Document oWordDoc, Application oWordApp, string ClientName, string BORDate, string RenewalDate, string OriginalPlanEffectiveDate, string CommissionEffectiveDate)
        {
            try
            {
                string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
                DateTime dtBORDate = DateTime.ParseExact(BORDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtOriginalPlanEffectiveDate = DateTime.ParseExact(OriginalPlanEffectiveDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtCommissionEffectiveDate = DateTime.ParseExact(CommissionEffectiveDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtRenewalDate = DateTime.ParseExact(RenewalDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);

                DateTime dt4bi = dtCommissionEffectiveDate.AddMonths(12);
                DateTime dt4bii = dtRenewalDate.AddMonths(12);

                int iTotalFields = 0;
                #region merge field writting
                foreach (Microsoft.Office.Interop.Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }
                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Client Name"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName.Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("BORDate"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(dtBORDate.ToString("MM/dd/yyyy").Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("RenewalDate"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(dtRenewalDate.ToString("MM/dd/yyyy").Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
                #region WriteTextBoxes
                for (int i = 1; i <= oWordDoc.Shapes.Count; i++)
                {
                    if (oWordDoc.Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<OriginalDate>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtOriginalPlanEffectiveDate.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<CommissionEffectiveDate>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtCommissionEffectiveDate.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<RenewalDateInforceCoverage>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtRenewalDate.ToString("MM/dd/yyyy"); ;
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<4bi>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dt4bi.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<4bii>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dt4bii.ToString("MM/dd/yyyy");
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void WriteToNewRenewTemplate(Document oWordDoc, Application oWordApp, string ClientName, string BORDate, string RenewalDate, string OriginalPlanEffectiveDate, string CommissionEffectiveDate)
        {
            try
            {
                string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
                DateTime dtBORDate = DateTime.ParseExact(BORDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtOriginalPlanEffectiveDate = DateTime.ParseExact(OriginalPlanEffectiveDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtCommissionEffectiveDate = DateTime.ParseExact(CommissionEffectiveDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);
                DateTime dtRenewalDate = DateTime.ParseExact(RenewalDate.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);

                DateTime dt4ai = dtCommissionEffectiveDate.AddMonths(12);


                int iTotalFields = 0;
                #region merge field writting
                foreach (Microsoft.Office.Interop.Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }
                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Client Name"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName.Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("BORDate"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(dtBORDate.ToString("MM/dd/yyyy").Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("RenewalDate"))
                        {
                            if (ClientName.Trim() != string.Empty)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(dtRenewalDate.ToString("MM/dd/yyyy").Trim());
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
                #region WriteTextBoxes
                for (int i = 1; i <= oWordDoc.Shapes.Count; i++)
                {
                    if (oWordDoc.Shapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<OriginalDate>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtOriginalPlanEffectiveDate.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<CommissionEffectiveDate>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtCommissionEffectiveDate.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<RenewalDateInforceCoverage>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dtRenewalDate.ToString("MM/dd/yyyy");
                        }
                        if (oWordDoc.Shapes[i].TextFrame.TextRange.Text.Contains("<<4ai>>"))
                        {
                            oWordDoc.Shapes[i].TextFrame.TextRange.Text = dt4ai.ToString("MM/dd/yyyy");
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}