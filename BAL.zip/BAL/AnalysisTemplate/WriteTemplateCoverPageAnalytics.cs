﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;

using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteTemplateCoverPageAnalytics
    {
        public void WriteTemplate_CommonFields(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DateTime MeetingDate, string ReportType)
        {

            #region MergeFields on page
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                    if (fieldName.Contains("ReportType"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ReportType.ToUpper());
                        continue;
                    }
                    if (fieldName.Contains("MeetingDate"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(MeetingDate.ToString("MMMM dd, yyyy"));
                        continue;
                    }
                }
            }
            #endregion

            #region Write Current date to footer
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Footers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Now.Year.ToString());

                                continue;
                            }
                        }
                    }
                }
            }
            #endregion
        }

        public void WriteTemplate_AccountContacts(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;
            string ServiceLead_FirstName = string.Empty;
            string ServiceLead_LastName = string.Empty;
            string PrimaryTeamContact = string.Empty;

            #region fetch data
            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimaryTeamContact = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"])+" "+ Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }
                    }
                }
            }
            #endregion

            #region MergeFields writing
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Primary Sales Lead"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                        continue;
                    }
                    if (fieldName.Contains("Primary Service Lead"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                        continue;
                    }
                    if (fieldName.Contains("Primary Contact"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(PrimaryTeamContact);
                        continue;
                    }
                }
            }
            #endregion

        }
    }
}