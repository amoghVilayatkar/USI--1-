﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class ActivityCls
    { 
        #region Variable
        private int _ActivityId;
        private string _Activity_Name;
        private string _Activity_Group;
        #endregion

        #region Properties

        /// <summary>
        /// Get and SetActivityId
        /// </summary>
        public int Activity_Id
        {
            get
            {
                return _ActivityId;
            }
            set 
            {
                _ActivityId = value;
            }
        }
        /// <summary>
        /// Get and SetActivity_Name
        /// </summary>
        public string Activity_Name
        {
            get
            {
                return _Activity_Name;
            }
            set 
            {
                _Activity_Name = value;
            }
        }
        /// <summary>
        /// Get and SetActivity_Group
        /// </summary>
        public string Activity_Group
        {
            get
            {
                return _Activity_Group;
            }
            set
            {
                _Activity_Group = value;
            }
        }
        
        #endregion
    }
}