﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.EmployeeEducationMaterials;
using BenefitPointSummaryPortal.Common.ViewModels;
using System.Data;
using System.Collections;
namespace BenefitPointSummaryPortal.View
{
    public partial class EmployeeEducationMaterials : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        EmployeeEducationSummary EmpEducational = new EmployeeEducationSummary();
        public ConstantValue cv = new ConstantValue();
        DataSet BenefitDS = new DataSet();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        public static Dictionary<string, string> dictFieldsValue = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        enum AccessKeys { SessionID, DeliverableCategory, IsDescriptionHide, AvailablePlanList, AvailableProductList, SelectedSummaries }
        enum PlanStatus { Pending, Current, ArchivedPriorYear };
        public enum PlanSelectionModes { None, SinglePlan, UnlimitedPlans, FiniteCountPlans }
        public enum ProductSelectionModes { None, SinglePlan, UnlimitedPlans, FiniteCountPlans }


        #region Page Properties
        public bool IsDescriptionHide
        {
            get
            {
                bool HideDescription = false;
                HideDescription = Session[AccessKeys.IsDescriptionHide.ToString()] == null ? false : bool.Parse(Session[AccessKeys.IsDescriptionHide.ToString()].ToString());
                return HideDescription;
            }
            set
            {
                Session[AccessKeys.IsDescriptionHide.ToString()] = value;
            }
        }
        string SessionId
        {
            get
            {
                return Session[AccessKeys.SessionID.ToString()].ToString();
            }
            set
            {
                Session[AccessKeys.SessionID.ToString()] = value;
            }
        }
        public List<string> EducationMaterialTypesStyles
        {
            get
            {
                List<string> lstStyles = new List<string>();
                if (ddlTopic.SelectedValue == "Preventive Care")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Preventive Care & You":
                            lstStyles = new List<string>() { "Original", "Custom Color", "Basic Blue", "Bay View", "Mosaic", "Mountain", "Spring Field", "Spot Light", "Summer Health", "Tabs" };
                            break;
                        case "Preventive Care Basics":
                            lstStyles = new List<string>() { "Original", "Custom Color" };
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "HSA")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Is an HSA Right for You?":
                            lstStyles = new List<string>() { "Original", "Custom Color", "Basic Blue", "Bay View", "Mosaic", "Mountain", "Spring Field", "Spot Light", "Summer Health", "Tabs" };
                            break;
                        case "HSA Eligible Expenses":
                            lstStyles = new List<string>() { "Original", "Custom Color" };
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "Emergency Room")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Wise Use of the Emergency Room":
                            lstStyles = new List<string>() { "Original", "Custom Color" };
                            break;
                        case "Emergency Room vs Urgent Care":
                            lstStyles = new List<string>() { "Original", "Custom Color" };
                            break;
                    }
                }

                return lstStyles;
            }
        }
        public List<string> EducationMaterialTypes
        {
            get
            {
                List<string> lstTypes = new List<string>();
                switch (ddlTopic.SelectedValue)
                {
                    case "Preventive Care":
                        lstTypes = new List<string>() { "Preventive Care & You", "Preventive Care Basics" };
                        break;
                    case "HSA":
                        lstTypes = new List<string>() { "Is an HSA Right for You?", "HSA Eligible Expenses" };
                        break;
                    case "Emergency Room":
                        lstTypes = new List<string>() { "Wise Use of the Emergency Room", "Emergency Room vs Urgent Care" };
                        break;
                }
                return lstTypes;
            }
        }
        public List<string> EducationMaterialColors
        {
            get
            {
                List<string> lstColors = new List<string>();
                switch (ddlStyle.SelectedValue)
                {
                    case "Original":
                        lstColors = new List<string>() { "Grey (Default)", "Custom Color (RGB)", "Black", "USI Blue", "True Blue", "Green", "Dark Green", "Bright Green", "Olive Green", "Red", "Maroon", "Dark Red", "Mustard", "Orange", "Purple", "Light Brown", "Dark Brown" };
                        break;
                    case "Custom Color":
                        lstColors = new List<string>() { "Grey (Default)", "Custom Color (RGB)", "Black", "USI Blue", "True Blue", "Green", "Dark Green", "Bright Green", "Olive Green", "Red", "Maroon", "Dark Red", "Mustard", "Orange", "Purple", "Light Brown", "Dark Brown" };
                        break;

                }
                return lstColors;
            }
        }

        List<int> ApplicablePlanTypes
        {
            get
            {
                List<int> AllPlans = new List<int>();
                AllPlans = EmployeeEducationSummary.LoadAllEmpEducationPlans(ddlTopic.SelectedValue, ddlType.SelectedValue);
                return AllPlans;
            }
        }
        List<int> ApplicableProductTypes
        {
            get
            {
                List<int> AllProducts = new List<int>();
                AllProducts = EmployeeEducationSummary.LoadAllEmpEducationProducts(ddlTopic.SelectedValue, ddlType.SelectedValue);
                return AllProducts;
            }
        }
        List<Plan> AvailablePlans
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailablePlanList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailablePlanList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailablePlanList.ToString()] = value;
            }
        }
        List<Plan> AvailableProducts
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailableProductList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailableProductList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailableProductList.ToString()] = value;
            }
        }
        public bool AccountContactApplicable
        {
            get
            {
                bool AccountContactApplicables = false;
                if (ddlTopic.SelectedValue == "Preventive Care")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Preventive Care & You":
                            AccountContactApplicables = false;
                            break;
                        case "Preventive Care Basics":
                            AccountContactApplicables = false;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "HSA")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Is an HSA Right for You?":
                            AccountContactApplicables = true;
                            break;
                        case "HSA Eligible Expenses":
                            AccountContactApplicables = false;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "Emergency Room")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Wise Use of the Emergency Room":
                            AccountContactApplicables = false;
                            break;
                        case "Emergency Room vs Urgent Care":
                            AccountContactApplicables = false;
                            break;
                    }
                }

                return AccountContactApplicables;
            }
        }
        public bool PlansApplicable
        {
            get
            {
                bool PlansApplicable = false;
                if (ddlTopic.SelectedValue == "Preventive Care")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Preventive Care & You":
                            PlansApplicable = true;
                            break;
                        case "Preventive Care Basics":
                            PlansApplicable = true;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "HSA")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Is an HSA Right for You?":
                            PlansApplicable = true;
                            break;
                        case "HSA Eligible Expenses":
                            PlansApplicable = false;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "Emergency Room")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Wise Use of the Emergency Room":
                            PlansApplicable = false;
                            break;
                        case "Emergency Room vs Urgent Care":
                            PlansApplicable = true;
                            break;
                    }
                }

                return PlansApplicable;
            }
        }
        public bool ProductApplicable
        {
            get
            {
                bool ProductsApplicable = false;
                if (ddlTopic.SelectedValue == "Preventive Care")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Preventive Care & You":
                            ProductsApplicable = false;
                            break;
                        case "Preventive Care Basics":
                            ProductsApplicable = true;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "HSA")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Is an HSA Right for You?":
                            ProductsApplicable = false;
                            break;
                        case "HSA Eligible Expenses":
                            ProductsApplicable = false;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "Emergency Room")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Wise Use of the Emergency Room":
                            ProductsApplicable = false;
                            break;
                        case "Emergency Room vs Urgent Care":
                            ProductsApplicable = false;
                            break;
                    }
                }

                return ProductsApplicable;
            }
        }
        public List<BenefitSummaryStructure> BenefitSummarySelectionMap
        {
            get
            {
                List<BenefitSummaryStructure> AllPlans = new List<BenefitSummaryStructure>();
                AllPlans = EmployeeEducationSummary.GetBenefitSummarySelectionMap(ddlTopic.SelectedValue, ddlType.SelectedValue);
                return AllPlans;
            }
        }
        /// <summary>
        /// Return Selected Plans/Benefit Summarys
        /// </summary>
        List<SummarySelectionViewModel> SelectedPlansBenefitSummary
        {
            get
            {
                List<SummarySelectionViewModel> lstSelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
                lstSelectedPlansBenefitSummary = Session[AccessKeys.SelectedSummaries.ToString()] == null ? lstSelectedPlansBenefitSummary : Session[AccessKeys.SelectedSummaries.ToString()] as List<SummarySelectionViewModel>;
                return lstSelectedPlansBenefitSummary;
            }
            set
            {
                Session[AccessKeys.SelectedSummaries.ToString()] = value;
            }
        }
        #region Plans TypeIds
        List<int> MedicalPlanTypes
        {
            get
            {
                List<int> MedicalPlanTypes = new List<int>();
                MedicalPlanTypes = EmployeeEducationSummary.EmpEducationPlanType_MedicalPlan.Union(EmployeeEducationSummary.EmpEducationPlanType_MedicalRxPlan).ToList();
                return MedicalPlanTypes;
            }
        }
        List<int> DentalPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_Dental;
                return Plans;
            }
        }
        List<int> VisionPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_Vision;
                return Plans;
            }
        }
        List<int> HSAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_HealthSavingAccounts;
                return Plans;
            }
        }
        List<int> HRAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_HealthReimbursementArrangement;
                return Plans;
            }
        }
        List<int> LifeADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_LifeADD;
                return Plans;
            }
        }
        List<int> GroupTermPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_GroupTermLife;
                return Plans;
            }
        }
        List<int> ADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_ADD;
                return Plans;
            }
        }
        List<int> VoluntaryLifePlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_VoluntaryLife;
                return Plans;
            }
        }
        List<int> VoluntaryADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_VoluntaryADD;
                return Plans;
            }
        }
        List<int> STDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_ShortTermDisability;
                return Plans;
            }
        }
        List<int> LTDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_LongTermDisablity;
                return Plans;
            }
        }
        List<int> EAPPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_EmployeeAssistanceProgram;
                return Plans;
            }
        }
        List<int> FSAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_FlexibleSpendingAccount;
                return Plans;
            }
        }
        List<int> WellnessPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_Wellness;
                return Plans;
            }
        }
        List<int> PlnaTypes401K
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_401K;
                return Plans;
            }
        }
        List<int> StopLossPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_StopLoss;
                return Plans;
            }
        }
        List<int> InternationalBundledPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_InternationalBundledsPlan_3_Tier;
                return Plans;
            }
        }
        List<int> BTAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = EmployeeEducationSummary.EmpEducationPlanType_BussinessTravelAccident;
                return Plans;
            }
        }
        #endregion

        public PlanSelectionModes TopicTypePlanSelectionMode
        {
            get
            {
                PlanSelectionModes mode = PlanSelectionModes.None;
                if (ddlTopic.SelectedValue == "Preventive Care")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Preventive Care & You":
                            mode = PlanSelectionModes.SinglePlan;
                            break;
                        case "Preventive Care Basics":
                            mode = PlanSelectionModes.SinglePlan;
                            break;

                    }
                }
                if (ddlTopic.SelectedValue == "HSA")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Is an HSA Right for You?":
                            mode = PlanSelectionModes.SinglePlan;
                            break;
                        case "HSA Eligible Expenses":
                            mode = PlanSelectionModes.None;
                            break;
                    }
                }
                if (ddlTopic.SelectedValue == "Emergency Room")
                {
                    switch (ddlType.SelectedValue)
                    {
                        case "Wise Use of the Emergency Room":
                            mode = PlanSelectionModes.None;
                            break;
                        case "Emergency Room vs Urgent Care":
                            mode = PlanSelectionModes.SinglePlan;
                            break;
                    }
                }
                return mode;
            }
        }
        #endregion

        #region UI Events
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                IsDescriptionHide = true;
                mvMainContainer.ActiveViewIndex = 0;
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                objCommFun.GetUserDetails();
                Activity_Group = "Analytics";
                Activity = TitleSpan.InnerText;
                Session[AccessKeys.DeliverableCategory.ToString()] = "Analytics";
                ddlTopic_SelectedIndexChanged(null, null);
                trColorOption.Style.Add("display", "none");
                trRGBcolor.Style.Add("display", "none");
                ShowHideDescriptionPanel();
            }
        }
        protected void ddlTopic_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlType.Items.Clear();
            ddlType.Visible = false;
            lblTypeLabel.Visible = false;

            List<string> lstTypes = EducationMaterialTypes;
            ddlType.DataSource = lstTypes;
            ddlType.DataBind();
            ddlType.Items.Insert(0, new ListItem("Select", "Select"));

            if (lstTypes.Count == 1)
                ddlType.SelectedValue = lstTypes[0];

            if (ddlTopic.SelectedValue != "Select")
            {
                ddlType.Visible = true;
                lblTypeLabel.Visible = true;
            }
            ddlType_SelectedIndexChanged(null, null);
        }
        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlStyle.Visible = false;
            lblStyle.Visible = false;

            ddlStyle.Items.Clear();
            ddlStyle.DataSource = EducationMaterialTypesStyles;
            ddlStyle.DataBind();
            ddlStyle.Items.Insert(0, new ListItem("Select", "Select"));

            if (EducationMaterialTypesStyles.Count == 1)
                ddlStyle.SelectedValue = EducationMaterialTypesStyles[0];

            if (ddlType.SelectedValue != "Select")
            {
                if (EducationMaterialTypesStyles.Count > 1)
                {
                    ddlStyle.SelectedValue = "Original";
                    ddlStyle.Visible = true;
                    lblStyle.Visible = true;
                }
            }

            if (PlansApplicable)
                tblPlanProductCriteria.Style.Add("display", "");
            else
                tblPlanProductCriteria.Style.Add("display", "none");


            if (ProductApplicable)
                trProductContainer.Style.Add("display", "");
            else
                trProductContainer.Style.Add("display", "none");


            ClearPlanGrid();
            ClearProductGrid();
            rdlPlanStatus.SelectedValue = PlanStatus.Current.ToString();
            if (AccountContactApplicable == true)
            {
                trAccountContact.Style.Add("display", "");
                BindAccountContact();
            }
            else
            {
                trAccountContact.Style.Add("display", "none");
            }

            ddlStyle_SelectedIndexChanged(null, null);
        }
        protected void ddlStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlColor.Items.Clear();
            ddlColor.DataSource = EducationMaterialColors;
            ddlColor.DataBind();

            ddlColor.SelectedValue = "Grey (Default)";

            if (ddlStyle.SelectedValue == "Select")
            {
                IsDescriptionHide = true;
                lblDescription.Text = string.Empty;
            }
            else
            {
                lblDescription.Text = "Description for " + ddlStyle.SelectedItem.Text;
            }
            if (ddlStyle.SelectedValue == "Custom Color")
            {
                trColorOption.Style.Add("display", "");
                ddlColor.SelectedValue = EducationMaterialColors[0];
            }
            else if (ddlStyle.SelectedValue == "Original")
            {
                trColorOption.Style.Add("display", "none");
            }
            else
            {
                trColorOption.Style.Add("display", "none");
            }
            ddlColor_SelectedIndexChanged(null, null);
            ShowHideDescriptionPanel();
        }
        protected void ddlColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtR.Text = string.Empty;
            txtG.Text = string.Empty;
            txtB.Text = string.Empty;
            if (ddlColor.SelectedValue == "Custom Color (RGB)")
                trRGBcolor.Style.Add("display", "");
            else
                trRGBcolor.Style.Add("display", "none");

        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
            ClearProductGrid();
            rdlPlanStatus.SelectedValue = PlanStatus.Current.ToString();
            BindAccountContact();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return;
            }
            LoadPlansAndProducts();

        }
        protected void rdlPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
            ClearProductGrid();
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (ValidateCriteriaPage())
            {
                AddSelctedPlanBenefitSummaryToSessions();
                bool success = ValidateBenefitSummarySelection();
                if (!success)
                    return;

                if (PlansApplicable)
                {
                    sd.BuildBenefitSummaryTable();
                    DataTable dtblSelectedSummaries = CreateBenfitDsParameterTable();
                    BenefitDS = sd.GetBenefitSummary_V2(dtblSelectedSummaries, SessionId);
                }

                switch (ddlTopic.SelectedValue)
                {
                    case "Preventive Care":
                        ProcessPreventiceCareType();
                        break;
                    case "HSA":
                        ProcessHSAType();
                        break;
                    case "Emergency Room":
                        ProcessEmergencyType();
                        break;
                    default:
                        break;
                }

            }
        }

        protected void chkPlanHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }
        protected void chkProductHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdProducts.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdProducts');</script>", false);
        }
        protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.Header)
            {
                CheckBox chkPlanHeaderSelect = e.Row.FindControl("chkPlanHeaderSelect") as CheckBox;
                if (TopicTypePlanSelectionMode == PlanSelectionModes.SinglePlan)
                {
                    chkPlanHeaderSelect.Visible = false;
                    chkPlanHeaderSelect.Checked = false;


                }
                else if (TopicTypePlanSelectionMode == PlanSelectionModes.UnlimitedPlans)
                {
                    chkPlanHeaderSelect.Visible = true;
                    chkPlanHeaderSelect.Checked = true;

                }
                else if (TopicTypePlanSelectionMode == PlanSelectionModes.FiniteCountPlans)
                {
                    chkPlanHeaderSelect.Visible = true;
                    chkPlanHeaderSelect.Checked = false;
                }
            }
            else
            {
                CheckBox chkItemSelect = e.Row.FindControl("chkItemSelect") as CheckBox;
                RadioButton rdoItemSelect = e.Row.FindControl("rdoItemSelect") as RadioButton;
                if (chkItemSelect != null && rdoItemSelect != null)
                {
                    if (TopicTypePlanSelectionMode == PlanSelectionModes.SinglePlan)
                    {

                        chkItemSelect.Visible = false;
                        rdoItemSelect.Visible = true;
                        rdoItemSelect.GroupName = "grpPlan";

                    }
                    else if (TopicTypePlanSelectionMode == PlanSelectionModes.UnlimitedPlans)
                    {

                        chkItemSelect.Visible = true;
                        chkItemSelect.Checked = true;
                        rdoItemSelect.Visible = false;
                    }
                    else if (TopicTypePlanSelectionMode == PlanSelectionModes.FiniteCountPlans)
                    {
                        chkItemSelect.Visible = true;
                        rdoItemSelect.Visible = false;
                    }
                }
            }
        }
        protected void rdoItemSelect_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            GridViewRow selectedRow = (GridViewRow)rb.NamingContainer;
            ((RadioButton)selectedRow.FindControl("rdoItemSelect")).Checked = rb.Checked;
            foreach (GridViewRow row in grdPlans.Rows)
            {
                if (selectedRow.RowIndex != row.RowIndex)
                    ((RadioButton)row.FindControl("rdoItemSelect")).Checked = false;
            }

            //Set the new selected row


        }
        #endregion

        #region Functions
        private void BindAccountContact()
        {
            ddlAccountContact.Items.Clear();
            if (AccountContactApplicable)
            {
                if (ddlClient.SelectedIndex > 0)
                {
                    List<Contact> ContactList = new List<Contact>();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                    Session["Contact"] = ContactList;
                    ddlAccountContact.DataSource = ContactList;
                    ddlAccountContact.DataBind();
                    ddlAccountContact.Items.Insert(0, new ListItem("Select", string.Empty));
                    ddlAccountContact.Items.Insert(1, new ListItem("None", "-1"));
                }
            }
        }
        private void ClearPlanGrid()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            trPlanContainer.Style.Add("display", "none");
            tblEmptyPlanTemplate.Style.Add("display", "none");
            grdPlans.Style.Add("display", "none");
        }
        private void ClearProductGrid()
        {
            grdProducts.DataSource = null;
            grdProducts.DataBind();
            trProductContainer.Style.Add("display", "none");
            tblEmptyProductTemplate.Style.Add("display", "none");
            grdProducts.Style.Add("display", "none");
        }
        private void ResetForm()
        {
            ddlTopic.SelectedValue = "Select";
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Add(new ListItem("Select", ""));
            rdlClient.SelectedIndex = 0;

            ddlTopic_SelectedIndexChanged(null, null);
            ddlClient_SelectedIndexChanged(null, null);
            IsDescriptionHide = true;
            ShowHideDescriptionPanel();
        }
        private void LoadPlansAndProducts()
        {
            List<Plan> PlanList = new List<Plan>();
            PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            LoadPlans(PlanList);
            LoadProducts(PlanList);
        }
        private void LoadPlans(List<Plan> PlanList)
        {
            ClearPlanGrid();
            if (ApplicablePlanTypes.Count == 0)
                return;
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;
                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (MedicalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.MedicalLOC;
                        }
                        if (DentalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.DentalLOC;
                        }
                        if (VisionPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VisionLOC;
                        }
                        if (HSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HSALOC;
                        }
                        if (HRAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HRALOC;
                        }
                        if (LifeADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LifeADDLOC;
                        }
                        if (GroupTermPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                        }
                        if (ADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.ADNDPlanType_CommonCriteria;
                        }
                        if (VoluntaryLifePlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VoluntaryLife;
                        }
                        if (VoluntaryADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                        }
                        if (STDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.STDLOC;
                        }
                        if (LTDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LTDLOC;
                        }
                        if (EAPPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.EAPLOC;
                        }
                        if (FSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.FSAPlanType;
                        }
                        if (WellnessPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Wellness;
                        }
                        if (StopLossPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.StopLoss;
                        }

                        if (PlnaTypes401K.Contains(item.ProductTypeId))
                        {
                            item.LOC = "401K";
                        }
                        if (BTAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = "BTA";
                        }

                        if (CanAdd)
                            FilteredPlanList.Add(item);

                    }
                }
            }


            FilteredPlanList = SortPlans(FilteredPlanList);
            grdPlans.DataSource = FilteredPlanList;
            grdPlans.DataBind();

            trPlanContainer.Style.Add("display", "");

            if (FilteredPlanList.Count > 0)
            {
                //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                grdPlans.Style.Add("display", "");
            }
            else
            {
                tblEmptyPlanTemplate.Style.Add("display", "");
            }

            AvailablePlans = FilteredPlanList;
        }
        private void LoadProducts(List<Plan> PlanList)
        {
            ClearProductGrid();
            if (ApplicableProductTypes.Count == 0)
                return;
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;
                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        item.SummaryID = 0;
                        item.SummaryName = string.Empty;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (CanAdd)
                            FilteredPlanList.Add(item);
                    }
                }
            }
            FilteredPlanList = (from l in FilteredPlanList
                                orderby l.ProductTypeId ascending
                                select l).ToList();

            grdProducts.DataSource = FilteredPlanList;
            grdProducts.DataBind();

            trProductContainer.Style.Add("display", "");
            if (FilteredPlanList.Count > 0)
            {
                // ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdProducts');</script>", false);
                grdProducts.Style.Add("display", "");
            }
            else
            {
                tblEmptyProductTemplate.Style.Add("display", "");
            }

            AvailableProducts = FilteredPlanList;
        }
        private bool ValidateBenefitSummarySelection()
        {
            string DescriptionBoxScipt = "";
            if (BenefitSummarySelectionMap.Count == 0)
                return true;
            else
            {
                if (SelectedPlansBenefitSummary.Count == 0)
                {
                    //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select atleast one Benefit Summary.');" + DescriptionBoxScipt + "</script>");
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select at least one Benefit Summary.');" + DescriptionBoxScipt + "</script>");
                    return false;
                }
                foreach (BenefitSummaryStructure item in BenefitSummarySelectionMap)
                {
                    int count = 0;

                    if (item.LOC == cv.LifeADDLOC)
                        count = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).Count();
                    else if (item.LOC == cv.VoluntaryLifeADDLOC)
                        count = SelectedPlansBenefitSummary.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).Count();
                    else
                        count = SelectedPlansBenefitSummary.Where(r => r.LOC == item.LOC).Count();

                    if (count > item.MaxBenefitSummary)
                    {

                        string ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " " + item.LOC + " " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". If you wish to select another benefit summary, you will need to uncheck an existing " + item.LOC + " summary election";
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('" + ErrorMessage + "');" + DescriptionBoxScipt + "</script>");
                        return false;
                    }
                }
            }

            return true;

        }
        private void AddSelctedPlanBenefitSummaryToSessions()
        {
            ConstantValue cv = new ConstantValue();
            List<SummarySelectionViewModel> lstSelectedSummaries = new List<SummarySelectionViewModel>();
            SelectedPlansBenefitSummary = lstSelectedSummaries;
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();
                System.Web.UI.WebControls.CheckBox rdoItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        bool IsPlanSelected = false;
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        rdoItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("rdoItemSelect"));
                        if (TopicTypePlanSelectionMode == PlanSelectionModes.SinglePlan)
                        {
                            if (rdoItemSelect.Checked == true)
                                IsPlanSelected = true;
                        }
                        if (TopicTypePlanSelectionMode == PlanSelectionModes.FiniteCountPlans || TopicTypePlanSelectionMode == PlanSelectionModes.UnlimitedPlans)
                        {
                            if (chkItemSelect.Checked == true)
                                IsPlanSelected = true;
                        }

                        if (IsPlanSelected)
                        {
                            SummarySelectionViewModel BenefitSummaryItem = new SummarySelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                BenefitSummaryItem.SummaryName = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryName = string.Empty;
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 the 'You are not authorized to access the requesn it gives an errorted information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                                }
                                else
                                {
                                    BenefitSummaryItem.ProductTypeId = 0;
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                BenefitSummaryItem.SummaryId = int.Parse((grRow.Cells[9].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryId = 0;
                            }

                            if (MedicalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MedicalLOC;
                            }
                            if (DentalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.DentalLOC;
                            }
                            if (VisionPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VisionLOC;
                            }
                            if (LifeADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LifeADDLOC;
                            }
                            if (GroupTermPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                            }
                            if (ADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.ADNDPlanType_CommonCriteria;
                            }
                            if (VoluntaryLifePlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VoluntaryLife;
                            }
                            if (VoluntaryADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                            }
                            if (LTDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LTDLOC;
                            }

                            if (STDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.STDLOC;
                            }

                            if (EAPPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.EAPLOC;
                            }

                            if (FSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FSAPlanType;
                            }
                            if (HSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HSALOC;
                            }
                            if (HRAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HRALOC;
                            }
                            if (StopLossPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.StopLoss;
                            }
                            if (WellnessPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Wellness;
                            }
                            if (PlnaTypes401K.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "401K";
                            }
                            if (BTAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "BTA";
                            }
                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }
                    }//Foreach Close
                    SelectedPlansBenefitSummary = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private List<Plan> SortPlans(List<Plan> lstPlans)
        {
            List<Plan> lstSortedPlan = new List<Plan>();
            foreach (BenefitSummaryStructure item in BenefitSummarySelectionMap)
            {
                List<Plan> lstLOCPlans = new List<Plan>();
                List<BenefitSummaryDropDownViewModel> lstSummaryDataSource = new List<BenefitSummaryDropDownViewModel>();
                if (item.LOC == cv.LifeADDLOC)
                {

                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                }
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                }
                else
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == item.LOC).ToList();
                }
                lstLOCPlans = (from l in lstLOCPlans
                               orderby l.ProductTypeDescription, l.SummaryName, l.CarrierName, l.RenewalDate ascending
                               select l).ToList();

                lstSortedPlan.AddRange(lstLOCPlans);

            }
            return lstSortedPlan;

        }
        private bool ValidateCriteriaPage()
        {
            string DescriptionBoxScipt = "";

            if (ddlTopic.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Topic.');" + DescriptionBoxScipt + "</script>");
                ddlTopic.Focus();
                return false;
            }
            if (ddlType.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type.');" + DescriptionBoxScipt + "</script>");
                ddlType.Focus();
                return false;
            }
            if (ddlStyle.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Style.');" + DescriptionBoxScipt + "</script>");
                ddlStyle.Focus();
                return false;
            }
            if (ddlStyle.SelectedValue == "Custom Color")
            {
                if (ddlColor.SelectedValue == "Custom Color (RGB)")
                {
                    if (txtR.Text.Trim() == string.Empty)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter value for Red color.');" + DescriptionBoxScipt + "</script>");
                        txtR.Focus();
                        return false;
                    }
                    if (int.Parse(txtR.Text.Trim()) < 0 || int.Parse(txtR.Text.Trim()) > 255)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid value for Red color. Range should be 0-255');" + DescriptionBoxScipt + "</script>");
                        txtR.Focus();
                        return false;
                    }

                    if (txtG.Text.Trim() == string.Empty)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter value for Green color.');" + DescriptionBoxScipt + "</script>");
                        txtG.Focus();
                        return false;
                    }
                    if (int.Parse(txtG.Text.Trim()) < 0 || int.Parse(txtG.Text.Trim()) > 255)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid value for Green color. Range should be 0-255');" + DescriptionBoxScipt + "</script>");
                        txtG.Focus();
                        return false;
                    }
                    if (txtB.Text.Trim() == string.Empty)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter value for Blue color.');" + DescriptionBoxScipt + "</script>");
                        txtB.Focus();
                        return false;
                    }
                    if (int.Parse(txtB.Text.Trim()) < 0 || int.Parse(txtB.Text.Trim()) > 255)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid value for Blue color. Range should be 0-255');" + DescriptionBoxScipt + "</script>");
                        txtB.Focus();
                        return false;
                    }
                }
            }
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.');" + DescriptionBoxScipt + "</script>");
                ddlClient.Focus();
                return false;
            }
            if (AccountContactApplicable)
            {
                if (ddlAccountContact.SelectedIndex == 0 || ddlAccountContact.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Account Contact.');" + DescriptionBoxScipt + "</script>");
                    ddlAccountContact.Focus();
                    return false;
                }
            }
            return true;
        }
        #endregion
        protected void DownloadFile(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void btnDescriptionHeader_Click(object sender, EventArgs e)
        {
            IsDescriptionHide = !IsDescriptionHide;
            ShowHideDescriptionPanel();
        }
        private void ShowHideDescriptionPanel()
        {
            if (IsDescriptionHide)
            {
                trDescriptionBox.Style.Add("display", "none");
                btnDescriptionHeader.Text = "Guide >>";
            }
            else
            {
                trDescriptionBox.Style.Add("display", "");
                btnDescriptionHeader.Text = "Guide <<";
            }
        }
        private DataTable CreateBenfitDsParameterTable()
        {
            DataTable dlSummaryTable = new DataTable();
            dlSummaryTable.Columns.Add(new DataColumn("PlanType"));
            dlSummaryTable.Columns.Add(new DataColumn("SummaryId"));

            foreach (SummarySelectionViewModel summary in SelectedPlansBenefitSummary)
            {
                DataRow dr = dlSummaryTable.NewRow();
                dr["PlanType"] = summary.ProductTypeDescription;
                dr["SummaryId"] = summary.SummaryId;
                dlSummaryTable.Rows.Add(dr);
            }
            return dlSummaryTable;
        }

        public void ProcessPreventiceCareType()
        {
            switch (ddlType.SelectedValue)
            {
                case "Preventive Care & You":
                    PrventiveCare_PreventiveCareAndYou();
                    break;
                case "Preventive Care Basics":
                    PreventiveCare_PreventiveCareBasics();
                    break;

                default:
                    break;
            }
        }
        public void ProcessHSAType()
        {
            switch (ddlType.SelectedValue)
            {
                case "Is an HSA Right for You?":
                    HSA_IsanHSARightforYou();
                    break;
                case "HSA Eligible Expenses":
                    HSA_EligibleExpenses();
                    break;
                default:
                    break;
            }
        }
        public void ProcessEmergencyType()
        {
            switch (ddlType.SelectedValue)
            {
                case "Wise Use of the Emergency Room":
                    Emergency_WiseEmergencyRoom();
                    break;
                case "Emergency Room vs Urgent Care":
                    Emergency_UrgentCare();
                    break;
                default:
                    break;
            }
        }

        public void PrventiveCare_PreventiveCareAndYou()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;

            dictFieldsValue.Clear();

            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            dictFieldsValue["<<ClientName>>"] = ddlClient.SelectedItem.Text;
            dictFieldsValue["<<carriername>>"] = SelectedPlansBenefitSummary.First().CarrierName;
            dictFieldsValue["<<MedicalPlanType>>"] = SelectedPlansBenefitSummary.First().ProductTypeDescription;

            int SummeryId = SelectedPlansBenefitSummary.First().SummaryId;

            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;

                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }

                    break;
                case "Basic Blue":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-BasicBlue.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Bay View":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-BayView.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Mosaic":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-Mosaic.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Mountain":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-Mountain.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Spring Field":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-SpringField.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Spot Light":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-SpotLight.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Summer Health":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-SummerHealth.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Tabs":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareandYou-Tabs.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
            }

            EmpEducational.WriteFilePreventiveCareAndYou(BenefitDS, dictFieldsValue, SummeryId, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);
        }
        public void PreventiveCare_PreventiveCareBasics()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;

            dictFieldsValue.Clear();

            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            dictFieldsValue["<<ClientName>>"] = ddlClient.SelectedItem.Text;
            dictFieldsValue["<<carriername>>"] = SelectedPlansBenefitSummary.First().CarrierName;
            dictFieldsValue["<<MedicalPlanType>>"] = SelectedPlansBenefitSummary.First().ProductTypeDescription;

            int SummeryId = SelectedPlansBenefitSummary.First().SummaryId;

            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareBasics-Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;

                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/PreventiveCareBasics-Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }

                    break;
            }

            EmpEducational.WriteFilePreventiveCareBasics(BenefitDS, dictFieldsValue, SummeryId, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);
        }
        public void HSA_IsanHSARightforYou()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;
            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            Dictionary<string, string> dictMergeFieldsValue = new Dictionary<string, string>();

            //dictFieldsValue["<<ClientName>>"] = ddlClient.SelectedItem.Text;
            //dictFieldsValue["<<HSACarrier>>"] = SelectedPlansBenefitSummary.First().CarrierName;
            dictFieldsValue["<<Client Name>>"] = ddlClient.SelectedItem.Text;
            dictFieldsValue["<<HSA Carrier>>"] = SelectedPlansBenefitSummary.First().CarrierName;
            dictFieldsValue["<<PlanType>>"] = SelectedPlansBenefitSummary.First().ProductTypeDescription;
            dictFieldsValue["<<BenefitSummaryName>>"] = SelectedPlansBenefitSummary.First().SummaryName;

            int SummaryId = SelectedPlansBenefitSummary.First().SummaryId;
            List<Contact> ContactList = new List<Contact>();
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
            ArrayList arrAcctContact = new ArrayList();
            arrAcctContact.Add(ddlAccountContact.SelectedValue);
            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }
                    break;
                case "Basic Blue":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_BasicBlue.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Bay View":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_BayView.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Mosaic":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Mosaic.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Mountain":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Mountain.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Spring Field":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_SpringField.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Spot Light":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Spotlight.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Summer Health":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_SummerHealth.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Tabs":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSA_Tabs.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
            }
            EmpEducational.WriteFileHSA_IsanHSARightforYou(SummaryId, dictFieldsValue, BenefitDS, ContactList, arrAcctContact, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);

        }
        public void HSA_EligibleExpenses()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;
            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            Dictionary<string, string> dictMergeFieldsValue = new Dictionary<string, string>();
            dictFieldsValue["<<ClientName>>"] = ddlClient.SelectedItem.Text;
            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSAEligibleExpenses-Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/HSAEligibleExpenses-Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }
                    break;
            }
            EmpEducational.WriteFileHSAEligibleExpenses(dictFieldsValue, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);
        }

        public void Emergency_WiseEmergencyRoom()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;
            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/WiseUseofER-Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/WiseUseofER-Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }
                    break;
            }
            EmpEducational.WriteFileWiseEmergencyRoom(dictFieldsValue, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);
        }

        public void Emergency_UrgentCare()
        {
            string TemplatePath = string.Empty;
            string DownloadFilePath = string.Empty;
            string color = string.Empty;
            int R = 0;
            int G = 0;
            int B = 0;
            DownloadFilePath = Server.MapPath("~/Files/EmployeeEducationMaterials/download");
            dictFieldsValue["<<ClientName>>"] = ddlClient.SelectedItem.Text;
            dictFieldsValue["<<carriername>>"] = SelectedPlansBenefitSummary.First().CarrierName;
            dictFieldsValue["<<MedicalPlanType>>"] = SelectedPlansBenefitSummary.First().ProductTypeDescription;
            int SummeryId = SelectedPlansBenefitSummary.First().SummaryId;
            switch (ddlStyle.SelectedValue)
            {
                case "Original":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/ERvsUrgentCare-Original.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    break;
                case "Custom Color":
                    TemplatePath = Server.MapPath("~/Files/EmployeeEducationMaterials/Templates/ERvsUrgentCare-Custom.docx");
                    dictFieldsValue["TemplatePath"] = TemplatePath;
                    dictFieldsValue["DownloadFilePath"] = DownloadFilePath;
                    color = ddlColor.SelectedValue;
                    if (ddlColor.SelectedValue == "Custom Color (RGB)")
                    {
                        R = int.Parse(txtR.Text);
                        G = int.Parse(txtG.Text);
                        B = int.Parse(txtB.Text);
                    }
                    break;
            }
            EmpEducational.WriteFileEmergencyUrgentCare(BenefitDS, dictFieldsValue, SummeryId, color, R, G, B);
            DownloadFile(EmpEducational.DownloadFilePath);
        }
    }
}