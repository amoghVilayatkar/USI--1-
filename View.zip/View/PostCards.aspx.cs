﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.Collections;
using BenefitPointSummaryPortal.BAL.PostCards;
namespace BenefitPointSummaryPortal.View
{
    public partial class PostCards : System.Web.UI.Page
    {
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        Dictionary<string, string> DictDiscriptionType = new Dictionary<string, string>();
        public void BuiltDictDiscriptionType() 
        {
            DictDiscriptionType.Add("PostCardsBasicBlue", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsBayView", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsMosaic", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsMountain", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsSpotLight", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsSpringField", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsSummerHealth", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("PostCardsTabs", "Remind employees of their upcoming open enrollment with this style post card. Designs match other open enrollment deliverables in the Hub, so you can easily create a cohesive communications package.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
            DictDiscriptionType.Add("Wellness", "Provide an overview of a wellness program, highlight incentives or remind employees of a wellness deadline using this post card.\n\nPost Card Template used:\nMicrosoft 1/2 Letter Postcard\nHeight: 5.5 \nWidth: 8.5 \nPage size 8.5x11");
           }
        protected void Page_Load(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                mvPostCards.ActiveViewIndex = 0;
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                Session["SessionId"] = SessionId;
                objCommFun.GetUserDetails();
                Activity_Group = "PostCards";
                Activity = TitleSpan.InnerText;
                Session["DeliverableCategory"] = "PostCards";
                txtLetterDecription.Text = "";
                txtsearch.Focus();
               
                ddlPostcardType_SelectedIndexChanged(null, null);
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
                ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                if (ValidateForm())
                {
                    CreatePostCardsReport();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void CreatePostCardsReport()
        {
            try
            {
                if (ddlPostCardType.SelectedValue == "OpenEnrollment")
                    Create_OpenEnrollmentReport();
                if (ddlPostCardType.SelectedValue == "Wellness")
                    Create_WellnessReport();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        private void Create_WellnessReport()
        {
            try
            {
                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
                string mynewfile = "";
                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);




                if (ddlPostCardType.SelectedValue == "Wellness")
                {
                    mynewfile = CreateTemplate_PostCardsWellness(AccountDS, ContactList);
                }

                #region ------- Code for Add Activity Log --------


                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                string AdditionalCrtieriaOption_1 = ddlPostCardType.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DictDepartment = sd.getDepartmentDetails();
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                if (mynewfile != "")
                {
                    DownloadFileNew(mynewfile);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void Create_OpenEnrollmentReport()
        {
            try
            {
                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
                string mynewfile = "";
                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);



                if (ddlSummaryStyle.SelectedValue == "PostCardsBasicBlue")
                {
                    mynewfile = CreateTemplate_PostCardsBasicBlue(AccountDS, ContactList);
                }

                if (ddlSummaryStyle.SelectedValue == "PostCardsMosaic")
                  {
                     mynewfile = CreateTemplate_PostCardsMosaic(AccountDS, ContactList);
                  }
               
                if (ddlSummaryStyle.SelectedValue == "PostCardsMountain")
                   {
                       mynewfile = CreateTemplate_PostCardsMountain(AccountDS, ContactList);
                   }

                if (ddlSummaryStyle.SelectedValue == "PostCardsBayView")
                    {
                      mynewfile = CreateTemplate_PostCardsBayView(AccountDS, ContactList);
                    }

                if (ddlSummaryStyle.SelectedValue == "PostCardsSpotLight")
                    {
                        mynewfile = CreateTemplate_PostCardsSpotLight(AccountDS, ContactList);
                    }
                
                if (ddlSummaryStyle.SelectedValue == "PostCardsSpringField")
                    {
                        mynewfile = CreateTemplate_PostCardsSpringField(AccountDS, ContactList);
                    }
                if (ddlSummaryStyle.SelectedValue == "PostCardsSummerHealth")
                    {
                        mynewfile = CreateTemplate_PostCardsSummerHealth(AccountDS, ContactList);
                    }

                if (ddlSummaryStyle.SelectedValue == "PostCardsTabs")
                {
                    mynewfile = CreateTemplate_PostCardsTab(AccountDS, ContactList);
                }
                
                #region ------- Code for Add Activity Log --------


                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                string AdditionalCrtieriaOption_1 = ddlPostCardType.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DictDepartment = sd.getDepartmentDetails();
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                if (mynewfile != "")
                {
                    DownloadFileNew(mynewfile);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private bool ValidateForm()
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return false;
            }
            if (ddlHRContact.SelectedIndex == 0 || ddlHRContact.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select HR Contact.')</script>");
                ddlHRContact.Focus();
                return false;
            }
            if (ddlPostCardType.SelectedIndex == 0 || ddlPostCardType.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type of Post Card.')</script>");
                ddlPostCardType.Focus();
                return false;
            }
            if ((ddlSummaryStyle.SelectedIndex == 0 || ddlSummaryStyle.SelectedIndex == -1) && ddlPostCardType.SelectedValue == "OpenEnrollment")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Style.')</script>");
                ddlSummaryStyle.Focus();
                return false;
            }
            
            return true;

        }
        private void ResetForm()
        {
            rdlClient.SelectedIndex = 0;
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlHRContact.Items.Clear();
            ddlSummaryStyle.SelectedIndex = 0;
            ddlPostCardType.SelectedIndex = 0;
            ddlPostcardType_SelectedIndexChanged(null, null);
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Contact> ContactList = new List<Contact>();
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedItem.Text != "Select" && ddlClient.SelectedItem.Text.Trim() != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                }

                Session["Contact"] = ContactList;
                ddlHRContact.DataSource = ContactList;
                ddlHRContact.DataBind();

                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));
                ddlSummaryStyle.SelectedIndex = 0;
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlPostcardType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BuiltDictDiscriptionType();
            tdSummaryStyleLabel.Style.Add("display","none");
            tdSummaryStyleDropDown.Style.Add("display", "none");
            tdDescription.Style.Add("display", "none");
            ddlSummaryStyle.SelectedValue = "0";
            string SelectedPostCardType = ddlPostCardType.SelectedValue;
            switch (SelectedPostCardType)
            {
                case "OpenEnrollment":
                    tdSummaryStyleLabel.Style.Add("display", "");
                    tdSummaryStyleDropDown.Style.Add("display", "");
                    break;
                case "Wellness":
                    tdDescription.Style.Add("display", "");
                    txtLetterDecription.Text = DictDiscriptionType[ddlPostCardType.SelectedValue];
                    break;
            }
        }
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public string CreateTemplate_PostCardsWellness(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCards_Wellness.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_Wellness wr = new WriteTemplate_PostCards_Wellness();
                wr.Write_PostCards_Wellness_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }
        public string CreateTemplate_PostCardsBasicBlue(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_BasicBlue.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_BasicBlue wr = new WriteTemplate_PostCards_BasicBlue();
                wr.Write_PostCards_BasicBlue_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }
        public string CreateTemplate_PostCardsBayView(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_BayView.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_BayView wr = new WriteTemplate_PostCards_BayView();
                wr.Write_PostCards_BayView_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }
        public string CreateTemplate_PostCardsMosaic(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_Mosaic.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_Mosaic wr = new WriteTemplate_PostCards_Mosaic();
                wr.Write_PostCards_Mosaic_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }
        public string CreateTemplate_PostCardsSpotLight(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_SpotLight.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_SpotLight wr = new WriteTemplate_PostCards_SpotLight();
                wr.Write_PostCards_SpotLight_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }

        public string CreateTemplate_PostCardsMountain(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_Mountain.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_Mountain wr = new WriteTemplate_PostCards_Mountain();
                wr.Write_PostCards_Mountain_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }

         public string CreateTemplate_PostCardsSpringField(DataSet AccountDS, List<Contact> Contactlist)
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                }
                string filename = "~/Files/PostCards/Documents/Templates/PostCard_Springfield.docm";
                string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlHRContact.SelectedValue);
                WriteTemplate_PostCards_SpringField wr = new WriteTemplate_PostCards_SpringField();
                wr.Write_PostCards_SpringField_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return (wobj.Save_File); ;
        }
         public string CreateTemplate_PostCardsSummerHealth(DataSet AccountDS, List<Contact> Contactlist)
         {
             Object missing = System.Reflection.Missing.Value;
             try
             {
                 if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                 {
                     Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                 }
                 string filename = "~/Files/PostCards/Documents/Templates/PostCard_SummerHealth.docm";
                 string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                 wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                 ArrayList arrAcctContact = new ArrayList();
                 arrAcctContact.Add(ddlHRContact.SelectedValue);
                 WriteTemplate_PostCards_SummerHealth wr = new WriteTemplate_PostCards_SummerHealth();
                 wr.Write_PostCards_SummerHealth_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                 wobj.office.oWordDoc.Save();
                 wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
             }
             catch (Exception Ex)
             {
                 throw Ex;
             }
             return (wobj.Save_File); ;
         }

         public string CreateTemplate_PostCardsTab(DataSet AccountDS, List<Contact> Contactlist)
         {
             Object missing = System.Reflection.Missing.Value;
             try
             {
                 if (!Directory.Exists(Server.MapPath("~/Files/PostCards/Documents/Templates/Download")))
                 {
                     Directory.CreateDirectory(Server.MapPath("~/Files/PostCards/Documents/Templates/Download"));
                 }
                 string filename = "~/Files/PostCards/Documents/Templates/PostCard_Tabs.docm";
                 string _savefilename = "~/Files/PostCards/Documents/Templates/Download/NewDocument";
                 wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                 ArrayList arrAcctContact = new ArrayList();
                 arrAcctContact.Add(ddlHRContact.SelectedValue);
                 WriteTemplate_PostCards_Tabs wr = new WriteTemplate_PostCards_Tabs();
                 wr.Write_PostCards_Tabs_Fields(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, AccountDS, Contactlist, arrAcctContact);
                 wobj.office.oWordDoc.Save();
                 wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
             }
             catch (Exception Ex)
             {
                 throw Ex;
             }
             return (wobj.Save_File); ;
         }
        protected void ddlSummaryStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            tdDescription.Style.Add("display", "none");
            BuiltDictDiscriptionType();
            if (DictDiscriptionType.ContainsKey(ddlSummaryStyle.SelectedValue.ToString()))
            {
                tdDescription.Style.Add("display", "");
                txtLetterDecription.Text = DictDiscriptionType[ddlSummaryStyle.SelectedValue.ToString()];
            }
        }
    }
}