﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.Common.ClientUserControl;
using System.ComponentModel;
using System.Data;
using BenefitPointSummaryPortal.BAL.ClientServiceUtility;

namespace BenefitPointSummaryPortal.View
{
    public partial class ucClientControl : System.Web.UI.UserControl
    {
        string SessionId = "";
        ClientServiveFactory ServiceFactory;
        BPBusiness bp = new BPBusiness();
        public event ClientChanged ClientSelected;
        public event ClientReset ClientReset;
        public event ClientSearchClicked ClientSearchClicked;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

            }
        }

        #region Properties
        [Browsable(true), EditorBrowsable(EditorBrowsableState.Always)]
        public string DescriptionText
        {
            set
            {
                spnClientDescription.Text = value;
            }
        }
        public string ServiceOption
        {
            set
            {
                hdnServiceOption.Value = value;

                switch (hdnServiceOption.Value)
                {
                    case "BPSericeV1":
                        ServiceFactory = new BPBrokerConnectV2();
                        break;
                    case "BPSericeV2":
                        ServiceFactory = new Wf_BPBrokerConnectV2();
                        break;
                    default:
                        ServiceFactory = new BPBrokerConnectV2();
                        break;
                }
            }
        }
        public string AccountOffice
        {
            get
            {
                try
                {
                    DataTable dtlb = GetOfficeDetail();
                    return dtlb.Rows[0]["OfficeName"].ToString();

                }
                catch (Exception ex)
                {
                    return "";
                }
            }
        }
        public string AccountRegion
        {
            get
            {
                try
                {
                    DataTable dtlb = GetOfficeDetail();
                    return dtlb.Rows[0]["RegionName"].ToString();
                }
                catch (Exception ex)
                {
                    return "";
                }
            }
        }
        public bool IsClientSelected
        {
            get
            {
                if (ddlClient.SelectedIndex <= 0)
                    return false;
                else
                    return true;
            }
        }
        public string ClientName
        {
            get
            {
                try
                {
                    return ddlClient.SelectedItem.Text;
                }
                catch (Exception ex)
                {
                    return "";
                }
            }
        }
        public int ClientID
        {
            get
            {
                try
                {
                    return int.Parse(ddlClient.SelectedValue);
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        } 
        #endregion

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = ServiceFactory.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                if (ClientSearchClicked != null)
                    ClientSearchClicked(this);
                
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtsearch.Text = "";
            rdlClient.SelectedIndex = 0;
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", ""));
            if (ClientReset != null)
                ClientReset(this);
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClientSelectedEventArgs args = new ClientSelectedEventArgs();
            if (ddlClient.SelectedIndex <= 0)
            {
                args.ClientID = 0;
                args.ClientName = "";
            }
            else
            {
                args.ClientID = int.Parse(ddlClient.SelectedValue);
                args.ClientName = ddlClient.SelectedItem.Text;
            }
            if (ClientSelected != null)
                ClientSelected(this,args);
        }
        #region functions
        /// <summary>
        /// Returns Account Details
        /// </summary>
        /// <returns></returns>
        public DataSet GetAccountDetails()
        {
            DataSet AccountDS = null;
            if (IsClientSelected)
            {
                try
                {
                    SessionId = Session["SessionId"].ToString();
                    SummaryDetail sd = new SummaryDetail();
                    sd.BuildAccountTable();
                    AccountDS = ServiceFactory.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return AccountDS;
        }
        /// <summary>
        /// Return Account Contact
        /// </summary>
        /// <returns></returns>
        public List<Contact> GetAccountContacts()
        {
            List<Contact> lstContact = new List<Contact>();
            if (IsClientSelected)
            {
                try
                {
                    SessionId = Session["SessionId"].ToString();
                    lstContact = ServiceFactory.FindContacts(ddlClient.SelectedValue, SessionId);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return lstContact;
        }
        /// <summary>
        /// Returns Team Members
        /// </summary>
        /// <returns></returns>
        public DataSet GetAccountTeamMembers()
        {
            DataSet AccountTeamMemberDS = null;
            if (IsClientSelected)
            {
                try
                {
                    SessionId = Session["SessionId"].ToString();
                    SummaryDetail sd = new SummaryDetail();
                    sd.BuildAccountTable();
                    AccountTeamMemberDS = ServiceFactory.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return AccountTeamMemberDS;
        }
        /// <summary>
        /// Get Office Details.DataTable having Column OfficeName,RegionName and OfficeID
        /// </summary>
        public DataTable GetOfficeDetail()
        {
             SessionId = Session["SessionId"].ToString();
            return ServiceFactory.GetOfficeDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
        }
        #endregion;

    }
}