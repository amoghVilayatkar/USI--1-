﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;
using StringTrimmer;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.BAL.Finance
{
    public class EB_Invoice_Request : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="ProductDS"></param>
        /// <param name="Office_Region"></param>
        /// <param name="carrierList"></param>
        public void WriteInvoiceFinance_ServiceFee(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataSet ProductDS, string Office_Region, List<Carrier> carrierList)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string email = string.Empty;
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string effectiveDate = String.Empty;
                string carrier = String.Empty;
                string commissionfee = String.Empty;
                string frequency = String.Empty;
                Int32 billingCarrierID = 0;
                string billingCarrierName = String.Empty;
                int clmCnt = 1;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        //ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        oWordDoc.Tables[1].Rows[2].Range.Copy();
                        for (int row = 1; row < arrAcctContact.Count; row++)
                        {
                            oWordDoc.Tables[1].Rows[oWordDoc.Tables[1].Rows.Count].Range.Paste();
                        }

                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Name);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Delete();
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Email);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Delete();
                                    }
                                    clmCnt++;
                                }
                            }
                        }
                    }
                    else
                        oWordDoc.Tables[1].Rows[2].Delete();
                }

                #endregion

                #region Plan Writing

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    commissionfee = Convert.ToString(ProductDS.Tables[1].Rows[k][38]);
                    if (!String.IsNullOrEmpty(commissionfee) && commissionfee[0] != '$')
                        commissionfee = "$" + Convert.ToString(ProductDS.Tables[1].Rows[k][38]);
                    frequency = Convert.ToString(ProductDS.Tables[1].Rows[k][39]).Replace("_", " ");
                    billingCarrierID = Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]);
                    billingCarrierName = Convert.ToString((from cc in carrierList
                                                           where cc.CarrierId == billingCarrierID
                                                           select cc.CarrierName).FirstOrDefault());
                }

                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Renewal"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Service Team"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }

                        if (fieldName.Contains("PlanType"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planType)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planType));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PolicyNumber"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(policyNo)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(policyNo));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("BillingName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(billingCarrierName))
                            {
                                oWordApp.Selection.TypeText(billingCarrierName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("CommissionFee"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(commissionfee))
                            {
                                oWordApp.Selection.TypeText(commissionfee);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Frequency"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(frequency))
                            {
                                oWordApp.Selection.TypeText(frequency);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("SERVICEFEE"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(commissionfee))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(" ");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("AccountContact_Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(name))
                        //    {
                        //        oWordApp.Selection.TypeText(name);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("AccountContact_Title"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(title))
                        //    {
                        //        oWordApp.Selection.TypeText(title);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="ProductDS"></param>
        /// <param name="Office_Region"></param>
        /// <param name="carrierList"></param>
        public void WriteInvoiceFinance_BillClient(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataSet ProductDS, string Office_Region, List<Carrier> carrierList)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string effectiveDate = String.Empty;
                string carrier = String.Empty;
                string premiumFrequency = String.Empty;
                Int32 billingCarrierID = 0;
                string billingCarrierName = String.Empty;
                int clmCnt = 1;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        //ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        oWordDoc.Tables[1].Rows[2].Range.Copy();
                        for (int row = 1; row < arrAcctContact.Count; row++)
                        {
                            oWordDoc.Tables[1].Rows[oWordDoc.Tables[1].Rows.Count].Range.Paste();
                        }

                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Name);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Delete();
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Email);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Delete();
                                    }
                                    clmCnt++;
                                }
                            }
                        }
                    }
                    else
                        oWordDoc.Tables[1].Rows[2].Delete();
                }

                #endregion

                #region Plan Writing

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    premiumFrequency = Convert.ToString(ProductDS.Tables[1].Rows[k]["premiumPaymentFrequency"]).Replace("_", " ");
                    billingCarrierID = Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]);
                    billingCarrierName = Convert.ToString((from cc in carrierList
                                                           where cc.CarrierId == billingCarrierID
                                                           select cc.CarrierName).FirstOrDefault());
                }

                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Renewal"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Service Team"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }

                        if (fieldName.Contains("PlanType"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planType)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planType));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PolicyNumber"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(policyNo)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(policyNo));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("BillingName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(billingCarrierName))
                            {
                                oWordApp.Selection.TypeText(billingCarrierName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PremiumFrequency"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(premiumFrequency))
                            {
                                oWordApp.Selection.TypeText(premiumFrequency);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("BILLPREMIUM"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(premiumFrequency))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(" ");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("AccountContact_Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(name))
                        //    {
                        //        oWordApp.Selection.TypeText(name);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("AccountContact_Title"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(title))
                        //    {
                        //        oWordApp.Selection.TypeText(title);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="ProductDS"></param>
        /// <param name="Office_Region"></param>
        /// <param name="carrierList"></param>
        public void WriteInvoiceFinance_ThirdPartyService(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataSet ProductDS, string Office_Region, List<Carrier> carrierList)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string effectiveDate = String.Empty;
                string carrier = String.Empty;
                string premiumFrequency = String.Empty;
                Int32 billingCarrierID = 0;
                string billingCarrierName = String.Empty;
                int clmCnt = 1;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        //ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        oWordDoc.Tables[1].Rows[2].Range.Copy();
                        for (int row = 1; row < arrAcctContact.Count; row++)
                        {
                            oWordDoc.Tables[1].Rows[oWordDoc.Tables[1].Rows.Count].Range.Paste();
                        }

                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Name);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 1).Range.Fields[1].Delete();
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Select();
                                        oWordApp.Selection.TypeText(ContactList[i].Email);
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(j + 2, 2).Range.Fields[1].Delete();
                                    }
                                    clmCnt++;
                                }
                            }
                        }
                    }
                    else
                        oWordDoc.Tables[1].Rows[2].Delete();
                }

                #endregion

                #region Plan Writing

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    premiumFrequency = Convert.ToString(ProductDS.Tables[1].Rows[k]["premiumPaymentFrequency"]).Replace("_", " ");
                    billingCarrierID = Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]);
                    billingCarrierName = Convert.ToString((from cc in carrierList
                                                           where cc.CarrierId == billingCarrierID
                                                           select cc.CarrierName).FirstOrDefault());
                }

                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Renewal"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Service Team"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }

                        if (fieldName.Contains("PlanType"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planType)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planType));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PolicyNumber"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(policyNo)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(policyNo));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("BillingName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(billingCarrierName))
                            {
                                oWordApp.Selection.TypeText(billingCarrierName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PremiumFrequency"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(premiumFrequency))
                            {
                                oWordApp.Selection.TypeText(premiumFrequency);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("THIRDPARTYSERVICE"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(premiumFrequency))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(" ");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("AccountContact_Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(name))
                        //    {
                        //        oWordApp.Selection.TypeText(name);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("AccountContact_Title"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(title))
                        //    {
                        //        oWordApp.Selection.TypeText(title);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Client Name"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                continue;
                            }
                        }
                    }
                }
            }

        }
    }
}