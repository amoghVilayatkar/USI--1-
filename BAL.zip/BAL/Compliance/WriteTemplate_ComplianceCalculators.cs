﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.Compliance
{
    public class WriteTemplate_ComplianceCalculators : System.Web.UI.Page
    {
        public void WriteFields_CompliancePCORCalculatorsTemplate(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];            
            wkSheet.Cells[2, 8] = ClientName;
        }
        public void WriteFields_ComplianceCalculatorsExciseTaxTemplate(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];            
            wkSheet.Cells[1, 1] = ClientName;
        }
        public void WriteFields_ComplianceCalculatorWellnessTemplate(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName, DateTime dtRenewalDate)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            wkSheet.Cells[1, 1] = ClientName;
            wkSheet.Cells[3, 1] = dtRenewalDate.ToString("MMMM d, yyyy") + " Renewal Date";
        }
    }
}