﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using StringTrimmer;
using System.Globalization;

namespace BenefitPointSummaryPortal.BAL.Pilot
{
    public class WriteLetters : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        int deleterow = 2;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="priorCarrierName"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_LifeDisabilityCarrierToClient(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, string priorCarrierName, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }
                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField
                string effectiveDate = string.Empty;
                string planType = string.Empty;
                string carrier = String.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("PriorCName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(priorCarrierName))
                            {
                                oWordApp.Selection.TypeText(priorCarrierName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_LifeDisabilityCarrierToCarrier(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Plan Writing

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);

                    planDetails.Append("\n        " + planType + ", " + policyNo);
                }

                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    break;
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("MinusDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDateMinus))
                            {
                                oWordApp.Selection.TypeText(renewalDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Carrier Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="priorCarrierName"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_BORToCarrier(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_NewClientThankYouLetter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress, List<BRC> BRCList, DropDownList ddlBRC, GridView grdAccountTeam, DataTable dtPlanContactInfo)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string firstname = String.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                        firstname = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 1;
                int count = 1;
                string SerialNo = string.Empty;
                string name1 = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    //DataTable dtAccountTeam = new DataTable();
                    //dtAccountTeam.Columns.Add("SrNo", typeof(string));
                    //dtAccountTeam.Columns.Add("Name", typeof(string));
                    //dtAccountTeam.Columns.Add("email", typeof(string));
                    //dtAccountTeam.Columns.Add("role", typeof(string));
                    //dtAccountTeam.Columns.Add("workPhone", typeof(string));
                    System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();
                    //TextBox txtSerialNo = new TextBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));

                        //txtSerialNo = ((TextBox)grRow.FindControl("txtSRNo"));
                        if (chkItemSelect.Checked == true)
                        {
                            SerialNo = "";
                            name1 = "";
                            role = "";
                            workPhone = "";
                            email = "";

                            //SerialNo = txtSerialNo.Text;
                            name1 = Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "") + " " + Convert.ToString(grRow.Cells[6].Text).Replace("&nbsp;", "");
                            email = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                            role = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");
                            workPhone = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "");


                            //DataRow drAccountTeamRow;
                            //drAccountTeamRow = dtAccountTeam.NewRow();
                            //drAccountTeamRow["SrNo"] = SerialNo;
                            //drAccountTeamRow["Name"] = name;
                            //drAccountTeamRow["email"] = email;
                            //drAccountTeamRow["role"] = role;
                            //drAccountTeamRow["workPhone"] = workPhone;
                            //dtAccountTeam.Rows.Add(drAccountTeamRow);


                            if (grRow.RowIndex > 0)
                            {
                                oWordDoc.Tables[1].Rows.Add();
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name1;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }
                            /******************************************************************************/
                            /* AS PER :- FEEDBACK 5: New Deliverables Request - Letters Criteria Page Changes and Additional Letters
                                      Client contact name is appearing in USI Service Team table. Though the Title, Phone number and email are for a true USI Service Team member
                            */
                            else if (grRow.RowIndex == 0)
                            {
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name1;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }

                        }

                    }
                }
                #endregion

                #region For Contact information writing
                oWordApp.ActiveDocument.Tables[2].AllowPageBreaks = true;
                if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                {
                    foreach (DataRow row in dtPlanContactInfo.Rows)
                    {
                        if (dtPlanContactInfo.Rows.IndexOf(row) > 0)
                        {
                            oWordDoc.Tables[2].Rows.Add();
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                        else if (dtPlanContactInfo.Rows.IndexOf(row) == 0)
                        {
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                    }
                }
                else if (dtPlanContactInfo.Rows.Count == 0)
                {
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Cell(1, 1).Select();
                    oWordDoc.Tables[2].Cell(deleterow, 1).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 2).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 3).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 4).Range.Text = "";
                }
                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient, PlanInfoTable, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                int BRCindex = -1;
                string hasBRC = String.Empty;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                    hasBRC = " ";
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(firstname))
                            {
                                oWordApp.Selection.TypeText(firstname);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                            oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                            continue;
                        }

                        if (fieldName.Contains("HAVE_BRC"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(hasBRC))
                            {
                                oWordApp.Selection.TypeText(hasBRC);
                            }
                            continue;
                        }

                        if (BRCindex > -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                }
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                }
                                continue;
                            }

                        }
                        else if (BRCindex == -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }

                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_NewClientThankYouLetter_WithoutContactSheet(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string firstname = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                        firstname = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                        firstname = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(firstname))
                            {
                                oWordApp.Selection.TypeText(firstname);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_USITerminationLetter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                //foreach (DataRow dr in PlanInfoTable.Rows)
                //{
                //    renewalDate = Convert.ToString(dr["Renewal"]);
                //    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                //    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                //    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                //    break;
                //}

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        //Added by Amogh  - FEEDBACK 3: New Deliverables Request - 2 Additional Letters issue
                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("First Plan Renewal Date"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDate))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDate);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("MinusDate"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDateMinus))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDateMinus);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Plan"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                        //    {
                        //        oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("First Carrier Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(carrier))
                        //    {
                        //        oWordApp.Selection.TypeText(carrier);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Main Address"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(MainAddress))
                        //    {
                        //        oWordApp.Selection.TypeText(MainAddress);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                // myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write_DateInto_Footer
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_DateInto_Footer(Word.Document oWordDoc, Word.Application oWordApp)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.ToString("yyyy"));
                                continue;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header_Letters(Word.Document oWordDoc, Word.Application oWordApp, DataTable dtOfficeAddress)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("OfficeStreet"))
                            {
                                field.Select();
                                string OfficeStreetAdd = Convert.ToString(dtOfficeAddress.Rows[0]["Office Street Address"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeStreetAdd))
                                {
                                    oWordApp.Selection.TypeText(OfficeStreetAdd);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("City"))
                            {
                                field.Select();

                                string OfficeCity = Convert.ToString(dtOfficeAddress.Rows[0]["City"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeCity))
                                {
                                    oWordApp.Selection.TypeText(OfficeCity);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("State"))
                            {
                                field.Select();
                                string OfficeState = Convert.ToString(dtOfficeAddress.Rows[0]["State"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeState))
                                {
                                    oWordApp.Selection.TypeText(OfficeState);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("ZIP"))
                            {
                                field.Select();
                                string OfficeZip = Convert.ToString(dtOfficeAddress.Rows[0]["Zip"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeZip))
                                {
                                    oWordApp.Selection.TypeText(OfficeZip);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("Office Phone Number"))
                            {
                                field.Select();
                                string OfficePhNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Phone Number"]).Trim();
                                if (!string.IsNullOrEmpty(OfficePhNumber))
                                {
                                    oWordApp.Selection.TypeText(OfficePhNumber);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                        }
                    }
                }
            }

        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataTable PlanInfoTable, DataTable dtOfficeAddress)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Client Name"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                continue;
                            }

                            if (fieldName.Contains("First Med Plan Effective Date"))
                            {
                                field.Select();
                                string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                                oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                continue;
                            }
                            if (fieldName.Contains("OfficeStreet"))
                            {
                                field.Select();
                                string OfficeStreetAdd = Convert.ToString(dtOfficeAddress.Rows[0]["Office Street Address"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeStreetAdd))
                                {
                                    oWordApp.Selection.TypeText(OfficeStreetAdd);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("City"))
                            {
                                field.Select();

                                string OfficeCity = Convert.ToString(dtOfficeAddress.Rows[0]["City"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeCity))
                                {
                                    oWordApp.Selection.TypeText(OfficeCity);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("State"))
                            {
                                field.Select();
                                string OfficeState = Convert.ToString(dtOfficeAddress.Rows[0]["State"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeState))
                                {
                                    oWordApp.Selection.TypeText(OfficeState);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("ZIP"))
                            {
                                field.Select();
                                string OfficeZip = Convert.ToString(dtOfficeAddress.Rows[0]["Zip"]).Trim();
                                if (!string.IsNullOrEmpty(OfficeZip))
                                {
                                    oWordApp.Selection.TypeText(OfficeZip);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                            if (fieldName.Contains("Office Phone Number"))
                            {
                                field.Select();
                                string OfficePhNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Phone Number"]).Trim();
                                if (!string.IsNullOrEmpty(OfficePhNumber))
                                {
                                    oWordApp.Selection.TypeText(OfficePhNumber);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;

                            }
                        }
                    }
                }
            }

        }

        #region Added by Shravan
        public void WriteLetters_BAA_Cover_Letter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                //code added by shravan
                string AccountContact_FirstName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                //added by shravan
                string email = string.Empty;
                string phone = string.Empty;



                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    //code added by shravan //  --------------------------
                                    if (ContactList[i].Email != null)
                                    {
                                        email = ContactList[i].Email;
                                    }
                                    else
                                    {
                                        email = " ";
                                    }
                                    //if (ContactList[i].Phone[0] != null)
                                    //{
                                    //    phone = ContactList[i].Phone[0];
                                    //}
                                    //else
                                    //{
                                    //    phone = " ";
                                    //}
                                    if (ContactList[i].First_Name != null)
                                    {
                                        AccountContact_FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        AccountContact_FirstName = " ";
                                    }


                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        //code added by shravan 
                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContact_FirstName))
                            {
                                oWordApp.Selection.TypeText(AccountContact_FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        // WORD // ------------------------- Authorization to Share PHI ----------------- // WORD //
        public void WriteLetters_Authorization_to_Share_PHI(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        // WORD // ------------------------- Carrier Not Rated ----------------- // WORD //
        public void WriteLetters_Carrier_Not_Rated(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                //code added by shravan
                string AccountContact_FirstName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        AccountContact_FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        AccountContact_FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //code added by shravan 
                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContact_FirstName))
                            {
                                oWordApp.Selection.TypeText(AccountContact_FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        // WORD // ------------------------- HICA Cover Letter ----------------- // WORD //
        public void WriteLetters_HICA_Cover_Letter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                //code added by shravan
                string AccountContact_FirstName = string.Empty;


                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    if (ContactList[i].First_Name != null)
                                    {
                                        AccountContact_FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        AccountContact_FirstName = " ";
                                    }

                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //code added by shravan 
                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContact_FirstName))
                            {
                                oWordApp.Selection.TypeText(AccountContact_FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // WORD // ------------------------- Marketing Declination Letter To Carrier ----------------- // WORD //
        public void WriteLetters_Marketing_Declination_Letter_To_Carrier(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                string phone = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    //Added by Shravan
                                    //if (ContactList[i].Phone != null)
                                    //{
                                    //    phone = ContactList[i].Phone[0].ToString();
                                    //}
                                    //else
                                    //{
                                    //    title = " ";
                                    //}

                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("AccountContact_WorkPhone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(phone))
                            {
                                oWordApp.Selection.TypeText(phone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        // WORD // ------------------------- Small Business Welcome Kit Letter ----------------- // WORD //
        public void WriteLetters_Small_Business_Welcome_Kit_Letter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                //code added by shravan
                string AccountContact_FirstName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Broker_Of_Record = string.Empty;
                string name = string.Empty;
                string title = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        AccountContact_FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        AccountContact_FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //code added by shravan 
                        if (fieldName.Contains("AccountContact_FirstName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContact_FirstName))
                            {
                                oWordApp.Selection.TypeText(AccountContact_FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        #region Added By Vinod
        #region Added for A.M. Best Rating Client Letter - Initial Coverage Placement word letter

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_BestRatingClientLetter_InitialCoveragePlacement(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                string FirstName = String.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }


                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {

                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstName))
                            {
                                oWordApp.Selection.TypeText(FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        #endregion

        #region Renewal Analysis Cover Letter

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_RenewalAnalysisCoverLetter(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string FirstName = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion


                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                //foreach (DataRow dr in PlanInfoTable.Rows)
                //{
                //    renewalDate = Convert.ToString(dr["Renewal"]);
                //    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                //    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                //    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                //    break;
                //}


                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    // planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    //carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    // planDetails.Append("\n        " + planType + ", " + policyNo);
                    break;
                }



                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        //Added by Amogh  - FEEDBACK 3: New Deliverables Request - 2 Additional Letters issue
                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("First Plan Renewal Date"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDate))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDate);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("MinusDate"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDateMinus))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDateMinus);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Plan"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                        //    {
                        //        oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("First Carrier Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(carrier))
                        //    {
                        //        oWordApp.Selection.TypeText(carrier);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Main Address"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(MainAddress))
                        //    {
                        //        oWordApp.Selection.TypeText(MainAddress);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("First Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstName))
                            {
                                oWordApp.Selection.TypeText(FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion



                #region Generating table for plan
                int count = 1;
                if (PlanInfoTable != null && PlanInfoTable.Rows.Count > 0)
                {

                    foreach (DataRow row in PlanInfoTable.Rows)
                    {
                        if (count > 1)
                            oWordDoc.Tables[1].Rows.Add();
                        count++;
                        int countsec = PlanInfoTable.Rows.Count + 1;
                        for (int i = 1; i < countsec; i++)
                        {

                            oWordDoc.Tables[1].Cell(count, 1).Select();
                            oWordDoc.Tables[1].Cell(count, 1).Range.Text = row["Name"].ToString();
                            oWordDoc.Tables[1].Cell(count, 2).Range.Text = row["Carrier"].ToString();
                            oWordDoc.Tables[1].Cell(count, 3).Range.Text = "";

                        }

                    }
                }
                else if (PlanInfoTable.Rows.Count == 0)
                {
                    count++;
                    oWordDoc.Tables[1].Cell(count, 1).Select();
                    oWordDoc.Tables[1].Cell(count, 1).Range.Text = "";
                    oWordDoc.Tables[1].Cell(count, 2).Range.Text = "";
                    oWordDoc.Tables[1].Cell(count, 3).Range.Text = "";
                }
                #endregion

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        #region Termination Letter from Client to Carrier

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_TerminationLettefromClienttoCarrier(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string FirstPlanRenewlaDateMinus = string.Empty;
                string carrier = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                //#region Write Table of Account Contacts

                //if (ContactList != null)
                //{
                //    if (arrAcctContact.Count > 0)
                //    {
                //        for (int j = 0; j < arrAcctContact.Count; j++)
                //        {
                //            for (int i = 0; i < ContactList.Count; i++)
                //            {
                //                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                //                {
                //                    if (ContactList[i].Name != null)
                //                    {
                //                        name = ContactList[i].Name;
                //                    }
                //                    else
                //                    {
                //                        name = " ";
                //                    }

                //                    if (ContactList[i].Title != null)
                //                    {
                //                        title = ContactList[i].Title;
                //                    }
                //                    else
                //                    {
                //                        title = " ";
                //                    }
                //                }
                //            }
                //        }
                //    }
                //}
                //#endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    //if (ContactList[i].First_Name != null)
                                    //{
                                    //    FirstName = ContactList[i].First_Name;
                                    //}
                                    //else
                                    //{
                                    //    FirstName = " ";
                                    //}
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    DateTime dtRenewalDate = GetDate(dr["Renewal"].ToString());
                    renewalDate = dtRenewalDate.AddDays(-1).ToString("MMMM dd, yyyy");
                    //  renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    break;
                }

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    // renewalDate = Convert.ToString(dr["Renewal"]);
                    //renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    //renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    //renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");

                    planDetails.Append(planType + ", " + policyNo + "\n");
                    //  break;
                }
                /***************OLD CODE COMMND BY AMOGH - FEEDBACK 6: [ Cat :- Error messaged received when attempting to Create the letter when plan selected is an Additional Product]*/
                ////planDetails.Remove(planDetails.Length - 1, 1);

                if (planDetails.Length > 0)
                {
                    planDetails.Remove(planDetails.Length - 1, 1);
                }



                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("MinusDate"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDateMinus))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDateMinus);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("MinusDate"))
                        {
                            FirstPlanRenewlaDateMinus = renewalDate;
                            //renewalDateMinus = Convert.ToString(Convert.ToDateTime(FirstPlanRenewlaDateMinus.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(FirstPlanRenewlaDateMinus.ToString()).Year.ToString());

                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstPlanRenewlaDateMinus))
                            {
                                oWordApp.Selection.TypeText(FirstPlanRenewlaDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        #region A.M. Best Rating Client Letter - Midyear Downgrade

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_AMBestRatingClientLetter_MidyearDowngrade(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress, string PlanInfo_Carrier)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = PlanInfo_Carrier;
                string FirstName = String.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");

                    planDetails.Append("\n        " + planType + ", " + policyNo);
                    break;
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("MinusDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDateMinus))
                            {
                                oWordApp.Selection.TypeText(renewalDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("First Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstName))
                            {
                                oWordApp.Selection.TypeText(FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }



                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        #endregion

        #region Carrier Contract to client

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_CarrierContracttoClient(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string FirstName = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string effectiveDate = string.Empty;
                string carrier = String.Empty;
                string fEffectiveDate = string.Empty;
                string FirstPlaneffectiveDate = string.Empty;

                string frenewalDate = string.Empty;
                string FirstrenewalDate = string.Empty;
                string FirstrenewalDateMinus = string.Empty;




                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    fEffectiveDate = Convert.ToString(dr["Effective"]);
                    FirstPlaneffectiveDate = Convert.ToString(Convert.ToDateTime(fEffectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(fEffectiveDate.ToString()).Year.ToString());

                    frenewalDate = Convert.ToString(dr["Renewal"]);
                    FirstrenewalDate = Convert.ToString(Convert.ToDateTime(frenewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(frenewalDate.ToString()).Year.ToString());
                    //FirstrenewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());

                    break;
                }

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    planDetails.Append(planType + ", " + policyNo + "\n");
                    // break;
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstPlaneffectiveDate))
                            {
                                oWordApp.Selection.TypeText(FirstPlaneffectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {

                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("MinusDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDateMinus))
                            {
                                oWordApp.Selection.TypeText(renewalDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstrenewalDate))
                            {
                                oWordApp.Selection.TypeText(FirstrenewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstName))
                            {
                                oWordApp.Selection.TypeText(FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        #region Renewal Request Letter to Carrier
        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="AccountDS"></param>
        /// <param name="PlanInfoTable"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="ContactList"></param>
        /// <param name="SessionId"></param>
        /// <param name="arrAcctContact"></param>
        /// <param name="dtOfficeAddress"></param>
        public void WriteLetters_RenewalRequestLettertoCarrier(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string carrier = String.Empty;
                string effectiveDate = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].Phone != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                //#region Plan Writing

                //foreach (DataRow dr in PlanInfoTable.Rows)
                //{
                //    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                //    policyNo = Convert.ToString(dr["PolicyNumber"]);

                //    planDetails.Append("\n        " + planType + ", " + policyNo);
                //}

                //#endregion

                #region MergeField

                //foreach (DataRow dr in PlanInfoTable.Rows)
                //{
                //    renewalDate = Convert.ToString(dr["Renewal"]);
                //    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                //    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                //    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                //    break;
                //}


                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    planDetails.Append(planType + ", " + policyNo + "\n");
                    // break;
                }
                ////planDetails.Remove(planDetails.Length - 1, 1);  // commented by Amogh 

                if (planDetails.Length > 0)
                {
                    planDetails.Remove(planDetails.Length - 1, 1);
                }


                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        //Added by Amogh  - FEEDBACK 3: New Deliverables Request - 2 Additional Letters issue
                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                //oWordApp.Selection.TypeText(MainAddress);
                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("MinusDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDateMinus))
                            {
                                oWordApp.Selection.TypeText(renewalDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDate))
                            {
                                oWordApp.Selection.TypeText(renewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        //if (fieldName.Contains("First Plan Renewal Date"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDate))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDate);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("MinusDate"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(renewalDateMinus))
                        //    {
                        //        oWordApp.Selection.TypeText(renewalDateMinus);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Plan"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                        //    {
                        //        oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("First Carrier Name"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(carrier))
                        //    {
                        //        oWordApp.Selection.TypeText(carrier);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        //if (fieldName.Contains("Main Address"))
                        //{
                        //    myMergeField.Select();
                        //    if (!string.IsNullOrEmpty(MainAddress))
                        //    {
                        //        oWordApp.Selection.TypeText(MainAddress);
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //    continue;
                        //}

                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion



                //#region Generating plan
                //int count = 1;
                //if (PlanInfoTable != null && PlanInfoTable.Rows.Count > 0)
                //{

                //    foreach (DataRow row in PlanInfoTable.Rows)
                //    {
                //        if (count > 1)
                //            oWordDoc.Tables[1].Rows.Add();
                //        count++;
                //        int countsec = PlanInfoTable.Rows.Count + 1;
                //        for (int i = 2; i < countsec; i++)
                //        {

                //            oWordDoc.Tables[1].Cell(count, 1).Select();
                //            oWordDoc.Tables[1].Cell(count, 1).Range.Text = row["Name"].ToString();
                //            oWordDoc.Tables[1].Cell(count, 2).Range.Text = row["Carrier"].ToString();
                //            oWordDoc.Tables[1].Cell(count, 3).Range.Text = "";

                //        }

                //    }
                //}
                //else if (PlanInfoTable.Rows.Count == 0)
                //{
                //    count++;
                //    oWordDoc.Tables[1].Cell(count, 1).Select();
                //    oWordDoc.Tables[1].Cell(count, 1).Range.Text = "";
                //    oWordDoc.Tables[1].Cell(count, 2).Range.Text = "";
                //    oWordDoc.Tables[1].Cell(count, 3).Range.Text = "";
                //}
                //#endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
        #endregion

        public void Add_Replacee(Word.Document oWordDoc, Word.Application oWordApp, Word.Range range, string mergeField, string fieldName)
        {
            if (String.IsNullOrEmpty(fieldName))
                fieldName = "";


            // Word.Range range = oWordDoc.Range();
            Word.Find find = range.Find;
            find.Text = mergeField;

            find.ClearFormatting();
            Object missing = System.Reflection.Missing.Value;
            range.Find.Execute(
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing);
            while (find.Found)
            {
                find.Replacement.ClearFormatting();
                find.Replacement.Text = fieldName;

                object replaceAll = Word.WdReplace.wdReplaceAll;
                find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref replaceAll, ref missing, ref missing, ref missing, ref missing);
            }
        }
        public void WriteLetters_CarrierConfirmation(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {


                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string FirstName = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string effectiveDate = string.Empty;
                string carrier = String.Empty;
                string LOC = string.Empty;
                string fEffectiveDate = string.Empty;
                string FirstPlaneffectiveDate = string.Empty;

                string frenewalDate = string.Empty;
                string FirstrenewalDate = string.Empty;
                string FirstrenewalDateMinus = string.Empty;

                string ServiceLead_FullName = "";


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_FullName = ServiceLead_FirstName + " " + ServiceLead_LastName;
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                //Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                //Write_DateInto_Footer(oWordDoc, oWordApp);
                List<string> lstPlanTypePolicyNames = new List<string>();
                List<string> lstLOC = new List<string>();

                foreach (DataRow dr in PlanInfoTable.Rows)
                {

                    if (FirstPlaneffectiveDate == string.Empty)
                        FirstPlaneffectiveDate = Convert.ToString(Convert.ToDateTime(Convert.ToString(dr["Effective"])).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(Convert.ToString(dr["Effective"])).Year.ToString());
                    if (FirstrenewalDate == string.Empty)
                        FirstrenewalDate = Convert.ToString(Convert.ToDateTime(Convert.ToString(dr["Renewal"])).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(Convert.ToString(dr["Renewal"])).Year.ToString());
                    if (carrier == string.Empty)
                        carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");

                    LOC = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    policyNo = Convert.ToString(dr["PolicyNumber"]);

                    string PlanTypePolicyName = LOC + ", " + policyNo;
                    if (!lstPlanTypePolicyNames.Contains(PlanTypePolicyName))
                        lstPlanTypePolicyNames.Add(PlanTypePolicyName);
                    if (!lstLOC.Contains(LOC))
                        lstLOC.Add(LOC);
                    planDetails.Append(PlanTypePolicyName + "\n");
                }
                #region BodyContent
                string strPlanTypePolicyNumber = string.Join("\n", lstPlanTypePolicyNames);
                string strLOCs = string.Join(", ", lstLOC);
                if (planDetails.Length > 0)
                {
                    planDetails.Remove(planDetails.Length - 1, 1);
                }
                StringBuilder extractText = new StringBuilder(oWordDoc.Content.Text);

                System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"\<<(.*?)\>>",
               System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                System.Text.RegularExpressions.MatchCollection matches = rx.Matches(extractText.ToString());
                Word.Range range = oWordDoc.Range();
                foreach (System.Text.RegularExpressions.Match match in matches)
                {
                    if (match.ToString() == "<<Today’s Date>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), DateTime.Today.ToString("MM/dd/yyyy"));
                    else if (match.ToString() == "<<Carrier Name>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), carrier);
                    else if (match.ToString() == "<<Client Name>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ddlClient.SelectedItem.Text.ToString().Trim());
                    else if (match.ToString() == "<<Effective Date>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), FirstPlaneffectiveDate);
                    else if (match.ToString() == "<<Renewal Date>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), FirstrenewalDate);
                    else if (match.ToString() == "<<Policy Number>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), policyNo);
                    else if (match.ToString() == "<<Primary Service Lead>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ServiceLead_FullName);
                    else if (match.ToString() == "<< Service Info / Primary Contact >>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ServiceLead_FullName);
                    else if (match.ToString() == "<< Service Info /Primary Contact Role>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ServiceLead_Role);
                    if (match.ToString() == "<< Service Info / Primary Contact Work Phone>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ServiceLead_WorkPhone);
                    if (match.ToString() == "<<Line of Coverage>>")
                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), strLOCs);
                    //if (match.ToString() == "")
                    //Add_Replacee(oWordDoc, oWordApp, match.ToString(),);
                }
                #endregion
                #region Header
                string HeaderText = "";
                matches = null;
                string OfficeStreetAdd = Convert.ToString(dtOfficeAddress.Rows[0]["Office Street Address"]).Trim();
                string OfficeCity_State_Zip = Convert.ToString(dtOfficeAddress.Rows[0]["City"]).Trim() + ", " + Convert.ToString(dtOfficeAddress.Rows[0]["State"]).Trim() + "  " + Convert.ToString(dtOfficeAddress.Rows[0]["Zip"]).Trim();
                string OfficePhNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Phone Number"]).Trim();
                foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                {
                    foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                    {
                        HeaderText = header.Range.Text;
                        matches = rx.Matches(HeaderText);
                        if (matches.Count > 0)
                        {
                            foreach (System.Text.RegularExpressions.Match match in matches)
                            {
                                if (match.ToString() == "<<Office Street Address>>")
                                    Add_Replacee(oWordDoc, oWordApp, header.Range, match.ToString(), OfficeStreetAdd);
                                else if (match.ToString() == "<<Office City, State  Zip>>")
                                    Add_Replacee(oWordDoc, oWordApp, header.Range, match.ToString(), OfficeCity_State_Zip);
                                else if (match.ToString() == "<<Office Phone Number>>")
                                    Add_Replacee(oWordDoc, oWordApp, header.Range, match.ToString(), OfficePhNumber);
                            }
                        }
                    }
                }
                #endregion
                #region Footer
                string FooterText = "";
                matches = null;

                foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                {
                    foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                    {
                        FooterText = footer.Range.Text;
                        matches = rx.Matches(FooterText);
                        if (matches.Count > 0)
                        {
                            foreach (System.Text.RegularExpressions.Match match in matches)
                            {
                                if (match.ToString() == "<<Current Year>>")
                                    Add_Replacee(oWordDoc, oWordApp, footer.Range, match.ToString(), DateTime.Today.ToString("yyyy"));

                            }
                        }
                    }
                }
                #endregion
                #region merge field
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("PlanTypePolicyNumber"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(strPlanTypePolicyNumber);
                            break;
                        }
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        //Added by shravan
        public void WriteLetters_ClientLogoUsageRelease(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string name = string.Empty;
                string FirstName = string.Empty;
                string title = string.Empty;
                StringBuilder planDetails = new StringBuilder();
                string planType = string.Empty;
                string policyNo = String.Empty;
                string renewalDate = string.Empty;
                string renewalDateMinus = string.Empty;
                string effectiveDate = string.Empty;
                string carrier = String.Empty;
                string fEffectiveDate = string.Empty;
                string FirstPlaneffectiveDate = string.Empty;

                string frenewalDate = string.Empty;
                string FirstrenewalDate = string.Empty;
                string FirstrenewalDateMinus = string.Empty;




                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region Write Table of Account Contacts

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }
                                    if (ContactList[i].First_Name != null)
                                    {
                                        FirstName = ContactList[i].First_Name;
                                    }
                                    else
                                    {
                                        FirstName = " ";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                Write_Field_Header_Letters(oWordDoc, oWordApp, dtOfficeAddress);
                Write_DateInto_Footer(oWordDoc, oWordApp);

                #region MergeField

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    fEffectiveDate = Convert.ToString(dr["Effective"]);
                    FirstPlaneffectiveDate = Convert.ToString(Convert.ToDateTime(fEffectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(fEffectiveDate.ToString()).Year.ToString());

                    frenewalDate = Convert.ToString(dr["Renewal"]);
                    FirstrenewalDate = Convert.ToString(Convert.ToDateTime(frenewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(frenewalDate.ToString()).Year.ToString());
                    //FirstrenewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());

                    break;
                }

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    effectiveDate = Convert.ToString(dr["Effective"]);
                    effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                    planType = Convert.ToString(dr["Name"]).Replace("&amp;", "&");
                    renewalDate = Convert.ToString(dr["Renewal"]);
                    renewalDate = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString());
                    renewalDateMinus = Convert.ToString(Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).AddDays(-1).Year.ToString());
                    policyNo = Convert.ToString(dr["PolicyNumber"]);
                    carrier = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    planDetails.Append(planType + ", " + policyNo + "\n");
                    // break;
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("CarrierName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstPlaneffectiveDate))
                            {
                                oWordApp.Selection.TypeText(FirstPlaneffectiveDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {

                                oWordApp.Selection.TypeText(Convert.ToString(MainAddress).Replace("_", " "));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("MinusDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(renewalDateMinus))
                            {
                                oWordApp.Selection.TypeText(renewalDateMinus);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Plan Renewal Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstrenewalDate))
                            {
                                oWordApp.Selection.TypeText(FirstrenewalDate);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Plan Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(planType))
                            {
                                oWordApp.Selection.TypeText(planType);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }


                        if (fieldName.Contains("Plan"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Convert.ToString(planDetails)))
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(planDetails));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("First Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FirstName))
                            {
                                oWordApp.Selection.TypeText(FirstName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("AccountContact_Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Role"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_Role))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_Role);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
       
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
    }
}