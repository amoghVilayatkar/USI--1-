﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.DAL;

namespace BenefitPointSummaryPortal.BAL.BRCInformation
{

    public class BRCInformationOperation
    {
        DBHelper DB_helper = new DBHelper();
        /// <summary>
        /// Delete BRC Details from datadase BPPortal by id .
        /// </summary>
        /// <returns></returns>
        public bool DeleteBRCInformationDetails(int Id)
        {
            bool IsSuccess = false;
            try
            {
                // IsActive = false;                
                string flag = "Delete";
                SqlParameter[] parameters = { new SqlParameter("@ID ", SqlDbType.NVarChar), new SqlParameter("@op ", SqlDbType.NVarChar) };
                parameters[0].Value = Id;
                parameters[1].Value = flag;
                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBRCDetails", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return IsSuccess;
        }

        public DataTable SearchBRCInformation(string BRCName, string State, int BRCLocation)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@BRCName", SqlDbType.NVarChar, 500), 
                                                new SqlParameter("@State", SqlDbType.NVarChar, 500), 
                                                new SqlParameter("@BRCID", SqlDbType.Int, 500)
                                            };


                parameters[0].Value = BRCName;
                parameters[1].Value = State;
                parameters[2].Value = BRCLocation;


                DataTable dtblOfficeAddress = DB_helper.ExecProcedure("GetSearchBRCInforamtionDetailsData", parameters);
                return dtblOfficeAddress;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }


        public bool InsertUpdateBRCDetails(int Id, string OfficeName, string BRCOfficeId, int BRCID, string RegionName, string USIOfficeLocation, string State, bool IsDelete)
        {


            bool IsSuccess = false;
            try
            {
                string flag = "Insert";
                if (Id > 0)
                    flag = "Update";

                SqlParameter[] parameters = { 
                                                new SqlParameter("@BPOfficeName ", SqlDbType.NVarChar), 
                                                new SqlParameter("@BPOfficeID ", SqlDbType.NVarChar), 
                                                new SqlParameter("@BRCID", SqlDbType.Int), 
                                                new SqlParameter("@Region", SqlDbType.NVarChar),                                               
                                                new SqlParameter("@USIOffiLocation", SqlDbType.NVarChar), 
                                               // new SqlParameter("@BRCLocation", SqlDbType.NVarChar), 
                                                new SqlParameter("@State", SqlDbType.NVarChar), 
                                               // new SqlParameter("@BRCPhone", SqlDbType.NVarChar), 
                                               // new SqlParameter("@BRCEmail ", SqlDbType.NVarChar), 
                                               // new SqlParameter("@BRCTimezone ", SqlDbType.NVarChar),                                                
                                                new SqlParameter("@op ", SqlDbType.NVarChar), 
                                                new SqlParameter("@ID ", SqlDbType.Int)
                                                
                                            
                                            };
                parameters[0].Value = OfficeName;
                parameters[1].Value = BRCOfficeId;
                parameters[2].Value = BRCID;
                parameters[3].Value = RegionName;
                parameters[4].Value = USIOfficeLocation;
                //  parameters[5].Value = BRCLocationName;
                parameters[5].Value = State;
                // parameters[7].Value = Phone;
                //  parameters[8].Value = EmailAddress;
                // parameters[9].Value = BRCTimeZone;
                parameters[6].Value = flag;
                parameters[7].Value = Id;

                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBRCDetails", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return IsSuccess;
        }


        public DataTable GetBRCInforamtionById(int id)
        {
            DataTable dtbl = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ID ", SqlDbType.NVarChar) };
                parameters[0].Value = id;
                dtbl = DB_helper.ExecProcedure("GetBRCInformationDetailsDatabyId", parameters);//("select Office_name from dbo.BROKER_OFFICE");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtbl;
        }

        public DataTable GetBRCLocation()
        {
            //[GetBRCLocation]
            DataTable dtblBRCLocation = new DataTable();
            try
            {
                dtblBRCLocation = DB_helper.ExecProcedure("GetBRCLocation", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblBRCLocation;
        }

        public DataTable GetBRCRegion()
        {
            //[GetBRCLocation]
            DataTable dtblBRCRegion = new DataTable();
            try
            {
                dtblBRCRegion = DB_helper.ExecProcedure("GetBRCRegion", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblBRCRegion;
        }

        /// <summary>
        /// Get BRC TimeZone from datadase BPPortal.
        /// </summary>
        /// <returns>TimeZone Name</returns>
        public DataTable GetBRCTimeZoneList()
        {
            DataTable dtblTimeZones;
            try
            {
                dtblTimeZones = DB_helper.ExecProcedure("GetBRCTimeZoneData", null);//("select Office_State from dbo.BRC_Region&Office");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblTimeZones;
        }

        /// <summary>
        /// Get BRC Region State name from datadase BPPortal.
        /// </summary>
        /// <returns>State Name</returns>
        public DataTable GetBRCRegionStateList()
        {
            DataTable dtblStates;
            try
            {
                dtblStates = DB_helper.ExecProcedure("GetBRCRegionStateData", null);//("select Office_State from dbo.BRC_Region&Office");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblStates;
        }

        public DataTable GetBRCOfficeName()
        {
            //[GetBRCLocation]
            DataTable dtblBRCOfficeName = new DataTable();
            try
            {
                dtblBRCOfficeName = DB_helper.ExecProcedure("GetBRCNameData", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblBRCOfficeName;
        }


        #region MyRegion
        // BRC Location Details

        public DataTable SearchBRCLocation(string BRCLocation, string PhoneNumber)
        {
            try
            {
                SqlParameter[] parameters = { 
                                                new SqlParameter("@BRCLocation", SqlDbType.NVarChar, 500),
                                                new SqlParameter("@PhoneNumber", SqlDbType.NVarChar, 500)
                                            };

                parameters[0].Value = BRCLocation;
                parameters[1].Value = PhoneNumber;


                DataTable dtblLocation = DB_helper.ExecProcedure("GetSearchBRCLocationData", parameters);
                return dtblLocation;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public bool InsertUpdateBRCLocation(int BRCID, string BRCName, string BRCLocation, string BRCDaysHours, string Phone, string EmailAddress,
            string Fax, string BRCTimeZone)
        {


            bool IsSuccess = false;
            try
            {
                string flag = "Insert";
                if (BRCID > 0)
                    flag = "Update";

                SqlParameter[] parameters = {                                                                                                
                                                //new SqlParameter("@BRCID", SqlDbType.Int), 
                                                new SqlParameter("@BRCName ", SqlDbType.NVarChar),                                                
                                                new SqlParameter("@BRCLocation", SqlDbType.NVarChar), 
                                                new SqlParameter("@BenefitResourceCenterDaysHours", SqlDbType.NVarChar), 
                                                new SqlParameter("@BRCPhone", SqlDbType.NVarChar), 
                                                new SqlParameter("@BRCEmail ", SqlDbType.NVarChar), 
                                                new SqlParameter("@Fax ", SqlDbType.NVarChar), 
                                                new SqlParameter("@BRCTimezone ", SqlDbType.NVarChar),                                                
                                                new SqlParameter("@op ", SqlDbType.NVarChar),
                                                new SqlParameter("@BRCID", SqlDbType.Int), 
                                                
                                            
                                            };
                parameters[0].Value = BRCName;
                parameters[1].Value = BRCLocation;
                parameters[2].Value = BRCDaysHours;
                parameters[3].Value = Phone;
                parameters[4].Value = EmailAddress;
                parameters[5].Value = Fax;
                parameters[6].Value = BRCTimeZone;
                parameters[7].Value = flag;
                parameters[8].Value = BRCID;

                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBRCLocation", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return IsSuccess;
        }

        public DataTable GetBRCCenterDayHours()
        {

            DataTable dtblCenterDayHours = new DataTable();
            try
            {
                dtblCenterDayHours = DB_helper.ExecProcedure("GeTBRCCenterDatsHours", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblCenterDayHours;
        }

        public DataTable GetBRCLocationById(int id)
        {
            DataTable dtbl = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ID ", SqlDbType.NVarChar) };
                parameters[0].Value = id;
                dtbl = DB_helper.ExecProcedure("GetBRCLocationById", parameters);//("select Office_name from dbo.BROKER_OFFICE");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtbl;
        }

        public bool DeleteBRCLocationDetails(int Id)
        {
            bool IsSuccess = false;
            try
            {
                // IsActive = false;                
                string flag = "Delete";
                SqlParameter[] parameters = { new SqlParameter("@BRCID ", SqlDbType.NVarChar), new SqlParameter("@op ", SqlDbType.NVarChar) };
                parameters[0].Value = Id;
                parameters[1].Value = flag;
                DataTable dtblResult = DB_helper.ExecProcedure("InsertUpdateDeleteBRCLocation", parameters);
                IsSuccess = bool.Parse(dtblResult.Rows[0]["IsSuccess"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return IsSuccess;
        }

        public DataTable GetBRCTimeZoneDataList()
        {
            DataTable dtblStates;
            try
            {
                dtblStates = DB_helper.ExecProcedure("GetBRC_TimeZone_Data", null);//("select Office_State from dbo.BRC_Region&Office");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtblStates;
        }
        #endregion

    }
}