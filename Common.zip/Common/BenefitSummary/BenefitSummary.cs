﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class BenefitSummarydata
    { 
        #region Variable
        private int _benefitsummmaryId;
        private int _productId;
        private string _description;
        #endregion
        #region Properties
        /// <summary>
        /// Get and Set  BenefitsummmaryId
        /// </summary>
        public int BenefitsummmaryId
        {
            get
            {
                return _benefitsummmaryId;
            }
            set
            {
                _benefitsummmaryId = value;
            }
        }
        /// <summary>
        /// Get and Set  BenefitsummmaryDescription
        /// </summary>
        public string BenefitDescription
        {
            get
            {
               return _description;
            }
            set
            {
                _description = value;
            }
        }

        public int ProductId
        {
            get
            {
                return _productId;
            }
            set
            {
                _productId = value;
            }
        }
        #endregion
    }
}