﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate8_AnnualLegalNotices : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        /// <param name="ddlCoverPage">DropDownList ddlCoverPage Object</param>
        /// <param name="ddlClient">DropDownList ddlClient Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice Object</param>
        /// <param name="OfficeTable">DataTable OfficeTable Object</param>
        public void WriteNoticeSectionToTemplate8(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, CheckBoxList chkAnualNotice, DropDownList ddlClient, DropDownList ddlOffice, DataTable OfficeTable, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                int cntCreditable = 0;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CoverPage"))
                        {
                            myMergeField.Select();
                            //if (ddlCoverPage.SelectedIndex == 1)
                            //{
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();

                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                            for (int i = chkAnualNotice.Items.Count - 1; i >= 0; i--)
                            {
                                if (ddlCreditableCoverage.SelectedIndex > 0)
                                {
                                    cntCreditable++;
                                    break;
                                }
                            }

                            if (cntCreditable == 0)
                            {
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/LegalNotce_CoverPage.docx"), missing, true, missing, missing);
                            }
                            else if (cntCreditable > 0)
                            {
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/LegalNotice_CoverPage_CreditableDisclosure.docx"), missing, true, missing, missing);
                            }
                            //}
                            //else
                            //{
                            //    myMergeField.Delete();
                            //    oWordApp.Selection.Delete();
                            //}
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //For word page break-03 June 2014
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                            }
                            // Loop added by Vaibhav and Shravan Date: 19-04-2018 for spanish templete in legal notice
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                // for spanish
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //For word page break-03 June 2014
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);

                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing); // to be change by actual path of spanish template
                                foreach (Section hdr in oWordDoc.Sections)
                                {
                                    hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                    hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                }
                                if (cntCreditable > 0)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                    foreach (Section hdr in oWordDoc.Sections)
                                    {
                                        hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                        hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                    }
                                }

                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            // Loop added by Vaibhav and Shravan Date: 19-04-2018 for spanish templete in legal notice
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016_Spanish.doc"), missing, true, missing, missing); // to be change with actual spanish document
                                if (cntCreditable > 0)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                    foreach (Section hdr in oWordDoc.Sections)
                                    {
                                        hdr.Headers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                        hdr.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary].LinkToPrevious = false;
                                    }
                                }
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {

                            myMergeField.Select();

                            //if (ddlCoverPage.SelectedIndex == 1)
                            //{
                            //  oWordApp.Selection.TypeText("\f");
                            //}
                            //else
                            //{
                            //    oWordApp.Selection.TypeBackspace();
                            //}

                            oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            //}
                            //else
                            //{
                            //    myMergeField.Delete();
                            //}
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            //if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            //{
                            myMergeField.Delete();
                            object missing = System.Type.Missing;
                            Word.Range r = oWordDoc.Range();
                            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                            // Call common function to take notices
                            // comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            //}
                            //else
                            //{
                            //    myMergeField.Delete();
                            //}
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields

                /*********** THIS CODE COMMENED FOR NEW REQUIREMENT - BY AMOGH & SHRAVAN */
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
                /****************************************************************************/

                //  Added by Vaibhav for spanish template on 25/04/2018 
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true);

                // Call common function to write the client name on the cover page
                comFunObj.WriteFieldsForCoverPage(oWordDoc, oWordApp, ddlClient, ddlOffice, OfficeTable);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}