﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.Client_Agreements
{
    public class Fee_Exhibits
    {
        public void WriteFileds_OnSiteClientFeeExhibits(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, string LegalEntity)
        {
            #region MergeField
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {

                Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;    // -- Only One Field
                        
                    }

                    if (fieldName.Contains("InsertLegalName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(LegalEntity);
                        continue;    // -- Only One Field
                   
                    }
                }
            }
            #endregion
        }
    }
}