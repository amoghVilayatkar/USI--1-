﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using System.Text;

namespace BenefitPointSummaryPortal.BAL.ClientServiceUtility
{
   public abstract class ClientServiveFactory
    {
        #region properties
        //account
        protected DataTable account_table = new DataTable();
        protected DataTable accountCustomFieldValues_table = new DataTable();
        protected DataTable accountEmployeeTypesValues_table = new DataTable();
        protected DataTable account_Team_memeber = new DataTable();
        #endregion
        #region Abstract Method
        public abstract List<Account> FindAccounts(int Selectedindex, string SessionId, string txtsearch);
        public abstract List<Contact> FindContacts(string Selectedindex, string SessionId, string reportname = "");
        public abstract DataSet GetAccountDetail(int account_id, string SessionId);
        public abstract DataSet GetTeamMembers(int account_id, string SessionId);
        public abstract DataTable GetOfficeDetail(int account_id, string SessionId);
        #endregion
        #region Concrete Methods
        public void BuildAccountTable()
        {
            try
            {
                #region accounttables

                #region account_datatable

                account_table.Columns.Add("accountID", typeof(string));  // Row 0
                account_table.Columns.Add("active", typeof(bool));  // Row 1
                account_table.Columns.Add("inactiveAsOf", typeof(DateTime));  // Row 2
                account_table.Columns.Add("inactiveReason", typeof(string));  // Row 3
                account_table.Columns.Add("accountClassification", typeof(string));  // Row 4
                account_table.Columns.Add("accountType", typeof(string));  // Row 5
                account_table.Columns.Add("officeID", typeof(Int32));  // Row 6
                account_table.Columns.Add("departmentID", typeof(Int32));  // Row 7
                account_table.Columns.Add("administratorUserID", typeof(Int32));  // Row 8
                account_table.Columns.Add("primaryContactUserID", typeof(Int32));  // Row 9
                account_table.Columns.Add("primarySalesLeadUserID", typeof(Int32));  // Row 10
                account_table.Columns.Add("primaryServiceLeadUserID", typeof(Int32));  // Row 11
                account_table.Columns.Add("notes", typeof(string));  // Row 12            
                account_table.Columns.Add("lastReviewedByUserID", typeof(Int32));  // Row 13
                account_table.Columns.Add("lastReviewedOn", typeof(DateTime));  // Row 14
                account_table.Columns.Add("createdOn", typeof(DateTime));  // Row 15
                account_table.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 16
                account_table.Columns.Add("Blank", typeof(bool));  // Row 17          
                account_table.Columns.Add("mainAddress_street1", typeof(string));  // Row 18
                account_table.Columns.Add("mainAddress_street2", typeof(string));  // Row 19
                account_table.Columns.Add("mainAddress_city", typeof(string));  // Row 20
                account_table.Columns.Add("mainAddress_state", typeof(string));  // Row 21
                account_table.Columns.Add("mainAddress_zip", typeof(string));  // Row 22
                account_table.Columns.Add("mainAddress_country", typeof(string));  // Row 23
                account_table.Columns.Add("billingAddress_street1", typeof(string));  // Row 24
                account_table.Columns.Add("billingAddress_street2", typeof(string));  // Row 25
                account_table.Columns.Add("billingAddress_city", typeof(string));  // Row 26
                account_table.Columns.Add("billingAddress_state", typeof(string));  // Row 27
                account_table.Columns.Add("billingAddress_zip", typeof(string));  // Row 28
                account_table.Columns.Add("billingAddress_country", typeof(string));  // Row 29
                account_table.Columns.Add("mailingAddress_street1", typeof(string));  // Row 30
                account_table.Columns.Add("mailingAddress_street2", typeof(string));  // Row 31
                account_table.Columns.Add("mailingAddress_city", typeof(string));  // Row 32
                account_table.Columns.Add("mailingAddress_state", typeof(string));  // Row 33
                account_table.Columns.Add("mailingAddress_zip", typeof(string));  // Row 34
                account_table.Columns.Add("mailingAddress_country", typeof(string));  // Row 35
                account_table.Columns.Add("groupAccountInfo_accountName", typeof(string));  // Row 36
                account_table.Columns.Add("groupAccountInfo_DBA", typeof(string));  // Row 37
                account_table.Columns.Add("groupAccountInfo_numberOfFTEs", typeof(Int32));  // Row 38
                account_table.Columns.Add("groupAccountInfo_numberOfFTEsAsOf", typeof(DateTime));  // Row 39
                account_table.Columns.Add("groupAccountInfo_marketSize", typeof(string));  // Row 40
                account_table.Columns.Add("groupAccountInfo_businessType", typeof(string));  // Row 41
                account_table.Columns.Add("groupAccountInfo_SICCode", typeof(string));  // Row 42
                account_table.Columns.Add("groupAccountInfo_NAICSCode", typeof(string));  // Row 43
                account_table.Columns.Add("groupAccountInfo_requires5500", typeof(bool));  // Row 44
                account_table.Columns.Add("groupAccountInfo_locationsByZip", typeof(string));  // Row 45
                account_table.Columns.Add("groupAccountInfo_affiliates", typeof(string));  // Row 46
                account_table.Columns.Add("groupAccountInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 47
                account_table.Columns.Add("groupAccountInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 48
                account_table.Columns.Add("groupAccountInfo_multiplePayrollCycles", typeof(bool));  // Row 49
                account_table.Columns.Add("groupAccountInfo_multiplePayrollCyclesDifferBy", typeof(string));  // Row 50
                account_table.Columns.Add("groupAccountInfo_singlePayrollCycle", typeof(string));  // Row 51
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_numberOfRetirees", typeof(Int32));  // Row 52
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf", typeof(DateTime));  // Row 53
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_yearEstablished", typeof(Int32));  // Row 54
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_accountFundingType", typeof(string));  // Row 55
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_primaryIndustry", typeof(string));  // Row 56
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_secondaryIndustry", typeof(string));  // Row 57
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_otherPrimaryIndustry", typeof(string));  // Row 58
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_otherSecondaryIndustry", typeof(string));  // Row 59
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_taxpayerID", typeof(string));  // Row 60
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_website", typeof(string));  // Row 61
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_accountNumber", typeof(string));  // Row 62
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf", typeof(DateTime));  // Row 63
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAARequired", typeof(bool));  // Row 64
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn", typeof(DateTime));  // Row 65
                account_table.Columns.Add("individualAccountInfo_personInfo_firstName", typeof(string));  // Row 66
                account_table.Columns.Add("individualAccountInfo_personInfo_middleName", typeof(string));  // Row 67
                account_table.Columns.Add("individualAccountInfo_personInfo_lastName", typeof(string));  // Row 68
                account_table.Columns.Add("individualAccountInfo_personInfo_salutation", typeof(string));  // Row 69
                account_table.Columns.Add("individualAccountInfo_personInfo_dateOfBirth", typeof(DateTime));  // Row 70
                account_table.Columns.Add("individualAccountInfo_personInfo_gender", typeof(string));  // Row 71
                account_table.Columns.Add("individualAccountInfo_personInfo_ssn", typeof(string));  // Row 72
                account_table.Columns.Add("individualAccountInfo_personInfo_maritalStatus", typeof(string));  // Row 73
                account_table.Columns.Add("individualAccountInfo_email", typeof(string));  // Row 74
                account_table.Columns.Add("individualAccountInfo_phone_areaCode", typeof(string));  // Row 75
                account_table.Columns.Add("individualAccountInfo_phone_number", typeof(string));  // Row 76
                account_table.Columns.Add("individualAccountInfo_phone_type", typeof(string));  // Row 77
                account_table.Columns.Add("individualAccountInfo_affiliatedGroupAccountID", typeof(Int32));  // Row 78
                account_table.Columns.Add("marketingGroupAccountInfo_marketingGroupName", typeof(string));  // Row 79
                account_table.Columns.Add("marketingGroupAccountInfo_marketingGroupType", typeof(string));  // Row 80
                account_table.Columns.Add("marketingGroupAccountInfo_numberOfFTEs", typeof(Int32));  // Row 81
                account_table.Columns.Add("marketingGroupAccountInfo_numberOfFTEsAsOf", typeof(DateTime));  // Row 82
                account_table.Columns.Add("marketingGroupAccountInfo_associatedAccountIDs", typeof(Int32));  // Row 83
                account_table.Columns.Add("agencyAccountInfo_agencyName", typeof(string));  // Row 84
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_email", typeof(string));  // Row 85
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_areaCode", typeof(string));  // Row 86
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_areaCode", typeof(string));  // Row 87
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_areaCode", typeof(string));  // Row 88
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_areaCode", typeof(string));  // Row 89
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_number", typeof(string));  // Row 90
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_number", typeof(string));  // Row 91
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_number", typeof(string));  // Row 92
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_number", typeof(string));  // Row 93
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_type", typeof(string));  // Row 94
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_type", typeof(string));  // Row 95
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_type", typeof(string));  // Row 96
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_type", typeof(string));  // Row 97
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_taxPayerID", typeof(string));  // Row 98
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 99
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 100
                account_table.Columns.Add("agentAccountInfo_personInfo_firstName", typeof(string));  // Row 101
                account_table.Columns.Add("agentAccountInfo_personInfo_middleName", typeof(string));  // Row 102
                account_table.Columns.Add("agentAccountInfo_personInfo_lastName", typeof(string));  // Row 103
                account_table.Columns.Add("agentAccountInfo_personInfo_salutation", typeof(string));  // Row 104
                account_table.Columns.Add("agentAccountInfo_personInfo_dateOfBirth", typeof(DateTime));  // Row 105
                account_table.Columns.Add("agentAccountInfo_personInfo_gender", typeof(string));  // Row 106
                account_table.Columns.Add("agentAccountInfo_personInfo_ssn", typeof(string));  // Row 107
                account_table.Columns.Add("agentAccountInfo_personInfo_maritalStatus", typeof(string));  // Row 108
                account_table.Columns.Add("agentAccountInfo_agencyAccountID", typeof(Int32));  // Row 109
                account_table.Columns.Add("agentAccountInfo_agentInfo_email", typeof(string));  // Row 110
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_areaCode", typeof(string));  // Row 111
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_areaCode", typeof(string));  // Row 112
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_areaCode", typeof(string));  // Row 113
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_areaCode", typeof(string));  // Row 114
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_number", typeof(string));  // Row 115
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_number", typeof(string));  // Row 116
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_number", typeof(string));  // Row 117
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_number", typeof(string));  // Row 118
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_type", typeof(string));  // Row 119
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_type", typeof(string));  // Row 120
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_type", typeof(string));  // Row 121
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_type", typeof(string));  // Row 122
                account_table.Columns.Add("agentAccountInfo_agentInfo_taxPayerID", typeof(string));  // Row 123
                account_table.Columns.Add("agentAccountInfo_agentInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 124
                account_table.Columns.Add("agentAccountInfo_agentInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 125
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_numberOfRetirees", typeof(Int32));  // Row 126
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf", typeof(DateTime));  // Row 127
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_yearEstablished", typeof(Int32));  // Row 128
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_accountFundingType", typeof(string));  // Row 129
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_primaryIndustry", typeof(string));  // Row 130
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_secondaryIndustry", typeof(string));  // Row 131
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_otherPrimaryIndustry", typeof(string));  // Row 132
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_otherSecondaryIndustry", typeof(string));  // Row 133
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_taxpayerID", typeof(string));  // Row 134
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_website", typeof(string));  // Row 135
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_accountNumber", typeof(string));  // Row 136
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf", typeof(DateTime));  // Row 137
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAARequired", typeof(bool));  // Row 138
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn", typeof(DateTime));  // Row 139            
                account_table.Columns.Add("sagittaClientID", typeof(string));// Row 140
                account_table.Columns.Add("sourceCode", typeof(string));// Row 141
                account_table.Columns.Add("primarySalesLeadIntCode", typeof(string));// Row 142
                account_table.Columns.Add("primaryServiceLeadIntCode", typeof(string));// Row 143 
                account_table.Columns.Add("TAMCustomer", typeof(string));// Row 144
                account_table.Columns.Add("groupAccountInfo_numberOfFullTimeEquivalents", typeof(Int32));  // Row 145
                account_table.Columns.Add("groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate", typeof(DateTime));  // Row 146

                #endregion


                accountCustomFieldValues_table.Columns.Add("accountID", typeof(Int32));  // Row 0
                accountCustomFieldValues_table.Columns.Add("customFieldValues_customFieldValueID", typeof(Int32));  // Row 1
                accountCustomFieldValues_table.Columns.Add("customFieldValues_customFieldID", typeof(Int32));  // Row 2
                accountCustomFieldValues_table.Columns.Add("customFieldValues_optionValueID", typeof(Int32));  // Row 3
                accountCustomFieldValues_table.Columns.Add("customFieldValues_valueText", typeof(string));  // Row 4
                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        public void BuildAccountTeamMamberTable()
        {
            try
            {
                account_Team_memeber.Columns.Add("userID", typeof(string));  // Row 0
                account_Team_memeber.Columns.Add("firstName", typeof(string));  // Row 1
                account_Team_memeber.Columns.Add("lastName", typeof(string));  // Row 2
                account_Team_memeber.Columns.Add("email", typeof(string));  // Row 3
                account_Team_memeber.Columns.Add("role", typeof(string));  // Row 4
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        #endregion
    }
}