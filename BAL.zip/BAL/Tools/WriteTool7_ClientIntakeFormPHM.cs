﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;

namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTool7_ClientIntakeFormPHM : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        ConstantValue cv = new ConstantValue();

        public void WriteFieldToTools7_ClientIntakeFormWellnessPHM(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, string SessionId, DataTable PlanTable, DataSet BenefitDS)
        {
            try
            {
                int count = 1;
                string value = string.Empty;

                #region HashtableWellness
                Hashtable HashtableWellness = new Hashtable();
                HashtableWellness.Add(1, "903");              //Biometric Screenings
                HashtableWellness.Add(2, "910");              //Health Assessments
                HashtableWellness.Add(3, "914");              //Weight Management
                HashtableWellness.Add(4, "944");              //Personalized Wellness Portal
                HashtableWellness.Add(5, "904");              //Flu Shots
                HashtableWellness.Add(6, "913");              //Health Coaching
                HashtableWellness.Add(7, "920");              //Points Based Program
                #endregion

                for (int k = 0; k < PlanTable.Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.Wellness.ToLower().Trim())
                    {
                        #region Wellness

                        oWordDoc.Tables[7].Cell(1, 1).Select();

                        foreach (int key in HashtableWellness.Keys)
                        {
                            foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            {
                                if (dr["section"].ToString().ToLower().Trim() == cv.Wellness.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && dr["attributeID"].ToString() == HashtableWellness[key].ToString())
                                {
                                    value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    switch (key)
                                    {
                                        case 1: if (value != null)
                                                oWordDoc.Tables[7].Cell(2, 2).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(2, 2).Range.Text = " ";
                                            break;
                                        case 2: if (value != null)
                                                oWordDoc.Tables[7].Cell(3, 2).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(3, 2).Range.Text = " ";
                                            break;
                                        case 3: if (value != null)
                                                oWordDoc.Tables[7].Cell(4, 2).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(4, 2).Range.Text = " ";
                                            break;
                                        case 4: if (value != null)
                                                oWordDoc.Tables[7].Cell(5, 2).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(5, 2).Range.Text = " ";
                                            break;
                                        case 5: if (value != null)
                                                oWordDoc.Tables[7].Cell(2, 4).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(2, 4).Range.Text = " ";
                                            break;
                                        case 6: if (value != null)
                                                oWordDoc.Tables[7].Cell(3, 4).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(3, 4).Range.Text = " ";
                                            break;
                                        case 7: if (value != null)
                                                oWordDoc.Tables[7].Cell(4, 4).Range.Text = value;
                                            else
                                                oWordDoc.Tables[7].Cell(4, 4).Range.Text = " ";
                                            break;
                                    }
                                }
                            }
                        }
                        #endregion
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFieldToTools7_ClientIntakeFormMedicalPHM(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                int count = 1;
                string value = string.Empty;

                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                HashtableMedical.Add(1, "571");            //Preventive Care[Well-Child Care]
                HashtableMedical.Add(2, "16");             //Preventive Care - Adult Periodic Exams with Preventive Tests
                #endregion

                for (int k = 0; k < PlanTable.Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        #region Medical
                        oWordDoc.Tables[6].Rows.Add();
                        count++;
                        oWordDoc.Tables[6].Cell(1, 1).Select();
                        oWordDoc.Tables[6].Cell(count, 1).Range.Text = PlanTable.Rows[k]["Name"].ToString();
                        CallDropdown(oWordDoc, count);

                        foreach (int key in HashtableMedical.Keys)
                        {
                            foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            {
                                if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                {
                                    if (!string.IsNullOrEmpty(BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"].ToString()))
                                        oWordDoc.Tables[6].Cell(count, 2).Range.Text = BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"].ToString();
                                    else
                                        oWordDoc.Tables[6].Cell(count, 2).Range.Text = " ";
                                    value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    switch (key)
                                    {
                                        case 1: if (value != null)
                                                oWordDoc.Tables[6].Cell(count, 3).Range.Text = value;
                                            else
                                                oWordDoc.Tables[6].Cell(count, 3).Range.Text = " ";
                                            break;
                                        case 2: if (value != null)
                                                oWordDoc.Tables[6].Cell(count, 4).Range.Text = value;
                                            else
                                                oWordDoc.Tables[6].Cell(count, 4).Range.Text = value;
                                            break;
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFieldToTools7_ClientIntakeFormPHM(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable PlanTable, string Office_Region, int engagement, DataTable dtNewAcctContactList)
        {
            try
            {
                DataTable dt = new DataTable();
                dtNewAcctContactList.DefaultView.Sort = "[PrimaryContact] asc";
                dt = dtNewAcctContactList.DefaultView.ToTable(true);
                dtNewAcctContactList = dt;

                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                
                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Hipaa_Signed_On = string.Empty;
                string website = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;
                string federalTaxpayer = string.Empty;
                string businessType = string.Empty;
                string accountFunding = string.Empty;

                string Street1 = string.Empty;
                string Street2 = string.Empty;
                string City = string.Empty;
                string State = string.Empty;
                string Zip = string.Empty;
                string Country = string.Empty;

                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;
                string sname = string.Empty;
                string stitle = string.Empty;
                string semail = string.Empty;
                string sphoneNumber = string.Empty;
                string threeDEngagement = string.Empty;
                string priIndustry = string.Empty;
                string primaryIndustry = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");

                //3D Engagement
                switch (engagement)
                {
                    case 108871: threeDEngagement = "Engaged"; break;
                    case 108870: threeDEngagement = "Select"; break;
                    case 108873: threeDEngagement = "Client Declined"; break;
                    case 108872: threeDEngagement = "Ineligible"; break;
                    default: threeDEngagement = ""; break;
                }

                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                priIndustry = Convert.ToString(pIndustry.First()).Replace(@"_", " ");
                DataTable dt1 = bp.GetBenchmarkingGrp(priIndustry);
                if(dt1.Rows.Count > 0)
                    primaryIndustry = dt1.AsEnumerable().First().Field<string>("Benchmarking_Grouping");

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        //ServiceLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"])))
                            {
                                Required_5500 = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"]);

                                if (Required_5500.ToLower() == "false")
                                {
                                    Required_5500 = "No";
                                }
                                else if (Required_5500.ToLower() == "true")
                                {
                                    Required_5500 = "Yes";
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_website"])))
                            {
                                website = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_website"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn"]), out dateValue) == true)
                                {
                                    Hipaa_Signed_On = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"])))
                            {
                                Primary_Industry = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"]);
                                Primary_Industry = Primary_Industry.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"])))
                            {
                                Num_Of_Retiree = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_Retiree_As_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"])))
                            {
                                federalTaxpayer = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_businessType"])))
                            {
                                businessType = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_businessType"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_accountFundingType"])))
                            {
                                accountFunding = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_accountFundingType"]);
                            }


                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_country"])))
                            {
                                Country = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_country"]);
                            }
                        }
                    }

                }

                #endregion

                //for (int k = 0; k < ActivityInfoTable.Rows.Count; k++)
                //{
                //if (ActivityInfoTable.Rows[k]["recordID"].ToString() == ActivityDS.Tables["activityrecord_table"].Rows[0]["recordID"].ToString())
                //{

                if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                {
                    #region Write Table of Account Contacts for client Intake
                    //Tools_Constant tc = new Tools_Constant();
                    //string accountInfo = string.Empty;
                    int clmCnt1 = 0;

                    if (ContactList != null)
                    {
                        if (dtNewAcctContactList.Rows.Count > 0)
                        {
                            for (int j = 0; j < dtNewAcctContactList.Rows.Count; j++)
                            {
                                for (int i = 0; i < ContactList.Count; i++)
                                {
                                    if (dtNewAcctContactList.Rows[j]["ID"].ToString() == Convert.ToString(ContactList[i].ContactId))
                                    {
                                        //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                        //{
                                        ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                        //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                        //{
                                        //if (clmCnt > 1)
                                        //{
                                        //    oWordDoc.Tables[2].Columns.Add();
                                        //}
                                        clmCnt1++;
                                        if (clmCnt1 == 1)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                name = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                name = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                title = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                title = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                email = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                email = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                phoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                phoneNumber = " ";
                                            }
                                        }
                                        if (clmCnt1 == 2)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                sname = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                sname = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                stitle = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                stitle = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                semail = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                semail = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                sphoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                sphoneNumber = " ";
                                            }
                                        }
                                        //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 1).Range.Text = name;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 2).Range.Text = title;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 3).Range.Text = phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 4).Range.Text = email;
                                        //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);

                                        //clmCnt++;

                                        //if (clmCnt > 3)
                                        //{
                                        //    break;
                                        //}
                                        //}
                                        //}
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                }
                else
                {
                    #region Write Table of Account Contacts

                    int clmCnt = 0;

                    if (ContactList != null)
                    {
                        if (arrAcctContact.Count > 0)
                        {
                            for (int j = 0; j < arrAcctContact.Count; j++)
                            {
                                for (int i = 0; i < ContactList.Count; i++)
                                {
                                    if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                    {
                                        //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                        //{
                                        ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                        //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                        //{
                                        //if (clmCnt > 1)
                                        //{
                                        //    oWordDoc.Tables[2].Columns.Add();
                                        //}
                                        clmCnt++;
                                        if (clmCnt == 1)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                name = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                name = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                title = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                title = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                email = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                email = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                phoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                phoneNumber = " ";
                                            }
                                        }
                                        if (clmCnt == 2)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                sname = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                sname = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                stitle = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                stitle = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                semail = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                semail = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                sphoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                sphoneNumber = " ";
                                            }
                                        }
                                        //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 1).Range.Text = name;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 2).Range.Text = title;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 3).Range.Text = phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 4).Range.Text = email;
                                        //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);

                                        //clmCnt++;

                                        //if (clmCnt > 3)
                                        //{
                                        //    break;
                                        //}
                                        //}
                                        //}
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                }

                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }



                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        //if (fieldName.Contains("Legal Name"))
                        //{
                        //    myMergeField.Select();
                        //    oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                        //    continue;
                        //}

                        if (fieldName.Contains("Legal Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("Service Team"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }
                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Street Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Street1) || !string.IsNullOrEmpty(Street2))
                            {
                                oWordApp.Selection.TypeText(Street1 + " " + Street2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("City"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(City))
                            {
                                oWordApp.Selection.TypeText(City);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("State"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(State))
                            {
                                oWordApp.Selection.TypeText(State);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Zip"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Zip))
                            {
                                oWordApp.Selection.TypeText(Zip);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("5500 Required"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Required_5500))
                            {
                                oWordApp.Selection.TypeText(Required_5500);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }



                        if (fieldName.Contains("Primary Industry"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Primary_Industry))
                            {
                                oWordApp.Selection.TypeText(Primary_Industry);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("TaxpayerID"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(federalTaxpayer))
                            {
                                oWordApp.Selection.TypeText(federalTaxpayer);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Website"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(website))
                            {
                                oWordApp.Selection.TypeText(website);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Business Type"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(businessType))
                            {
                                oWordApp.Selection.TypeText(businessType.Replace(@"_", " "));
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Account Funding"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(accountFunding))
                            {
                                oWordApp.Selection.TypeText(accountFunding);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Date Signed"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Hipaa_Signed_On))
                            {
                                oWordApp.Selection.TypeText(Hipaa_Signed_On);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of FTE"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(phoneNumber))
                            {
                                oWordApp.Selection.TypeText(phoneNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(email))
                            {
                                oWordApp.Selection.TypeText(email);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(sname))
                            {
                                oWordApp.Selection.TypeText(sname);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(stitle))
                            {
                                oWordApp.Selection.TypeText(stitle);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(sphoneNumber))
                            {
                                oWordApp.Selection.TypeText(sphoneNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(semail))
                            {
                                oWordApp.Selection.TypeText(semail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("3D Engagement"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(threeDEngagement))
                            {
                                oWordApp.Selection.TypeText(threeDEngagement);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Benchmarking Industry"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(primaryIndustry))
                            {
                                oWordApp.Selection.TypeText(primaryIndustry);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                    }
                }
                #endregion

                #region TeamTable
                oWordDoc.Tables[1].Cell(1, 2).Select();
                oWordDoc.Tables[1].Cell(1, 2).Range.Text = DateTime.Today.ToString("MM/dd/yyyy");

                //Service Lead
                if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                {
                    oWordDoc.Tables[1].Cell(3, 2).Select();
                    oWordDoc.Tables[1].Cell(3, 2).Range.Text = ServiceLead_FirstName + " " + ServiceLead_LastName;
                    //  oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                }
                else
                {
                    oWordApp.Selection.TypeText(" ");
                }

                //Sales Lead
                if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                {
                    oWordDoc.Tables[1].Cell(4, 2).Select();
                    oWordDoc.Tables[1].Cell(4, 2).Range.Text = SalesLead_FirstName + " " + SalesLead_LastName;
                    // oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                }
                else
                {
                    oWordApp.Selection.TypeText(" ");
                }
                //Broker_Of_Record
                if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                {
                    oWordDoc.Tables[1].Cell(6, 2).Select();
                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = Broker_Of_Record;
                    //oWordApp.Selection.TypeText(Broker_Of_Record);
                }
                else
                {
                    oWordApp.Selection.TypeText(" ");
                }
                #endregion

                #region Plan Details
                int count = 1;
                string[] arr;
                string benefitSum = String.Empty;
                string voluntary = String.Empty;
                int OptionFieldValueiD;
                string FundingType = "";
                Object missing = System.Reflection.Missing.Value;
                string strShared = "Shared";
                string strErpaid = "ER Paid";
                string strEepaid = "EE Paid";
                string strNot = "Not Specified";

                DataView view = new DataView(PlanTable);
                DataTable PlanTableDistinct = view.ToTable(true, "Carrier", "Name", "Effective", "Renewal", "PolicyNumber", "ProductId", "ProductName", "ProductTypeId", "PlanType");

                if (PlanTableDistinct != null && PlanTableDistinct.Rows.Count > 0)
                {
                    foreach (DataRow row in PlanTableDistinct.Rows)
                    {
                        if (row["PlanType"].ToString().ToLower().Trim() != cv.MedicalPlanType.ToLower().Trim() && row["PlanType"].ToString().ToLower().Trim() != cv.Wellness.ToLower().Trim())
                        {
                            arr = (row["ProductName"].ToString()).Split('/');
                            benefitSum = arr[1];
                            //voluntary = arr[2];

                            //Funding
                            OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(row["ProductId"].ToString()), SessionId);
                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self-Insured"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }

                            //Voluntary
                            if (row["ProductName"].ToString() != null)
                            {
                                if (row["ProductName"].ToString().Trim().ToLower().Contains("shared"))
                                {
                                    voluntary = strShared;
                                }
                                else if (row["ProductName"].ToString().Trim().ToLower().Contains("er paid"))
                                {
                                    voluntary = strErpaid;
                                }
                                else if (row["ProductName"].ToString().Trim().ToLower().Contains("ee paid"))
                                {
                                    voluntary = strEepaid;
                                }
                                else
                                {
                                    voluntary = strNot;
                                }
                            }
                            else
                            {
                                voluntary = strNot;
                            }
                            if(count > 1)
                               oWordDoc.Tables[8].Rows.Add();
                            count++;
                            oWordDoc.Tables[8].Cell(count, 1).Select();
                            if (!string.IsNullOrEmpty(row["Name"].ToString()))
                                oWordDoc.Tables[8].Cell(count, 1).Range.Text = row["Name"].ToString();
                            else
                                oWordDoc.Tables[8].Cell(count, 1).Range.Text = " ";
                            if (!string.IsNullOrEmpty(row["Carrier"].ToString()))
                                oWordDoc.Tables[8].Cell(count, 2).Range.Text = row["Carrier"].ToString();
                            else
                                oWordDoc.Tables[8].Cell(count, 2).Range.Text = " ";
                            if(!string.IsNullOrEmpty(benefitSum))
                                oWordDoc.Tables[8].Cell(count, 3).Range.Text = benefitSum;
                            else
                                oWordDoc.Tables[8].Cell(count, 3).Range.Text = " ";
                            if(!string.IsNullOrEmpty(FundingType))
                                oWordDoc.Tables[8].Cell(count, 4).Range.Text = FundingType;
                            else
                                oWordDoc.Tables[8].Cell(count, 4).Range.Text = " ";
                            if (!string.IsNullOrEmpty(row["Renewal"].ToString()))
                                oWordDoc.Tables[8].Cell(count, 5).Range.Text = row["Renewal"].ToString();
                            else
                                oWordDoc.Tables[8].Cell(count, 5).Range.Text = " ";
                            if (!string.IsNullOrEmpty(voluntary))
                                oWordDoc.Tables[8].Cell(count, 6).Range.Text = voluntary;
                            else
                                oWordDoc.Tables[8].Cell(count, 6).Range.Text = " ";
                        }
                    }
                }
                else if (PlanTableDistinct.Rows.Count == 0)
                {
                    count++;
                    oWordDoc.Tables[8].Cell(count, 1).Select();
                    oWordDoc.Tables[8].Cell(count, 1).Range.Text = "";
                    oWordDoc.Tables[8].Cell(count, 2).Range.Text = "";
                    oWordDoc.Tables[8].Cell(count, 3).Range.Text = "";
                    oWordDoc.Tables[8].Cell(count, 4).Range.Text = "";
                    oWordDoc.Tables[8].Cell(count, 5).Range.Text = "";
                    oWordDoc.Tables[8].Cell(count, 6).Range.Text = "";
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void CallDropdown(Word.Document oWordDoc, int i)
        {
            try
            {
                Range range = oWordDoc.Tables[6].Cell(i, 5).Range;
                range.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range);
                foreach (Word.ContentControl dropdown in range.ContentControls)
                {
                    dropdown.DropdownListEntries.Clear();
                    dropdown.DropdownListEntries.Add("Every 12 months", "first", 1);
                    dropdown.DropdownListEntries.Add("Once per Calendar year", "second", 2);
                    dropdown.DropdownListEntries.Add("Once per Plan year", "third", 3);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}