﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.OpenEnrollmentMemo;
using BenefitPointSummaryPortal.Common.OpenCloseWord;

namespace BenefitPointSummaryPortal.View
{
    public partial class OpenEnrollmentMemos : System.Web.UI.Page
    {
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
        string SessionId = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        private static string Activity = "";
        private static string Activity_Group = "";
        private static readonly string DeliverableCategory = "Employee Communications";
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        public Dictionary<string, bool> DictImageOptionMap = new Dictionary<string, bool>();
        public Dictionary<string, bool> DictColorOptionMap = new Dictionary<string, bool>();

        BRCData BRCDetails = new BRCData();
        DataSet AccountDS = new DataSet();
        DataSet AccountTeamMemberDS = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                LoadDisplyStatusData();
                if (!IsPostBack)
                {
                    ddlMemoType.SelectedValue = "Short";
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    Activity = "Open Enrollment Memos";
                    Activity_Group = "Employee Communications";

                    objCommFun.GetUserDetails();
                    mvExperienceReport.ActiveViewIndex = 0;
                    txtsearch.Focus();
                    BindColorDropDown();
                    ddlIsMobileAppOffered_SelectedIndexChanged(null, null);
                    ddlMemoStyle_SelectedIndexChanged(null, null);

                    BindImageDropDown();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }

        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlMemoStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlColor.SelectedValue = WriteOpenEnrollmentMemo_BayView.ColorOptions.Grey.ToString();
            ddlImageOption.SelectedIndex = 0;
            string SelectedMemoOption = ddlMemoStyle.SelectedValue;
            ddlColor.Enabled = false;
            ddlImageOption.Enabled = false;

            #region Color Option Processing
            if (DictColorOptionMap.ContainsKey(SelectedMemoOption))
                if (DictColorOptionMap[SelectedMemoOption])
                    ddlColor.Enabled = true;
            #endregion

            #region Image Option Processing
            if (DictImageOptionMap.ContainsKey(SelectedMemoOption))
                if (DictImageOptionMap[SelectedMemoOption])
                    ddlImageOption.Enabled = true;
            #endregion
        }
        private void ResetForm()
        {
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;

            ddlHRContact.Items.Clear();
            ddlHRContact.Items.Insert(0, new ListItem("Select", "Select"));

            ddlBRC.SelectedIndex = 0;

            txtRenewalDate.Text = "";
            txtOpenEnrollmentStartDate.Text = "";
            txtOpenEnrollmentEndDate.Text = "";
            txtMobileAppCode.Text = "";
            ddlMemoType.SelectedIndex = 0;
            ddlMemoStyle.SelectedIndex = 0;
            ddlIsMobileAppOffered.SelectedIndex = 0;
            ddlIsMobileAppOffered_SelectedIndexChanged(null, null);
            ddlMemoStyle_SelectedIndexChanged(null, null);

        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            List<Contact> ContactList = new List<Contact>();
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
            Session["Contact"] = ContactList;
            ddlHRContact.DataSource = ContactList;
            ddlHRContact.DataBind();
            ddlHRContact.Items.Insert(0, new ListItem("Select", "Select"));
            ddlHRContact.Items.Insert(1, new ListItem("None", "None"));

        }
        protected void ddlIsMobileAppOffered_SelectedIndexChanged(object sender, EventArgs e)
        {
            tblMobileAppStatuss.Style.Add("display", "none");
            lblMobileAppStatus.Style.Add("display", "none");
            ddlMobileAppStatus.SelectedIndex = 0;
            if (ddlIsMobileAppOffered.SelectedValue.ToLower().Equals("yes"))
            {
                tblMobileAppStatuss.Style.Add("display", "");
                lblMobileAppStatus.Style.Add("display", "");
            }
            ddlMobileAppStatus_SelectedIndexChanged(null, null);
        }
        protected void ddlMobileAppStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblMobileAppCode.Style.Add("display", "none");
            txtMobileAppCode.Style.Add("display", "none");
            txtMobileAppCode.Text = "";
            if (ddlMobileAppStatus.SelectedValue == "New")
            {
                lblMobileAppCode.Style.Add("display", "");
                txtMobileAppCode.Style.Add("display", "");
            }
            if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
            {
                lblMobileAppCode.Style.Add("display", "");
                txtMobileAppCode.Style.Add("display", "");
            }
        }
        private bool ValidateForm()
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return false;
            }
            if (ddlHRContact.SelectedIndex == 0 || ddlHRContact.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select HR Contact.')</script>");
                ddlHRContact.Focus();
                return false;
            }
            if (ddlBRC.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select BRC.')</script>");
                ddlBRC.Focus();
                return false;
            }
            if (ddlMemoType.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Memo Type.')</script>");
                ddlMemoType.Focus();
                return false;
            }
            if (ddlMemoStyle.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Memo Style.')</script>");
                ddlMemoStyle.Focus();
                return false;
            }
            if (txtRenewalDate.Text.Trim() == string.Empty)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Renewal Date.')</script>");
                txtRenewalDate.Focus();
                return false;
            }
            if (!IsValidDate(txtRenewalDate.Text.Trim()))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Invalid Renewal Date. Date format should be MM/DD/YYYY')</script>");
                txtRenewalDate.Focus();
                return false;
            }
            if (txtOpenEnrollmentStartDate.Text.Trim() == string.Empty)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Open Enrollment Start Date.')</script>");
                txtOpenEnrollmentStartDate.Focus();
                return false;
            }
            if (!IsValidDate(txtOpenEnrollmentStartDate.Text.Trim()))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Invalid Open Enrollment Start Date. Date format should be MM/DD/YYYY')</script>");
                txtOpenEnrollmentStartDate.Focus();
                return false;
            }

            if (txtOpenEnrollmentEndDate.Text.Trim() == string.Empty)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Open Enrollment End Date.')</script>");
                txtOpenEnrollmentEndDate.Focus();
                return false;
            }
            if (!IsValidDate(txtOpenEnrollmentEndDate.Text.Trim()))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Invalid Open Enrollment End Date. Date format should be MM/DD/YYYY')</script>");
                txtOpenEnrollmentEndDate.Focus();
                return false;
            }
            if (ddlIsMobileAppOffered.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for Mobile App Offered.')</script>");
                ddlIsMobileAppOffered.Focus();
                return false;
            }
            if (ddlIsMobileAppOffered.SelectedValue == "Yes")
            {
                if (ddlMobileAppStatus.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Mobile App Status.')</script>");
                    ddlMobileAppStatus.Focus();
                    return false;
                }
                if (ddlMobileAppStatus.SelectedValue == "New" || ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                {
                    if (txtMobileAppCode.Text.Trim() == string.Empty)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter Mobile App 6-digit Code.')</script>");
                        txtMobileAppCode.Focus();
                        return false;
                    }
                    if (txtMobileAppCode.Text.Trim().Length < 6)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid Mobile App 6-digit Code.')</script>");
                        txtMobileAppCode.Focus();
                        return false;
                    }
                }
            }
            return true;
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
        private void LoadDisplyStatusData()
        {
            #region Color option mapping
            DictColorOptionMap["MemoShort_BayView"] = false;
            DictColorOptionMap["MemoShort_FAQ"] = true;
            DictColorOptionMap["MemoShort_Mosaic"] = false;
            DictColorOptionMap["MemoShort_Mountain"] = false;
            DictColorOptionMap["MemoShort_Plain"] = false;
            DictColorOptionMap["MemoShort_SpotLight"] = false;
            DictColorOptionMap["MemoShort_SpringField"] = false;
            DictColorOptionMap["MemoShort_SummerHealth"] = false;
            DictColorOptionMap["MemoShort_Tabs"] = false;
            DictColorOptionMap["MemoShort_Highlights"] = true;
            DictColorOptionMap["MemoShort_ColorBlocks"] = true;
            DictColorOptionMap["MemoShort_EnrollmentSummary"] = true;
            DictColorOptionMap["MemoShort_ValueSummary"] = true;
            #endregion
            #region Image option mappings
            DictImageOptionMap["MemoShort_BayView"] = false;
            DictImageOptionMap["MemoShort_FAQ"] = false;
            DictImageOptionMap["MemoShort_Mosaic"] = false;
            DictImageOptionMap["MemoShort_Mountain"] = false;
            DictImageOptionMap["MemoShort_Plain"] = false;
            DictImageOptionMap["MemoShort_SpotLight"] = false;
            DictImageOptionMap["MemoShort_SpringField"] = false;
            DictImageOptionMap["MemoShort_SummerHealth"] = false;
            DictImageOptionMap["MemoShort_Tabs"] = false;
            DictImageOptionMap["MemoShort_Highlights"] = false;
            DictImageOptionMap["MemoShort_ColorBlocks"] = false;
            DictImageOptionMap["MemoShort_EnrollmentSummary"] = true;
            DictImageOptionMap["MemoShort_ValueSummary"] = true;
            #endregion
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            SummaryDetail sd = new SummaryDetail();
            try
            {
                SessionId = Session["SessionId"].ToString();
                if (ValidateForm())
                {
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    if (!string.IsNullOrEmpty(Account_Office))
                    {
                        List<BRCData> BRCListNew = new List<BRCData>();
                        BRCListNew = bp.GetBRCDetails(Account_Office);
                        BRCDetails = BRCListNew.FirstOrDefault();
                        if (BRCDetails == null)
                        {
                            BRCDetails.BRCId = 0;
                            BRCDetails.BRCName = "";
                            BRCDetails.BRCLocation = "";
                            BRCDetails.BRCEmail = "";
                            BRCDetails.BRCPhone = "";
                            BRCDetails.BRCFax = "";
                            BRCDetails.BRCTimezone = "";
                            BRCDetails.BRCDayHours = "";
                        }
                        sd.BuildAccountTable();
                        AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_BayView")
                    {
                        WriteMemoShort_BayViewTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_Plain")
                    {
                        WriteMemoShort_PlainTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_Mosaic")
                    {
                        WriteMemoShort_MosaicTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_SummerHealth")
                    {
                        WriteMemoShort_SummerHealthTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_Mountain")
                    {
                        WriteMemoShort_MountainTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_SpotLight")
                    {
                        WriteMemoShort_SpotLightTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_SpringField")
                    {
                        WriteMemoShort_SpringFieldTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_Tabs")
                    {
                        WriteMemoShort_TabsTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_FAQ")
                    {
                        WriteMemoShort_FAQTemplate();
                    }
                    if (ddlMemoStyle.SelectedValue == "MemoShort_ColorBlocks")
                    {
                        WriteMemoShort_ColorBlockTemplate();
                    }

                    if (ddlMemoStyle.SelectedValue == "MemoShort_Highlights")
                    {
                        WriteMemoShort_HighLightsTemplate();
                    }

                    if (ddlMemoStyle.SelectedValue == "MemoShort_ValueSummary")
                    {
                        WriteMemoShort_ValueSummaryTemplate();
                    }

                    if (ddlMemoStyle.SelectedValue == "MemoShort_EnrollmentSummary")
                    {
                        WriteMemoShort_EnrollmentSummaryTemplate();
                    }
                    #region Insert Activity lOG Details 
                    List<Contact> ContactList = new List<Contact>();
                    ContactList =  Session["Contact"] as List<Contact>;
                    string AdditionalCrtieriaOption_1 = ddlMemoType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlMemoStyle.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DictDepartment = sd.getDepartmentDetails();
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, DeliverableCategory, Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                    #endregion
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void WriteMemoShort_BayViewTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_BayView_Template.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_PlainTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_Plain_Template.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_MosaicTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_Mosaic_Template.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_SummerHealthTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_SummerHealth_Template.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_MountainTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_Mountain.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_SpotLightTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_SpotLight.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_SpringFieldTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_SpringField.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_TabsTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_Tabs.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_FAQTemplate()
        {
            WriteOpenEnrollmentMemo_BayView wr = new WriteOpenEnrollmentMemo_BayView();
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_FAQ.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void WriteMemoShort_HighLightsTemplate()
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_Highlights.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                Word.WdColor TextBoxColor = wr.GetTextBoxColor(ddlColor.SelectedValue);
                Word.WdColor FontColor = wr.GetFontColor(ddlColor.SelectedValue);
                Word.WdColor CellColor = wr.GetCellColor(ddlColor.SelectedValue);
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.FillTextColor(wobj.office.oWordDoc, wobj.office.oWordApp, TextBoxColor, FontColor, CellColor, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_ColorBlockTemplate()
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_ColorBlocks.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;
                Word.WdColor TextBoxColor = wr.GetTextBoxColor(ddlColor.SelectedValue);
                Word.WdColor FontColor = wr.GetFontColor(ddlColor.SelectedValue);
                Word.WdColor CellColor = wr.GetCellColor(ddlColor.SelectedValue);
                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.FillTextColor(wobj.office.oWordDoc, wobj.office.oWordApp, TextBoxColor, FontColor, CellColor, dtRenewalDate, false);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_EnrollmentSummaryTemplate()
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_EnrollmentSummary.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;

                Word.WdColor TextBoxColor = wr.GetTextBoxColor(ddlColor.SelectedValue);
                Word.WdColor FontColor = wr.GetFontColor(ddlColor.SelectedValue);
                Word.WdColor CellColor = wr.GetCellColor(ddlColor.SelectedValue);

                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.FillTextColor(wobj.office.oWordDoc, wobj.office.oWordApp, TextBoxColor, FontColor, CellColor, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                wr.InsertImageToTemplateEnrollment(wobj.office.oWordDoc, wobj.office.oWordApp, ddlImageOption, ddlBRC, ddlMobileAppStatus);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                }
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                        // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                        // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void WriteMemoShort_ValueSummaryTemplate()
        {
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded"));
                }
                string filename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Memo_Short_ValueSummary.docx";
                string _savefilename = "~/Files/OpenEnrollmentMemo/Documents/Templates/Downloaded/NewDocument";
                wobj.Word_Open_DOCX(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                DateTime dtOEStartDate = GetDate(txtOpenEnrollmentStartDate.Text.Trim());
                DateTime dtOEEndDate = GetDate(txtOpenEnrollmentEndDate.Text.Trim());
                List<Contact> ContactList = new List<Contact>();
                ContactList = Session["Contact"] as List<Contact>;
                Contact SelectedContact = new Contact();
                string ContactPhone = string.Empty;

                Word.WdColor TextBoxColor = wr.GetTextBoxColor(ddlColor.SelectedValue);
                Word.WdColor FontColor = wr.GetFontColor(ddlColor.SelectedValue);
                Word.WdColor CellColor = wr.GetCellColor(ddlColor.SelectedValue);

                if (ddlHRContact.SelectedValue != "Select" && ddlHRContact.SelectedValue != "None")
                {
                    if (ContactList != null)
                    {
                        SelectedContact = ContactList.Where(r => r.ContactId == int.Parse(ddlHRContact.SelectedValue)).FirstOrDefault();
                        if (SelectedContact == null)
                            SelectedContact = new Contact();
                    }
                }

                if (SelectedContact.Phone != null && SelectedContact.Phone.Count > 0)
                    ContactPhone = (SelectedContact.Phone.FirstOrDefault() == null) ? "" : SelectedContact.Phone.FirstOrDefault();

                wr.WriteHeaderFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.WriteFooterFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, dtRenewalDate);
                wr.FillTextColor(wobj.office.oWordDoc, wobj.office.oWordApp, TextBoxColor, FontColor, CellColor, dtRenewalDate);
                wr.WriteCommonFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient.SelectedItem.Text, dtRenewalDate, dtOEStartDate, dtOEEndDate, txtMobileAppCode.Text.Trim());
                if (ddlBRC.SelectedValue == "Yes")
                    wr.WriteBRCFieldsToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, BRCDetails);
                else
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "BRC");
                }
                wr.WriteContactInfoFieldToOEMemo_BayView(wobj.office.oWordDoc, wobj.office.oWordApp, SelectedContact.First_Name + " " + SelectedContact.Last_Name, ContactPhone, SelectedContact.Email);

                wr.InsertImageToTemplateValue(wobj.office.oWordDoc, wobj.office.oWordApp, ddlImageOption, ddlBRC, ddlMobileAppStatus);

                if (ddlIsMobileAppOffered.SelectedValue != "Yes")
                {
                    wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                    //wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                }
                else
                {
                    if (ddlMobileAppStatus.SelectedValue == "New")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNewExst");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/New Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstExisting");
                        //wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                    else if (ddlMobileAppStatus.SelectedValue == "Existing/Existing Code")
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusNew");
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppStatusExstNew");
                        // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                    else
                    {
                        wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MainMobileApp");
                        // wr.DeleteIndivialBookmark(wobj.office.oWordDoc, "MobileAppImageOne");
                    }
                }

                wobj.office.oWordDoc.Save();
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                DownloadFileNew(wobj.Save_File);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void BindColorDropDown()
        {
            ddlColor.DataSource = WriteOpenEnrollmentMemo_BayView.ColorOptionList;
            ddlColor.DataBind();
        }
        private void BindImageDropDown()
        {
            // This block is used to bind the Image DropDownList with the folder names in a given path
            string path = Server.MapPath("~/Files/BenefitSummary/Images/Pictures/New Benefit Summaries/");
            DirectoryInfo objDirInfo = new DirectoryInfo(path);
            DirectoryInfo[] diArr = null;
            diArr = objDirInfo.GetDirectories();

            // Display the names of the directories.
            foreach (DirectoryInfo dri in diArr)
            {
                if (dri.Name == "Standard (Default)")
                {
                    ddlImageOption.Items.Insert(0, new ListItem(dri.Name, string.Empty));
                }
                else
                {
                    ddlImageOption.Items.Add(dri.Name);
                }
            }
        }

    }
}