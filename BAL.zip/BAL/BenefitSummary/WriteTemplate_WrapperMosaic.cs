﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_WrapperMosaic : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;

        Dictionary<string, List<int>> DictContactsPlanTypes = new Dictionary<string, List<int>>();

        public void Write_CommonFieldToMosaicWrapper(Word.Document oWordDoc, Word.Application oWordApp, DataSet EligibilityDS, DropDownList ddlHRContact, List<Contact> ContactList, DataTable EmpTable, DataSet AccountDS, ArrayList arrAcctContact)
        {
            try
            {
                ////Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();

                int index = -1;
                string AccountAddress1 = string.Empty;
                string AccountAddress2 = string.Empty;
                string CompanyStatePincode = string.Empty;

                string City = string.Empty;
                string State = string.Empty;
                string Zip = string.Empty;
                string Street1 = string.Empty;
                string Street2 = string.Empty;


                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (EmpTable.Rows.Count > 0)
                {
                    Emp = EmpTable;
                }


                #region Write Table of Account Contacts
                string AccountContactname = string.Empty;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        AccountContactname = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        AccountContactname = " ";
                                    }

                                }
                            }
                        }
                    }
                }
                #endregion

                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                                State = State.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }

                        }
                    }
                }//AccountDS Close

                CompanyStatePincode = City + ", " + State + "  " + Zip;
                AccountAddress1 = Street1;
                AccountAddress2 = Street2;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                            continue;
                        }


                        if (fieldName.Contains("unmarriedchildtoage"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim() == "")
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("definitionofdomesticpartner"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                if (domesticPartner.Trim().Length == 0)
                                {
                                    oWordApp.Selection.TypeText(domesticPartner);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(domesticPartner.Trim());
                                }
                            }
                        }

                        ///Account Conact Name 
                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContactname))
                            {
                                oWordApp.Selection.TypeText(AccountContactname);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }


                        if (Emp.Rows.Count > 0)
                        {
                            if (fieldName.Contains("EmployeeStatus"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                continue;
                            }

                            if (fieldName.Contains("Frequency_Eligibility"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("Employee Status"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }

                            if (fieldName.Contains("Frequency"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("medicalplanwaitingperiod"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().ToLower().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        /*******COMPANY DETAILS */
                        //Company_Address
                        if (fieldName.Contains("Account Address1"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountAddress1))
                            {
                                oWordApp.Selection.TypeText(AccountAddress1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Account Address2"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountAddress2))
                            {
                                oWordApp.Selection.TypeText(AccountAddress2 + "\n");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        //CompanyCity_StateZipCode
                        if (fieldName.Contains("CompanyCity_StateZipCode"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(CompanyStatePincode))
                            {
                                oWordApp.Selection.TypeText(CompanyStatePincode);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void Write_BRCToMosaicWrapper(Word.Document oWordDoc, Word.Application oWordApp, List<BRCData> BRCList)
        {
            int BRCindex = 0;


            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    //BRCPhoneNumber
                    if (fieldName.Contains("BRCPhoneNumber"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone);
                        continue;
                    }

                    //BRCDaysHours
                    if (fieldName.Contains("BRCDaysHours"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours);
                        continue;
                    }

                    //BRCEmailAddress
                    if (fieldName.Contains("BRCEmailAddress"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail);
                        continue;
                    }

                }
            }
            #endregion
        }


        public void Write_ContactsToMosaicWrapper(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlClient, string SessionId)
        {
            int rowcount = 0;
            int count = 1;
            string FirstMedEffective = "";
            int TotalPlanCount = 0;
            int TotalPlanCountCopy = 0;
            StringBuilder uniquePlans = new StringBuilder();

            Dictionary<string, string> DistinctPlanTypes = new Dictionary<string, string>();
            Dictionary<string, string> DictPlanCarrier = new Dictionary<string, string>();
            DistinctPlanTypes.Clear();

            DataTable DistinctPlanTable = AddColumnToPlanTable(PlanTable, SessionId);

            DistinctPlanTable.DefaultView.Sort = "ProductTypeId";
            DistinctPlanTable = DistinctPlanTable.DefaultView.ToTable();

            DataTable PlanTableCopy = new DataTable();
            PlanTableCopy = PlanTable.Copy();
            TotalPlanCountCopy = PlanTable.Rows.Count;

            TotalPlanCount = DistinctPlanTable.Rows.Count;
            #region Removing dulicate rows from table
            for (int rowindex = 0; rowindex < DistinctPlanTable.Rows.Count; rowindex++)
            {
                string plantype = DistinctPlanTable.Rows[rowindex]["contactPlanType"].ToString();
                if ((!DistinctPlanTypes.ContainsKey(plantype)) && plantype != "")
                {
                    DistinctPlanTypes.Add(plantype, plantype);
                }
                else
                {
                    DistinctPlanTable.Rows[rowindex].Delete();
                    rowindex--;
                }
            }
            #endregion

            DataTable uniqueplantable = DistinctPlanTable.DefaultView.ToTable(true, "contactPlanType");
            int lastIndex = uniqueplantable.Rows.Count;

            for (int i = 0; i < lastIndex; i++)
            {
                string plantype = uniqueplantable.Rows[i]["contactPlanType"].ToString();
                if (plantype.Trim() != "")
                {
                    uniquePlans.Append(plantype.Trim());

                    if (i != lastIndex - 1)
                    {
                        uniquePlans.Append("\n");
                    }
                }

            }

            #region writing Contacts Table
            for (int i = 0; i < TotalPlanCountCopy; i++)
            {
                DataRow row = PlanTableCopy.Rows[i];
                if (row["contactPlanType"].ToString() == "Medical" && FirstMedEffective == "")
                {
                    FirstMedEffective = row["Effective"].ToString();
                }

                if (PlanTableCopy.Rows[i]["Carrier"].ToString().Trim() != "" && PlanTableCopy.Rows[i]["Name"].ToString().Trim() != "")
                {
                    string plancarrier = PlanTableCopy.Rows[i]["Carrier"].ToString() + PlanTableCopy.Rows[i]["Name"].ToString();
                    if (!DictPlanCarrier.ContainsKey(plancarrier))
                    {
                        DictPlanCarrier.Add(plancarrier, plancarrier);
                    }
                    else
                    {
                        PlanTableCopy.Rows[i].Delete();
                        TotalPlanCountCopy--;
                        i--;
                    }

                }
            }

            for (int i = 0; i < PlanTableCopy.Rows.Count; i++)
            {
                rowcount++;
                if (rowcount > 1)
                {
                    oWordDoc.Tables[count].Rows.Add(Type.Missing);
                }

                oWordDoc.Tables[count].Cell(rowcount + 1, 2).Range.Text = PlanTableCopy.Rows[i]["Carrier"].ToString();
                oWordDoc.Tables[count].Cell(rowcount + 1, 1).Range.Text = PlanTableCopy.Rows[i]["Name"].ToString();
                oWordDoc.Tables[count].Cell(rowcount + 1, 3).Range.Text = "(###) ###-####";
                oWordDoc.Tables[count].Cell(rowcount + 1, 4).Range.Text = "www.website.com";
            }

            #endregion


            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("FirstMedEffectiveYear"))
                    {
                        myMergeField.Select();
                        string effectivedate = FirstMedEffective;
                        // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                        continue;
                    }

                    if (fieldName.Contains("FirstMedEffectiveDate"))
                    {
                        myMergeField.Select();
                        string effectivedate = FirstMedEffective;
                        // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                        oWordApp.Selection.TypeText(Convert.ToDateTime(effective_date.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effective_date.ToString()).Year.ToString());
                        continue;
                    }

                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text);

                    }
                    if (fieldName.Contains("WriteUniquePlanTypes"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(uniquePlans.ToString());

                    }
                }
            }
            #endregion

        }

        private void BuiltDictContactsPlanTypes()
        {
            DictContactsPlanTypes.Clear();

            DictContactsPlanTypes.Add("Medical", new List<int> { 100, 110, 120, 130, 140, 150, 160, 170, 420, 233, 173, 235 });
            DictContactsPlanTypes.Add("Dental", new List<int> { 180, 190, 200, 210 });
            DictContactsPlanTypes.Add("Vision", new List<int> { 230 });

            DictContactsPlanTypes.Add("Life and AD&D", new List<int> { 240, 250, 270 });

            DictContactsPlanTypes.Add("Voluntary Life AD&D", new List<int> { 260, 280 });

            DictContactsPlanTypes.Add("Short Term Disability", new List<int> { 290, 292, 293, 294 });
            DictContactsPlanTypes.Add("Long Term Disability", new List<int> { 300 });

            DictContactsPlanTypes.Add("Health Savings Account", new List<int> { 179 });
            DictContactsPlanTypes.Add("Health Reimbursement Account", new List<int> { 178 });

            DictContactsPlanTypes.Add("Flexible Spending Accounts", new List<int> { 330 });
            DictContactsPlanTypes.Add("Employee Assistance Program", new List<int> { 310 });
            DictContactsPlanTypes.Add("Business Travel Accident", new List<int> { 320 });

            DictContactsPlanTypes.Add("Patient Advocacy", new List<int> { 1790 });
            DictContactsPlanTypes.Add("Telemedicine", new List<int> { 5460 });
            DictContactsPlanTypes.Add("Wellness", new List<int> { 317, 1740, 5875 });

            DictContactsPlanTypes.Add("Additional Coverages", new List<int> { 1160, 1400, 5500 });

            // DictContactsPlanTypes.Add("401(k) Insurance", new List<int> { 340 });

        }

        private DataTable AddColumnToPlanTable(DataTable PlanTable, string SessionId)
        {
            BuiltDictContactsPlanTypes();

            if (!PlanTable.Columns.Contains("contactPlanType"))
            {
                PlanTable.Columns.Add("contactPlanType", typeof(string));
            }

            foreach (DataRow row in PlanTable.Rows)
            {
                foreach (string plantype in DictContactsPlanTypes.Keys)
                {
                    if (DictContactsPlanTypes[plantype].Contains(Convert.ToInt32(row["ProductTypeId"])))
                    {
                        row["contactPlanType"] = plantype;
                        break;
                    }
                }
            }
            return PlanTable;
        }

        private bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }

        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }

        public void WriteNoticeSectionToMosaicWrapper(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}