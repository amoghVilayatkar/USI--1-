﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;

namespace BenefitPointSummaryPortal.BAL.ExperienceReports
{
    public class ExperienceReports
    {
        public enum ReportType { None, Experience, Utilization }
        public enum LineOfCoverages { None, Dental, Medical }
        public enum FundingMethods { None, Fully_Insured, Self_Funded }
        public enum ConfigNames { None, Experience_Dental_FI_Landscape, Experience_Dental_FI_Portrait, Experience_Dental_SF_Landscape, Experience_Dental_SF_Portrait, Experience_Medical_FI_SinglePlan_Landscape, Experience_Medical_FI_SinglePlan_Portrait, Experience_Medical_FI_MultiPlan_Landscape, Experience_Medical_FI_MultiPlan_Portrait, Experience_Medical_SF_Landscape, Experience_Medical_SF_Portrait, Utilization_Medical_Utilization_Landscape, Utilization_Medical_Utilization_Portrait }
        public DataTable dtblReportConfig = new DataTable();

        public ExperienceReports()
        {
            LoadReportConfig();
        }
        public ExperienceReports.ReportType CovertToReportType(string RetortTypeName)
        {
            if (RetortTypeName.ToLower().Equals("experience"))
            {
                return ExperienceReports.ReportType.Experience;
            }
            if (RetortTypeName.ToLower().Equals("utilization"))
            {
                return ExperienceReports.ReportType.Utilization;
            }
            return ExperienceReports.ReportType.None;
        }
        public ExperienceReports.LineOfCoverages CovertToLineOfCoverage(string LOCName)
        {
            if (LOCName.ToLower().Equals("dental"))
            {
                return ExperienceReports.LineOfCoverages.Dental;
            }
            if (LOCName.ToLower().Equals("medical"))
            {
                return ExperienceReports.LineOfCoverages.Medical;
            }
            return ExperienceReports.LineOfCoverages.None;
        }
        public ExperienceReports.ConfigNames CovertToConfigName(string ConfigName)
        {
            ExperienceReports.ConfigNames ReturnValue = ConfigNames.None;
            if (ConfigName.ToLower().Equals("experience_dental_fi_landscape"))
            {
                ReturnValue = ConfigNames.Experience_Dental_FI_Landscape;
            }
            if (ConfigName.ToLower().Equals("experience_dental_fi_portrait"))
            {
                ReturnValue = ConfigNames.Experience_Dental_FI_Portrait;
            }
            if (ConfigName.ToLower().Equals("experience_dental_sf_landscape"))
            {
                ReturnValue = ConfigNames.Experience_Dental_SF_Landscape;
            }
            if (ConfigName.ToLower().Equals("experience_dental_sf_portrait"))
            {
                ReturnValue = ConfigNames.Experience_Dental_SF_Portrait;
            }
            if (ConfigName.ToLower().Equals("experience_medical_fi_singleplan_landscape"))
            {
                ReturnValue = ConfigNames.Experience_Medical_FI_SinglePlan_Landscape;
            }
            if (ConfigName.ToLower().Equals("experience_medical_fi_singleplan_portrait"))
            {
                ReturnValue = ConfigNames.Experience_Medical_FI_SinglePlan_Portrait;
            }
            if (ConfigName.ToLower().Equals("experience_medical_fi_multiplan_landscape"))
            {
                ReturnValue = ConfigNames.Experience_Medical_FI_MultiPlan_Landscape;
            }
            if (ConfigName.ToLower().Equals("experience_medical_fi_multiplan_portrait"))
            {
                ReturnValue = ConfigNames.Experience_Medical_FI_MultiPlan_Portrait;
            }
            if (ConfigName.ToLower().Equals("experience_medical_sf_landscape"))
            {
                ReturnValue = ConfigNames.Experience_Medical_SF_Landscape;
            }
            if (ConfigName.ToLower().Equals("experience_medical_sf_portrait"))
            {
                ReturnValue = ConfigNames.Experience_Medical_SF_Portrait;
            }
            if (ConfigName.ToLower().Equals("utilization_medical_utilization_landscape"))
            {
                ReturnValue = ConfigNames.Utilization_Medical_Utilization_Landscape;
            }
            if (ConfigName.ToLower().Equals("utilization_medical_utilization_portrait"))
            {
                ReturnValue = ConfigNames.Utilization_Medical_Utilization_Portrait;
            }
            return ReturnValue;
        }
        private void LoadReportConfig()
        {
            dtblReportConfig = new DataTable();
            dtblReportConfig.Columns.Add(new DataColumn("Type"));
            dtblReportConfig.Columns.Add(new DataColumn("LOC"));
            dtblReportConfig.Columns.Add(new DataColumn("FundingMethod"));
            dtblReportConfig.Columns.Add(new DataColumn("TemplateName"));
            dtblReportConfig.Columns.Add(new DataColumn("PageOrientation"));
            dtblReportConfig.Columns.Add(new DataColumn("FileName"));
            dtblReportConfig.Columns.Add(new DataColumn("ConfigName"));

            DataRow drExperience_Dental_FI_Landscape = dtblReportConfig.NewRow();
            drExperience_Dental_FI_Landscape["Type"] = "Experience";
            drExperience_Dental_FI_Landscape["LOC"] = "Dental";
            drExperience_Dental_FI_Landscape["FundingMethod"] = "Fully Insured";
            drExperience_Dental_FI_Landscape["TemplateName"] = "";
            drExperience_Dental_FI_Landscape["PageOrientation"] = "Landscape";
            drExperience_Dental_FI_Landscape["FileName"] = "01-Dental_FI_Landscape.xlsx";
            drExperience_Dental_FI_Landscape["ConfigName"] = "Experience_Dental_FI_Landscape";
            dtblReportConfig.Rows.Add(drExperience_Dental_FI_Landscape);


            DataRow drExperience_Dental_FI_Portrait = dtblReportConfig.NewRow();
            drExperience_Dental_FI_Portrait["Type"] = "Experience";
            drExperience_Dental_FI_Portrait["LOC"] = "Dental";
            drExperience_Dental_FI_Portrait["FundingMethod"] = "Fully Insured";
            drExperience_Dental_FI_Portrait["TemplateName"] = "";
            drExperience_Dental_FI_Portrait["PageOrientation"] = "Portrait";
            drExperience_Dental_FI_Portrait["FileName"] = "02-Dental_FI_Portrait.xlsx";
            drExperience_Dental_FI_Portrait["ConfigName"] = "Experience_Dental_FI_Portrait";
            dtblReportConfig.Rows.Add(drExperience_Dental_FI_Portrait);

            DataRow drExperience_Dental_SF_Landscape = dtblReportConfig.NewRow();
            drExperience_Dental_SF_Landscape["Type"] = "Experience";
            drExperience_Dental_SF_Landscape["LOC"] = "Dental";
            drExperience_Dental_SF_Landscape["FundingMethod"] = "Self Funded";
            drExperience_Dental_SF_Landscape["TemplateName"] = "";
            drExperience_Dental_SF_Landscape["PageOrientation"] = "Landscape";
            drExperience_Dental_SF_Landscape["FileName"] = "03-Dental_SF_Landscape.xlsx";
            drExperience_Dental_SF_Landscape["ConfigName"] = "Experience_Dental_SF_Landscape";
            dtblReportConfig.Rows.Add(drExperience_Dental_SF_Landscape);

            DataRow drExperience_Dental_SF_Portrait = dtblReportConfig.NewRow();
            drExperience_Dental_SF_Portrait["Type"] = "Experience";
            drExperience_Dental_SF_Portrait["LOC"] = "Dental";
            drExperience_Dental_SF_Portrait["FundingMethod"] = "Self Funded";
            drExperience_Dental_SF_Portrait["TemplateName"] = "";
            drExperience_Dental_SF_Portrait["PageOrientation"] = "Portrait";
            drExperience_Dental_SF_Portrait["FileName"] = "04-Dental_SF_Portrait.xlsx";
            drExperience_Dental_SF_Portrait["ConfigName"] = "Experience_Dental_SF_Portrait";
            dtblReportConfig.Rows.Add(drExperience_Dental_SF_Portrait);

            DataRow drExperience_Medical_FI_SP_Landscape = dtblReportConfig.NewRow();
            drExperience_Medical_FI_SP_Landscape["Type"] = "Experience";
            drExperience_Medical_FI_SP_Landscape["LOC"] = "Medical";
            drExperience_Medical_FI_SP_Landscape["FundingMethod"] = "Fully Insured";
            drExperience_Medical_FI_SP_Landscape["TemplateName"] = "Single Plan";
            drExperience_Medical_FI_SP_Landscape["PageOrientation"] = "Landscape";
            drExperience_Medical_FI_SP_Landscape["FileName"] = "05-Medical_FI_SinglePlan_Landscape.xlsx";
            drExperience_Medical_FI_SP_Landscape["ConfigName"] = "Experience_Medical_FI_SinglePlan_Landscape";
            dtblReportConfig.Rows.Add(drExperience_Medical_FI_SP_Landscape);

            DataRow drExperience_Medical_FI_SP_Portrait = dtblReportConfig.NewRow();
            drExperience_Medical_FI_SP_Portrait["Type"] = "Experience";
            drExperience_Medical_FI_SP_Portrait["LOC"] = "Medical";
            drExperience_Medical_FI_SP_Portrait["FundingMethod"] = "Fully Insured";
            drExperience_Medical_FI_SP_Portrait["TemplateName"] = "Single Plan";
            drExperience_Medical_FI_SP_Portrait["PageOrientation"] = "Portrait";
            drExperience_Medical_FI_SP_Portrait["FileName"] = "06-Medical_FI_SinglePlan_Portrait.xlsx";
            drExperience_Medical_FI_SP_Portrait["ConfigName"] = "Experience_Medical_FI_SinglePlan_Portrait";
            dtblReportConfig.Rows.Add(drExperience_Medical_FI_SP_Portrait);

            DataRow drExperience_Medical_FI_MP_Landscape = dtblReportConfig.NewRow();
            drExperience_Medical_FI_MP_Landscape["Type"] = "Experience";
            drExperience_Medical_FI_MP_Landscape["LOC"] = "Medical";
            drExperience_Medical_FI_MP_Landscape["FundingMethod"] = "Fully Insured";
            drExperience_Medical_FI_MP_Landscape["TemplateName"] = "Multi Plan";
            drExperience_Medical_FI_MP_Landscape["PageOrientation"] = "Landscape";
            drExperience_Medical_FI_MP_Landscape["FileName"] = "07-Medical_FI_MultiPlan_Landscape.xlsx";
            drExperience_Medical_FI_MP_Landscape["ConfigName"] = "Experience_Medical_FI_MultiPlan_Landscape";
            dtblReportConfig.Rows.Add(drExperience_Medical_FI_MP_Landscape);

            DataRow drExperience_Medical_FI_MP_Portrait = dtblReportConfig.NewRow();
            drExperience_Medical_FI_MP_Portrait["Type"] = "Experience";
            drExperience_Medical_FI_MP_Portrait["LOC"] = "Medical";
            drExperience_Medical_FI_MP_Portrait["FundingMethod"] = "Fully Insured";
            drExperience_Medical_FI_MP_Portrait["TemplateName"] = "Multi Plan";
            drExperience_Medical_FI_MP_Portrait["PageOrientation"] = "Portrait";
            drExperience_Medical_FI_MP_Portrait["FileName"] = "08-Medical_FI_MultiPlan_Portrait.xlsx";
            drExperience_Medical_FI_MP_Portrait["ConfigName"] = "Experience_Medical_FI_MultiPlan_Portrait";
            dtblReportConfig.Rows.Add(drExperience_Medical_FI_MP_Portrait);

            DataRow drExperience_Medical_SF_Landscape = dtblReportConfig.NewRow();
            drExperience_Medical_SF_Landscape["Type"] = "Experience";
            drExperience_Medical_SF_Landscape["LOC"] = "Medical";
            drExperience_Medical_SF_Landscape["FundingMethod"] = "Self Funded";
            drExperience_Medical_SF_Landscape["TemplateName"] = "";
            drExperience_Medical_SF_Landscape["PageOrientation"] = "Landscape";
            drExperience_Medical_SF_Landscape["FileName"] = "09-Medical_SF_Landscape.xlsx";
            drExperience_Medical_SF_Landscape["ConfigName"] = "Experience_Medical_SF_Landscape";
            dtblReportConfig.Rows.Add(drExperience_Medical_SF_Landscape);

            DataRow drExperience_Medical_SF_Portrait = dtblReportConfig.NewRow();
            drExperience_Medical_SF_Portrait["Type"] = "Experience";
            drExperience_Medical_SF_Portrait["LOC"] = "Medical";
            drExperience_Medical_SF_Portrait["FundingMethod"] = "Self Funded";
            drExperience_Medical_SF_Portrait["TemplateName"] = "";
            drExperience_Medical_SF_Portrait["PageOrientation"] = "Portrait";
            drExperience_Medical_SF_Portrait["FileName"] = "10-Medical_SF_Portrait.xlsx";
            drExperience_Medical_SF_Portrait["ConfigName"] = "Experience_Medical_SF_Portrait";
            dtblReportConfig.Rows.Add(drExperience_Medical_SF_Portrait);

            DataRow drUtilization_Medical_Landscape = dtblReportConfig.NewRow();
            drUtilization_Medical_Landscape["Type"] = "Utilization";
            drUtilization_Medical_Landscape["LOC"] = "Medical";
            drUtilization_Medical_Landscape["FundingMethod"] = "";
            drUtilization_Medical_Landscape["TemplateName"] = "";
            drUtilization_Medical_Landscape["PageOrientation"] = "Landscape";
            drUtilization_Medical_Landscape["FileName"] = "11-Medical_Utilization_Landscape.xlsx";
            drUtilization_Medical_Landscape["ConfigName"] = "Utilization_Medical_Utilization_Landscape";
            dtblReportConfig.Rows.Add(drUtilization_Medical_Landscape);

            DataRow drUtilization_Medical_Portrait = dtblReportConfig.NewRow();
            drUtilization_Medical_Portrait["Type"] = "Utilization";
            drUtilization_Medical_Portrait["LOC"] = "Medical";
            drUtilization_Medical_Portrait["FundingMethod"] = "";
            drUtilization_Medical_Portrait["TemplateName"] = "";
            drUtilization_Medical_Portrait["PageOrientation"] = "Portrait";
            drUtilization_Medical_Portrait["FileName"] = "12-Medical_Utilization_Portrait.xlsx";
            drUtilization_Medical_Portrait["ConfigName"] = "Utilization_Medical_Utilization_Portrait";
            dtblReportConfig.Rows.Add(drUtilization_Medical_Portrait);

        }
        public void WriteClientNameToExperienceReport(Microsoft.Office.Interop.Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName, int RowNum, int ColumnNum)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            wkSheet.Cells[RowNum,ColumnNum] = ClientName;
        }

    }
}