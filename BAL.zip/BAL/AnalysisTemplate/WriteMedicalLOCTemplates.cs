﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Collections;
namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteMedicalLOCTemplates
    {
        public static List<int> Medical_PlanIDs = new List<int>() { 100, 110, 120, 130, 140, 150, 160, 170 };
        public static List<int> HRA_PlanIDs = new List<int>() { 178 };
        public static List<int> HSA_PlanIDs = new List<int>() { 179 };
        public static List<int> StopLoss_PlanIDs = new List<int>() { 235 };
        public List<string> TemplateTypeList;
        public enum TemplateType { None, FI_Single, FI_Dual, FI_Triple, SF_Single, SF_Dual, SF_Triple };
        public List<int> Medical_InNetworkColumnsIds = new List<int>() { 100, 101, 103, 106, 108, 111, 112, 114 };
        public List<int> Medical_OutNetworkColumnsIds = new List<int>() { 113, 109, 107, 104, 102 };

        public WriteMedicalLOCTemplates()
        {
            TemplateTypeList = new List<string>();
            TemplateTypeList.Add(TemplateType.FI_Single.ToString().Replace("_", " "));
            TemplateTypeList.Add(TemplateType.FI_Dual.ToString().Replace("_", " "));
            TemplateTypeList.Add(TemplateType.FI_Triple.ToString().Replace("_", " "));
            TemplateTypeList.Add(TemplateType.SF_Single.ToString().Replace("_", " "));
            TemplateTypeList.Add(TemplateType.SF_Dual.ToString().Replace("_", " "));
            TemplateTypeList.Add(TemplateType.SF_Triple.ToString().Replace("_", " "));
        }
        public void WriteMedicalBenefit_Fields(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string ClientName, DateTime RenewalDate, IList<string> SfSheet)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            wkSheet.Cells[1, 2] = ClientName;
            wkSheet.Cells[4, 2] = RenewalDate.ToString("MMMM d, yyyy") + " Renewal Date";
            for (int i = 1; i <= myWorkbook.Worksheets.Count; i++)
            {
                Excel.Worksheet wkSheetToCheck = (Excel.Worksheet)myWorkbook.Worksheets[i];
                if (wkSheetToCheck.Name != null)
                {
                    if (!SfSheet.Contains(wkSheetToCheck.Name))
                    {
                        wkSheetToCheck.Visible = Excel.XlSheetVisibility.xlSheetHidden;
                    }
                }
            }

        }
        public TemplateType ConvertToTemplateType(string TemplateTypeName)
        {
            TemplateType ReturnValue = TemplateType.None;
            TemplateTypeName = TemplateTypeName.Replace(" ", "_");
            switch (TemplateTypeName)
            {
                case "FI_Single":
                    ReturnValue = TemplateType.FI_Single;
                    break;
                case "FI_Dual":
                    ReturnValue = TemplateType.FI_Dual;
                    break;
                case "FI_Triple":
                    ReturnValue = TemplateType.FI_Triple;
                    break;
                case "SF_Single":
                    ReturnValue = TemplateType.SF_Single;
                    break;
                case "SF_Dual":
                    ReturnValue = TemplateType.SF_Dual;
                    break;
                case "SF_Triple":
                    ReturnValue = TemplateType.SF_Triple;
                    break;
            }
            return ReturnValue;
        }
        public int GetPlanTier(string TemplateTypeName)
        {
            TemplateType ReturnValue = TemplateType.None;
            ReturnValue = ConvertToTemplateType(TemplateTypeName);
            int PlanTier = 0;
            switch (ReturnValue)
            {
                case TemplateType.None:
                    break;
                case TemplateType.FI_Single:
                    PlanTier = 1;
                    break;
                case TemplateType.FI_Dual:
                    PlanTier = 2;
                    break;
                case TemplateType.FI_Triple:
                    PlanTier = 3;
                    break;
                case TemplateType.SF_Single:
                    PlanTier = 1;
                    break;
                case TemplateType.SF_Dual:
                    PlanTier = 2;
                    break;
                case TemplateType.SF_Triple:
                    PlanTier = 3;
                    break;
            }
            return PlanTier;
        }
        public void DeleteHRAorHSA_Rows(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, IList<int> delRows)
        {
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            delRows.RemoveAt(delRows.Count - 1);
            for (int i = 0; i < delRows.Count; i++)
            {
                var hiddenRange = wkSheet.Range[wkSheet.Cells[delRows[i], 1], wkSheet.Cells[delRows[i], 22]];
               // hiddenRange.EntireRow.Hidden = true;
            }


        }
        public void WriteMedicalBenefits_V1(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string CarrierName, string ClientName, string PlanName, string PlanType, string SummaryName, DateTime RenewalDate, DataSet BenefitDS, int BenefitSummaryID, int Column1, int Column2 = 0, int Column3 = 0)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            wkSheet.Cells[1, 2] = ClientName;
            wkSheet.Cells[8, Column1] = CarrierName;
            //wkSheet.Cells[9, Column1] = PlanType + "\n" + PlanName + "\n" + SummaryName;
            wkSheet.Cells[9, Column1] = PlanType + "\n" + SummaryName;
            wkSheet.Cells[4, 2] = RenewalDate.ToString("MMMM d, yyyy") + " Renewal Date";

            #region In Network Deductible (Individual / Family) - 10
            DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_InNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
            }
            DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_InNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                }
            }
            wkSheet.Cells[10, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[10, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[10, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Out Network Deductible (Individual / Family) - 11
            DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_OutNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
            }
            DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_OutNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                }
            }
            wkSheet.Cells[11, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[11, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[11, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region In Network Out-of-Pocket Maximum (Individual / Family) - 13
            DataRow AnnualOutofPocket_InetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_InetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_InetworkIndividual);
            }
            DataRow AnnualOutofPocket_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_InNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_InNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(AnnualOutofPocket_InNetworkFamily);
                }
            }
            wkSheet.Cells[13, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[13, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[13, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Out Network Out-of-Pocket Maximum (Individual / Family) - 14
            DataRow AnnualOutofPocket_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_OutNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkIndividual);
            }
            DataRow AnnualOutofPocket_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_OutNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkFamily);
                }
            }
            wkSheet.Cells[14, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[14, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[14, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Coinsurance (In / Out) -17
            DataRow Coinsurance_InNetwork = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (Coinsurance_InNetwork != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(Coinsurance_InNetwork);
            }
            DataRow Coinsurance_OutNetwork = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (Coinsurance_OutNetwork != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(Coinsurance_OutNetwork);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(Coinsurance_OutNetwork);
                }
            }
            wkSheet.Cells[17, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[17, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[17, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Wellness / Preventive Care -18
            DataRow PreventiveServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PreventiveServices != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PreventiveServices);
            }
            wkSheet.Cells[18, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[18, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[18, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Primary Care Office Visit -19
            DataRow OfficeVisitExam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OfficeVisitExam != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OfficeVisitExam);
            }
            wkSheet.Cells[19, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[19, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[19, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Specialist Office Visit -20
            DataRow OutpatientSpecialistVisit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientSpecialistVisit != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientSpecialistVisit);
            }
            wkSheet.Cells[20, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[20, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[20, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Walk-In / Urgent Care Visit -21
            DataRow UrgentCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (UrgentCare != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(UrgentCare);
            }
            wkSheet.Cells[21, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[21, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[21, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Emergency Room -22
            DataRow EmergencyRoom = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (EmergencyRoom != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(EmergencyRoom);
            }
            wkSheet.Cells[22, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[22, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[22, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Outpatient Lab / X-Ray -23
            DataRow DiagnosticXRayandLabTests = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (DiagnosticXRayandLabTests != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(DiagnosticXRayandLabTests);
            }
            wkSheet.Cells[23, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[23, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[23, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Complex Imaging (MRI, CAT, PET, et.al.) -24
            DataRow OutpatientComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientComplexRadiology != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientComplexRadiology);
            }
            wkSheet.Cells[24, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[24, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[24, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Outpatient Surgical Facility -25
            DataRow OutpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientFacilityCharges != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientFacilityCharges);
            }
            wkSheet.Cells[25, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[25, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[25, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Inpatient Hospital Facility -26
            DataRow InpatientHospitalization = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (InpatientHospitalization != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(InpatientHospitalization);
            }
            wkSheet.Cells[26, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[26, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[26, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Generic -27
            DataRow PrescriptionDrugBenefits_Generic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_Generic != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_Generic);
            }
            DataRow PrescriptionDrugBenefits_BrandFormulaPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_BrandFormulaPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaPreferred);
                }
            }
            DataRow PrescriptionDrugBenefits_BrandFormulaNonPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_BrandFormulaNonPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaNonPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaNonPreferred);
                }
            }

            wkSheet.Cells[27, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[27, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[27, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Generic -28
            DataRow PrescriptionDrugBenefits_MailOrderGeneric = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderGeneric != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderGeneric);
            }
            DataRow PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred);
                }
            }
            DataRow PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred);
                }
            }

            wkSheet.Cells[28, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[28, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[28, Column3] = strBenefitSummaryAttributeValue;

            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Preffered Speciality -29
            DataRow PrescriptionDrugBenefits_PrefferedSpeciality = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_PrefferedSpeciality != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_PrefferedSpeciality);
            }

            wkSheet.Cells[29, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[29, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[29, Column3] = strBenefitSummaryAttributeValue;

            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
        }
        public void WriteMedicalBenefits_V2(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, string CarrierName, string ClientName, string PlanName, string PlanType, string SummaryName, DateTime RenewalDate, DataSet BenefitDS, int BenefitSummaryID, int Column1, int Column2 = 0, int Column3 = 0)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            wkSheet.Cells[1, 2] = ClientName;
            wkSheet.Cells[4, 2] = RenewalDate.ToString("MMMM d, yyyy") + " Renewal Date";

            wkSheet.Cells[7, Column1] = CarrierName;
          //  wkSheet.Cells[8, Column1] = PlanType + "\n" + PlanName + "\n" + SummaryName;
            wkSheet.Cells[8, Column1] = PlanType + "\n" + SummaryName;

            #region In Network Deductible (Individual / Family) - 9
            DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_InNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
            }
            DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_InNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                }
            }
            wkSheet.Cells[9, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[9, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[9, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Out Network Deductible (Individual / Family) - 10
            DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_OutNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
            }
            DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_OutNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                }
            }
            wkSheet.Cells[10, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[10, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[10, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region In Network Out-of-Pocket Maximum (Individual / Family) - 12
            DataRow AnnualOutofPocket_InetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_InetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_InetworkIndividual);
            }
            DataRow AnnualOutofPocket_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_InNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_InNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(AnnualOutofPocket_InNetworkFamily);
                }
            }
            wkSheet.Cells[12, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[12, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[12, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Out Network Out-of-Pocket Maximum (Individual / Family) - 13
            DataRow AnnualOutofPocket_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_OutNetworkIndividual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkIndividual);
            }
            DataRow AnnualOutofPocket_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (AnnualOutofPocket_OutNetworkFamily != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkFamily);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(AnnualOutofPocket_OutNetworkFamily);
                }
            }
            wkSheet.Cells[13, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[13, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[13, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Coinsurance (In / Out) -16
            DataRow Coinsurance_InNetwork = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (Coinsurance_InNetwork != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(Coinsurance_InNetwork);
            }
            DataRow Coinsurance_OutNetwork = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_OutNetworkColumnsIds) + ") ").FirstOrDefault();
            if (Coinsurance_OutNetwork != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(Coinsurance_OutNetwork);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(Coinsurance_OutNetwork);
                }
            }
            wkSheet.Cells[16, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[16, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[16, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Wellness / Preventive Care -17
            DataRow PreventiveServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PreventiveServices != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PreventiveServices);
            }
            wkSheet.Cells[17, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[17, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[17, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Primary Care Office Visit -18
            DataRow OfficeVisitExam = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OfficeVisitExam != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OfficeVisitExam);
            }
            wkSheet.Cells[18, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[18, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[18, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Specialist Office Visit -19
            DataRow OutpatientSpecialistVisit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientSpecialistVisit != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientSpecialistVisit);
            }
            wkSheet.Cells[19, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[19, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[19, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Walk-In / Urgent Care Visit -20
            DataRow UrgentCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (UrgentCare != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(UrgentCare);
            }
            wkSheet.Cells[20, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[20, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[20, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Emergency Room -21
            DataRow EmergencyRoom = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (EmergencyRoom != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(EmergencyRoom);
            }
            wkSheet.Cells[21, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[21, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[21, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Outpatient Lab / X-Ray -22
            DataRow DiagnosticXRayandLabTests = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (DiagnosticXRayandLabTests != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(DiagnosticXRayandLabTests);
            }
            wkSheet.Cells[22, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[22, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[22, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Complex Imaging (MRI, CAT, PET, et.al.) -23
            DataRow OutpatientComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientComplexRadiology != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientComplexRadiology);
            }
            wkSheet.Cells[23, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[23, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[23, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Outpatient Surgical Facility -24
            DataRow OutpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (OutpatientFacilityCharges != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(OutpatientFacilityCharges);
            }
            wkSheet.Cells[24, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[24, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[24, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region Inpatient Hospital Facility -25
            DataRow InpatientHospitalization = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (InpatientHospitalization != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(InpatientHospitalization);
            }
            wkSheet.Cells[25, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[25, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[25, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Generic -26
            DataRow PrescriptionDrugBenefits_Generic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_Generic != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_Generic);
            }
            DataRow PrescriptionDrugBenefits_BrandFormulaPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_BrandFormulaPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaPreferred);
                }
            }
            DataRow PrescriptionDrugBenefits_BrandFormulaNonPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_BrandFormulaNonPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaNonPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_BrandFormulaNonPreferred);
                }
            }

            wkSheet.Cells[26, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[26, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[26, Column3] = strBenefitSummaryAttributeValue;
            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Generic -27
            DataRow PrescriptionDrugBenefits_MailOrderGeneric = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderGeneric != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderGeneric);
            }
            DataRow PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaPreferred);
                }
            }
            DataRow PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred != null)
            {
                if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred);
                else
                {
                    strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(PrescriptionDrugBenefits_MailOrderBrandFormulaNonPreferred);
                }
            }

            wkSheet.Cells[27, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[27, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[27, Column3] = strBenefitSummaryAttributeValue;

            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
            #region PrescriptionDrugBenefits_Preffered Speciality -28
            DataRow PrescriptionDrugBenefits_PrefferedSpeciality = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (PrescriptionDrugBenefits_PrefferedSpeciality != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(PrescriptionDrugBenefits_PrefferedSpeciality);
            }

            wkSheet.Cells[28, Column1] = strBenefitSummaryAttributeValue;
            if (Column2 != 0)
                wkSheet.Cells[28, Column2] = strBenefitSummaryAttributeValue;
            if (Column3 != 0)
                wkSheet.Cells[28, Column3] = strBenefitSummaryAttributeValue;

            strBenefitSummaryAttributeValue = string.Empty;
            #endregion
        }
        public void WriteHRAHSA(Excel.Application myExcelApp, Excel.Workbook myWorkbook, string SheetNames, DataSet BenefitDS, int BenefitSummaryID, string IsHRAorHSA, IList<int> HraHsaRows, int ValueColumnIndex, int LabelColumnIndex = 0)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            Excel.Worksheet wkSheet = null;
            wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[SheetNames];
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            string Label_Total = string.Empty;
            string Label_AnnualPremium = string.Empty;
            string Label_AnnualContribution = string.Empty;
            if (IsHRAorHSA == "HRA")
            {
                #region In Network Deductible (Individual / Family) - 15
                Label_AnnualContribution = "Annual HRA Contribution (Individual / Family)";
                Label_Total = "HRA Total";
                Label_AnnualPremium = "Annual Premium Total (w/out HRA)";
                DataRow drBenefitValues_HRAIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 238").FirstOrDefault();
                if (drBenefitValues_HRAIndividual != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_HRAIndividual);
                }
                DataRow drBenefitValues_HRAFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 241").FirstOrDefault();
                if (drBenefitValues_HRAFamily != null)
                {
                    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_HRAFamily);
                    else
                    {
                        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_HRAFamily);
                    }
                }
                wkSheet.Cells[HraHsaRows[0], ValueColumnIndex] = strBenefitSummaryAttributeValue;
                if (LabelColumnIndex != 0)
                {
                    wkSheet.Cells[HraHsaRows[0], LabelColumnIndex] = Label_AnnualContribution;
                    wkSheet.Cells[HraHsaRows[0], LabelColumnIndex].Characters(24, 44).Font.Size = 10;
                    wkSheet.Cells[HraHsaRows[1], LabelColumnIndex] = Label_Total;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex] = Label_AnnualPremium;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex].Characters(21, 32).Font.Size = 10;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex].Characters(21, 32).Font.Bold = "True";
                }
                strBenefitSummaryAttributeValue = string.Empty;
                #endregion}
            }
            else if (IsHRAorHSA == "HSA")
            {
                #region In Network Deductible (Individual / Family) - 15
                Label_AnnualContribution = "Annual HSA Contribution (Individual / Family)";
                Label_Total = "HSA Total";
                Label_AnnualPremium = "Annual Premium Total (w/out HSA)";
                DataRow drBenefitValues_HSAIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 635").FirstOrDefault();
                if (drBenefitValues_HSAIndividual != null)
                {
                    strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_HSAIndividual);
                }
                DataRow drBenefitValues_HSAFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 636").FirstOrDefault();
                if (drBenefitValues_HSAFamily != null)
                {
                    if (string.IsNullOrEmpty(strBenefitSummaryAttributeValue))
                        strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_HSAFamily);
                    else
                    {
                        strBenefitSummaryAttributeValue = strBenefitSummaryAttributeValue + " / " + GetBenefitFormattedValue(drBenefitValues_HSAFamily);
                    }
                }
                wkSheet.Cells[HraHsaRows[0], ValueColumnIndex] = strBenefitSummaryAttributeValue;
                if (LabelColumnIndex != 0)
                {
                    wkSheet.Cells[HraHsaRows[0], LabelColumnIndex] = Label_AnnualContribution;
                    wkSheet.Cells[HraHsaRows[0], LabelColumnIndex].Characters(24, 44).Font.Size = 10;
                    wkSheet.Cells[HraHsaRows[1], LabelColumnIndex] = Label_Total;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex] = Label_AnnualPremium;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex].Characters(21, 32).Font.Size = 10;
                    wkSheet.Cells[HraHsaRows[2], LabelColumnIndex].Characters(21, 32).Font.Bold = "True";
                }
                strBenefitSummaryAttributeValue = string.Empty;
                #endregion}
            }
            else
            {

                DeleteHRAorHSA_Rows(myExcelApp, myWorkbook, SheetNames, HraHsaRows);
            }
        }
        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
            {
                string Value = dr["value"].ToString().Trim();
                if (!Value.Contains(","))
                {
                    if (Value != string.Empty && dr["UOM"].ToString().ToLower() == "dollars")
                    {
                        if (Value.Contains('.'))
                            Value = string.Format("{0:#,0.##}", double.Parse(Value));
                        else
                            Value = string.Format("{0:#,0.##}", int.Parse(Value));
                    }
                }
                return (dr["prefix"].ToString() + Value + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            }
            return "";
        }
    }
}