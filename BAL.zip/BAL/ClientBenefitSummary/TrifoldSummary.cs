﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.Common.ViewModels;

namespace BenefitPointSummaryPortal.BAL.ClientBenefitSummary
{
    public class TrifoldSummary
    {
        public static ConstantValue cv = new ConstantValue();
        public static List<string> CriteriaPages = new List<string>() { "viewPlanBenefitSummary", "viewBenefitSummarySelection", "viewMobileAppLegalNotice" };

        #region TrifoldPlan Lists
        public static List<int> TrifoldPlanType_MedicalPlan = new List<int>() { 100, 110, 120, 130, 140, 150, 160, 170, 233 };
        public static List<int> TrifoldPlanType_Dental = new List<int>() { 180, 190, 200, 210 };
        public static List<int> TrifoldPlanType_Vision = new List<int>() { 230 };
        public static List<int> TrifoldPlanType_HealthSavingAccounts = new List<int>() { 179 };
        public static List<int> TrifoldPlanType_HealthReimbursementArrangement = new List<int>() { 178 };
        public static List<int> TrifoldPlanType_LifeADD = new List<int>() { 240 };
        public static List<int> TrifoldPlanType_GroupTermLife = new List<int>() { 250 };
        public static List<int> TrifoldPlanType_ADD = new List<int>() { 270 };
        public static List<int> TrifoldPlanType_VoluntaryLife = new List<int>() { 260 };
        public static List<int> TrifoldPlanType_VoluntaryADD = new List<int>() { 280 };
        public static List<int> TrifoldPlanType_ShortTermDisability = new List<int>() { 290, 292, 293, 294 };
        public static List<int> TrifoldPlanType_VoluntaryShortTermDisability = new List<int>() { 290 };
        public static List<int> TrifoldPlanType_LongTermDisablity = new List<int>() { 300 };
        public static List<int> TrifoldPlanType_VoluntaryLongTermDisablity = new List<int>() { 300 };
        public static List<int> TrifoldPlanType_EmployeeAssistanceProgram = new List<int>() { 310 };
        public static List<int> TrifoldPlanType_FlexibleSpendingAccount = new List<int>() { 330 };
        public static List<int> TrifoldPlanType_Wellness = new List<int>() { 317 };
        public static List<int> TrifoldPlanType_MedicalRxPlan = new List<int>() { 176 };
        public static List<int> TrifoldPlanType_401K = new List<int>() { 340 };
        public static List<int> TrifoldPlanType_StopLoss = new List<int>() { 235 };
        public static List<int> TrifoldPlanType_InternationalBundledsPlan_3_Tier = new List<int>() { 410 };
        public static List<int> TrifoldPlanType_BussinessTravelAccident = new List<int>() { 320 };
        #endregion

        #region Trifold Product Lists
        public static List<int> TrifoldProductType_Telemedicine = new List<int>() { 5460 };
        public static List<int> TrifoldProductType_PatientAdvocacy = new List<int>() { 1790 };
        public static List<int> TrifoldProductType_Hospitalization = new List<int>() { 5060 };
        public static List<int> TrifoldProductType_Accident = new List<int>() { 5500 };
        public static List<int> TrifoldProductType_CriticalIllnesss = new List<int>() { 1160 };
        public static List<int> TrifoldProductType_VoluntaryCancer = new List<int>() { 1400 };
        public static List<int> TrifoldProductType_LifeADD = new List<int>() { 1150, 1230 };
        public static List<int> TrifoldProductType_AbsenseMasnagement = new List<int>() { 5330 };
        public static List<int> TrifoldProductType_PetInsurance = new List<int>() { 1480 };
        public static List<int> TrifoldProductType_CobraAdministration = new List<int>() { 1109 };
        public static List<int> TrifoldProductType_FinancialProduct = new List<int>() { 1107 };
        public static List<int> TrifoldProductType_ExecutiveBenefit = new List<int>() { 1104 };
        public static List<int> TrifoldProductType_500Filling = new List<int>() { 1110 };
        public static List<int> TrifoldProductType_TransitParkingAdmin = new List<int>() { 1720 };
        public static List<int> TrifoldProductType_LegalServices = new List<int>() { 1114 };
        public static List<int> TrifoldProductType_IdentifyTheft = new List<int>() { 3090 };
        public static List<int> TrifoldProductType_ShortTermMedical = new List<int>() { 1240 };
        public static List<int> TrifoldProductType_WholeLifeIndividual = new List<int>() { 5070 };
        public static List<int> TrifoldProductType_DiseaseManagement = new List<int>() { 5875 };
        public static List<int> TrifoldProductType_TobaccoPolicy = new List<int>() { 5040 };
        public static List<int> TrifoldProductType_GroupHomeAndAuto = new List<int>() { 4020 };
        public static List<int> TrifoldProductType_MinimumEssentialCoverage = new List<int>() { 5825 };
        public static List<int> TrifoldProductType_IND_INDIV_LONG_TERM_CARE = new List<int>() { 1890 };
        public static List<int> TrifoldProductType_IndividualDisability = new List<int>() { 1460 };
        public static List<int> TrifoldProductType_MedicareSupplement = new List<int>() { 1260 };
        public static List<int> TrifoldProductType_FeeForService_Consulting_Project = new List<int>() { 1108 };
        public static List<int> TrifoldProductType_FeeForService_PBMConsulting = new List<int>() { 5885 };
        public static List<int> TrifoldProductType_FeeForService_HR_Ben_Admin_Services = new List<int>() { 1111 };
        public static List<int> TrifoldProductType_LongTermCare = new List<int>() { 1115 };
        public static List<int> TrifoldProductType_MedicalPlanRiders = new List<int>() { 1116 };
        public static List<int> TrifoldProductType_OnsiteMedicenter = new List<int>() { 5340 };
        #endregion

        private static List<int> _TrifoldAllPlans;
        private static List<int> _TrifoldAllProducts;
        public static List<int> Trifold_AllPlans
        {
            get
            {
                LoadAllTrifildPlans();
                return _TrifoldAllPlans;
            }
        }
        public static List<int> Trifold_AllProducts
        {
            get
            {
                LoadAllTrifildProducts();
                return _TrifoldAllProducts;
            }
        }
        public static void LoadAllTrifildPlans()
        {
            _TrifoldAllPlans = new List<int>();
            _TrifoldAllPlans.AddRange(TrifoldPlanType_MedicalPlan);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_MedicalRxPlan);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_Dental);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_Vision);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_HealthSavingAccounts);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_HealthReimbursementArrangement);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_LifeADD);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_GroupTermLife);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_ADD);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_VoluntaryLife);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_VoluntaryADD);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_ShortTermDisability);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_VoluntaryShortTermDisability);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_LongTermDisablity);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_VoluntaryLongTermDisablity);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_EmployeeAssistanceProgram);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_FlexibleSpendingAccount);
            _TrifoldAllPlans.AddRange(TrifoldPlanType_Wellness);
            //_TrifoldAllPlans.AddRange(TrifoldPlanType_401K);
          //  _TrifoldAllPlans.AddRange(TrifoldPlanType_StopLoss);
           // _TrifoldAllPlans.AddRange(TrifoldPlanType_InternationalBundledsPlan_3_Tier);
          //  _TrifoldAllPlans.AddRange(TrifoldPlanType_BussinessTravelAccident);

        }
        public static void LoadAllTrifildProducts()
        {
            _TrifoldAllProducts = new List<int>();
            _TrifoldAllProducts.AddRange(TrifoldProductType_Telemedicine);
            _TrifoldAllProducts.AddRange(TrifoldProductType_PatientAdvocacy);
            _TrifoldAllProducts.AddRange(TrifoldProductType_Hospitalization);
            _TrifoldAllProducts.AddRange(TrifoldProductType_Accident);
            _TrifoldAllProducts.AddRange(TrifoldProductType_CriticalIllnesss);
            _TrifoldAllProducts.AddRange(TrifoldProductType_VoluntaryCancer);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_LifeADD);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_AbsenseMasnagement);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_PetInsurance);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_CobraAdministration);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_FinancialProduct);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_ExecutiveBenefit);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_500Filling);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_TransitParkingAdmin);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_LegalServices);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_IdentifyTheft);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_ShortTermMedical);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_WholeLifeIndividual);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_DiseaseManagement);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_TobaccoPolicy);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_GroupHomeAndAuto);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_MinimumEssentialCoverage);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_IND_INDIV_LONG_TERM_CARE);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_IndividualDisability);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_MedicareSupplement);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_FeeForService_Consulting_Project);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_FeeForService_PBMConsulting);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_FeeForService_HR_Ben_Admin_Services);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_LongTermCare);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_MedicalPlanRiders);
            //_TrifoldAllProducts.AddRange(TrifoldProductType_OnsiteMedicenter);
        }
        public static List<BenefitSummaryStructure> BenefitSummarySelectionMap
        {
            get
            {
                List<BenefitSummaryStructure> lstMap = new List<BenefitSummaryStructure>();

                BenefitSummaryStructure Medical = new BenefitSummaryStructure();
                Medical.LOC = cv.MedicalLOC;
                Medical.MaxBenefitSummary = 3;
                Medical.MaxContributionPerSummary = 1;
                Medical.ContributionApplicable = true;
                Medical.BenefitSummaryApplicable = true;
                Medical.RateApplicable = false;
                Medical.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Medical);

                BenefitSummaryStructure Dental = new BenefitSummaryStructure();
                Dental.LOC = cv.DentalLOC;
                Dental.MaxBenefitSummary = 2;
                Dental.MaxContributionPerSummary = 1;
                Dental.ContributionApplicable = true;
                Dental.BenefitSummaryApplicable = true;
                Dental.RateApplicable = false;
                Dental.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Dental);

                BenefitSummaryStructure Vision = new BenefitSummaryStructure();
                Vision.LOC = cv.VisionLOC;
                Vision.MaxBenefitSummary = 2;
                Vision.MaxContributionPerSummary = 1;
                Vision.ContributionApplicable = true;
                Vision.BenefitSummaryApplicable = true;
                Vision.RateApplicable = false;
                Vision.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Vision);

                BenefitSummaryStructure HSA = new BenefitSummaryStructure();
                HSA.LOC = cv.HSALOC;
                HSA.MaxBenefitSummary = 1;
                HSA.MaxContributionPerSummary = 0;
                HSA.ContributionApplicable = false;
                HSA.BenefitSummaryApplicable = false;
                HSA.RateApplicable = false;
                HSA.MaxRatePerBenefitSummary = 0;
                lstMap.Add(HSA);

                BenefitSummaryStructure HRA = new BenefitSummaryStructure();
                HRA.LOC = cv.HRALOC;
                HRA.MaxBenefitSummary = 1;
                HRA.MaxContributionPerSummary = 0;
                HRA.ContributionApplicable = false;
                HRA.BenefitSummaryApplicable = false;
                lstMap.Add(HRA);

                BenefitSummaryStructure LifeADD = new BenefitSummaryStructure();
                LifeADD.LOC = cv.LifeADDLOC;
                LifeADD.MaxBenefitSummary = 1;
                LifeADD.MaxContributionPerSummary = 0;
                LifeADD.ContributionApplicable = false;
                LifeADD.BenefitSummaryApplicable = false;
                LifeADD.RateApplicable = false;
                LifeADD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(LifeADD);

                BenefitSummaryStructure VolLifeADD = new BenefitSummaryStructure();
                VolLifeADD.LOC = cv.VoluntaryLifeADDLOC;
                VolLifeADD.MaxBenefitSummary = 1;
                VolLifeADD.MaxContributionPerSummary = 0;
                VolLifeADD.ContributionApplicable = false;
                VolLifeADD.BenefitSummaryApplicable = false;
                VolLifeADD.RateApplicable = false;
                VolLifeADD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(VolLifeADD);

                BenefitSummaryStructure STD = new BenefitSummaryStructure();
                STD.LOC = cv.STDLOC;
                STD.MaxBenefitSummary = 1;
                STD.MaxContributionPerSummary = 0;
                STD.ContributionApplicable = false;
                STD.BenefitSummaryApplicable = false;
                STD.RateApplicable = false;
                STD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(STD);

                BenefitSummaryStructure LTD = new BenefitSummaryStructure();
                LTD.LOC = cv.LTDLOC;
                LTD.MaxBenefitSummary = 1;
                LTD.MaxContributionPerSummary = 0;
                LTD.ContributionApplicable = false;
                LTD.BenefitSummaryApplicable = false;
                LTD.RateApplicable = false;
                LTD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(LTD);

                BenefitSummaryStructure EAP = new BenefitSummaryStructure();
                EAP.LOC = cv.EAPLOC;
                EAP.MaxBenefitSummary = 1;
                EAP.MaxContributionPerSummary = 0;
                EAP.ContributionApplicable = false;
                EAP.BenefitSummaryApplicable = false;
                EAP.RateApplicable = false;
                EAP.MaxRatePerBenefitSummary = 0;
                lstMap.Add(EAP);

                BenefitSummaryStructure Wllness = new BenefitSummaryStructure();
                Wllness.LOC = cv.Wellness;
                Wllness.MaxBenefitSummary = 1;
                Wllness.MaxContributionPerSummary = 0;
                Wllness.ContributionApplicable = false;
                Wllness.BenefitSummaryApplicable = false;
                Wllness.RateApplicable = false;
                Wllness.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Wllness);

                BenefitSummaryStructure Telemedicine = new BenefitSummaryStructure();
                Telemedicine.LOC = "Telemedicine";
                Telemedicine.MaxBenefitSummary = 1;
                Telemedicine.MaxContributionPerSummary = 0;
                Telemedicine.ContributionApplicable = false;
                Telemedicine.BenefitSummaryApplicable = false;
                Telemedicine.RateApplicable = false;
                Telemedicine.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Telemedicine);

                BenefitSummaryStructure PatientAdvocyProgram = new BenefitSummaryStructure();
                PatientAdvocyProgram.LOC = "Patient Advocacy";
                PatientAdvocyProgram.MaxBenefitSummary = 1;
                PatientAdvocyProgram.MaxContributionPerSummary = 0;
                PatientAdvocyProgram.ContributionApplicable = false;
                PatientAdvocyProgram.BenefitSummaryApplicable = false;
                PatientAdvocyProgram.RateApplicable = false;
                PatientAdvocyProgram.MaxRatePerBenefitSummary = 0;
                lstMap.Add(PatientAdvocyProgram);

                return lstMap;
            }
        }
        public static ValidationViewModel ValidateSelectedSummaries(List<SummarySelectionViewModel> lstSeuumaries)
        {
            ValidationViewModel ViewErrowModel = new ValidationViewModel();
            foreach (BenefitSummaryStructure item in TrifoldSummary.BenefitSummarySelectionMap)
            {
                int count = 0;

                if (item.LOC == cv.LifeADDLOC)
                    count = lstSeuumaries.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).Count();
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                    count = lstSeuumaries.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).Count();
                else
                    count = lstSeuumaries.Where(r => r.LOC == item.LOC).Count();

                if (item.LOC == cv.MedicalLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " medical " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing medical summary election";
                        break;
                    }
                }
                if (item.LOC == cv.DentalLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " dental " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing dental summary election";
                        break;
                    }
                }
                if (item.LOC == cv.VisionLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " vision " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing vision summary election";
                        break;
                    }
                }
                if (item.LOC == cv.HRALOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " HRA " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing HRA summary election";
                        break;
                    }
                }
                if (item.LOC == cv.HSALOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " HSA " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing HSA summary election";
                        break;
                    }
                }
                if (item.LOC == cv.LifeADDLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " Life and AD&D " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing Life and AD&D summary election";
                        break;
                    }
                }
                if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " Voluntary Life " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing Voluntary Life summary election";
                        break;
                    }
                }
                if (item.LOC == cv.STDLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " STD " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing STD summary election";
                        break;
                    }
                }
                if (item.LOC == cv.LTDLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " LTD " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing LTD summary election";
                        break;
                    }
                }
                if (item.LOC == cv.EAPLOC)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " EAP " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing EAP summary election";
                        break;
                    }
                }
                if (item.LOC == cv.Wellness)
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " Wellness " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing Wellness summary election";
                        break;
                    }
                }
                if (item.LOC == "401K")
                {
                    if (count > item.MaxBenefitSummary)
                    {
                        ViewErrowModel.IsSuccess = false;
                        ViewErrowModel.ErrorMessage = "This deliverable can only accomodate " + item.MaxBenefitSummary.ToString() + " 401K " + (item.MaxBenefitSummary <= 1 ? "benefit summary" : "benefit summaries") + ". if you wish to select another benefit summary, you will need to uncheck an existing 401K summary election";
                        break;
                    }
                }

                if (item.LOC != cv.LifeADDLOC)
                {


                }
                else
                {
                }

            }
            return ViewErrowModel;
        }
        public static ValidationViewModel ValidateBenefitSummaryOptions(List<SummaryOptionItemViewModel> BenefitSummaryOptions)
        {
            ValidationViewModel ViewErroModel = new ValidationViewModel();
            ViewErroModel.IsSuccess = true;
            int SelectionCount = BenefitSummaryOptions.Where(r => r.SummaryId > 0).ToList().Count();
            if (SelectionCount == 0)
            {
                  ViewErroModel.IsSuccess = false;
                  ViewErroModel.ErrorMessage = "You have not selected any Benefit Summary, please select atleast one Benefit Summary.";
                  return ViewErroModel;
            }

            var tempResult = from summry in BenefitSummaryOptions
                             group summry by new { summry.LOC, summry.SummaryId, summry.PlanId } into eg
                             where eg.Count() > 1 && eg.Key.SummaryId != 0 && eg.Key.PlanId != 0
                             select new { eg.Key.SummaryId, eg.Key.PlanId, eg.Key.LOC };
            if (tempResult.Count() > 0)
            {
                ViewErroModel.IsSuccess = false;
                ViewErroModel.ErrorMessage = "You have selected duplicate Benefit Summaries for " + tempResult.First().LOC + ", please select unique Benefit Summaries.";
                return ViewErroModel;
            }
            return ViewErroModel;
        }
        public static Dictionary<string, ClientBenefitSummaryUIViewModel> ViewConfig
        {
            get
            {
                Dictionary<string, ClientBenefitSummaryUIViewModel> tempConfig = new Dictionary<string, ClientBenefitSummaryUIViewModel>();
                ClientBenefitSummaryUIViewModel viewPlanBenefitSummary = new ClientBenefitSummaryUIViewModel();
                viewPlanBenefitSummary.IsNextButtonVisibles = true;
                viewPlanBenefitSummary.IsPreviousButtonVisibles = false;
                viewPlanBenefitSummary.IsCreateButtonVisibles = false;

                viewPlanBenefitSummary.NextButtonText = "Selected Summary Options >>";
                viewPlanBenefitSummary.PreviousButtonText = "";
                viewPlanBenefitSummary.CreateButtonText = "";
                viewPlanBenefitSummary.CriteraPageIndexText = "1 of 3";
                viewPlanBenefitSummary.IsDeliverableDescriptionVisible = true;
                viewPlanBenefitSummary.IsCriteriaInformarionVisible = false;
                tempConfig["viewPlanBenefitSummary"] = viewPlanBenefitSummary;

                ClientBenefitSummaryUIViewModel viewBenefitSummarySelection = new ClientBenefitSummaryUIViewModel();
                viewBenefitSummarySelection.IsNextButtonVisibles = true;
                viewBenefitSummarySelection.IsPreviousButtonVisibles = true;
                viewBenefitSummarySelection.IsCreateButtonVisibles = false;

                viewBenefitSummarySelection.NextButtonText = "Additional Output Options >>";
                viewBenefitSummarySelection.PreviousButtonText = "<< Deliverable Decisions";
                viewBenefitSummarySelection.CreateButtonText = "";
                viewBenefitSummarySelection.CriteraPageIndexText = "2 of 3";
                viewBenefitSummarySelection.IsDeliverableDescriptionVisible = false;
                viewBenefitSummarySelection.IsCriteriaInformarionVisible = true;
                tempConfig["viewBenefitSummarySelection"] = viewBenefitSummarySelection;

                ClientBenefitSummaryUIViewModel viewMobileAppLegalNotice = new ClientBenefitSummaryUIViewModel();
                viewMobileAppLegalNotice.IsNextButtonVisibles = false;
                viewMobileAppLegalNotice.IsPreviousButtonVisibles = true;
                viewMobileAppLegalNotice.IsCreateButtonVisibles = true;

                viewMobileAppLegalNotice.NextButtonText = "";
                viewMobileAppLegalNotice.PreviousButtonText = "<< Summary Options";
                viewMobileAppLegalNotice.CreateButtonText = "Create";
                viewMobileAppLegalNotice.CriteraPageIndexText = "3 of 3";
                viewMobileAppLegalNotice.IsDeliverableDescriptionVisible = false;
                viewMobileAppLegalNotice.IsCriteriaInformarionVisible = true;
                tempConfig["viewMobileAppLegalNotice"] = viewMobileAppLegalNotice;

                return tempConfig;
            }
        }


    }

   
}
