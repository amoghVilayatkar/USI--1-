﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using StringTrimmer;
using Microsoft.Office.Core;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate10_SimpleSummary : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string Std_Plan = string.Empty;
        int PremiumTable_counter = 10;

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        public void WriteFieldToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, string selectedcolor, string IncomeProtectionPlanList, DropDownList ddlImageOption = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                int index = -1;

                oWordDoc.Tables[1].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[1].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[1].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[1].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[1].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);
                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    #region img
                                    if (fieldName.Contains("Picture_1"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //  Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //  var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 1.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.75f);
                                        //shape.Height = oWordApp.InchesToPoints(2.05f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 3.95f, 2.27f);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture_2"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 2.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 2.63f, 4.04f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }

                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 3"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 3.jpg"), false, true);
                                        //shape.Width = oWordApp.InchesToPoints(3.01f);
                                        //shape.Height = oWordApp.InchesToPoints(2.23f);
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 3", 3.01f, 2.23f);
                                        continue;
                                    }
                                    //if (fieldName.Contains("Picture 4"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 4.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    //if (fieldName.Contains("Picture 5"))
                                    //{
                                    //    myMergeField.Delete();
                                    //    object missing = System.Type.Missing;
                                    //    Word.Range r = oWordDoc.Range();
                                    //    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                    //    var shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 5.jpg"), false, true);
                                    //    shape.Width = oWordApp.InchesToPoints(7.54f);
                                    //    shape.Height = oWordApp.InchesToPoints(2.05f);
                                    //    continue;
                                    //}
                                    if (fieldName.Contains("Picture 6"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);

                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 6.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 6", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(1.96f);
                                        //shape.Height = oWordApp.InchesToPoints(1.51f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 7"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);

                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 6.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 7", 1.62f, 1.4f);
                                        //shape.Width = oWordApp.InchesToPoints(1.96f);
                                        //shape.Height = oWordApp.InchesToPoints(1.51f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeCenter;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 13"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 7.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 13", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(4.22f);
                                        //shape.Height = oWordApp.InchesToPoints(1.12f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 17"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 7.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 17", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(4.22f);
                                        //shape.Height = oWordApp.InchesToPoints(1.12f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            //shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 8"))
                                    {
                                        myMergeField.Delete();
                                        //object missing = System.Type.Missing;
                                        //Word.Range r = oWordDoc.Range();
                                        //r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        //var inline_shape = r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Value) + "/Picture 8.jpg"), false, true);

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 8", 2.8f, 2.27f);
                                        //shape.Width = oWordApp.InchesToPoints(2.67f);
                                        //shape.Height = oWordApp.InchesToPoints(5.2f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            //shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionBottomMarginArea;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeRight;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    #endregion

                                    if (fieldName.Contains("Client_Name1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());

                                        continue;
                                    }

                                    if (fieldName.Contains("Wellness Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("client website"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (!string.IsNullOrEmpty(AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString()))
                                        {
                                            oWordApp.Selection.TypeText(" | " + AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Effective Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Effective Year Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan minus 1 day"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string renewDate = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime rDate = Convert.ToDateTime(renewDate).AddDays(-1);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(rDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(rDate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("First Medical Plan Renewal Year"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("HSA Medical Plan Renewal Year"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                                        continue;
                                    }
                                    //if (fieldName.Contains("unmarriedchildtoage"))
                                    //{
                                    //    myMergeField.Select();
                                    //    //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //}
                                    //if (fieldName.Contains("definitionofdomesticpartner"))
                                    //{
                                    //    myMergeField.Select();
                                    //    //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                    //        if (domesticPartner.Trim().Length == 0)
                                    //        {
                                    //            oWordApp.Selection.TypeText(domesticPartner);
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(domesticPartner.Trim());
                                    //        }
                                    //    }
                                    //}
                                    //if (Emp.Rows.Count > 0)
                                    //{
                                    //    if (fieldName.Contains("Employee Status"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("Working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                    //        continue;
                                    //    }

                                    //    if (fieldName.Contains("Frequency_Eligibility"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    if (fieldName.Contains("Employee Status"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("Working"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }

                                    //    if (fieldName.Contains("Frequency"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //    if (fieldName.Contains("unitofmeasure"))
                                    //    {
                                    //        myMergeField.Select();
                                    //        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //        oWordApp.Selection.TypeText(" ");
                                    //        continue;
                                    //    }
                                    //}

                                    //if (fieldName.Contains("medicalplanwaitingperiod"))
                                    //{
                                    //    myMergeField.Select();
                                    //    //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim()))
                                    //        {
                                    //            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().ToLower().Trim());
                                    //        }
                                    //        else
                                    //        {
                                    //            oWordApp.Selection.TypeText(" ");
                                    //        }
                                    //        continue;
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //    continue;
                                    //}


                                    ////if (ddlBRC.SelectedItem.Text != "None")
                                    if (ddlBRCSelectedValue == "YES")
                                    {
                                        if (fieldName.Contains("BRC_Details"))
                                        {
                                            myMergeField.Select();
                                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            //oWordApp.Selection.TypeText("\f"); // For page break
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }

                                    ////if (BRCindex > -1)
                                    if (ddlBRCSelectedValue == "YES" && BRCList.Count > 0)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("CONTACT INFORMATION");
                                        continue;
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date of First Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(renewdate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewdate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    // For header and sub header field writing starts here
                                    if (fieldName.Contains("WHAT’S INSIDE THIS GUIDE?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("WHAT’S INSIDE THIS GUIDE?");
                                        continue;
                                    }

                                    if (fieldName.Contains("INTRODUCTION"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("INTRODUCTION");
                                        continue;
                                    }

                                    if (fieldName.Contains("Takes Your Wellness Seriously"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Takes Your Wellness Seriously");
                                        continue;
                                    }

                                    if (fieldName.Contains("EMPLOYEE CONTRIBUTION RATES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("EMPLOYEE CONTRIBUTION RATES");
                                        continue;
                                    }

                                    if (fieldName.Contains("GET MORE VALUE FROM YOUR PLANS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("GET MORE VALUE FROM YOUR PLANS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Minimize your out-of-pocket expenses"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Minimize your out-of-pocket expenses");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use the Emergency Room ONLY for emergencies"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Use the Emergency Room ONLY for emergencies");
                                        continue;
                                    }

                                    if (fieldName.Contains("Annual physical exams and cancer screening tests are 100% covered!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Annual physical exams and cancer screening tests are 100% covered!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Preventive dental care is covered 100%!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Preventive dental care is covered 100%!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Save tax dollars and enroll in a Flexible Spending Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Save tax dollars and enroll in a Flexible Spending Account");
                                        continue;
                                    }

                                    if (fieldName.Contains("Rates Effective"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Effective");
                                        continue;
                                    }

                                    if (fieldName.Contains("MEDICAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("MEDICAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("DENTAL BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DENTAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("In-network vs. out-of-network"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("In-network vs. out-of-network");
                                        continue;
                                    }

                                    if (fieldName.Contains("Be prepared and plan ahead"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Be prepared and plan ahead");
                                        continue;
                                    }

                                    if (fieldName.Contains("VISION BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF VISION BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Using your vision benefit is easy!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Using your vision benefit is easy!");
                                        continue;
                                    }

                                    if (fieldName.Contains("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use-it or lose-it benefit"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Use-it or lose-it benefit");
                                        continue;
                                    }

                                    if (fieldName.Contains("Example of tax savings"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Example of tax savings");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("INCOME PROTECTION BENEFIT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("INCOME PROTECTION BENEFIT");
                                        continue;
                                    }
                                    if (fieldName.Contains("IncomeProtectionPlanList"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(IncomeProtectionPlanList);

                                        continue;
                                    }
                                    if (fieldName.Contains("SUMMARY OF BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("SUMMARY OF BENEFITS");
                                        continue;
                                    }



                                    if (fieldName.Contains("VALUE-ADDED PROGRAMS AND SERVICES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("VALUE-ADDED PROGRAMS AND SERVICES");
                                        continue;
                                    }

                                    if (fieldName.Contains("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES");
                                        continue;
                                    }

                                    if (fieldName.Contains("CONTACT NUMBERS & WEBSITE LINKS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("CONTACT NUMBERS & WEBSITE LINKS");
                                        continue;
                                    }

                                    if (fieldName.Contains("THE BENEFIT RESOURCE CENTER"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("THE BENEFIT RESOURCE CENTER");
                                        continue;
                                    }

                                    if (fieldName.Contains("If you have any questions, please contact the following:"))
                                    {
                                        myMergeField.Select();
                                        // oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("If you have any questions, please contact the following:");
                                        continue;
                                    }

                                    if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call the BRC for assistance with:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call the BRC for assistance with:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call Toll Free"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call Toll Free");
                                        continue;
                                    }

                                    if (fieldName.Contains("or email"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("or email");
                                        continue;
                                    }

                                    if (fieldName.Contains("This guide is provided to you by"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("This guide is provided to you by");
                                        continue;
                                    }

                                    if (fieldName.Contains("and BRC"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("and");
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        /// <param name="ddlLifeADD">DropDownList ddlLifeADD Object</param>
        /// <param name="ddlVoluntaryADD">DropDownList ddlVoluntaryADD Object</param>
        /// <param name="ddlMarketplaceCoverage">DropDownList ddlMarketplaceCoverage Object</param>
        /// <param name="ddlCreditableCoverage">DropDownList ddlCreditableCoverage Object</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteNoticeSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlLifeADD, DropDownList ddlVoluntaryADD, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 26")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        //shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                bool flag = false;
                bool flag1 = false;

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (ddlAnnualLegalNotice.SelectedIndex == 1 && ddlCreditableCoverage.SelectedIndex > 0)
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (ddlAnnualLegalNotice.SelectedIndex == 1 && ddlCreditableCoverage.SelectedIndex > 0)
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                // r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                if ((ddlChipNotice.SelectedIndex >= 1) || (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlCreditableCoverage.SelectedIndex > 0))
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            // Added by Vaibhav for Spanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                if ((ddlChipNotice.SelectedIndex >= 1) || (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlCreditableCoverage.SelectedIndex > 0))
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("OtherProducts"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag1 == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag1 = false;
                                }

                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                //Commented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true, selectedColor, "Enrollment Summary");
                //Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedColor, "Enrollment Summary");
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlMedicalNoOfPlan, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, string selectedcolor)
        {
            try
            {
                int iTotalFields = 0;

                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;

                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string Medical_Old_Carrier1 = null;
                ArrayList arrMedical = new ArrayList();
                string value = string.Empty;
                int Table_Number = 2;
                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 7" || shape.Name == "Text Box 8" || shape.Name == "Text Box 28")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                    if (shape.Name == "Rectangle 3")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                    if (shape.Name == "Rectangle 2")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }

                foreach (Word.Section section in oWordDoc.Sections)
                {
                    Word.HeaderFooter header = section.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                    foreach (Word.Shape shape in header.Shapes)
                    {
                        if (shape.Name == "Text Box 32")
                        {
                            shape.Select();
                            shape.TextFrame.TextRange.Shading.BackgroundPatternColor = wdColor_cell;
                        }
                        if (shape.Name == "Text Box 31")
                        {
                            shape.Select();
                            shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        }
                    }
                }

                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(1, "45");              //Annual Deductible[Per Person]
                HashtableMedical.Add(2, "44");              //Annual Deductible[Maximum Per Family]
                HashtableMedical.Add(3, "53");              //Annual Out-of-Pocket Maximum[Per Person]
                HashtableMedical.Add(4, "52");              //Annual Out-of-Pocket Maximum[Maximum Per Family]
                //HashtableMedical.Add(9, "16");              //Preventive Care[Office Visit]
                //HashtableMedical.Add(10, "571");            //Preventive Care[Well-Child Care]
                HashtableMedical.Add(5, "386");            //Professional[Office Visit]
                HashtableMedical.Add(6, "16");             //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedical.Add(7, "414");            //Outpatient Specialist visit
                //HashtableMedical.Add(13, "414");            //Professional [Outpatient Visit]
                HashtableMedical.Add(8, "295");            //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(9, "409");            //Hospital/Facility[Outpatient Care]
                HashtableMedical.Add(10, "184");            //Other Services[Emergency Room]
                HashtableMedical.Add(11, "287");            //Mental Health/Substance Abuse[Inpatient]
                HashtableMedical.Add(12, "407");            //Mental Health/Substance Abuse[Outpatient]
                HashtableMedical.Add(13, "168");            //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedical.Add(14, "971");            //Other Services[Complex Radiology]
                HashtableMedical.Add(15, "555");            //Other Services[Urgent Care]
                HashtableMedical.Add(16, "107");            //Other Services[Spinal Manipulations]

                HashtableMedicalOutNetwork.Add(1, "45");   //Out-of-Network Benefits[Annual Deductible Per Person]
                HashtableMedicalOutNetwork.Add(2, "44");   //Out-of-Network Benefits[Annual Deductible Family]
                HashtableMedicalOutNetwork.Add(3, "53");   //Out-of-Network Benefits[Annual Out-of-Pocket Max Per Person]
                HashtableMedicalOutNetwork.Add(4, "52");   //Out-of-Network Benefits[Annual Out-of-Pocket Max Family]
                HashtableMedicalOutNetwork.Add(5, "112");  //Out-of-Network Benefits[Coinsurance]
                HashtableMedicalOutNetwork.Add(6, "386");      //Physician Office Visit (Primary)
                HashtableMedicalOutNetwork.Add(7, "16");   //Out-of-Network Benefits[Preventive Care Office Visit]
                //HashtableMedicalOutNetwork.Add(8, "386");  //Out-of-Network Benefits[Preventive Care Office Visit]
                HashtableMedicalOutNetwork.Add(8, "184");  //Out-of-Network Benefits[Emergency Room]
                //HashtableMedical.Add(35, "315");            //Lifetime Maximum
                #endregion

                #region Table color

                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);


                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 4 || i == 6 || i == 10 || i == 14 || i == 17 || i == 22)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }

                #endregion
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string AnnualDeductible_Individual = string.Empty;
                            string AnnualDeductible_Family = string.Empty;
                            string OutOfPocketMax_Individual = string.Empty;
                            string OutOfPocketMax_Family = string.Empty;
                            string AnnualDeductible_Individual_Outnetwork = string.Empty;
                            string AnnualDeductible_Family_Outnetwork = string.Empty;
                            string OutOfPocketMax_Individual_Outnetwork = string.Empty;
                            string OutOfPocketMax_Family_Outnetwork = string.Empty;
                            if (count == 1)
                            {
                                foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                                foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            }
                            # region MergeField
                            Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Number of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlMedicalNoOfPlan.SelectedItem.Text.Trim());
                                    }
                                    if (fieldName.Contains("Medical Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (count == 1)
                                        {
                                            // Previously 'ProductTypeDescription' was suggested by client
                                            //oWordApp.Selection.TypeText(" or the " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " plan with ");
                                            oWordApp.Selection.TypeText(" a " + PlanTable.Rows[k]["SummaryName"].ToString() + " through ");
                                        }
                                        else if (count < 4)
                                        {
                                            oWordApp.Selection.TypeText(", a " + PlanTable.Rows[k]["SummaryName"].ToString() + " through ");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" and a " + PlanTable.Rows[k]["SummaryName"].ToString() + " through ");
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        Medical_Old_Carrier1 = PlanTable.Rows[k]["Carrier"].ToString();
                                        if (count < 4)
                                        {
                                            oWordApp.Selection.TypeText(Medical_Old_Carrier1.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(Medical_Old_Carrier1.Trim());
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("MEDICAL");
                                    }
                                    if (fieldName.Contains("Plan Type (PPO, HMO, POS) Specific Text"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            PlanSpecific = foundPlanTypeRows[0]["PlanSpecific"].ToString();
                                            oWordApp.Selection.TypeText(PlanSpecific.Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("OneMedicalPlan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (Convert.ToInt32(ddlMedicalNoOfPlan.SelectedItem.Text.Trim()) == 1)
                                            myMergeField.Delete();
                                    }
                                    if (fieldName.Contains("MoreMedicalPlan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (Convert.ToInt32(ddlMedicalNoOfPlan.SelectedItem.Text.Trim()) > 1)
                                            myMergeField.Delete();
                                    }
                                    if (fieldName.Contains("PPOField"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            PlanSpecific = PlanTable.Rows[k]["ProductTypeDescription"].ToString();
                                            if (PlanSpecific.Contains("PPO"))
                                                myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("HMOField"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_cell;
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            PlanSpecific = PlanTable.Rows[k]["ProductTypeDescription"].ToString();
                                            if (PlanSpecific.Contains("HMO"))
                                                myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region MedicalTable
                            if (!arrMedical.Contains(PlanTable.Rows[k]["Carrier"].ToString()))
                            {
                                oWordDoc.Tables[1].Cell(2, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(2, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(2, 2).Range.Text = oWordDoc.Tables[1].Cell(2, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString());
                            }

                            oWordDoc.Tables[2].Cell(1, count + 1).Select();
                            oWordDoc.Tables[2].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"] + " " + PlanTable.Rows[k]["PolicyNumber"].ToString();

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: AnnualDeductible_Individual = value; break;
                                            case 2:
                                                if (!string.IsNullOrEmpty(value))
                                                {
                                                    AnnualDeductible_Family = " / " + value;
                                                }
                                                else
                                                {
                                                    AnnualDeductible_Family = value;
                                                }
                                                break;
                                            //case 3: wkSheet.Cells[18, Column_No] = value; break;        // Coinsurance (Percentage)
                                            case 3: OutOfPocketMax_Individual = value; break;
                                            case 4: if (!string.IsNullOrEmpty(value))
                                                {
                                                    OutOfPocketMax_Family = " / " + value;
                                                }
                                                else
                                                {
                                                    OutOfPocketMax_Family = value;
                                                }
                                                break;
                                            case 5: oWordDoc.Tables[2].Cell(7, count + 1).Range.Text = value; break;        // Professional Office Visit 
                                            case 6: oWordDoc.Tables[2].Cell(8, count + 1).Range.Text = value; break;         // Preventive Care Visit
                                            case 7: oWordDoc.Tables[2].Cell(9, count + 1).Range.Text = value; break;        // Specialist Visit
                                            case 8: oWordDoc.Tables[2].Cell(11, count + 1).Range.Text = value; break;        // Hospital/Facility[Inpatient Care]
                                            case 9: oWordDoc.Tables[2].Cell(12, count + 1).Range.Text = value; break;        // Hospital/Facility[Outpatient Care]
                                            case 10: oWordDoc.Tables[2].Cell(13, count + 1).Range.Text = value; break;       // Other Services[Emergency Room]
                                            case 11: oWordDoc.Tables[2].Cell(15, count + 1).Range.Text = value; break;       // Mental Health Inpatient
                                            case 12: oWordDoc.Tables[2].Cell(16, count + 1).Range.Text = value; break;       // Mental Health Outpatient
                                            case 13: oWordDoc.Tables[2].Cell(18, count + 1).Range.Text = value; break;       // Other Services[Diagnostic X-Ray and Lab Tests]
                                            case 14: oWordDoc.Tables[2].Cell(19, count + 1).Range.Text = value; break;       // Other Services[Complex Radiology]
                                            case 15: oWordDoc.Tables[2].Cell(20, count + 1).Range.Text = value; break;       // Other Services[Urgent Care]
                                            case 16: oWordDoc.Tables[2].Cell(21, count + 1).Range.Text = value; break;       // Other Services[Spinal Manipulations]
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[2].Cell(3, count + 1).Range.Text = AnnualDeductible_Individual.Trim() + AnnualDeductible_Family;
                            oWordDoc.Tables[2].Cell(5, count + 1).Range.Text = OutOfPocketMax_Individual.Trim() + OutOfPocketMax_Family;


                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: AnnualDeductible_Individual_Outnetwork = value; break;
                                            case 2:
                                                if (!string.IsNullOrEmpty(value))
                                                {
                                                    AnnualDeductible_Family_Outnetwork = " / " + value;
                                                }
                                                else
                                                {
                                                    AnnualDeductible_Family_Outnetwork = value;
                                                }
                                                break;
                                            //case 3: wkSheet.Cells[18, Column_No] = value; break;        // Coinsurance (Percentage)
                                            case 3: OutOfPocketMax_Individual_Outnetwork = value; break;
                                            case 4: if (!string.IsNullOrEmpty(value))
                                                {
                                                    OutOfPocketMax_Family_Outnetwork = " / " + value;
                                                }
                                                else
                                                {
                                                    OutOfPocketMax_Family_Outnetwork = value;
                                                }
                                                break;
                                            case 5: oWordDoc.Tables[2].Cell(25, count + 1).Range.Text = value; break;     // Coinsurance (Percentage)   
                                            case 6: oWordDoc.Tables[2].Cell(26, count + 1).Range.Text = value; break;
                                            case 7: oWordDoc.Tables[2].Cell(27, count + 1).Range.Text = value; break;
                                            case 8: oWordDoc.Tables[2].Cell(28, count + 1).Range.Text = value; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[2].Cell(23, count + 1).Range.Text = AnnualDeductible_Individual_Outnetwork.Trim() + AnnualDeductible_Family_Outnetwork;
                            oWordDoc.Tables[2].Cell(24, count + 1).Range.Text = OutOfPocketMax_Individual_Outnetwork.Trim() + OutOfPocketMax_Family_Outnetwork;

                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string selectedcolor)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int count = 1;
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                int Table_Number = 3;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                HashtablePrescriptionDrugs.Add(3, "578");   //Prescription Drug Deductible
                HashtablePrescriptionDrugs.Add(5, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(6, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(7, "84");    //Prescription Categories[Non Formulary]
                //HashtablePrescriptionDrugs.Add(4, "380");   //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(8, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();
                HashtableMailOrder.Add(10, "211");   //Mail Order[Generic]
                HashtableMailOrder.Add(11, "76");    //Mail Order[Formulary]
                HashtableMailOrder.Add(12, "82");    //Mail Order[Non Formulary]
                //HashtableMailOrder.Add(4, "378");   //Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(13, "884");    //Mail Order[Preferred Specialty]
                #endregion
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);
                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 4 || i == 9)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Prescription Drugs"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("PRESCRIPTION DRUGS");
                                    }
                                }
                            }
                            #endregion

                            # region Priscription Drugs IN_Network
                            oWordDoc.Tables[3].Cell(1, count + 1).Select();
                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"] + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString();
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    }
                                }
                            }
                            #endregion

                            #region Mail Order In_Network
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        public void WriteDentalSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, string selectedcolor, int dentalindex)
        {
            try
            {
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;

                string OldCarrier = "";
                string Dental_Old_Carrier = null;
                string value = string.Empty;
                string AnnualDeductible_Individual = string.Empty;
                string AnnualDeductible_Family = string.Empty;
                int Table_Number = 4;
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 4 || i == 7 || i == 14 || i == 19)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                #region HashtableDental
                Hashtable HashtableDental = new Hashtable();
                HashtableDental.Add(1, "55");       //Benefit Year Maximum 
                HashtableDental.Add(2, "45");       //Annual Deductible[Individual]
                HashtableDental.Add(3, "44");       //Annual Deductible[Family]
                HashtableDental.Add(4, "566");      //Annual Deductible[Deductible waived for Preventive]
                HashtableDental.Add(5, "164");      //Dental Categories[Preventive & Diagnostic Care]
                HashtableDental.Add(6, "64");      //Dental Categories[Basic Restorative Care]
                HashtableDental.Add(7, "190");    //Endodontic Treatment
                HashtableDental.Add(8, "419");    //Periodontic Treatment
                HashtableDental.Add(9, "336");     //Dental Categories[Major Restorative Care]
                HashtableDental.Add(10, "255");     //Implants
                HashtableDental.Add(11, "392");     //Orthodontia[Benefits]
                HashtableDental.Add(12, "314");     //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDental.Add(13, "152");     //Orthodontia[Dependent Children]
                HashtableDental.Add(14, "17");      //Adults (and Covered Full-time Students, if Eligible)
                HashtableDental.Add(15, "565");     //Additional Features[Waiting Periods]
                HashtableDental.Add(16, "465");     //Additional Features[Usual Customary & Reasonable]
                #endregion
                int count = 1;

                ConstantValue cv = new ConstantValue();

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 9")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                            //foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            #region MergeField
                            Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("DENTAL");
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (count > 1)
                                        {
                                            if (Dental_Old_Carrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" or " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Dental_Old_Carrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier-ToFind"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (dentalindex == 2)
                                        {
                                            oWordApp.Selection.TypeText("To find a " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier Phone Number" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (foundRows.Count() > 0)
                                        {
                                            if (count > 1)
                                            {
                                                oWordApp.Selection.TypeText(" provider, call " + foundRows[0]["PhoneNumber"].ToString() + ".");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("Pull Plan Specific Text (PPO or Indemnity)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region DetalTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(3, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(3, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(3, 2).Range.Text = oWordDoc.Tables[1].Cell(3, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            oWordDoc.Tables[4].Cell(1, count + 1).Select();
                            oWordDoc.Tables[4].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"] + " " + PlanTable.Rows[k]["PolicyNumber"].ToString();

                            foreach (int key in HashtableDental.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {

                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDental[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: oWordDoc.Tables[4].Cell(3, count + 1).Range.Text = value; break;
                                            case 2: AnnualDeductible_Individual = value; break;
                                            case 3:
                                                if (!string.IsNullOrEmpty(value) && !string.IsNullOrWhiteSpace(value))
                                                {
                                                    AnnualDeductible_Family = " / " + value;
                                                }
                                                else
                                                {
                                                    AnnualDeductible_Family = value;
                                                }
                                                break;
                                            case 4: oWordDoc.Tables[4].Cell(6, count + 1).Range.Text = value; break;
                                            case 5: oWordDoc.Tables[4].Cell(8, count + 1).Range.Text = value; break;
                                            case 6: oWordDoc.Tables[4].Cell(9, count + 1).Range.Text = value; break;
                                            case 7: oWordDoc.Tables[4].Cell(10, count + 1).Range.Text = value; break;
                                            case 8: oWordDoc.Tables[4].Cell(11, count + 1).Range.Text = value; break;
                                            case 9: oWordDoc.Tables[4].Cell(12, count + 1).Range.Text = value; break;
                                            case 10: oWordDoc.Tables[4].Cell(13, count + 1).Range.Text = value; break;
                                            case 11: oWordDoc.Tables[4].Cell(15, count + 1).Range.Text = value; break;
                                            case 12: oWordDoc.Tables[4].Cell(16, count + 1).Range.Text = value; break;
                                            case 13: oWordDoc.Tables[4].Cell(17, count + 1).Range.Text = value; break;
                                            case 14: oWordDoc.Tables[4].Cell(18, count + 1).Range.Text = value; break;
                                            case 15: oWordDoc.Tables[4].Cell(20, count + 1).Range.Text = value; break;
                                            case 16: oWordDoc.Tables[4].Cell(21, count + 1).Range.Text = value; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[4].Cell(5, count + 1).Range.Text = AnnualDeductible_Individual.Trim() + AnnualDeductible_Family;
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, string selectedcolor)
        {
            try
            {
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableSTD
                HashtableSTD.Add(3, "8");       //Elimination Period[Accident]
                HashtableSTD.Add(4, "505");     //Elimination Period[Sickness]
                HashtableSTD.Add(6, "569");     //Benefit Features[Maximum Benefit]
                HashtableSTD.Add(7, "350");     //Benefit Features[Maximum Benefit Duration]
                HashtableSTD.Add(66, "373");    //Benefit Features[Miniumum enefit]
                HashtableSTD.Add(8, "449");     //Benefit Features[Pre-Existing Condition Limitation]
                #endregion
                int Table_Number = 8;
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 5)
                    {
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                int columnCount = 1;
                int iTotalFields = 0;
                string OldCarrier = "";
                string minimum_weekly_benefit = "";
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 20")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region STDTable Writing
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(6, 2).Select();
                                Std_Plan = PlanTable.Rows[k]["Carrier"].ToString();
                                if (!string.IsNullOrEmpty(Std_Plan))
                                {
                                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = Std_Plan;
                                }
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }//IfClose
                            oWordDoc.Tables[8].Cell(1, columnCount + 1).Select();
                            oWordDoc.Tables[8].Cell(1, columnCount + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {

                                        if (key == 66)
                                        {
                                            minimum_weekly_benefit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 6)
                                        {
                                            oWordDoc.Tables[8].Cell(key, columnCount + 1).Range.Text = minimum_weekly_benefit + "up to a maximum of " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per week";
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[8].Cell(key, columnCount + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }//InnerForEach
                            }//OuterForEach

                            #endregion

                            #region STD Merge Field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;
                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;
                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }
                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Group Short Term Disability Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("GROUP SHORT TERM DISABILITY");
                                    }
                                    if (fieldName.Contains("Selected STD Plan Carrier" + columnCount.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (columnCount > 1)
                                        {
                                            oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString());
                                        }
                                        else
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString());
                                    }
                                }//IFMERGEFIELDClose
                            }
                            #endregion
                            columnCount++;
                        }
                    }
                }//ForLoopClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LTDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan</param>
        public void WriteLTDSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, string selectedcolor)
        {
            try
            {
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                string OldCarrier = "";
                int columnCount = 1;
                string minimum_monthly_benefit = "";
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                #region HashtableLTD
                HashtableLTD.Add(3, "181");     //Benefits[Elimination Period]
                HashtableLTD.Add(4, "374");     //Benefits[Maximum Monthly Benefit]
                HashtableLTD.Add(44, "371");    //Benefits[Minimum Monthly Benefit]
                HashtableLTD.Add(5, "351");     //Benefits[Maximum Benefit Period]
                HashtableLTD.Add(6, "141");     //Benefits[Definition of Disability]
                HashtableLTD.Add(7, "449");     //Benefits[Pre-Existing Condition Limitation]
                #endregion
                int Table_Number = 9;
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 21")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region LTDTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(6, 2).Select();
                                if (!string.IsNullOrEmpty(Std_Plan))
                                {
                                    if (Std_Plan != PlanTable.Rows[k]["Carrier"].ToString())
                                    {
                                        oWordDoc.Tables[1].Cell(6, 2).Range.Text = oWordDoc.Tables[1].Cell(6, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                    }
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            oWordDoc.Tables[9].Cell(1, columnCount + 1).Select();
                            oWordDoc.Tables[9].Cell(1, columnCount + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            #region HASH Table Iteration Logic
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        if (key == 44)
                                        {
                                            minimum_monthly_benefit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 4)
                                        {
                                            oWordDoc.Tables[9].Cell(key, columnCount + 1).Range.Text = minimum_monthly_benefit + "upto a " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "monthly maximum";
                                        }

                                        if (key == 5)
                                        {
                                            if (dr["UOM"].ToString() != "text")
                                            {
                                                oWordDoc.Tables[9].Cell(key, columnCount + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[9].Cell(key, columnCount + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[9].Cell(key, columnCount + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }//InnerForeachCloser
                            }//OuterForeachCloser
                            #endregion

                            #endregion

                            #region LTD Merge Field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;
                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;
                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }
                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Group Long Term Disability Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("GROUP LONG TERM DISABILITY");
                                    }
                                    if (fieldName.Contains("Selected LTD Plan Carrier" + columnCount.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (columnCount > 1)
                                        {
                                            oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString());
                                        }
                                        else
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString());
                                    }
                                }
                            }//ForeachCloser
                            #endregion
                            columnCount++;
                        }
                    }//OuterIfCloser
                }//ForLoopCloser
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        public void WriteVisionSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, string selectedcolor)
        {
            try
            {
                Hashtable HashtableVisionBenefit = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefit.Add(3, "195");   //Examination[Copay]
                HashtableVisionBenefit.Add(4, "344");   //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefit.Add(6, "194");   //Examination[Frequency]
                HashtableVisionBenefit.Add(7, "309");   //Hardware[Lenses]
                HashtableVisionBenefit.Add(8, "207");   //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefit.Add(9, "122");   //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(11, "507");      //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefit.Add(12, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(13, "208");     //Covered Services – Frames
                #endregion
                int Table_Number = 5;
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 5 || i == 10)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                int count = 1;

                string OldCarrier = "";

                string Vision_Old_Carrier = null;
                ConstantValue cv = new ConstantValue();

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 11")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        //shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField
                            Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("VISION");
                                    }

                                    if (fieldName.Contains("Vision Plan Carrier" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (count > 1)
                                        {
                                            if (Vision_Old_Carrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" or " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Vision_Old_Carrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                    }
                                }
                            }

                            #endregion

                            # region VisionBenefitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(4, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(4, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(4, 2).Range.Text = oWordDoc.Tables[1].Cell(4, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            oWordDoc.Tables[5].Cell(1, count + 1).Select();
                            oWordDoc.Tables[5].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"] + " " + PlanTable.Rows[k]["PolicyNumber"].ToString();

                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + dr["exclusionsLimitations"].ToString().Trim();
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLifeADDSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, ArrayList ADDBenefitColumnIdList, DataTable CarrierSpecific, string selectedcolor)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;
                double benefitamount = 0;
                string age = "";
                int Table_Number = 6;
                string strPlanName = String.Empty;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 6 || i == 10 || i == 14)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                #region HashtableGroupLifeADDBenifit
                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                HashtableGroupLifeADDBenifit.Add(3, "186");     //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(4, "188");     //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(5, "187");     //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(7, "517");     //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(8, "519");     //Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(9, "518");     //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(11, "102");    //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(12, "104");    //Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(13, "103");    //Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(14, "2");      //age
                HashtableGroupLifeADDBenifit.Add(15, "3");      //age
                HashtableGroupLifeADDBenifit.Add(16, "4");      //age
                HashtableGroupLifeADDBenifit.Add(17, "5");      //age
                #endregion

                #region HashtableADD
                Hashtable hashTableADDBenifit = new Hashtable();
                hashTableADDBenifit.Add(1, "186");  //Employee [Benefit Amount]
                #endregion


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    bool containsadd = ProductDS.Tables["ProductTable"].AsEnumerable().Any(row => row.Field<Int32>("productTypeID") == 270);
                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.GroupTermLifePlanType_CommonCriteria) || PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.LifeADDLOC))
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                #region GroupLifeADDBenifitTable
                                if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                                {
                                    oWordDoc.Tables[1].Cell(5, 2).Select();
                                    if (count == 1)
                                    {
                                        oWordDoc.Tables[1].Cell(5, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[1].Cell(5, 2).Range.Text = oWordDoc.Tables[1].Cell(5, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                    }

                                    OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                /* The following line changed beacause we merging the first cell of table to Display the carrier name in correct format*/
                                oWordDoc.Tables[6].Cell(1, count + 1).Select();
                                oWordDoc.Tables[6].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"] + " " + PlanTable.Rows[k]["PolicyNumber"].ToString();

                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key < 14)
                                            {
                                                oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }

                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            int ch = int.Parse(dr["attributeID"].ToString());
                                            switch (ch)
                                            {
                                                case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                                case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                                case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                                case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                                case 186:
                                                    if (dr["value"].ToString().Trim() != "")
                                                    {
                                                        string str = dr["value"].ToString().Trim();
                                                        bool isNum = double.TryParse(str, out benefitamount);
                                                        if (isNum)
                                                        {
                                                        }
                                                        else
                                                        {
                                                            benefitamount = 0;
                                                        }
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0; break;
                                                    }
                                            }
                                        }
                                    }
                                }
                                if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().ToLower() != cv.LifeADDLOC.ToLower())
                                {
                                    oWordDoc.Tables[6].Rows[16].Delete();
                                    oWordDoc.Tables[6].Rows[15].Delete();
                                    oWordDoc.Tables[6].Rows[14].Delete();
                                }
                                #endregion

                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Group Life Benefits"))
                                        {
                                            myMergeField.Select();
                                            if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                                            {
                                                oWordApp.Selection.TypeText("LIFE AND AD&D INSURANCE");
                                                strPlanName = "LIFE AND AD&D INSURANCE";
                                            }
                                            if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                            {
                                                oWordApp.Selection.TypeText("LIFE INSURANCE");
                                                strPlanName = "LIFE INSURANCE";
                                            }
                                        }
                                        if (fieldName.Contains("GroupLifeADDTaxation"))
                                        {
                                            if (benefitamount > 50000)
                                            {
                                                myMergeField.Delete();
                                            }
                                        }
                                        if (fieldName.Contains("Life Plan Type" + count.ToString()))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (count > 1)
                                            {
                                                // Previously 'ProductTypeDescription' was suggested by client
                                                //oWordApp.Selection.TypeText(" or the " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " plan with ");
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["SummaryName"].ToString());
                                            }
                                            else
                                            {
                                                // Previously 'ProductTypeDescription' was suggested by client
                                                //oWordApp.Selection.TypeText(PlanTable.Rows[k]["ProductTypeDescription"].ToString());

                                                oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                            }
                                        }
                                        if (fieldName.Contains("Reduction of Benefit Schedule Return Age"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            if (age != "")
                                            {
                                                oWordApp.Selection.TypeText(age.Trim());
                                            }
                                            else
                                            {
                                                myMergeField.Delete();
                                            }
                                        }
                                    }
                                }
                                #endregion
                                count++;
                            }
                        }
                    }
                    //else if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.ADNDPlanType_CommonCriteria))
                    else if (containsadd)
                    {
                        #region merge fields
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("AD&D"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText("ACCIDENTAL DEATH & DISMEMBERMENT (AD&D)");
                                }
                                if (fieldName.Contains("ScheduleOfBenefit"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    foreach (int key in hashTableADDBenifit.Keys)
                                    {
                                        foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                        {
                                            if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableADDBenifit[key].ToString())
                                            {
                                                oWordApp.Selection.TypeText(dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + "" + dr["ancillaryText"].ToString() + "" + dr["exclusionsLimitations"].ToString().Trim());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 17")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        shape.TextFrame.ContainingRange.Text = strPlanName;
                    }
                    else if (shape.Name == "Text Box 18")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeADDSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, DataTable CarrierSpecific, string selectedcolor)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                double benefitamount = 0;
                string OldCarrier = "";
                int count = 1;
                int iTotalFields = 0;
                string age = string.Empty;
                string value = string.Empty;
                int Table_Number = 7;
                string strPlanName = String.Empty;
                #region Table color
                oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Table_Number].Rows.Borders.InsideColor = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[Table_Number].Rows.Borders.OutsideColor = comFunObj.border_color(selectedcolor);

                Word.WdColor wdColor_cell = comFunObj.cell_color(selectedcolor);
                for (int i = 1; i <= oWordDoc.Tables[Table_Number].Rows.Count; i++)
                {
                    if (i == 2 || i == 6 || i == 10 || i == 14)
                    {
                        //oWordDoc.Tables[Table_Number].Range.Font.Color = comFunObj.font_color(selectedcolor);
                        oWordDoc.Tables[Table_Number].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                }
                #endregion
                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(7, "516");//Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(8, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(9, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(11, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(13, "103"); //Child(ren)[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(14, "2");//age--
                HashtableVoluntaryLifeADDBenifit.Add(15, "3");//age
                HashtableVoluntaryLifeADDBenifit.Add(16, "4");//age
                HashtableVoluntaryLifeADDBenifit.Add(17, "5");//age
                #endregion


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            bool containsVLife = PlanTable.AsEnumerable().Any(row => cv.VoluntaryLifeADDLOC == row.Field<String>("ProductTypeDescription"));
                            bool containsVLifeadd = PlanTable.AsEnumerable().Any(row => cv.Voluntary_ADNDPlanType_CommonCriteria == row.Field<String>("ProductTypeDescription"));
                            if (!(containsVLife && containsVLifeadd))
                            {
                                oWordDoc.Tables[7].Rows[16].Delete();
                                oWordDoc.Tables[7].Rows[15].Delete();
                                oWordDoc.Tables[7].Rows[14].Delete();
                            }
                            #region VoluntaryLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(7, 2).Select();
                                oWordDoc.Tables[1].Cell(7, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            oWordDoc.Tables[7].Cell(1, count + 1).Select();
                            oWordDoc.Tables[7].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"] + " " + PlanTable.Rows[k]["PolicyNumber"].ToString();
                            string planname = PlanTable.Rows[k]["ProductTypeDescription"].ToString();

                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        if (key < 14)
                                        {
                                            oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }

                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Voluntary Life Benefits"))
                                    {
                                        myMergeField.Select();
                                        if (containsVLife && containsVLifeadd)
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Life and AD&D".ToUpper());
                                            strPlanName = "Voluntary Life and AD&D";
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(planname.Trim().ToUpper());
                                            strPlanName = planname.Trim();
                                        }
                                    }
                                    if (fieldName.Contains("Reduction of Benefit Schedule Return Age"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(age.Trim());
                                    }
                                    if (fieldName.Contains("VoluntaryLifeADDTaxation"))
                                    {
                                        if (benefitamount > 50000)
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Voluntary Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (count > 1)
                                        {
                                            oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["SummaryName"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                        }
                                    }

                                    if (fieldName.Contains("VOLUNTARY_BENEFIT_REDUCTION"))
                                    {
                                        if (planname.Trim().ToUpper() == "VOLUNTARY LIFE")
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("VOLUNTARY_GIAMOUNT"))
                                    {
                                        if (planname.Trim().ToUpper() == "VOLUNTARY LIFE")
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion

                            oWordDoc.Tables[1].Cell(7, 1).Range.Text = strPlanName;
                            count++;
                        }
                    }
                }
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 19")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        shape.TextFrame.ContainingRange.Text = strPlanName.ToUpper();
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableEAP = new Hashtable();
                int columnCount = 1;
                string OldCarrier = "";
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(color);
                #region HashtableEAP
                HashtableEAP.Add(1, "384");//Number of Visit 
                #endregion

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 23")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(color);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(8, 2).Select();
                                if (columnCount == 1)
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = oWordDoc.Tables[1].Cell(7, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {

                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;
                                            Word.Range rngFieldCode = myMergeField.Code;
                                            String fieldText = rngFieldCode.Text;
                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }
                                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                                String fieldName = fieldText.Substring(11, endMerge - 11);
                                                fieldName = fieldName.Trim();
                                                if (fieldName.Contains("Number of Visit Item"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    string number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                }
                                                if (fieldName.Contains("EAP Plan Carrier1"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                }
                                                if (fieldName.Contains("Employee Assistance Program"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("EMPLOYEE ASSISTANCE PLAN");
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                        }//InnerIFCloser
                    }//OuterIFCloser
                }//ForLoopCloser
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, string selectedcolor)
        {
            try
            {
                Hashtable HashtableFSA = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableFSA
                HashtableFSA.Add(1, "150");//Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");//Administration Services – Grace Period
                HashtableFSA.Add(3, "354");//Administration Services-Medical Spending Accounts - Maximum
                #endregion

                int iTotalFields = 0;
                int columnCount = 1;
                string OldCarrier = "";
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 22")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        //shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(9, 2).Select();
                                if (columnCount == 1)
                                {
                                    oWordDoc.Tables[1].Cell(9, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(9, 2).Range.Text = oWordDoc.Tables[1].Cell(8, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            #region HASH TABLE Itaration Logic
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;
                                            Word.Range rngFieldCode = myMergeField.Code;
                                            String fieldText = rngFieldCode.Text;
                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }
                                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                                String fieldName = fieldText.Substring(11, endMerge - 11);
                                                fieldName = fieldName.Trim();
                                                if (key == 3)
                                                {
                                                    if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                        string administration_service_medicalspending = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                        if (administration_service_medicalspending.Trim().Length == 0)
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_medicalspending);
                                                        }
                                                        else
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                        }
                                                    }
                                                }//IFKey_3Close
                                                if (key == 1)
                                                {
                                                    if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                                        string administration_service_dependentcare = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                        if (administration_service_dependentcare.Trim().Length == 0)
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_dependentcare);
                                                        }
                                                        else
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_dependentcare.Trim());
                                                        }
                                                    }
                                                }//IFKey_1Close
                                                if (fieldName.Contains("Flexible Spending Account"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("FLEXIBLE SPENDING ACCOUNT");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }//InnerIFCloser
                    }//OuterIFCloser
                }//ForLoopCloser
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, string selectedColor)
        {
            try
            {
                int iTotalFields = 0;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                string HRACarrier = string.Empty;
                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;
                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "239"); // Health Reimbursement Account Tier 2
                #endregion

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 16")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                }
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            HRACarrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();
                            #region HRA Hash Table Iteration
                            foreach (int key in HashtableHRA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 2)
                                        {
                                            HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }//ForEachInnerClr
                            }//ForEachOuterClr
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;
                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;
                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }
                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Health Reimbursement Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("HEALTH REIMBURSEMENT ACCOUNT (HRA)");
                                    }
                                    if (fieldName.Contains("HRA_Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (!string.IsNullOrEmpty(HRACarrier))
                                        {
                                            oWordApp.Selection.TypeText(HRACarrier);
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("HRA_Benefit Attributes_Health Reimbursement Tier_1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (!string.IsNullOrEmpty(HRA_Tier_1))
                                        {
                                            oWordApp.Selection.TypeText(HRA_Tier_1);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("HRA_Benefit Attributes_Health Reimbursement Tier_2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        if (!string.IsNullOrEmpty(HRA_Tier_2))
                                        {
                                            oWordApp.Selection.TypeText(HRA_Tier_2);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }//MERGEFIELD_IFClr
                            }
                            #endregion
                        }//InnerIFClr
                    }//OuterIFClr
                }//ForLoopClr
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, string selectedColor, ArrayList HSABenefitColumnIdList)
        {
            try
            {
                string carrier = string.Empty;
                string maxAnnualContribution_Individual = string.Empty;
                string maxAnnualContribution_Family = string.Empty;
                int count = 1;
                #region HashtableHSA
                Hashtable HashtableHSA = new Hashtable();
                HashtableHSA.Add(1, "635");//General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSA.Add(2, "636");//General Plan Information – Maximum Annual Contribution/Family
                #endregion

                string OldCarrier = String.Empty;
                // IRS
                DataTable dt_IRS = new DataTable();
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 15")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                }

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(10, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(10, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(10, 2).Range.Text = oWordDoc.Tables[1].Cell(9, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            #region GET Max Annual Contribution/Family and Contribution/Individual
                            carrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();
                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            maxAnnualContribution_Individual = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 2)
                                        {
                                            maxAnnualContribution_Family = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion
                        }//InnerIFCloser
                    }//OuterIFCloser
                }//ForLoopCloser
                #region HSA MERGE FILEDS

                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    String fieldText = rngFieldCode.Text;
                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }
                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        String fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("HSA_Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            if (!string.IsNullOrEmpty(carrier))
                            {
                                oWordApp.Selection.TypeText(carrier);
                            }
                            continue;
                        }
                        if (fieldName.Contains("Health Savings Account"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("HEALTH SAVINGS ACCOUNT (HSA)");
                        }
                        if (fieldName.Contains("IRS Employee Only coverage"))//General Plan Information – Maximum Annual Contribution/Individual
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                            //oWordApp.Selection.TypeText(maxAnnualContribution_Individual);
                            if (!string.IsNullOrEmpty(maxAnnualContribution_Individual))
                            {
                                oWordApp.Selection.TypeText(maxAnnualContribution_Individual);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("IRS Family Coverage"))//General Plan Information – Maximum Annual Contribution/Family
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.Range.Font.Color = wdColor_font;
                            //oWordApp.Selection.TypeText(maxAnnualContribution_Family);
                            if (!string.IsNullOrEmpty(maxAnnualContribution_Family))
                            {
                                oWordApp.Selection.TypeText(maxAnnualContribution_Family);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }//MERGEFIELD_IFClr
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void WriteContactinformationToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor, DataTable dtPlanContactDetails = null)
        {
            try
            {
                //int count = PremiumTable_counter + 1;
                int count = 20;

                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 14")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                }

                oWordDoc.Tables[count].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[count].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[count].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        if (k > 1)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                        oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString()) + "\n" + Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString());
                        //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");

                        var planContactFirstName = (from n in dtPlanContactDetails.AsEnumerable()
                                                    where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                    select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                        var planContactLastName = (from n in dtPlanContactDetails.AsEnumerable()
                                                   where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                   select n.Field<string>("Contact_LastName")).FirstOrDefault();

                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(planContactFirstName) + "  " + Convert.ToString(planContactLastName) + "\n" + Convert.ToString(planContactPhone);

                        k++;
                        rowCnt++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanInfoTable"></param>
        public void WriteAdditionalProductsToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DropDownList ddlEAPNoOfPlan, string selectedColor)
        {
            try
            {
                string Accident_CarrierName = string.Empty;
                string Voluntary_Cancer_CarrierName = string.Empty;
                string Critical_Illness_CarrierName = string.Empty;
                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;
                string wsCarrierName = string.Empty;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 24" || shape.Name == "Text Box 25" || shape.Name == "Text Box 27")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                }

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            Accident_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                            is_Accident_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            Voluntary_Cancer_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                            is_Voluntary_Cancer_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            Critical_Illness_CarrierName = PlanInfoTable.Rows[k]["Carrier"].ToString();
                            is_Voluntary_Critical_Illness_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                        }
                    }
                }//IfPlanInfoTablClose
                // This Method returing the Worksite Benifite Name
                wsCarrierName = comFunObj.GetCarrierList("\n", Accident_CarrierName, Voluntary_Cancer_CarrierName, Critical_Illness_CarrierName);
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    String fieldText = rngFieldCode.Text;
                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }
                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        String fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Worksite Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            if (!string.IsNullOrEmpty(wsCarrierName))
                            {
                                oWordApp.Selection.TypeText(wsCarrierName);
                            }
                            continue;
                        }
                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("PATIENT ADVOCACY PROGRAM"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("PATIENT ADVOCACY PROGRAM");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("TELEMEDICINE"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("TELEMEDICINE");
                                continue;
                            }
                        }

                        if (is_Accident_Selected == true || is_Voluntary_Cancer_Selected == true || is_Voluntary_Critical_Illness_Selected == true)
                        {
                            if (fieldName.Contains("WORSITE BENEFITS"))
                            {
                                myMergeField.Select();
                                //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WORSITE BENEFITS");
                                continue;
                            }
                        }
                    }
                }//ForEachClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMonthlyPremiumSectionToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataSet ContributionDS, DataTable PlanTable, string selectedColor)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;
                int planCount = 0;

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 6" || shape.Name == "Text Box 26" || shape.Name == "Text Box 14")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                }

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;
                    int monthly_premium_row_counter = 2;
                    bool header_created = false;
                    string Frequency_Of_Contribution = String.Empty;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                    int iTotalFields = 0;
                    #endregion

                    #region Rate
                    //for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    //{
                    //    if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                    //    {
                    //        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                    //        {
                    //            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                    //            {
                    //                Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
                    //                End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
                    //                Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
                    //                //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
                    //                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
                    //                {
                    //                    PremiumTable.Rows.Add();
                    //                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                    //                    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                    //                    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                    //                    {
                    //                        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                    //                    }
                    //                    else
                    //                    {
                    //                        PremiumTable.Rows[premium_row_counter][1] = 0;
                    //                    }
                    //                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                    //                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                    //                    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                    //                    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                    //                    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                    //                    premium_row_counter++;
                    //                }
                    //            }
                    //            else
                    //            {
                    //                PremiumTable.Rows.Add();
                    //                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                    //                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                    //                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                    //                {
                    //                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                    //                }
                    //                else
                    //                {
                    //                    PremiumTable.Rows[premium_row_counter][1] = 0;
                    //                }
                    //                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                    //                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                    //                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                    //                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                    //                PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                    //                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    //                {
                    //                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                    //                    {
                    //                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                    //                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                    //                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                    //                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                    //                        //Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                    //                        break;
                    //                    }
                    //                }
                    //                premium_row_counter++;
                    //            }
                    //        }
                    //    }
                    //}

                    #endregion
                    #region contribution
                    //new change
                    Boolean flag = false;

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim() || PlanTable.Rows[index]["ContributionId_2"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag == false)
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                PremiumTable.Rows[premium_row_counter][3] = "";
                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
                                PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                //break;
                                premium_row_counter++;
                            }
                        }
                    }
                    //end change
                    #endregion
                    #region AddTable

                    DataTable dt = new DataTable();
                    //change
                    if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                    {
                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                    }
                    //End Change
                    else
                    {
                        //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                    }

                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                    {
                        //Word.Table objTable;
                        //Word.Range TableRng = oWordDoc.Tables[PremiumTable_counter].Range;

                        //TableRng.SetRange(oWordDoc.Tables[PremiumTable_counter].Range.End + 1, oWordDoc.Tables[PremiumTable_counter].Range.End + 1);

                        //objTable = oWordDoc.Tables.Add(TableRng, 2, 2, ref missing, ref missing);

                        //objTable.Rows[1].Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorGray50;
                        //objTable.Rows[1].Range.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorWhite;
                        //objTable.Rows[1].Range.Font.Size = 10;
                        //objTable.Rows[1].Range.Font.Bold = 1;
                        ////objTable.Columns.Width = 172;
                        //objTable.PreferredWidth = oWordApp.InchesToPoints(7.01f);
                        //objTable.Rows.Height = 12;
                        //objTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                        //objTable.Range.Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                        //objTable.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
                        #region Table color
                        oWordDoc.Tables[PremiumTable_counter].Range.Font.Color = comFunObj.font_color(selectedColor);
                        oWordDoc.Tables[PremiumTable_counter].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[PremiumTable_counter].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[PremiumTable_counter].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                        oWordDoc.Tables[PremiumTable_counter].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                        #endregion

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {

                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("Monthly Premiums"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText("Monthly Premiums");
                                }

                                if (fieldName.Contains("UndereligibilityforMedicalPlan"))
                                {

                                    if (domesticPartner.ToString().ToLower() == "completed")
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanSpecific.Trim());
                                    }
                                    else
                                    {
                                        myMergeField.Delete();
                                    }
                                }
                            }
                        }

                    }

                    #endregion
                    #region FillTable

                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                    {
                        if (!header_created)
                        {
                            oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
                            oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = PlanTable.Rows[index]["ContributionName"].ToString();
                            header_created = true;
                        }

                        if (PremiumTable.Rows[i][1].ToString() == "8")
                        {
                            if (oWordDoc.Tables[PremiumTable_counter].Cell(2, 1).Range.Text.Replace("\r\a", "") == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                            {

                                //monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
                                monthly_premium_row_counter = 1;
                                monthly_premium_row_counter++;
                                oWordDoc.Tables[PremiumTable_counter].Columns.Add();
                                oWordDoc.Tables[PremiumTable_counter].Columns[3].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                                oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                                oWordDoc.Tables[PremiumTable_counter].Columns[3].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = PlanTable.Rows[index]["ContributionName_2"].ToString(); ;
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                oWordDoc.Tables[PremiumTable_counter].PreferredWidth = oWordApp.InchesToPoints(7.01f);

                            }
                            else
                            {
                                //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                monthly_premium_row_counter = 1;
                                monthly_premium_row_counter++;
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                                oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(3.9f);
                            }
                        }
                        else
                        {
                            if (oWordDoc.Tables[PremiumTable_counter].Cell((monthly_premium_row_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable.Rows[i][2].ToString())
                            {
                                //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                monthly_premium_row_counter++;
                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            }
                            else
                            {
                                oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                monthly_premium_row_counter++;
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            }
                        }
                    }

                    #endregion
                    #region merge field
                    int iTotalField = 0;
                    Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                    planCount = PlanTable.AsEnumerable().Where(x => x["PlanType"].ToString() == "Medical" || x["PlanType"].ToString() == "Dental" || x["PlanType"].ToString() == "Vision").ToList().Count;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalField++;
                        Word.Range rngFieldCode = myMergeField.Code;
                        String fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }
                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            String fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Contribution_freq"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(Frequency_Of_Contribution.Trim());
                            }
                            if (fieldName.Contains("ContributionTable2"))
                            {
                                if (planCount >= 2)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable3"))
                            {
                                if (planCount >= 3)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable4"))
                            {
                                if (planCount >= 4)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable5"))
                            {
                                if (planCount >= 5)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable6"))
                            {
                                if (planCount >= 6)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable7"))
                            {
                                if (planCount >= 7)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable8"))
                            {
                                if (planCount >= 8)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable9"))
                            {
                                if (planCount >= 9)
                                {
                                    myMergeField.Delete();
                                }
                            }
                            if (fieldName.Contains("ContributionTable10"))
                            {
                                if (planCount >= 10)
                                {
                                    myMergeField.Delete();
                                }
                            }
                        }
                    }
                    #endregion
                    #region FormatTable
                    //if (PremiumTable.Rows.Count > 0)
                    //{
                    //    foreach (Word.Border border in oWordDoc.Tables[PremiumTable_counter].Borders)
                    //    {
                    //        border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                    //        border.Color = Microsoft.Office.Interop.Word.WdColor.wdColorGray25;
                    //    }

                    //    oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                    //    oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                    //    oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                    //    oWordDoc.Tables[PremiumTable_counter].Range.Font.Size = 10;

                    //for (int k = 2; k < oWordDoc.Tables[PremiumTable_counter].Rows.Count + 1; k++)
                    //for (int k = PremiumTable_counter; k < oWordDoc.Tables[PremiumTable_counter].; k++)
                    //{

                    //oWordDoc.Tables[PremiumTable_counter].Columns[1].Cells[k].Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
                    if (PremiumTable_counter > 9 && PremiumTable_counter < 20)
                        oWordDoc.Tables[PremiumTable_counter].Columns[1].PreferredWidth = oWordApp.InchesToPoints(3.2f);

                    //oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                    //}
                    PremiumTable_counter++;
                    //}
                    #endregion
                }
                //oWordDoc.Tables[PremiumTable_counter].Delete();
                PremiumTable_counter = PremiumTable_counter - 1;
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        //public void WriteMonthlyPremiumSectionToTemplate10_Original(Word.Document oWordDoc, Word.Application oWordApp, DataSet ContributionDS, DataTable PlanTable, string selectedColor)
        //{
        //    try
        //    {
        //        Object missing = System.Reflection.Missing.Value;
        //        //string contribution_Text = "Unless otherwise requested, non-life and disability premiums will automatically be deducted on a pre-tax basis." + "\n" +
        //        //"*For domestic partners that do not qualify as dependents under Section 152 of the Internal Revenue Code, premium associated with domestic partner coverage will be paid by the employee with after-tax dollars and the fair market value of any employer contributions made on behalf of your domestic partner will be imputed as income to the employee.";

        //        foreach (Word.Shape shape in oWordDoc.Shapes)
        //        {
        //            if (shape.Name == "Text Box 6" || shape.Name == "Text Box 26" || shape.Name == "Text Box 14")
        //            {
        //                shape.Select();
        //                shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
        //                //shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
        //            }
        //        }

        //        for (int index = 0; index < PlanTable.Rows.Count; index++)
        //        {
        //            #region  BuildTable
        //            DataTable PremiumTable = new DataTable();
        //            int premium_row_counter = 0;
        //            int monthly_premium_row_counter = 2;
        //            bool header_created = false;
        //            int Start = 0;
        //            int End = 0;
        //            int Interval = 0;
        //            string Frequency_Of_Contribution = String.Empty;

        //            PremiumTable.Columns.Add("Plan", typeof(string));
        //            //PremiumTable.Columns.Add("rateTierID", typeof(string));
        //            PremiumTable.Columns.Add("rateTierID", typeof(Int16));
        //            PremiumTable.Columns.Add("rateTier_description", typeof(string));
        //            PremiumTable.Columns.Add("monthlycost", typeof(string));
        //            PremiumTable.Columns.Add("contributioncost", typeof(string));
        //            PremiumTable.Columns.Add("summaryname", typeof(string));
        //            PremiumTable.Columns.Add("contributionFrequency", typeof(string));
        //            PremiumTable.Columns.Add("contributionid", typeof(string));
        //            PremiumTable.Columns.Add("rateid", typeof(string));
        //            PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
        //            PremiumTable.Columns.Add("ageBandIndex", typeof(int));
        //            int iTotalFields = 0;
        //            #endregion

        //            #region Rate
        //            //for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        //            //{
        //            //    if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        //            //    {
        //            //        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
        //            //        {
        //            //            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //            //            {
        //            //                Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
        //            //                End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
        //            //                Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
        //            //                //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
        //            //                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
        //            //                {
        //            //                    PremiumTable.Rows.Add();
        //            //                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //            //                    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //            //                    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //            //                    {
        //            //                        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //            //                    }
        //            //                    else
        //            //                    {
        //            //                        PremiumTable.Rows[premium_row_counter][1] = 0;
        //            //                    }
        //            //                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //            //                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //            //                    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //            //                    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //            //                    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //            //                    premium_row_counter++;
        //            //                }
        //            //            }
        //            //            else
        //            //            {
        //            //                PremiumTable.Rows.Add();
        //            //                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //            //                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //            //                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //            //                {
        //            //                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //            //                }
        //            //                else
        //            //                {
        //            //                    PremiumTable.Rows[premium_row_counter][1] = 0;
        //            //                }
        //            //                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //            //                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //            //                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //            //                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //            //                PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //            //                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //            //                {
        //            //                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //            //                    {
        //            //                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //            //                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //            //                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //            //                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        //            //                        //Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //            //                        break;
        //            //                    }
        //            //                }
        //            //                premium_row_counter++;
        //            //            }
        //            //        }
        //            //    }
        //            //}

        //            #endregion
        //            #region contribution
        //            //new change
        //            Boolean flag = false;

        //            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //            {
        //                if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim() || PlanTable.Rows[index]["ContributionId_2"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
        //                {
        //                    // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
        //                    //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
        //                    //{
        //                    //    flag = false;

        //                    for (int i = 0; i < PremiumTable.Rows.Count; i++)
        //                    {
        //                        if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                        {
        //                            flag = true;
        //                            break;
        //                        }
        //                    }
        //                    if (flag == false)
        //                    {
        //                        PremiumTable.Rows.Add();
        //                        PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
        //                        PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
        //                        PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][3] = "";
        //                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                        //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
        //                        PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
        //                        Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                        //break;
        //                        premium_row_counter++;
        //                    }
        //                    //}
        //                }
        //            }
        //            //end change
        //            #endregion
        //            #region AddTable

        //            DataTable dt = new DataTable();
        //            //change
        //            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //            {
        //                PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }
        //            //End Change
        //            else
        //            {
        //                //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }

        //            if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
        //            {
        //                Word.Table objTable;
        //                Word.Range TableRng = oWordDoc.Tables[PremiumTable_counter].Range;

        //                TableRng.SetRange(oWordDoc.Tables[PremiumTable_counter].Range.End + 1, oWordDoc.Tables[PremiumTable_counter].Range.End + 1);

        //                objTable = oWordDoc.Tables.Add(TableRng, 2, 2, ref missing, ref missing);

        //                objTable.Rows[1].Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorGray50;
        //                objTable.Rows[1].Range.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorWhite;
        //                objTable.Rows[1].Range.Font.Size = 10;
        //                objTable.Rows[1].Range.Font.Bold = 1;
        //                //objTable.Columns.Width = 172;
        //                objTable.PreferredWidth = oWordApp.InchesToPoints(7.01f);
        //                objTable.Rows.Height = 12;
        //                objTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        //                objTable.Range.Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                objTable.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

        //                oWordDoc.Tables[PremiumTable_counter].Range.Font.Color = comFunObj.font_color(selectedColor);
        //                oWordDoc.Tables[PremiumTable_counter].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
        //                oWordDoc.Tables[PremiumTable_counter].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
        //                oWordDoc.Tables[PremiumTable_counter].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
        //                oWordDoc.Tables[PremiumTable_counter].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

        //                foreach (Word.Field myMergeField in oWordDoc.Fields)
        //                {
        //                    iTotalFields++;

        //                    Word.Range rngFieldCode = myMergeField.Code;

        //                    String fieldText = rngFieldCode.Text;

        //                    if (fieldText.StartsWith(" MERGEFIELD"))
        //                    {

        //                        Int32 endMerge = fieldText.IndexOf("\\");
        //                        if (endMerge == -1)
        //                        {
        //                            endMerge = fieldText.Length;
        //                        }

        //                        Int32 fieldNameLength = fieldText.Length - endMerge;

        //                        String fieldName = fieldText.Substring(11, endMerge - 11);

        //                        fieldName = fieldName.Trim();
        //                        if (fieldName.Contains("Monthly Premiums"))
        //                        {
        //                            myMergeField.Select();
        //                            oWordApp.Selection.TypeText("Monthly Premiums");
        //                        }

        //                        if (fieldName.Contains("UndereligibilityforMedicalPlan"))
        //                        {

        //                            if (domesticPartner.ToString().ToLower() == "completed")
        //                            {
        //                                myMergeField.Select();
        //                                oWordApp.Selection.TypeText(PlanSpecific.Trim());
        //                            }
        //                            else
        //                            {
        //                                myMergeField.Delete();
        //                            }
        //                        }
        //                    }
        //                }

        //            }

        //            #endregion
        //            Int16 recordCnt = 0;
        //            #region FillTable

        //            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //            {
        //                if (!header_created)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = PlanTable.Rows[index]["ContributionName"].ToString();
        //                    header_created = true;
        //                }

        //                if (PremiumTable.Rows[i][1].ToString() == "8")
        //                {
        //                    if (oWordDoc.Tables[PremiumTable_counter].Cell(2, 1).Range.Text.Replace("\r\a", "") == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
        //                    {

        //                        //monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
        //                        monthly_premium_row_counter = 1;
        //                        monthly_premium_row_counter++;
        //                        oWordDoc.Tables[PremiumTable_counter].Columns.Add();
        //                        oWordDoc.Tables[PremiumTable_counter].Columns[3].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = PlanTable.Rows[index]["ContributionName_2"].ToString(); ;
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                        oWordDoc.Tables[PremiumTable_counter].PreferredWidth = oWordApp.InchesToPoints(7.01f);
        //                    }
        //                    else
        //                    {
        //                        //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
        //                        monthly_premium_row_counter = 1;
        //                        monthly_premium_row_counter++;
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                    }
        //                }
        //                else
        //                {
        //                    if (oWordDoc.Tables[PremiumTable_counter].Cell((monthly_premium_row_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable.Rows[i][2].ToString())
        //                    {
        //                        //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
        //                        monthly_premium_row_counter++;
        //                        //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
        //                        monthly_premium_row_counter++;
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                    }
        //                }
        //                //recordCnt++;
        //                //if (recordCnt != PremiumTable.Rows.Count)
        //                //{

        //                //}
        //                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                //monthly_premium_row_counter++;
        //            }

        //            #endregion
        //            #region merge field
        //            int iTotalField = 0;
        //            Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
        //            foreach (Word.Field myMergeField in oWordDoc.Fields)
        //            {
        //                iTotalField++;
        //                Word.Range rngFieldCode = myMergeField.Code;
        //                String fieldText = rngFieldCode.Text;
        //                if (fieldText.StartsWith(" MERGEFIELD"))
        //                {
        //                    Int32 endMerge = fieldText.IndexOf("\\");
        //                    if (endMerge == -1)
        //                    {
        //                        endMerge = fieldText.Length;
        //                    }
        //                    Int32 fieldNameLength = fieldText.Length - endMerge;
        //                    String fieldName = fieldText.Substring(11, endMerge - 11);
        //                    fieldName = fieldName.Trim();
        //                    if (fieldName.Contains("Contribution_freq"))
        //                    {
        //                        myMergeField.Select();
        //                        oWordApp.Selection.Range.Font.Color = wdColor_font;
        //                        oWordApp.Selection.TypeText(Frequency_Of_Contribution.Trim());
        //                    }
        //                    //if (fieldName.Contains("Second"))
        //                    //{
        //                    //    if (ContributionDS.Tables["ContributionTable"].Rows.Count >= 2)
        //                    //    {
        //                    //        oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //                    //    }
        //                    //}
        //                    //if (fieldName.Contains("Third"))
        //                    //{
        //                    //    if (ContributionDS.Tables["ContributionTable"].Rows.Count >= 3)
        //                    //    {
        //                    //        oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //                    //    }
        //                    //}
        //                    //if (fieldName.Contains("Premium_Text"))
        //                    //{
        //                    //    myMergeField.Select();
        //                    //    oWordApp.Selection.TypeText(contribution_Text);
        //                    //}
        //                }
        //            }
        //            #endregion
        //            #region FormatTable
        //            if (PremiumTable.Rows.Count > 0)
        //            {
        //                foreach (Word.Border border in oWordDoc.Tables[PremiumTable_counter].Borders)
        //                {
        //                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
        //                    border.Color = Microsoft.Office.Interop.Word.WdColor.wdColorGray25;
        //                }

        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                oWordDoc.Tables[PremiumTable_counter].Range.Font.Size = 10;

        //                for (int k = 2; k < oWordDoc.Tables[PremiumTable_counter].Rows.Count + 1; k++)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Columns[1].Cells[k].Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
        //                    oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                }
        //                PremiumTable_counter++;
        //            }
        //            #endregion

        //            //oWordDoc.TextLineEnding=WdLineEndingType.wdCRLF;
        //        }

        //        //if (ContributionDS.Tables["ContributionTable"].Rows.Count < 9)
        //        //{
        //        //    Word.Range r = oWordDoc.Range(); 
        //        //    string text = oWordDoc.Content.Text;
        //        //    int start = text.IndexOf("2");
        //        //    int end = text.IndexOf("9");
        //        //    object missing1 = System.Type.Missing;
        //        //    r.SetRange(start, end);
        //        //    r.Select();
        //        //    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //    //oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
        //        //}
        //        oWordDoc.Tables[PremiumTable_counter].Delete();
        //        PremiumTable_counter = PremiumTable_counter - 1;
        //    }

        //    catch (Exception ex)
        //    {
        //        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        //public void WriteMonthlyPremiumSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable)
        //{
        //    try
        //    {
        //        Object missing = System.Reflection.Missing.Value;

        //        for (int index = 0; index < PlanTable.Rows.Count; index++)
        //        {
        //            #region  BuildTable
        //            DataTable PremiumTable = new DataTable();
        //            int premium_row_counter = 0;
        //            int monthly_premium_row_counter = 2;
        //            bool header_created = false;
        //            int Start = 0;
        //            int End = 0;
        //            int Interval = 0;

        //            PremiumTable.Columns.Add("Plan", typeof(string));
        //            //PremiumTable.Columns.Add("rateTierID", typeof(string));
        //            PremiumTable.Columns.Add("rateTierID", typeof(Int16));
        //            PremiumTable.Columns.Add("rateTier_description", typeof(string));
        //            PremiumTable.Columns.Add("monthlycost", typeof(string));
        //            PremiumTable.Columns.Add("contributioncost", typeof(string));
        //            PremiumTable.Columns.Add("summaryname", typeof(string));
        //            PremiumTable.Columns.Add("contributionFrequency", typeof(string));
        //            PremiumTable.Columns.Add("contributionid", typeof(string));
        //            PremiumTable.Columns.Add("rateid", typeof(string));
        //            PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
        //            PremiumTable.Columns.Add("ageBandIndex", typeof(int));
        //            int iTotalFields = 0;

        //            for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        //            {
        //                if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        //                {
        //                    if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
        //                    {
        //                        if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //                        {
        //                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
        //                            End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
        //                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
        //                            //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
        //                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
        //                            {
        //                                PremiumTable.Rows.Add();
        //                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //                                }
        //                                else
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][1] = 0;
        //                                }
        //                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                                PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //                                premium_row_counter++;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            PremiumTable.Rows.Add();
        //                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                            //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //                            if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //                            {
        //                                PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //                            }
        //                            else
        //                            {
        //                                PremiumTable.Rows[premium_row_counter][1] = 0;
        //                            }
        //                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                            PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                            PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                            PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //                            {
        //                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        //                                    break;
        //                                }
        //                            }
        //                            premium_row_counter++;
        //                        }
        //                    }
        //                }
        //            }

        //            #endregion

        //            //new change
        //            Boolean flag = false;

        //            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //            {
        //                if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
        //                {
        //                    // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
        //                    //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
        //                    //{
        //                    //    flag = false;

        //                    for (int i = 0; i < PremiumTable.Rows.Count; i++)
        //                    {
        //                        if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                        {
        //                            flag = true;
        //                            break;
        //                        }
        //                    }
        //                    if (flag == false)
        //                    {
        //                        PremiumTable.Rows.Add();
        //                        PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
        //                        PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
        //                        PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][3] = "";
        //                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();

        //                        PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString(); ;
        //                        //break;
        //                        premium_row_counter++;
        //                    }
        //                    //}
        //                }
        //            }
        //            //end change

        //            #region AddTable

        //            DataTable dt = new DataTable();
        //            //change
        //            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //            {
        //                PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }
        //            //End Change
        //            else
        //            {
        //                PremiumTable.DefaultView.Sort = "[rateTierID] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }

        //            if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
        //            {
        //                Word.Table objTable;
        //                Word.Range TableRng = oWordDoc.Tables[PremiumTable_counter].Range;

        //                TableRng.SetRange(oWordDoc.Tables[PremiumTable_counter].Range.End + 1, oWordDoc.Tables[PremiumTable_counter].Range.End + 1);

        //                objTable = oWordDoc.Tables.Add(TableRng, 2, 3, ref missing, ref missing);

        //                objTable.Rows[1].Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorGray50;
        //                objTable.Rows[1].Range.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorWhite;
        //                objTable.Rows[1].Range.Font.Size = 9;
        //                objTable.Rows[1].Range.Font.Bold = 1;
        //                objTable.Columns.Width = 172;
        //                objTable.Rows.Height = 12;
        //                objTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        //                objTable.Range.Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                objTable.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

        //                foreach (Word.Field myMergeField in oWordDoc.Fields)
        //                {
        //                    iTotalFields++;

        //                    Word.Range rngFieldCode = myMergeField.Code;

        //                    String fieldText = rngFieldCode.Text;

        //                    if (fieldText.StartsWith(" MERGEFIELD"))
        //                    {

        //                        Int32 endMerge = fieldText.IndexOf("\\");
        //                        if (endMerge == -1)
        //                        {
        //                            endMerge = fieldText.Length;
        //                        }

        //                        Int32 fieldNameLength = fieldText.Length - endMerge;

        //                        String fieldName = fieldText.Substring(11, endMerge - 11);

        //                        fieldName = fieldName.Trim();
        //                        if (fieldName.Contains("Monthly Premiums"))
        //                        {
        //                            myMergeField.Select();
        //                            oWordApp.Selection.TypeText("Monthly Premiums");
        //                        }

        //                        if (fieldName.Contains("UndereligibilityforMedicalPlan"))
        //                        {

        //                            if (domesticPartner.ToString().ToLower() == "completed")
        //                            {
        //                                myMergeField.Select();
        //                                oWordApp.Selection.TypeText(PlanSpecific.Trim());
        //                            }
        //                            else
        //                            {
        //                                myMergeField.Delete();
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //            #endregion
        //            Int16 recordCnt = 0;
        //            #region FillTable
        //            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //            {
        //                if (!header_created)
        //                {
        //                    //oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["PolicyNumber"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString() + PremiumTable.Rows[i][5].ToString();
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = "Total Plan Cost"; //"Total Monthly Cost";

        //                    if (PremiumTable.Rows[i][6].ToString() == "Bi_Weekly_26_or_yr")
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Your Bi-Weekly (26 Per Year) Cost";
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Employee Contribution";
        //                    }

        //                    header_created = true;
        //                }

        //                if (PremiumTable.Rows[i][1].ToString() == "8")
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                }
        //                else
        //                {
        //                    //Change

        //                    if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker")
        //                    {
        //                        if (Start < End - 1)
        //                        {
        //                            if (monthly_premium_row_counter == 2)
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Under " + Start.ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                            }
        //                            else
        //                            {
        //                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                                Start = Start + Interval + 1;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (Start == End)
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Over " + End.ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                                Start = Start + Interval + 1;
        //                            }
        //                            else
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Composite";
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                            }
        //                        }
        //                    }
        //                    //End Change
        //                    else
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                    }
        //                }
        //                recordCnt++;
        //                if (recordCnt != PremiumTable.Rows.Count)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
        //                }
        //                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                monthly_premium_row_counter++;
        //            }

        //            #endregion

        //            #region FormatTable
        //            if (PremiumTable.Rows.Count > 0)
        //            {
        //                foreach (Word.Border border in oWordDoc.Tables[PremiumTable_counter].Borders)
        //                {
        //                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
        //                    border.Color = Microsoft.Office.Interop.Word.WdColor.wdColorGray25;
        //                }

        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                oWordDoc.Tables[PremiumTable_counter].Range.Font.Size = 9;

        //                for (int k = 2; k < oWordDoc.Tables[PremiumTable_counter].Rows.Count + 1; k++)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Columns[1].Cells[k].Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
        //                    oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;
        //                }

        //                PremiumTable_counter++;
        //            }
        //            #endregion
        //        }

        //        oWordDoc.Tables[PremiumTable_counter].Delete();
        //        PremiumTable_counter = PremiumTable_counter - 1;
        //    }

        //    catch (Exception ex)
        //    {
        //        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        //public void WriteMonthlyPremiumSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable)
        //{
        //    try
        //    {
        //        Object missing = System.Reflection.Missing.Value;

        //        for (int index = 0; index < PlanTable.Rows.Count; index++)
        //        {
        //            #region  BuildTable
        //            DataTable PremiumTable = new DataTable();
        //            int premium_row_counter = 0;
        //            int monthly_premium_row_counter = 2;
        //            bool header_created = false;
        //            int Start = 0;
        //            int End = 0;
        //            int Interval = 0;

        //            PremiumTable.Columns.Add("Plan", typeof(string));
        //            //PremiumTable.Columns.Add("rateTierID", typeof(string));
        //            PremiumTable.Columns.Add("rateTierID", typeof(Int16));
        //            PremiumTable.Columns.Add("rateTier_description", typeof(string));
        //            PremiumTable.Columns.Add("monthlycost", typeof(string));
        //            PremiumTable.Columns.Add("contributioncost", typeof(string));
        //            PremiumTable.Columns.Add("summaryname", typeof(string));
        //            PremiumTable.Columns.Add("contributionFrequency", typeof(string));
        //            PremiumTable.Columns.Add("contributionid", typeof(string));
        //            PremiumTable.Columns.Add("rateid", typeof(string));
        //            PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
        //            PremiumTable.Columns.Add("ageBandIndex", typeof(int));
        //            int iTotalFields = 0;

        //            for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        //            {
        //                if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        //                {
        //                    if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
        //                    {
        //                        if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //                        {
        //                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
        //                            End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
        //                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
        //                            //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
        //                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
        //                            {
        //                                PremiumTable.Rows.Add();
        //                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //                                }
        //                                else
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][1] = 0;
        //                                }
        //                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                                PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //                                premium_row_counter++;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            PremiumTable.Rows.Add();
        //                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                            //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
        //                            if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //                            {
        //                                PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //                            }
        //                            else
        //                            {
        //                                PremiumTable.Rows[premium_row_counter][1] = 0;
        //                            }
        //                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                            PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                            PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                            PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

        //                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //                            {
        //                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                                {
        //                                    PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                                    PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        //                                    break;
        //                                }
        //                            }
        //                            premium_row_counter++;
        //                        }
        //                    }
        //                }
        //            }

        //            #endregion

        //            //new change
        //            Boolean flag = false;

        //            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //            {
        //                if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
        //                {
        //                    // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
        //                    //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
        //                    //{
        //                    //    flag = false;

        //                    for (int i = 0; i < PremiumTable.Rows.Count; i++)
        //                    {
        //                        if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                        {
        //                            flag = true;
        //                            break;
        //                        }
        //                    }
        //                    if (flag == false)
        //                    {
        //                        PremiumTable.Rows.Add();
        //                        PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
        //                        PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
        //                        PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][3] = "";
        //                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();

        //                        PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString(); ;
        //                        //break;
        //                        premium_row_counter++;
        //                    }
        //                    //}
        //                }
        //            }
        //            //end change

        //            #region AddTable

        //            DataTable dt = new DataTable();
        //            //change
        //            if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
        //            {
        //                PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }
        //            //End Change
        //            else
        //            {
        //                PremiumTable.DefaultView.Sort = "[rateTierID] asc";
        //                dt = PremiumTable.DefaultView.ToTable(true);
        //                PremiumTable = dt;
        //            }

        //            if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
        //            {
        //                Word.Table objTable;
        //                Word.Range TableRng = oWordDoc.Tables[PremiumTable_counter].Range;

        //                TableRng.SetRange(oWordDoc.Tables[PremiumTable_counter].Range.End + 1, oWordDoc.Tables[PremiumTable_counter].Range.End + 1);

        //                objTable = oWordDoc.Tables.Add(TableRng, 2, 3, ref missing, ref missing);

        //                objTable.Rows[1].Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorGray50;
        //                objTable.Rows[1].Range.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorWhite;
        //                objTable.Rows[1].Range.Font.Size = 9;
        //                objTable.Rows[1].Range.Font.Bold = 1;
        //                objTable.Columns.Width = 172;
        //                objTable.Rows.Height = 12;
        //                objTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        //                objTable.Range.Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                objTable.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

        //                foreach (Word.Field myMergeField in oWordDoc.Fields)
        //                {
        //                    iTotalFields++;

        //                    Word.Range rngFieldCode = myMergeField.Code;

        //                    String fieldText = rngFieldCode.Text;

        //                    if (fieldText.StartsWith(" MERGEFIELD"))
        //                    {

        //                        Int32 endMerge = fieldText.IndexOf("\\");
        //                        if (endMerge == -1)
        //                        {
        //                            endMerge = fieldText.Length;
        //                        }

        //                        Int32 fieldNameLength = fieldText.Length - endMerge;

        //                        String fieldName = fieldText.Substring(11, endMerge - 11);

        //                        fieldName = fieldName.Trim();
        //                        if (fieldName.Contains("Monthly Premiums"))
        //                        {
        //                            myMergeField.Select();
        //                            oWordApp.Selection.TypeText("Monthly Premiums");
        //                        }

        //                        if (fieldName.Contains("UndereligibilityforMedicalPlan"))
        //                        {

        //                            if (domesticPartner.ToString().ToLower() == "completed")
        //                            {
        //                                myMergeField.Select();
        //                                oWordApp.Selection.TypeText(PlanSpecific.Trim());
        //                            }
        //                            else
        //                            {
        //                                myMergeField.Delete();
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //            #endregion
        //            Int16 recordCnt = 0;
        //            #region FillTable
        //            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //            {
        //                if (!header_created)
        //                {
        //                    //oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["PolicyNumber"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString() + PremiumTable.Rows[i][5].ToString();
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = "Total Plan Cost"; //"Total Monthly Cost";

        //                    if (PremiumTable.Rows[i][6].ToString() == "Bi_Weekly_26_or_yr")
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Your Bi-Weekly (26 Per Year) Cost";
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Employee Contribution";
        //                    }

        //                    header_created = true;
        //                }

        //                if (PremiumTable.Rows[i][1].ToString() == "8")
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
        //                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                }
        //                else
        //                {
        //                    //Change

        //                    if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker")
        //                    {
        //                        if (Start < End - 1)
        //                        {
        //                            if (monthly_premium_row_counter == 2)
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Under " + Start.ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                            }
        //                            else
        //                            {
        //                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                                Start = Start + Interval + 1;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (Start == End)
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Over " + End.ToString();
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                                Start = Start + Interval + 1;
        //                            }
        //                            else
        //                            {
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Composite";
        //                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                            }
        //                        }
        //                    }
        //                    //End Change
        //                    else
        //                    {
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
        //                    }
        //                }
        //                recordCnt++;
        //                if (recordCnt != PremiumTable.Rows.Count)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
        //                }
        //                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
        //                monthly_premium_row_counter++;
        //            }

        //            #endregion

        //            #region FormatTable
        //            if (PremiumTable.Rows.Count > 0)
        //            {
        //                foreach (Word.Border border in oWordDoc.Tables[PremiumTable_counter].Borders)
        //                {
        //                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
        //                    border.Color = Microsoft.Office.Interop.Word.WdColor.wdColorGray25;
        //                }

        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
        //                oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

        //                oWordDoc.Tables[PremiumTable_counter].Range.Font.Size = 9;

        //                for (int k = 2; k < oWordDoc.Tables[PremiumTable_counter].Rows.Count + 1; k++)
        //                {
        //                    oWordDoc.Tables[PremiumTable_counter].Columns[1].Cells[k].Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
        //                    oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;
        //                }

        //                PremiumTable_counter++;
        //            }
        //            #endregion
        //        }

        //        oWordDoc.Tables[PremiumTable_counter].Delete();
        //        PremiumTable_counter = PremiumTable_counter - 1;
        //    }

        //    catch (Exception ex)
        //    {
        //        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void FillColorContactinformationToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, string selectedColor)
        {
            try
            {
                int count = PremiumTable_counter + 1;

                oWordDoc.Tables[count].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[count].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[count].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[count].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToTemplate10(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            string domesticPartner = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("EmployeeStatus"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unitofmeasure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency_Eligibility"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("definitionofdomesticpartner"))
                    {
                        myMergeField.Select();
                        if (domesticPartner != string.Empty)
                            oWordApp.Selection.TypeText(domesticPartner);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("medicalplanwaitingperiod"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period.ToLower());
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }
    }
}