﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Core;
namespace BenefitPointSummaryPortal.BAL.PHMStrategicPlan
{
    public class WriteTemplatePHMStrategicPlan
    {
        BPBusiness bp = new BPBusiness();
        public void WriteCommonValueOnTemplate(Word.Document oWordDoc, Word.Application oWordApp, Word.Document oWordDocSource, Word.Application oWordAppSorce, string ClientName, string ContactName, string Role)
        {
            try
            {
                #region MergeField
                string CurrentDate = string.Empty;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;
                    string ClientNameUpper = string.Empty;
                    ClientNameUpper = ClientName.ToUpper();

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        myMergeField.Select();

                        if (fieldName.Contains("ClientNameUpper"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ClientNameUpper))
                                oWordApp.Selection.TypeText(ClientNameUpper);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ClientName))
                                oWordApp.Selection.TypeText(ClientName);
                            else
                                myMergeField.Delete();
                            continue;
                        }

                        if (fieldName.Contains("AccountContactName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ContactName))
                                oWordApp.Selection.TypeText(ContactName);
                            else
                                myMergeField.Delete();
                            continue;
                        }

                        if (fieldName.Contains("AccountContactRole"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Role))
                                oWordApp.Selection.TypeText(Role);
                            else
                                myMergeField.Delete();
                            continue;
                        }

                        if (fieldName.Contains("CurrentDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(DateTime.Now.ToString("MMMM dd, yyyy")))
                                oWordApp.Selection.TypeText(DateTime.Now.ToString("MMMM dd, yyyy"));
                            else
                                myMergeField.Delete();
                            continue;
                        }



                    }
                }
                #endregion
                
                Write_DateInto_Footer(oWordDoc, oWordApp);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void Write_DateInto_Footer(Word.Document oWordDoc, Word.Application oWordApp)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
           
                    foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                    {
                        foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                        {
                            Word.Fields fields = footer.Range.Fields;

                            foreach (Word.Field field in fields)
                            {
                                Word.Range rngFieldCode = field.Code;
                                string fieldText = rngFieldCode.Text;
                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("CurrentYear"))
                                    {
                                        field.Select();
                                        oWordApp.Selection.TypeText(DateTime.Today.ToString("yyyy"));
                                        continue;
                                    }
                                }
                            }

                           
                        }
                
            }


        }
    }
}