﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;


namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_WapperTabs : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;

        Dictionary<string, List<int>> DictContactsPlanTypes = new Dictionary<string, List<int>>();
        private void BuiltDictContactsPlanTypes()
        {
            DictContactsPlanTypes.Clear();

            comFunObj.LoadPlanTypeIds();
            DictContactsPlanTypes.Add("Medical Insurance", new List<int> { 100, 110, 120, 130, 140, 150, 160, 170, 410, 233 });
            DictContactsPlanTypes.Add("Dental Insurance", new List<int> { 180, 190, 200, 210 });
            DictContactsPlanTypes.Add("Vision Benefits", new List<int> { 230 });

            comFunObj.LoadPlanTypeIds_Pilot();
            DictContactsPlanTypes.Add("Life and AD&D Insurance", new List<int> { 240 });
            DictContactsPlanTypes.Add("Group Term Life Insurance", new List<int> { 250 });
            DictContactsPlanTypes.Add("Accidental Death & Dismemberment Insurance", new List<int> { 270 });

            DictContactsPlanTypes.Add("Voluntary Life Insurance", new List<int> { 260 });
            DictContactsPlanTypes.Add("Voluntary AD&D Insurance", new List<int> { 280 });

            DictContactsPlanTypes.Add("Short Term Disability Insurance", new List<int> { 290 });
            DictContactsPlanTypes.Add("Long Term Disability Insurance", new List<int> { 300 });

            DictContactsPlanTypes.Add("Health Savings Account", new List<int> { 179 });
            DictContactsPlanTypes.Add("Health Reimbursement Account", new List<int> { 178 });

            DictContactsPlanTypes.Add("Flexible Spending Accounts", CommonFunctionsBS.FSAPlanTypeList);
            DictContactsPlanTypes.Add("Employee Assistance Program", CommonFunctionsBS.EAPPlanTypeList);

            DictContactsPlanTypes.Add("Stop Loss Insurance", new List<int> { 235 });

            DictContactsPlanTypes.Add("Patient Advocacy Program", new List<int> { ConstantValue.AdditionalProducts_Patient_Advocacy });
            DictContactsPlanTypes.Add("Telemedicine", new List<int> { ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine });
            DictContactsPlanTypes.Add("Wellness Plan", new List<int> { ConstantValue.AdditionalProducts_Wellness });
            DictContactsPlanTypes.Add("Accident Insurance", new List<int> { ConstantValue.AdditionalProducts_Accident });
            DictContactsPlanTypes.Add("Critical Illness Insurance", new List<int> { ConstantValue.AdditionalProducts_Voluntary_Critical_Illness });

            DictContactsPlanTypes.Add("401(k) Insurance", new List<int> { 340 });
            DictContactsPlanTypes.Add("Disability Insurance", new List<int> { 294, 293, 292 });
            DictContactsPlanTypes.Add("Business Travel Accident (BTA)", new List<int> { 320 });

            DictContactsPlanTypes.Add("Prescription Drug (Carve-Out)", new List<int> { 173 });

        }
        private DataTable AddColumnToPlanTable(DataTable PlanTable, string SessionId)
        {
            BuiltDictContactsPlanTypes();

            if (!PlanTable.Columns.Contains("contactPlanType"))
            {
                PlanTable.Columns.Add("contactPlanType", typeof(string));
            }

            foreach (DataRow row in PlanTable.Rows)
            {
                foreach (string plantype in DictContactsPlanTypes.Keys)
                {
                    if (DictContactsPlanTypes[plantype].Contains(Convert.ToInt32(row["ProductTypeId"])))
                    {
                        if (plantype == "Life and AD&D Insurance" && IsProductVoluntary(Convert.ToInt32(row["ProductId"]), SessionId))
                        {
                            row["contactPlanType"] = "Voluntary Life & AD&D Insurance";
                        }
                        else
                        {
                            row["contactPlanType"] = plantype;
                        }

                        break;
                    }
                }
                if (!PlanTable.Columns.Contains("CarrierPlanType"))
                {
                    PlanTable.Columns.Add("CarrierPlanType", typeof(string));
                }
                foreach (DataRow rw in PlanTable.Rows)
                {
                    rw["CarrierPlanType"] = rw["Carrier"] + " " + rw["Name"];
                }
            }
            return PlanTable;
        }
        private bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        public void Add_Replacee(Word.Document oWordDoc, Word.Application oWordApp, string mergeField, string fieldName)
        {
            if (String.IsNullOrEmpty(fieldName))
                fieldName = "";


            Word.Range range = oWordDoc.Range();
            Word.Find find = range.Find;
            find.Text = mergeField;

            find.ClearFormatting();
            Object missing = System.Reflection.Missing.Value;
            range.Find.Execute(
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing);
            while (find.Found)
            {
                find.Replacement.ClearFormatting();
                //     find.Replacement.Highlight = 0;
                find.Replacement.Text = fieldName;
                object replaceAll = Word.WdReplace.wdReplaceAll;
                find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref replaceAll, ref missing, ref missing, ref missing, ref missing);
            }
        }
        #region Brc Section
        public void Write_BRCToWapperTabs(Word.Document oWordDoc, Word.Application oWordApp, List<BRCData> BRCList)
        {
            StringBuilder extractText = new StringBuilder(oWordDoc.Content.Text);

            System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"\<<(.*?)\>>",
           System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.MatchCollection matches = rx.Matches(extractText.ToString());
            int BRCindex = 0;

            foreach (System.Text.RegularExpressions.Match match in matches)
            {
                if (match.ToString() == "<<Applicable BRC Days Hours>>")
                    Add_Replacee(oWordDoc, oWordApp, match.ToString(), BRCList[BRCindex].BRCDayHours);
                if (match.ToString() == "<<Applicable BRC Phone Number>>")
                    Add_Replacee(oWordDoc, oWordApp, match.ToString(), BRCList[BRCindex].BRCPhone);
                if (match.ToString() == "<<Applicable BRC E-mail Address>>")
                    Add_Replacee(oWordDoc, oWordApp, match.ToString(), BRCList[BRCindex].BRCEmail);

            }

        }
        #endregion
        public void Write_CommonFieldToWapperTabs(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountTeamMemberDS, DataTable EmployeeTypeTable,DataTable EligibilityDS, DropDownList ddlHRContact, List<Contact> ContactList, DataTable EmpTable, DataSet AccountDS, ArrayList arrAcctContact)
        {
            try
            {
                StringBuilder extractText = new StringBuilder(oWordDoc.Content.Text);

                System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"\<<(.*?)\>>",
               System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                System.Text.RegularExpressions.MatchCollection matches = rx.Matches(extractText.ToString());
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();

                int index = -1;

                string CompanyStatePincode = string.Empty;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (EmpTable.Rows.Count > 0)
                {
                    Emp = EmpTable;
                }

                #region Account Contact Name
                string AccountContact_Firstname = string.Empty;
                string AccountContact_Lastname = string.Empty;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].First_Name != null)
                                    {
                                        AccountContact_Firstname = ContactList[i].First_Name;


                                    }
                                    else
                                    {
                                        AccountContact_Firstname = "";
                                    }
                                    if (ContactList[i].Last_Name != null)
                                    {


                                        AccountContact_Lastname = ContactList[i].Last_Name;
                                    }
                                    else
                                    {
                                        AccountContact_Lastname = "";
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion


                

                string EmployeeStatus = string.Empty;
                string Working = string.Empty;
                string Frequency = string.Empty;
                string UOM = string.Empty;
                string Defination_UnmarriedChildAge = string.Empty;
                if (EligibilityDS.Rows.Count > 0 && EmployeeTypeTable.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                {

                    IEnumerable<DataRow> query = from product in EmployeeTypeTable.AsEnumerable()
                                                 where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                 select product;

                    foreach (DataRow Def_Eligible_Emp in query)
                    {
                        EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                        Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                        Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                        UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                    }
                }
                foreach (System.Text.RegularExpressions.Match match in matches)
                {
                    if (EligibilityDS.Rows.Count > 0)
                    {
                        if (match.ToString() == "<<First Medical Plan Selected/Eligibility/Definition of Dependent/Unmarried child to age>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                        
                        if (match.ToString() == "<<eligibility rule – waiting period>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), EligibilityDS.Rows[0]["item"].ToString().Trim());
                    }
                    else
                    {
                        if (match.ToString() == "<<First Medical Plan Selected/Eligibility/Definition of Dependent/Unmarried child to age>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString()," ");
                       
                        if (match.ToString() == "<<eligibility rule – waiting period>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), " ");
                    }
                    if (EmployeeTypeTable.Rows.Count > 0)
                    {
                        if (match.ToString() == "<<Account Summary/Employee types/Employee Status>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), EmployeeStatus);
                        if (match.ToString() == "<<working>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(),Working);

                        if (match.ToString() == "<<unit of measure>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), UOM);

                        if (match.ToString() == "<<frequency>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), Frequency);
                    }
                    else
                    {
                        if (match.ToString() == "<<Account Summary/Employee types/Employee Status>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), " ");
                        if (match.ToString() == "<<working>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), " ");

                        if (match.ToString() == "<<unit of measure>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), " ");

                        if (match.ToString() == "<<frequency>>")
                            Add_Replacee(oWordDoc, oWordApp, match.ToString(), " ");
                    }
                    if (match.ToString() == "<<Account Contact First Name>>")
                        Add_Replacee(oWordDoc, oWordApp, match.ToString(), AccountContact_Firstname);
                    if (match.ToString() == "<<Account Contact Last Name>>")
                        Add_Replacee(oWordDoc, oWordApp, match.ToString(), AccountContact_Lastname);
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #region Contact Information
        public void Write_ContactsToWapperTabs(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlClient, string SessionId)
        {
            StringBuilder extractText = new StringBuilder(oWordDoc.Content.Text);

            System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"\<<(.*?)\>>",
           System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.MatchCollection matches = rx.Matches(extractText.ToString());
            int rowCount = 2;
            string FirstMedRenewal = string.Empty;
            string FirstMedEffective = string.Empty;
            StringBuilder uniquePlans = new StringBuilder();
            string plantype = "";
            Microsoft.Office.Interop.Word.Table table = oWordDoc.Tables[1];

            Dictionary<string, string> DistinctPlanTypes = new Dictionary<string, string>();
            DistinctPlanTypes.Clear();
            DataTable DistinctPlanTable = AddColumnToPlanTable(PlanTable, SessionId);
            #region Removing dulicate rows from table
            for (int rowindex = 0; rowindex < DistinctPlanTable.Rows.Count; rowindex++)
            {
                plantype = (DistinctPlanTable.Rows[rowindex]["CarrierPlanType"].ToString()).Replace(" ", string.Empty); ;
                if ((!DistinctPlanTypes.ContainsKey(plantype)) && plantype != "")
                {
                    DistinctPlanTypes.Add(plantype, plantype);
                }
                else
                {
                    DistinctPlanTable.Rows[rowindex].Delete();
                    rowindex--;
                }
            }
            #endregion

            #region writing Contacts Table
            foreach (DataRow row in DistinctPlanTable.Rows)
            {
                if (row["contactPlanType"].ToString() == "Medical Insurance" && FirstMedEffective == string.Empty && FirstMedRenewal == string.Empty)
                {
                    FirstMedRenewal = row["Renewal"].ToString();
                    FirstMedEffective = row["Effective"].ToString();
                }

                if (rowCount > 2)
                {
                    table.Rows.Add(Type.Missing);
                }
            //    table.Range.HighlightColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdNoHighlight;
                table.Cell(rowCount, 1).Range.Text = row["Name"].ToString();
               // table.Cell(rowCount, 1).Range.HighlightColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdNoHighlight;
                table.Cell(rowCount, 2).Range.Text = row["Carrier"].ToString();
                //table.Cell(rowCount, 2).Range.HighlightColorIndex = Microsoft.Office.Interop.Word.WdColorIndex.wdNoHighlight;
                table.Cell(rowCount, 3).Range.Text = "(###) ###-####";
                table.Cell(rowCount, 4).Range.Text = "www.website.com";

                rowCount++;
            }
            #endregion
            foreach (System.Text.RegularExpressions.Match match in matches)
            {
                if (match.ToString() == "<<First Medical Plan Effective Year>>")
                {
                    if (FirstMedEffective.Trim() != "" || FirstMedEffective != null)
                    {

                        DateTime renewdate = Convert.ToDateTime(FirstMedEffective);
                        Add_Replacee(oWordDoc, oWordApp, match.ToString(), renewdate.Year.ToString());
                    }
                }
                if (match.ToString() == "<<First Medical Plan Effective Date>>")
                {

                    if (FirstMedEffective.Trim() != "" || FirstMedEffective != null)
                    {

                        DateTime renewdate = Convert.ToDateTime(FirstMedEffective);
                        Add_Replacee(oWordDoc, oWordApp, match.ToString(), (renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString()).Trim());
                    }
                    else
                        Add_Replacee(oWordDoc, oWordApp, match.ToString(), "");

                }
                if (match.ToString() == "<<Company Name>>")
                    Add_Replacee(oWordDoc, oWordApp, match.ToString(), ddlClient.SelectedItem.Text);
                if (match.ToString() == "<<Client Name>>")
                    Add_Replacee(oWordDoc, oWordApp, match.ToString(), ddlClient.SelectedItem.Text);

            }
        }
        #endregion

        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        #region Notice Section
        public void WriteFieldsForContactInformationNotice_V2(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, int index, int marketplaceSelectedIndex = 0, string creditableCoverageValue = "", CheckBoxList chkAnualNotice = null, bool isSelected = false, string selectedColor = "", string summaryName = "")
        {
            int iTotalFields = 0;
            BPBusiness bp = new BPBusiness();

            Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
            try
            {
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    //if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    //{
                    if (shape.Name == "Annual_Notice_1" || shape.Name == "Annual_Notice_2" || shape.Name == "Annual_Notice_3" || shape.Name == "Annual_Notice_4" || shape.Name == "Annual_Notice_4_a" || shape.Name == "Annual_Notice_5" || shape.Name == "Annual_Notice_6" || shape.Name == "Annual_Notice_7" || shape.Name == "Annual_Notice_8" || shape.Name == "Annual_Notice_9")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        shape.TextFrame.TextRange.Font.Color = Word.WdColor.wdColorWhite;
                    }
                    // }
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("(MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("(MODIFICATION REQUIRED"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED");
                            continue;
                        }
                        if (fieldName.Contains("MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)");
                            continue;
                        }
                        if (fieldName.Contains("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)");
                            continue;
                        }

                        if (fieldName.Contains("(IF APPLICABLE -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(IF APPLICABLE - ");
                            continue;
                        }

                        if (fieldName.Contains("(ONLY USE IF GRANDFATHERED -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(ONLY USE IF GRANDFATHERED - ");
                            continue;
                        }

                        if (fieldName.Contains("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION");
                            continue;
                        }

                        if (fieldName.Contains("REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("REQUIRED)");
                            continue;
                        }

                        if (fieldName.Contains("MICHELLE’S LAW DISCLOSURE"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MICHELLE’S LAW DISCLOSURE");
                            continue;
                        }
                        if (fieldName.Contains("(USE ONLY IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(USE ONLY IF APPLICABLE)");
                            continue;
                        }
                        if (fieldName.Contains("Receive Information about Your Plan and Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Receive Information about Your Plan and Benefits");
                            continue;
                        }
                        if (fieldName.Contains("Continue Group Health Plan Coverage"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Continue Group Health Plan Coverage");
                            continue;
                        }
                        if (fieldName.Contains("Prudent Actions by Plan Fiduciaries"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Prudent Actions by Plan Fiduciaries");
                            continue;
                        }
                        if (fieldName.Contains("Enforce your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Enforce your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Assistance with your Questions"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Assistance with your Questions");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("Your Information. Your Rights. Our Responsibilities."))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.Range.Font.Bold = 1;
                            oWordApp.Selection.TypeText("Your Information. Your Rights. Our Responsibilities.");
                            continue;
                        }
                        if (fieldName.Contains("Your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Your Choices"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Choices");
                            continue;
                        }
                        if (fieldName.Contains("Our Uses and Disclosures"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Our Uses and Disclosures");
                            continue;
                        }
                        if (fieldName.Contains("Changes to the Terms of this Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Changes to the Terms of this Notice");
                            continue;
                        }
                        if (fieldName.Contains("Other Instructions for Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Other Instructions for Notice");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("PART A: General Information"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART A: General Information");
                            continue;
                        }
                        if (fieldName.Contains("What is the Health Insurance Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("What is the Health Insurance Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Can I Save Money on my Health Insurance Premiums in the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Can I Save Money on my Health Insurance Premiums in the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("How Can I Get More Information?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("How Can I Get More Information?");
                            continue;
                        }
                        if (fieldName.Contains("PART B: Information About Health Coverage Offered by Your Employer"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART B: Information About Health Coverage Offered by Your Employer");
                            continue;
                        }
                        if (fieldName.Contains("HealthCare.gov"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("HealthCare.gov");
                            continue;
                        }

                        if (fieldName.Contains("CREDITABLE COVERAGE"))
                        {
                            if (creditableCoverageValue.Trim() != string.Empty)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (creditableCoverageValue.Trim() != "Not Included")
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                switch (creditableCoverageValue)
                                {
                                    case "Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Non-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Cobra-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11c - Creditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11c - Notice of Creditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Cobra-Non-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11d - Noncreditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11d - Notice of Noncreditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Creditable-Spanish":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide_Spanish.docx"), missing, true, missing, missing);

                                        }
                                        else
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11_Spanish.docx"), missing, true, missing, missing);
                                        }

                                        break;
                                    case "NonCreditable-Spanish":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide_Spanish.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11_spanish.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    default:
                                        break;
                                }

                                #region to be remove
                                //if (creditableCoverageIndex == 1)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 2)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 3)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11c - Creditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11c - Notice of Creditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 4)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11d - Noncreditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11d - Notice of Noncreditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                #endregion
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Notice of Privacy Practices"))
                        {
                            if (chkAnualNotice.Items[9].Selected == true)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);

                                if (summaryName == "Enrollment Summary" || summaryName == "Summary Highlight" || summaryName == "Value Summary" || summaryName == "Enrollment Guide")
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices_EnrolmentGuide.doc"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                    }
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                }
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (index > -1)
                        {
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("\f");
                                if (isSelected == true)
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText("CONTACT INFORMATION");
                                }
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Name);
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Address);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Email);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Phone.Count == 0)
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    StringBuilder Phone = new StringBuilder(); ;
                                    for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                    {
                                        Phone.Append(ContactList[index].Phone[i]);
                                        if (ContactList[index].Phone[i] != string.Empty)
                                        {
                                            if (Phone.ToString().Contains("_"))
                                            {
                                                Phone.Replace("_", "-");
                                            }
                                            Phone.Append("\n");
                                        }
                                    }
                                    oWordApp.Selection.TypeText(Phone.ToString());
                                }
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Postion == " ")
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(ContactList[index].Postion);
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("MARKETPLACE COVERAGE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Delete();
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteNoticeSectionToTabs(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();



                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionMountain");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
    }
}