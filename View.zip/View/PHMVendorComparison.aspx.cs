﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using System.IO;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using Word = Microsoft.Office.Interop.Word;
using BenefitPointSummaryPortal.BAL.PHM;
using System.Drawing;

namespace BenefitPointSummaryPortal.View
{
    public partial class PHMVendorComparison : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose Destination_wobj = new WordOpenClose();

        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        private static string Activity = "Vendor Comparison - CORE Health";
        private static string Activity_Group = "Population Health Management";


        string SessionId = "";
        string Session_DataSourceKey = "DataSource";
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session_DataSourceKey = Session_DataSourceKey + hdnUniqueID.Value;
                if (Session["Summary"].ToString().Equals("PHMVendorComparison"))
                {
                    Page.MaintainScrollPositionOnPostBack = true;
                    div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                    if (!IsPostBack)
                    {
                        Random objRan = new Random();
                        hdnUniqueID.Value = objRan.Next(int.MaxValue).ToString();
                        Session_DataSourceKey = Session_DataSourceKey + hdnUniqueID.Value;
                        mvMedicalLOC.ActiveViewIndex = 0;
                        SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                        SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                        Session["SessionId"] = SessionId;
                        objCommFun.GetUserDetails();
                        ddlOption_SelectedIndexChanged(null, null);
                        DataTable OptionDataSource = Build_ComparisonOptionDataSource();
                        Session[Session_DataSourceKey] = OptionDataSource;
                        BindGrid();
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void ddlOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            trClientDetailRow1.Style.Add("display", "none");
            trClientDetailRow2.Style.Add("display", "none");
            trProspectName.Style.Add("display", "none");
            spnClientDescription.Text = "";
            switch (ddlOption.SelectedValue)
            {
                case "Client":
                    trClientDetailRow1.Style.Add("display", "");
                    trClientDetailRow2.Style.Add("display", "");
                    spnClientDescription.Text = "Indicate which BenefitPoint client you would like to create a Vendor Comparison for.";
                    break;
                case "Prospect":
                    trProspectName.Style.Add("display", "");
                    spnClientDescription.Text = "Enter the name of the Prospect you would like to create a Vendor Comparison for.";
                    break;
            }
        }
        private void ResetForm()
        {
            ddlOption.SelectedValue = "Select";
            txtsearch.Text = "";
            rdlClient.SelectedIndex = 0;
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            txtAccountContactName.Text = "";
            txtAccountContactRole.Text = "";
            DataTable OptionDataSource = Build_ComparisonOptionDataSource();
            Session[Session_DataSourceKey] = OptionDataSource;
            BindGrid();
            ddlOption_SelectedIndexChanged(null, null);
        }
        private bool ValidateForm()
        {
            if (ddlOption.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Report Option.')</script>");
                ddlOption.Focus();
                return false;
            }
            if (ddlOption.SelectedValue == "Client")
            {
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                    ddlClient.Focus();
                    return false;
                }
            }
            if (ddlOption.SelectedValue == "Prospect")
            {
                if (txtProspectName.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter Prospect Name.')</script>");
                    txtProspectName.Focus();
                    return false;
                }
            }
            DataTable dlblSource = (DataTable)Session[Session_DataSourceKey];
            int TotalRecords = dlblSource.Select("IsSelected = true").Count();

            if (TotalRecords == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Comparison Option(s).')</script>");
                gvComparisonOptions.Focus();
                return false;
            }
            return true;
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                if (ValidateForm())
                {
                    Create_VendorComparisonTemplate();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void chkItemSelect_CheckedChanged(object sender, EventArgs e)
        {
            if (sender != null)
            {
                DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;

                CheckBox chkItem = sender as CheckBox;
                string CLientID = chkItem.ClientID;
                string[] IdParts = CLientID.Split('_');
                int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
                dlblDataSource.Rows[RowIndex]["IsSelected"] = chkItem.Checked;
                Session[Session_DataSourceKey] = dlblDataSource;
                BindGrid();
            }
        }
        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkItem = sender as CheckBox;
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            foreach (DataRow dr in dlblDataSource.Rows)
            {
                dr["IsSelected"] = chkItem.Checked;
            }
            Session[Session_DataSourceKey] = dlblDataSource;
            BindGrid();
        }
        private DataTable Build_ComparisonOptionDataSource()
        {
            DataTable dtOptionDataSource = new DataTable();
            dtOptionDataSource.Columns.Add(new DataColumn("ComparisonOptionName", Type.GetType("System.String")));
            dtOptionDataSource.Columns.Add(new DataColumn("LinkText", Type.GetType("System.String")));
            dtOptionDataSource.Columns.Add(new DataColumn("Url", Type.GetType("System.String")));
            dtOptionDataSource.Columns.Add(new DataColumn("SortOrder", Type.GetType("System.Int16")));
            dtOptionDataSource.Columns.Add(new DataColumn("IsSelected", Type.GetType("System.Boolean")));

            DataRow dr1 = dtOptionDataSource.NewRow();
            dr1["ComparisonOptionName"] = "Zomo";
            dr1["LinkText"] = "Pricing Sheet";
            dr1["Url"] = "http://usi-sp-01/Employee%20Benefits%20Operations%20-%20Lib/2.22.2018%20ZomoHealth-Information%20Packet%20Pricing%20Sheet.pdf";
            dr1["SortOrder"] = 1;
            dr1["IsSelected"] = true;
            dtOptionDataSource.Rows.Add(dr1);

            DataRow dr2 = dtOptionDataSource.NewRow();
            dr2["ComparisonOptionName"] = "Bravo";
            dr2["LinkText"] = "Pricing Sheet";
            dr2["Url"] = "http://usi-sp-01/Employee Benefits Operations - Lib/8.24.2018 Bravo+USICORE-Overview-Pricing_20180813_v1.0.pdf";
            dr2["SortOrder"] = 2;
            dr2["IsSelected"] = true;
            dtOptionDataSource.Rows.Add(dr2);


            DataRow dr3 = dtOptionDataSource.NewRow();
            dr3["ComparisonOptionName"] = "TriHealth";
            dr3["LinkText"] = "Pricing Sheet";
            dr3["Url"] = "http://usi-sp-01/Employee Benefits Operations - Lib/6.9.2017 Healthy Directions Pricing Sheet.pdf";
            dr3["SortOrder"] = 3;
            dr3["IsSelected"] = true;
            dtOptionDataSource.Rows.Add(dr3);

            DataRow dr4 = dtOptionDataSource.NewRow();
            dr4["ComparisonOptionName"] = "Wellworks";
            dr4["LinkText"] = "Pricing Sheet";
            dr4["Url"] = "http://usi-sp-01/Employee Benefits Operations - Lib/12.4.2018 WellworksPricingSheet_2019 FINAL.pdf";
            dr4["SortOrder"] = 4;
            dr4["IsSelected"] = true;
            dtOptionDataSource.Rows.Add(dr4);

            return dtOptionDataSource;
        }
        private void BindGrid()
        {
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            DataView dv = new DataView(dlblDataSource);
            dv.Sort = ("SortOrder" + " ASC");
            dlblDataSource = dv.ToTable();
            gvComparisonOptions.DataSource = dlblDataSource;
            gvComparisonOptions.DataBind();
            Session[Session_DataSourceKey] = dlblDataSource;
            SetHeaderCheckBox();
        }
        protected void MoveGridViewRowUp(object sender, EventArgs e)
        {
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            Button btnItem = sender as Button;
            string CLientID = btnItem.ClientID;
            string[] IdParts = CLientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            dlblDataSource.Rows[RowIndex]["SortOrder"] = int.Parse(dlblDataSource.Rows[RowIndex]["SortOrder"].ToString()) - 1;
            dlblDataSource.Rows[RowIndex - 1]["SortOrder"] = int.Parse(dlblDataSource.Rows[RowIndex - 1]["SortOrder"].ToString()) + 1;
            Session[Session_DataSourceKey] = dlblDataSource;
            BindGrid();

        }
        protected void MoveGridViewRowDown(object sender, EventArgs e)
        {
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            Button btnItem = sender as Button;
            string CLientID = btnItem.ClientID;
            string[] IdParts = CLientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            dlblDataSource.Rows[RowIndex]["SortOrder"] = int.Parse(dlblDataSource.Rows[RowIndex]["SortOrder"].ToString()) + 1;
            dlblDataSource.Rows[RowIndex + 1]["SortOrder"] = int.Parse(dlblDataSource.Rows[RowIndex + 1]["SortOrder"].ToString()) - 1;
            Session[Session_DataSourceKey] = dlblDataSource;
            BindGrid();

        }
        protected void gvComparisonOptions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            int RowIndex = e.Row.RowIndex;
            if (RowIndex >= 0)
            {
                Button btnUp = e.Row.FindControl("btnUp") as Button;
                Button btnDown = e.Row.FindControl("btnDown") as Button;
                btnUp.Enabled = true;
                btnDown.Enabled = true;
                if (RowIndex == 0)
                {
                    btnUp.Enabled = false;
                    btnUp.BackColor = Color.Silver;
                }
                if (RowIndex == dlblDataSource.Rows.Count - 1)
                {
                    btnDown.Enabled = false;
                    btnDown.BackColor = Color.Silver;
                }
            }

        }
        private void SetHeaderCheckBox()
        {
            bool CheckAll = true;
            DataTable dlblDataSource = Session[Session_DataSourceKey] as DataTable;
            foreach (DataRow item in dlblDataSource.Rows)
            {
                if (bool.Parse(item["IsSelected"].ToString()) == false)
                {
                    CheckAll = false;
                    break;
                }
            }
            CheckBox chkHeader = gvComparisonOptions.HeaderRow.FindControl("chkHeaderSelect") as CheckBox;
            chkHeader.Checked = CheckAll;

        }
        private void Create_VendorComparisonTemplate()
        {
            VendorComparison wr = new VendorComparison();
            string ClientProspectName = string.Empty;
            string AccountContactRole = string.Empty;
            string AccountContactName = string.Empty;
            Object missing = System.Reflection.Missing.Value;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/PHMVendorComparison/Documents/Templates/Downloaded")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PHMVendorComparison/Documents/Templates/Downloaded"));
                }

                DataTable dlblSource = (DataTable)Session[Session_DataSourceKey];
                WordOpenClose wobjSource = new WordOpenClose();
                string SourceFileName = "~/Files/PHMVendorComparison/Documents/Templates/PHM_VendorComparison_Template_v2.docx";
                wobjSource.Word_OpenReadOnly(wobjSource.office.oWordApp, wobjSource.office.oWordDoc, SourceFileName, missing);

                string DestinationFileName = "~/Files/PHMVendorComparison/Documents/Templates/PHM_VendorComparison_Template_v1_Blank.docx";
                string _savefilename = "~/Files/PHMVendorComparison/Documents/Templates/Downloaded/NewDocument";
                Destination_wobj.Word_Open_DOCX(Destination_wobj.office.oWordApp, Destination_wobj.office.oWordDoc, DestinationFileName, _savefilename, missing);

                ClientProspectName = ddlOption.SelectedValue == "Client" ? ddlClient.SelectedItem.Text : txtProspectName.Text.Trim();
                AccountContactRole = txtAccountContactRole.Text.Trim();
                AccountContactName = txtAccountContactName.Text.Trim();
                wr.WriteCommonFieldToVendorComparisonTemplate(wobjSource.office.oWordDoc, wobjSource.office.oWordApp, Destination_wobj.office.oWordDoc, Destination_wobj.office.oWordApp, ClientProspectName, AccountContactRole, AccountContactName, dlblSource);
                wr.WriteFooterFieldToVendorComparisonTemplate(Destination_wobj.office.oWordDoc, Destination_wobj.office.oWordApp, DateTime.Now);
                Destination_wobj.office.oWordDoc.Save();
                Destination_wobj.Word_Close(Destination_wobj.office.oWordApp, Destination_wobj.office.oWordDoc, missing);
                wobjSource.Word_Close(wobjSource.office.oWordApp, wobjSource.office.oWordDoc, missing);
                DownloadFileNew(Destination_wobj.Save_File);

                #region ------- Code for Add Activity Log --------
                string AdditionalCrtieriaOption_1 = ddlOption.SelectedValue == "Client" ? ddlClient.SelectedItem.Text : txtProspectName.Text.Trim();
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                Account_Office = ddlOption.SelectedValue == "Client" ? objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region) : string.Empty;
                //DictDepartment = sd.getDepartmentDetails();
                ////DicActivityLog.Clear();
                ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
       
    }
}