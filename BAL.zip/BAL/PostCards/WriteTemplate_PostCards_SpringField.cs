﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Text;
using System.Collections;
using Microsoft.Office.Interop.Word;
using BenefitPointSummaryPortal.DAL;
using System.Data.SqlClient;
namespace BenefitPointSummaryPortal.BAL.PostCards
{
    public class WriteTemplate_PostCards_SpringField : System.Web.UI.Page
    {
        DBHelper DB_helper = new DBHelper();
        public void Add_Replacee(Word.Document oWordDoc, Word.Application oWordApp, Word.Range range, string mergeField, string fieldName)
        {
            if (String.IsNullOrEmpty(fieldName))
                fieldName = string.Empty;

            Word.Find find = range.Find;
            find.Text = mergeField;

            find.ClearFormatting();
            Object missing = System.Reflection.Missing.Value;
            range.Find.Execute(
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing);
            while (find.Found)
            {
                find.Replacement.ClearFormatting();
                //     find.Replacement.Highlight = 0;
                find.Replacement.Text = fieldName;
                object replaceAll = Word.WdReplace.wdReplaceAll;
                find.Execute(ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref replaceAll, ref missing, ref missing, ref missing, ref missing);
            }
        }

        public void Write_PostCards_SpringField_Fields(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataSet AccountDS, List<Contact> ContactList, ArrayList arrAcctContact)
        {

            string AccountAddress1 = string.Empty;
            string AccountAddress2 = string.Empty;
            string AccountAddress = string.Empty;
            string City = string.Empty;
            string State = string.Empty;
            string Zip = string.Empty;
            string Street1 = string.Empty;
            string Street2 = string.Empty;


            #region HR Contact
            string HRContact_Firstname = string.Empty;
            string HRContact_Lastname = string.Empty;
            string HRContact_Phone = string.Empty;
            string HRContact_Email = string.Empty;
            // string HRContact_ = string.Empty;


            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].First_Name != null)
                                {
                                    HRContact_Firstname = ContactList[i].First_Name;


                                }
                                else
                                {
                                    HRContact_Firstname = "";
                                }
                                if (ContactList[i].Last_Name != null)
                                {


                                    HRContact_Lastname = ContactList[i].Last_Name;
                                }
                                else
                                {
                                    HRContact_Lastname = "";
                                }
                                if (ContactList[i].Email != null)
                                {


                                    HRContact_Email = ContactList[i].Email;
                                }
                                else
                                {
                                    HRContact_Email = "";
                                }
                                if (ContactList[i].Phone.Count > 0)
                                {


                                    HRContact_Phone = ContactList[i].Phone[0];
                                }
                                else
                                {
                                    HRContact_Phone = "";
                                }

                            }
                        }
                    }
                }
            }
            #endregion
            #region Address
            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                        {
                            City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                        {
                            State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                            State = State.Replace("_", " ");
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                        {
                            Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                        {
                            Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                        {
                            Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                        }

                    }
                }
            }
            #endregion

            AccountAddress1 = Street1;
            AccountAddress2 = Street2;
            AccountAddress = Street1 + "\n" + Street2;
            string State_Abbriviation = SearchStateAbbriviation(State);
            foreach (Word.Shape shape in oWordDoc.Shapes)
            {
                shape.Select();
                if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                {
                    Word.GroupShapes dyShapes = shape.GroupItems;
                    //foreach (dynamic item in dyShapes)
                    //{
                    //    var ranges = item.TextFrame2.TextRange.Text;
                    //}
                    for (int i = 1; i <= dyShapes.Count; i++)
                    {

                        dyShapes[i].Select();
                        //  Word.Range ra=     oWordApp.Selection.Range;
                        if (dyShapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoTextBox || dyShapes[i].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                        {

                            Word.Range range = dyShapes[i].TextFrame.TextRange;
                            StringBuilder extractText = new StringBuilder(range.Text);
                            System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"\<<(.*?)\>>",
                           System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                            System.Text.RegularExpressions.MatchCollection matches = rx.Matches(extractText.ToString());
                            foreach (System.Text.RegularExpressions.Match match in matches)
                            {
                                range = dyShapes[i].TextFrame.TextRange;
                                if (match.ToString() == "<<Client Name>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), ClientName);
                                    continue;
                                }
                                if (match.ToString() == "<<HR Contact First Name>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), HRContact_Firstname);
                                    continue;
                                }
                                if (match.ToString() == "<<HR Contact Last Name>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), HRContact_Lastname);
                                    continue;
                                }
                                if (match.ToString() == "<<HR Contact Work Phone>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), HRContact_Phone);
                                    continue;
                                }
                                if (match.ToString() == "<<HR Contact Email>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), HRContact_Email);
                                    continue;
                                }
                                if (match.ToString() == "<<Client Main Address 1>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), AccountAddress1);
                                    continue;
                                }
                                if (match.ToString() == "<<Client Main Address2>>")
                                {
                                    if (AccountAddress2 == string.Empty || AccountAddress2 == null)
                                    {
                                        if (range.Find.Execute("<<Client Main Address2>>"))
                                        {
                                            range.Expand(WdUnits.wdParagraph); // or change to .wdSentence or .wdParagraph
                                            range.Delete();
                                        }
                                        continue;
                                    }
                                    else
                                    {
                                        Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), AccountAddress2);
                                        continue;
                                    }
                                }
                                if (match.ToString() == "<<Client Main City>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), City);
                                    continue;
                                }
                                if (match.ToString() == "<<Client Main State>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), State_Abbriviation);
                                    continue;
                                }
                                if (match.ToString() == "<<Client Main Zip Code>>")
                                {
                                    Add_Replacee(oWordDoc, oWordApp, range, match.ToString(), Zip);
                                    continue;
                                }
                                //if (match.ToString() == ""){
                                //                      Add_Replacee(oWordDoc, oWordApp, match.ToString(), );
                                //                  }

                            }
                        }
                    }
                }



            }

        }

        public string SearchStateAbbriviation(string State)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@StateName", SqlDbType.NVarChar, 500) };

                parameters[0].Value = State;
                DataTable dtblStateAbbriviation = DB_helper.ExecProcedure("GetStateAbbreviation", parameters);

                string stateabbrivation;

                if (dtblStateAbbriviation.Rows.Count > 0)
                    stateabbrivation = dtblStateAbbriviation.Rows[0]["StateAbbreviation"].ToString();
                else
                    stateabbrivation = "";
                return stateabbrivation;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
    }
}