﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using BenefitPointSummaryPortal.BAL.BPTimeLine;


namespace BenefitPointSummaryPortal.BAL.Reports
{
    public class RenewalStatusReport_V2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();

        public void WriteFieldToReports2(Excel.Worksheet myExcelApp, int SubjectID, string SessionId, CheckBoxList cblistOffice, DropDownList ddlProducerTeam, DateTime _fromdate, DateTime _todate, List<Account> filteredAccountList, DropDownList ddlDateType)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                string RenewalDate = string.Empty;
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                // Hashtable for PreRenewal
                #region HashTable_Reports
                Hashtable HashtableReports1 = new Hashtable();
                HashtableReports1.Add(1, "17630");   //Experience w/ Pre‐Rnwl?*
                HashtableReports1.Add(2, "17631");   //Target Date (Pre)*
                HashtableReports1.Add(3, "17632");   //Internal Date (Pre)
                HashtableReports1.Add(4, "17633");   //Completed Date (Pre)
                HashtableReports1.Add(5, "17634");   //Meeting Status (Pre)
                HashtableReports1.Add(6, "17641");   //Experience w/ Renewal?*
                HashtableReports1.Add(7, "17642");   //Target Date (Rnwl)*
                HashtableReports1.Add(8, "17643");   //Internal Date (Rnwl)
                HashtableReports1.Add(9, "17644");   //Completed Date (Rnwl)
                HashtableReports1.Add(10, "17645");  //Meeting Status (Rnwl)
                HashtableReports1.Add(11, "17646");  //Experience w/ Post‐Renewal?*
                HashtableReports1.Add(12, "17647");  //Target Date (Post)*
                HashtableReports1.Add(13, "17648");  //Internal Date (Post)
                HashtableReports1.Add(14, "17649");  //Completed Date (Post)
                HashtableReports1.Add(15, "17650");  //Meeting Status (Post)
                HashtableReports1.Add(16, "17651");  //Meeting Type
                HashtableReports1.Add(17, "17652");  //Target Date (Misc)*
                HashtableReports1.Add(18, "17653");  //Internal Date (Misc)
                HashtableReports1.Add(19, "17654");  //Completed Date (Misc)
                HashtableReports1.Add(20, "17655");  //Meeting Status (Misc)
                HashtableReports1.Add(21, "17604");  //Renewal Date
                HashtableReports1.Add(22, "17605");  //Request Census Target Date1
                HashtableReports1.Add(23, "17606");  //Receive Census Target Date2
                HashtableReports1.Add(24, "17607");  //Send Renewal Letter Target Date
                HashtableReports1.Add(25, "17608");  //Send RFP Target Date
                HashtableReports1.Add(26, "17609");  //Receive RFP Target Date
                HashtableReports1.Add(27, "17610");  //Make Benefit Decisions Target Date
                HashtableReports1.Add(28, "17611");  //Enrollment Materials Target Date
                HashtableReports1.Add(29, "17612");  //Employee Meetings Target Date
                HashtableReports1.Add(30, "17613");  //OE Paperwork Target Date
                HashtableReports1.Add(31, "17614");  //Finalize Enrollment Target Date
                HashtableReports1.Add(32, "17615");  //CMS Reminder Target Date
                HashtableReports1.Add(33, "17617");  //Request Census Completed Date
                HashtableReports1.Add(34, "17618");  //Receive Census Target Date Completed
                HashtableReports1.Add(35, "17619");  //Send Renewal Letter Completed Date
                HashtableReports1.Add(36, "17620");  //Send RFP Completed Date
                HashtableReports1.Add(37, "17621");  //Receive RFP Completed Date
                HashtableReports1.Add(38, "17622");  //Make Benefit Decisions Completed Date
                HashtableReports1.Add(39, "17623");  //Enrollment Materials Completed Date
                HashtableReports1.Add(40, "17624");  //Employee Meetings Completed Date
                HashtableReports1.Add(41, "17625");  //OE Paperwork Completed Date
                HashtableReports1.Add(42, "17626");  //Finalize Enrollment Completed Date
                HashtableReports1.Add(43, "17627");  //CMS Reminder Completed Date

                ArrayList arrActivityDetails = new ArrayList();
                foreach (int key in HashtableReports1.Keys)
                {
                    arrActivityDetails.Add(key);
                }

                arrActivityDetails.Sort();
                #endregion

                TimelineDetail timeD = new TimelineDetail();
                DataTable ActivityInfoTable = new DataTable();
                DataTable filteredActivityTable = new DataTable();

                filteredActivityTable.Columns.Add("recordID", typeof(Int32));               // Row 0  
                filteredActivityTable.Columns.Add("subject", typeof(string));               // Row 1  
                filteredActivityTable.Columns.Add("name", typeof(string));                  // Row 2  
                filteredActivityTable.Columns.Add("createdon", typeof(string));             // Row 3   
                filteredActivityTable.Columns.Add("dueon", typeof(string));                 // Row 4  
                filteredActivityTable.Columns.Add("status", typeof(string));                // Row 5  
                filteredActivityTable.Columns.Add("AccountID", typeof(Int32));              // Row 6
                filteredActivityTable.Columns.Add("ClientName", typeof(string));            // Row 7
                filteredActivityTable.Columns.Add("salesLeadId", typeof(Int32));            // Row 8
                filteredActivityTable.Columns.Add("serviceLeadId", typeof(Int32));          // Row 9
                filteredActivityTable.Columns.Add("primaryContactId", typeof(Int32));       // Row 10

                DataSet ActivityDS = new DataSet();
                int rowIndex = 3;
                SummaryDetail sd = new SummaryDetail();
                DataSet AccountTeamMemberDS = new DataSet();

                string customValue = string.Empty;
                bool flagIsCreateDateSelected = false;
                bool flagIsRenewalDateSelected = false;


                // If ddlDateType = "Create Date"
                if (ddlDateType.SelectedValue == "1")
                {
                    flagIsCreateDateSelected = true;
                }
                // If ddlDateType = "Renewal Date"
                else if (ddlDateType.SelectedValue == "2")
                {
                    flagIsRenewalDateSelected = true;
                }

                foreach (var dr in filteredAccountList)
                {
                    ActivityDS = timeD.Get_Activity_Detail_For_Reports(Convert.ToInt32(dr.RecordId), SessionId);

                    // Get TeamMembers dataset for fetching PrimaryContactName, PrimarySalesLeadUserName and PrimaryServiceLeadUserName
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(dr.AccountId), SessionId);

                    var salesLeadName = (from n in AccountTeamMemberDS.Tables["AccountTeamMember"].AsEnumerable()
                                         where n.Field<string>("userID") == Convert.ToString(dr.PrimarySalesLeadUserID)
                                         select (n.Field<string>("firstName")) + " " + (n.Field<string>("lastName"))).FirstOrDefault();

                    var serviceLeadName = (from n in AccountTeamMemberDS.Tables["AccountTeamMember"].AsEnumerable()
                                           where n.Field<string>("userID") == Convert.ToString(dr.PrimaryServiceLeadUserID)
                                           select (n.Field<string>("firstName")) + " " + (n.Field<string>("lastName"))).FirstOrDefault();

                    var primaryContactName = (from n in AccountTeamMemberDS.Tables["AccountTeamMember"].AsEnumerable()
                                              where n.Field<string>("userID") == Convert.ToString(dr.PrimaryContactUserID)
                                              select (n.Field<string>("firstName")) + " " + (n.Field<string>("lastName"))).FirstOrDefault();

                    var preRenewal = (from n in ActivityDS.Tables["activityCustomFieldValues_table"].AsEnumerable()
                                      where n.Field<Int32>("customFieldValues_CustomFieldId") == 17629
                                      select n.Field<string>("customFieldValues_valueText")).FirstOrDefault();

                    var Renewal = (from n in ActivityDS.Tables["activityCustomFieldValues_table"].AsEnumerable()
                                   where n.Field<Int32>("customFieldValues_CustomFieldId") == 17636
                                   select n.Field<string>("customFieldValues_valueText")).FirstOrDefault();

                    var postRenewal = (from n in ActivityDS.Tables["activityCustomFieldValues_table"].AsEnumerable()
                                       where n.Field<Int32>("customFieldValues_CustomFieldId") == 17637
                                       select n.Field<string>("customFieldValues_valueText")).FirstOrDefault();

                    var misc = (from n in ActivityDS.Tables["activityCustomFieldValues_table"].AsEnumerable()
                                where n.Field<Int32>("customFieldValues_CustomFieldId") == 17638
                                select n.Field<string>("customFieldValues_valueText")).FirstOrDefault();

                    // Iterate loop on ActivityDS to make use of HashTable
                    if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count > 0)
                    {
                        foreach (int key in arrActivityDetails)
                        {
                            foreach (DataRow drAct in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (drAct["customFieldValues_CustomFieldId"].ToString() == "17604")
                                {
                                    RenewalDate = Convert.ToDateTime(drAct["customFieldValues_valueText"].ToString()).ToString("MM/dd/yyyy");
                                }

                                if (flagIsRenewalDateSelected == true)
                                {
                                    if ((Convert.ToDateTime(RenewalDate) >= _fromdate && Convert.ToDateTime(RenewalDate) <= _todate) || (_fromdate == DateTime.MinValue && _todate == DateTime.MinValue))
                                    {
                                        WriteExcelCells(myExcelApp, HashtableReports1, key, drAct, dr.AccountName, serviceLeadName, primaryContactName, RenewalDate, salesLeadName, preRenewal, Renewal, postRenewal, misc, rowIndex);
                                    }
                                }
                                else if (flagIsCreateDateSelected == true)
                                {
                                    WriteExcelCells(myExcelApp, HashtableReports1, key, drAct, dr.AccountName, serviceLeadName, primaryContactName, RenewalDate, salesLeadName, preRenewal, Renewal, postRenewal, misc, rowIndex);
                                }
                            }
                        }

                        //myExcelApp.Cells[rowIndex, 1] = dr.AccountName;
                        //myExcelApp.Cells[rowIndex, 2] = salesLeadName;
                        //myExcelApp.Cells[rowIndex, 3] = serviceLeadName;
                        //myExcelApp.Cells[rowIndex, 4] = primaryContactName;

                        //myExcelApp.Cells[rowIndex, 5] = RenewalDate;

                        if (flagIsRenewalDateSelected == true)
                        {
                            if (Convert.ToDateTime(RenewalDate) >= _fromdate && Convert.ToDateTime(RenewalDate) <= _todate)
                            {
                                myExcelApp.Range["A3:AU" + Convert.ToString(rowIndex)].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                                rowIndex++;
                            }
                        }
                        else if (flagIsCreateDateSelected == true)
                        {
                            myExcelApp.Range["A3:AU" + Convert.ToString(rowIndex)].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                            rowIndex++;
                        }
                    }


                    //rowIndex++;
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void WriteExcelCells(Excel.Worksheet myExcelApp, Hashtable HashtableReports1, int key, DataRow drAct, string AccountName, string serviceLeadName, string primaryContactName, string RenewalDate, string salesLeadName, string preRenewal, string Renewal, string postRenewal, string misc, int rowIndex)
        {
            string value = string.Empty;
            string customValue = string.Empty;
            DateTime dateValue = new DateTime();

            try
            {
                if (drAct["customFieldValues_CustomFieldId"].ToString() == HashtableReports1[key].ToString())
                {
                    value = drAct["customFieldValues_valueText"].ToString().Trim();

                    if (!string.IsNullOrEmpty(value) && value != "" && value != null)
                    {
                        if (DateTime.TryParse(value, out dateValue) == true)
                        {
                            customValue = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                        }
                        else
                        {
                            customValue = value;
                        }

                        if (!string.IsNullOrEmpty(preRenewal) && preRenewal.ToString().ToLower() == "yes")
                        {
                            if (key == 1) // Experience w/ Pre‐Rnwl?* - 17630
                            {
                                myExcelApp.Cells[rowIndex, 34] = customValue;//11
                            }
                            else if (key == 2) // Target Date (Pre)* - 17631
                            {
                                myExcelApp.Cells[rowIndex, 33] = customValue;
                            }
                            else if (key == 3) // Internal Date (Pre) - 17632
                            {
                                myExcelApp.Cells[rowIndex, 35] = customValue;
                            }
                            else if (key == 4) // Completed Date (Pre) - 17633
                            {
                                myExcelApp.Cells[rowIndex, 36] = customValue;
                            }
                            else if (key == 5) // Meeting Status (Pre) - 17634
                            {
                                myExcelApp.Cells[rowIndex, 37] = customValue;
                            }
                        }

                        if (!string.IsNullOrEmpty(Renewal) && Renewal.ToString().ToLower() == "yes")
                        {
                            if (key == 6) // Experience w/ Renewal?* - 17641
                            {
                                myExcelApp.Cells[rowIndex, 39] = customValue;
                            }
                            else if (key == 7) // Target Date (Rnwl)* - 17642
                            {
                                myExcelApp.Cells[rowIndex, 38] = customValue;//16
                            }
                            else if (key == 8) // Internal Date (Rnwl) - 17643
                            {
                                myExcelApp.Cells[rowIndex, 40] = customValue;
                            }
                            else if (key == 9) // Completed Date (Rnwl) - 17644
                            {
                                myExcelApp.Cells[rowIndex, 41] = customValue;
                            }
                            else if (key == 10) // Meeting Status (Rnwl) - 17645
                            {
                                myExcelApp.Cells[rowIndex, 42] = customValue;
                            }
                        }

                        if (!string.IsNullOrEmpty(postRenewal) && postRenewal.ToString().ToLower() == "yes")
                        {
                            if (key == 11) // Experience w/ Post‐Renewal?* - 17646
                            {
                                myExcelApp.Cells[rowIndex, 44] = customValue;
                            }
                            else if (key == 12) // Target Date (Post)* - 17647
                            {
                                myExcelApp.Cells[rowIndex, 43] = customValue;//21
                            }
                            else if (key == 13) // Internal Date (Post) - 17648
                            {
                                myExcelApp.Cells[rowIndex, 45] = customValue;
                            }
                            else if (key == 14) // Completed Date (Post) - 17649
                            {
                                myExcelApp.Cells[rowIndex, 46] = customValue;
                            }
                            else if (key == 15) // Meeting Status (Post) - 17650
                            {
                                myExcelApp.Cells[rowIndex, 47] = customValue;
                            }
                        }

                        if (!string.IsNullOrEmpty(misc) && misc.ToString().ToLower() == "yes")
                        {
                            if (key == 16) // Meeting Type - 17651
                            {
                                myExcelApp.Cells[rowIndex, 28] = customValue;//6
                            }
                            else if (key == 17) // Target Date (Misc)* - 17652
                            {
                                myExcelApp.Cells[rowIndex, 29] = customValue;
                            }
                            else if (key == 18) // Internal Date (Misc) - 17653
                            {
                                myExcelApp.Cells[rowIndex, 30] = customValue;
                            }
                            else if (key == 19) // Completed Date (Misc) - 17654
                            {
                                myExcelApp.Cells[rowIndex, 31] = customValue;
                            }
                            else if (key == 20) // Meeting Status (Misc) - 17655
                            {
                                myExcelApp.Cells[rowIndex, 32] = customValue;
                            }
                        }

                        //if (key == 21)
                        //{
                        //    myExcelApp.Cells[rowIndex, 10] = customValue;
                        //}
                        if (key == 22)
                        {
                            myExcelApp.Cells[rowIndex, 6] = customValue;//Request Census Target Date
                        }
                        if (key == 23)
                        {
                            myExcelApp.Cells[rowIndex, 8] = customValue;
                        }
                        if (key == 24)
                        {
                            myExcelApp.Cells[rowIndex, 10] = customValue;
                        }
                        if (key == 25)
                        {
                            myExcelApp.Cells[rowIndex, 12] = customValue;
                        }
                        if (key == 26)
                        {
                            myExcelApp.Cells[rowIndex, 14] = customValue;
                        }
                        if (key == 27)
                        {
                            myExcelApp.Cells[rowIndex, 16] = customValue;
                        }
                        if (key == 28)
                        {
                            myExcelApp.Cells[rowIndex, 18] = customValue;
                        }
                        if (key == 29)
                        {
                            myExcelApp.Cells[rowIndex, 20] = customValue;
                        }
                        if (key == 30)
                        {
                            myExcelApp.Cells[rowIndex, 22] = customValue;
                        }
                        if (key == 31)
                        {
                            myExcelApp.Cells[rowIndex, 24] = customValue;
                        }
                        if (key == 32)
                        {
                            myExcelApp.Cells[rowIndex, 26] = customValue;
                        }
                        if (key == 33)
                        {
                            myExcelApp.Cells[rowIndex, 7] = customValue;
                        }
                        if (key == 34)
                        {
                            myExcelApp.Cells[rowIndex, 9] = customValue;
                        }
                        if (key == 35)
                        {
                            myExcelApp.Cells[rowIndex, 11] = customValue;
                        }
                        if (key == 36)
                        {
                            myExcelApp.Cells[rowIndex, 13] = customValue;
                        }
                        if (key == 37)
                        {
                            myExcelApp.Cells[rowIndex, 15] = customValue;
                        }
                        if (key == 38)
                        {
                            myExcelApp.Cells[rowIndex, 17] = customValue;
                        }
                        if (key == 39)
                        {
                            myExcelApp.Cells[rowIndex, 19] = customValue;
                        }
                        if (key == 40)
                        {
                            myExcelApp.Cells[rowIndex, 21] = customValue;
                        }
                        if (key == 41)
                        {
                            myExcelApp.Cells[rowIndex, 23] = customValue;
                        }
                        if (key == 42)
                        {
                            myExcelApp.Cells[rowIndex, 25] = customValue;
                        }
                        if (key == 43)
                        {
                            myExcelApp.Cells[rowIndex, 27] = customValue;
                        }
                    }
                }

                myExcelApp.Cells[rowIndex, 1] = AccountName;
                myExcelApp.Cells[rowIndex, 2] = salesLeadName;
                myExcelApp.Cells[rowIndex, 3] = serviceLeadName;
                myExcelApp.Cells[rowIndex, 4] = primaryContactName;
                myExcelApp.Cells[rowIndex, 5] = RenewalDate;

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}