﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.DAL;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BRCInformation;


namespace BenefitPointSummaryPortal.View
{
    public partial class BRC_Information : System.Web.UI.Page
    {
        BPSummary bp = new BPSummary();
        DBHelper DB_helper = new DBHelper();
        BRCInformationOperation BRCInformationOps;

        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                ddlSearchBRCName.Focus();
                GetBRCOfficeNameList();
                BindLocation();
                BindRegion();
                BindState();
                btnSearch_Click(null, null);
                mvClientContact.ActiveViewIndex = 0;
                hdnID.Value = "0";
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchBRCInformation();
        }

        protected void bntSave_Click(object sender, EventArgs e)
        {
            try
            {
                BRCInformationOps = new BRCInformationOperation();

                bool flag = BRCInformationOps.InsertUpdateBRCDetails((int.Parse(hdnID.Value)), txtOfficeName.Text.Trim(), "", int.Parse(ddlBRCLocation.SelectedValue), ddlRegion.SelectedValue,
                    txtUSIOfficeLocation.Text.Trim(), ddlState.SelectedValue.ToString(), true);

                if (flag)
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('BRC details updated successfully.')</script>", false);
                    mvClientContact.ActiveViewIndex = 0;
                    ClearBRCInformationDetailForm();
                    hdnID.Value = "0";
                    btnSearch_Click(null, null);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while insert/updating record, please try again')</script>", false);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void SearchBRCInformation()
        {
            try
            {
                string strBRCName = ddlSearchBRCName.SelectedValue;
                int strBRCLocation = int.Parse(ddlSearchBRCLocation.SelectedValue);
                string strState = ddlSearchState.SelectedValue;

                BRCInformationOps = new BRCInformationOperation();

                DataTable dtblBRCInformation = BRCInformationOps.SearchBRCInformation(strBRCName, strState, strBRCLocation);

                grdBRCInformation.DataSource = dtblBRCInformation;
                grdBRCInformation.DataBind();

                ClearBRCInformationDetailForm();

            }
            catch (Exception ex)
            {

            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            hdnID.Value = "0";
            mvClientContact.ActiveViewIndex = 1;
            txtOfficeName.Focus();
            ClearBRCInformationDetailForm();
            bntSave.Text = "Save";
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            mvClientContact.ActiveViewIndex = 0;
            ddlSearchBRCName.Focus();
            hdnID.Value = "0";

        }
        protected void BtnReset_Click(object sender, EventArgs e)
        {
            mvClientContact.ActiveViewIndex = 0;
            ddlSearchBRCName.Focus();
            hdnID.Value = "0";

            ddlSearchBRCLocation.SelectedIndex = 0;
            ddlSearchBRCName.SelectedIndex = 0;
            ddlSearchState.SelectedIndex = 0;

        }

        private void FillBRCInforamtionDetails(int Id)
        {
            hdnID.Value = Id.ToString();
            BRCInformationOps = new BRCInformationOperation();

            DataTable dtblBRCDetails = BRCInformationOps.GetBRCInforamtionById(Id);

            if (dtblBRCDetails != null && dtblBRCDetails.Rows.Count > 0)
            {
                txtOfficeName.Text = dtblBRCDetails.Rows[0]["OfficeName"].ToString();
                txtUSIOfficeLocation.Text = dtblBRCDetails.Rows[0]["OfficeLocation"].ToString();

                if (ddlBRCLocation.Items.Contains(new ListItem(dtblBRCDetails.Rows[0]["BRCLocation"].ToString(), dtblBRCDetails.Rows[0]["BRCID"].ToString())))
                    ddlBRCLocation.SelectedValue = dtblBRCDetails.Rows[0]["BRCID"].ToString();
                else
                    ddlBRCLocation.SelectedIndex = 0;

                if (ddlRegion.Items.Contains(new ListItem(dtblBRCDetails.Rows[0]["Region"].ToString(), dtblBRCDetails.Rows[0]["Region"].ToString())))
                    ddlRegion.SelectedValue = dtblBRCDetails.Rows[0]["Region"].ToString();
                else
                    ddlRegion.SelectedIndex = 0;

                if (ddlState.Items.Contains(new ListItem(dtblBRCDetails.Rows[0]["State"].ToString(), dtblBRCDetails.Rows[0]["State"].ToString())))
                    ddlState.SelectedValue = dtblBRCDetails.Rows[0]["State"].ToString();
                else
                    ddlState.SelectedIndex = 0;

            }
        }

        protected void grdBRCInformation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string RowCommand = e.CommandName;
            if (RowCommand == "EditAddress")
            {
                mvClientContact.ActiveViewIndex = 1;
                ClearBRCInformationDetailForm();
                FillBRCInforamtionDetails(int.Parse(e.CommandArgument.ToString()));
                bntSave.Text = "Update";
            }
            else if (RowCommand == "DeleteAddress")
            {
                try
                {
                    BRCInformationOps = new BRCInformationOperation();
                    bool IsSuccess = BRCInformationOps.DeleteBRCInformationDetails(int.Parse(e.CommandArgument.ToString()));
                    if (IsSuccess)
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('BRC Details deleted successfully.')</script>", false);
                        btnSearch_Click(null, null);
                    }
                    else
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while deleting record, please try again')</script>", false);
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void ClearBRCInformationDetailForm()
        {
            txtOfficeName.Text = "";
            txtUSIOfficeLocation.Text = "";
            ddlBRCLocation.SelectedIndex = 0;

            ddlRegion.SelectedIndex = 0;
            ddlState.SelectedIndex = 0;
        }

        private void BindLocation()
        {
            try
            {
                BRCInformationOperation objBRCInfo = new BRCInformationOperation();
                DataTable dtblLocation = objBRCInfo.GetBRCLocation();
                ddlBRCLocation.DataSource = dtblLocation;
                ddlBRCLocation.DataBind();

                ddlSearchBRCLocation.DataSource = dtblLocation;
                ddlSearchBRCLocation.DataBind();
            }
            catch (Exception ex)
            {
            }

        }
        private void GetBRCOfficeNameList()
        {
            try
            {
                BRCInformationOperation objBRCInfo = new BRCInformationOperation();
                DataTable dtblOfficeName = objBRCInfo.GetBRCOfficeName();

                ddlSearchBRCName.DataSource = dtblOfficeName;
                ddlSearchBRCName.DataBind();
            }
            catch (Exception ex)
            {
            }
        }

        private void BindRegion()
        {
            BRCInformationOperation objBRCInfo = new BRCInformationOperation();
            DataTable dtblRegion = objBRCInfo.GetBRCRegion();
            ddlRegion.DataSource = dtblRegion;
            ddlRegion.DataBind();
        }

        private void BindState()
        {
            try
            {
                BRCInformationOperation objBRCInfo = new BRCInformationOperation();
                DataTable dtblLocation = objBRCInfo.GetBRCRegionStateList();
                ddlSearchState.DataSource = dtblLocation;
                ddlSearchState.DataBind();

                ddlState.DataSource = dtblLocation;
                ddlState.DataBind();
            }
            catch (Exception ex)
            {
            }

        }


    }
}