﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using System.IO;

using System.Runtime.InteropServices;
using BenefitPointSummaryPortal.BAL.Pilot;
using BenefitPointSummaryPortal.DAL;

namespace BenefitPointSummaryPortal.View
{

    public class MobileAppLocationItem
    {
        public string MobileAppLocationName { get; set; }
        public List<MobileAppVideo> EnglishVideos { get; set; }
        public List<MobileAppVideo> SpnaishVideos { get; set; }
        public MobileAppLocationItem()
        {
            EnglishVideos = new List<MobileAppVideo>();
            SpnaishVideos = new List<MobileAppVideo>();
        }
    }

    public class MobileAppVideo
    {
        public string VideoID { get; set; }
        public string VideoName { get; set; }
        public string VideoURL { get; set; }
    }


    public partial class Pilot_MobApp : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        //Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        ConstantValue cv = new ConstantValue();
        SummaryDetail sd = new SummaryDetail();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        #endregion
        List<MobileAppLocationItem> lstMobileAppLocations = new List<MobileAppLocationItem>();

        private void GetVideos()
        {
            DBHelper helper = new DBHelper();
            DataTable dtblMobileAppVideos = helper.ExecProcedure("GetMobileAppVideoLocations", null);
            if (dtblMobileAppVideos != null && dtblMobileAppVideos.Rows.Count > 0)
            {

                DataView view = new DataView(dtblMobileAppVideos);
                DataTable DistinctLocations = view.ToTable(true, "MobileAppLocation");

                foreach (DataRow dr in DistinctLocations.Rows)
                {
                    MobileAppLocationItem location = new MobileAppLocationItem();
                    location.MobileAppLocationName = dr["MobileAppLocation"].ToString().Trim();
                    DataRow[] EnglisVideos = dtblMobileAppVideos.Select("MobileAppLocation = '" + location.MobileAppLocationName.ToString() + "' AND Language = 'English'");
                    foreach (DataRow drVideo in EnglisVideos)
                    {
                        MobileAppVideo video = new MobileAppVideo();
                        video.VideoID = drVideo["VideoID"].ToString();
                        video.VideoURL = drVideo["VideoLink"].ToString();
                        video.VideoName = drVideo["VideoName"].ToString();
                        location.EnglishVideos.Add(video);
                    }
                    DataRow[] SpanishVideos = dtblMobileAppVideos.Select("MobileAppLocation = '" + location.MobileAppLocationName.ToString() + "' AND Language = 'Spanish'");
                    foreach (DataRow drVideo in SpanishVideos)
                    {
                        MobileAppVideo video = new MobileAppVideo();
                        video.VideoID = drVideo["VideoID"].ToString();
                        video.VideoURL = drVideo["VideoLink"].ToString();
                        video.VideoName = drVideo["VideoName"].ToString();
                        location.SpnaishVideos.Add(video);
                    }

                    lstMobileAppLocations.Add(location);

                }
                MobileAppLocationItem HomeLocation = new MobileAppLocationItem();
                HomeLocation.MobileAppLocationName = "Home Page";
                DataRow[] AllEnglishVideos = dtblMobileAppVideos.Select("Language = 'English'");
                DataRow[] AllSpanishVideos = dtblMobileAppVideos.Select("Language = 'Spanish'");
                foreach (DataRow drVideo in AllEnglishVideos)
                {
                    MobileAppVideo video = new MobileAppVideo();
                    video.VideoID = drVideo["VideoID"].ToString();
                    video.VideoURL = drVideo["VideoLink"].ToString();
                    video.VideoName = drVideo["VideoName"].ToString();
                    HomeLocation.EnglishVideos.Add(video);
                }
                foreach (DataRow drVideo in AllSpanishVideos)
                {
                    MobileAppVideo video = new MobileAppVideo();
                    video.VideoID = drVideo["VideoID"].ToString();
                    video.VideoURL = drVideo["VideoLink"].ToString();
                    video.VideoName = drVideo["VideoName"].ToString();
                    HomeLocation.SpnaishVideos.Add(video);
                }

                lstMobileAppLocations.Insert(0, HomeLocation);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                GetVideos();
                if (!IsPostBack)
                {
                    ddlIncludeFlipVideos_SelectedIndexChanged(null, null);
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    DictDepartment = sd.getDepartmentDetails();
                    LoadMobileAppLocationDropDown();
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    if (Convert.ToString(Session["Summary"]) == "MobileAppRequestForm")
                    {
                        TitleSpan.InnerText = "Mobile App Request Form";
                        //ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>ReplaceAuditReportToClientIntake()</script>", false);
                        mvClientContact.ActiveViewIndex = 0;
                        trCreateButton.Style.Add("display", "none");
                        trNextButton.Style.Add("display", "next");
                        SpanClientIntake.Visible = true;
                        SpanAccountProfile.Visible = false;
                        SpanClientIntakeComplaince.Visible = false;
                        hdnSummary.Value = "MobileAppRequestForm";
                        Activity_Group = "Tools";
                        //Activity_Group = "Pilot";
                        ddlIncludeBrainShark_SelectedIndexChanged(null, null);
                    }

                    txtsearch.Focus();
                    //Activity = lblHeading.Text;
                    ////Activity = TitleSpan.InnerText;
                    Activity = "Client Mobile App Request";
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void LoadMobileAppLocationDropDown()
        {
            for (int i = 1; i <= 12; i++)
            {
                string id = "ddlAppMobileLocation_" + i;
                DropDownList ddlAppMobileLocation = Page.FindControl(id) as DropDownList;
                if (ddlAppMobileLocation != null)
                {
                    ddlAppMobileLocation.DataTextField = "MobileAppLocationName";
                    ddlAppMobileLocation.DataValueField = "MobileAppLocationName";
                    ddlAppMobileLocation.AppendDataBoundItems = true;
                    ddlAppMobileLocation.SelectedValue = "0";
                    ddlAppMobileLocation.DataSource = lstMobileAppLocations;
                    ddlAppMobileLocation.DataBind();
                }
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                //ddlActivity.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                pnlPlans.Visible = false;
                // rdlActivity.SelectedIndex = 0;
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                cblistAccountContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            //ddlActivity.SelectedIndex = 0;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //ddlActivity.Items.Clear();
                // rdlActivity.SelectedIndex = 0;

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;

                cblistAccountContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlActivity.Items.Clear();
            pnlPlans.Visible = false;
            if (Convert.ToString(Session["Summary"]) == "Tools1")
            {
                // GetActivity_List(rdlActivity.SelectedItem.Text, tc.Tools1_SubjectID);
            }
            else if (Convert.ToString(Session["Summary"]) == "MobileAppRequestForm")
            {
                lblMessage.Visible = false;
                cblistAccountContact.Items.Clear();

                ddlIncludeBrainShark.SelectedIndex = 0;
                ddlIncludeBrainShark_SelectedIndexChanged(null, null);

                ddlIncludeDocuments.SelectedIndex = 0;

                ddlIncludeFlipVideos.SelectedIndex = 0;
                ddlIncludeFlipVideos_SelectedIndexChanged(null, null);
                ddlVideoCount.SelectedIndex = 0;

                SessionId = Session["SessionId"].ToString();
                List<Contact> acctContact = new List<Contact>();
                List<Contact> ContactList = new List<Contact>();
                Contact cont = new Contact();
                if (ddlClient.SelectedValue != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                }

                ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
                if (ContactList != null)
                {
                    for (int i = 0; i < ContactList.Count; i++)
                    {
                        cont = new Contact();
                        cont.ContactId = ContactList[i].ContactId;

                        if (!string.IsNullOrEmpty(ContactList[i].Title))
                        {
                            cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                        }
                        else
                        {
                            cont.Name = ContactList[i].Name;
                        }

                        acctContact.Add(cont);
                    }
                }

                lblAccountContact.Visible = true;
                pnlChkAccountContact.Visible = true;
                if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                {
                    divgrdSelectedAccountContact.Visible = true;
                }
                else
                {
                    divgrdSelectedAccountContact.Visible = false;

                }
                if (acctContact.Count > 0)
                {
                    cblistAccountContact.DataSource = acctContact;
                    cblistAccountContact.DataBind();
                    pnlChkAccountContact.Height = 130;
                }
                else
                {
                    lblMessage.Visible = true;
                    pnlChkAccountContact.Height = 50;
                }
            }

        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                SessionId = Session["SessionId"].ToString();
                bool IsSuccess = true;
                DataTable PlanInfoTable = new DataTable();
                if (Convert.ToString(Session["Summary"]) == "MobileAppRequestForm")
                {
                    if (!IsMobileAppLocationSelected())
                    {
                        IsSuccess = false;
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select mobile app location')</script>");
                        return;
                    }
                    if (!IsMobileAppLocationVideosSelected())
                    {
                        IsSuccess = false;
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select flip video name for mobile app location')</script>");
                        return;
                    }

                    if (IsDuplicateMobileAppVideoSelected())
                    {
                        IsSuccess = false;
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Flip video selected more than once')</script>");
                        return;
                    }

                }

                if (IsSuccess == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    string mynewfile = "";

                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();

                    sd.BuildProductTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


                    //string Office_Region = Account_Region;
                    /**** HERE WE ADD REGION AS PER CLIENT REQUEST - 22 AUG 2017 ****/
                    string Office_Region = Account_Region + " / " + Account_Office;
                    //code used for contract review and benchmark audit report
                    PlanInfoTable = GetPlanInfoTable();

                    DataTable PlanTable = new DataTable();
                    PlanTable.Merge(PlanInfoTable);

                    //code used for selected primary contact
                    #region selected primary contact

                    DataTable dtNewAcctContactList = new DataTable();
                    dtNewAcctContactList.Columns.Add("Name", typeof(string));
                    dtNewAcctContactList.Columns.Add("ID", typeof(string));
                    dtNewAcctContactList.Columns.Add("PrimaryContact", typeof(string));
                    string ID = string.Empty;
                    string Name = string.Empty;
                    string primary = string.Empty;



                    for (int i = 0; i < ddlSelectedAccountContact.Items.Count; i++)
                    {
                        if (ddlSelectedAccountContact.Items[i].Selected == true)
                        {
                            primary = "1";

                        }
                        else
                        {
                            primary = "2";
                        }
                        Name = ddlSelectedAccountContact.Items[i].Text;
                        ID = ddlSelectedAccountContact.Items[i].Value;
                        dtNewAcctContactList.Rows.Add(Name, ID, primary);
                    }

                    #endregion

                    if (Convert.ToString(Session["Summary"]) == "MobileAppRequestForm")
                    {
                        mynewfile = CreatePilot_MobileAppRequestForm_V2(PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId, PlanTable, Office_Region);

                    }
                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected string CreatePilot_MobileAppRequestForm(DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, DataTable PlanTable, string Office_Region)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/MobileAppRequestFormTemplate.docm");

            Object readOnly = true;
            Object isVisible = false;
            //TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                WritePilot1_MobileAppRequestForm wt = new WritePilot1_MobileAppRequestForm();

                ArrayList arrAcctContact = new ArrayList();

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }

                wt.WriteFieldToPilot1_MobileAppRequestForm(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, PlanTable, Office_Region);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreatePilot_MobileAppRequestForm_V2(DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, DataTable PlanTable, string Office_Region)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/MobileAppRequestForm_v2.docm");

            Object readOnly = true;
            Object isVisible = false;
            //TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                WritePilot1_MobileAppRequestForm wt = new WritePilot1_MobileAppRequestForm();

                ArrayList arrAcctContact = new ArrayList();

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }

                wt.Write_RequestDetails_VideoAttachment_DetailsToMobileApp_V2(oWordDoc, oWordApp, ddlClient, AccountDS, AccountTeamMemberDS, Office_Region, ddlIncludeBrainShark.SelectedValue, txtBrainsharkName.Text, txtBrainsharkLink.Text, ddlIncludeDocuments.SelectedValue);
                DataTable dtblVideos = GetSelectedVideos();
                wt.Write_SelectedVideos_V2(oWordDoc, oWordApp, dtblVideos);
                wt.Write_ClientProfileDetails_V2(oWordDoc, oWordApp, PlanInfoTable, PlanTable);
                wt.Write_ResourceDetails_V2(oWordDoc, oWordApp, ContactList, arrAcctContact);
                wt.Write_PlansProductDetails_V2(oWordDoc, oWordApp, PlanInfoTable, PlanTable);
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlIncludeBrainShark.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlIncludeDocuments.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlIncludeFlipVideos.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        private DataTable GetSelectedVideos()
        {
            DataTable dtblVideos = new DataTable();
            dtblVideos.Columns.Add(new DataColumn("VideoName"));
            dtblVideos.Columns.Add(new DataColumn("VideoLocationName"));
            dtblVideos.Columns.Add(new DataColumn("Language"));
            dtblVideos.Columns.Add(new DataColumn("URL"));

            for (int i = 1; i <= int.Parse(ddlVideoCount.SelectedValue); i++)
            {
                string ddlAppMobileLocationID = "ddlAppMobileLocation_" + i.ToString();
                string ddlAppVideoID = "ddlAppVideo_" + i.ToString();

                DropDownList ddlAppMobileLocation = this.FindControl(ddlAppMobileLocationID) as DropDownList;
                DropDownList ddlAppVideo = this.FindControl(ddlAppVideoID) as DropDownList;

                if (ddlAppMobileLocation != null && ddlAppVideo != null)
                {
                    MobileAppLocationItem LocationItem = lstMobileAppLocations.Where(r => r.MobileAppLocationName == ddlAppMobileLocation.SelectedValue).FirstOrDefault();

                    if (LocationItem != null)
                    {
                        MobileAppVideo EnglishVideo = LocationItem.EnglishVideos.Where(r => r.VideoName == ddlAppVideo.SelectedValue).FirstOrDefault();
                        MobileAppVideo SpanishVideo = LocationItem.SpnaishVideos.Where(r => r.VideoName == ddlAppVideo.SelectedValue).FirstOrDefault();
                        switch (ddlLanguage.SelectedValue)
                        {
                            case "Both":
                                if (EnglishVideo != null)
                                {
                                    DataRow drEn = dtblVideos.NewRow();
                                    drEn["VideoName"] = EnglishVideo.VideoName.Contains("(English Only)") ? EnglishVideo.VideoName.Replace("(English Only)", "") : EnglishVideo.VideoName;
                                    drEn["VideoLocationName"] = LocationItem.MobileAppLocationName;
                                    drEn["Language"] = "English";
                                    drEn["URL"] = EnglishVideo.VideoURL;
                                    dtblVideos.Rows.Add(drEn);
                                }

                                if (SpanishVideo != null)
                                {
                                    DataRow drsp = dtblVideos.NewRow();
                                    drsp["VideoName"] = SpanishVideo.VideoName;
                                    drsp["VideoLocationName"] = LocationItem.MobileAppLocationName;
                                    drsp["Language"] = "Spanish";
                                    drsp["URL"] = SpanishVideo.VideoURL;
                                    dtblVideos.Rows.Add(drsp);
                                }
                                break;
                            case "English":
                                if (EnglishVideo != null)
                                {
                                    DataRow drEn = dtblVideos.NewRow();
                                    drEn["VideoName"] = EnglishVideo.VideoName.Contains("(English Only)") ? EnglishVideo.VideoName.Replace("(English Only)", "") : EnglishVideo.VideoName;
                                    drEn["VideoLocationName"] = LocationItem.MobileAppLocationName;
                                    drEn["Language"] = "English";
                                    drEn["URL"] = EnglishVideo.VideoURL;
                                    dtblVideos.Rows.Add(drEn);
                                }
                                break;
                            case "Spanish":
                                if (SpanishVideo != null)
                                {
                                    DataRow drsp = dtblVideos.NewRow();
                                    drsp["VideoName"] = SpanishVideo.VideoName;
                                    drsp["VideoLocationName"] = LocationItem.MobileAppLocationName;
                                    drsp["Language"] = "Spanish";
                                    drsp["URL"] = SpanishVideo.VideoURL;
                                    dtblVideos.Rows.Add(drsp);
                                }
                                break;
                        }
                    }
                }

            }
            return dtblVideos;
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                Hashtable htSortedPlanList = new Hashtable();
                Hashtable hsTblFilterPlan = new Hashtable();

                if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                {
                    htSortedPlanList = ClientIntake_planList();
                }


                if (flag == true)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                            PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        //PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        else
                            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    /* ----- This Code added by Amogh On 31 Oct 2017 to add List of Plan provided by Nicole --- */
                    hsTblFilterPlan = valideFilterPlanList();


                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "Tools1")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                else if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent && hsTblFilterPlan.ContainsValue(item.ProductTypeId)) // here we check Item exist in FilterPlanList provide by Nicole
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    if (hsTblFilterPlan.ContainsValue(item.ProductTypeId)) // here we check Item exist in FilterPlanList provide by Nicole
                                        commonPlanList.Add(item);
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlans.Visible = true;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        private Hashtable ClientIntake_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            //htSortedPlanList.Add(15, 260);   // Voluntary Life
            //htSortedPlanList.Add(16, 270);   // AD&D
            //htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125


            htSortedPlanList.Add(21, 130);   // Medical
            //htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }

        /// <summary>
        /// //Created by Amogh 
        /// //Date : 31 Oct 2017
        /// This Function return the all Plan list which need to display on criteria page on Mobile App as per Nicole
        /// </summary>
        /// <returns></returns>
        public Hashtable valideFilterPlanList()
        {
            Hashtable validePlanList = new Hashtable();
            try
            {
                validePlanList.Add(0, 340);
                validePlanList.Add(1, 5500);
                validePlanList.Add(2, 270);
                validePlanList.Add(3, 320);
                validePlanList.Add(4, 5460);
                validePlanList.Add(5, 210);
                validePlanList.Add(6, 190);
                validePlanList.Add(7, 200);
                validePlanList.Add(8, 310);
                validePlanList.Add(9, 250);
                validePlanList.Add(10, 178);
                validePlanList.Add(11, 179);
                validePlanList.Add(12, 5060);
                validePlanList.Add(13, 3090);
                validePlanList.Add(14, 1114);
                validePlanList.Add(15, 1150);
                validePlanList.Add(16, 240);
                // validePlanList.Add(17, 233); Removed - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(18, 1115);
                validePlanList.Add(19, 300);
                validePlanList.Add(20, 180);
                validePlanList.Add(21, 150);
                validePlanList.Add(22, 160);
                validePlanList.Add(23, 100);
                validePlanList.Add(24, 170);
                // validePlanList.Add(25, 1116);Removed - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(26, 130);
                validePlanList.Add(27, 140);
                validePlanList.Add(28, 110);
                validePlanList.Add(29, 120);
                validePlanList.Add(30, 5340);
                validePlanList.Add(31, 1790);
                validePlanList.Add(32, 173);
                validePlanList.Add(33, 330);
                validePlanList.Add(34, 290);
                validePlanList.Add(35, 1230);
                validePlanList.Add(37, 1720);
                validePlanList.Add(38, 230);
                validePlanList.Add(39, 280);
                validePlanList.Add(40, 1400);
                validePlanList.Add(41, 1160);
                validePlanList.Add(42, 260);
                validePlanList.Add(43, 317);
                //validePlanList.Add(44, 1740);Removed - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(45, 1890);//Added - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(46, 5825);//Added - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(47, 1480);//Added - New Development Request - Mobile App Form v2 requested by Nicole
                validePlanList.Add(48, 294);//Added - New Development Request - Mobile App Form v2 requested by Nicole

                return validePlanList;
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return validePlanList;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();


            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true)
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        private DataTable GetPlanInfoTable_PHM()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();


            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        //protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        if (e.Row.RowIndex == 0)
        //            e.Row.Style.Add("width", "8px");
        //    }
        //}

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        protected void cblistAccountContact_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dtAcctContactList = new DataTable();
                dtAcctContactList.Columns.Add("Name", typeof(string));
                dtAcctContactList.Columns.Add("ID", typeof(string));
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        dtAcctContactList.Rows.Add(cblistAccountContact.Items[i].Text, cblistAccountContact.Items[i].Value);
                    }
                }
                grdSelectedAccountContact.DataSource = dtAcctContactList;
                grdSelectedAccountContact.DataBind();

                ddlSelectedAccountContact.DataSource = dtAcctContactList;
                ddlSelectedAccountContact.DataBind();

            }

            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            bool IsSuccess = true;
            Session["PlanTable"] = null;
            SessionId = Session["SessionId"].ToString();
            DataTable PlanInfoTable = new DataTable();
            DataTable PlanTable = new DataTable();
            if (Convert.ToString(Session["Summary"]) == "MobileAppRequestForm")
            {
                PlanInfoTable = GetPlanInfoTable();
                if (PlanInfoTable.Rows.Count <= 0)
                {
                    IsSuccess = false;
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Plan(s).')</script>");
                    return;
                }
            }

            if (IsSuccess)
            {
                if (mvClientContact.ActiveViewIndex == 0)
                {
                    PlanTable.Merge(PlanInfoTable);
                    Session["PlanTable"] = PlanTable;
                    mvClientContact.ActiveViewIndex = 1;
                    trCreateButton.Style.Add("display", "");
                    trNextButton.Style.Add("display", "none");

                    //ddlIncludeBrainShark.SelectedIndex = 0;
                    //ddlIncludeBrainShark_SelectedIndexChanged(null, null);

                    //ddlIncludeDocuments.SelectedIndex = 0;

                    //ddlIncludeFlipVideos.SelectedIndex = 0;
                    //ddlIncludeFlipVideos_SelectedIndexChanged(null, null);
                    //ddlVideoCount.SelectedIndex = 0;

                    TitleSpan.InnerText = "Document & Video Attachments";
                }
            }

        }

        protected void ddlIncludeBrainShark_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtBrainsharkName.Text = "";
            txtBrainsharkLink.Text = "";
            switch (ddlIncludeBrainShark.SelectedValue.ToLower())
            {
                case "yes":
                    trBrainsharkNameLink.Style.Add("display", "");
                    txtBrainsharkName.Focus();
                    break;
                case "no":
                    trBrainsharkNameLink.Style.Add("display", "none");
                    break;
                default:
                    trBrainsharkNameLink.Style.Add("display", "none");
                    break;
            }
        }

        protected void ddlLocations_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlLocation = sender as DropDownList;
            string ControlID = ddlLocation.ID;
            string[] ControlIDParts = ControlID.Split('_');
            int rowIndex = int.Parse(ControlIDParts[1]);
            string videoDropDownID = "ddlAppVideo_" + rowIndex.ToString();
            DropDownList ddlAppVideo = this.FindControl(videoDropDownID) as DropDownList;
            if (ddlAppVideo != null)
            {
                ddlAppVideo.Items.Clear();
                MobileAppLocationItem selectedLocation = lstMobileAppLocations.Where(r => r.MobileAppLocationName == ddlLocation.SelectedValue).FirstOrDefault();
                BindLocationVideos(ddlAppVideo, selectedLocation);
            }
        }

        protected void ddlVideoCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            int RowCount = int.Parse(ddlVideoCount.SelectedValue);
            for (int i = 1; i <= 12; i++)
            {
                Control rowControl = this.FindControl("trVideo_" + i.ToString());
                if (rowControl != null)
                {
                    if (i <= RowCount)
                        rowControl.Visible = true;
                    else
                        rowControl.Visible = false;
                }
            }
        }

        private bool IsDuplicateMobileAppVideoSelected()
        {
            string ddlAppVideoID = "ddlAppVideo_";

            bool IsDuplicate = false;
            for (int i = 1; i <= int.Parse(ddlVideoCount.SelectedValue); i++)
            {
                string ID1 = ddlAppVideoID + i.ToString();
                DropDownList ddlLocationVideoToCheck = this.FindControl(ID1) as DropDownList;
                string Value1 = ddlLocationVideoToCheck.SelectedValue;
                for (int j = i + 1; j <= int.Parse(ddlVideoCount.SelectedValue); j++)
                {
                    string ID2 = ddlAppVideoID + j.ToString();
                    DropDownList ddlLocationVideosToCompare = this.FindControl(ID2) as DropDownList;
                    string Value2 = ddlLocationVideosToCompare.SelectedValue;
                    if (Value1 == Value2)
                    {
                        IsDuplicate = true;
                        break;
                    }
                }
                if (IsDuplicate)
                {
                    ddlLocationVideoToCheck.Focus();
                    break;
                }
            }
            return IsDuplicate;
        }

        private bool IsMobileAppLocationSelected()
        {
            string ddlAppVideoID = "ddlAppMobileLocation_";
            bool IsSuccess = true;
            for (int i = 1; i <= int.Parse(ddlVideoCount.SelectedValue); i++)
            {
                string ID1 = ddlAppVideoID + i.ToString();
                DropDownList ddlLocationVideoToCheck = this.FindControl(ID1) as DropDownList;
                if (ddlLocationVideoToCheck.SelectedValue == "0")
                {
                    IsSuccess = false;
                }
            }
            return IsSuccess;
        }
        private bool IsMobileAppLocationVideosSelected()
        {
            string ddlAppVideoID = "ddlAppVideo_";
            bool IsSuccess = true;
            for (int i = 1; i <= int.Parse(ddlVideoCount.SelectedValue); i++)
            {
                string ID1 = ddlAppVideoID + i.ToString();
                DropDownList ddlLocationVideoToCheck = this.FindControl(ID1) as DropDownList;
                if (ddlLocationVideoToCheck.SelectedValue == "0")
                {
                    IsSuccess = false;
                }
            }
            return IsSuccess;
        }

        private void ClearVideoDropDown()
        {
            string ddlAppVideoID = "ddlAppVideo_";
            string ddlAppVideoLocationID = "ddlAppMobileLocation_";
            for (int i = 1; i <= 12; i++)
            {
                string ID1 = ddlAppVideoID + i.ToString();
                DropDownList ddlLocationVideoToCheck = this.FindControl(ID1) as DropDownList;
                string ID2 = ddlAppVideoLocationID + i.ToString();
                DropDownList ddlLocationVideoLocationToCheck = this.FindControl(ID2) as DropDownList;

                if (ddlLocationVideoLocationToCheck != null)
                {
                    ddlLocationVideoLocationToCheck.SelectedIndex = 0;
                }

                if (ddlLocationVideoToCheck != null)
                {
                    ddlLocationVideoToCheck.Items.Clear();
                    ddlLocationVideoToCheck.Items.Insert(0, new ListItem("Select", "0"));
                }


            }
        }

        public void BindLocationVideos(DropDownList ddlAppVideo, MobileAppLocationItem Location)
        {
            ddlAppVideo.DataTextField = "VideoName";
            ddlAppVideo.DataValueField = "VideoName";
            if (Location == null)
            {
                ddlAppVideo.Items.Insert(0, new ListItem("Select", "0"));
                return;
            }

            if (ddlLanguage.SelectedValue == "English")
            {
                ddlAppVideo.DataSource = Location.EnglishVideos.OrderBy(r => r.VideoName);
            }
            if (ddlLanguage.SelectedValue == "Spanish")
            {
                ddlAppVideo.DataSource = Location.SpnaishVideos.OrderBy(r => r.VideoName);
            }
            else if (ddlLanguage.SelectedValue == "Select")
            {
                ddlAppVideo.DataSource = null;
            }
            else if (ddlLanguage.SelectedValue == "Both")
            {
                ddlAppVideo.DataSource = Location.EnglishVideos.OrderBy(r => r.VideoName);
            }
            ddlAppVideo.DataBind();
            ddlAppVideo.Items.Insert(0, new ListItem("Select", "0"));
        }

        protected void ddlIncludeFlipVideos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlIncludeFlipVideos.SelectedValue == "Yes")
            {
                trFlipVideoSection1.Visible = true;
                trFlipVideoSection2.Visible = true;
                FlipVideoSection3.Visible = true;
            }
            else
            {
                ddlLanguage.SelectedIndex = 0;
                ddlVideoCount.SelectedIndex = 0;
                ddlVideoCount_SelectedIndexChanged(null, null);
                ClearVideoDropDown();
                trFlipVideoSection1.Visible = false;
                trFlipVideoSection2.Visible = false;
                FlipVideoSection3.Visible = false;

            }

        }

        protected void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int rowIndex = 1; rowIndex <= 12; rowIndex++)
            {
                string videoDropDownID = "ddlAppVideo_" + rowIndex.ToString();
                DropDownList ddlAppVideo = this.FindControl(videoDropDownID) as DropDownList;
                ddlAppVideo.Items.Clear();
                string videoLocationsID = "ddlAppMobileLocation_" + rowIndex.ToString();
                DropDownList ddlVideoLocation = this.FindControl(videoLocationsID) as DropDownList;
                MobileAppLocationItem selectedLocation = lstMobileAppLocations.Where(r => r.MobileAppLocationName == ddlVideoLocation.SelectedValue).FirstOrDefault();
                BindLocationVideos(ddlAppVideo, selectedLocation);
            }
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            if (mvClientContact.ActiveViewIndex == 1)
            {
                mvClientContact.ActiveViewIndex = 0;
                trCreateButton.Style.Add("display", "none");
                trNextButton.Style.Add("display", "");
                TitleSpan.InnerText = "Mobile App Request Form";
            }
        }
    }
}