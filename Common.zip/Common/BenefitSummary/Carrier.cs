﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Carrier
    {
        #region Variable
        private int _carrierId;
        private string _carrierName;
        # endregion

        #region Properties
        /// <summary>
        /// Get and Set CarrierId
        /// </summary>
        public int CarrierId
        {
            get
            {
                return _carrierId;
            }
            set
            {
                _carrierId = value;
            }
        }
        /// <summary>
        /// Get and Set CarrierName
        /// </summary>
        public string CarrierName
        {
            get
            {
                return _carrierName;

            }
            set
            {
                _carrierName = value;
            }
        }
        # endregion
    }
}