﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;

using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;



using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;

namespace BenefitPointSummaryPortal.View
{

    public partial class AnalyticsCoverPage : System.Web.UI.Page
    {
        int MaxRows = 14;
        BPBusiness bp = new BPBusiness();
        static string Activity = "";
        static string Activity_Group = "";

        CommonFunctionsBS objCommFun = new CommonFunctionsBS();

        protected void Page_Load(object sender, EventArgs e)
        {
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            if (!Page.IsPostBack)
            {
                Activity = "Table of Contents & Section Dividers";
                Activity_Group = "Analytics";
                CreateAnalyticsDataTable();
                BindGrid();
            }
        }

        private void CreateAnalyticsDataTable()
        {
            DataTable dtAnalyticsPageData = new DataTable();
            dtAnalyticsPageData.Columns.Add(new DataColumn("Section"));
            dtAnalyticsPageData.Columns.Add(new DataColumn("SelectedVersion"));
            dtAnalyticsPageData.Columns.Add(new DataColumn("Order"));
            dtAnalyticsPageData.Columns.Add(new DataColumn("AvailableVersions"));


            DataRow drSummaries = dtAnalyticsPageData.NewRow();
            drSummaries["Section"] = "Summaries";
            drSummaries["SelectedVersion"] = "Version 1";
            drSummaries["Order"] = "0";
            drSummaries["AvailableVersions"] = "Version 1,Version 2,Version 3";

            DataRow drMedical = dtAnalyticsPageData.NewRow();
            drMedical["Section"] = "Medical Plan";
            drMedical["SelectedVersion"] = "Version 1";
            drMedical["Order"] = "0";
            drMedical["AvailableVersions"] = "Version 1,Version 2";

            DataRow drDental = dtAnalyticsPageData.NewRow();
            drDental["Section"] = "Dental Plan";
            drDental["SelectedVersion"] = "Version 1";
            drDental["Order"] = "0";
            drDental["AvailableVersions"] = "Version 1,Version 2";

            DataRow drVision = dtAnalyticsPageData.NewRow();
            drVision["Section"] = "Vision Plan";
            drVision["SelectedVersion"] = "Version 1";
            drVision["Order"] = "0";
            drVision["AvailableVersions"] = "Version 1,Version 2";

            DataRow drDentalAndVision = dtAnalyticsPageData.NewRow();
            drDentalAndVision["Section"] = "Dental & Vision Plans";
            drDentalAndVision["SelectedVersion"] = "Include";
            drDentalAndVision["Order"] = "0";
            drDentalAndVision["AvailableVersions"] = "Include";


            DataRow drLifeAndDisability = dtAnalyticsPageData.NewRow();
            drLifeAndDisability["Section"] = "Life & Disability";
            drLifeAndDisability["SelectedVersion"] = "Include";
            drLifeAndDisability["Order"] = "0";
            drLifeAndDisability["AvailableVersions"] = "Include";

            DataRow drAccount = dtAnalyticsPageData.NewRow();
            drAccount["Section"] = "Account Administration";
            drAccount["SelectedVersion"] = "Version 1";
            drAccount["Order"] = "0";
            drAccount["AvailableVersions"] = "Version 1,Version 2";


            DataRow drMedicalExperience = dtAnalyticsPageData.NewRow();
            drMedicalExperience["Section"] = "Medical Experience";
            drMedicalExperience["SelectedVersion"] = "Version 1";
            drMedicalExperience["Order"] = "0";
            drMedicalExperience["AvailableVersions"] = "Version 1,Version 2";

            DataRow drDentalExperience = dtAnalyticsPageData.NewRow();
            drDentalExperience["Section"] = "Dental Experience";
            drDentalExperience["SelectedVersion"] = "Version 1";
            drDentalExperience["Order"] = "0";
            drDentalExperience["AvailableVersions"] = "Version 1,Version 2";

            DataRow drCompliance = dtAnalyticsPageData.NewRow();
            drCompliance["Section"] = "Compliance";
            drCompliance["SelectedVersion"] = "Include";
            drCompliance["Order"] = "0";
            drCompliance["AvailableVersions"] = "Include";



            DataRow drVerisk = dtAnalyticsPageData.NewRow();
            drVerisk["Section"] = "USI 3D";
            drVerisk["SelectedVersion"] = "Include";
            drVerisk["Order"] = "0";
            drVerisk["AvailableVersions"] = "Include";

            DataRow drBenefit = dtAnalyticsPageData.NewRow();
            drBenefit["Section"] = "Benefit Resource Center Report";
            drBenefit["SelectedVersion"] = "Include";
            drBenefit["Order"] = "0";
            drBenefit["AvailableVersions"] = "Include";


            DataRow drRenewalTime = dtAnalyticsPageData.NewRow();
            drRenewalTime["Section"] = "Renewal Timeline";
            drRenewalTime["SelectedVersion"] = "Include";
            drRenewalTime["Order"] = "0";
            drRenewalTime["AvailableVersions"] = "Include";


            DataRow drRates = dtAnalyticsPageData.NewRow();
            drRates["Section"] = "Current Rates & Benefits";
            drRates["SelectedVersion"] = "Version 1";
            drRates["Order"] = "0";
            drRates["AvailableVersions"] = "Version 1,Version 2";



            dtAnalyticsPageData.Rows.Add(drSummaries);
            dtAnalyticsPageData.Rows.Add(drMedical);
            dtAnalyticsPageData.Rows.Add(drDental);
            dtAnalyticsPageData.Rows.Add(drVision);
            dtAnalyticsPageData.Rows.Add(drDentalAndVision);
            dtAnalyticsPageData.Rows.Add(drLifeAndDisability);
            dtAnalyticsPageData.Rows.Add(drAccount);
            dtAnalyticsPageData.Rows.Add(drMedicalExperience);
            dtAnalyticsPageData.Rows.Add(drDentalExperience);
            dtAnalyticsPageData.Rows.Add(drCompliance);
            dtAnalyticsPageData.Rows.Add(drVerisk);
            dtAnalyticsPageData.Rows.Add(drBenefit);
            dtAnalyticsPageData.Rows.Add(drRenewalTime);
            dtAnalyticsPageData.Rows.Add(drRates);



            Session["AnalyticsData"] = dtAnalyticsPageData;


        }

        protected DataTable BuildtSectionTable()
        {

            DataTable sectionTable = new DataTable();
            sectionTable.Columns.Add("Section", typeof(string));
            sectionTable.Columns.Add("Version", typeof(string));
            sectionTable.Columns.Add("Order", typeof(string));

            int rowcount = gvAnalyticsCoverPage.Rows.Count;
            int columncount = gvAnalyticsCoverPage.Columns.Count;

            for (int row = 0; row < rowcount; row++)
            {
                DataRow dtRow = sectionTable.NewRow();
                bool flag = false;
                for (int column = 0; column < columncount; column++)
                {
                    if (gvAnalyticsCoverPage.Rows[row].Cells[column].Controls.Count > 0)
                    {
                        if (column == 0)
                        {
                            Label label = gvAnalyticsCoverPage.Rows[row].Cells[column].FindControl("lblSection") as Label;
                            dtRow["Section"] = label.Text;
                        }
                        else if (column == 1)
                        {
                            DropDownList dropdownVersion = gvAnalyticsCoverPage.Rows[row].Cells[column].FindControl("ddlVersion") as DropDownList;
                            dtRow["Version"] = dropdownVersion.SelectedItem.Text;
                            if (dropdownVersion.SelectedIndex > 0)
                            {
                                flag = true;
                            }
                        }
                        else if (column == 2)
                        {
                            DropDownList dropdownOrder = gvAnalyticsCoverPage.Rows[row].Cells[column].FindControl("ddlOrder") as DropDownList;
                            dtRow["Order"] = dropdownOrder.SelectedItem.Text;
                        }
                    }
                }
                if (flag == true)
                {
                    sectionTable.Rows.Add(dtRow);
                }
            }


            return sectionTable;
        }

        #region Grid Realted Functions

        private void BindGrid()
        {
            DataTable dtAnalyticsPageData = Session["AnalyticsData"] as DataTable;
            gvAnalyticsCoverPage.DataSource = dtAnalyticsPageData;
            gvAnalyticsCoverPage.DataBind();
            EnableddlOrder();

        }

        protected void gvAnalyticsCoverPage_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataTable dtAnalyticsPageData = Session["AnalyticsData"] as DataTable;
            DropDownList ddlOrder = e.Row.FindControl("ddlOrder") as DropDownList;
            DropDownList ddlVersion = e.Row.FindControl("ddlVersion") as DropDownList;
            HiddenField hdnAvailableVersions = e.Row.FindControl("hdnAvailableVersions") as HiddenField;

            if (e.Row.RowIndex >= 0)
            {
                ddlOrder.SelectedValue = dtAnalyticsPageData.Rows[e.Row.RowIndex]["Order"].ToString();
                string AvailableVersions = dtAnalyticsPageData.Rows[e.Row.RowIndex]["AvailableVersions"].ToString();
                string SelectedVersion = dtAnalyticsPageData.Rows[e.Row.RowIndex]["SelectedVersion"].ToString();
                List<string> lstVersions = AvailableVersions.Split(',').ToList();
                ddlVersion.Items.Clear();
                ddlVersion.DataSource = lstVersions;
                ddlVersion.DataBind();

                ddlVersion.Items.Insert(0, new ListItem("Do Not Include", "Do Not Include"));
                ddlVersion.SelectedValue = SelectedVersion;
                ddlOrder.Enabled = false;
            }
        }

        protected void gvAnalyticsCoverPage_OrderChanged(object sender, EventArgs e)
        {
            DataTable dtAnalyticsPageData = Session["AnalyticsData"] as DataTable;
            DropDownList ddlOrder = sender as DropDownList;
            string[] IdParts = ddlOrder.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            int SelectedOrder = int.Parse(ddlOrder.SelectedValue);
            bool IsAlreadySelected = false;
            int PreviousOrder = int.Parse(dtAnalyticsPageData.Rows[RowIndex]["Order"].ToString());
            dtAnalyticsPageData.Rows[RowIndex]["Order"] = SelectedOrder;
            if (SelectedOrder > 0)
            {
                for (int DataRowIndex = 0; DataRowIndex < dtAnalyticsPageData.Rows.Count; DataRowIndex++)
                {
                    if (RowIndex != DataRowIndex)
                    {
                        if (int.Parse(dtAnalyticsPageData.Rows[DataRowIndex]["Order"].ToString()) == SelectedOrder)
                        {
                            IsAlreadySelected = true;
                            break;
                        }
                    }
                }
                if (IsAlreadySelected)
                {
                    for (int DataRowIndex = 0; DataRowIndex < dtAnalyticsPageData.Rows.Count; DataRowIndex++)
                    {
                        if (RowIndex != DataRowIndex)
                        {
                            if (int.Parse(dtAnalyticsPageData.Rows[DataRowIndex]["Order"].ToString()) >= SelectedOrder)
                            {
                                int NewOrder = int.Parse(dtAnalyticsPageData.Rows[DataRowIndex]["Order"].ToString());
                                NewOrder = NewOrder + 1;
                                if (NewOrder > MaxRows)
                                    NewOrder = 0;
                                dtAnalyticsPageData.Rows[DataRowIndex]["Order"] = NewOrder;
                            }
                        }
                    }
                }
            }
            else
            {
                if (PreviousOrder > 0)
                {
                    for (int DataRowIndex = 0; DataRowIndex < dtAnalyticsPageData.Rows.Count; DataRowIndex++)
                    {
                        if (RowIndex != DataRowIndex)
                        {
                            if (int.Parse(dtAnalyticsPageData.Rows[DataRowIndex]["Order"].ToString()) >= PreviousOrder)
                            {
                                int NewOrder = int.Parse(dtAnalyticsPageData.Rows[DataRowIndex]["Order"].ToString());
                                NewOrder = NewOrder - 1;
                                dtAnalyticsPageData.Rows[DataRowIndex]["Order"] = NewOrder;

                            }
                        }
                    }
                }
            }
            Session["AnalyticsData"] = dtAnalyticsPageData;
            BindGrid();
        }

        protected void gvAnalyticsCoverPage_VersionChanged(object sender, EventArgs e)
        {


            DataTable dtAnalyticsPageData = Session["AnalyticsData"] as DataTable;
            DropDownList ddlVersion = sender as DropDownList;
            string[] IdParts = ddlVersion.ClientID.Split('_');
            int RowIndex = int.Parse(IdParts[IdParts.Length - 1]);
            DropDownList ddlOrder = gvAnalyticsCoverPage.Rows[RowIndex].FindControl("ddlOrder") as DropDownList;



            dtAnalyticsPageData.Rows[RowIndex]["SelectedVersion"] = ddlVersion.SelectedValue;
            Session["AnalyticsData"] = dtAnalyticsPageData;
            if (ddlVersion.SelectedValue == "Do Not Include")
            {
                ddlOrder.SelectedValue = "0";
                gvAnalyticsCoverPage_OrderChanged(ddlOrder, null);
                dtAnalyticsPageData.Rows[RowIndex]["Order"] = "0";

            }

            BindGrid();

            //if (ddlVersion.SelectedValue != "Do Not Include")
            //{
            //    (gvAnalyticsCoverPage.Rows[RowIndex].FindControl("ddlOrder") as DropDownList).Enabled = true;
            //}
        }

        #endregion

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (ddlFormat.SelectedValue == "None")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation')</script>");
                ddlFormat.Focus();
                return;
            }
            DataTable SectionTable = BuildtSectionTable();
            if (SectionTable.Rows.Count == 0 && ddlAdditional.SelectedValue.ToString() == "0")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please include atleast 1 Image Option')</script>");
            }
            else
            {
                if (ddlFormat.SelectedIndex > 0)
                {
                    Create_AnalyticsCoverPages(SectionTable);

                    #region Activity Log

                    string version = "";
                    if (SectionTable.Rows.Count > 1)
                        version = SectionTable.Rows.Count + " Sections";
                    else
                        version = SectionTable.Rows.Count + " Section";
                    string AdditionalCrtieriaOption_1 = SectionTable.Rows.Count.ToString() + version;
                    string AdditionalCrtieriaOption_2 = "";
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "", "Analytics", "", "", "", "", "", ddlFormat.SelectedItem.Text, version, ddlAdditional.SelectedValue + " Additional", Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                }

            }

        }

        protected void Create_AnalyticsCoverPages(DataTable SectionTable)
        {
            int NoOfAdditionalTabs = 0;
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Workbook myWorkbookdest = null;
            Excel.Worksheet myWorksheet = null;

            try
            {
                // SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;
                //Analytics Cover Pages/Documents/Templates
                string myPath = "";
                //TOC Sections and Disclaimer_Portrait
                if (ddlFormat.SelectedValue == "Landscape")
                {
                    myPath = Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/TOC Sections and Disclaimer.xlsx");

                }
                else
                {
                    myPath = Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/TOC Sections and Disclaimer_Portrait.xlsx");
                }

                string myPathdest = Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/Analytics_Blank.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbookdest = myExcelApp.Workbooks.Open(myPath);
                myWorkbook = myExcelApp.Workbooks.Open(myPathdest);
                // myWorksheet = myWorkbook.ActiveSheet;
                myWorksheet = myWorkbookdest.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");
                //Table of Contents w Sections and Disclaimer (Land)1.xlsx
                if (!Directory.Exists(Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/Report1/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/AnalyticsCoverPages/Documents/Templates/Report1/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                NoOfAdditionalTabs = Convert.ToInt32(ddlAdditional.SelectedValue);
                WriteTemplateAnalyticsCoverPage wt = new WriteTemplateAnalyticsCoverPage();

                if (ddlFormat.SelectedValue == "Landscape")
                {
                    wt.WriteTemplate_AnalyticsCoverPage_Landscape(myExcelApp, myWorkbook, myWorkbookdest, myWorksheet, SectionTable, NoOfAdditionalTabs);
                }
                else
                {
                    wt.WriteTemplate_AnalyticsCoverPage_Portrait(myExcelApp, myWorkbook, myWorkbookdest, myWorksheet, SectionTable, NoOfAdditionalTabs);
                }


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myWorkbookdest.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;

                Marshal.FinalReleaseComObject(myWorkbookdest);
                myWorkbookdest = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                //if (myWorksheetdest != null)
                //{
                //    Marshal.FinalReleaseComObject(myWorksheetdest);
                //    myWorksheetdest = null;
                //}
                if (myWorkbookdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }


                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                //if (myWorksheetdest != null)
                //{
                //    Marshal.FinalReleaseComObject(myWorksheetdest);
                //    myWorksheetdest = null;
                //}
                if (myWorkbookdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        protected void EnableddlOrder()
        {
            int rowcount = gvAnalyticsCoverPage.Rows.Count;
            int columncount = gvAnalyticsCoverPage.Columns.Count;

            for (int row = 0; row < rowcount; row++)
            {

                bool flag = false;
                DropDownList ddlversion = gvAnalyticsCoverPage.Rows[row].Cells[1].FindControl("ddlVersion") as DropDownList;
                DropDownList ddlorder = gvAnalyticsCoverPage.Rows[row].Cells[2].FindControl("ddlOrder") as DropDownList;

                if (ddlversion.SelectedValue != "Do Not Include")
                {
                    ddlorder.Enabled = true;
                }

            }

        }

        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}