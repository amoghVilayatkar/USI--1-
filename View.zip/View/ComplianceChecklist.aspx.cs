﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;
using System.Globalization;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.BAL.Compliance;

namespace BenefitPointSummaryPortal.View
{
    public partial class ComplianceChecklist : System.Web.UI.Page
    {
        #region Global Variable
        DataSet AccountDS = new DataSet();
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string temperror = "cs";

        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        //PowerPoint.Presentations objPresSet;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        SummaryDetail sdd = new SummaryDetail();
        #endregion

        # region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                if (!IsPostBack)
                {
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    DictDepartment = sdd.getDepartmentDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();

                    if (Convert.ToString(Session["Summary"]) == "Template1")
                    {
                        //lblHeading.Text = "Quick Compliance Check-up";
                        TitleSpan.InnerText = "Compliance Checklist";
                        Activity_Group = "Compliance";
                        pnlDetailedCompliance.Visible = false;
                        trLegalName.Visible = false;
                        lblQuickCompliance.Visible = true;
                    }

                    //if (Convert.ToString(Session["Summary"]) == "Template2")
                    //{
                    //    //lblHeading.Text = "Detailed Compliance Checklist";
                    //    TitleSpan.InnerText = "Detailed Compliance Checklist";
                    //    Activity_Group = "Compliance";
                    //    pnlScreen1_BS_Text1.Visible = false;
                    //    pnlDetailedCompliance.Visible = true;
                    //    trLegalName.Visible = true;
                    //    lblQuickCompliance.Visible = false;
                    //    ///** Office Dropdown Enabled=False by Amogh*/
                    //    ddlOffice.Enabled = false;
                    //}

                    //Activity = lblHeading.Text;
                    ////Activity = TitleSpan.InnerText;
                    Activity = "Compliance Checklist";
                    txtsearch.Focus();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        BPBusiness bp = new BPBusiness();

        //        Clear();
        //        SessionId = Session["SessionId"].ToString();
        //        List<Contact> ContactList = new List<Contact>();
        //        if(ddlClient.SelectedValue != "")
        //        {
        //        ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
        //        }
        //        Session["Contact"] = ContactList;
        //        ddlHRContact.DataSource = ContactList;
        //        ddlHRContact.DataBind();
        //        ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
        //        ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));
        //    }
        //    catch (Exception ex)
        //    {
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                txtMeetingDate.Text = "";
                trMeetingDate.Visible = false;
                ddlChecklistOption.SelectedIndex = 0;
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                Clear();

                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }

                //ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                SummaryDetail sd = new SummaryDetail();
                SessionId = Session["SessionId"].ToString();
                DataTable PlanInfoTable = new DataTable();
                BPBusiness bp = new BPBusiness();
                CommonFunctionsCompliance commCompliance = new CommonFunctionsCompliance();
                bool flag = true;

                if (Convert.ToString(Session["Summary"]) == "Template1")
                {


                }
                //Added for PowerPoint Option
                if (Convert.ToString(Session["Summary"]) == "Template3")
                {
                    flag = IsValidDate(txtMeetingDate.Text.Trim());
                    if (txtMeetingDate.Text.Trim() == "")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter meeting date.')</script>");
                        txtMeetingDate.Focus();
                        return;
                    }
                    else if (flag == false)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Invalid Meeting Date. Date format should be MM/DD/YYYY')</script>");
                        txtMeetingDate.Focus();
                        return;
                    }
                }
                //Added for Plan Administration
                if (Convert.ToString(Session["Summary"]) == "Template4")
                {
                    // Plan Administration validation 
                }
                if (Convert.ToString(Session["Summary"]) == "Template2")
                {
                    PlanInfoTable = commCompliance.GetPlanInfoTable(grdPlans);
                    if (grdPlans.Rows.Count == 0)
                    {
                        //ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please click on 'View Plans' button and select plan(s) from plan listing Grid.')</script>", false);
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please click on View Plans button and select plan(s) from plan listing Grid.')</script>");
                        btnViewPlans.Focus();
                        flag = false;
                    }
                    else if (PlanInfoTable.Rows.Count == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select plan(s) from plan listing Grid.')</script>");
                        flag = false;
                    }
                    else if (trQuestion1.Visible == true && ddlQuestion1.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Is this client a MEWA?')</script>");
                        ddlQuestion1.Focus();
                        flag = false;
                    }
                    else if (trQuestion2.Visible == true && ddlQuestion2.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Does this client have a Federally Qualified HMO?')</script>");
                        ddlQuestion2.Focus();
                        flag = false;
                    }
                    else if (trQuestion3.Visible == true && ddlQuestion3.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : What is this clients Grandfathered status?')</script>");
                        ddlQuestion3.Focus();
                        flag = false;
                    }
                    //else if (trQuestion4.Visible == true && ddlQuestion4.SelectedIndex == 0)
                    //{
                    //    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Has this client filed over 250 W-2 forms?')</script>");
                    //    ddlQuestion4.Focus();
                    //    flag = false;
                    //}
                    else if (trQuestion5.Visible == true && ddlQuestion5.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Does this client offer Retiree Health plans?')</script>");
                        ddlQuestion5.Focus();
                        flag = false;
                    }
                    else if (trQuestion6.Visible == true && ddlQuestion6.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for :Is this client a Non Profit Religious organization?')</script>");
                        ddlQuestion6.Focus();
                        flag = false;
                    }
                    else if (trQuestion8.Visible == true && ddlQuestion8.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Does this client have any employees in: HI, MA, VT or the City/County of San Francisco,CA?')</script>");
                        ddlQuestion8.Focus();
                        flag = false;
                    }

                    else if (trQuestion9.Visible == true && ddlQuestion9.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for : Does this client have any employees in: California, Hawaii, New Jersey, New York,Rhode Island or Puerto Rico?')</script>");
                        ddlQuestion9.Focus();
                        flag = false;
                    }

                    else if (trQuestion10.Visible == true && ddlQuestion10.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for :  Are children age 26 or older allowed to participate in medical plans?')</script>");
                        ddlQuestion10.Focus();
                        flag = false;
                    }

                    else if (trQuestion11.Visible == true && ddlQuestion11.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select value for :Does this client offer a Wellness program?')</script>");
                        ddlQuestion11.Focus();
                        flag = false;
                    }

                }


                if (flag == true)
                {
                    string mynewfile = "";
                    List<Contact> ContactList = new List<Contact>();
                    DataSet AccountTeamMemberDS = new DataSet();
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

                    if (ddlClient.SelectedValue != "")
                    {
                       AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    if (Convert.ToString(Session["Summary"]) == "Template1")
                    {
                        ////mynewfile = CreateComplianceTemplate_1();
                        mynewfile = CreateComplianceTemplate_1(AccountTeamMemberDS, ContactList);
                    }
                    else if (Convert.ToString(Session["Summary"]) == "Template2")
                    {
                        PlanInfoTable = commCompliance.GetPlanInfoTable(grdPlans);
                        ////mynewfile = CreateTemplate_2_DetailedCompliance(PlanInfoTable, AccountDS, SessionId);
                        mynewfile = CreateTemplate_2_DetailedCompliance(PlanInfoTable, AccountDS, SessionId, AccountTeamMemberDS, ContactList);
                    }
                    else if (Convert.ToString(Session["Summary"]) == "Template3")
                    {
                        //Method to be PowerPoint Option
                        mynewfile = CreateComplianceChecklistPPT();
                    }
                    else if (Convert.ToString(Session["Summary"]) == "Template4")
                    {
                        //Method for Plan Adminstration
                        mynewfile = CreatePlanAdminstration();
                    }
                    if (mynewfile.Trim() != "")
                        DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                if (Convert.ToString(Session["Summary"]) == "Template2")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        flag = false;
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                    }
                }

                if (flag == true)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;
                    objCommFun.LoadPlanTypeIds();

                    List<int> plansProductTypeIds = new List<int>();

                    // Maintain the order as given below 
                    //•	Medical
                    //•	Dental
                    //•	Vision
                    //•	HSA
                    //•	HRA
                    //•	FSA
                    //•	Life and AD&D
                    //•	Voluntary Life/AD&D  (was Voluntary Life)
                    //•	Short Term Disability  (was STD)
                    //•	Long Term Disability  (was LTD)
                    //•	EAP
                    plansProductTypeIds.Clear();
                    plansProductTypeIds.AddRange(CommonFunctionsBS.MedicalPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.DentalPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.VisionPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.HSAPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.HRAPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.FSAPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.LifeADDPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.VoluntaryLifeADDPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.STDPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.LTDPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.EAPPlanTypeList);
                    plansProductTypeIds.AddRange(CommonFunctionsBS.WellnessPlanTypeList);
                    //plansProductTypeIds.AddRange(CommonFunctionsBS.AdditionalProductsPlanTypeList);

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                if (Convert.ToString(Session["Summary"]) == "Template2")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (plansProductTypeIds.Contains(item.ProductTypeId))
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (plansProductTypeIds.Contains(item.ProductTypeId))
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    if (plansProductTypeIds.Contains(item.ProductTypeId))
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            //lstPlanList = (from l in commonPlanList
                            //               orderby l.ProductTypeId, l.CarrierName ascending
                            //               select l).ToList();

                            foreach (int item in plansProductTypeIds)
                            {
                                foreach (var planItem in commonPlanList)
                                {
                                    if (planItem.ProductTypeId == item)
                                    {
                                        lstPlanList.Add(planItem);
                                    }
                                }
                            }

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        #endregion

        #region Function

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        /// <summary>
        /// Create Compliance Report
        /// </summary>
        protected string CreateComplianceTemplate_1(DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            //DataTable Office = (DataTable)Session["OffieceTable"];
            //List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;
            SummaryDetail sd = new SummaryDetail();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/Report1"));
                }
                string filename = "~/Files/Compliance/Documents/Templates/Compliance Checkup - updated Jan 18 2019.docm";
                string _savefilename = "~/Files/Compliance/Documents/Templates/Report1/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                //RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary7" });
                //temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                string AdditionalCrtieriaOption_1 = ddlChecklistOption.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = rdlPlan.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlQuestion1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlQuestion2.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Create DetailedC ompliance Report
        /// </summary>
        protected string CreateTemplate_2_DetailedCompliance(DataTable PlanInfoTable, DataSet AccountDS, string SessionId, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Object missing = System.Reflection.Missing.Value;
            SummaryDetail sd = new SummaryDetail();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/Report2"));
                }
                string filename = "~/Files/Compliance/Documents/Templates/Compliance 2_DetailedComplianceReport.docm";
                string _savefilename = "~/Files/Compliance/Documents/Templates/Report2/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);
                objCommFun.LoadPlanTypeIds();

                WriteTemplate2_DetailedCompliance wt = new WriteTemplate2_DetailedCompliance();

                // This function is used to insert all the selected topics and not to delete the paragraphs from the inserted topics
                wt.WriteFieldToTemplate2_DetailedCompliance(wobj.office.oWordDoc, wobj.office.oWordApp, ddlClient, AccountDS, PlanInfoTable, SessionId, ddlOffice, chkComplianceTopics);

                // Check for if any medical plan is selected or not
                bool isMedicalPlanSelected = false;
                bool isFTE_Greater_Or_Equal_To_100 = false;
                bool isFTE_Greater_Or_Equal_To_50 = false;
                bool isFTE_LT_50 = false;
                bool isFTE_Greater_Or_Equal_To_20 = false;
                bool isFTE_Less_Than_100 = false;
                bool isFSA_Plan_Selected = false;
                bool isHRA_Plan_Selected = false;
                bool isHSA_Plan_Selected = false;
                bool isSTD_Plan_Selected = false;
                bool isLTD_Plan_Selected = false;
                bool isAnySelectedPlan_FundingType_Self_Insured = false;
                bool isFundingType_Self_Insured = false;
                bool isFundingType_Fully_Insured = false;
                int FTE = 0;
                int OptionFieldValueiD = 0;
                if (PlanInfoTable != null)
                {
                    if (PlanInfoTable.Rows.Count > 0)
                    {
                        #region Topic 01 General ERISA Requirements conditions - Starts here
                        // Check if any of the medical plan is selected from the gridview
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.MedicalPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.MedicalPlanTypeList[j]))
                                {
                                    isMedicalPlanSelected = true;
                                    break;
                                }
                            }

                            if (isMedicalPlanSelected == true)
                            {
                                break;
                            }
                        }

                        // Check for if the Number of Eligible Employees is greater than or eqal to 100 (i.e. >= 100)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            FTE = sd.GetProductDetail_numberofeligibleemployee(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                            if (FTE >= 100)
                            {
                                isFTE_Greater_Or_Equal_To_100 = true;
                                break;
                            }
                        }

                        // Check for if the Number of Eligible Employees is less than 100 (i.e. < 100)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            FTE = sd.GetProductDetail_numberofeligibleemployee(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                            if (FTE < 100)
                            {
                                isFTE_Less_Than_100 = true;
                                break;
                            }
                        }
                        #endregion Topic 01 General ERISA Requirements conditions - Ends here

                        #region Topic 02 General COBRA Requirements conditions - Starts here
                        // Check if the FSA plan is selected (ProductTypeId = 330)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.FSAPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.FSAPlanTypeList[j]))
                                {
                                    isFSA_Plan_Selected = true;
                                    break;
                                }
                            }
                            if (isFSA_Plan_Selected == true)
                            {
                                break;
                            }
                        }

                        // Check if the HRA plan is selected (ProductTypeId = 178)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.HRAPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.HRAPlanTypeList[j]))
                                {
                                    isHRA_Plan_Selected = true;
                                    break;
                                }
                            }
                            if (isHRA_Plan_Selected == true)
                            {
                                break;
                            }
                        }

                        // Check for if the Funding type for selected medical plan is 'Self Insured'
                        //    case 52403: FundingType = "Self-Insured"; 
                        //    case 52401: FundingType = "Fully Insured"; 
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.MedicalPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.MedicalPlanTypeList[j]))
                                {
                                    OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                                    if (OptionFieldValueiD == ConstantValue.OptionFieldValue_SelfInsured)
                                    {
                                        isFundingType_Self_Insured = true;
                                        break;
                                    }
                                }
                            }
                            if (isFundingType_Self_Insured == true)
                            {
                                break;
                            }
                        }

                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.MedicalPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.MedicalPlanTypeList[j]))
                                {
                                    OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                                    if (OptionFieldValueiD == ConstantValue.OptionFieldValue_FullyInsured)
                                    {
                                        isFundingType_Fully_Insured = true;
                                        break;
                                    }
                                }
                            }
                            if (isFundingType_Fully_Insured == true)
                            {
                                break;
                            }
                        }
                        #endregion Topic 02 General COBRA Requirements conditions - Ends here

                        #region Topic 04 Other Group Health Plan Mandates conditions - Starts here
                        // Check for if the Number of Eligible Employees is less than 100 (i.e. >= 50)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            FTE = sd.GetProductDetail_numberofeligibleemployee(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                            if (FTE >= 50)
                            {
                                isFTE_Greater_Or_Equal_To_50 = true;
                            }
                            else
                            {
                                isFTE_LT_50 = true;
                            }
                        }

                        #endregion Topic 04 Other Group Health Plan Mandates conditions - Ends here

                        #region Topic 06 Federal Tax Code Requirements conditions - Starts here
                        // Check if the STD plan is selected (ProductTypeId = 290)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.STDPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.STDPlanTypeList[j]))
                                {
                                    isSTD_Plan_Selected = true;
                                    break;
                                }
                            }
                            if (isSTD_Plan_Selected == true)
                            {
                                break;
                            }
                        }

                        // Check if the LTD plan is selected (ProductTypeId = 300)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.LTDPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.LTDPlanTypeList[j]))
                                {
                                    isLTD_Plan_Selected = true;
                                    break;
                                }
                            }
                            if (isLTD_Plan_Selected == true)
                            {
                                break;
                            }
                        }
                        #endregion Topic 06 Federal Tax Code Requirements conditions - Ends here

                        #region Topic 07 Medicare Requrements conditions - Starts here
                        // Check for if the Number of Eligible Employees is less than 100 (i.e. >=20 100)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            FTE = sd.GetProductDetail_numberofeligibleemployee(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                            if (FTE >= 20)
                            {
                                isFTE_Greater_Or_Equal_To_20 = true;
                                break;
                            }
                        }

                        // Check if the HSA plan is selected (ProductTypeId = 179)
                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.HSAPlanTypeList.Count; j++)
                            {
                                if (Convert.ToInt32(PlanInfoTable.Rows[i]["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.HSAPlanTypeList[j]))
                                {
                                    isHSA_Plan_Selected = true;
                                    break;
                                }
                            }
                            if (isHSA_Plan_Selected == true)
                            {
                                break;
                            }
                        }
                        #endregion Topic 07 Medicare Requrements conditions - Ends here

                        for (int i = 0; i < PlanInfoTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < CommonFunctionsBS.MedicalPlanTypeList.Count; j++)
                            {
                                OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(PlanInfoTable.Rows[i]["ProductId"].ToString()), SessionId);
                                if (OptionFieldValueiD == ConstantValue.OptionFieldValue_SelfInsured)
                                {
                                    isAnySelectedPlan_FundingType_Self_Insured = true;
                                    break;
                                }
                            }
                            if (isAnySelectedPlan_FundingType_Self_Insured == true)
                            {
                                break;
                            }
                        }

                    }
                }

                wt.Delete_Or_Keep_Bookmarks(wobj.office.oWordApp, ddlQuestion1, ddlQuestion2, ddlQuestion3, ddlQuestion4, ddlQuestion5, ddlQuestion6, ddlQuestion8, ddlQuestion9, ddlQuestion10, ddlQuestion11, isMedicalPlanSelected, isFTE_Greater_Or_Equal_To_100, isFTE_Less_Than_100, isFSA_Plan_Selected, isHRA_Plan_Selected, isFundingType_Self_Insured, isFTE_Greater_Or_Equal_To_50, isFundingType_Fully_Insured, isFTE_Greater_Or_Equal_To_20, isHSA_Plan_Selected, isSTD_Plan_Selected, isLTD_Plan_Selected, isAnySelectedPlan_FundingType_Self_Insured, isFTE_LT_50);

                wt.ShowPageNumberOnContentPage_For_SelectedTopic(wobj.office.oWordApp, wobj.office.oWordDoc, chkComplianceTopics);

                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);


                string AdditionalCrtieriaOption_1 = ddlChecklistOption.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = rdlPlan.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlQuestion1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlQuestion2.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            //ddlHRContact.Items.Clear();
            //ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
            //ddlCoverPage.SelectedIndex = 0;
            //ddlAnnualLegalNotice.SelectedIndex = 0;
            //chkAnualNotice.SelectedIndex = -1;
            //trAnual.Visible = false;
            // ddlChipNotice.SelectedIndex = 0;

        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        protected void chkComplianceTopics_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                trQuestion1.Visible = false;
                trQuestion2.Visible = false;
                trQuestion3.Visible = false;
                trQuestion4.Visible = false;
                trQuestion5.Visible = false;
                trQuestion6.Visible = false;
                trQuestion8.Visible = false;
                trQuestion9.Visible = false;
                trQuestion10.Visible = false;
                trQuestion11.Visible = false;
                int cnt = 0;
                bool isQues5 = false;

                for (int i = 0; i < chkComplianceTopics.Items.Count - 1; i++)
                {
                    cnt = i;
                    if (chkComplianceTopics.Items[i].Selected == true)
                    {
                        cnt = cnt + 1;
                        switch (cnt)
                        {
                            case 1:
                                trQuestion1.Visible = true;
                                break;
                            case 3:
                                trQuestion11.Visible = true;
                                break;
                            case 4:
                                trQuestion2.Visible = true;
                                trQuestion10.Visible = true;
                                break;
                            case 5:
                                trQuestion3.Visible = true;
                                trQuestion4.Visible = false;
                                trQuestion5.Visible = true;
                                trQuestion6.Visible = true;
                                isQues5 = true;
                                break;
                            case 7:
                                if (isQues5 == false)
                                {
                                    trQuestion5.Visible = true;
                                }
                                break;
                            case 8:
                                trQuestion8.Visible = true;
                                trQuestion9.Visible = true;
                                break;
                        }
                    }
                }
                if (grdPlans.Rows.Count > 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //protected void ddlChecklistOption_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (ddlChecklistOption.SelectedValue == "Quick")
        //    {
        //        Session["Summary"] = "Template1";
        //        //lblHeading.Text = "Quick Compliance Check-up";
        //        TitleSpan.InnerText = "Compliance Checklist";
        //        Activity_Group = "Compliance";
        //        pnlDetailedCompliance.Visible = false;
        //        trLegalName.Visible = false;
        //        lblQuickCompliance.Visible = true;
        //        trMeetingDate.Visible = false;
        //    }

        //    if (ddlChecklistOption.SelectedValue == "Detailed")
        //    {
        //        Session["Summary"] = "Template2";
        //        //lblHeading.Text = "Detailed Compliance Checklist";
        //        TitleSpan.InnerText = "Detailed Compliance Checklist";
        //        Activity_Group = "Compliance";
        //        pnlScreen1_BS_Text1.Visible = false;
        //        pnlDetailedCompliance.Visible = true;
        //        trLegalName.Visible = false;
        //        lblQuickCompliance.Visible = false;
        //        ///** Office Dropdown Enabled=False by Amogh*/
        //        ddlOffice.Enabled = false;
        //        trMeetingDate.Visible = false;
        //    }
        //    if (ddlChecklistOption.SelectedValue == "PowerPoint")
        //    {
        //        Session["Summary"] = "Template3";
        //        //lblHeading.Text = "Quick Compliance Check-up";
        //        TitleSpan.InnerText = "Compliance Checklist";
        //        Activity_Group = "Compliance";
        //        pnlDetailedCompliance.Visible = false;
        //        trLegalName.Visible = false;
        //        lblQuickCompliance.Visible = true;
        //        trMeetingDate.Visible = true;
        //    }

        //}

        protected void ddlChecklistOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            trMeetingDate.Visible = false;
            if (ddlChecklistOption.SelectedValue == "Standard")    // Quick changed to standard
            {
                Session["Summary"] = "Template1";
                //lblHeading.Text = "Quick Compliance Check-up";
                //TitleSpan.InnerText = "Quick Compliance Check-up";
                TitleSpan.InnerText = "Compliance Checklist";
                Activity_Group = "Compliance";
                pnlDetailedCompliance.Visible = false;
                trLegalName.Visible = false;
                lblQuickCompliance.Visible = true;
                trMeetingDate.Visible = false;
            }
            if (ddlChecklistOption.SelectedValue == "PowerPoint")
            {
                Session["Summary"] = "Template3";
                //lblHeading.Text = "Quick Compliance Check-up";
                TitleSpan.InnerText = "Compliance Checklist";
                Activity_Group = "Compliance";
                pnlDetailedCompliance.Visible = false;
                trLegalName.Visible = false;
                lblQuickCompliance.Visible = true;
                trMeetingDate.Visible = true;
            }
            if (ddlChecklistOption.SelectedValue == "Plan Administration")
            {
                Session["Summary"] = "Template4";
                TitleSpan.InnerText = "Compliance Checklist";
                Activity_Group = "Compliance";
                pnlDetailedCompliance.Visible = false;
                trLegalName.Visible = false;
                lblQuickCompliance.Visible = true;
                trMeetingDate.Visible = false;
            }

            //if (ddlChecklistOption.SelectedValue == "Detailed")
            //{
            //    Session["Summary"] = "Template2";
            //    //lblHeading.Text = "Detailed Compliance Checklist";
            //    TitleSpan.InnerText = "Detailed Compliance Checklist";
            //    Activity_Group = "Compliance";
            //    pnlScreen1_BS_Text1.Visible = false;
            //    pnlDetailedCompliance.Visible = true;
            //    trLegalName.Visible = true;
            //    lblQuickCompliance.Visible = false;
            //    ///** Office Dropdown Enabled=False by Amogh*/
            //    ddlOffice.Enabled = false;
            //    trMeetingDate.Visible = false;
            //}

        }

        [STAThread]
        protected string CreateComplianceChecklistPPT()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceChecklist_PowerPoint.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/Compliance/Documents/Downloads/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    DateTime MeetingDate = GetDate(txtMeetingDate.Text.ToString().Trim());
                    WritePowerPoint_ComplianceChecklist wt = new WritePowerPoint_ComplianceChecklist();
                    wt.WriteSlideMaster(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteCommonFields(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient, MeetingDate);
                    //WritePowerPoint_FreeStandingFLIMP wt = new WritePowerPoint_FreeStandingFLIMP();
                    //wt.Write_FLIMPVideos(objPres, objPresSet, DictVideosSelected, objSlides, objShapes, txtFrame, txtRange, ddlLanguage);


                    objPres.Save();
                }

                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateComplianceChecklistPPT();
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return savefilename.ToString();
        }

        //Method Added by shravan - for template writing
        private string CreatePlanAdminstration()
        {
            // SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = "";

            fileName = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceChecklist_PlanAdmin.docx");


            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Compliance/Documents/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docx");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                WriteTemplatePlanAdministration wr = new WriteTemplatePlanAdministration();
                wr.WriteCommonFields(oWordDoc, oWordApp, ddlClient.SelectedItem.Text);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
    }
}