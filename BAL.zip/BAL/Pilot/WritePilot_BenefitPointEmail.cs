﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Drawing;
using System.Configuration;
using outlook = Microsoft.Office.Interop.Outlook;

namespace BenefitPointSummaryPortal.BAL.Pilot
{
    public class WritePilot_BenefitPointEmail : System.Web.UI.Page
    {
        SummaryDetail sd = new SummaryDetail();
        BPBusiness bp = new BPBusiness();

        public void WriteEmailBody(DropDownList ddlClient, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataSet AccountDS)
        {
            try
            {

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();
                //DataTable dtNewAcctContactList = new DataTable();
                //dtNewAcctContactList.Columns.Add("Name", typeof(string));
                //dtNewAcctContactList.Columns.Add("ID", typeof(string));

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook
                outlook.Application objOutlk = new outlook.Application();
              
                const int olMailItem = 0;
                
                outlook._MailItem objMail = (outlook._MailItem)objOutlk.CreateItem(outlook.OlItemType.olMailItem);
                objMail = objOutlk.CreateItem(olMailItem);
               
                objMail.To = "";
               // objMail.CC = "";

                //Set up Subject Line
                objMail.Subject = "Broker of Letter Change";
                //To add an attachment, use:
                //objMail.Attachments.Add("C:\\MyTestDoc.txt");
               

                Literal lit = new Literal();
                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span style='background-color: #FFFF00'>Carrier Contact Name:</span>,</span> <br/>";
                lit.Text += "<p>Enclosed is a letter from <span style='background-color: #00FF00'>" + Account_Contacts + "</span> at  <span style='background-color: #00FF00'>" + CompanyName + " </span>naming";
                lit.Text += " USI Insurance Services as broker of record for all of their employee benefit plans effective <span style='background-color: #00FF00'>" + Broker_Of_Record + "</span>.</p>";
                lit.Text += "<p>In order to ensure uninterrupted, quality service to our mutual customer, please furnish the following information:";
                lit.Text += "<ul><li>Copy of the summary plan description</li>";
                lit.Text += "<li>Copy of the group application</li>";
                lit.Text += "<li>Copy of the contract</li>";
                lit.Text += "<li>Copy of the last renewal</li>";
                lit.Text += "<li>Commission agreement</li>";
                lit.Text += "<li>Contact sheet showing member services toll-free number and claim office mailing address</li>";
                lit.Text += "<li>Rate history for the past three years (if applicable)</li>";
                lit.Text += "<li>Schedule A for past plan years (if applicable)</li>";
                lit.Text += "<li>Copy of most recent premium statement</li>";
                lit.Text += "<li>Plan policy numbers </li></ul></p>";
                lit.Text += "<p>Please note that we require a minimum 90-day notification on all renewals. Also, USI Insurance Services should be";
                lit.Text += " copied on all future correspondence pertaining to <span style='background-color: #00FF00'>" + CompanyName + "</span>.</p>";
                lit.Text += "<p>Please notify us immediately if any of these requests cannot be fulfilled. We thank you for your assistance in these";
                lit.Text += " matters and look forward to working with you on this account.</p>";

                lit.Text += "<span>Sincerely,</span><br/>";
                lit.Text += "<span style='background-color: #00FF00'>" + ServiceLead_FirstName + " " + ServiceLead_LastName + "<br/>" + ServiceLead_Role + "<br/>" + ServiceLead_WorkPhone + "</span></div>";

                objMail.HTMLBody = lit.Text;
                objMail.BodyFormat = outlook.OlBodyFormat.olFormatHTML;

                //Use this To display before sending, otherwise call objMail.Send to send without reviewing
                //Display the mailbox
                objMail.Display();
                //Clean up
                objMail = null;
                objOutlk = null;
                #endregion

            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}