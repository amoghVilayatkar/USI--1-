﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Eligibility
    {
        #region Variable
        private int _EligibilityId;
        private string _description;
        #endregion
        #region Properties
        /// <summary>
        /// Get and Set EligibilityId
        /// </summary>
        public int EligibilityId
        {
            get
            {
                return _EligibilityId;
            }
            set
            {
                _EligibilityId = value;
            }
        }
        /// <summary>
        /// Get and Set EligibilityDescription
        /// </summary>
        public string EligibilityDescription
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        #endregion
    }
}