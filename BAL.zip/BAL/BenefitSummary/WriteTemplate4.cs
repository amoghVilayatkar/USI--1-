﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate4 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="ddlAnnualLegalNotice">Dropdownlist ddlAnnualLegalNotice Object</param>
        /// <param name="ddlChipNotice">Dropdownlist ddlChipNotice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        /// <param name="ddlImageOption">Dropdownlist ddlImageOption Object</param>
        public void WriteFieldToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, DropDownList ddlAnnualLegalNotice, DropDownList ddlChipNotice, DropDownList ddlImageOption)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                int index = -1;

                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Picture 1"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 1.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 2"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 2.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 3"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 3.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 4"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 4.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 5"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 5.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 6"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 6.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 7"))
                                    {
                                        myMergeField.Delete();
                                        object missing = System.Type.Missing;
                                        Word.Range r = oWordDoc.Range();
                                        r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                        r.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/Pictures/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/Picture 7.jpg"), false, true);
                                        continue;
                                    }
                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("client website"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString()))
                                        {
                                            oWordApp.Selection.TypeText(" | " + AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("unmarriedchildtoage"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("definitionofdomesticpartner"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                            oWordApp.Selection.TypeText(domesticPartner);
                                            continue;
                                        }
                                    }
                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                            continue;
                                        }

                                        if (fieldName.Contains("frequency"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Unit to Measure"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Waiting Period"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                            continue;
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("CRB"))
                                        {
                                            myMergeField.Select();
                                            myMergeField.Delete();
                                            continue;
                                        }

                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("CRB"))
                                        {
                                            myMergeField.Select();

                                            if (ddlBRC.SelectedIndex == 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                                            {
                                                oWordApp.Selection.TypeBackspace();
                                                oWordApp.Selection.TypeBackspace();
                                                oWordApp.Selection.TypeBackspace();
                                                oWordApp.Selection.TypeBackspace();
                                            }
                                            else
                                            {
                                                myMergeField.Delete();
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(22, "45");   //Calendar Year Deductible indivisual
                HashtableMedicalInNetwork1.Add(2, "44");    //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(33, "53");   //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalInNetwork1.Add(3, "52");    //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalInNetwork1.Add(4, "386");   //Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(5, "112");   //General Plan Information Coinsurence



                Hashtable HashtableMedicalInNetwork2 = new Hashtable();
                HashtableMedicalInNetwork2.Add(2, "414");   //Specialists Office Visit
                HashtableMedicalInNetwork2.Add(3, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork2.Add(4, "971");            //Other Services[Complex Radiology]
                HashtableMedicalInNetwork2.Add(5, "295");   //Inpatient Hospitalization
                HashtableMedicalInNetwork2.Add(6, "184");   //Emergency Room
                #endregion

                int count = 1;
                string InNetwork_Indivisual_Plan1 = string.Empty;
                string InNetwork_Family_Plan1 = string.Empty;
                string InNetwork_Coinsurance_Plan1 = string.Empty;
                string InNetwork_Office_Visit_Plan1 = string.Empty;
                string OutOfPocket_Individual_Plan1 = string.Empty;
                string InNetwork_Indivisual_Plan2 = string.Empty;
                string InNetwork_Family_Plan2 = string.Empty;
                string InNetwork_Coinsurance_Plan2 = string.Empty;
                string InNetwork_Office_Visit_Plan2 = string.Empty;
                string OutOfPocket_Individual_Plan2 = string.Empty;
                string InNetwork_Indivisual_Plan3 = string.Empty;
                string InNetwork_Family_Plan3 = string.Empty;
                string InNetwork_Coinsurance_Plan3 = string.Empty;
                string InNetwork_Office_Visit_Plan3 = string.Empty;
                string OutOfPocket_Individual_Plan3 = string.Empty;
                string medicalcarrier = "";
                int TableNo = 4;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            if (count == 1)
                            {
                                oWordDoc.Tables[TableNo].Cell(1, count + 1).Select();
                                oWordDoc.Tables[TableNo].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                oWordDoc.Tables[TableNo + 1].Cell(1, count + 1).Select();
                                oWordDoc.Tables[TableNo + 1].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            if (count == 2)
                            {
                                TableNo = 4;
                                oWordDoc.Tables[TableNo].Cell(1, 3).Select();
                                oWordDoc.Tables[TableNo].Cell(1, 3).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                oWordDoc.Tables[TableNo + 1].Cell(1, 3).Select();
                                oWordDoc.Tables[TableNo + 1].Cell(1, 3).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            if (count == 3)
                            {
                                TableNo = 4;
                                oWordDoc.Tables[TableNo].Cell(1, 4).Select();
                                oWordDoc.Tables[TableNo].Cell(1, 4).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                oWordDoc.Tables[TableNo + 1].Cell(1, 4).Select();
                                oWordDoc.Tables[TableNo + 1].Cell(1, 4).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }

                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 33)
                                            {
                                                OutOfPocket_Individual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (OutOfPocket_Individual_Plan1 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family";
                                            }
                                            else if (key == 22)
                                            {
                                                InNetwork_Indivisual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                InNetwork_Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (InNetwork_Indivisual_Plan1 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family"; ;
                                            }
                                            else if (key == 4)
                                            {
                                                InNetwork_Office_Visit_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = InNetwork_Office_Visit_Plan1;
                                            }
                                            else if (key == 5)
                                            {
                                                InNetwork_Coinsurance_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            if (key == 33)
                                            {
                                                OutOfPocket_Individual_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (OutOfPocket_Individual_Plan2 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family";
                                            }
                                            else if (key == 22)
                                            {
                                                InNetwork_Indivisual_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                InNetwork_Family_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (InNetwork_Indivisual_Plan2 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family"; ;
                                            }
                                            else if (key == 4)
                                            {
                                                InNetwork_Office_Visit_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = InNetwork_Office_Visit_Plan2;
                                            }
                                            else if (key == 5)
                                            {
                                                InNetwork_Coinsurance_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            if (key == 33)
                                            {
                                                OutOfPocket_Individual_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 4).Range.Text = (OutOfPocket_Individual_Plan3 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family";
                                            }
                                            else if (key == 22)
                                            {
                                                InNetwork_Indivisual_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                InNetwork_Family_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (InNetwork_Indivisual_Plan3 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n" + "per member / family"; ;
                                            }
                                            else if (key == 4)
                                            {
                                                InNetwork_Office_Visit_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                oWordDoc.Tables[TableNo].Cell(key, 4).Range.Text = InNetwork_Office_Visit_Plan3;
                                            }
                                            else if (key == 5)
                                            {
                                                InNetwork_Coinsurance_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }

                            TableNo++;
                            foreach (int key in HashtableMedicalInNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork2[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 5)
                                            {
                                                if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per admit";
                                                }
                                                else
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = " ";
                                                }
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            if (key == 5)
                                            {
                                                if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per admit";
                                                }
                                                else
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = " ";
                                                }
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            if (key == 5)
                                            {
                                                if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per admit";
                                                }
                                                else
                                                {
                                                    oWordDoc.Tables[TableNo].Cell(key, 4).Range.Text = " ";
                                                }
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (count == 1)
                                    {
                                        if (fieldName.Contains("First Medical Plan Year"))
                                        {
                                            myMergeField.Select();
                                            string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Medical Carrier1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }

                                        if (fieldName.Contains("Medical Plan Type Name1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                            continue;
                                        }

                                        if (fieldName.Contains("Medical Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Individual Plan1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Indivisual_Plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("innetwork Coinsurance Plan1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Coinsurance_Plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Office Visit Exam  Plan1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Office_Visit_Plan1);
                                            continue;
                                        }
                                        if (fieldName.Contains("First Medical Plan Expiry Date"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"]).ToShortDateString().ToString());
                                            continue;
                                        }
                                    }

                                    if (count == 2)
                                    {
                                        if (fieldName.Contains("Medical Carrier2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Medical Plan Type Name2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Medical Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Individual Plan2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Indivisual_Plan2);
                                            continue;
                                        }
                                        if (fieldName.Contains("innetwork Coinsurance Plan2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Coinsurance_Plan2);
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Office Visit Exam  Plan2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Office_Visit_Plan2);
                                            continue;
                                        }
                                    }
                                    if (count == 3)
                                    {
                                        if (fieldName.Contains("Medical Carrier3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Medical Plan Type Name3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Medical Benefit Summary Description3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Individual Plan3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Indivisual_Plan3);
                                            continue;
                                        }
                                        if (fieldName.Contains("innetwork Coinsurance Plan3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Coinsurance_Plan3);
                                            continue;
                                        }
                                        if (fieldName.Contains("Innetwork Office Visit Exam  Plan3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(InNetwork_Office_Visit_Plan3);
                                            continue;
                                        }
                                    }
                                }
                            }

                            #endregion
                            medicalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string NoOfDaysSupply = string.Empty;
                string Preferred_Specialty = "";
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213"); //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");  //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");  //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "380"); //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211"); //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");  //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");  //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "378"); //Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value + "\n"; break;
                                            case 2: Formulary = "Formulary: " + value + "\n"; break;
                                            case 3: NonFormulary = " Non Formulary: " + value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[5].Cell(7, 1).Range.Text = "Retail Prescription Drugs " + "\n" + NoOfDaysSupply;
                                oWordDoc.Tables[5].Cell(7, 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[5].Cell(7, 3).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[5].Cell(7, 4).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value + "\n"; break;
                                            case 2: Formulary = "Formulary: " + value + "\n"; break;
                                            case 3: NonFormulary = " Non Formulary: " + value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                            case 5: Preferred_Specialty = "Preferred Specialty: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                oWordDoc.Tables[5].Cell(8, 1).Range.Text = "Mail Order Prescriptions " + "\n" + NoOfDaysSupply;
                                oWordDoc.Tables[5].Cell(8, 2).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[5].Cell(8, 3).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[5].Cell(8, 4).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;
                            }
                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(11, "45");     //Calendar Year Deductible - Individual
                HashtableDentalInNetwork.Add(3, "44");      //Calendar Year Deductible - Family
                HashtableDentalInNetwork.Add(4, "566");     //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalInNetwork.Add(5, "55");      //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(6, "164");     //Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(7, "64");      //Basic Restorative Care - Basic 
                HashtableDentalInNetwork.Add(8, "336");     //Major Restorative Care - Major
                HashtableDentalInNetwork.Add(9, "392");     //Orthodontic Services

                #endregion
                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(11, "45");     //Calendar Year Deductible - Individual
                HashtableDentalOutNetwork.Add(3, "44");      //Calendar Year Deductible - Family
                HashtableDentalOutNetwork.Add(4, "566");     //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalOutNetwork.Add(5, "55");      //Calendar Year Benefit Maximum
                HashtableDentalOutNetwork.Add(6, "164");     //Preventive & Diagnostic Care
                HashtableDentalOutNetwork.Add(7, "64");      //Basic Restorative Care - Basic 
                HashtableDentalOutNetwork.Add(8, "336");     //Major Restorative Care - Major
                HashtableDentalOutNetwork.Add(9, "392");     //Orthodontic Services

                #endregion
                int count = 1;

                string AnnualDeductible_Individual = "";
                string value = "";
                string Dentalcarrier = "";
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region DentalTable

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(1, count + 1).Select();
                                oWordDoc.Tables[6].Cell(1, count + 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            else if (count == 2)
                            {
                                oWordDoc.Tables[7].Cell(1, 2).Select();
                                oWordDoc.Tables[7].Cell(1, 2).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 11: AnnualDeductible_Individual = value; break;
                                                case 3:
                                                    oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = AnnualDeductible_Individual + " / " + value + "\n" + "per member / family";
                                                    break;
                                            }

                                            if (key != 11 && key != 3)
                                            {
                                                oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 11: AnnualDeductible_Individual = value; break;
                                                case 3:
                                                    oWordDoc.Tables[7].Cell(key, 2).Range.Text = AnnualDeductible_Individual + " / " + value + "\n" + "per member / family";
                                                    break;
                                            }

                                            if (key != 11 && key != 3)
                                            {
                                                oWordDoc.Tables[7].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 11: AnnualDeductible_Individual = value; break;
                                                case 3:
                                                    oWordDoc.Tables[6].Cell(key, count + 2).Range.Text = AnnualDeductible_Individual + " / " + value + "\n" + "per member / family";
                                                    break;
                                            }
                                            if (key != 11 && key != 3)
                                            {
                                                oWordDoc.Tables[6].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 11: AnnualDeductible_Individual = value; break;
                                                case 3:
                                                    oWordDoc.Tables[7].Cell(key, 3).Range.Text = AnnualDeductible_Individual + " / " + value + "\n" + "per member / family";
                                                    break;
                                            }
                                            if (key != 11 && key != 3)
                                            {
                                                oWordDoc.Tables[7].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (Dentalcarrier != PlanTable.Rows[rowindex]["Carrier"].ToString())
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (Dentalcarrier != PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString())
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                            continue;
                                        }
                                    }
                                }
                            }

                            #endregion
                            Dentalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, DataTable CarrierSpecific)
        {
            try
            {
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(11, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(44, "194");     //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork.Add(43, "309");     //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitInNetwork.Add(42, "122");     //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefitInNetwork.Add(4, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(5, "195");      //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(6, "507");      //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(7, "73");       //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitInNetwork.Add(8, "553");      //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitInNetwork.Add(9, "208");      //Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(10, "356");     //Covered Services – Contact Lenses – Medically Necessary

                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                Hashtable HashtableVisionBenefitOutNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitOutNetwork.Add(11, "195");    //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitOutNetwork.Add(3, "344");     //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitOutNetwork.Add(5, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitOutNetwork.Add(6, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitOutNetwork.Add(7, "73");      //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitOutNetwork.Add(8, "553");     //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitOutNetwork.Add(9, "208");     //Covered Services – Frames
                HashtableVisionBenefitOutNetwork.Add(10, "356");    //Covered Services – Contact Lenses – Medically Necessary

                ArrayList arrVisionBenefitOutNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitOutNetwork.Keys)
                {
                    arrVisionBenefitOutNetwork.Add(key);
                }

                arrVisionBenefitOutNetwork.Sort();
                arrVisionBenefitOutNetwork.Reverse();
                #endregion

                string CopayExamination = string.Empty;
                string BenefitFrequency_Examination = string.Empty;
                string BenefitFrequency_Lenses = string.Empty;
                string BenefitFrequency_Contacts = string.Empty;

                int iTotalFields = 0;
                int count = 1;

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable

                            if (count == 1)
                            {
                                oWordDoc.Tables[8].Cell(1, 2).Select();
                                oWordDoc.Tables[8].Cell(1, 2).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                            }
                            else if (count == 2)
                            {
                                CopayExamination = "";
                                BenefitFrequency_Examination = "";
                                BenefitFrequency_Lenses = "";
                                BenefitFrequency_Contacts = "";
                                oWordDoc.Tables[9].Cell(1, 2).Select();
                                oWordDoc.Tables[9].Cell(1, 2).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                            }

                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 11: CopayExamination = value; break;
                                                case 44: BenefitFrequency_Examination = value; break;
                                                case 43: BenefitFrequency_Lenses = value; break;
                                                case 42: BenefitFrequency_Contacts = value; break;
                                                case 3: oWordDoc.Tables[8].Cell(key, 2).Range.Text = "Examination - " + CopayExamination + " \n" + "Materials - " + value; break;
                                                case 4: oWordDoc.Tables[8].Cell(key, 2).Range.Text = "Exams - " + BenefitFrequency_Examination + "\n" + "Lenses - " + BenefitFrequency_Lenses + "\n" + "Contacts - " + BenefitFrequency_Contacts + "\n" + "Frames - " + value; break;
                                            }
                                            if (key != 11 && key != 44 && key != 43 && key != 42 && key != 4 && key != 3)
                                            {
                                                oWordDoc.Tables[8].Cell(key, 2).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 11: CopayExamination = value; break;
                                                case 44: BenefitFrequency_Examination = value; break;
                                                case 43: BenefitFrequency_Lenses = value; break;
                                                case 42: BenefitFrequency_Contacts = value; break;
                                                case 3: oWordDoc.Tables[9].Cell(key, 2).Range.Text = "Examination - " + CopayExamination + " \n" + "Materials - " + value; break;
                                                case 4: oWordDoc.Tables[9].Cell(key, 2).Range.Text = "Exams - " + BenefitFrequency_Examination + "\n" + "Lenses - " + BenefitFrequency_Lenses + "\n" + "Contacts - " + BenefitFrequency_Contacts + "\n" + "Frames - " + value; break;
                                            }
                                            if (key != 11 && key != 44 && key != 43 && key != 42 && key != 4 && key != 3)
                                            {
                                                oWordDoc.Tables[9].Cell(key, 2).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in arrVisionBenefitOutNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 11: CopayExamination = value; break;
                                                case 44: BenefitFrequency_Examination = value; break;
                                                case 43: BenefitFrequency_Lenses = value; break;
                                                case 42: BenefitFrequency_Contacts = value; break;
                                                case 3: oWordDoc.Tables[8].Cell(key, 3).Range.Text = "Examination - " + CopayExamination + " \n" + "Materials - " + value; break;
                                                case 4: oWordDoc.Tables[8].Cell(key, 3).Range.Text = "Exams - " + BenefitFrequency_Examination + "\n" + "Lenses - " + BenefitFrequency_Lenses + "\n" + "Contacts - " + BenefitFrequency_Contacts + "\n" + "Frames - " + value; break;
                                            }
                                            if (key != 11 && key != 44 && key != 43 && key != 42 && key != 4 && key != 3)
                                            {
                                                oWordDoc.Tables[8].Cell(key, 3).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 11: CopayExamination = value; break;
                                                case 44: BenefitFrequency_Examination = value; break;
                                                case 43: BenefitFrequency_Lenses = value; break;
                                                case 42: BenefitFrequency_Contacts = value; break;
                                                case 3: oWordDoc.Tables[9].Cell(key, 3).Range.Text = "Examination - " + CopayExamination + " \n" + "Materials - " + value; break;
                                                case 4: oWordDoc.Tables[9].Cell(key, 3).Range.Text = "Exams - " + BenefitFrequency_Examination + "\n" + "Lenses - " + BenefitFrequency_Lenses + "\n" + "Contacts - " + BenefitFrequency_Contacts + "\n" + "Frames - " + value; break;
                                            }
                                            if (key != 11 && key != 44 && key != 43 && key != 42 && key != 4 && key != 3)
                                            {
                                                oWordDoc.Tables[9].Cell(key, 3).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        public void WriteLTDSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlClient, DropDownList ddlLTDPlanName)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableLTD
                HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period
                HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage
                HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum
                HashtableLTD.Add(4, "351");     //General Plan Information – Maximum Period of Payment
                #endregion

                string value = "";
                string Elimination_Period = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Maximum_Period_Of_Payment = string.Empty;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                if (value.Contains("days"))
                                                {
                                                    Elimination_Period = value.Trim().Replace("days", "day");
                                                }
                                                else
                                                {
                                                    Elimination_Period = value.Trim();
                                                }
                                                break;
                                            case 2: Benefit_Percentage = value.Trim(); break;
                                            case 3: Monthly_Benefit_Maximum = value.Trim(); break;
                                            case 4: Maximum_Period_Of_Payment = value.Trim() + " " + dr["UOM"].ToString().Trim(); break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VlLTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Equals("\"Voluntary LTD\""))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary ");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Disability Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Disability Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("MainTableSTDLTD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString() + " provides a company–sponsored long-term disability (LTD) insurance plan through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".");
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Elimination Period Plan1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Elimination_Period))
                                        {
                                            oWordApp.Selection.TypeText(Elimination_Period);
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("LTD Monthly Benefit Percentage Plan"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Benefit_Percentage))
                                        {
                                            oWordApp.Selection.TypeText(Benefit_Percentage);
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("LTD Monthly Benefit Max Plan 1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum))
                                        {
                                            oWordApp.Selection.TypeText(Monthly_Benefit_Maximum);
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }

                                    if (fieldName.Contains("LTD Max Period of Payment"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Maximum_Period_Of_Payment))
                                        {
                                            oWordApp.Selection.TypeText(Maximum_Period_Of_Payment);
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlLTDNoOfPlan, DropDownList ddlClient, DropDownList ddlSTDPlanName)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(2, "505");     //STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");      //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment
                #endregion

                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string ProductName = "";

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                if (value.Contains("days"))
                                                {
                                                    EliminationPeriod_Accident = value.Trim().Replace("days", "day");
                                                }
                                                else
                                                {
                                                    EliminationPeriod_Accident = value.Trim();
                                                }
                                                break;
                                            case 2:
                                                if (value.Contains("days"))
                                                {
                                                    EliminationPeriod_Sickness = value.Trim().Replace("days", "day");
                                                }
                                                else
                                                {
                                                    EliminationPeriod_Sickness = value.Trim();
                                                }
                                                break;
                                            case 3: Benefit_Percentage = value.Trim(); break;
                                            case 4: Weekly_Benefit_Maximum = value.Trim(); break;
                                            case 5: Maximum_Period_of_Payment = value.Trim(); break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VlSTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Equals("\"Voluntary STD\""))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary ");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Disability Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Disability Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("MainTableSTDLTD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Voluntary STD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDNoOfPlan.SelectedIndex > 0)
                                        {
                                            oWordApp.Selection.TypeText("In addition, " + ddlClient.SelectedItem.Text.ToString() + " employees have the opportunity to become insured against loss of income due to short-term disabilities (STD) through the " + PlanTable.Rows[rowindex]["Carrier"].ToString() + " salary continuation program");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString() + " employees have the opportunity to become insured against loss of income due to short-term disabilities (STD) through the)" + PlanTable.Rows[rowindex]["Carrier"].ToString() + " salary continuation program");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Voluntary STD Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    }
                                    if (fieldName.Contains("Voluntary STD  Accident Plan1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(EliminationPeriod_Accident))
                                        {
                                            oWordApp.Selection.TypeText(EliminationPeriod_Accident);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (fieldName.Contains("Voluntary STD Sickness Plan1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(EliminationPeriod_Sickness))
                                        {
                                            oWordApp.Selection.TypeText(EliminationPeriod_Sickness);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("Voluntary STD  Benefit Percentage Plan1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Benefit_Percentage))
                                        {
                                            oWordApp.Selection.TypeText(Benefit_Percentage);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (fieldName.Contains("Voluntary STD Weekly Benefit Max Plan1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Weekly_Benefit_Maximum))
                                        {
                                            oWordApp.Selection.TypeText(Weekly_Benefit_Maximum);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (fieldName.Contains("Voluntary STD Max Period of Payment"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                        {
                                            oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLifeADDToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string OverallMaximum = "";
                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "188");     //Employee[Overall Maximum]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region GroupLifeADDBenifitTable

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: OverallMaximum = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Life_ADD_Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life Insurance");
                                        continue;
                                    }

                                    if (fieldName.Contains("Life and AD&D Carrier1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Life AD&D Overall Maximum Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(OverallMaximum);
                                        continue;
                                    }
                                }
                            }
                        }
                            #endregion
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>

        public void WriteContactinformationToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 2;
                int k = 1;
                string carriername = "";
                string plantype = "";
                DataRow[] foundRows = null;
                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;
                int rowCnt = 3;
                int cntPlan = 0;
                int cntPlan1 = 0;

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if (k > 1)
                    {
                        oWordDoc.Tables[count].Rows.Add();
                    }

                    int medical_plan = 0;
                    int dental_plan = 0;
                    int vision_plan = 0;

                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        for (int c = 0; c < PlanTable.Rows.Count; c++)
                        {
                            plantype = PlanTable.Rows[c]["PlanType"].ToString();
                            if (plantype == cv.DentalPlanType)
                            {
                                dental_plan++;
                            }
                            if (plantype == cv.VisionPlanType)
                            {
                                vision_plan++;
                            }
                            if (plantype == cv.MedicalPlanType)
                            {
                                medical_plan++;
                            }
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();

                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Underline = Word.WdUnderline.wdUnderlineSingle;
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Bold = 1;

                        if (plantype == cv.LifeADDPlanType || plantype == cv.VoluntaryLifeADDPlanType || plantype == cv.LTDPlanType || plantype == cv.STDPlanType)
                        {
                            if (cntPlan == 0)
                            {
                                oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " Additional Lines of Coverage";
                                oWordDoc.Tables[count].Rows.Add();
                                rowCnt++;
                                cntPlan++;
                            }
                        }
                        else if (plantype == cv.FSAPlanType || plantype == cv.HSAPlanType || plantype == cv.HRAPlanType)
                        {
                            if (cntPlan1 == 0)
                            {
                                oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " Spending Account(s)";
                                oWordDoc.Tables[count].Rows.Add();
                                rowCnt++;
                                cntPlan1++;
                            }
                        }
                        else
                        {
                            if (plantype == cv.MedicalPlanType)
                            {
                                if (medical_plan == 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype;
                                }
                                else if (medical_plan > 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype + "s";
                                }
                            }
                            if (plantype == cv.DentalPlanType)
                            {
                                if (dental_plan == 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype;
                                }
                                else if (dental_plan > 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype + "s";
                                }
                            }
                            if (plantype == cv.VisionPlanType)
                            {
                                if (vision_plan == 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype;
                                }
                                else if (vision_plan > 1)
                                {
                                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype + "s";
                                }
                            }
                            if (plantype == cv.EAPPlanType)
                            {
                                oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = " " + plantype;
                            }

                            oWordDoc.Tables[count].Rows.Add();
                            rowCnt++;
                        }
                    }

                    oWordDoc.Tables[count].Rows[rowCnt].Borders.Enable = 0;

                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Underline = Word.WdUnderline.wdUnderlineNone;
                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Bold = 0;

                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["SummaryName"].ToString());
                    oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                    oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());

                    foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");
                    if (foundRows.Count() > 0)
                    {
                        oWordDoc.Tables[count].Cell(rowCnt, 4).Range.Text = Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                        oWordDoc.Tables[count].Cell(rowCnt, 5).Range.Text = Convert.ToString(foundRows[0]["Website"].ToString());
                    }
                    else
                    {
                        oWordDoc.Tables[count].Cell(rowCnt, 4).Range.Text = "";
                        oWordDoc.Tables[count].Cell(rowCnt, 5).Range.Text = "";
                    }

                    k++;
                    rowCnt++;
                }

                // Give Top border for each of the heading
                for (int t = 1; t <= oWordDoc.Tables[count].Rows.Count; t++)
                {
                    if (oWordDoc.Tables[count].Rows[t].Cells[1].Range.Text.Contains("Dental Plan") || oWordDoc.Tables[count].Rows[t].Cells[1].Range.Text.Contains("Vision Plan") || oWordDoc.Tables[count].Rows[t].Cells[1].Range.Text.Contains("Additional Lines of Coverage") || oWordDoc.Tables[count].Rows[t].Cells[1].Range.Text.Contains("Spending Account(s)") || oWordDoc.Tables[count].Rows[t].Cells[1].Range.Text.Contains("EAP Plan"))
                    {
                        oWordDoc.Tables[count].Rows[t].Borders[Word.WdBorderType.wdBorderTop].Visible = true;
                        oWordDoc.Tables[count].Rows[t].Borders[Word.WdBorderType.wdBorderTop].Color = Word.WdColor.wdColorWhite;
                        oWordDoc.Tables[count].Rows[t].Borders[Word.WdBorderType.wdBorderTop].ColorIndex = Word.WdColorIndex.wdWhite;
                    }
                }

                // Update Table of Content
                int contentPageNo = 9;
                int contentRowCnt = 6;

                int dentalCnt = 0;
                int visionCnt = 0;
                bool isSTD_LTD = false;
                bool isLife_Voluntary_Life = false;
                bool isFSA_HRA = false;
                ArrayList arrTOC = new ArrayList();
                arrTOC.Add("Dental Insurance");
                arrTOC.Add("Vision Insurance");
                arrTOC.Add("Disability Insurance");
                arrTOC.Add("Life Insurance");
                arrTOC.Add("Flexible Spending Accounts");
                arrTOC.Add("Employee Assistance Plan");

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    if (plantype == cv.DentalPlanType)
                    {
                        dentalCnt++;
                    }
                    if (plantype == cv.VisionPlanType)
                    {
                        visionCnt++;
                    }
                }

                for (int j = 0; j < arrTOC.Count; j++)
                {
                    for (int i = 0; i < PlanTable.Rows.Count; i++)
                    {
                        if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()))
                        {
                            carriername = PlanTable.Rows[i]["Carrier"].ToString();
                            plantype = PlanTable.Rows[i]["PlanType"].ToString();

                            ((oWordDoc.Tables[1]).Columns[1]).Cells[contentRowCnt].Height = 20;
                            ((oWordDoc.Tables[1]).Columns[1]).Cells[contentRowCnt].VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalBottom;

                            if (j == 0)
                            {
                                if (plantype == cv.DentalPlanType)
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Dental Insurance";
                                    contentRowCnt++;
                                    if (dentalCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    break;
                                }
                                continue;
                            }

                            if (j == 1)
                            {
                                if (plantype == cv.VisionPlanType)
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Vision Insurance";
                                    contentRowCnt++;
                                    if (visionCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    break;
                                }
                                continue;
                            }

                            if (j == 2)
                            {
                                if (isSTD_LTD == false)
                                {
                                    if (plantype == cv.STDPlanType || plantype == cv.LTDPlanType)
                                    {
                                        oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Disability Insurance";
                                        contentRowCnt++;
                                        contentPageNo++;
                                        isSTD_LTD = true;
                                        break;
                                    }
                                }
                                continue;
                            }

                            if (j == 3)
                            {
                                if (isLife_Voluntary_Life == false)
                                {
                                    if (plantype == cv.LifeADDPlanType || plantype == cv.VoluntaryLifeADDPlanType)
                                    {
                                        oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Life Insurance";
                                        contentRowCnt++;
                                        contentPageNo++;
                                        isLife_Voluntary_Life = true;
                                        break;
                                    }
                                }
                                continue;
                            }

                            if (j == 4)
                            {
                                if (isFSA_HRA == false)
                                {
                                    if (plantype == cv.FSAPlanType || plantype == cv.HRAPlanType)
                                    {
                                        if (plantype == cv.FSAPlanType)
                                        {
                                            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Flexible Spending Accounts";
                                        }
                                        else if (plantype == cv.HRAPlanType)
                                        {
                                            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Health Reimbursement Account";
                                        }
                                        contentRowCnt++;
                                        contentPageNo++;
                                        isFSA_HRA = true;
                                        break;
                                    }
                                }
                                continue;
                            }

                            if (j == 5)
                            {
                                if (plantype == cv.EAPPlanType)
                                {
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = "Employee Assistance Plan";
                                    contentRowCnt++;
                                    contentPageNo++;
                                    break;
                                }
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        ///// <summary>
        ///// Write Monthly Premium Section to template.
        ///// </summary>
        ///// <param name="oWordDoc">Word Document Object</param>
        ///// <param name="oWordApp">Word Application Object</param>
        ///// <param name="PlanTable">PlanTable contain selected Plan</param>
        ///// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        ///// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        //public void WriteMonthlyPremiumSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        //{
        //    try
        //    {
        //        ConstantValue cv = new ConstantValue();
        //        int Medicalindex = 5;
        //        int DentalCount = 0;
        //        int VisionCount = 0;

        //        DataTable PremiumTableWriteMedical = new DataTable();
        //        PremiumTableWriteMedical.Columns.Add("RateHeader");
        //        PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
        //        PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
        //        PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

        //        DataTable PremiumTableWriteDental = new DataTable();
        //        PremiumTableWriteDental.Columns.Add("RateHeader");
        //        PremiumTableWriteDental.Columns.Add("Plan1_Rate");
        //        PremiumTableWriteDental.Columns.Add("Plan2_Rate");

        //        DataTable PremiumTableWriteVision = new DataTable();
        //        PremiumTableWriteVision.Columns.Add("RateHeader");
        //        PremiumTableWriteVision.Columns.Add("Plan1_Rate");
        //        PremiumTableWriteVision.Columns.Add("Plan2_Rate");

        //        for (int index = 0; index < PlanTable.Rows.Count; index++)
        //        {
        //            #region  BuildTable
        //            DataTable PremiumTable = new DataTable();
        //            int premium_row_counter = 0;

        //            PremiumTable.Columns.Add("Plan", typeof(string));
        //            PremiumTable.Columns.Add("rateTierID", typeof(int));
        //            PremiumTable.Columns.Add("rateTier_description", typeof(string));
        //            PremiumTable.Columns.Add("monthlycost", typeof(string));
        //            PremiumTable.Columns.Add("contributioncost", typeof(string));
        //            PremiumTable.Columns.Add("summaryname", typeof(string));
        //            PremiumTable.Columns.Add("contributionFrequency", typeof(string));
        //            PremiumTable.Columns.Add("contributionid", typeof(string));
        //            PremiumTable.Columns.Add("rateid", typeof(string));
        //            PremiumTable.Columns.Add("rateFieldValueID", typeof(string));

        //            for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
        //            {
        //                if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
        //                {
        //                    if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
        //                    {
        //                        PremiumTable.Rows.Add();
        //                        PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
        //                        if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
        //                        {
        //                            PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
        //                        }
        //                        else
        //                        {
        //                            PremiumTable.Rows[premium_row_counter][1] = 0;
        //                        }
        //                        PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
        //                        PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
        //                        PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
        //                        PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
        //                        for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
        //                        {
        //                            if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
        //                            {
        //                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
        //                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
        //                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
        //                                PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
        //                                break;
        //                            }
        //                        }
        //                        premium_row_counter++;
        //                    }
        //                }
        //            }

        //            #endregion

        //            DataTable dt = new DataTable();

        //            PremiumTable.DefaultView.Sort = "[rateTierID] asc";
        //            dt = PremiumTable.DefaultView.ToTable(true);
        //            PremiumTable = dt;

        //            # region FillTable Medical

        //            if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
        //            {
        //                if (index == 0)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            DataRow dr = PremiumTableWriteMedical.NewRow();
        //                            dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";
        //                            dr["Plan3_Rate"] = "";
        //                            PremiumTableWriteMedical.Rows.Add(dr);
        //                        }
        //                        else
        //                        {
        //                            DataRow dr = PremiumTableWriteMedical.NewRow();
        //                            dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";
        //                            dr["Plan3_Rate"] = "";
        //                            PremiumTableWriteMedical.Rows.Add(dr);
        //                        }
        //                    }
        //                }
        //                if (index == 1)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        int flag = 0;
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteMedical.NewRow();
        //                                dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                dr["Plan3_Rate"] = "";
        //                                PremiumTableWriteMedical.Rows.Add(dr);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteMedical.NewRow();
        //                                dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                dr["Plan3_Rate"] = "";
        //                                PremiumTableWriteMedical.Rows.Add(dr);
        //                            }
        //                        }
        //                    }
        //                }
        //                if (index == 2)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        int flag = 0;
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteMedical.NewRow();
        //                                dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                dr["Plan2_Rate"] = "";
        //                                PremiumTableWriteMedical.Rows.Add(dr);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteMedical.NewRow();
        //                                dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                dr["Plan2_Rate"] = "";
        //                                PremiumTableWriteMedical.Rows.Add(dr);
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            #endregion

        //            # region FillTable Dental

        //            if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
        //            {
        //                if (DentalCount == 0)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            DataRow dr = PremiumTableWriteDental.NewRow();
        //                            dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";
        //                            PremiumTableWriteDental.Rows.Add(dr);
        //                        }
        //                        else
        //                        {
        //                            DataRow dr = PremiumTableWriteDental.NewRow();
        //                            dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";
        //                            PremiumTableWriteDental.Rows.Add(dr);
        //                        }
        //                    }
        //                }
        //                if (DentalCount == 1)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        int flag = 0;
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteDental.NewRow();
        //                                dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                PremiumTableWriteDental.Rows.Add(dr);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteDental.NewRow();
        //                                dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                PremiumTableWriteDental.Rows.Add(dr);
        //                            }
        //                        }
        //                    }
        //                }
        //                DentalCount++;
        //            }
        //            #endregion

        //            #region FillTable Vision
        //            if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
        //            {
        //                if (VisionCount == 0)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            DataRow dr = PremiumTableWriteVision.NewRow();
        //                            dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";

        //                            PremiumTableWriteVision.Rows.Add(dr);
        //                        }
        //                        else
        //                        {
        //                            DataRow dr = PremiumTableWriteVision.NewRow();
        //                            dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                            dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                            dr["Plan2_Rate"] = "";

        //                            PremiumTableWriteVision.Rows.Add(dr);
        //                        }
        //                    }
        //                }
        //                if (VisionCount == 1)
        //                {
        //                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
        //                    {
        //                        int flag = 0;
        //                        if (PremiumTable.Rows[i][1].ToString() == "8")
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteVision.NewRow();
        //                                dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";

        //                                PremiumTableWriteVision.Rows.Add(dr);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
        //                            {
        //                                if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
        //                                {
        //                                    PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                    flag = 1;
        //                                    break;
        //                                }
        //                            }
        //                            if (flag == 0)
        //                            {
        //                                DataRow dr = PremiumTableWriteVision.NewRow();
        //                                dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
        //                                dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
        //                                dr["Plan1_Rate"] = "";
        //                                PremiumTableWriteVision.Rows.Add(dr);
        //                            }
        //                        }
        //                    }
        //                }

        //                VisionCount++;
        //            }
        //            #endregion
        //        }

        //        #region Medical Monthly Premium

        //        int MediCalTableRowCounter = 11;
        //        int kl = 0;
        //        for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
        //        {
        //            if (kl > 0)
        //            {
        //                oWordDoc.Tables[Medicalindex].Rows.Add();
        //            }
        //            oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[d][0].ToString();
        //            oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[d][1].ToString();
        //            oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 3).Range.Text = PremiumTableWriteMedical.Rows[d][2].ToString();
        //            oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 4).Range.Text = PremiumTableWriteMedical.Rows[d][3].ToString();
        //            MediCalTableRowCounter++;
        //            kl++;
        //        }
        //        #endregion

        //        #region Dental Monthly Premium

        //        int DentalTableRowCounter = 0;

        //        for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
        //        {
        //            if (d == 1)
        //            {
        //                DentalTableRowCounter = 11;
        //                int kk = 0;
        //                for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
        //                {
        //                    if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
        //                    {
        //                        if (kk > 0)
        //                        {
        //                            oWordDoc.Tables[6].Rows.Add();
        //                        }
        //                        oWordDoc.Tables[6].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
        //                        oWordDoc.Tables[6].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
        //                        DentalTableRowCounter++;
        //                        kk++;
        //                    }
        //                }
        //            }
        //            if (d == 2)
        //            {
        //                DentalTableRowCounter = 11;
        //                int kk = 0;
        //                for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
        //                {
        //                    if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
        //                    {
        //                        if (kk > 0)
        //                        {
        //                            oWordDoc.Tables[7].Rows.Add();
        //                        }
        //                        oWordDoc.Tables[7].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
        //                        oWordDoc.Tables[7].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
        //                        DentalTableRowCounter++;
        //                        kk++;
        //                    }
        //                }
        //            }
        //        }
        //        #endregion

        //        #region Vision Monthly Premium

        //        int VisionTableRowCounter = 0;

        //        for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
        //        {
        //            if (d == 1)
        //            {
        //                VisionTableRowCounter = 13; //Start row 
        //                int kk = 0;
        //                for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
        //                {
        //                    if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
        //                    {
        //                        if (kk > 0)
        //                        {
        //                            oWordDoc.Tables[8].Rows.Add();
        //                        }
        //                        oWordDoc.Tables[8].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
        //                        oWordDoc.Tables[8].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
        //                        VisionTableRowCounter++;
        //                        kk++;
        //                    }
        //                }
        //            }
        //            if (d == 2)
        //            {
        //                VisionTableRowCounter = 13; //Start row 
        //                int kk = 0;
        //                for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
        //                {
        //                    if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
        //                    {
        //                        if (kk > 0)
        //                        {
        //                            oWordDoc.Tables[9].Rows.Add();
        //                        }
        //                        oWordDoc.Tables[9].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
        //                        oWordDoc.Tables[9].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
        //                        VisionTableRowCounter++;
        //                        kk++;
        //                    }
        //                }
        //            }
        //        }
        //        #endregion
        //    }

        //    catch (Exception ex)
        //    {
        //        //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 5;
                int DentalCount = 0;
                int VisionCount = 0;

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("ContributionTierID", typeof(string));

                    /* ---------- As per Nocole November 16, 2017 We need to only display Contribution instead of Rate section, So we commented Rate Section --------------- */
                    //for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    //{
                    //    if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                    //    {
                    //        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                    //        {
                    //            PremiumTable.Rows.Add();
                    //            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                    //            if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                    //            {
                    //                PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                    //            }
                    //            else
                    //            {
                    //                PremiumTable.Rows[premium_row_counter][1] = 0;
                    //            }
                    //            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                    //            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                    //            PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                    //            PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];

                    //            premium_row_counter++;

                    //        }
                    //    }
                    //}


                    int premium1_row_counter = 0;
                    DataTable PremiumTable1 = new DataTable();
                    PremiumTable1.Columns.Add("ContributionRateTierID", typeof(int));
                    PremiumTable1.Columns.Add("contributioncost", typeof(string));
                    PremiumTable1.Columns.Add("contributionDescription", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                PremiumTable1.Rows.Add();
                                PremiumTable1.Rows[premium1_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable1.Rows[premium1_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable1.Rows[premium1_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                premium1_row_counter++;
                            }
                        }

                    }

                    #endregion

                    //DataTable dt = new DataTable();
                    //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    //dt = PremiumTable.DefaultView.ToTable(true);
                    //PremiumTable = dt;

                    DataTable dtTableContribution = new DataTable();

                    PremiumTable1.DefaultView.Sort = "[ContributionRateTierID] asc";
                    dtTableContribution = PremiumTable1.DefaultView.ToTable(true);
                    PremiumTable1 = dtTableContribution;
                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    //dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString(); 
                                    dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    //dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }
                        }
                        if (index == 1)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable1.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (index == 2)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable1.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    //dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    //dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable1.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    //dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    //dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    //dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            for (int i = 0; i < PremiumTable1.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable1.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        //dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        //dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["RateHeader"] = PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable1.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable1.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable1.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable1.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable1.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 11;
                int kl = 0;
                for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
                {
                    if (kl > 0)
                    {
                        oWordDoc.Tables[Medicalindex].Rows.Add();
                    }
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[d][0].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[d][1].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 3).Range.Text = PremiumTableWriteMedical.Rows[d][2].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 4).Range.Text = PremiumTableWriteMedical.Rows[d][3].ToString();
                    MediCalTableRowCounter++;
                    kl++;
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        DentalTableRowCounter = 11;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[6].Rows.Add();
                                }
                                oWordDoc.Tables[6].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[6].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        DentalTableRowCounter = 11;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[7].Rows.Add();
                                }
                                oWordDoc.Tables[7].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[7].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion

                #region Vision Monthly Premium

                int VisionTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        VisionTableRowCounter = 13; //Start row 
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[8].Rows.Add();
                                }
                                oWordDoc.Tables[8].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[8].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        VisionTableRowCounter = 13; //Start row 
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[9].Rows.Add();
                                }
                                oWordDoc.Tables[9].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[9].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary STD  and LTD Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();

                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                int Start = 0;
                int End = 0;
                int Interval = 0;

                int rowCnt = 3;
                int ColumnCount = 0;
                int oldageBand = -1;
                int PlanCount = 0;
                DataTable dt = new DataTable();
                int tableNo = 0;
                bool isSTD = false;
                bool isLTD = false;

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower())
                        {
                            tableNo = 11;
                        }
                        else if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                        {
                            tableNo = 10;
                            PlanCount = 0;
                        }

                        PlanCount++;
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"] != null)
                        {
                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"] != null)
                        {
                            End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"] != null)
                        {
                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;
                        }
                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        int StartValue = Start;
                        int RowCount = 4;

                        if (Start > 0 && PlanCount == 1)
                        {
                            oWordDoc.Tables[tableNo].Cell(rowCnt, 1).Range.Text = "Under " + Start.ToString();

                            while (StartValue < End - 1)
                            {
                                oWordDoc.Tables[tableNo].Rows.Add();
                                if (StartValue == Start)
                                {
                                    oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                    StartValue = Start + Interval;
                                }
                                else
                                {
                                    oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                    StartValue = StartValue + Interval + 1;
                                }
                                RowCount++;
                            }
                            oWordDoc.Tables[tableNo].Rows.Add();
                            oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                            oWordDoc.Tables[tableNo].Rows.Add();
                            oWordDoc.Tables[tableNo].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        }

                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 2;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.STDPlanType)
                            {
                                ColumnCount = 2;
                                isSTD = true;
                            }

                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.LTDPlanType)
                            {
                                ColumnCount = 2;
                                isLTD = true;
                            }
                            if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                            {
                                RowCount++;
                            }
                            oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());
                            oWordDoc.Tables[tableNo].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                        }
                    }
                }

                //if (tableNo != 0)
                //{
                //    ColumnCount = oWordDoc.Tables[tableNo].Columns.Count;
                //    bool flag = false;
                //    if (oWordDoc.Tables[tableNo].Rows.Count < 5)
                //    {
                //        oWordDoc.Tables[tableNo].Delete();
                //    }
                //    else
                //    {
                //        while (ColumnCount > 1)
                //        {
                //            for (int i = rowCnt; i < oWordDoc.Tables[tableNo].Rows.Count; i++)
                //            {
                //                if (oWordDoc.Tables[tableNo].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
                //                {
                //                    flag = false;
                //                    break;
                //                }
                //                else
                //                {
                //                    flag = true;
                //                }
                //            }
                //            if (flag == true)
                //            {
                //                oWordDoc.Tables[tableNo].Columns[ColumnCount].Delete();
                //            }
                //            ColumnCount--;
                //        }
                //    }
                //}
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteFSASectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();
                DataRow[] foundRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "150");     //Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");     //Administration Services – Grace Period
                HashtableFSA.Add(3, "354");     //Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("MAIN_FSA_HRA"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(" ");
                                                    continue;
                                                }

                                                if (key == 3)
                                                {
                                                    if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (key == 1)
                                                {
                                                    if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (fieldName.Contains("FSA Plan Carrier"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Flexible Spending |" + PlanTable.Rows[rowindex]["Carrier"].ToString());
                                                }

                                                if (fieldName.Contains("HD"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("");
                                                    continue;
                                                }

                                                if (fieldName.Contains("FSA Carrier Website"))
                                                {
                                                    myMergeField.Select();
                                                    if (foundRows.Count() > 0)
                                                    {
                                                        oWordApp.Selection.TypeText("| " + foundRows[0]["Website"].ToString());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }

                                                if (fieldName.Contains("FSA Carrier Phone"))
                                                {
                                                    myMergeField.Select();
                                                    if (foundRows.Count() > 0)
                                                    {
                                                        oWordApp.Selection.TypeText("| " + foundRows[0]["PhoneNumber"].ToString());
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                            }
                                        }

                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        public void WriteHRASectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region merge fields
                            if (ddlHRAPlanName.SelectedIndex > 0)
                            {
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();
                                        if (fieldName.Contains("Medical – Health Reimbursement Arrangement Carrier"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                        if (fieldName.Contains("MAIN_FSA_HRA"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("HD"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("");
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        ///  Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteEAPSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                DataRow[] foundRows = null;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("EAP Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    }
                                    if (fieldName.Contains("EAP plan type"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString());
                                        ////oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["PlanType"].ToString());
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ProductDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();
                string ProductType_Id = string.Empty;
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            ProductType_Id = (ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"].ToString()).Trim();
                            if (ProductType_Id == "260")
                            {
                                int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                                int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                                int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                                for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                                {
                                    if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                                    {
                                        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                        {

                                            PremiumTable.Rows.Add();
                                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                            PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                            PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                            PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                            PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                            premium_row_counter++;
                                        }
                                    }
                                }

                                #region For EE Unismoker
                                oWordDoc.Tables[12].Cell(2, 1).Range.Text = "Under " + Start.ToString();
                                int StartValue = Start;
                                int RowCount = 3;
                                while (StartValue < End - 1)
                                {
                                    oWordDoc.Tables[12].Rows.Add();
                                    if (StartValue == Start)
                                    {
                                        oWordDoc.Tables[12].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                        StartValue = Start + Interval;
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[12].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                        StartValue = StartValue + Interval + 1;
                                    }
                                    RowCount++;
                                }
                                oWordDoc.Tables[12].Rows.Add();
                                oWordDoc.Tables[12].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                                oWordDoc.Tables[12].Rows.Add();
                                oWordDoc.Tables[12].Cell(RowCount + 1, 1).Range.Text = "Composite";

                                int ColumnCount = 0;
                                int oldageBand = -1;
                                DataTable dt = new DataTable();

                                PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                                dt = PremiumTable.DefaultView.ToTable(true);
                                PremiumTable = dt;
                                RowCount = 2;
                                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                {
                                    if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                    {
                                        ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                        oWordDoc.Tables[12].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                        RowCount++;
                                    }
                                }
                                #endregion
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;
                int count = 1;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(1, "188");     //Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(2, "186");     //Employee [Benefit Amount]
                //HashtableVoluntaryLifeADDBenifit.Add(2, "187");     //Employee [Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(3, "519");     //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(4, "516");     //Spouse[Benefit Amount]
                //HashtableVoluntaryLifeADDBenifit.Add(4, "518");     //Spouse[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(5, "104");     //Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(6, "106");     //Child(ren)[Benefit Amount] 
                //HashtableVoluntaryLifeADDBenifit.Add(6, "103");     //Child(ren)[Guarantee Issue Amount]

                #endregion

                string GuarenteeIssueAmtEmp = "";
                string GuarenteeIssueAmtSpouse = "";
                string GuarenteeIssueAmtChild = "";

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";
                string ProductType_Id = string.Empty;
                ArrayList arrProductType_Id = new ArrayList();

                for (int id = 0; id < ProductDS.Tables["ProductTable"].Rows.Count; id++)
                {
                    if (PlanTable.Rows[id]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[id]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[id]["productID"].ToString())
                        {
                            ProductType_Id = (ProductDS.Tables["ProductTable"].Rows[id]["productTypeID"].ToString()).Trim();
                            arrProductType_Id.Add(ProductType_Id);
                        }
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    OverallMaximumEmployee = "";
                    GuarenteeIssueAmtEmp = "";
                    OverallMaximumSpouse = "";
                    GuarenteeIssueAmtSpouse = "";
                    OverallMaximumChild = "";
                    GuarenteeIssueAmtChild = "";
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            ProductType_Id = (ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"].ToString()).Trim();

                            #region VoluntaryLifeADDBenifitTable
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: OverallMaximumEmployee = value; break;
                                            case 2: GuarenteeIssueAmtEmp = value; break;
                                            case 3: OverallMaximumSpouse = value; break;
                                            case 4: GuarenteeIssueAmtSpouse = value; break;
                                            case 5: OverallMaximumChild = value; break;
                                            case 6: GuarenteeIssueAmtChild = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Life_ADD_Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life Insurance");
                                        continue;
                                    }
                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Carrier1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Carrier1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                            continue;
                                        }
                                    }

                                    if (fieldName.Contains("Voluntary Life and AD&D Heading"))
                                    {
                                        myMergeField.Select();

                                        if (arrProductType_Id.Count > 1)
                                        {
                                            if (arrProductType_Id.Contains("260") && arrProductType_Id.Contains("280"))
                                            {
                                                oWordApp.Selection.TypeText("Voluntary Life and AD&D");
                                            }
                                        }
                                        if (arrProductType_Id.Count == 1 && arrProductType_Id.Contains("280"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary AD&D");
                                        }
                                        else if (arrProductType_Id.Count == 1 && arrProductType_Id.Contains("260"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Life");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Also"))
                                    {
                                        myMergeField.Select();

                                        if (arrProductType_Id.Count > 1)
                                        {
                                            if (arrProductType_Id.Contains("260") && arrProductType_Id.Contains("280"))
                                            {
                                                oWordApp.Selection.TypeText(" also ");
                                            }
                                        }
                                        if (arrProductType_Id.Count == 1 && arrProductType_Id.Contains("280"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }

                                        continue;
                                    }

                                    if (fieldName.Contains("Vol Rate Table"))
                                    {
                                        myMergeField.Select();
                                        if (ProductType_Id == "260")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Benefit Amt Employee"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtEmp))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtEmp);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Benefit Amt Employee"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtEmp))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtEmp);
                                            }
                                            continue;
                                        }
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Overall Max Employee"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumEmployee))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumEmployee);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Overall Max Employee"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumEmployee))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumEmployee);
                                            }
                                            continue;
                                        }
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Benefit Amt Spouse"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtSpouse))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtSpouse);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Benefit Amt Spouse"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtSpouse))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtSpouse);
                                            }
                                            continue;
                                        }
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Overall Max Spouse"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumSpouse))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumSpouse);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Overall Max Spouse"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumSpouse))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumSpouse);
                                            }
                                            continue;
                                        }
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Benefit Amt Children"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtChild))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtChild);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Benefit Amt Children"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(GuarenteeIssueAmtChild))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(GuarenteeIssueAmtChild);
                                            }
                                            continue;
                                        }
                                    }

                                    if (ProductType_Id == "280")
                                    {
                                        if (fieldName.Contains("Voluntary Life AD&D Overall Max Children"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumChild))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumChild);
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Voluntary Life Overall Max Children"))
                                        {
                                            myMergeField.Select();
                                            if (string.IsNullOrEmpty(OverallMaximumChild))
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(OverallMaximumChild);
                                            }
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        /// <param name="ddlBRC">DropDownList ddlBRC Object</param>
        public void WriteNoticeSectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlBRC, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                //For word page break-02 July 2014
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            // code added by vaibhav and shravan for spanish chip notice 
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                //For word page break-02 July 2014
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //if (ddlChipNotice.SelectedIndex == 1)
                                //{
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                //}
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Addev  by Vaibhav
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //if (ddlChipNotice.SelectedIndex == 1)
                                //{
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                //}
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                if (ddlBRC.SelectedIndex > 1)
                                {
                                    oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                                }
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;


                // Call common function to write the contact information page fields
                // Commented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
                //Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        public void WriteHSASectionToTemplate4(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;

                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string value = "";

                Hashtable HashtableHSA = new Hashtable();
                #region HashtableHSA
                HashtableHSA.Add(1, "635");//General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSA.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region HSABenifitTable

                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value; break;
                                            case 2: Max_Annual_Contribution_Family1 = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("HSA Carrier1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Main_HSA"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("IRS Employee Only coverage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("IRS Family Coverage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}