﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Runtime.InteropServices;


namespace BenefitPointSummaryPortal.View
{
    public partial class VolumeCalculator : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        DataSet BenefitDS = new DataSet();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        ConstantValue cv = new ConstantValue();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        private static readonly string DeliverableCategory = "Analytics";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        DataTable PlanInfoTable = new DataTable();
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);

                if (!IsPostBack)
                {
                    div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                    TitleSpan.InnerText = "Volume Calculator";
                    mvVolumeCalculator.ActiveViewIndex = 0;

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    Activity = "Volume Calculator";
                    Activity_Group = "Analytics";

                    txtsearch.Focus();
                    chkItemSelect_CheckedChanged(null, null);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                chkItemSelect_CheckedChanged(null, null);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();

                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                chkItemSelect_CheckedChanged(null, null);
            }
            catch (Exception ex)
            {

                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                Hashtable htSortedPlanList = new Hashtable();
                htSortedPlanList = GetVolumeCalculatorPlanList();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                List<Plan> PlanList = new List<Plan>();
                List<Plan> commonPlanList = new List<Plan>();
                Session["PlanList"] = null;
                SessionId = Session["SessionId"].ToString();
                if (ddlClient.SelectedIndex > 0)
                {
                    PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                }
                Session["PlanList"] = PlanList;

                if (PlanList != null)
                {
                    if (PlanList.Count > 0)
                    {
                        if (rdlPlan.SelectedIndex == 0)
                        {

                            foreach (Plan item in PlanList)
                            {
                                if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                {
                                    if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }

                        }
                        if (rdlPlan.SelectedIndex == 1)
                        {
                            foreach (Plan item in PlanList)
                            {
                                if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                {
                                    commonPlanList.Add(item);
                                }
                            }
                        }

                        List<Plan> lstPlanList = new List<Plan>();
                        lstPlanList = (from l in commonPlanList
                                       orderby l.ProductTypeId ascending
                                       select l).ToList();

                        grdPlans.DataSource = lstPlanList;
                        grdPlans.DataBind();


                        if (commonPlanList.Count > 0)
                        {
                            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                            ChkBoxHeader.Checked = true;
                            foreach (GridViewRow row in grdPlans.Rows)
                            {
                                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                                ChkBoxRows.Checked = true;
                            }
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        else
                        {
                            string script = "alert(\"No active plans.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                    else
                    {
                        string script = "alert(\"No plans for selected client.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
                else
                {
                    string script = "alert(\"No plans for selected client.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                }
                chkItemSelect_CheckedChanged(null, null);
            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                DataTable PlanInfoTable = GetPlanInfoTable();
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                    ddlClient.Focus();
                    return;
                }

                if (PlanInfoTable.Rows.Count == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select atleast one plan from Plan Grid')</script>");
                    return;
                }



                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType.ToLower() && ddlSTDOptions.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Disability Volume Calculation Option for STD plan')</script>");
                        ddlSTDOptions.Focus();
                        return;
                    }
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType.ToLower() && ddlLTDOptions.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Disability Volume Calculation Options for LTD plan')</script>");
                        ddlLTDOptions.Focus();
                        return;
                    }
                }

                sd.BuildBenefitSummaryTable();
                sd.BuildBenifitSummaryStructureTable();
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                BenefitDS = sd.GetBenefitSummary_V2(PlanInfoTable, SessionId);

                Create_VolumePages(PlanInfoTable);

                #region ------- Code for Add Activity Log --------

                string AdditionalCrtieriaOption_1 = string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DictDepartment = sd.getDepartmentDetails();
                sd.BuildAccountTable();
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
                DataSet AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                DataSet AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, DeliverableCategory, Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
               
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                chkItemSelect_CheckedChanged(null, null);
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds_Pilot();
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 5))
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[9].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
                            }


                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }



                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }


                            rowCount++;
                        }
                    }//Foreach Close

                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        public string GetPlanName(int PlanTypeId)
        {
            string _planName = string.Empty;

            try
            {

                // Life and AD&D
                foreach (var item in CommonFunctionsBS.LifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LifeADDLOC;
                    }
                }

                // STD
                foreach (var item in CommonFunctionsBS.STDPlanTypeList)
                {
                    if (CommonFunctionsBS.STDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.STDLOC;
                    }
                }

                // Voluntary Life and AD&D
                foreach (var item in CommonFunctionsBS.VoluntaryLifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria;
                    }
                }

                // LTD
                foreach (var item in CommonFunctionsBS.LTDPlanTypeList)
                {
                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LTDLOC;
                    }
                }


                // Group Term Life
                foreach (var item in CommonFunctionsBS.GroupTermLifePlanTypeList)
                {
                    if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.GroupTermLifePlanType;
                    }
                }

                //// AD&D
                //foreach (var item in LifeADDPlanTypeList)
                //{
                //    if (LifeADDPlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.ADD;
                //    }
                //}

                // Additional Products

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _planName;
        }
        private Hashtable GetVolumeCalculatorPlanList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            return htSortedPlanList;
        }
        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                System.Web.UI.WebControls.CheckBox ChkBoxRows = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            chkItemSelect_CheckedChanged(null, null);
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }
        protected void Create_VolumePages(DataTable PlanInfoTable)
        {
            Dictionary<string, List<int>> dictBenefitSummaries = new Dictionary<string, List<int>>();
            WriteVolumeCalculator wr = new WriteVolumeCalculator();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            string SheetName = string.Empty;
            try
            {
                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/VolumeCalculator/Documents/Templates/VolumeCalculator_Templat.xlsx");
                myExcelApp.DisplayAlerts = false;

                object savefilename = Server.MapPath("~/Files/VolumeCalculator/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/VolumeCalculator/Documents/Templates/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/VolumeCalculator/Documents/Templates/Downloads/"));
                }
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;
                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                List<string> DeleteSheetNames = new List<string>() { "Life Flat Benefit", "Life Multiple of Salary", "STD Covered Benefit", "STD Covered Payroll", "LTD Covered Benefit", "LTD Covered Payroll" };
                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    int BenefitSummaryId = 0;
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        int.TryParse(dr["SummaryID"].ToString(), out BenefitSummaryId);
                        if (BenefitSummaryId != 0)
                        {
                            if (IsFlatLifeADDPlan(BenefitSummaryId))
                            {
                                if (DeleteSheetNames.Contains("Life Flat Benefit"))
                                    DeleteSheetNames.Remove("Life Flat Benefit");
                                if (!dictBenefitSummaries.ContainsKey("Life_Flat_Benefit"))
                                    dictBenefitSummaries["Life_Flat_Benefit"] = new List<int>();
                                dictBenefitSummaries["Life_Flat_Benefit"].Add(BenefitSummaryId);
                            }
                            else
                            {
                                if (DeleteSheetNames.Contains("Life Multiple of Salary"))
                                    DeleteSheetNames.Remove("Life Multiple of Salary");
                                if (!dictBenefitSummaries.ContainsKey("Life_Multiple_Salary"))
                                    dictBenefitSummaries["Life_Multiple_Salary"] = new List<int>();
                                dictBenefitSummaries["Life_Multiple_Salary"].Add(BenefitSummaryId);
                            }
                        }
                    }
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType.ToLower())
                    {
                        int.TryParse(dr["SummaryID"].ToString(), out BenefitSummaryId);
                        if (BenefitSummaryId != 0)
                        {
                            if (IsFlatLifeADDPlan(BenefitSummaryId))
                            {
                                if (DeleteSheetNames.Contains("Life Flat Benefit"))
                                    DeleteSheetNames.Remove("Life Flat Benefit");
                                if (!dictBenefitSummaries.ContainsKey("Life_Flat_Benefit"))
                                    dictBenefitSummaries["Life_Flat_Benefit"] = new List<int>();
                                dictBenefitSummaries["Life_Flat_Benefit"].Add(BenefitSummaryId);
                            }
                            else
                            {
                                if (DeleteSheetNames.Contains("Life Multiple of Salary"))
                                    DeleteSheetNames.Remove("Life Multiple of Salary");
                                if (!dictBenefitSummaries.ContainsKey("Life_Multiple_Salary"))
                                    dictBenefitSummaries["Life_Multiple_Salary"] = new List<int>();
                                dictBenefitSummaries["Life_Multiple_Salary"].Add(BenefitSummaryId);
                            }
                        }
                    }
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType.ToLower())
                    {
                        int.TryParse(dr["SummaryID"].ToString(), out BenefitSummaryId);
                        if (BenefitSummaryId != 0)
                        {
                            switch (ddlSTDOptions.SelectedValue)
                            {
                                case "CoveredBenefit":
                                    if (DeleteSheetNames.Contains("STD Covered Benefit"))
                                        DeleteSheetNames.Remove("STD Covered Benefit");
                                    break;
                                case "CoveredPayroll":
                                    if (DeleteSheetNames.Contains("STD Covered Payroll"))
                                        DeleteSheetNames.Remove("STD Covered Payroll");
                                    break;
                            }

                            if (!dictBenefitSummaries.ContainsKey("STD_Covered_Benefit"))
                                dictBenefitSummaries["STD_Covered_Benefit"] = new List<int>();
                            dictBenefitSummaries["STD_Covered_Benefit"].Add(BenefitSummaryId);
                        }
                    }
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        int.TryParse(dr["SummaryID"].ToString(), out BenefitSummaryId);
                        if (BenefitSummaryId != 0)
                        {
                            switch (ddlLTDOptions.SelectedValue)
                            {
                                case "CoveredBenefit":
                                    if (DeleteSheetNames.Contains("LTD Covered Benefit"))
                                        DeleteSheetNames.Remove("LTD Covered Benefit");
                                    break;
                                case "CoveredPayroll":
                                    if (DeleteSheetNames.Contains("LTD Covered Payroll"))
                                        DeleteSheetNames.Remove("LTD Covered Payroll");
                                    break;
                            }

                            if (!dictBenefitSummaries.ContainsKey("LTD_Covered_Benefit"))
                                dictBenefitSummaries["LTD_Covered_Benefit"] = new List<int>();

                            dictBenefitSummaries["LTD_Covered_Benefit"].Add(BenefitSummaryId);
                        }
                    }
                }
                if (PlanInfoTable.Rows.Count > 0)
                {
                    wr.WriteActiveEnrollmentTally(myExcelApp, myWorkbook, "Active Enrollment Tally", ddlClient.SelectedItem.Text, BenefitDS);
                    #region LIFE AD&D and Group Term Plans
                    Dictionary<int, int> dictBenefitSummaryMap = new Dictionary<int, int>();
                    if (dictBenefitSummaries.ContainsKey("Life_Flat_Benefit"))
                    {
                        dictBenefitSummaryMap = wr.CreateLifeFlatBenefitStructure(myExcelApp, myWorkbook, "Life Flat Benefit", dictBenefitSummaries["Life_Flat_Benefit"]);
                        foreach (int BenefitSummatyId in dictBenefitSummaries["Life_Flat_Benefit"])
                        {
                            DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                            if (drBenefitRow != null)
                            {
                                string SummaryName = Convert.ToString(drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&"));
                                wr.WriteLifeFlatBenifites(myExcelApp, myWorkbook, "Life Flat Benefit", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS);
                            }
                        }
                    }
                    if (dictBenefitSummaries.ContainsKey("Life_Multiple_Salary"))
                    {
                        dictBenefitSummaryMap = wr.CreateLifeMultipleSalaryStructure(myExcelApp, myWorkbook, "Life Multiple of Salary", dictBenefitSummaries["Life_Multiple_Salary"]);
                        foreach (int BenefitSummatyId in dictBenefitSummaries["Life_Multiple_Salary"])
                        {
                            DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                            if (drBenefitRow != null)
                            {
                                string SummaryName = Convert.ToString(drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&"));


                                wr.WriteLifeMultipleOfSalary(myExcelApp, myWorkbook, "Life Multiple of Salary", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS);
                            }
                        }
                    }
                    #endregion
                    #region STD
                    if (dictBenefitSummaries.ContainsKey("STD_Covered_Benefit"))
                    {
                        if (ddlSTDOptions.SelectedValue == "CoveredBenefit")
                        {
                            dictBenefitSummaryMap = wr.CreateSTDCoverdBenifitsSruture(myExcelApp, myWorkbook, "STD Covered Benefit", dictBenefitSummaries["STD_Covered_Benefit"]);
                            foreach (int BenefitSummatyId in dictBenefitSummaries["STD_Covered_Benefit"])
                            {
                                DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                                if (drBenefitRow != null)
                                {
                                    string SummaryName = drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&");;
                                    wr.WriteSTDCoverdBenifits(myExcelApp, myWorkbook, "STD Covered Benefit", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS, true);
                                }
                            }
                        }
                        else if (ddlSTDOptions.SelectedValue == "CoveredPayroll")
                        {
                            dictBenefitSummaryMap = wr.CreateSTDCoverdPayrollruture(myExcelApp, myWorkbook, "STD Covered Payroll", dictBenefitSummaries["STD_Covered_Benefit"]);
                            foreach (int BenefitSummatyId in dictBenefitSummaries["STD_Covered_Benefit"])
                            {
                                DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                                if (drBenefitRow != null)
                                {
                                    string SummaryName = drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&");;
                                    wr.WriteSTDCoverdPayroll(myExcelApp, myWorkbook, "STD Covered Payroll", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS, true);
                                }
                            }
                        }
                    }
                    #endregion
                    #region LTD
                    if (dictBenefitSummaries.ContainsKey("LTD_Covered_Benefit"))
                    {
                        if (ddlLTDOptions.SelectedValue == "CoveredBenefit")
                        {
                            dictBenefitSummaryMap = wr.CreateLTDCoverdBenifitsSruture(myExcelApp, myWorkbook, "LTD Covered Benefit", dictBenefitSummaries["LTD_Covered_Benefit"]);
                            foreach (int BenefitSummatyId in dictBenefitSummaries["LTD_Covered_Benefit"])
                            {
                                DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                                if (drBenefitRow != null)
                                {
                                    string SummaryName = drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&");
                                    wr.WriteLTDCoverdBenifits(myExcelApp, myWorkbook, "LTD Covered Benefit", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS, true);
                                }
                            }
                        }
                        else if (ddlLTDOptions.SelectedValue == "CoveredPayroll")
                        {
                            dictBenefitSummaryMap = wr.CreateLTDCoverdPayrollruture(myExcelApp, myWorkbook, "LTD Covered Payroll", dictBenefitSummaries["LTD_Covered_Benefit"]);
                            foreach (int BenefitSummatyId in dictBenefitSummaries["LTD_Covered_Benefit"])
                            {
                                DataRow drBenefitRow = PlanInfoTable.Select("SummaryID = '" + BenefitSummatyId.ToString() + "'").FirstOrDefault();
                                if (drBenefitRow != null)
                                {
                                    string SummaryName = drBenefitRow["SummaryName"].ToString().Replace("&amp;", "&");
                                    wr.WriteLTDCoverdPayroll(myExcelApp, myWorkbook, "LTD Covered Payroll", SummaryName, BenefitSummatyId, dictBenefitSummaryMap[BenefitSummatyId], BenefitDS, true);
                                }
                            }
                        }
                    }
                    #endregion
                }


                wr.HideWorkSheets(myExcelApp, myWorkbook, DeleteSheetNames);
                Microsoft.Office.Interop.Excel.Worksheet sheet = (Microsoft.Office.Interop.Excel.Worksheet)myExcelApp.Worksheets["Active Enrollment Tally"];
                sheet.Select(Type.Missing);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }

                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                throw ex;
            }
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected void chkItemSelect_CheckedChanged(object sender, EventArgs e)
        {
            if (sender != null)
            {
                CheckBox chkItem = sender as CheckBox;
                if (chkItem.Checked == false)
                {
                    CheckBox objCheckbox = grdPlans.HeaderRow.FindControl("chkHeaderSelect") as CheckBox;
                    if (objCheckbox != null)
                        objCheckbox.Checked = false;
                }
            }
            DataTable dtblPlan = GetPlanInfoTable();
            bool IsSTDExists = false;
            bool IsLTDExists = false;

            tdSTDLabel.Style.Add("display", "none");
            tdSTDControl.Style.Add("display", "none");
            tdLTDLabel.Style.Add("display", "none");
            tdLTDControl.Style.Add("display", "none");
            tblCalculationOptions.Style.Add("display", "none");

            ddlLTDOptions.SelectedValue = "Select";
            ddlSTDOptions.SelectedValue = "Select";


            if (dtblPlan != null && dtblPlan.Rows.Count > 0)
            {
                foreach (DataRow dr in dtblPlan.Rows)
                {
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.STDPlanType.ToLower())
                    {
                        IsSTDExists = true;
                    }
                    if (dr["PlanType"].ToString().Trim().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        IsLTDExists = true;
                    }
                }
                if (IsSTDExists)
                {
                    tblCalculationOptions.Style.Add("display", "");
                    tblCalculationOptions.Rows[1].Cells[0].Style.Add("display", "");
                    tblCalculationOptions.Rows[1].Cells[1].Style.Add("display", "");
                    // tdSTDLabel.Style.Add("display", "");
                    //tdSTDControl.Style.Add("display", "");
                }
                if (IsLTDExists)
                {
                    tblCalculationOptions.Style.Add("display", "");
                    //tdLTDLabel.Style.Add("display", "");
                    //tdLTDControl.Style.Add("display", "");
                    tblCalculationOptions.Rows[1].Cells[2].Style.Add("display", "");
                    tblCalculationOptions.Rows[1].Cells[3].Style.Add("display", "");
                }
            }

        }
        private bool IsFlatLifeADDPlan(int BenefitSummaryId)
        {
            bool IsFlatBenefit = false;
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            DataRow drBenefitValues_BenifitAmount = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryId + " AND attributeID = 186").FirstOrDefault();
            string BenefitValue_UOM = drBenefitValues_BenifitAmount["UOM"].ToString();
            if (drBenefitValues_BenifitAmount != null && BenefitValue_UOM == "dollars")
            {
                IsFlatBenefit = true;
            }
            return IsFlatBenefit;
        }
    }
}