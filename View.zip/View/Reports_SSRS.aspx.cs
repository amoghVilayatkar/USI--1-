﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using Microsoft.Office.Interop.Word;
using Microsoft.Reporting.WebForms;
using System.IO;
using System.Web;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace BenefitPointSummaryPortal.View
{
    public partial class Reports_SSRS : System.Web.UI.Page
    {

        #region Global Variable
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        DataSet AccountDS = new DataSet();
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        DataSet EligibilityDS = new DataSet();
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        Timeline_Constant tc = new Timeline_Constant();
        string temperror = "cs";

        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList MedicalBenefitColumnId_Tier3 = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList();
        ArrayList WellnessBenefitColumnIdList = new ArrayList();
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        static DataTable PlanInfoTable = new DataTable();
        static DataTable dtPlanContactInfo = new DataTable();

        //static List<int> MedicalPlanTypeList = new List<int>();
        //static List<int> DentalPlanTypeList = new List<int>();
        //static List<int> VisionPlanTypeList = new List<int>();
        //static List<int> LifeADDPlanTypeList = new List<int>();
        //static List<int> STDPlanTypeList = new List<int>();
        //static List<int> LTDPlanTypeList = new List<int>();
        //static List<int> VoluntaryLifeADDPlanTypeList = new List<int>();
        //static List<int> EAPPlanTypeList = new List<int>();
        //static List<int> FSAPlanTypeList = new List<int>();
        //static List<int> HRAPlanTypeList = new List<int>();
        //static List<int> HSAPlanTypeList = new List<int>();
        //static List<int> WellnessPlanTypeList = new List<int>();
        //static List<int> GroupTermLifePlanTypeList = new List<int>();
        //static List<int> ADNDPlanTypeList = new List<int>();
        //static List<int> AdditionalProductsPlanTypeList = new List<int>();
        SummaryDetail sd = new SummaryDetail();
        string selectedColor = string.Empty;

        #endregion
        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                //if (Session["Summary"].ToString() == "Reports2_RenewalStatusReport")
                //{  TitleSpan.InnerText = Session["Title"].ToString();
                TitleSpan.InnerText = "Reports";
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                Session["SessionId"] = SessionId;
                btnReportCreate.Visible = true;
                btnReportReset.Visible = true;
                Activity = "Renewal Status Report";
                Activity_Group = "Reports";

                List<Office> OfficeList = new List<Office>();
                OfficeList = bp.FindOffice(SessionId, "");
                Session["Reports_Office_List"] = OfficeList;

                var lregion = (from s in OfficeList orderby s.RegionName ascending select s.RegionName).Distinct();

                ddlRegion.DataSource = lregion;
                ddlRegion.DataBind();
                ddlRegion.Items.Insert(0, new ListItem("Select", "0"));

                ////cblistOffice.DataSource = OfficeList;
                ////cblistOffice.DataBind();

                //Reading the data from Producer XML file and bind to ddlProducerTeam dropdown
                DataSet procedure = new DataSet();
                procedure.ReadXml(Server.MapPath("~/Common/Reports/Producer.xml"));
                ddlProducerTeam.DataSource = procedure;
                ddlProducerTeam.DataTextField = "description";
                ddlProducerTeam.DataValueField = "id";
                ddlProducerTeam.DataBind();

                ddlProducerTeam.SelectedValue = "1111";
            }
            //else
            //{
            //    btnReportCreate.Visible = false;
            //    btnReportReset.Visible = false;
            //}
            //}
            //ShowReport();
        }

        protected void ddlRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Office> OfficeList = new List<Office>();
                OfficeList = (List<Office>)Session["Reports_Office_List"];

                if (ddlRegion.SelectedValue != "-1" && ddlRegion.SelectedValue != "0" && ddlRegion.SelectedValue != "")
                {
                    var loffice = from s in OfficeList where s.RegionName == ddlRegion.SelectedItem.Text select s;
                    cblistOffice.DataSource = loffice;
                    cblistOffice.DataBind();
                }
                //else if (ddlRegion.SelectedValue == "0")
                //{
                //    cblistOffice.DataSource = null;
                //    cblistOffice.DataBind();
                //}
                else
                {
                    cblistOffice.Items.Clear();
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            ServerReport serverReport = rptViewer.ServerReport;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri("http://usi-sq-10/ReportServer_ADPConcur");
            serverReport.ReportPath = "/BP/BP Renewal Status Report";

            string[] values_Regions = new string[] { "Midwest" };
            string[] values_Offices = new string[] { "Cleveland", "Chicago" };


            ReportParameter[] Param = new ReportParameter[6];
            Param[0] = new ReportParameter("REGIONS", values_Regions);
            Param[1] = new ReportParameter("OFFICES", values_Offices);
            Param[2] = new ReportParameter("DATETYPE", "CD");
            Param[3] = new ReportParameter("PRODUCERTEAMS", "%");
            Param[4] = new ReportParameter("DATEFROM", "04/01/2017");
            Param[5] = new ReportParameter("DATETO", "04/12/2017");

            //ReportParameter[] Param = new ReportParameter[6];
            //Param[0] = new ReportParameter("REGIONS", "8071");
            //Param[1] = new ReportParameter("OFFICES", "Cleveland");
            //Param[2] = new ReportParameter("DATETYPE", "CD");
            //Param[3] = new ReportParameter("PRODUCERTEAMS", "%");
            //Param[4] = new ReportParameter("DATEFROM", "04/01/2017");
            //Param[5] = new ReportParameter("DATETO", "04/12/2017");

            rptViewer.ServerReport.GetParameters();
            rptViewer.ShowParameterPrompts = true;
            rptViewer.ServerReport.SetParameters(Param);


            //Warning[] warnings;
            //string[] streamIds;
            //string mimeType = string.Empty;
            //string encoding = string.Empty;
            //string extension = string.Empty;
            //string Title = "UserList " + Convert.ToString(DateTime.Now);
            //byte[] bytes = rptViewer.LocalReport.Render("EXCEL", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

            //Response.Buffer = true;
            //Response.Clear();
            //Response.ContentType = mimeType;
            //Response.AddHeader("content-disposition", "attachment; filename=" + Title + "." + extension);
            //Response.BinaryWrite(bytes); // create the file
            //Response.Flush();


            rptViewer.ServerReport.Refresh();
        }

        protected void btnReportCreate_Click(object sender, EventArgs e)
        {
            SessionId = Session["SessionId"].ToString();
            bool flag = true;
            try
            {
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                //DateTime.TryParse(txtDateFrom.Text, out dtFrom);
                //DateTime.TryParse(txtDateTo.Text, out dtTo);

                DateTime.TryParseExact(txtDateFrom.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtFrom);
                DateTime.TryParseExact(txtDateTo.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtTo);

                if (ddlReportStyle.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Report.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlReportStyle.Focus();
                    flag = false;
                    return;
                }

                if (ddlRegion.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Region.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlRegion.Focus();
                    flag = false;
                    return;
                }

                if (cblistOffice.Items.Count > 0)
                {
                    int cnt = 0;
                    for (int i = 0; i < cblistOffice.Items.Count; i++)
                    {
                        if (cblistOffice.Items[i].Selected == true)
                        {
                            cnt++;
                        }
                    }

                    if (cnt == 0)
                    {
                        string script = "alert(\"Please select Office(s).\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        flag = false;
                        return;
                    }
                }

                if (ddlDateType.SelectedValue == "0")
                {
                    string script = "alert(\"Please select Date Type.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    ddlDateType.Focus();
                    flag = false;
                    return;
                }



                if (ddlDateType.SelectedValue == "CD")
                {
                    if (txtDateFrom.Text != "")
                    {
                        if (DateTime.MinValue == dtFrom)
                        {
                            txtDateFrom.Focus();
                            string script = "alert(\"'Date From' should be in 'mm/dd/yyyy' format.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            return;
                        }

                        if (dtFrom > DateTime.Today)
                        {
                            txtDateFrom.Focus();
                            string script = "alert(\"'Date From' should not be greater than today's date.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            return;
                        }
                    }
                }

                if (txtDateFrom.Text != "")
                {
                    if (DateTime.MinValue == dtFrom)
                    {
                        txtDateFrom.Focus();
                        string script = "alert(\"'Date From' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (txtDateFrom.Text.Trim() != "" && txtDateTo.Text.Trim() == "")
                {
                    txtDateTo.Focus();
                    string script = "alert(\"Please enter 'Date To'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateFrom.Text.Trim() == "" && txtDateTo.Text.Trim() != "")
                {
                    txtDateFrom.Focus();
                    string script = "alert(\"Please enter 'Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateFrom.Text == "" && txtDateTo.Text == "")
                {
                    txtDateFrom.Focus();
                    string script = "alert(\"' Please enter 'Date From' and 'Date To' '\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                    return;
                }
                if (txtDateTo.Text != "")
                {
                    if (DateTime.MinValue == dtTo)
                    {
                        txtDateTo.Focus();
                        string script = "alert(\"'Date To' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (dtTo < dtFrom)
                {
                    string script = "alert(\"'Date To' should be greater than 'Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                    return;
                }

                if (flag == true)
                {
                    // Get the Account Office and Account Region for the selected client
                    ////Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    tblRptViewer.Visible = true;
                    if (Convert.ToString(Session["Summary"]) == "Reports1_MeetingTrackingReport")
                    {
                        //  CreateReports1_MeetingTrackingReport(tc.Timeline1_SubjectID, SessionId);
                    }
                    if (Convert.ToString(Session["Summary"]) == "Reports2_RenewalStatusReport")
                    {
                        //CreateReports2_RenewalStatusReport();

                        SSRS_Report();


                        //Warning[] warnings;
                        //string[] streamids;
                        //string mimeType, encoding, extension, deviceInfo, filename; ;

                        //deviceInfo = "True";
                        //byte[] bytes = rptViewer.ServerReport.Render("Excel", null, out mimeType, out encoding, out extension, out streamids, out warnings);
                        //filename = string.Format("{0}.{1}", "ExportToExcel", "xls");

                        //Response.Buffer = true;
                        //////Response.Clear();
                        //////Response.AddHeader("Content-Disposition", "attachment;filename=" + filename);
                        //////Response.AddHeader("Content-Length", file.Length.ToString());
                        //////Response.ContentType = mimeType;
                        ////////Response.Headers.Clear();
                        ////Creatr PDF file on disk
                        //string pdfPath = @"D:\ExportToExcel.xls";       // Path to export Report.

                        ////System.IO.FileStream pdfFile = new System.IO.FileStream(pdfPath, System.IO.FileMode.Create);
                        ////pdfFile.Write(bytes, 0, bytes.Length);
                        ////pdfFile.Close();
                        ////Response.Flush();
                        ////Response.End();

                        //FileStream fs = null;
                        //BinaryReader br = null;
                        ////byte[] data1 = null;
                        //if (File.Exists(pdfPath.ToString()))
                        //{
                        //    FileInfo file = new FileInfo(pdfPath.ToString());
                        //    fs = new FileStream(pdfPath.ToString(), FileMode.Open, FileAccess.Read, FileShare.Read);
                        //    br = new BinaryReader(fs, System.Text.Encoding.Default);
                        //    bytes = new byte[Convert.ToInt32(fs.Length)];
                        //    br.Read(bytes, 0, bytes.Length);

                        //    Response.Clear();
                        //    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        //    Response.AddHeader("content-disposition", "attachment; filename=ActivityReport-" + DateTime.Now.ToShortDateString() + ".xls");
                        //    Response.AddHeader("Content-Length", file.Length.ToString());
                        //    Response.BinaryWrite(bytes);
                        //    Response.Flush();
                        //    Response.Close();
                        //}

                    }
                }
            }
            catch (System.Threading.ThreadAbortException)
            {
                // To Handle HTTP Exception "Cannot redirect after HTTP headers have been sent".
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReportReset_Click(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                ddlRegion.SelectedValue = "0";
                cblistOffice.Items.Clear();
                ddlDateType.SelectedValue = "0";
                txtDateFrom.Text = "";
                txtDateTo.Text = "";
                tblRptViewer.Visible = false;
                ddlProducerTeam.SelectedValue = "1111";
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlReportStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Office> OfficeList = new List<Office>();
                OfficeList = bp.FindOffice(Convert.ToString(Session["SessionId"]), "");
                Session["Reports_Office_List"] = OfficeList;

                var lregion = (from s in OfficeList orderby s.RegionName ascending select s.RegionName).Distinct();

                ddlRegion.DataSource = lregion;
                ddlRegion.DataBind();
                ddlRegion.Items.Insert(0, new ListItem("Select", "0"));
                Activity_Group = "Reports";

                // Meeting Tracking Report
                if (ddlReportStyle.SelectedValue == "2")
                {
                    Session["Summary"] = "Reports1_MeetingTrackingReport";
                    Activity = "Meeting Tracking Report";
                }
                // Renewal Status Report
                else if (ddlReportStyle.SelectedValue == "1")
                {
                    Session["Summary"] = "Reports2_RenewalStatusReport";
                    Activity = "Renewal Status Report";
                }
                else if (ddlReportStyle.SelectedValue == "0") // Select
                {
                    ddlRegion.SelectedValue = "0";
                    cblistOffice.Items.Clear();
                    ddlDateType.SelectedValue = "0";
                    txtDateFrom.Text = "";
                    txtDateTo.Text = "";
                }

                //Reading the data from Producer XML file and bind to ddlProducerTeam dropdown
                DataSet procedure = new DataSet();
                procedure.ReadXml(Server.MapPath("~/Common/Reports/Producer.xml"));
                ddlProducerTeam.DataSource = procedure;
                ddlProducerTeam.DataTextField = "description";
                ddlProducerTeam.DataValueField = "id";
                ddlProducerTeam.DataBind();

                ddlProducerTeam.SelectedValue = "1111";
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Summary Template 2
        /// </summary>
        protected void CreateReports2_RenewalStatusReport( )
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            try
            {

               //SessionId = Session["SessionId"].ToString();


                //myExcelApp = new Excel.Application();

                //myExcelApp.Visible = false;

                //Object missing = System.Reflection.Missing.Value;

                //string myPath = Server.MapPath("~/Files/Reports/Documents/Templates/Reports2_Renewal Status Report.xlsx");

                //myExcelApp.DisplayAlerts = false;

                //myWorkbook = myExcelApp.Workbooks.Open(myPath);
                //myWorksheet = myWorkbook.ActiveSheet;

                //object savefilename = Server.MapPath("~/Files/Reports/Documents/Templates/Report2/NewDocument" + System.DateTime.Now.Year.ToString() +
                //    System.DateTime.Now.Month.ToString() +
                //                     System.DateTime.Now.Day.ToString() +
                //                      System.DateTime.Now.Hour.ToString() +
                //                       System.DateTime.Now.Minute.ToString() +
                //                      System.DateTime.Now.Second.ToString() +
                //                      System.DateTime.Now.Millisecond.ToString() +
                //                     ".xlsx");

                //if (!Directory.Exists(Server.MapPath("~/Files/Reports/Documents/Templates/Report2")))
                //{
                //    Directory.CreateDirectory(Server.MapPath("~/Files/Reports/Documents/Templates/Report2"));
                //}

                //myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                //  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                //RenewalStatusReport_V2 wr = new RenewalStatusReport_V2();
                //wr.WriteFieldToReports2(myWorksheet, SubjectID, SessionId, cblistOffice, ddlProducerTeam, _fromdate, _todate, filteredAccountList, ddlDateType);

                SSRS_Report();
                
                //myWorkbook.Save();
                //myWorkbook.Close(true, Type.Missing, Type.Missing);
                //myExcelApp.Quit();

                DownloadFileNew_Excel();

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office);

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        /// <summary>
        /// To download Report File in Excel format.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        public void DownloadFileNew_Excel()
        {
            try
            {
                Warning[] warnings;
                string[] streamids;
                string mimeType, encoding, extension, deviceInfo;
                deviceInfo = "True";
                byte[] bytes = rptViewer.ServerReport.Render("Excel", null, out mimeType, out encoding, out extension, out streamids, out warnings);

                object savefilename = Server.MapPath("~/Files/Reports/Documents/Templates/Report2/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                string filename = string.Format("{0}.{1}", "ExportToExcel", "xls");
                FileInfo file = new FileInfo(savefilename.ToString());

                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = mimeType;
                //Response.Headers.Clear();

                System.IO.FileStream pdfFile = new System.IO.FileStream(savefilename.ToString(), System.IO.FileMode.Create);
                pdfFile.Write(bytes, 0, bytes.Length);
                //pdfFile.Close();
                //Response.Flush();
                //Response.End();

                //FileStream fs = null;
                BinaryReader br = null;
                //byte[] data1 = null;
                if (File.Exists(savefilename.ToString()))
                {
                    //fs = new FileStream(savefilename.ToString(), FileMode.Open, FileAccess.Read, FileShare.Read);
                    br = new BinaryReader(pdfFile, System.Text.Encoding.Default);
                    bytes = new byte[Convert.ToInt32(pdfFile.Length)];
                    br.Read(bytes, 0, bytes.Length);

                    Response.Clear();
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.AddHeader("content-disposition", "attachment; filename=ActivityReport-" + DateTime.Now.ToShortDateString() + ".xlsx");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.BinaryWrite(bytes);
                    Response.Flush();
                    Response.Close();

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void SSRS_Report()
        {

            try
            {

                rptViewer.ProcessingMode = ProcessingMode.Remote;
                ServerReport serverReport = rptViewer.ServerReport;
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                serverReport.ReportServerUrl = new Uri("http://usi-sq-10/ReportServer_ADPConcur");
                serverReport.ReportPath = "/BP/BP Renewal Status Report";

                List<string> SelectedOfficeList = new List<string>();

                for (int i = 0; i < cblistOffice.Items.Count; i++)
                {
                    if (cblistOffice.Items[i].Selected)
                    {
                        SelectedOfficeList.Add(cblistOffice.Items[i].Text);
                    }
                }

                string[] values_Offices = SelectedOfficeList.ToArray();


                string ProducerTeam = string.Empty;

                if (ddlProducerTeam.SelectedValue.ToString() == "1111")
                {
                    ProducerTeam = "%";
                }
                else
                {
                    ProducerTeam = ddlProducerTeam.SelectedValue.ToString();
                }

                ReportParameter[] Param = new ReportParameter[6];
                Param[0] = new ReportParameter("REGIONS", ddlRegion.SelectedValue.ToString());
                Param[1] = new ReportParameter("OFFICES", values_Offices);
                Param[2] = new ReportParameter("DATETYPE", ddlDateType.SelectedValue.ToString());
                Param[3] = new ReportParameter("PRODUCERTEAMS", ProducerTeam);
                Param[4] = new ReportParameter("DATEFROM", txtDateFrom.Text);
                Param[5] = new ReportParameter("DATETO", txtDateTo.Text);
                // rptViewer.ServerReport.GetParameters();
                rptViewer.ShowParameterPrompts = true;
                rptViewer.ServerReport.SetParameters(Param);
                rptViewer.ServerReport.Refresh();
                // CreateReports2_RenewalStatusReport(tc.Timeline1_SubjectID, SessionId);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
    }
}