﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTool6_ClientIntakeForm : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        public void WriteFieldToTools6_ClientIntakeForm(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable PlanTable, string Office_Region, DataTable dtNewAcctContactList)
        {
            try
            {
                DataTable dt = new DataTable();
                dtNewAcctContactList.DefaultView.Sort = "[PrimaryContact] asc";
                dt = dtNewAcctContactList.DefaultView.ToTable(true);
                dtNewAcctContactList = dt;


                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;
                string federalTaxpayer = string.Empty;
                string businessType = string.Empty;
                string accountFunding = string.Empty;

                string Street1 = string.Empty;
                string Street2 = string.Empty;
                string City = string.Empty;
                string State = string.Empty;
                string Zip = string.Empty;
                string Country = string.Empty;

                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;
                string sname = string.Empty;
                string stitle = string.Empty;
                string semail = string.Empty;
                string sphoneNumber = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");

                int count = 1;
                int countzero = 2;
                string[] arr;
                string benefitSum = String.Empty;
                int OptionFieldValueiD;
                string FundingType = "";

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();
                                        //SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();
                                        //ServiceLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        //ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"])))
                            {
                                federalTaxpayer = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_country"])))
                            {
                                Country = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_country"]);
                            }
                        }
                    }

                }

                #endregion

                //for (int k = 0; k < ActivityInfoTable.Rows.Count; k++)
                //{
                //if (ActivityInfoTable.Rows[k]["recordID"].ToString() == ActivityDS.Tables["activityrecord_table"].Rows[0]["recordID"].ToString())
                //{


                if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm")
                {
                    #region Write Table of Account Contacts for client Intake
                    //Tools_Constant tc = new Tools_Constant();
                    //string accountInfo = string.Empty;
                    int clmCnt1 = 0;

                    if (ContactList != null)
                    {
                        if (dtNewAcctContactList.Rows.Count > 0)
                        {
                            for (int j = 0; j < dtNewAcctContactList.Rows.Count; j++)
                            {
                                for (int i = 0; i < ContactList.Count; i++)
                                {
                                    if (dtNewAcctContactList.Rows[j]["ID"].ToString() == Convert.ToString(ContactList[i].ContactId))
                                    {
                                        //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                        //{
                                        ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                        //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                        //{
                                        //if (clmCnt > 1)
                                        //{
                                        //    oWordDoc.Tables[2].Columns.Add();
                                        //}
                                        clmCnt1++;
                                        if (clmCnt1 == 1)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                name = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                name = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                title = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                title = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                email = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                email = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                phoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                phoneNumber = " ";
                                            }
                                        }
                                        if (clmCnt1 == 2)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                sname = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                sname = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                stitle = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                stitle = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                semail = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                semail = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                sphoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                sphoneNumber = " ";
                                            }
                                        }
                                        //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 1).Range.Text = name;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 2).Range.Text = title;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 3).Range.Text = phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 4).Range.Text = email;
                                        //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);

                                        //clmCnt++;

                                        //if (clmCnt > 3)
                                        //{
                                        //    break;
                                        //}
                                        //}
                                        //}
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                }
                else
                {
                    #region Write Table of Account Contacts

                    int clmCnt = 0;

                    if (ContactList != null)
                    {
                        if (arrAcctContact.Count > 0)
                        {
                            for (int j = 0; j < arrAcctContact.Count; j++)
                            {
                                for (int i = 0; i < ContactList.Count; i++)
                                {
                                    if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                    {
                                        //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                        //{
                                        ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                        //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                        //{
                                        //if (clmCnt > 1)
                                        //{
                                        //    oWordDoc.Tables[2].Columns.Add();
                                        //}
                                        clmCnt++;
                                        if (clmCnt == 1)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                name = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                name = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                title = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                title = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                email = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                email = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                phoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                phoneNumber = " ";
                                            }
                                        }
                                        if (clmCnt == 2)
                                        {
                                            if (ContactList[i].Name != null)
                                            {
                                                sname = ContactList[i].Name;
                                            }
                                            else
                                            {
                                                sname = " ";
                                            }

                                            if (ContactList[i].Title != null)
                                            {
                                                stitle = ContactList[i].Title;
                                            }
                                            else
                                            {
                                                stitle = " ";
                                            }

                                            if (ContactList[i].Email != null)
                                            {
                                                semail = ContactList[i].Email;
                                            }
                                            else
                                            {
                                                semail = " ";
                                            }

                                            if (ContactList[i].Phone.Count > 0)
                                            {
                                                sphoneNumber = ContactList[i].Phone[0];
                                            }
                                            else
                                            {
                                                sphoneNumber = " ";
                                            }
                                        }
                                        //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 1).Range.Text = name;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 2).Range.Text = title;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 3).Range.Text = phoneNumber;
                                        //oWordDoc.Tables[2].Cell(clmCnt, 4).Range.Text = email;
                                        //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);

                                        //clmCnt++;

                                        //if (clmCnt > 3)
                                        //{
                                        //    break;
                                        //}
                                        //}
                                        //}
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                }

                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        //if (fieldName.Contains("Legal Name"))
                        //{
                        //    myMergeField.Select();
                        //    oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                        //    continue;
                        //}

                        if (fieldName.Contains("Legal Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }
                        if (fieldName.Contains("Service Team"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Office_Region.Trim());
                            continue;
                        }
                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Street Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Street1) || !string.IsNullOrEmpty(Street2))
                            {
                                oWordApp.Selection.TypeText(Street1 + " " + Street2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("City"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(City))
                            {
                                oWordApp.Selection.TypeText(City);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("State"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(State))
                            {
                                oWordApp.Selection.TypeText(State);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Zip"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Zip))
                            {
                                oWordApp.Selection.TypeText(Zip);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("TaxpayerID"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(federalTaxpayer))
                            {
                                oWordApp.Selection.TypeText(federalTaxpayer);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of FTE"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(name))
                            {
                                oWordApp.Selection.TypeText(name);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(title))
                            {
                                oWordApp.Selection.TypeText(title);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(phoneNumber))
                            {
                                oWordApp.Selection.TypeText(phoneNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(email))
                            {
                                oWordApp.Selection.TypeText(email);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(sname))
                            {
                                oWordApp.Selection.TypeText(sname);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Title"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(stitle))
                            {
                                oWordApp.Selection.TypeText(stitle);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(sphoneNumber))
                            {
                                oWordApp.Selection.TypeText(sphoneNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Secondary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(semail))
                            {
                                oWordApp.Selection.TypeText(semail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                    }
                }
                #endregion

                #region TeamTable
                oWordDoc.Tables[1].Cell(1, 2).Select();
                oWordDoc.Tables[1].Cell(1, 2).Range.Text = DateTime.Today.ToString("MM/dd/yyyy");

                #region commented code
                ////Sales Lead
                //if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                //{
                //    oWordDoc.Tables[1].Cell(4, 2).Select();
                //    //oWordDoc.Tables[1].Cell(4, 2).Range.Text = "s";
                //    oWordDoc.Tables[1].Cell(4, 2).Range.Text = (SalesLead_FirstName + " " + SalesLead_LastName).Trim(charsToTrim);
                //    //oWordDoc.Tables[1].Cell(4, 2).Range.Text = oWordDoc.Tables[1].Cell(4, 2).Range.Text.Trim(charsToTrim);
                //    // oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                //}
                //else
                //{
                //    oWordApp.Selection.TypeText("");
                //}

                ////Service Lead
                //if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                //{
                //    oWordDoc.Tables[1].Cell(3, 2).Select();
                //    //oWordDoc.Tables[1].Cell(3, 2).Range.Text = "s";
                //    oWordDoc.Tables[1].Cell(3, 2).Range.Text = ServiceLead_FirstName + " " + ServiceLead_LastName;
                //    oWordDoc.Tables[1].Cell(3, 2).Range.Text = oWordDoc.Tables[1].Cell(3, 2).Range.Text.Trim(charsToTrim);
                //    //  oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                //}
                //else
                //{
                //    oWordApp.Selection.TypeText(" ");
                //}
                #endregion commented code


                //if (ddlClient.SelectedIndex > 0)
                //{
                //    oWordDoc.Tables[2].Cell(1, 1).Select();
                //    oWordDoc.Tables[2].Cell(1, 1).Range.Text = (ddlClient.SelectedItem.Text.ToString().Trim());

                //}
                //Broker_Of_Record
                if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                {
                    oWordDoc.Tables[1].Cell(6, 2).Select();
                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = Broker_Of_Record;
                    //oWordApp.Selection.TypeText(Broker_Of_Record);
                }
                else
                {
                    oWordApp.Selection.TypeText(" ");
                }
                #endregion

                #region Plan Details
                //string voluntary = String.Empty;
                //string voluntaryBool = String.Empty;
                //string strYes = "Yes";
                //string strNo = "No";

                if (PlanTable != null && PlanTable.Rows.Count > 0)
                {
                    foreach (DataRow row in PlanTable.Rows)
                    {
                        arr = (row["ProductName"].ToString()).Split('/');
                        benefitSum = arr[1];
                        //voluntary = arr[2];

                        //Voluntary
                        //if (voluntary.Trim() == "Shared" || voluntary.Trim() == "ER Paid")
                        //    voluntaryBool = strNo;
                        //else if (voluntary.Trim() == "EE Paid")
                        //voluntaryBool = strYes;

                        //Funding
                        OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(row["ProductId"].ToString()), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self-Insured"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        oWordDoc.Tables[6].Rows.Add();
                        count++;
                        oWordDoc.Tables[6].Cell(count, 1).Select();
                        oWordDoc.Tables[6].Cell(count, 1).Range.Text = row["PlanType"].ToString();
                        oWordDoc.Tables[6].Cell(count, 2).Range.Text = row["Carrier"].ToString();
                        oWordDoc.Tables[6].Cell(count, 3).Range.Text = benefitSum;
                        oWordDoc.Tables[6].Cell(count, 4).Range.Text = FundingType;
                        oWordDoc.Tables[6].Cell(count, 5).Range.Text = row["Renewal"].ToString();
                        //oWordDoc.Tables[6].Cell(count, 6).Range.Text = voluntaryBool;
                        //Range range = oWordDoc.Tables[6].Cell(count, 6).Range;
                        //range.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range);
                        //Range rng = oWordDoc.Tables[6].Cell(count, 7).Range;
                        //rng.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, rng);
                        ////oWordDoc.Tables[6].Cell(count, 7).Range.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, ref missing);

                        //foreach (Word.ContentControl dropdown in range.ContentControls)
                        //{
                        //    dropdown.DropdownListEntries.Clear();
                        //    dropdown.DropdownListEntries.Add("EDI/Automated File", "first", 1);
                        //    dropdown.DropdownListEntries.Add("Manual Entry", "second", 2);
                        //    dropdown.DropdownListEntries.Add("Aggregated (Self Bill)", "third", 3);
                        //    dropdown.DropdownListEntries.Add("Other (Describe Below)", "fourth", 4);
                        //}

                        //foreach (Word.ContentControl dropdown2 in rng.ContentControls)
                        //{
                        //    dropdown2.DropdownListEntries.Clear();
                        //    dropdown2.DropdownListEntries.Add("List Bill", "first", 1);
                        //    dropdown2.DropdownListEntries.Add("Self Bill", "second", 2);
                        //    dropdown2.DropdownListEntries.Add("Consolidated Bill", "third", 3);
                        //}
                        CallRowSixLoop(oWordDoc, count);
                        CallRowSevenLoop(oWordDoc, count);
                    }
                    oWordDoc.Tables[6].Rows.Add();
                    oWordDoc.Tables[6].Rows.Add();
                    oWordDoc.Tables[6].Rows.Add();
                    for (int i = count + 1; i < count + 5; i++)
                    {
                        //Range range2 = oWordDoc.Tables[6].Cell(i, 6).Range;
                        //range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
                        //foreach (Word.ContentControl dropdown in range2.ContentControls)
                        //{
                        //    dropdown.DropdownListEntries.Clear();
                        //    dropdown.DropdownListEntries.Add("EDI/Automated File", "first", 1);
                        //    dropdown.DropdownListEntries.Add("Manual Entry", "second", 2);
                        //    dropdown.DropdownListEntries.Add("Aggregated (Self Bill)", "third", 3);
                        //    dropdown.DropdownListEntries.Add("Other (Describe Below)", "fourth", 4);
                        //}

                        //Range rn = oWordDoc.Tables[6].Cell(i, 7).Range;
                        //rn.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, rn);
                        //foreach (Word.ContentControl dropdown2 in rn.ContentControls)
                        //{
                        //    dropdown2.DropdownListEntries.Clear();
                        //    dropdown2.DropdownListEntries.Add("List Bill", "first", 1);
                        //    dropdown2.DropdownListEntries.Add("Self Bill", "second", 2);
                        //    dropdown2.DropdownListEntries.Add("Consolidated Bill", "third", 3);
                        //}
                        CallRowSixLoop(oWordDoc, i);
                        CallRowSevenLoop(oWordDoc, i);
                    }
                }
                else if (PlanTable.Rows.Count == 0)
                {
                    oWordDoc.Tables[6].Rows.Add();
                    oWordDoc.Tables[6].Rows.Add();
                    oWordDoc.Tables[6].Rows.Add();
                    count++;
                    oWordDoc.Tables[6].Cell(count, 1).Select();
                    oWordDoc.Tables[6].Cell(count, 1).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 2).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 3).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 4).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 5).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 6).Range.Text = "";
                    oWordDoc.Tables[6].Cell(count, 7).Range.Text = "";
                    //Range rng = oWordDoc.Tables[6].Cell(count, 7).Range;
                    //rng.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, rng);

                    for (int i = countzero; i < countzero + 4; i++)
                    {
                        //Range range2 = oWordDoc.Tables[6].Cell(i, 6).Range;
                        //range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
                        //foreach (Word.ContentControl dropdown in range2.ContentControls)
                        //{
                        //    dropdown.DropdownListEntries.Clear();
                        //    dropdown.DropdownListEntries.Add("EDI/Automated File", "first", 1);
                        //    dropdown.DropdownListEntries.Add("Manual Entry", "second", 2);
                        //    dropdown.DropdownListEntries.Add("Aggregated (Self Bill)", "third", 3);
                        //    dropdown.DropdownListEntries.Add("Other (Describe Below)", "fourth", 4);
                        //}
                        CallRowSixLoop(oWordDoc, i);
                        CallRowSevenLoop(oWordDoc, i);
                        //Range rn = oWordDoc.Tables[6].Cell(i, 7).Range;
                        //rn.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, rn);
                        //foreach (Word.ContentControl xx in rn.ContentControls)
                        //{
                        //    xx.DropdownListEntries.Clear();
                        //    xx.DropdownListEntries.Add("List Bill", "first", 1);
                        //    xx.DropdownListEntries.Add("Self Bill", "second", 2);
                        //    xx.DropdownListEntries.Add("Consolidated Bill", "third", 3);
                        //    Marshal.ReleaseComObject(xx);
                        //}
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void CallRowSixLoop(Word.Document oWordDoc, int i)
        {
            Range range2 = oWordDoc.Tables[6].Cell(i, 6).Range;
            range2.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range2);
            foreach (Word.ContentControl dropdown in range2.ContentControls)
            {
                dropdown.DropdownListEntries.Clear();
                dropdown.DropdownListEntries.Add("EDI/Automated File", "first", 1);
                dropdown.DropdownListEntries.Add("Manual Entry", "second", 2);
                dropdown.DropdownListEntries.Add("Aggregated (Self Bill)", "third", 3);
                dropdown.DropdownListEntries.Add("Other (Describe Below)", "fourth", 4);
            }
        }

        public void CallRowSevenLoop(Word.Document oWordDoc, int i)
        {
            Range range = oWordDoc.Tables[6].Cell(i, 7).Range;
            range.ContentControls.Add(Word.WdContentControlType.wdContentControlDropdownList, range);
            foreach (Word.ContentControl drpdown in range.ContentControls)
            {
                drpdown.DropdownListEntries.Clear();
                drpdown.DropdownListEntries.Add("List Bill", "first", 1);
                drpdown.DropdownListEntries.Add("Self Bill", "second", 2);
                drpdown.DropdownListEntries.Add("Consolidated Bill", "third", 3);
                Marshal.ReleaseComObject(drpdown);
            }
        }

    }
}