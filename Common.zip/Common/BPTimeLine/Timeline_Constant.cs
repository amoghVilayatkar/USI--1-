﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BPTimeLine
{
    public class Timeline_Constant
    {
        #region Variable
        int _timeline1SubjectID = 24292;  // Renewal Timeline - Large Group
        int _timeline2SubjectID = 24293;  // Renewal Timeline - Small Group
        int _tools1SubjectID = 24294;     // Tools - 5500 Worksheet
        int _serviceCalendar2SubjectID = 38069;  // Service Calendar - Detail
       
        #endregion

        /// <summary>
        /// Get Timeline1 SubjectID
        /// Renewal Timeline - Large Group
        /// </summary>
        public int  Timeline1_SubjectID
        {
            get
            {
                return _timeline1SubjectID;
            }
        }

        /// <summary>
        /// Get Timeline1 SubjectID
        /// Renewal Timeline - Small Group
        /// </summary>
        public int Timeline2_SubjectID
        {
            get
            {
                return _timeline2SubjectID;
            }
        }

        /// <summary>
        /// Get Tools SubjectID
        /// Tools - 5500 Worksheet
        /// </summary>
        public int Tools1_SubjectID
        {
            get
            {
                return _tools1SubjectID;
            }
        }

        /// <summary>
        /// Get Service Calendar SubjectID
        /// Service Calendar - Detail
        /// </summary>
        public int ServiceCalendar2_SubjectID
        {
            get
            {
                return _serviceCalendar2SubjectID;
            }
        }
    }
}