﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.ServiceCalendar;

namespace BenefitPointSummaryPortal.BAL.ServiceCalendar
{
    public class WriteServiceCalendarCompliance : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctions objCommFun = new CommonFunctions();

        /// <summary>
        /// WriteFieldToSC_Compliance_12mo_W2
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="RenewalDate">DateTime RenewalDate for to take renewal month from</param>
        /// <param name="OptionFieldValueiD">int OptionFieldValueiD is used as a flag just to check whether funding method is "Self Funding" or "Self Insured" or nothing</param>
        /// <param name="ddlGroupMWEA">DropDownList ddlGroupMWEA is used as a flag just to check whether Groupd MEWA is included (Yes) or not</param>
        /// <param name="ddlIsEmpInCA">DropDownList ddlIsEmpInCA is used as a flag just to check whether is employee from San Frascisco (Yes) or not</param>
        /// <param name="AccountDS">DataSet AccountDS is used for taking "Maximum Number of Full Time Employees" and "Is 5500 Required"</param>

        public void WriteFieldToSC_Compliance_12mo_W2(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, DateTime EffectiveDate,
           int OptionFieldValueiD, DropDownList ddlGroupMWEA, DropDownList ddlIsEmpInCA, DataSet AccountDS, int ddlReportFormatCompliance_selectedindex, DateTime dtOriginal_RenewalDate, DropDownList ddlHRA, DropDownList ddlMassachusetts)
        {
            try
            {
                int cnt = 0;
                int cnt1 = 0;
                int cntDiff = 0;

                //EffectiveDate = Convert.ToDateTime("03/29/2019"); // hard code
                // Check for the last day of January for the selected year
                string strdt_Jan = "01/31/" + EffectiveDate.Year;
                DateTime d_Jan = Convert.ToDateTime(strdt_Jan);

                string strdt_Feb = "02/28/" + EffectiveDate.Year; 
                
                // Check for Leap Year 
                // Check for the last day of February
                /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                ////if (EffectiveDate.Year % 4 == 0)
                ////{
                ////    strdt_Feb = "02/29/" + EffectiveDate.Year;
                ////}
                ////else
                ////{
                ////    strdt_Feb = "02/28/" + EffectiveDate.Year;
                ////}
                DateTime d_Feb = Convert.ToDateTime(strdt_Feb);

                //OptionFieldValueiD = 52403; //Need to remove after compliting
                int SelectedMonthNo = EffectiveDate.Month;

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());

                /*
                // Get the Is 5500 Required details
                var Is_5500 = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<bool>("groupAccountInfo_requires5500");

                string Requires_5500 = Convert.ToString(Is_5500.First()).ToLower();
                */

                #region For writing table values

                ////// For common and static text call the following function
                ////objCommFun.Get_Compliance_Constant_Text(oWordDoc, 3, 7);

                /*
                // If Requires_5500 = Yes Topics
                if (Requires_5500 == "True".ToLower())
                {
                    //For Renewal Month + 2
                    oWordDoc.Tables[2].Cell(3, 3).Select();

                    if (oWordDoc.Tables[2].Cell(3, 3).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(3, 3).Range.Text = oWordDoc.Tables[2].Cell(3, 3).Range.Text + "Summary Annual Report due to plan participants";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(3, 3).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(3, 3).Range.Text = "Summary Annual Report due to plan participants";
                    }

                    //For Renewal Month + 6
                    oWordDoc.Tables[2].Cell(7, 1).Select();
                    if (oWordDoc.Tables[2].Cell(7, 1).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(7, 1).Range.Text = oWordDoc.Tables[2].Cell(7, 1).Range.Text + "Form 5500 (or Form 5558) filing due";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(7, 1).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(7, 1).Range.Text = "Form 5500 (or Form 5558) filing due";
                    }
                }
                */

                int renCnt = 1;
                string date_text = string.Empty;
                string ren_Text = string.Empty;
                int new_Month = 0;
                DateTime d_date;
                DateTime cal_date;
                // For <<Effective Date + 60 Days>> condition
                #region For <<Effective Date + 60 Days>> condition
                /*---- This Code is updated and commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                //DateTime CalculatedDate = EffectiveDate.AddDays(60);
                DateTime CalculatedDate = EffectiveDate.AddDays(59);

                renCnt = 1;
                new_Month = CalculatedDate.Month;

                d_date = CalculatedDate;
                //ren_Text = new_Month + "/" + CalculatedDate.Day + " – Report to CMS creditable status of drug coverage";
                ren_Text = new_Month + "/" + CalculatedDate.Day + " – Medicare Part D Creditable Coverage Notice due to CMS";

                renCnt = (d_date.Month - SelectedMonthNo) + 1;
                /*---- This Code is Commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                ////if (objCommFun.If_Weekend_Or_Holiday(d_date))
                ////{
                ////    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                ////    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                ////    if (d_date.DayOfWeek == DayOfWeek.Saturday)
                ////    {
                ////        d_date = d_date.AddDays(2);
                ////    }
                ////    else if (d_date.DayOfWeek == DayOfWeek.Sunday)
                ////    {
                ////        d_date = d_date.AddDays(1);
                ////    }

                ////    renCnt = (d_date.Month - SelectedMonthNo) + 1;
                ////    //ren_Text = date_text + " – Report to CMS creditable status of drug coverage";
                ////    ren_Text = date_text + " – Medicare Part D Creditable Coverage Notice due to CMS";
                ////}

                if (renCnt < 0)
                {
                    renCnt = 12 + renCnt;
                }
                oWordDoc.Tables[2].Cell(3, renCnt).Select();

                if (oWordDoc.Tables[2].Cell(3, renCnt).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = oWordDoc.Tables[2].Cell(3, renCnt).Range.Text + ren_Text;
                }
                else
                {
                    // For applying bullets in a cell
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = ren_Text;
                }

                #endregion

                //For Renewal Month
                #region For Renewal Month
                //renCnt = 1;
                //ren_Text = SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //d_date = Convert.ToDateTime(SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + "/" + EffectiveDate.Year);

                //if (objCommFun.If_Weekend_Or_Holiday(d_date))
                //{
                //    renCnt = 2;
                //    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                //    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                //    ren_Text = date_text + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //}
                //oWordDoc.Tables[2].Cell(3, renCnt).Select();

                //if (oWordDoc.Tables[2].Cell(3, renCnt).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = oWordDoc.Tables[2].Cell(3, renCnt).Range.Text + ren_Text;
                //}
                //else
                //{
                //    // For applying bullets in a cell
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = ren_Text;
                //}
                #endregion

                //For Renewal Month + 6
                #region For Renewal Month + 6
                new_Month = SelectedMonthNo + 6;
                GetRenewalMonth_6_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 7);
                #endregion

                //For Renewal Month + 8
                #region For Renewal Month + 8
                new_Month = SelectedMonthNo + 8;
                GetRenewalMonth_8_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 7);
                #endregion

                //// 52403 : is for self insured
                //if (OptionFieldValueiD == 52403) // If Self Insured
                //{
                //    // For first column static text
                //    oWordDoc.Tables[2].Cell(3, 1).Select();

                //    if (oWordDoc.Tables[2].Cell(3, 1).Range.Text.Length > 2)
                //    {
                //        oWordDoc.Tables[2].Cell(3, 1).Range.Text = oWordDoc.Tables[2].Cell(3, 1).Range.Text + "Consider Section 105(h) discrimination testing";
                //    }
                //    else
                //    {
                //        // For applying bullets in a cell
                //        oWordDoc.Tables[2].Cell(3, 1).Range.ListFormat.ApplyBulletDefault();
                //        oWordDoc.Tables[2].Cell(3, 1).Range.Text = "Consider Section 105(h) discrimination testing";
                //    }
                //}

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    #region Code for first 6 months
                    if (cnt < 6)
                    {
                        cnt++;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 3, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 3, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);// As Per Lisa 31 Jan 2018 to remove 'Distribute Form 1095-C to each ACA FTE and each covered primary insured' we comment this code in every where in fucntion
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);  // -- Edited by Amogh
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3) // -- Edited by Amogh 
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                        }
                    }
                    #endregion

                    // Code for next 6 columns (Months)
                    #region Code for next 6 months
                    else if (cnt >= 6)
                    {
                        cnt1++;
                        oWordDoc.Tables[2].Cell(4, cnt1).Select();
                        oWordDoc.Tables[2].Cell(4, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 7, cnt1, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 7, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // Edited by Amogh
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3) // Edited by Amogh
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                        }
                    }
                    #endregion

                    cntDiff++;
                }

                // Take a difference from above loop so that to iterate another loop for the 12 - cntDiff 
                // (i.e. Total 12 months minus the total months for which the loop is already executed
                if (cntDiff < 12)
                {
                    for (int j = 1; j <= 12 - cntDiff; j++)
                    {
                        #region Code for first 6 months
                        if (cnt < 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt++;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 3, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            objCommFun.Get_Renewal_Month_Topic(j, 3, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // Edited by Amogh
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3)  // Edited by Amogh
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        #endregion

                        #region Code for next 6 months
                        else if (cnt >= 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt1++;
                            oWordDoc.Tables[2].Cell(4, cnt1).Select();
                            oWordDoc.Tables[2].Cell(4, cnt1).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 7, cnt1, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            objCommFun.Get_Renewal_Month_Topic(j, 7, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);  // Edited by Amogh
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3) // Edited by Amogh
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }

                        #endregion
                    }
                }
                #endregion

                // For common and static text call the following function
                objCommFun.Get_Compliance_Constant_Text(oWordDoc, 3, 7);

                #region MergeField
                /*-------------- Modified by Amogh Vilayatkar 26/12/2017 --------------*/

                #region Footnote dynamic Generation Logic - by Amogh Vilayatkar 26/12/2017

                StringBuilder footnoteText = new StringBuilder();
                string footnote2 = string.Empty;
                string footNote4_SecondDate = string.Empty;
                string footNote4_FirstDate = string.Empty;

                DateTime dateFirst = new DateTime();
                DateTime dateSecond = new DateTime();
                // First Date Check 
                dateFirst = getFootNoteDate(1, EffectiveDate);
                footNote4_FirstDate = objCommFun.GetNextBusinessDay_For_Holiday(dateFirst.Month, dateFirst.Year, dateFirst);
                if (String.IsNullOrEmpty(footNote4_FirstDate))
                {
                    footNote4_FirstDate = dateFirst.ToShortDateString();
                }
                else { footNote4_FirstDate = footNote4_FirstDate + "/" + dateFirst.Year; }

                // Second Date Check logic
                dateSecond = getFootNoteDate(2, EffectiveDate);
                footNote4_SecondDate = objCommFun.GetNextBusinessDay_For_Holiday(dateSecond.Month, dateSecond.Year, dateSecond);
                if (String.IsNullOrEmpty(footNote4_SecondDate))
                {
                    footNote4_SecondDate = dateSecond.ToShortDateString();
                }
                else { footNote4_SecondDate = footNote4_SecondDate + "/" + dateSecond.Year; }

                switch (EffectiveDate.Year)
                {
                    case 2017: footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        break;
                    case 2018: footnote2 = "\u00B2 2018 OOPMs ($7,350/$14,700 Non-GF, $6,650/$13,300 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,450/$6,900.";
                        break;
                    ////case 2019: footnote2 = "\u00B2 2019 OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced.";
                    ////    break;
                    case 2019: footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        break;
                    default:
                        if (EffectiveDate.Year <= 2017)
                        {
                            footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        }
                        else if (EffectiveDate.Year >= 2019)
                        {
                            ////footnote2 = "\u00B2 " + EffectiveDate.Year + " OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced."; 
                            footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        }
                        break;
                }

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 2")
                    {
                        footnoteText.Append("\u00B9 The plan year is equivalent to the stability period for ongoing employees.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append(footnote2);
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u00B3 Benefit information may include the value of group health plan coverage, the value of group term life in excess of $50,000, HSA contributions, or additional Medicare tax.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2074 If Form 5558 filing extension submitted, Form 5500 is due " + footNote4_FirstDate + " and SAR is due to plan participants by " + footNote4_SecondDate + ".");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2075 Annual notices include SBCs, HIPAA Notice of Privacy Practice, HIPAA Notice of Special Enrollment Rights, ACA Patient Protections, CHIPRA Notice, Wellness, and WHCRA Annual Notice.");
                        shape.Select();
                        shape.TextFrame.ContainingRange.Text = Convert.ToString(footnoteText);
                    }
                }

                #endregion

                /*--------------End Modification by Amogh --------------*/

                // Write the common fields on the template
                objCommFun.Write_Field_Values_On_Template(oWordDoc, oWordApp, ddlClient, EffectiveDate);

                // Function writes the date in Footer section
                objCommFun.Write_DateInto_Footer(oWordDoc, oWordApp);
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// WriteFieldToSC_Compliance_12mo_W2_5
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="RenewalDate">DateTime RenewalDate for to take renewal month from</param>
        /// <param name="OptionFieldValueiD">int OptionFieldValueiD is used as a flag just to check whether funding method is "Self Funding" or "Self Insured" or nothing</param>
        /// <param name="ddlGroupMWEA">DropDownList ddlGroupMWEA is used as a flag just to check whether Groupd MEWA is included (Yes) or not</param>
        /// <param name="ddlIsEmpInCA">DropDownList ddlIsEmpInCA is used as a flag just to check whether is employee from San Frascisco (Yes) or not</param>
        /// <param name="AccountDS">DataSet AccountDS is used for taking "Maximum Number of Full Time Employees" and "Is 5500 Required"</param>

        public void WriteFieldToSC_Compliance_12mo_W2_5(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, DateTime EffectiveDate,
           int OptionFieldValueiD, DropDownList ddlGroupMWEA, DropDownList ddlIsEmpInCA, DataSet AccountDS, DateTime dtOriginal_RenewalDate, int ddlReportFormatCompliance_selectedindex, DropDownList ddlHRA, DropDownList ddlMassachusetts)
        {
            try
            {
                int cnt = 0;
                int cnt1 = 0;
                int cntDiff = 0;

                //EffectiveDate = Convert.ToDateTime("05/01/2019"); // hard code
                // Check for the last day of January for the selected year
                string strdt_Jan = "01/31/" + EffectiveDate.Year;
                DateTime d_Jan = Convert.ToDateTime(strdt_Jan);

                string strdt_Feb = "02/28/" + EffectiveDate.Year; ;
                // Check for Leap Year 
                
                // Check for the last day of February
                /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                ////if (EffectiveDate.Year % 4 == 0)
                ////{
                ////    strdt_Feb = "02/29/" + EffectiveDate.Year;
                ////}
                ////else
                ////{
                ////    strdt_Feb = "02/28/" + EffectiveDate.Year;
                ////}
                DateTime d_Feb = Convert.ToDateTime(strdt_Feb);

                //OptionFieldValueiD = 52403; //Need to remove after compliting
                int SelectedMonthNo = EffectiveDate.Month;

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());

                /*
                // Get the Is 5500 Required details
                var Is_5500 = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<bool>("groupAccountInfo_requires5500");

                string Requires_5500 = Convert.ToString(Is_5500.First()).ToLower();
                */

                #region For writing table values

                ////// For common and static text call the following function
                ////objCommFun.Get_Compliance_Constant_Text(oWordDoc, 3, 7);

                /*
                //If Requires_5500 = Yes Topics
                if (Requires_5500 == "True".ToLower())
                {
                    //For Renewal Month + 2
                    oWordDoc.Tables[2].Cell(3, 3).Select();

                    if (oWordDoc.Tables[2].Cell(3, 3).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(3, 3).Range.Text = oWordDoc.Tables[2].Cell(3, 3).Range.Text + "Summary Annual Report due to plan participants";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(3, 3).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(3, 3).Range.Text = "Summary Annual Report due to plan participants";
                    }

                    //For Renewal Month + 6
                    oWordDoc.Tables[2].Cell(7, 1).Select();
                    if (oWordDoc.Tables[2].Cell(7, 1).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(7, 1).Range.Text = oWordDoc.Tables[2].Cell(7, 1).Range.Text + "Form 5500 (or Form 5558) filing due";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(7, 1).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(7, 1).Range.Text = "Form 5500 (or Form 5558) filing due";
                    }
                }
                */

                int renCnt = 1;
                string date_text = string.Empty;
                string ren_Text = string.Empty;
                int new_Month = 0;
                DateTime d_date;
                DateTime cal_date;
                // For <<Effective Date + 60 Days>> condition
                #region For <<Effective Date + 60 Days>> condition
                /*---- This Code is updated and commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                ////DateTime CalculatedDate = EffectiveDate.AddDays(60);
                DateTime CalculatedDate = EffectiveDate.AddDays(59); // added 59 day as per Lisa requirement

                renCnt = 1;
                new_Month = CalculatedDate.Month;

                d_date = CalculatedDate;
                //ren_Text = new_Month + "/" + CalculatedDate.Day + " – Report to CMS creditable status of drug coverage";
                ren_Text = new_Month + "/" + CalculatedDate.Day + " – Medicare Part D Creditable Coverage Notice due to CMS";

                renCnt = (d_date.Month - SelectedMonthNo) + 1;

                /*---- This Code is Commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                ////if (objCommFun.If_Weekend_Or_Holiday(d_date))
                ////{
                ////    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                ////    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                ////    if (d_date.DayOfWeek == DayOfWeek.Saturday)
                ////    {
                ////        d_date = d_date.AddDays(2);
                ////    }
                ////    else if (d_date.DayOfWeek == DayOfWeek.Sunday)
                ////    {
                ////        d_date = d_date.AddDays(1);
                ////    }

                ////    renCnt = (d_date.Month - SelectedMonthNo) + 1;
                ////    //ren_Text = date_text + " – Report to CMS creditable status of drug coverage";
                ////    ren_Text = date_text + " – Medicare Part D Creditable Coverage Notice due to CMS";
                ////}

                if (renCnt < 0)
                {
                    renCnt = 12 + renCnt;
                }
                oWordDoc.Tables[2].Cell(3, renCnt).Select();

                if (oWordDoc.Tables[2].Cell(3, renCnt).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = oWordDoc.Tables[2].Cell(3, renCnt).Range.Text + ren_Text;
                }
                else
                {
                    // For applying bullets in a cell
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = ren_Text;
                }

                #endregion

                //For Renewal Month
                #region For Renewal Month
                //renCnt = 1;
                //ren_Text = SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //d_date = Convert.ToDateTime(SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + "/" + EffectiveDate.Year);

                //if (objCommFun.If_Weekend_Or_Holiday(d_date))
                //{
                //    renCnt = 2;
                //    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                //    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                //    ren_Text = date_text + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //}
                //oWordDoc.Tables[2].Cell(3, renCnt).Select();

                //if (oWordDoc.Tables[2].Cell(3, renCnt).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = oWordDoc.Tables[2].Cell(3, renCnt).Range.Text + ren_Text;
                //}
                //else
                //{
                //    // For applying bullets in a cell
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(3, renCnt).Range.Text = ren_Text;
                //}
                #endregion

                //For Renewal Month + 6
                #region For Renewal Month + 6
                //renCnt = 2;
                new_Month = SelectedMonthNo + 6;
                GetRenewalMonth_6_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 7);

                //if (new_Month > 12)
                //{
                //    new_Month = new_Month - 12;
                //    d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + "/" + dtOriginal_RenewalDate.Year);
                //    ren_Text = new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";

                //    if (objCommFun.If_Weekend_Or_Holiday(d_date))
                //    {
                //        renCnt = 3;
                //        date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                //        date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                //        ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                //    }
                //}
                //else
                //{
                //    d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + "/" + EffectiveDate.Year);
                //    ren_Text = new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";

                //    if (objCommFun.If_Weekend_Or_Holiday(d_date))
                //    {
                //        renCnt = 3;
                //        date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                //        date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                //        ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                //    }
                //}
                //oWordDoc.Tables[2].Cell(7, renCnt).Select();

                //if (oWordDoc.Tables[2].Cell(7, renCnt).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(7, renCnt).Range.Text = oWordDoc.Tables[2].Cell(7, renCnt).Range.Text + ren_Text;
                //}
                //else
                //{
                //    // For applying bullets in a cell
                //    oWordDoc.Tables[2].Cell(7, renCnt).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(7, renCnt).Range.Text = ren_Text;
                //}
                #endregion

                //For Renewal Month + 8
                #region For Renewal Month + 8
                new_Month = SelectedMonthNo + 8;
                GetRenewalMonth_8_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 7);
                #endregion

                //// 52403 : is for self insured
                //if (OptionFieldValueiD == 52403) // If Self Insured
                //{
                //    // For first column static text
                //    oWordDoc.Tables[2].Cell(3, 1).Select();

                //    if (oWordDoc.Tables[2].Cell(3, 1).Range.Text.Length > 2)
                //    {
                //        oWordDoc.Tables[2].Cell(3, 1).Range.Text = oWordDoc.Tables[2].Cell(3, 1).Range.Text + "Consider Section 105(h) discrimination testing";
                //    }
                //    else
                //    {
                //        // For applying bullets in a cell
                //        oWordDoc.Tables[2].Cell(3, 1).Range.ListFormat.ApplyBulletDefault();
                //        oWordDoc.Tables[2].Cell(3, 1).Range.Text = "Consider Section 105(h) discrimination testing";
                //    }
                //}

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    #region Code for first 6 months
                    if (cnt < 6)
                    {
                        cnt++;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 3, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 3, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                ////objCommFun.Get_Full_Time_Employees_Topic(i, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD); // As Per Lisa 31 Jan 2018 to remove 'Distribute Form 1095-C to each ACA FTE and each covered primary insured' we comment this code in every where in fucntion
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // -- Edited by Amogh
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                ////objCommFun.Get_Full_Time_Employees_Topic(i, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3)  // -- Edited by Amogh
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                        }
                    }
                    #endregion

                    // Code for next 6 columns (Months)
                    #region Code for next 6 months
                    else if (cnt >= 6)
                    {
                        cnt1++;
                        oWordDoc.Tables[2].Cell(4, cnt1).Select();
                        oWordDoc.Tables[2].Cell(4, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 7, cnt1, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 7, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                ////objCommFun.Get_Full_Time_Employees_Topic(i, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // -- Edited by Amogh
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                ////objCommFun.Get_Full_Time_Employees_Topic(i, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3) // -- Edited by Amogh
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                        }
                    }
                    #endregion

                    cntDiff++;
                }

                // Take a difference from above loop so that to iterate another loop for the 12 - cntDiff 
                // (i.e. Total 12 months minus the total months for which the loop is already executed
                if (cntDiff < 12)
                {
                    for (int j = 1; j <= 12 - cntDiff; j++)
                    {
                        #region Code for first 6 months
                        if (cnt < 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt++;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 3, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            objCommFun.Get_Renewal_Month_Topic(j, 3, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // -- Edited by Amogh
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 3, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3)
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 3, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        #endregion

                        #region Code for next 6 months
                        else if (cnt >= 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt1++;
                            oWordDoc.Tables[2].Cell(4, cnt1).Select();
                            oWordDoc.Tables[2].Cell(4, cnt1).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 7, cnt1, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            objCommFun.Get_Renewal_Month_Topic(j, 7, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD); // -- Edited by Amogh
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    ////objCommFun.Get_Full_Time_Employees_Topic(j, 7, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3)// -- Edited by Amogh
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 7, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }

                        #endregion
                    }
                }
                #endregion

                // For common and static text call the following function
                objCommFun.Get_Compliance_Constant_Text(oWordDoc, 3, 7);

                #region MergeField

                /*-------------- Modified by Amogh Vilayatkar 26/12/2017 --------------*/

                #region Footnote dynamic Generation Logic - by Amogh Vilayatkar 26/12/2017

                StringBuilder footnoteText = new StringBuilder();
                string footnote2 = string.Empty;
                string footNote4_SecondDate = string.Empty;
                string footNote4_FirstDate = string.Empty;

                DateTime dateFirst = new DateTime();
                DateTime dateSecond = new DateTime();
                // First Date Check 
                dateFirst = getFootNoteDate(1, EffectiveDate);
                footNote4_FirstDate = objCommFun.GetNextBusinessDay_For_Holiday(dateFirst.Month, dateFirst.Year, dateFirst);
                if (String.IsNullOrEmpty(footNote4_FirstDate))
                {
                    footNote4_FirstDate = dateFirst.ToShortDateString();
                }
                else { footNote4_FirstDate = footNote4_FirstDate + "/" + dateFirst.Year; }

                // Second Date Check logic
                dateSecond = getFootNoteDate(2, EffectiveDate);
                footNote4_SecondDate = objCommFun.GetNextBusinessDay_For_Holiday(dateSecond.Month, dateSecond.Year, dateSecond);
                if (String.IsNullOrEmpty(footNote4_SecondDate))
                {
                    footNote4_SecondDate = dateSecond.ToShortDateString();
                }
                else { footNote4_SecondDate = footNote4_SecondDate + "/" + dateSecond.Year; }

                switch (EffectiveDate.Year)
                {
                    case 2017: footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        break;
                    case 2018: footnote2 = "\u00B2 2018 OOPMs ($7,350/$14,700 Non-GF, $6,650/$13,300 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,450/$6,900.";
                        break;
                    ////case 2019: footnote2 = "\u00B2 2019 OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced.";
                    ////    break;
                    case 2019: footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        break;
                    default:
                        if (EffectiveDate.Year <= 2017)
                        {
                            footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        }
                        else if (EffectiveDate.Year >= 2019)
                        {
                            ////footnote2 = "\u00B2 " + EffectiveDate.Year + " OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced."; 
                            footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        }
                        break;
                }

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 2")
                    {
                        footnoteText.Append("\u00B9 The plan year is equivalent to the stability period for ongoing employees.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append(footnote2);
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u00B3 Benefit information may include the value of group health plan coverage, the value of group term life in excess of $50,000, HSA contributions, or additional Medicare tax.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2074 If Form 5558 filing extension submitted, Form 5500 is due " + footNote4_FirstDate + " and SAR is due to plan participants by " + footNote4_SecondDate + ".");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2075 Annual notices include SBCs, HIPAA Notice of Privacy Practice, HIPAA Notice of Special Enrollment Rights, ACA Patient Protections, CHIPRA Notice, Wellness, and WHCRA Annual Notice.");
                        shape.Select();
                        shape.TextFrame.ContainingRange.Text = Convert.ToString(footnoteText);
                    }
                }

                #endregion

                /*--------------End Modification by Amogh --------------*/
                // Write the common fields on the template
                objCommFun.Write_Field_Values_On_Template(oWordDoc, oWordApp, ddlClient, EffectiveDate);

                // Function writes the date in Footer section
                objCommFun.Write_DateInto_Footer(oWordDoc, oWordApp);
                #endregion

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// WriteFieldToSC_Compliance_6mo_W2
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="RenewalDate">DateTime RenewalDate for to take renewal month from</param>
        /// <param name="OptionFieldValueiD">int OptionFieldValueiD is used as a flag just to check whether funding method is "Self Insured" or "Fully Insured" or nothing</param>
        /// <param name="ddlGroupMWEA">DropDownList ddlGroupMWEA is used as a flag just to check whether Groupd MEWA is included (Yes) or not</param>
        /// <param name="ddlIsEmpInCA">DropDownList ddlIsEmpInCA is used as a flag just to check whether is employee from San Frascisco (Yes) or not</param>
        /// <param name="AccountDS">DataSet AccountDS is used for taking "Maximum Number of Full Time Employees" and "Is 5500 Required"</param>
        /// <param name="ddlReportFormatCompliance_selectedindex">int ddlReportFormatCompliance_selectedindex is used to check the selected report format's index</param>

        public void WriteFieldToSC_Compliance_6mo_W2(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, DateTime EffectiveDate,
           int OptionFieldValueiD, DropDownList ddlGroupMWEA, DropDownList ddlIsEmpInCA, DataSet AccountDS, int ddlReportFormatCompliance_selectedindex, DateTime dtOriginal_RenewalDate, DropDownList ddlHRA, DropDownList ddlMassachusetts)
        {
            try
            {
                int cnt = 0;
                int cnt1 = 0;
                int cntDiff = 0;

                //EffectiveDate = Convert.ToDateTime("05/01/2019"); // hard code
                //int EffectiveYear = 0;
                // Check for the last day of January for the selected year
                //if (EffectiveDate.Month >= 1 && EffectiveDate.Month <= 3)
                //{
                //    EffectiveYear = EffectiveDate.Year;
                //}
                //else
                //{
                //    EffectiveYear = dtOriginal_RenewalDate.Year;
                //}

                string strdt_Jan = "01/31/" + EffectiveDate.Year;
                DateTime d_Jan = Convert.ToDateTime(strdt_Jan);

                string strdt_Feb = "02/28/" + EffectiveDate.Year; 
                // Check for Leap Year 
                
                // Check for the last day of February
                /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                ////if (EffectiveDate.Year % 4 == 0)
                ////{
                ////    strdt_Feb = "02/29/" + EffectiveDate.Year;
                ////}
                ////else
                ////{
                ////    strdt_Feb = "02/28/" + EffectiveDate.Year;
                ////}
                DateTime d_Feb = Convert.ToDateTime(strdt_Feb);
                //DateTime d_Feb;
                //d_Feb.Day = week
                //OptionFieldValueiD = 52403; //Need to remove after compliting
                int SelectedMonthNo = EffectiveDate.Month;

                // Get the Full Time Employees details
                var FTE = from acct in AccountDS.Tables[1].AsEnumerable()
                          select acct.Field<int>("groupAccountInfo_numberOfFTEs");
                int Num_Of_FTE = Convert.ToInt32(FTE.First());

                /*
                // Get the Is 5500 Required details
                var Is_5500 = from acct in AccountDS.Tables[1].AsEnumerable()
                              select acct.Field<bool>("groupAccountInfo_requires5500");

                string Requires_5500 = Convert.ToString(Is_5500.First()).ToLower();
                */

                #region For writing table values

                ////// For common and static text call the following function
                ////objCommFun.Get_Compliance_Constant_Text(oWordDoc, 4, 8);

                /*
                //If Requires_5500 = Yes Topics
                if (Requires_5500 == "True".ToLower())
                {
                    //For Renewal Month + 2
                    oWordDoc.Tables[2].Cell(4, 3).Select();

                    if (oWordDoc.Tables[2].Cell(4, 3).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(4, 3).Range.Text = oWordDoc.Tables[2].Cell(4, 3).Range.Text + "Summary Annual Report due to plan participants";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(4, 3).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(4, 3).Range.Text = "Summary Annual Report due to plan participants";
                    }

                    //For Renewal Month + 6
                    oWordDoc.Tables[2].Cell(8, 1).Select();
                    if (oWordDoc.Tables[2].Cell(8, 1).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(8, 1).Range.Text = oWordDoc.Tables[2].Cell(8, 1).Range.Text + "Form 5500 (or Form 5558) filing due";
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(8, 1).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(8, 1).Range.Text = "Form 5500 (or Form 5558) filing due";
                    }
                }
                */

                int renCnt = 1;
                string date_text = string.Empty;
                string ren_Text = string.Empty;
                int new_Month = 0;
                DateTime d_date;
                DateTime cal_date;
                // For <<Effective Date + 60 Days>> condition
                #region For <<Effective Date + 60 Days>> condition
                /*---- This Code is updated and commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                ////DateTime CalculatedDate = EffectiveDate.AddDays(60);
                DateTime CalculatedDate = EffectiveDate.AddDays(59); // Add 59 Day as per requiremnet

                renCnt = 1;
                new_Month = CalculatedDate.Month;

                d_date = CalculatedDate;
                //ren_Text = new_Month + "/" + CalculatedDate.Day + " – Report to CMS creditable status of drug coverage";
                ren_Text = new_Month + "/" + CalculatedDate.Day + " – Medicare Part D Creditable Coverage Notice due to CMS";

                renCnt = (d_date.Month - SelectedMonthNo) + 1;
                /*---- This Code is Commented by Amogh As per Lisa Requiement 31 Jan 2018  [Email Sub - Changes to the Annual Compliance Calendar]---*/
                ////if (objCommFun.If_Weekend_Or_Holiday(d_date))
                ////{
                ////    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                ////    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                ////    if (d_date.DayOfWeek == DayOfWeek.Saturday)
                ////    {
                ////        d_date = d_date.AddDays(2);
                ////    }
                ////    else if (d_date.DayOfWeek == DayOfWeek.Sunday)
                ////    {
                ////        d_date = d_date.AddDays(1);
                ////    }

                ////    renCnt = (d_date.Month - SelectedMonthNo) + 1;
                ////    //ren_Text = date_text + " – Report to CMS creditable status of drug coverage";
                ////    ren_Text = date_text + " – Medicare Part D Creditable Coverage Notice due to CMS";
                ////}

                if (renCnt < 0)
                {
                    renCnt = 12 + renCnt;
                }
                oWordDoc.Tables[2].Cell(4, renCnt).Select();

                if (oWordDoc.Tables[2].Cell(4, renCnt).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(4, renCnt).Range.Text = oWordDoc.Tables[2].Cell(4, renCnt).Range.Text + ren_Text;
                }
                else
                {
                    // For applying bullets in a cell
                    oWordDoc.Tables[2].Cell(4, renCnt).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, renCnt).Range.Text = ren_Text;
                }

                #endregion

                //For Renewal Month
                #region For Renewal Month
                //renCnt = 1;
                //ren_Text = SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //d_date = Convert.ToDateTime(SelectedMonthNo + "/" + DateTime.DaysInMonth(EffectiveDate.Year, SelectedMonthNo) + "/" + EffectiveDate.Year);

                //if (objCommFun.If_Weekend_Or_Holiday(d_date))
                //{
                //    renCnt = 2;
                //    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                //    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                //    ren_Text = date_text + " – Distribute form W-2 to employees with applicable benefit information" + "\u2074";
                //}
                //oWordDoc.Tables[2].Cell(4, renCnt).Select();

                //if (oWordDoc.Tables[2].Cell(4, renCnt).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(4, renCnt).Range.Text = oWordDoc.Tables[2].Cell(4, renCnt).Range.Text + ren_Text;
                //}
                //else
                //{
                //    // For applying bullets in a cell
                //    oWordDoc.Tables[2].Cell(4, renCnt).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(4, renCnt).Range.Text = ren_Text;
                //}
                #endregion

                //For Renewal Month + 6
                #region For Renewal Month + 6
                new_Month = SelectedMonthNo + 6;
                GetRenewalMonth_6_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 8);

                #endregion

                //For Renewal Month + 8
                #region For Renewal Month + 8
                new_Month = SelectedMonthNo + 8;
                GetRenewalMonth_8_Text(oWordDoc, new_Month, EffectiveDate, dtOriginal_RenewalDate, 8);
                #endregion

                //// 52403 : is for self insured
                //if (OptionFieldValueiD == 52403) // If Self Insured
                //{
                //    // For first column static text
                //    oWordDoc.Tables[2].Cell(4, 1).Select();

                //    if (oWordDoc.Tables[2].Cell(4, 1).Range.Text.Length > 2)
                //    {
                //        oWordDoc.Tables[2].Cell(4, 1).Range.Text = oWordDoc.Tables[2].Cell(4, 1).Range.Text + "Consider Section 105(h) discrimination testing";
                //    }
                //    else
                //    {
                //        // For applying bullets in a cell
                //        oWordDoc.Tables[2].Cell(4, 1).Range.ListFormat.ApplyBulletDefault();
                //        oWordDoc.Tables[2].Cell(4, 1).Range.Text = "Consider Section 105(h) discrimination testing";
                //    }
                //}

                // For Send Form 1095-C to employees For March Month
                #region For Send Form 1095-C to employees For March Month

                // Check for the last day of March for the selected year
                string strdt_Mar_15 = "03/01/" + dtOriginal_RenewalDate.Year;
                DateTime d_Mar_15 = Convert.ToDateTime(strdt_Mar_15);
                string Mar_text = string.Empty;
                Mar_text = objCommFun.GetNextBusinessDay(d_Mar_15, out cal_date);
                string Mar_text_sat_sun = Mar_text + " - Send Form 1095-C to employees";


                #endregion


                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    #region Code for first 6 months
                    if (cnt < 6)
                    {
                        cnt++;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 4, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 4, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 4, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD); // As Per Lisa 31 Jan 2018 to remove 'Distribute Form 1095-C to each ACA FTE and each covered primary insured' we comment this code in every where in fucntion
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 4, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 4, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3)
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 4, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            if (oWordDoc.Tables[2].Cell(4, cnt).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(4, cnt).Range.Text = oWordDoc.Tables[2].Cell(4, cnt).Range.Text + Mar_text_sat_sun;
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(4, cnt).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(4, cnt).Range.Text = Mar_text_sat_sun;
                            }
                        }
                    }
                    #endregion

                    // Code for next 6 columns (Months)
                    #region Code for next 6 months
                    else if (cnt >= 6)
                    {
                        cnt1++;
                        oWordDoc.Tables[2].Cell(5, cnt1).Select();
                        oWordDoc.Tables[2].Cell(5, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // For Funding Method
                        objCommFun.Get_Funding_Method_Topic(i, 8, cnt1, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, EffectiveDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                        //For Renewal month Topic
                        objCommFun.Get_Renewal_Month_Topic(i, 8, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), EffectiveDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                        // For Full Time Employees Topic
                        if (i == 1 || i == 2) // Only applicable when the month is January
                        {
                            if (i == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 8, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                AnnualComplianceCalendar_DeadLineMoveLogic(i, 8, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            }
                            else if (i == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                            {
                                //objCommFun.Get_Full_Time_Employees_Topic(i, 8, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                            }
                        }
                        else if (i == 3)
                        {
                            AnnualComplianceCalendar_DeadLineMoveLogic(i, 8, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                            if (oWordDoc.Tables[2].Cell(4, cnt).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(4, cnt).Range.Text = oWordDoc.Tables[2].Cell(4, cnt).Range.Text + Mar_text_sat_sun;
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(4, cnt).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(4, cnt).Range.Text = Mar_text_sat_sun;
                            }
                        }

                    }
                    #endregion

                    cntDiff++;
                }

                // Take a difference from above loop so that to iterate another loop for the 12 - cntDiff 
                // (i.e. Total 12 months minus the total months for which the loop is already executed
                if (cntDiff < 12)
                {
                    for (int j = 1; j <= 12 - cntDiff; j++)
                    {
                        #region Code for first 6 months
                        if (cnt < 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            
                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt++;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 4, cnt, oWordDoc, OptionFieldValueiD, dtOriginal_RenewalDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            objCommFun.Get_Renewal_Month_Topic(j, 4, cnt, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);

                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 4, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 4, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 4, cnt, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3)
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 4, cnt, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                                if (oWordDoc.Tables[2].Cell(4, cnt).Range.Text.Length > 2)
                                {
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.Text = oWordDoc.Tables[2].Cell(4, cnt).Range.Text + Mar_text_sat_sun;
                                }
                                else
                                {
                                    // For applying bullets in a cell
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.Text = Mar_text_sat_sun;
                                }
                            }
                        }
                        #endregion

                        #region Code for next 6 months
                        else if (cnt >= 6)
                        {
                            strdt_Jan = "01/31/" + dtOriginal_RenewalDate.Year;
                            d_Jan = Convert.ToDateTime(strdt_Jan);

                            /******************* AS PER NICOLE [ 3/7/2019 9:11 PM ] - There is no special consideration required for a leap year.[Compliance Calendar - Duplicate tasks]**********************/
                            // Check for Leap Year 
                            // Check for the last day of February
                            ////if (dtOriginal_RenewalDate.Year % 4 == 0)
                            ////{
                            ////    strdt_Feb = "02/29/" + dtOriginal_RenewalDate.Year;
                            ////}
                            ////else
                            ////{
                            ////    strdt_Feb = "02/28/" + dtOriginal_RenewalDate.Year;
                            ////}
                            d_Feb = Convert.ToDateTime(strdt_Feb);

                            cnt1++;
                            oWordDoc.Tables[2].Cell(5, cnt1).Select();
                            oWordDoc.Tables[2].Cell(5, cnt1).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // For Funding Method
                            objCommFun.Get_Funding_Method_Topic(j, 8, cnt1, oWordDoc, OptionFieldValueiD, EffectiveDate, dtOriginal_RenewalDate.Year, ddlHRA.SelectedItem.ToString(), EffectiveDate.Month);

                            //For Renewal month Topic
                            //ddlReportFormatCompliance_selectedindex is optional parameter in the following function whoes value set to 0 by default
                            objCommFun.Get_Renewal_Month_Topic(j, 8, cnt1, oWordDoc, ddlGroupMWEA.SelectedItem.ToString(), ddlIsEmpInCA.SelectedItem.ToString(), d_Feb, dtOriginal_RenewalDate, ddlHRA.SelectedItem.ToString(), dtOriginal_RenewalDate.Year, OptionFieldValueiD, ddlMassachusetts, ddlReportFormatCompliance_selectedindex);


                            // For Full Time Employees Topic
                            if (j == 1 || j == 2) // Only applicable when the month is January
                            {
                                if (j == 1 && !(objCommFun.If_Weekend_Or_Holiday(d_Jan)))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 8, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                    AnnualComplianceCalendar_DeadLineMoveLogic(j, 8, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                                }
                                else if (j == 2 && objCommFun.If_Weekend_Or_Holiday(d_Jan))
                                {
                                    //objCommFun.Get_Full_Time_Employees_Topic(j, 8, cnt1, oWordDoc, d_Jan, Num_Of_FTE, OptionFieldValueiD);
                                }
                            }
                            else if (j == 3)
                            {
                                AnnualComplianceCalendar_DeadLineMoveLogic(j, 8, cnt1, oWordDoc, EffectiveDate, Num_Of_FTE, OptionFieldValueiD);
                                if (oWordDoc.Tables[2].Cell(4, cnt).Range.Text.Length > 2)
                                {
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.Text = oWordDoc.Tables[2].Cell(4, cnt).Range.Text + Mar_text_sat_sun;
                                }
                                else
                                {
                                    // For applying bullets in a cell
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(4, cnt).Range.Text = Mar_text_sat_sun;
                                }
                            }
                        }

                        #endregion
                    }
                }
                #endregion

                // For common and static text call the following function
                objCommFun.Get_Compliance_Constant_Text(oWordDoc, 4, 8);



                #region MergeField

                /*-------------- Modified by Amogh Vilayatkar 26/12/2017 --------------*/

                #region Footnote dynamic Generation Logic - by Amogh Vilayatkar 26/12/2017

                StringBuilder footnoteText = new StringBuilder();
                string footnote2 = string.Empty;
                string footNote4_SecondDate = string.Empty;
                string footNote4_FirstDate = string.Empty;

                DateTime dateFirst = new DateTime();
                DateTime dateSecond = new DateTime();
                // First Date Check 
                dateFirst = getFootNoteDate(1, EffectiveDate);
                footNote4_FirstDate = objCommFun.GetNextBusinessDay_For_Holiday(dateFirst.Month, dateFirst.Year, dateFirst);
                if (String.IsNullOrEmpty(footNote4_FirstDate))
                {
                    footNote4_FirstDate = dateFirst.ToShortDateString();
                }
                else { footNote4_FirstDate = footNote4_FirstDate + "/" + dateFirst.Year; }

                // Second Date Check logic
                dateSecond = getFootNoteDate(2, EffectiveDate);
                footNote4_SecondDate = objCommFun.GetNextBusinessDay_For_Holiday(dateSecond.Month, dateSecond.Year, dateSecond);
                if (String.IsNullOrEmpty(footNote4_SecondDate))
                {
                    footNote4_SecondDate = dateSecond.ToShortDateString();
                }
                else { footNote4_SecondDate = footNote4_SecondDate + "/" + dateSecond.Year; }

                switch (EffectiveDate.Year)
                {
                    case 2017: footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        break;
                    case 2018: footnote2 = "\u00B2 2018 OOPMs ($7,350/$14,700 Non-GF, $6,650/$13,300 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,450/$6,900.";
                        break;
                    ////case 2019: footnote2 = "\u00B2 2019 OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced.";
                    ////    break;
                    case 2019: footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        break;
                    default:
                        if (EffectiveDate.Year <= 2017)
                        {
                            footnote2 = "\u00B2 2017 OOPMs ($7,150/$14,300 Non-GF, $6,550/$13,100 QHDHP), QHDHP minimum deductible $1,300/$2/600, maximum HSA contribution $3,400/$6,750.";
                        }
                        else if (EffectiveDate.Year >= 2019)
                        {
                            ////footnote2 = "\u00B2 " + EffectiveDate.Year + " OOPMs, QHDHP minimum deductible, and maximum HSA contribution have not yet been announced.";
                            footnote2 = "\u00B2 2019 OOPMs ($7,900/$15,800 Non-GF, $6,750/$13,500 QHDHP), QHDHP minimum deductible $1,350/$2,700, maximum HSA contribution $3,500/$7,000.";
                        }
                        break;
                }

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 2")
                    {
                        footnoteText.Append("\u00B9 The plan year is equivalent to the stability period for ongoing employees.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append(footnote2);
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u00B3 Benefit information may include the value of group health plan coverage, the value of group term life in excess of $50,000, HSA contributions, or additional Medicare tax.");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2074 If Form 5558 filing extension submitted, Form 5500 is due " + footNote4_FirstDate + " and SAR is due to plan participants by " + footNote4_SecondDate + ".");
                        footnoteText.Append(Environment.NewLine);
                        footnoteText.Append("\u2075 Annual notices include SBCs, HIPAA Notice of Privacy Practice, HIPAA Notice of Special Enrollment Rights, ACA Patient Protections, CHIPRA Notice, Wellness, and WHCRA Annual Notice.");
                        shape.Select();
                        shape.TextFrame.ContainingRange.Text = Convert.ToString(footnoteText);
                    }
                }

                #endregion

                /*--------------End Modification by Amogh --------------*/

                // Write the common fields on the template
                objCommFun.Write_Field_Values_On_Template(oWordDoc, oWordApp, ddlClient, EffectiveDate);

                // Function writes the date in Footer section
                objCommFun.Write_DateInto_Footer(oWordDoc, oWordApp);
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Flag">To check For Month for 10 or last Month of Plan </param>
        /// <param name="planEffectiveDate"> Effective Date of Plan</param>
        /// <returns></returns>
        private DateTime getFootNoteDate(int Flag, DateTime planEffectiveDate)
        {
            DateTime returnEffectiveDate = new DateTime();
            //EffectiveDate = DateTime.Parse("6/1/2017");

            if (Flag == 1)// here we check 10 month of 15 day of Plan year 
            {
                returnEffectiveDate = planEffectiveDate.AddMonths(09).AddDays(-(planEffectiveDate.Day - 15));
                if (returnEffectiveDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    returnEffectiveDate = returnEffectiveDate.AddDays(2);
                }
                // If the last day of month is sunday then add 1 day in the current date
                else if (returnEffectiveDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    returnEffectiveDate = returnEffectiveDate.AddDays(1);
                }
            }
            else // here we check Last month of 15 day of Plan year 
            {
                returnEffectiveDate = planEffectiveDate.AddMonths(11).AddDays(-(planEffectiveDate.Day - 15));
                if (returnEffectiveDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    returnEffectiveDate = returnEffectiveDate.AddDays(2);
                }
                // If the last day of month is sunday then add 1 day in the current date
                else if (returnEffectiveDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    returnEffectiveDate = returnEffectiveDate.AddDays(1);
                }
            }

            return returnEffectiveDate;
        }

        /// <summary>
        /// Here We make the logc which Changes to the Annual Compliance Calendar dealline in March & Jan depending on Lisa Requirement
        /// </summary>
        /// <param name="monthno"></param>
        /// <param name="row">table Row Number</param>
        /// <param name="col">table Column number</param>
        /// <param name="oWordDoc"></param>
        /// <param name="effDate">Plan Effective Date</param>
        /// <param name="Num_Of_FTE">Number of FET</param>
        /// <param name="OptionFieldValueiD">Option Field Value ID</param>
        ////private void AnnualComplianceCalendar_DeadLineMoveLogic(int monthno, int row, int col, Word.Document oWordDoc, DateTime effDate, int Num_Of_FTE, int OptionFieldValueiD)
        ////{
        ////    string gt_50_FI = " - Distribute Form 1095-C to each ACA FTE";

        ////    /*--- Added by Amogh ---- */
        ////    DateTime conditonDateFeb = DateTime.ParseExact("02-01-2018", "MM-dd-yyyy", null);
        ////    DateTime conditonDateMarch = DateTime.ParseExact("03-01-2018", "MM-dd-yyyy", null);
        ////    DateTime conditonDateFromApr2017 = DateTime.ParseExact("04-01-2017", "MM-dd-yyyy", null);
        ////    DateTime conditonDateToJan2018 = DateTime.ParseExact("01-31-2018", "MM-dd-yyyy", null);

        ////    oWordDoc.Tables[2].Cell(row, col).Select();

        ////    // For Checking January Last day 
        ////    // If the last day of January month is saturday then add 2 days in the current date
        ////    if (effDate.DayOfWeek == DayOfWeek.Saturday)
        ////    {
        ////        effDate = effDate.AddDays(2);
        ////    }
        ////    // If the last day of January month is sunday then add 1 day in the current date
        ////    else if (effDate.DayOfWeek == DayOfWeek.Sunday)
        ////    {
        ////        effDate = effDate.AddDays(1);
        ////    }
        ////    else
        ////    {
        ////        //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
        ////    }
        ////    DateTime EffectiveDate = effDate;
        ////    // 52403 : is for self insured
        ////    if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52401)
        ////    {
        ////        if (conditonDateMarch < EffectiveDate) // If Plan year Date Greater then 31st March 2018 
        ////        {
        ////            if (monthno == 1)
        ////            {
        ////                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_FI;
        ////                }
        ////                else
        ////                {
        ////                    // For applying bullets in a cell
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_FI;
        ////                }
        ////            }
        ////        }
        ////        else if (EffectiveDate <= conditonDateMarch && EffectiveDate >= conditonDateFeb) // If Plan year Date between 02-01-2018 - 03-01-2018
        ////        {
        ////            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        ////            {
        ////                if (monthno == 3)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_FI;
        ////                }
        ////                if (monthno == 1)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_FI;
        ////                }
        ////            }
        ////            else
        ////            {
        ////                // For applying bullets in a cell
        ////                if (monthno == 3)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_FI;
        ////                }
        ////                if (monthno == 1)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_FI;
        ////                }
        ////            }
        ////        }
        ////        else if (EffectiveDate >= conditonDateFromApr2017 && EffectiveDate <= conditonDateToJan2018) // If plan year is between 04-01-2017 TO 01-31-2018 
        ////        {
        ////            if (monthno == 3)
        ////            {
        ////                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_FI;
        ////                }
        ////                else
        ////                {
        ////                    // For applying bullets in a cell
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_FI;
        ////                }
        ////            }
        ////        }
        ////        else if (EffectiveDate < conditonDateFromApr2017) // IF Plan year less than 04-01-2017  
        ////        {
        ////            if (monthno == 3)
        ////            {
        ////                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/31" + gt_50_FI;
        ////                }
        ////                else
        ////                {
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        ////                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/31" + gt_50_FI;
        ////                }
        ////            }
        ////        }
        ////    }

        ////}

        /*--- Added by Amogh ---- */
        //private void AnnualComplianceCalendar_DeadLineMoveLogic(int monthno, int row, int col, Word.Document oWordDoc, DateTime effDate, int Num_Of_FTE, int OptionFieldValueiD)
        //{
        //    string gt_50_FullyInsured = " - Distribute Form 1095-C to each ACA FTE";
        //    string gt_50_SelfInsured = " - Distribute Form 1095-C to each ACA FTE and each covered primary insured";

        //    oWordDoc.Tables[2].Cell(row, col).Select();

        //    // For Checking January Last day 
        //    // If the last day of January month is saturday then add 2 days in the current date
        //    if (effDate.DayOfWeek == DayOfWeek.Saturday)
        //    {
        //        effDate = effDate.AddDays(2);
        //    }
        //    // If the last day of January month is sunday then add 1 day in the current date
        //    else if (effDate.DayOfWeek == DayOfWeek.Sunday)
        //    {
        //        effDate = effDate.AddDays(1);
        //    }
        //    else
        //    {
        //        //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
        //    }
        //    DateTime EffectiveDate = effDate;

        //    if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52401) // 52403 : is for FULLY insured
        //    {
        //        if (effDate.Year >= 2019)
        //        {
        //            if (monthno == 3)
        //            {
        //                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                {
        //                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_FullyInsured;
        //                }
        //                else
        //                {
        //                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_FullyInsured;
        //                }
        //            }
        //        }
        //        else if (effDate.Year < 2019)
        //        {
        //            if (effDate.Year == 2018)
        //            {
        //                if (monthno == 3)
        //                {
        //                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_FullyInsured;
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_FullyInsured;
        //                    }
        //                }
        //            }
        //            if (effDate.Year <= 2017)
        //            {
        //                if (monthno == 1)
        //                {
        //                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_FullyInsured;
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_FullyInsured;
        //                    }
        //                }
        //            }
        //        }//Outer Else If close here 
        //    }
        //    else if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52403) // 52403 : is for self insured
        //    {
        //        if (effDate.Year >= 2019)
        //        {
        //            if (monthno == 3)
        //            {
        //                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                {
        //                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_SelfInsured;
        //                }
        //                else
        //                {
        //                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                    oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_SelfInsured;
        //                }
        //            }
        //        }
        //        else if (effDate.Year < 2019)
        //        {
        //            if (effDate.Year == 2018)
        //            {
        //                if (monthno == 3)
        //                {
        //                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_SelfInsured;
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_SelfInsured;
        //                    }
        //                }
        //            }
        //            if (effDate.Year <= 2017)
        //            {
        //                if (monthno == 1)
        //                {
        //                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_SelfInsured;
        //                    }
        //                    else
        //                    {
        //                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_SelfInsured;
        //                    }
        //                }
        //            }
        //        }
        //    }





        //    ////if (effDate.Year >= 2019 && Num_Of_FTE >= 50 && OptionFieldValueiD == 52401)
        //    ////{
        //    ////    if (monthno == 3)
        //    ////    {
        //    ////        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //    ////        {
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_FI;
        //    ////        }
        //    ////        else
        //    ////        {
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_FI;
        //    ////        }
        //    ////    }
        //    ////}
        //    ////else if (effDate.Year < 2019 && Num_Of_FTE >= 50 && OptionFieldValueiD == 52401)
        //    ////{
        //    ////    if (monthno == 1)
        //    ////    {
        //    ////        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
        //    ////        {
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_FI;
        //    ////        }
        //    ////        else
        //    ////        {
        //    ////            // For applying bullets in a cell
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
        //    ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_FI;
        //    ////        }
        //    ////    }
        //    ////}
        //}


        private void AnnualComplianceCalendar_DeadLineMoveLogic(int monthno, int row, int col, Word.Document oWordDoc, DateTime effDate, int Num_Of_FTE, int OptionFieldValueiD)
        {
            ////    /*--- Added by Amogh ---- */
            DateTime conditonDateFeb2019 = DateTime.ParseExact("02-01-2019", "MM-dd-yyyy", null);
            DateTime conditonDateMarch2019 = DateTime.ParseExact("03-31-2019", "MM-dd-yyyy", null);
            DateTime conditonDateToJan2019 = DateTime.ParseExact("01-01-2019", "MM-dd-yyyy", null);

            DateTime conditonDateToJan2018 = DateTime.ParseExact("01-01-2018", "MM-dd-yyyy", null);


            string gt_50_FullyInsured = " - Distribute Form 1095-C to each ACA FTE";
            string gt_50_SelfInsured = " - Distribute Form 1095-C to each ACA FTE and each covered primary insured";

            oWordDoc.Tables[2].Cell(row, col).Select();

            // For Checking January Last day 
            // If the last day of January month is saturday then add 2 days in the current date
            if (effDate.DayOfWeek == DayOfWeek.Saturday)
            {
                effDate = effDate.AddDays(2);
            }
            // If the last day of January month is sunday then add 1 day in the current date
            else if (effDate.DayOfWeek == DayOfWeek.Sunday)
            {
                effDate = effDate.AddDays(1);
            }
            else
            {
                //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
            }
            DateTime EffectiveDate = effDate;

            if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52401) // 52401 : is for FULLY insured
            {
                if (EffectiveDate >= conditonDateFeb2019) // If Plan year February 2019 or later
                {
                    if (monthno == 1)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_FullyInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_FullyInsured;
                        }
                    }
                    if (monthno == 3)
                    {
                        if (EffectiveDate <= conditonDateMarch2019)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_FullyInsured;
                            }
                            else
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_FullyInsured;
                            }
                        }
                    }
                }
                else if (EffectiveDate >= conditonDateToJan2019 && EffectiveDate <= conditonDateMarch2019) // If Plan Year between January 2019 – March 2019
                {
                    if (monthno == 3)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_FullyInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_FullyInsured;
                        }
                    }
                }
                else if (EffectiveDate < conditonDateToJan2019 && EffectiveDate >= conditonDateToJan2018)
                {
                    if (monthno == 3)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_FullyInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_FullyInsured;
                        }
                    }
                }
            }
            else if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52403) // 52403 : is for self insured
            {
                if (EffectiveDate >= conditonDateFeb2019) // If Plan year February 2019 or later
                {
                    if (monthno == 1)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "1/31" + gt_50_SelfInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "1/31" + gt_50_SelfInsured;
                        }
                    }
                    if (monthno == 3)
                    {
                        if (EffectiveDate <= conditonDateMarch2019)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_SelfInsured;
                            }
                            else
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_SelfInsured;
                            }
                        }
                    }
                }
                else if (EffectiveDate >= conditonDateToJan2019 && EffectiveDate <= conditonDateMarch2019) // If Plan Year between January 2019 – March 2019
                {
                    if (monthno == 3)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/4" + gt_50_SelfInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/4" + gt_50_SelfInsured;
                        }
                    }
                }
                else if (EffectiveDate < conditonDateToJan2019 && EffectiveDate >= conditonDateToJan2018)
                {
                    if (monthno == 3)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "3/2" + gt_50_SelfInsured;
                        }
                        else
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = "3/2" + gt_50_SelfInsured;
                        }
                    }
                }
            }

        }

        private void GetRenewalMonth_6_Text(Word.Document oWordDoc, int new_Month, DateTime EffectiveDate, DateTime dtOriginal_RenewalDate, int rowNum)
        {
            int renCnt = 1;
            DateTime d_date;
            DateTime cal_date;
            string ren_Text = string.Empty;
            string date_text = string.Empty;

            if (new_Month > 12)
            {
                new_Month = new_Month - 12;
                d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + "/" + dtOriginal_RenewalDate.Year);
                //ren_Text = new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                ren_Text = new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2074";

                if (objCommFun.If_Weekend_Or_Holiday(d_date))
                {
                    renCnt = 2;
                    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    //ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                    ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2074";
                }
            }
            else
            {
                d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + "/" + EffectiveDate.Year);
                //ren_Text = new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                ren_Text = new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + " – File form 5500 (or Form 5558 for an extension)" + "\u2074";

                if (objCommFun.If_Weekend_Or_Holiday(d_date))
                {
                    renCnt = 2;
                    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    //ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2075";
                    ren_Text = date_text + " – File form 5500 (or Form 5558 for an extension)" + "\u2074";
                }
            }
            oWordDoc.Tables[2].Cell(rowNum, renCnt).Select();

            if (oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text.Length > 2)
            {
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text = oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text + ren_Text;
            }
            else
            {
                // For applying bullets in a cell
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.ListFormat.ApplyBulletDefault();
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text = ren_Text;
            }
        }

        private void GetRenewalMonth_8_Text(Word.Document oWordDoc, int new_Month, DateTime EffectiveDate, DateTime dtOriginal_RenewalDate, int rowNum)
        {
            int renCnt = 3;
            DateTime d_date;
            DateTime cal_date;
            string ren_Text = string.Empty;
            string date_text = string.Empty;
            if (new_Month > 12)
            {
                new_Month = new_Month - 12;
                d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + "/" + dtOriginal_RenewalDate.Year);
                //ren_Text = new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + " – SAR due to plan participants" + "\u2076";
                ren_Text = new_Month + "/" + DateTime.DaysInMonth(dtOriginal_RenewalDate.Year, new_Month) + " – SAR due to plan participants";

                if (objCommFun.If_Weekend_Or_Holiday(d_date))
                {
                    renCnt = 4;
                    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    //ren_Text = date_text + " – SAR due to plan participants" + "\u2076";
                    ren_Text = date_text + " – SAR due to plan participants";
                }
            }
            else
            {
                d_date = Convert.ToDateTime(new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + "/" + EffectiveDate.Year);
                //ren_Text = new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + " – SAR due to plan participants" + "\u2076";
                ren_Text = new_Month + "/" + DateTime.DaysInMonth(EffectiveDate.Year, new_Month) + " – SAR due to plan participants";

                if (objCommFun.If_Weekend_Or_Holiday(d_date))
                {
                    renCnt = 4;
                    date_text = objCommFun.GetNextBusinessDay(d_date, out cal_date);
                    date_text = objCommFun.GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    //ren_Text = date_text + " – SAR due to plan participants" + "\u2076";
                    ren_Text = date_text + " – SAR due to plan participants";
                }
            }
            oWordDoc.Tables[2].Cell(rowNum, renCnt).Select();

            if (oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text.Length > 2)
            {
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text = oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text + ren_Text;
            }
            else
            {
                // For applying bullets in a cell
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.ListFormat.ApplyBulletDefault();
                oWordDoc.Tables[2].Cell(rowNum, renCnt).Range.Text = ren_Text;
            }
        }
    }
}