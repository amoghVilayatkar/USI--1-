﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.Tools;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.Pilot;

namespace BenefitPointSummaryPortal.View
{
    public partial class Tools_ClientRevenueSummary : System.Web.UI.Page
    {

        Hashtable myHashtable;

        #region Global Variable
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList(); // For newly added AD&D plan
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        ArrayList StopLossBenefitColumnIdList = new ArrayList();
        ArrayList FeesForServiceBenefitColumnIdList = new ArrayList();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToString(Session["Summary"]) == "ClientRevenueSummary")
                {
                    spanBenchmarkingAuditReport.Visible = true;
                    spanContractReviewChecklists_Plan.Visible = true;
                    TitleSpan.InnerText = "Client Revenue Summary";
                }
                if (!IsPostBack)
                {
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    DictDepartment = sd.getDepartmentDetails();
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    txtsearch.Focus();
                    Activity = TitleSpan.InnerText;
                    //Activity_Group = "Pilot";
                    Activity_Group = "Tools";
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }//PageLoad Close


        /// <summary>
        /// View Button Logic
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlLayoutOption.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset the Field Data
        /// </summary>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();
                SessionId = Session["SessionId"].ToString();
                ddlLayoutOption.SelectedIndex = 0;
                ddlClient.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        /// <summary>
        /// Load the Plan Detail depending on Selected Client 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                Hashtable htSortedPlanList = new Hashtable();
                if (Convert.ToString(Session["Summary"]) == "ClientRevenueSummary" && ddlClient.SelectedIndex != -1)
                {
                    htSortedPlanList = ClientRevenueSummary_planList();
                }
                else if (ddlClient.SelectedIndex == -1)
                {
                    flag = false;
                }


                if (flag == true)
                {
                    grdPlans.DataSource = null;
                    grdPlans.DataBind();
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                if (Convert.ToString(Session["Summary"]) == "ClientRevenueSummary")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }//IfSummaryCheck Close
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();
                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.SummaryName, l.CarrierName ascending
                                           select l).ToList();

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlans.Visible = true;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                        else
                        {
                            string script = "alert(\"No plans for selected client.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                    else
                    {
                        string script = "alert(\"No plans for selected client.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }//IfFlag Close
            }//tryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private Hashtable ClientRevenueSummary_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            htSortedPlanList.Add(15, 260);   // Voluntary Life
            htSortedPlanList.Add(16, 270);   // AD&D
            htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125

            htSortedPlanList.Add(21, 130);   // Medical
            //htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            /**************************** AS PER NICOLE - [Client Revenue Summary - Issue #3 - Update plans list] please update the Available Plans list to include the Plan type, Stop Loss***/
            htSortedPlanList.Add(25, 235);    //Stop Loss
            htSortedPlanList.Add(26, 340);   //401(k)
            htSortedPlanList.Add(27, 294);	 //Hawaii TDI
            htSortedPlanList.Add(28, 410);	 //International Bundled Plan (3-Tier)
            htSortedPlanList.Add(29, 233);	 //Limited Benefit 2-Tier
            htSortedPlanList.Add(30, 293);	 //New Jersey TDB
            htSortedPlanList.Add(31, 292);	 //New York DBL
            htSortedPlanList.Add(32, 173);	 //Prescription Drug (Carve-Out)
            htSortedPlanList.Add(33, 320);	 //Business Travel Accident (BTA)
            //htSortedPlanList.Add(26, 1108);   //Fees for Service
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                DataTable PlanInfoTable = new DataTable();
                PlanInfoTable = GetPlanInfoTable();

                if (Convert.ToString(Session["Summary"]) == "ClientRevenueSummary")
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }

                    if (PlanInfoTable != null)
                    {
                        if (PlanInfoTable.Rows.Count > 0)
                        {
                            foreach (GridViewRow oItem in grdPlans.Rows)
                            {
                                CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
                                Label lblProductType = oItem.Cells[7].FindControl("ProductTypeId") as Label;
                                if (chkSelect.Checked)
                                {
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            if (grdPlans.Rows.Count > 0)
                            {
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            flag = false;
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                        }
                    }
                }

                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    List<Carrier> carrierList = new List<Carrier>();

                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();
                    sd.BuildContributionTable_Pilot();
                    sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    //sd.BuildRateTable();
                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    //code used for contract review and benchmark audit report
                    #region common for both



                    DataTable PlanTable = new DataTable();
                    PlanTable.Merge(PlanInfoTable);

                    RateDS = sd.GetRateForClientRevenue(PlanTable, SessionId);
                    //ContributionDS = sd.GetContributionForPilot(PlanTable, SessionId);
                    var table = from x in PlanInfoTable.AsEnumerable() where !string.IsNullOrEmpty(x.Field<string>("PlanType")) select x;

                    PlanTable.Clear();
                    foreach (dynamic i in table)
                    {
                        PlanTable.NewRow();
                        PlanTable.ImportRow(i);
                    }
                    ProductDS = sd.GetProductDetail(PlanTable, SessionId);
                    BenefitDS = sd.GetBenefitSummaryPilot(PlanTable, SessionId);
                    DataTable ProductType = new DataTable();
                    ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductType.Columns.Add("PlanNumber", typeof(string));
                    ProductType.Columns.Add("ProductId", typeof(Int32));
                    DataRow[] foundrow = null;

                    for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    {
                        ProductType.Rows.Add();
                        ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);
                        foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");
                        ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                        ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                        ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);
                    }
                    BenefitStructureDS = sd.GetBenefitSummaryStructurePilot(ProductType, SessionId);
                    carrierList = bp.GetAllCarriers(SessionId);
                    #endregion

                    if (Convert.ToString(Session["Summary"]) == "ClientRevenueSummary")
                    {
                        ////CreateReports_ClientRevenueSummary(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, RateDS);
                        CreateReports_ClientRevenueSummary(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, RateDS, ContactList);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }//Btn Summary Close


        /// <summary>
        /// Create and Download the Report 
        /// </summary>
        /// <param name="SessionId"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="BenefitStructureDS"></param>
        /// <param name="AccountTeamMemberDS"></param>
        /// <param name="AccountDS"></param>
        /// <param name="carrierList"></param>
        protected void CreateReports_ClientRevenueSummary(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, DataSet RateDS, List<Contact> ContactList)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Workbook myWorkbookdest = null;
            Excel.Worksheet myWorksheetdest = null;

            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string strFileName = string.Empty;
                string strReportName = string.Empty;

                if (ddlLayoutOption.SelectedItem.Value == "1") // Landscape Format
                {
                    strFileName = "ClientRevenueSummary_Template_Landscape";
                    strReportName = "Report8 - Landscape";
                }
                else if (ddlLayoutOption.SelectedItem.Value == "2") // Portrait Format
                {
                    strFileName = "ClientRevenueSummary_Template_Portrait";
                    strReportName = "Report8 - Portrait";
                }

                string myPath = Server.MapPath("~/Files/Tools/Documents/Templates/" + strFileName + ".xlsx");
                string myPathdest = Server.MapPath("~/Files/Tools/Documents/Templates/Contract_Review_Blank.xlsx");
                myExcelApp.DisplayAlerts = false;

                myWorkbookdest = myExcelApp.Workbooks.Open(myPathdest);
                myWorkbook = myExcelApp.Workbooks.Open(myPath);

                myWorksheetdest = myWorkbookdest.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName));
                }

                myWorkbookdest.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                WriteTools_ClientRevenueSummary wr = new WriteTools_ClientRevenueSummary();
                LoadColumnIdArrayList();

                //// get process ids before running the excel codes
                //CheckExcellProcesses();

                string SummaryName_SheetName = string.Empty;

                #region Plan Overview
                //for (int i = 1; i <= myWorkbook.Worksheets.Count; i++)
                //{
                SummaryName_SheetName = "Revenue Summary";
                Excel.Worksheet wkSheet1 = (Excel.Worksheet)myWorkbook.Worksheets[1];

                if (wkSheet1.Name == SummaryName_SheetName)
                {
                    (myWorkbook.Worksheets[wkSheet1.Name] as Excel.Worksheet).Copy(Before: myWorkbookdest.Worksheets[1]);
                    myWorksheetdest = myWorkbookdest.Worksheets[1];
                    wr.WriteClientOverview(myExcelApp, ddlClient, myWorksheetdest.Name, AccountDS, AccountTeamMemberDS);
                    for (int k = 0; k < PlanTable.Rows.Count; k++)
                    {
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(PlanTable.Rows[k]["ProductId"].ToString()), SessionId);
                        wr.WritePlanSection(myExcelApp, PlanTable, ProductDS, BenefitDS, RateDS, ddlClient, AccountDS, BenefitStructureDS, AccountTeamMemberDS, carrierList, PlanTable.Rows[k]["SummaryID"].ToString(), OptionFieldValueiD);
                    }
                    //    break;
                }
                //}
                //}

                #endregion

                /////Deleting Sheet1(Default Sheet)
                if (myWorkbookdest.Worksheets.Count > 1)
                {
                    for (int i = 1; i <= myWorkbookdest.Worksheets.Count; i++)
                    {
                        Excel.Worksheet wkSheet = (Excel.Worksheet)myWorkbookdest.Worksheets[i];
                        if (wkSheet.Name == "Sheet1")
                        {
                            wkSheet.Delete();
                        }
                    }
                }
                myWorksheetdest = (Excel.Worksheet)myWorkbookdest.Worksheets[1];
                myWorksheetdest.Activate();

                myWorkbookdest.Save();
                myWorkbook.Save();
                myWorkbookdest.Close(true, Type.Missing, Type.Missing);
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(Convert.ToString(savefilename));

                string AdditionalCrtieriaOption_1 = ddlLayoutOption.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);


                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;

                Marshal.FinalReleaseComObject(myWorksheetdest);
                myWorksheetdest = null;
                Marshal.FinalReleaseComObject(myWorkbookdest);
                myWorkbookdest = null;

                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myWorksheetdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheetdest);
                    myWorksheetdest = null;
                }
                if (myWorkbookdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }
                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheetdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheetdest);
                    myWorksheetdest = null;
                }
                if (myWorkbookdest != null)
                {
                    myWorkbookdest.Close();
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }


        }

        /// <summary>
        /// Create Plan Informartion Table 
        /// </summary>
        /// <returns></returns>
        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds_Pilot();
            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 5))
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[9].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.StopLossPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.StopLoss;
                            }
                            if (CommonFunctionsBS.FeesForServicePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FeesForService;
                            }
                            rowCount++;
                        }
                    }//Foreach Close

                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Create Plan Info Table 
        /// </summary>
        /// <returns></returns>
        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");


                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");


                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // AD&D
                ADDBenefitColumnIdList.Add("129");

                //Stop Loss
                //StopLossBenefitColumnIdList.Add("235");
                StopLossBenefitColumnIdList.Add("141");

                //Fees for Service
                FeesForServiceBenefitColumnIdList.Add("1108");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File in Excel Format.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }//PartialPage CLose
}