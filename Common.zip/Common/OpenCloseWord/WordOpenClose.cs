﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;


namespace BenefitPointSummaryPortal.Common.OpenCloseWord
{

    public class WordOpenClose : System.Web.UI.Page
    {
      public  Word_Office office=new BenefitSummary.Word_Office ();
      BPBusiness bp = new BPBusiness();
        public string Save_File = null;



        public void Word_Open(Word.ApplicationClass oWordApp, Word.Document oWordDoc,string filename,string _savefilename,Object missing)
        {
            office.oWordApp = new Word.ApplicationClass();
           // Object missing = System.Reflection.Missing.Value;


            Object fileName = Server.MapPath(filename);

            Object readOnly = true;
            Object isVisible = false;

            office.oWordDoc = office.oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath(_savefilename + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +

                                 ".docm");

            try
            {
                office.oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;

               office.oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

               Save_File = savefilename.ToString();
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            
        }

        public void Word_Close(Word.ApplicationClass oWordApp, Word.Document oWordDoc, Object missing)
        {

            if (office.oWordApp != null)
            {

                ((Microsoft.Office.Interop.Word._Document)office.oWordDoc).Close(ref missing, ref missing, ref missing);
                Marshal.ReleaseComObject(oWordDoc);

                office.oWordDoc = null;
                office.oWordApp.Quit(ref missing, ref missing, ref missing);
                Marshal.FinalReleaseComObject(office.oWordApp);
                office.oWordApp = null;

            }
        }

        public void Word_Open_DOCX(Word.ApplicationClass oWordApp, Word.Document oWordDoc, string filename, string _savefilename, Object missing)
        {
            office.oWordApp = new Word.ApplicationClass();
            // Object missing = System.Reflection.Missing.Value;


            Object fileName = Server.MapPath(filename);

            Object readOnly = true;
            Object isVisible = false;

            office.oWordDoc = office.oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath(_savefilename + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +

                                 ".docx");

            try
            {
                office.oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;

                office.oWordDoc.SaveAs(ref savefilename,
                     ref missing, ref missing, ref missing, ref missing, ref missing,
                     ref missing, ref missing, ref missing, ref missing, ref missing,
                     ref missing, ref missing, ref missing, ref missing, ref missing);

                Save_File = savefilename.ToString();
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        public void Word_OpenReadOnly(Word.ApplicationClass oWordApp, Word.Document oWordDoc, string filename, Object missing)
        {
            office.oWordApp = new Word.ApplicationClass();
            // Object missing = System.Reflection.Missing.Value;


            Object fileName = Server.MapPath(filename);

            Object readOnly = true;
            Object isVisible = false;

            office.oWordDoc = office.oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);



            try
            {
                office.oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        public void ExportToPDF(string PDFPath)
        {
            try
            {
                office.oWordDoc.ExportAsFixedFormat(PDFPath, Word.WdExportFormat.wdExportFormatPDF);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}