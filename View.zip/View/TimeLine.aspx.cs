﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.Common.OpenCloseWord;

namespace BenefitPointSummaryPortal.View
{
    public partial class TimelLine : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        WordOpenClose wobj = new WordOpenClose();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        SummaryDetail sdd = new SummaryDetail();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                DictDepartment = sdd.getDepartmentDetails();
                if (!IsPostBack)
                {
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    //if (Request.QueryString["ReportName"] != null)
                    //{
                    //    Session["Summary"] = Request.QueryString["ReportName"];
                    //}

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();
                    if (Convert.ToString(Session["Summary"]) == "Timeline1")
                    {
                        TitleSpan.InnerText = "Renewal Timelines";
                    }

                    //if (Convert.ToString(Session["Summary"]) == "Timeline2")
                    //{
                    //    TitleSpan.InnerText = "Renewal – Small Group";
                    //    //lblTemplateNo.Text = "#1";
                    //}
                    txtsearch.Focus();
                    Activity = "Timelines";
                    Activity_Group = "Tools";
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                ddlActivity.Items.Clear();
                rdlActivity.SelectedIndex = 0;
                //BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            ddlActivity.SelectedIndex = 0;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                //BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                ddlActivity.Items.Clear();
                rdlActivity.SelectedIndex = 0;
                ddlLayout.SelectedIndex = 0;
                //Clear();

                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlActivity.Items.Clear();
            if (Convert.ToString(Session["Summary"]) == "Timeline1")
            {
                GetActivity_List(rdlActivity.SelectedItem.Text, tc.Timeline1_SubjectID, tc.Timeline2_SubjectID);
            }
            //else if (Convert.ToString(Session["Summary"]) == "Timeline2")
            //{
            //    GetActivity_List(rdlActivity.SelectedItem.Text, tc.Timeline2_SubjectID);
            //}
        }

        protected void rdlActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            SummaryDetail.isClientChanged_ForMedical = true;
            if (ddlActivity.SelectedIndex >= 0)
            {
                ddlActivity.SelectedIndex = 0;
                ddlActivity.Items.Clear();
                if (Convert.ToString(Session["Summary"]) == "Timeline1")
                {
                    GetActivity_List(rdlActivity.SelectedItem.Text, tc.Timeline1_SubjectID, tc.Timeline2_SubjectID);
                }
                //else if (Convert.ToString(Session["Summary"]) == "Timeline2")
                //{
                //    GetActivity_List(rdlActivity.SelectedItem.Text, tc.Timeline2_SubjectID);
                //}
            }
        }


        private void GetActivity_List(string rdlValue, int SubjectID_TL_1, int SubjectID_TL_2)
        {
            bool isActivityPresent = false;
            try
            {
                //BPBusiness bp = new BPBusiness();
                TimelineDetail timeD = new TimelineDetail();
                DataTable ActivityTable = new DataTable();
                DataTable ActivityTable_TL_1 = new DataTable();
                DataTable ActivityTable_TL_2 = new DataTable();
                string ActivityName = string.Empty;
                string ActivityID = string.Empty;
                SessionId = Session["SessionId"].ToString();
                int rowIndex = 1;
                //Clear();

                if (ddlClient.SelectedIndex == 0)
                {
                    ddlActivity.Items.Clear();
                }
                else
                {
                    ActivityTable_TL_1 = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID_TL_1);
                    ActivityTable_TL_2 = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID_TL_2);
                    ActivityTable = ActivityTable_TL_1;
                    ActivityTable.Merge(ActivityTable_TL_2);
                    Session["ActivityTable"] = ActivityTable;

                    if (ActivityTable.Rows.Count > 0)
                    {
                        ddlActivity.Items.Insert(0, new ListItem("Select", string.Empty));
                        for (int i = 0; i < ActivityTable.Rows.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["recordID"])))
                            {
                                ActivityID = Convert.ToString(ActivityTable.Rows[i]["recordID"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["subject"])))
                            {
                                ActivityName = Convert.ToString(ActivityTable.Rows[i]["subject"]);
                            }
                            //-- Do not delete code starts here --------------------------------------------------
                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["name"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["name"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["createdon"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["createdon"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["dueon"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["dueon"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["status"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["status"]);
                            ////}
                            //-- Do not delete code ends here --------------------------------------------------

                            if (rdlValue == "Open" && Convert.ToString(ActivityTable.Rows[i]["status"]).Trim().ToLower() == "open")
                            {
                                ddlActivity.Items.Insert(rowIndex, new ListItem(ActivityName, ActivityID + ";" + Convert.ToString(ActivityTable.Rows[i]["SubjectID"])));
                                rowIndex++;
                            }
                            else if (rdlValue == "All")
                            {
                                ddlActivity.Items.Insert(i + 1, new ListItem(ActivityName, ActivityID + ";" + Convert.ToString(ActivityTable.Rows[i]["SubjectID"])));
                            }
                        }
                        isActivityPresent = true;
                    }
                }

                if (isActivityPresent == false)
                {
                    if (ddlClient.SelectedItem.Text != "Select")
                    {
                        string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text + "'.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                SummaryDetail sd = new SummaryDetail();
                Session["PlanTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                //CreatePlanTable();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable ActivityTable = new DataTable();
                int selectedActivityID = 0;
                int selectedSubjectId = 0;
                //Activity_Group = "Timeline";

                if (Convert.ToString(Session["Summary"]) == "Timeline1")
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                        ddlClient.Focus();
                        return;
                    }
                    if (ddlActivity.SelectedIndex == 0 || ddlActivity.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Activity.')</script>");
                        flag = false;
                        ddlActivity.Focus();
                        return;
                    }
                    if (ddlLayout.SelectedIndex == 0 || ddlLayout.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Layout Option.')</script>");
                        flag = false;
                        ddlLayout.Focus();
                        return;
                    }
                }

                if (flag == true)
                {
                    string mynewfile = "";

                    //Insert New Activity Log
                    List<Contact> ContactList = new List<Contact>();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();

                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    // Get the Activity_ID and Subject_ID from the selected activity of dropdownlist
                    string[] arrActId = Convert.ToString(ddlActivity.SelectedItem.Value).Split(';').ToArray();
                    if (arrActId != null)
                    {
                        if (arrActId.Length > 0)
                        {
                            selectedActivityID = Convert.ToInt32(arrActId[0]);
                            selectedSubjectId = Convert.ToInt32(arrActId[1]);
                        }
                    }

                    if (selectedSubjectId == tc.Timeline1_SubjectID)
                    {
                        //Activity = "Renewal – Large Group";
                        mynewfile = CreateTimeLine1(tc.Timeline1_SubjectID, selectedActivityID, AccountDS, AccountTeamMemberDS, ContactList);
                    }
                    else if (selectedSubjectId == tc.Timeline2_SubjectID)
                    {
                        //Activity = "Renewal – Small Group";
                        mynewfile = CreateTimeLine2(tc.Timeline2_SubjectID, selectedActivityID, AccountDS, AccountTeamMemberDS, ContactList);
                    }

                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                Session["OffieceTable"] = null;
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;

                ///** Office Dropdown Enabled=False by Amogh*/
                ddlOffice.Enabled = false;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateTimeLine1(int SubjectID, int selectedActivityID, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Object missing = System.Reflection.Missing.Value;

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();



            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/TimeLine/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/TimeLine/Documents/Templates/Report1"));
                }
                string filename = ddlLayout.SelectedValue == "Portrait" ? "~/Files/TimeLine/Documents/Templates/RenewalTimeline_LG_Portrait_v2.docm" : "~/Files/TimeLine/Documents/Templates/RenewalTimeline_LG_Landscape_v2.docm";
                string _savefilename = "~/Files/TimeLine/Documents/Templates/Report1/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                WriteTimeline1 wt = new WriteTimeline1();
                ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);

                ActivityDS = timeD.Get_Activity_Detail(selectedActivityID, SessionId);
                wt.WriteFieldToTimeLine1(wobj.office.oWordDoc, wobj.office.oWordApp, Office, ddlOffice, ddlClient, ActivityDS, ActivityInfoTable);
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                string AdditionalCrtieriaOption_1 = ddlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = rdlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = "Large Group";
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Create Summary Template2
        /// </summary>
        protected string CreateTimeLine2(int SubjectID, int selectedActivityID, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Object missing = System.Reflection.Missing.Value;

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            DataSet ActivityDS = new DataSet();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/TimeLine/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/TimeLine/Documents/Templates/Report2"));
                }

                string filename = ddlLayout.SelectedValue == "Portrait" ? "~/Files/TimeLine/Documents/Templates/RenewalTimeline_SG_Portrait_v2.docm" : "~/Files/TimeLine/Documents/Templates/RenewalTimeline_SG_Landscape_v2.docm";
                string _savefilename = "~/Files/TimeLine/Documents/Templates/Report2/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                WriteTimeline2 wt = new WriteTimeline2();
                ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                ActivityDS = timeD.Get_Activity_Detail(selectedActivityID, SessionId);

                wt.WriteFieldToTimeLine2(wobj.office.oWordDoc, wobj.office.oWordApp, Office, ddlOffice, ddlClient, ActivityDS, ActivityInfoTable);

                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                string AdditionalCrtieriaOption_1 = ddlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = rdlActivity.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = "Small Group";
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

    }
}