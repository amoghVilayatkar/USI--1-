﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Word = Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.PHM
{
    public class VendorComparison
    {

        private void MergeTableColumns(Word.Document oWordDoc, int TableIndex, int MergeStart, int MergeEnd, int RowStartIndex, int RowEndIndex, List<int> SkippedRowIndexes)
        {
            Microsoft.Office.Interop.Word.Table objTable;
            objTable = oWordDoc.Tables[TableIndex];

            for (int i = RowStartIndex; i <= RowEndIndex; i++)
            {
                if (i > objTable.Rows.Count) break;
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(i))
                    {
                        objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                    }
                }
                else
                {
                    objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                }
            }
        }
        private void AdjustCellWidth(Word.Document oWordDoc, int TableIndex, int ColumnCount, List<int> SkippedRowIndexes, float TableWidth)
        {
            float CellWidth = TableWidth / ColumnCount;
            for (int Row = 2; Row <= oWordDoc.Tables[TableIndex].Rows.Count; Row++)
            {
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(Row))
                    {
                        for (int column = 2; column <= oWordDoc.Tables[TableIndex].Rows[Row].Cells.Count; column++)
                        {
                            oWordDoc.Tables[TableIndex].Rows[Row].Cells[column].Width = CellWidth;
                        }
                    }
                }
                else
                {
                    for (int column = 2; column <= oWordDoc.Tables[TableIndex].Rows[Row].Cells.Count; column++)
                    {
                        oWordDoc.Tables[TableIndex].Rows[Row].Cells[column].Width = CellWidth;
                    }
                }
            }
        }
        public void WriteCommonFieldToVendorComparisonTemplate(Word.Document oSourceWordDoc, Word.Application oSourceWordApp, Word.Document oDestinationWordDoc, Word.Application oDestinationApp, string ClientProspectName, string AccountContactRole, string AccountContactName, DataTable tblComparisomOptions)
        {
            Object missing = System.Reflection.Missing.Value;
            int tableIndex = 1;
            int ColumnIndex = 2;
            List<int> SkippedRowIndexes = new List<int>() { 1, 6 };
            float FullTableWidth = 0;
            float TableColumnsWidth = 0;
            int totalColumns = 5;
            int TotalRecords = tblComparisomOptions.Select("IsSelected = true").Count();

            FullTableWidth = oDestinationWordDoc.Tables[tableIndex].Cell(6, 1).Width;
            TableColumnsWidth = FullTableWidth - oDestinationWordDoc.Tables[tableIndex].Cell(2, 1).Width;

            switch (TotalRecords)
            {
                case 1:
                    MergeTableColumns(oDestinationWordDoc, tableIndex, 2, totalColumns, 2, int.MaxValue, SkippedRowIndexes);
                    AdjustCellWidth(oDestinationWordDoc, tableIndex, TotalRecords, SkippedRowIndexes, TableColumnsWidth);
                    break;
                case 2:
                    MergeTableColumns(oDestinationWordDoc, tableIndex, 3, totalColumns, 2, int.MaxValue, SkippedRowIndexes);
                    AdjustCellWidth(oDestinationWordDoc, tableIndex, TotalRecords, SkippedRowIndexes, TableColumnsWidth);
                    break;
                case 3:
                    MergeTableColumns(oDestinationWordDoc, tableIndex, 4, totalColumns, 2, int.MaxValue, SkippedRowIndexes);
                    AdjustCellWidth(oDestinationWordDoc, tableIndex, TotalRecords, SkippedRowIndexes, TableColumnsWidth);
                    break;
            }
            foreach (DataRow dr in tblComparisomOptions.Rows)
            {
                if (bool.Parse(dr["IsSelected"].ToString()) == true)
                {
                    switch (dr["ComparisonOptionName"].ToString())
                    {
                        #region Bravo
                        case "Bravo":
                            Word.Range Bravo_Overview = oSourceWordDoc.Tables[tableIndex].Cell(3, 2).Range;
                            Word.Range Bravo_Features = oSourceWordDoc.Tables[tableIndex].Cell(4, 2).Range;
                            Word.Range Bravo_Pricing = oSourceWordDoc.Tables[tableIndex].Cell(5, 2).Range;

                            oDestinationWordDoc.Tables[tableIndex].Cell(2, ColumnIndex).Range.Text = "BRAVO";
                            Bravo_Overview.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(3, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            Bravo_Features.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(4, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            Bravo_Pricing.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(5, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            ColumnIndex++;
                            break;
                        #endregion
                        #region Zomo
                        case "Zomo":
                            Word.Range Zomo_Overview = oSourceWordDoc.Tables[tableIndex].Cell(3, 5).Range;
                            Word.Range Zomo_Features = oSourceWordDoc.Tables[tableIndex].Cell(4, 5).Range;
                            Word.Range Zomo_Pricing = oSourceWordDoc.Tables[tableIndex].Cell(5, 5).Range;
                            oDestinationWordDoc.Tables[tableIndex].Cell(2, ColumnIndex).Range.Text = "ZOMO HEALTH";
                            Zomo_Overview.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(3, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            Zomo_Features.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(4, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            Zomo_Pricing.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(5, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            ColumnIndex++;
                            break;
                        #endregion
                        #region TriHealth Direction
                        case "TriHealth":
                            Word.Range TriHealthDirection_Overview = oSourceWordDoc.Tables[tableIndex].Cell(3, 4).Range;
                            Word.Range TriHealthDirection_Features = oSourceWordDoc.Tables[tableIndex].Cell(4, 4).Range;
                            Word.Range TriHealthDirection_Pricing = oSourceWordDoc.Tables[tableIndex].Cell(5, 4).Range;

                            oDestinationWordDoc.Tables[tableIndex].Cell(2, ColumnIndex).Range.Text = "TRIHEALTH HEALTHY DIRECTIONS";
                            TriHealthDirection_Overview.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(3, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            TriHealthDirection_Features.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(4, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            TriHealthDirection_Pricing.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(5, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            ColumnIndex++;
                            break;
                        #endregion
                        #region WellWorkForYou
                        case "Wellworks":
                            Word.Range WellWorkForYou_Overview = oSourceWordDoc.Tables[tableIndex].Cell(3, 3).Range;
                            Word.Range WellWorkForYou_Features = oSourceWordDoc.Tables[tableIndex].Cell(4, 3).Range;
                            Word.Range WellWorkForYou_Pricing = oSourceWordDoc.Tables[tableIndex].Cell(5, 3).Range;
                            oDestinationWordDoc.Tables[tableIndex].Cell(2, ColumnIndex).Range.Text = "WELLWORKS FOR YOU";
                            WellWorkForYou_Overview.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(3, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            WellWorkForYou_Features.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(4, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            WellWorkForYou_Pricing.Copy();
                            oDestinationWordDoc.Tables[tableIndex].Cell(5, ColumnIndex).Range.PasteAndFormat(Word.WdRecoveryType.wdPasteDefault);
                            ColumnIndex++;
                            break;
                        #endregion
                    }
                }
            }

            int iTotalFields = 0;
            try
            {
                foreach (Word.Field myMergeField in oDestinationWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;
                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("ClientProspectName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ClientProspectName))
                            {
                                oDestinationApp.Selection.TypeText(ClientProspectName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                        if (fieldName.Contains("AccountContactRoleAndName"))
                        {
                            myMergeField.Select();
                            if (string.IsNullOrEmpty(AccountContactRole) && string.IsNullOrEmpty(AccountContactName))
                            {
                                myMergeField.Delete();
                            }
                            else
                            {
                                if (AccountContactRole != string.Empty && AccountContactName != string.Empty)
                                    oDestinationApp.Selection.TypeText(AccountContactRole + ": " + AccountContactName);
                                else if (AccountContactRole != string.Empty)
                                    oDestinationApp.Selection.TypeText(AccountContactRole);
                                else
                                    oDestinationApp.Selection.TypeText(AccountContactName);
                            }
                            continue;
                        }
                        if (fieldName.Contains("AccountContactName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContactName))
                            {
                                oDestinationApp.Selection.TypeText(AccountContactName);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void WriteFooterFieldToVendorComparisonTemplate(Word.Document oWordDoc, Word.Application oWordApp, DateTime CurrentDate)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(CurrentDate.Year.ToString());
                                continue;
                            }
                        }
                    }
                }
            }
        }
    }
}