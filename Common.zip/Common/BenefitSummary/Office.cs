﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Office
    {

        #region Variable
        private int _officeId;
        private string _officeName;
        private string _regionName;
        # endregion

        #region Properties
        /// <summary>
        /// Get and Set OfficeId
        /// </summary>
        public int OfficeId
        {
            get
            {
                return _officeId;
            }
            set
            {
                _officeId = value;
            }
        }
        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public string OfficeNameText
        {
            get
            {
                return _officeName;

            }
            set
            {
                _officeName = value;
            }
        }
        /// <summary>
        /// Get and Set RegionName
        /// </summary>
        public string RegionName
        {
            get
            {
                return _regionName ;

            }
            set
            {
                _regionName = value;
            }
        }
        # endregion

    }
}