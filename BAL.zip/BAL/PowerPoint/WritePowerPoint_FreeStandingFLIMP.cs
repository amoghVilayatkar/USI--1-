﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.PowerPoint
{
    public class WritePowerPoint_FreeStandingFLIMP : System.Web.UI.Page
    {
        //Method To Write FLIMP Videos to Template
        internal void Write_FLIMPVideos(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Dictionary<string, string> DictVideosSelected, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange, DropDownList ddlLanguage)
        {
            try
            {
                for (int i = 1; i <= objPres.Slides.Count; i++)
                {
                    // Getting Text From Title of Shapes  i.e Slide heading
                    txtRange = objPres.Slides[i].Shapes.Title.TextFrame.TextRange;
                    

                    if (DictVideosSelected.Count > 0)
                    {
                        foreach (string key in DictVideosSelected.Keys)
                        {
                            string MergeFieldEnglish = "<<" + key + ">>";
                            string MergeFieldSpanish = "<<" + DictVideosSelected[key] + ">>";
                            string LastDictKey = DictVideosSelected.Last().Key;

                            if (ddlLanguage.SelectedValue == "English" || ddlLanguage.SelectedValue == "Both")
                            {
                                if (txtRange.Text.Contains(MergeFieldEnglish))
                                {
                                    //Only MergeField is found remove MergeField and Delete that Key from Dictonary
                                    txtRange.Replace(MergeFieldEnglish, " ");
                                    
                                    if (ddlLanguage.SelectedValue != "Both")
                                    {
                                        DictVideosSelected.Remove(key);
                                        break;
                                    }
                                   
                                }
                            }

                            if (ddlLanguage.SelectedValue == "Spanish" || ddlLanguage.SelectedValue == "Both")
                            {
                                if (txtRange.Text.Contains(MergeFieldSpanish))
                                {
                                    //Only MergeField is found remove MergeField and Delete that Key from Dictonary
                                    txtRange.Replace(MergeFieldSpanish, " ");
                                    DictVideosSelected.Remove(key);
                                    break;
                                }
                            }

                            // Delete sides only when any of MergeFields from Dictonary not present in Slide
                            if (key == LastDictKey) {
                                if (txtRange.Text.Contains("<<") && txtRange.Text.Contains(">>"))
                                {
                                    objPres.Slides[i].Delete();
                                    //Handling iteration Since deletion is done on Live Loop
                                    i--;
                                }
                            }
                            
                        }
                    }
                    else
                    {
                        // Once the Dictonary becomes Empty. Check and Delete Slides with MergeFields untill End of PPT
                        if (txtRange.Text.Contains("<<") && txtRange.Text.Contains(">>"))
                        {
                            objPres.Slides[i].Delete();
                            i--;
                        }
                    }


                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}