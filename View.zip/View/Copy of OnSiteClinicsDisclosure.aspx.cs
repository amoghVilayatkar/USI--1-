﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;


using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.BAL.Tools;

namespace BenefitPointSummaryPortal.View
{
    public partial class OnSiteClinics : System.Web.UI.Page
    {
        #region Global Variable
        DataSet AccountDS = new DataSet();
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        SummaryDetail sd = new SummaryDetail();

        //string temperror = "cs";
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());

                DictDepartment = sd.getDepartmentDetails();
                if (!IsPostBack)
                {
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    if (Convert.ToString(Session["Summary"]) == "OnSiteClinics_Disclosure")
                    {
                        TitleSpan.InnerText = "On-Site Clinics Disclosure";
                        //Activity_Group = "On-Site Clinics Disclosure";
                        Activity_Group = "Tools";

                    }
                    Activity = TitleSpan.InnerText;
                    txtsearch.Focus();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                //Clear();

                //if (ddlOffice.Items.Count > 1)
                //{
                //    ddlOffice.SelectedIndex = 2;
                //}

                //ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                //Session["PlanTable"] = null;
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                //DataTable PlanInfoTable = new DataTable();


                if (Convert.ToString(Session["Summary"]) == "OnSiteClinics_Disclosure")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }
                    else
                    {
                        //flag = CheckAccountContactsSelected();
                    }
                }


                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    //List<Carrier> carrierList = new List<Carrier>();
                    //SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    string mynewfile = "";

                    // Uncommned for new requirement Activity Log
                    sd.BuildAccountTable();
                    //sd.BuildBenefitSummaryTable();
                    //sd.BuildBenifitSummaryStructureTable();
                    //sd.BuildContributionTable();
                    //sd.BuildEligibilityRuleTable();
                    //sd.BuildProductTable();
                    //sd.BuildRateTable();

                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    //string Office_Region = Account_Region;
                    string Office_Region = Account_Region + " / " + Account_Office;

                    #region On-Site Clinics Disclosure
                    if (Convert.ToString(Session["Summary"]) == "OnSiteClinics_Disclosure")
                    {
                        mynewfile = Create_OnSiteClinicsDisclosure(ddlClient.SelectedItem.Text, SessionId, AccountDS, AccountTeamMemberDS, ContactList);
                    }
                    #endregion

                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private string Create_OnSiteClinicsDisclosure(string ClientName, string SessionId, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {


            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/On-SiteClinicsDisclosure _Compliance Considerations.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/On-SiteClinicsDisclosure/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/On-SiteClinicsDisclosure")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/On-SiteClinicsDisclosure"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                WriteTemplate_OnSiteClinicsDisclosure objOnSiteClinicsDisclosure = new WriteTemplate_OnSiteClinicsDisclosure();
                objOnSiteClinicsDisclosure.WriteFileds_OnSiteClinicsDisclosure(oWordDoc, oWordApp, ClientName);
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}