﻿using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.Runtime.InteropServices;

namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteAncillaryPanelCarrierTemplate  : System.Web.UI.Page
    {

        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        public void AttacheWordFiles(List<string> selectedCarriers, Word.Range r, Word.Document oWordDoc)
        {
            try
            {
                string path = "";
                path = "~/Files/AncillaryPanelCarrier/Documents/Templates/";

                object missing = System.Type.Missing;
                selectedCarriers.Reverse();// show the carrier list as per criteria page 

                foreach (string value in selectedCarriers)
                {

                    InsertFile(System.Web.HttpContext.Current.Server.MapPath(path + value), r);

                }

                //for (var i = selectedCarriers.Count - 1; i >= 0; i--)
                //{
                //    InsertFile(System.Web.HttpContext.Current.Server.MapPath(path +  selectedCarriers[i]), r);
                //}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void InsertFile_Old(object FilePath, Word.Range rngFieldCode)
        {
            Object readOnly = true;
            Object isVisible = false;
            object missing = System.Type.Missing;
            _Document sourceDocument;

            Word.ApplicationClass wordApp = null;
            wordApp = new ApplicationClass();
            wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

            Word.Range r = rngFieldCode;

            r.SetRange(rngFieldCode.End, rngFieldCode.End);

            sourceDocument = wordApp.Documents.Open(ref FilePath,
                                                                  ref missing, ref readOnly,
                                                                  ref missing, ref missing, ref missing,
                                                                  ref missing, ref missing, ref missing,
                                                                  ref missing, ref missing, ref isVisible,
                                                                  ref missing, ref missing, ref missing, ref missing);

            sourceDocument.Activate(); // This is the document I am copying from 

            sourceDocument.ActiveWindow.Selection.WholeStory();
            //sourceDocument.Bookmarks["bookmark"].Range.Select();

            sourceDocument.ActiveWindow.Selection.Copy();
            if (sourceDocument.ActiveWindow.Selection.Text.Trim() != "")
            {
                r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
            }

            if (wordApp != null)
            {

                ((Microsoft.Office.Interop.Word._Document)sourceDocument).Close(ref missing, ref missing, ref missing);
                Marshal.ReleaseComObject(sourceDocument);

                sourceDocument = null;
                wordApp.Quit(ref missing, ref missing, ref missing);
                Marshal.FinalReleaseComObject(wordApp);
                wordApp = null;

            }
        }

        public void InsertFile(object FilePath, Word.Range rngFieldCode)
        {
            Object readOnly = true;
            Object isVisible = false;
            object missing = System.Type.Missing;
            _Document sourceDocument;

            Word.ApplicationClass wordApp = null;
            wordApp = new ApplicationClass();
            wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

            Word.Range r = rngFieldCode;

            r.SetRange(rngFieldCode.End, rngFieldCode.End);

            sourceDocument = wordApp.Documents.Open(ref FilePath,
                                                                  ref missing, ref readOnly,
                                                                  ref missing, ref missing, ref missing,
                                                                  ref missing, ref missing, ref missing,
                                                                  ref missing, ref missing, ref isVisible,
                                                                  ref missing, ref missing, ref missing, ref missing);

            sourceDocument.Activate(); // This is the document I am copying from 

            sourceDocument.ActiveWindow.Selection.WholeStory();
            //sourceDocument.Bookmarks["bookmark"].Range.Select();

            sourceDocument.ActiveWindow.Selection.Copy();
            if (sourceDocument.ActiveWindow.Selection.Text.Trim() != "")
            {
                r.PasteAndFormat(WdRecoveryType.wdUseDestinationStylesRecovery);
            }

            #region This is to make clipbord empty
            sourceDocument.ActiveWindow.Selection.Text = "abc";
            sourceDocument.Activate(); // This is the document I am copying from 

            sourceDocument.ActiveWindow.Selection.WholeStory();
            //sourceDocument.Bookmarks["bookmark"].Range.Select();

            sourceDocument.ActiveWindow.Selection.Copy();
            #endregion

            if (wordApp != null)
            {

                ((Microsoft.Office.Interop.Word._Document)sourceDocument).Close(false);   // false - donot save before quits
                Marshal.ReleaseComObject(sourceDocument);

                sourceDocument = null;
                // wordApp.Quit(ref missing, ref missing, ref missing);
                wordApp.Quit(false);
                Marshal.FinalReleaseComObject(wordApp);
                wordApp = null;

            }
        }
    }
}