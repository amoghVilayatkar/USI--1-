﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;
using BenefitPointSummaryPortal.Common.ViewModels;
using System.Data;
using BenefitPointSummaryPortal.AsposeUtility;
using System.Collections;
namespace BenefitPointSummaryPortal.BAL.EmployeeEducationMaterials
{
    public class EmployeeEducationSummary
    {
        AsposeWord WordDoc;
        public string TemplateFilePath;
        public string DownloadFilePath;
        public static ConstantValue cv = new ConstantValue();
        public enum ColorOptions { Grey, Black, Blue, USI_Blue, True_Blue, Green, Dark_Green, Bright_Green, Olive_Green, Red, Maroon, Dark_Red, Mustard, Orange, Purple, Light_Brown, Dark_Brown, RGB };
        public static List<string> ColorOptionList = new List<string>() { "Black", "Blue", "USI Blue", "True Blue", "Green", "Dark Green", "Bright Green", "Olive Green", "Red", "Maroon", "Dark Red", "Mustard", "Orange", "Purple", "Light Brown", "Dark Brown", "RGB" };
        public List<int> Medical_InNetworkColumnsIds = new List<int>() { 100, 101, 103, 106, 108, 111, 112, 114 };
        Dictionary<string, string> dictColorText = new Dictionary<string, string>();
        #region EmployeeEducation Plan list
        public static List<int> EmpEducationPlanType_MedicalPlan = new List<int>() { 100, 110, 120, 130, 140, 150, 160, 170, 233 };
        public static List<int> EmpEducationPlanType_Dental = new List<int>() { 180, 190, 200, 210 };
        public static List<int> EmpEducationPlanType_Vision = new List<int>() { 230 };
        public static List<int> EmpEducationPlanType_HealthSavingAccounts = new List<int>() { 179 };
        public static List<int> EmpEducationPlanType_HealthReimbursementArrangement = new List<int>() { 178 };
        public static List<int> EmpEducationPlanType_LifeADD = new List<int>() { 240 };
        public static List<int> EmpEducationPlanType_GroupTermLife = new List<int>() { 250 };
        public static List<int> EmpEducationPlanType_ADD = new List<int>() { 270 };
        public static List<int> EmpEducationPlanType_VoluntaryLife = new List<int>() { 260 };
        public static List<int> EmpEducationPlanType_VoluntaryADD = new List<int>() { 280 };
        public static List<int> EmpEducationPlanType_ShortTermDisability = new List<int>() { 290, 292, 293, 294 };
        public static List<int> EmpEducationPlanType_VoluntaryShortTermDisability = new List<int>() { 290 };
        public static List<int> EmpEducationPlanType_LongTermDisablity = new List<int>() { 300 };
        public static List<int> EmpEducationPlanType_VoluntaryLongTermDisablity = new List<int>() { 300 };
        public static List<int> EmpEducationPlanType_EmployeeAssistanceProgram = new List<int>() { 310 };
        public static List<int> EmpEducationPlanType_FlexibleSpendingAccount = new List<int>() { 330 };
        public static List<int> EmpEducationPlanType_Wellness = new List<int>() { 317 };
        public static List<int> EmpEducationPlanType_MedicalRxPlan = new List<int>() { 173 };
        public static List<int> EmpEducationPlanType_401K = new List<int>() { 340 };
        public static List<int> EmpEducationPlanType_StopLoss = new List<int>() { 235 };
        public static List<int> EmpEducationPlanType_InternationalBundledsPlan_3_Tier = new List<int>() { 410 };
        public static List<int> EmpEducationPlanType_BussinessTravelAccident = new List<int>() { 320 };
        #endregion
        #region EmployeeEducation Product Lists
        public static List<int> EmpEducationProductType_Telemedicine = new List<int>() { 5460 };
        public static List<int> EmpEducationProductType_PatientAdvocacy = new List<int>() { 1790 };
        public static List<int> EmpEducationProductType_Hospitalization = new List<int>() { 5060 };
        public static List<int> EmpEducationProductType_Accident = new List<int>() { 5500 };
        public static List<int> EmpEducationProductType_CriticalIllnesss = new List<int>() { 1160 };
        public static List<int> EmpEducationProductType_VoluntaryCancer = new List<int>() { 1400 };
        public static List<int> EmpEducationProductType_LifeADD = new List<int>() { 1150, 1230 };
        public static List<int> EmpEducationProductType_AbsenseMasnagement = new List<int>() { 5330 };
        public static List<int> EmpEducationProductType_PetInsurance = new List<int>() { 1480 };
        public static List<int> EmpEducationProductType_CobraAdministration = new List<int>() { 1109 };
        public static List<int> EmpEducationProductType_FinancialProduct = new List<int>() { 1107 };
        public static List<int> EmpEducationProductType_ExecutiveBenefit = new List<int>() { 1104 };
        public static List<int> EmpEducationProductType_500Filling = new List<int>() { 1110 };
        public static List<int> EmpEducationProductType_TransitParkingAdmin = new List<int>() { 1720 };
        public static List<int> EmpEducationProductType_LegalServices = new List<int>() { 1114 };
        public static List<int> EmpEducationProductType_IdentifyTheft = new List<int>() { 3090 };
        public static List<int> EmpEducationProductType_ShortTermMedical = new List<int>() { 1240 };
        public static List<int> EmpEducationProductType_WholeLifeIndividual = new List<int>() { 5070 };
        public static List<int> EmpEducationProductType_DiseaseManagement = new List<int>() { 5875 };
        public static List<int> EmpEducationProductType_TobaccoPolicy = new List<int>() { 5040 };
        public static List<int> EmpEducationProductType_GroupHomeAndAuto = new List<int>() { 4020 };
        public static List<int> EmpEducationProductType_MinimumEssentialCoverage = new List<int>() { 5825 };
        public static List<int> EmpEducationProductType_IND_INDIV_LONG_TERM_CARE = new List<int>() { 1890 };
        public static List<int> EmpEducationProductType_IndividualDisability = new List<int>() { 1460 };
        public static List<int> EmpEducationProductType_MedicareSupplement = new List<int>() { 1260 };
        public static List<int> EmpEducationProductType_FeeForService_Consulting_Project = new List<int>() { 1108 };
        public static List<int> EmpEducationProductType_FeeForService_PBMConsulting = new List<int>() { 5885 };
        public static List<int> EmpEducationProductType_FeeForService_HR_Ben_Admin_Services = new List<int>() { 1111 };
        public static List<int> EmpEducationProductType_LongTermCare = new List<int>() { 1115 };
        public static List<int> EmpEducationProductType_MedicalPlanRiders = new List<int>() { 1116 };
        public static List<int> EmpEducationProductType_OnsiteMedicenter = new List<int>() { 5340 };
        #endregion
        public static List<BenefitSummaryStructure> GetBenefitSummarySelectionMap(string Topic, string Types)
        {
            List<BenefitSummaryStructure> EmpEducationMap = new List<BenefitSummaryStructure>();

            if (Topic == "Preventive Care")
            {
                switch (Types)
                {
                    case "Preventive Care & You":
                        BenefitSummaryStructure Medical = new BenefitSummaryStructure();
                        Medical.LOC = cv.MedicalLOC;
                        Medical.MaxBenefitSummary = 1;
                        Medical.MaxContributionPerSummary = 0;
                        Medical.ContributionApplicable = false;
                        Medical.BenefitSummaryApplicable = true;
                        Medical.RateApplicable = false;
                        Medical.MaxRatePerBenefitSummary = 0;
                        EmpEducationMap.Add(Medical);
                        break;
                    case "Preventive Care Basics":
                        BenefitSummaryStructure Medical_1 = new BenefitSummaryStructure();
                        Medical_1.LOC = cv.MedicalLOC;
                        Medical_1.MaxBenefitSummary = 1;
                        Medical_1.MaxContributionPerSummary = 0;
                        Medical_1.ContributionApplicable = false;
                        Medical_1.BenefitSummaryApplicable = true;
                        Medical_1.RateApplicable = false;
                        Medical_1.MaxRatePerBenefitSummary = 0;
                        EmpEducationMap.Add(Medical_1);
                        break;
                }
            }
            if (Topic == "HSA")
            {
                switch (Types)
                {
                    case "Is an HSA Right for You?":
                        BenefitSummaryStructure HSA = new BenefitSummaryStructure();
                        HSA.LOC = cv.HSALOC;
                        HSA.MaxBenefitSummary = 1;
                        HSA.MaxContributionPerSummary = 0;
                        HSA.ContributionApplicable = false;
                        HSA.BenefitSummaryApplicable = true;
                        HSA.RateApplicable = false;
                        HSA.MaxRatePerBenefitSummary = 0;
                        EmpEducationMap.Add(HSA);
                        break;
                    case "HSA Eligible Expenses":
                        break;
                }
            }
            if (Topic == "Emergency Room")
            {
                switch (Types)
                {
                    case "Wise Use of the Emergency Room":
                        break;
                    case "Emergency Room vs Urgent Care":
                        BenefitSummaryStructure Medical = new BenefitSummaryStructure();
                        Medical.LOC = cv.MedicalLOC;
                        Medical.MaxBenefitSummary = 1;
                        Medical.MaxContributionPerSummary = 0;
                        Medical.ContributionApplicable = false;
                        Medical.BenefitSummaryApplicable = true;
                        Medical.RateApplicable = false;
                        Medical.MaxRatePerBenefitSummary = 0;
                        EmpEducationMap.Add(Medical);
                        break;
                }
            }

            return EmpEducationMap;
        }
        public static List<int> LoadAllEmpEducationPlans(string Topic, string Types)
        {
            List<int> _EmpEducationAllPlans = new List<int>();

            if (Topic == "Preventive Care")
            {
                switch (Types)
                {
                    case "Preventive Care & You":
                        _EmpEducationAllPlans.AddRange(EmpEducationPlanType_MedicalPlan);
                        break;
                    case "Preventive Care Basics":
                        _EmpEducationAllPlans.AddRange(EmpEducationPlanType_MedicalPlan);
                        break;
                }
            }
            if (Topic == "HSA")
            {
                switch (Types)
                {
                    case "Is an HSA Right for You?":
                        _EmpEducationAllPlans.AddRange(EmpEducationPlanType_HealthSavingAccounts);
                        break;
                    case "HSA Eligible Expenses":
                        break;
                }
            }
            if (Topic == "Emergency Room")
            {
                switch (Types)
                {
                    case "Wise Use of the Emergency Room":
                        break;
                    case "Emergency Room vs Urgent Care":
                        _EmpEducationAllPlans.AddRange(EmpEducationPlanType_MedicalPlan);
                        break;
                }
            }

            return _EmpEducationAllPlans;

        }
        public static List<int> LoadAllEmpEducationProducts(string Topic, string Types)
        {
            List<int> _EmpEducationAllProducts = new List<int>();

            if (Topic == "Preventive Care")
            {
                switch (Types)
                {
                    case "Preventive Care & You":
                        break;
                }
            }
            if (Topic == "HSA")
            {
                switch (Types)
                {
                    case "Is an HSA Right for You?":
                        break;
                    case "HSA Eligible Expenses":
                        break;
                }
            }
            if (Topic == "Emergency Room")
            {
                switch (Types)
                {
                    case "Wise Use of the Emergency Room":
                        break;
                    case "Emergency Room vs Urgent Care":
                        break;
                }
            }

            return _EmpEducationAllProducts;
        }
        public EmployeeEducationSummary.ColorOptions CovertToColorOption(string ColorOption)
        {
            EmployeeEducationSummary.ColorOptions returnValue = ColorOptions.Grey;
            switch (ColorOption)
            {
                case "Gray(default)":
                    returnValue = ColorOptions.Grey;
                    break;
                case "Black":
                    returnValue = ColorOptions.Black;
                    break;
                case "Blue":
                    returnValue = ColorOptions.Blue;
                    break;
                case "USI Blue":
                    returnValue = ColorOptions.USI_Blue;
                    break;
                case "True Blue":
                    returnValue = ColorOptions.True_Blue;
                    break;
                case "Green":
                    returnValue = ColorOptions.Green;
                    break;
                case "Dark Green":
                    returnValue = ColorOptions.Dark_Green;
                    break;
                case "Bright Green":
                    returnValue = ColorOptions.Bright_Green;
                    break;
                case "Olive Green":
                    returnValue = ColorOptions.Olive_Green;
                    break;
                case "Red":
                    returnValue = ColorOptions.Red;
                    break;
                case "Maroon":
                    returnValue = ColorOptions.Maroon;
                    break;
                case "Dark Red":
                    returnValue = ColorOptions.Dark_Red;
                    break;
                case "Mustard":
                    returnValue = ColorOptions.Mustard;
                    break;
                case "Orange":
                    returnValue = ColorOptions.Orange;
                    break;
                case "Purple":
                    returnValue = ColorOptions.Purple;
                    break;
                case "Light Brown":
                    returnValue = ColorOptions.Light_Brown;
                    break;
                case "Dark Brown":
                    returnValue = ColorOptions.Dark_Brown;
                    break;
            }
            return returnValue;
        }

        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
            {
                string Value = dr["value"].ToString().Trim();
                if (!Value.Contains(","))
                {
                    if (Value != string.Empty && dr["UOM"].ToString().ToLower() == "dollars")
                    {
                        if (Value.Contains('.'))
                            Value = string.Format("{0:#,0.##}", double.Parse(Value));
                        else
                            Value = string.Format("{0:#,0.##}", int.Parse(Value));
                    }
                }
                return (dr["prefix"].ToString() + Value + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            }
            return "";
        }
        public void WriteFilePreventiveCareAndYou(DataSet BenefitDS, Dictionary<string, string> dictMergeFieldsValue, int SummeryId, string color, int R, int G, int B)
        {
            dictColorText.Clear();
            #region AdultPeriodicExamswithPreventiveTests
            string strBenefitSummaryAttributeValue = string.Empty;
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            DataRow drBenefitValues_PreventiveCareAndYou = dtblBenefitAttribute.Select("benefitSummaryID = " + SummeryId + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_PreventiveCareAndYou != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_PreventiveCareAndYou);
                dictMergeFieldsValue["<<AdultPeriodicExamswithPreventiveTests>>"] = strBenefitSummaryAttributeValue;
            }
            #endregion

            dictColorText["PreventiveCareYou"] = "Preventive Care & You";
            dictColorText["Whatispreventivecare"] = "What is preventive care?";
            dictColorText["Ispreventivecareenoughtoavoid"] = "Is preventive care enough to avoid";
            dictColorText["developingchronicdiseases"] = "developing chronic diseases?";
            dictColorText["Whatstepspreventivecare"] = "What steps should I take to get preventive care";
            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            dictMergeFieldsValue.Remove("TemplatePath");
            dictMergeFieldsValue.Remove("DownloadFilePath");
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            WordDoc.ReplaceToTextPatterns(dictMergeFieldsValue);
            if (color != string.Empty)
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));


        }
        public void WriteFilePreventiveCareBasics(DataSet BenefitDS, Dictionary<string, string> dictMergeFieldsValue, int SummeryId, string color, int R, int G, int B)
        {
            dictColorText.Clear();
            #region AdultPeriodicExamswithPreventiveTests
            string strBenefitSummaryAttributeValue = string.Empty;
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            DataRow drBenefitValues_PreventiveCareAndYou = dtblBenefitAttribute.Select("benefitSummaryID = " + SummeryId + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_PreventiveCareAndYou != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_PreventiveCareAndYou);
                dictMergeFieldsValue["<<AdultPeriodicExamswithPreventiveTests>>"] = strBenefitSummaryAttributeValue;
            }
            #endregion

            dictColorText["Preventivecareconsists"] = "Preventive care consists not only of yearly physical exams, but also routine health screenings, immunizations and maintaining a healthy lifestyle";
            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            dictMergeFieldsValue.Remove("TemplatePath");
            dictMergeFieldsValue.Remove("DownloadFilePath");
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            WordDoc.ReplaceToTextPatterns(dictMergeFieldsValue);
            if (color != string.Empty)
            {
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));
                //WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.46");
                WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.54");
            }

        }
        public void WriteFileHSA_IsanHSARightforYou(int summaryId, Dictionary<string, string> dictMergeFieldsValue, DataSet BenefitDS, List<Contact> ContactList, ArrayList arrAcctContact, string color, int R, int G, int B)
        {
            string strBenefitSummaryAttributeValue = string.Empty;
            dictColorText.Clear();
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            DataRow drBenefitValues_ContributionIndivisual = dtblBenefitAttribute.Select("benefitSummaryID = " + summaryId + " AND attributeID = 640 ").FirstOrDefault();
            if (drBenefitValues_ContributionIndivisual != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ContributionIndivisual);

                //dictMergeFieldsValue["<<HSAEmployerContributionsIndividual>>"] = strBenefitSummaryAttributeValue;
                dictMergeFieldsValue["<<HSA>Employer Contributions>Individual>>"] = strBenefitSummaryAttributeValue;
            }

            DataRow drBenefitValues_ContributionThreeOrMore = dtblBenefitAttribute.Select("benefitSummaryID = " + summaryId + " AND attributeID = 643 ").FirstOrDefault();
            if (drBenefitValues_ContributionThreeOrMore != null)
            {
                strBenefitSummaryAttributeValue = GetBenefitFormattedValue(drBenefitValues_ContributionThreeOrMore);
                dictMergeFieldsValue["<<HSAEmployerContributionsIndividualThreeorMore>>"] = strBenefitSummaryAttributeValue;

            }

            string HRContact_Firstname = string.Empty;
            string HRContact_Lastname = string.Empty;
            string HRContact_Phone = string.Empty;
            string HRContact_Email = string.Empty;
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].First_Name != null)
                                {
                                    //dictMergeFieldsValue["<<ClientContactFirstName>>"] = ContactList[i].First_Name;
                                    dictMergeFieldsValue["<<Client Contact First Name>>"] = ContactList[i].First_Name;
                                }

                                else
                                {
                                    //dictMergeFieldsValue["<<ClientContactFirstName>>"] = "";
                                    dictMergeFieldsValue["<<Client Contact First Name>>"] = "";
                                }
                                if (ContactList[i].Last_Name != null)
                                {


                                    //dictMergeFieldsValue["<<ClientContactLastName>>"] = ContactList[i].Last_Name;
                                    dictMergeFieldsValue["<<Client Contact Last Name>>"] = ContactList[i].Last_Name;
                                }
                                else
                                {
                                    //dictMergeFieldsValue["<<ClientContactLastName>>"] = "";
                                    dictMergeFieldsValue["<<Client Contact Last Name>>"] = "";
                                }
                                if (ContactList[i].Email != null)
                                {


                                    //dictMergeFieldsValue["<<ClientContactEmail>>"] = ContactList[i].Email;
                                    dictMergeFieldsValue["<<Client Contact Email>>"] = ContactList[i].Email;

                                }
                                else
                                {
                                    //dictMergeFieldsValue["<<ClientContactEmail>>"] = "";
                                    dictMergeFieldsValue["<<Client Contact Email>>"] = "";
                                }
                                if (ContactList[i].Title != null)
                                {


                                    //dictMergeFieldsValue["<<ClientContactTitle>>"] = ContactList[i].Title;
                                    dictMergeFieldsValue["<<Client Contact Title>>"] = ContactList[i].Title;
                                }
                                else
                                {
                                    //dictMergeFieldsValue["<<ClientContactTitle>>"] = "";
                                    dictMergeFieldsValue["<<Client Contact Title>>"] = "";
                                }

                            }
                        }
                    }
                }
            }

            dictColorText["isHSARightforYou"] = "Is a Health Savings Account (HSA) Right for you?";
            dictColorText["DoIqualifyforanHSA"] = "Do I qualify for an HSA?";
            dictColorText["HowdoesanHSAwork"] = "How does an HSA work?";
            dictColorText["WhatifIdontusethemoney"] = "What if I don’t use the money?";
            dictColorText["Questions"] = "Questions?";
            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            dictMergeFieldsValue.Remove("TemplatePath");
            dictMergeFieldsValue.Remove("DownloadFilePath");
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            WordDoc.ReplaceToTextPatterns(dictMergeFieldsValue);
            if (color != string.Empty)
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));

        }
        public void WriteFileHSAEligibleExpenses(Dictionary<string, string> dictMergeFieldsValue, string color, int R, int G, int B)
        {
            dictColorText.Clear();
            dictColorText["Qualifiedmedicalcareexpenses"] = "Qualified medical care expenses are amounts paid for the diagnosis, cure or treatment of a disease, and for treatments affecting any part or function of the body.";

            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            dictMergeFieldsValue.Remove("TemplatePath");
            dictMergeFieldsValue.Remove("DownloadFilePath");
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            WordDoc.ReplaceToTextPatterns(dictMergeFieldsValue);
            if (color != string.Empty)
            {
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));
                //WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.25");
                WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.75");
            }
        }
        public void WriteFileWiseEmergencyRoom(Dictionary<string, string> dictMergeFieldsValue, string color, int R, int G, int B)
        {

            dictColorText.Clear();
            dictColorText["life-threatening"] = "life-threatening";
            dictColorText["immediate"] = "immediate";
            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            if (color != string.Empty)
            {

                List<string> li = new List<string>();
                li.Add("An emergency is");
                li.Add("and requires");
                li.Add("care. Call 911. Be sure to bring along identification, insurance cards, and medication and health history information.");

                //WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.25");
                WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "0.75");
                WordDoc.ReplaceToTextPatternByList(li, WordDoc.GetFontColor(color, R, G, B));
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));
            }
        }
        public void WriteFileEmergencyUrgentCare(DataSet BenefitDS, Dictionary<string, string> dictMergeFieldsValue, int SummeryId, string color, int R, int G, int B)
        {
            dictColorText.Clear();
            string strBenefitSummaryAttributeValueEmergencyRoom = string.Empty;
            string strBenefitSummaryAttributeValueUrgentCare = string.Empty;
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            DataRow drBenefitValues_EmergencyRoom = dtblBenefitAttribute.Select("benefitSummaryID = " + SummeryId + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            DataRow drBenefitValues_UregentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + SummeryId + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_InNetworkColumnsIds) + ") ").FirstOrDefault();
            if (drBenefitValues_EmergencyRoom != null)
            {
                strBenefitSummaryAttributeValueEmergencyRoom = GetBenefitFormattedValue(drBenefitValues_EmergencyRoom);
                dictMergeFieldsValue["<<EmergencyRoom>>"] = strBenefitSummaryAttributeValueEmergencyRoom;
            }
            if (drBenefitValues_UregentCareFacility != null)
            {
                strBenefitSummaryAttributeValueUrgentCare = GetBenefitFormattedValue(drBenefitValues_UregentCareFacility);
                dictMergeFieldsValue["<<UrgentCareFacility>>"] = strBenefitSummaryAttributeValueUrgentCare;
            }
            dictColorText["EmergencyRoom"] = "Emergency Room";
            dictColorText["UrgentCare"] = "Urgent Care";
            WordDoc = new AsposeWord(dictMergeFieldsValue["TemplatePath"], dictMergeFieldsValue["DownloadFilePath"]);
            dictMergeFieldsValue.Remove("TemplatePath");
            dictMergeFieldsValue.Remove("DownloadFilePath");
            this.TemplateFilePath = WordDoc.TemplateFilePath;
            this.DownloadFilePath = WordDoc.DownloadFilePath;
            WordDoc.ReplaceToTextPatterns(dictMergeFieldsValue);
            if (color != string.Empty)
            {
                WordDoc.SetMultipleTectFontColor(dictColorText, WordDoc.GetFontColor(color, R, G, B));
                WordDoc.FillRectangleTextBoxColor(WordDoc.GetFontColor(color, R, G, B), "");
            }

        }

    }
}