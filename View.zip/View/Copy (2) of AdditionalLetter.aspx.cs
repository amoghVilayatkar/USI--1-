﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;

using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using System.Collections;
using Word = Microsoft.Office.Interop.Word;
using Core = Microsoft.Office.Core;
using outlook = Microsoft.Office.Interop.Outlook;
using BenefitPointSummaryPortal.BAL.Pilot;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Net;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;


namespace BenefitPointSummaryPortal.View
{
    public partial class AdditionalLetter : System.Web.UI.Page
    {
        Hashtable myHashtable;

        #region Global Variable
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        List<UserDetails> lstUserDetails = new List<UserDetails>();
        DataSet BenefitStructureDS = new DataSet();
        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList(); // For newly added AD&D plan
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();

        ArrayList StopLossBenefitColumnIdList = new ArrayList();
        ArrayList FeesForServiceBenefitColumnIdList = new ArrayList();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        static DataTable dtPlanContactInfo = new DataTable();
        static DataTable dtPlanContact;
        static DataTable AdditionalInfoTable = new DataTable();
        int rowvalue = 0;
        Dictionary<string, string> dictClientContactSheetDisplayValue = new Dictionary<string, string>();
        Dictionary<string, string> dictStateDropDownDisplayValue = new Dictionary<string, string>();
        Dictionary<string, string> dictContactValue = new Dictionary<string, string>();
        Dictionary<string, string> dictLetterFormat = new Dictionary<string, string>();
        Dictionary<string, string> dictLetterDescriptions = new Dictionary<string, string>();
        Dictionary<string, string> dictLetterCarriersValue = new Dictionary<string, string>();
        Dictionary<string, int> dictLetterPlanCount = new Dictionary<string, int>();
        Dictionary<string, string> dictLetterPlanRequiredValue = new Dictionary<string, string>();

        List<string> lstCarriersAndAvailableAllPlans = new List<string> { "AMBestRatingClientLetter_MidyearDowngrade", "Carrier_Contract_to_Client", "RenewalAnalysisCoverLetter", "Renewal_Request_Letter_to_Carrier", "TerminationLetterfromClienttoCarrier" };
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                LoadDisplayStatusData();
                Session["Summary"] = "AdditionalLetter";
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                DictDepartment = sd.getDepartmentDetails();
                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                {

                    TitleSpan.InnerText = "Letters";
                }
                if (!IsPostBack)
                {
                    btnNext.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage1');";
                    btnSummary.OnClientClick = "javascript:return ValidateForm();";
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    mvClientContact.ActiveViewIndex = 0;
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    //if (Convert.ToString(Session["Summary"]) == "Tools_ContractReview")
                    //{
                    //    TitleSpan.InnerText = "Contract Review Checklist";
                    //}
                    //else if (Convert.ToString(Session["Summary"]) == "Benchmarking_AuditReport")
                    //{
                    //    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceContractReviewToBenchmarkAudit", "<script>ReplaceContractReviewToBenchmarkAudit()</script>", false);

                    //    TitleSpan.InnerText = "Benchmarking Audit Report";
                    //}
                    GetData();
                    ddlcontents.Focus();
                    ////Activity = TitleSpan.InnerText;
                    Activity = "Communications to Clients/Carriers";
                    Activity_Group = "Communications";
                    ////Activity_Group = "Pilot";
                    ddlcontents.SelectedIndex = 0;
                    ddlFormat.SelectedIndex = 0;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "none");
                    tblClientContactSheet.Style.Add("display", dictClientContactSheetDisplayValue[ddlcontents.SelectedValue] == "yes" ? "" : "none");
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void LoadDisplayStatusData()
        {
            #region Client Contact Sheet
            dictClientContactSheetDisplayValue["0"] = "no";
            dictClientContactSheetDisplayValue["AMBestRatingClientLetter_InitialCoveragePlacement"] = "no";
            dictClientContactSheetDisplayValue["AMBestRatingClientLetter_MidyearDowngrade"] = "no";
            dictClientContactSheetDisplayValue["Authorization_to_Share_PHI"] = "no";
            dictClientContactSheetDisplayValue["BAA_Cover_Letter"] = "no";
            dictClientContactSheetDisplayValue["BOR"] = "no";
            dictClientContactSheetDisplayValue["Carrier_Contract_to_Client"] = "no";
            dictClientContactSheetDisplayValue["Carrier_Not_Rated"] = "no";
            dictClientContactSheetDisplayValue["HICA_Cover_Letter"] = "no";
            dictClientContactSheetDisplayValue["LifeDisability_CarrierToCarrier"] = "no";
            dictClientContactSheetDisplayValue["LifeDisability_CarrierToClient"] = "no";
            dictClientContactSheetDisplayValue["Marketing_Declination_Letter_To_Carrier"] = "no";
            dictClientContactSheetDisplayValue["NewClientThankYouLetter"] = "yes";
            dictClientContactSheetDisplayValue["RenewalAnalysisCoverLetter"] = "no";
            dictClientContactSheetDisplayValue["Renewal_Request_Letter_to_Carrier"] = "no";
            dictClientContactSheetDisplayValue["TerminationLetterfromClienttoCarrier"] = "no";
            dictClientContactSheetDisplayValue["USITerminationLetter"] = "no";
            dictClientContactSheetDisplayValue["Small_Business-Welcome_Kit_Letter"] = "no";
            //added Sharvan
            dictClientContactSheetDisplayValue["Client_Logo_Usage_Release"] = "no";
            #endregion
            #region State Dropdown
            dictStateDropDownDisplayValue["0"] = "no";
            dictStateDropDownDisplayValue["AMBestRatingClientLetter_InitialCoveragePlacement"] = "yes";
            dictStateDropDownDisplayValue["AMBestRatingClientLetter_MidyearDowngrade"] = "yes";
            dictStateDropDownDisplayValue["Authorization_to_Share_PHI"] = "no";
            dictStateDropDownDisplayValue["BAA_Cover_Letter"] = "yes";
            dictStateDropDownDisplayValue["BOR"] = "yes";
            dictStateDropDownDisplayValue["Carrier_Contract_to_Client"] = "yes";
            dictStateDropDownDisplayValue["Carrier_Not_Rated"] = "yes";
            dictStateDropDownDisplayValue["HICA_Cover_Letter"] = "yes";
            dictStateDropDownDisplayValue["LifeDisability_CarrierToCarrier"] = "no";
            dictStateDropDownDisplayValue["LifeDisability_CarrierToClient"] = "yes";
            dictStateDropDownDisplayValue["Marketing_Declination_Letter_To_Carrier"] = "yes";
            dictStateDropDownDisplayValue["NewClientThankYouLetter"] = "yes";
            dictStateDropDownDisplayValue["RenewalAnalysisCoverLetter"] = "yes";
            dictStateDropDownDisplayValue["Renewal_Request_Letter_to_Carrier"] = "yes";
            dictStateDropDownDisplayValue["TerminationLetterfromClienttoCarrier"] = "no";
            dictStateDropDownDisplayValue["USITerminationLetter"] = "yes";
            dictStateDropDownDisplayValue["Small_Business-Welcome_Kit_Letter"] = "yes";
            //added Sharvan
            dictStateDropDownDisplayValue["Client_Logo_Usage_Release"] = "yes";
            #endregion
            #region Contact Type value
            dictContactValue["0"] = "none";
            dictContactValue["AMBestRatingClientLetter_InitialCoveragePlacement"] = "Account";
            dictContactValue["AMBestRatingClientLetter_MidyearDowngrade"] = "Account";
            dictContactValue["Authorization_to_Share_PHI"] = "Carrier";
            dictContactValue["BAA_Cover_Letter"] = "Account";
            dictContactValue["BOR"] = "Account";
            dictContactValue["Carrier_Contract_to_Client"] = "Account";
            dictContactValue["Carrier_Not_Rated"] = "Account";
            dictContactValue["HICA_Cover_Letter"] = "Account";
            dictContactValue["LifeDisability_CarrierToCarrier"] = "Carrier"; // amogh 
            dictContactValue["LifeDisability_CarrierToClient"] = "Account";
            dictContactValue["Marketing_Declination_Letter_To_Carrier"] = "Carrier";
            dictContactValue["NewClientThankYouLetter"] = "Account";
            dictContactValue["RenewalAnalysisCoverLetter"] = "Account";
            dictContactValue["Renewal_Request_Letter_to_Carrier"] = "Carrier";
            dictContactValue["TerminationLetterfromClienttoCarrier"] = "Carrier";
            dictContactValue["USITerminationLetter"] = "Account";
            dictContactValue["Small_Business-Welcome_Kit_Letter"] = "Account";
            //Added by shravan
            dictContactValue["Client_Logo_Usage_Release"] = "Account";
            #endregion
            #region Letter format value
            dictLetterFormat["0"] = "none";
            dictLetterFormat["AMBestRatingClientLetter_InitialCoveragePlacement"] = "Word";
            dictLetterFormat["AMBestRatingClientLetter_MidyearDowngrade"] = "Both";
            dictLetterFormat["Authorization_to_Share_PHI"] = "Both";
            dictLetterFormat["BAA_Cover_Letter"] = "Both";
            dictLetterFormat["BOR"] = "Both";
            dictLetterFormat["Carrier_Contract_to_Client"] = "Both";
            dictLetterFormat["Carrier_Not_Rated"] = "Word";
            dictLetterFormat["HICA_Cover_Letter"] = "Both";
            dictLetterFormat["LifeDisability_CarrierToCarrier"] = "Both";
            dictLetterFormat["LifeDisability_CarrierToClient"] = "Both";
            dictLetterFormat["Marketing_Declination_Letter_To_Carrier"] = "Both";
            dictLetterFormat["NewClientThankYouLetter"] = "Word";
            dictLetterFormat["RenewalAnalysisCoverLetter"] = "Word";
            dictLetterFormat["Renewal_Request_Letter_to_Carrier"] = "Both";
            dictLetterFormat["TerminationLetterfromClienttoCarrier"] = "Both";
            dictLetterFormat["USITerminationLetter"] = "Both";
            dictLetterFormat["Small_Business-Welcome_Kit_Letter"] = "Both";
            //Added by shravan
            dictLetterFormat["Client_Logo_Usage_Release"] = "Word";
            #endregion
            #region Letter Description
            dictLetterDescriptions["0"] = "";
            dictLetterDescriptions["AMBestRatingClientLetter_InitialCoveragePlacement"] = "Informs the client that the rating of the carrier they selected is below the USI’s minimum standard of A-.  The letter includes a required client signature section.";
            dictLetterDescriptions["AMBestRatingClientLetter_MidyearDowngrade"] = "Informs clients that the rating for the carrier with which they have coverage has been downgraded by the A. M. Best Company.   Signature is not required.";
            dictLetterDescriptions["Authorization_to_Share_PHI"] = "A letter to carriers authorizing PHI information be shared with specific vendors.";
            dictLetterDescriptions["BAA_Cover_Letter"] = "A letter to clients to let them know USI will be receiving PHI information on behalf of their plan. ";
            dictLetterDescriptions["BOR"] = "Notifies carriers that USI is the Broker of Record, and what date that BOR became effective. The letter includes a list of client information needed.";
            dictLetterDescriptions["Carrier_Contract_to_Client"] = "A cover letter sent to a client when sending them a carrier contract.";
            dictLetterDescriptions["Carrier_Not_Rated"] = "Informs the client that the rating of the carrier they selected is below USI’s minimum standard and has not been rated by the A.M. Best Company.  The letter includes a required client signature section.";
            dictLetterDescriptions["HICA_Cover_Letter"] = "Describes USI’s role as a Business Associate of a client’s plan, and informs clients of their obligation to choose if they want to be “Hands on” or “Hands off” with PHI.";
            dictLetterDescriptions["LifeDisability_CarrierToCarrier"] = "Notifies the incumbent carrier that the client is cancelling their coverage. The letter includes information on Waiver of Premium.";
            dictLetterDescriptions["LifeDisability_CarrierToClient"] = "This letter Informs the client of their obligations to their employees when changing Life or Disability carriers.";
            dictLetterDescriptions["Marketing_Declination_Letter_To_Carrier"] = "Informs carriers that have provided proposals that the client has chosen not to move forward.";
            dictLetterDescriptions["NewClientThankYouLetter"] = "This letter thanks new clients for placing their business with US and includes USI team and carrier contact information.";
            dictLetterDescriptions["RenewalAnalysisCoverLetter"] = "This letter provides clients with a summary of renewal premium by line of coverage.";
            dictLetterDescriptions["Renewal_Request_Letter_to_Carrier"] = "This letter provides carriers the date on which a renewal is requested.";
            dictLetterDescriptions["TerminationLetterfromClienttoCarrier"] = "This letter informs carriers that the client has chosen to terminate coverage on a specified date.";
            dictLetterDescriptions["USITerminationLetter"] = "This letter confirms a client’s decision to no longer work with USI.";
            dictLetterDescriptions["Small_Business-Welcome_Kit_Letter"] = "This letter welcomes clients to USI’s Small Business Unit and provides team contact information.";
            //added by shravan
            dictLetterDescriptions["Client_Logo_Usage_Release"] = "This letter requests client permission to use their logo communications and presentations.";
            #endregion
            #region Letter Carriers Values
            dictLetterCarriersValue["0"] = "No";
            dictLetterCarriersValue["AMBestRatingClientLetter_InitialCoveragePlacement"] = "No";
            dictLetterCarriersValue["AMBestRatingClientLetter_MidyearDowngrade"] = "Yes";
            dictLetterCarriersValue["Authorization_to_Share_PHI"] = "No";
            dictLetterCarriersValue["BAA_Cover_Letter"] = "No";
            dictLetterCarriersValue["BOR"] = "No";
            dictLetterCarriersValue["Carrier_Contract_to_Client"] = "Yes";
            dictLetterCarriersValue["Carrier_Not_Rated"] = "No";
            dictLetterCarriersValue["HICA_Cover_Letter"] = "No";
            dictLetterCarriersValue["LifeDisability_CarrierToCarrier"] = "Yes";
            dictLetterCarriersValue["LifeDisability_CarrierToClient"] = "Yes";
            dictLetterCarriersValue["Marketing_Declination_Letter_To_Carrier"] = "No";
            dictLetterCarriersValue["NewClientThankYouLetter"] = "No";
            dictLetterCarriersValue["RenewalAnalysisCoverLetter"] = "No";
            dictLetterCarriersValue["Renewal_Request_Letter_to_Carrier"] = "Yes";
            dictLetterCarriersValue["TerminationLetterfromClienttoCarrier"] = "Yes";
            dictLetterCarriersValue["USITerminationLetter"] = "No";
            dictLetterCarriersValue["Small_Business-Welcome_Kit_Letter"] = "No";
            //added by shravan
            dictLetterCarriersValue["Client_Logo_Usage_Release"] = "No";
            #endregion
            #region Plan count
            dictLetterPlanCount["0"] = 0;
            dictLetterPlanCount["AMBestRatingClientLetter_InitialCoveragePlacement"] = 999;
            dictLetterPlanCount["AMBestRatingClientLetter_MidyearDowngrade"] = 999;
            dictLetterPlanCount["Authorization_to_Share_PHI"] = 999;
            dictLetterPlanCount["BAA_Cover_Letter"] = 999;
            dictLetterPlanCount["BOR"] = 999;
            dictLetterPlanCount["Carrier_Contract_to_Client"] = 999;
            dictLetterPlanCount["Carrier_Not_Rated"] = 999;
            dictLetterPlanCount["HICA_Cover_Letter"] = 999;
            dictLetterPlanCount["LifeDisability_CarrierToCarrier"] = int.MaxValue;
            dictLetterPlanCount["LifeDisability_CarrierToClient"] = 1;
            dictLetterPlanCount["Marketing_Declination_Letter_To_Carrier"] = 999;
            dictLetterPlanCount["NewClientThankYouLetter"] = 999;
            dictLetterPlanCount["RenewalAnalysisCoverLetter"] = 999;
            dictLetterPlanCount["Renewal_Request_Letter_to_Carrier"] = 999;
            dictLetterPlanCount["TerminationLetterfromClienttoCarrier"] = 999;
            dictLetterPlanCount["USITerminationLetter"] = 999;
            dictLetterPlanCount["Small_Business-Welcome_Kit_Letter"] = 999;
            //added by shravan
            dictLetterPlanCount["Client_Logo_Usage_Release"] = 999;
            #endregion
            #region Letters Plans Required
            dictLetterPlanRequiredValue["0"] = "No";
            dictLetterPlanRequiredValue["AMBestRatingClientLetter_InitialCoveragePlacement"] = "No";
            dictLetterPlanRequiredValue["AMBestRatingClientLetter_MidyearDowngrade"] = "No";
            dictLetterPlanRequiredValue["Authorization_to_Share_PHI"] = "No";
            dictLetterPlanRequiredValue["BAA_Cover_Letter"] = "No";
            dictLetterPlanRequiredValue["BOR"] = "No";
            dictLetterPlanRequiredValue["Carrier_Contract_to_Client"] = "Yes";
            dictLetterPlanRequiredValue["Carrier_Not_Rated"] = "No";
            dictLetterPlanRequiredValue["HICA_Cover_Letter"] = "No";
            dictLetterPlanRequiredValue["LifeDisability_CarrierToCarrier"] = "Yes";
            dictLetterPlanRequiredValue["LifeDisability_CarrierToClient"] = "Yes";
            dictLetterPlanRequiredValue["Marketing_Declination_Letter_To_Carrier"] = "No";
            dictLetterPlanRequiredValue["NewClientThankYouLetter"] = "Yes";
            dictLetterPlanRequiredValue["RenewalAnalysisCoverLetter"] = "Yes";
            dictLetterPlanRequiredValue["Renewal_Request_Letter_to_Carrier"] = "Yes";
            dictLetterPlanRequiredValue["TerminationLetterfromClienttoCarrier"] = "Yes";
            dictLetterPlanRequiredValue["USITerminationLetter"] = "No";
            dictLetterPlanRequiredValue["Small_Business-Welcome_Kit_Letter"] = "No";
            //added by shravan
            dictLetterPlanRequiredValue["Client_Logo_Usage_Release"] = "No";
            #endregion
        }

        /// <summary>
        /// Loading the USI State List 
        /// </summary>
        protected void GetData()
        {
            try
            {
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();

                ////panelState.Style.Add("display", "none");
                ////panelGrid.Style.Add("display", "none");


                //USI State
                DataTable dtOfficeState = new DataTable();
                dtOfficeState = bp.GetOfficeStateList();
                Session["OffieceTable"] = dtOfficeState;
                ddlUSI_State.DataSource = dtOfficeState;
                ddlUSI_State.DataBind();
                ddlUSI_State.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlUSI_State.SelectedIndex = 0;

                // BRC
                List<BRC> BRCList = new List<BRC>();
                BRCList = bp.GetBRC_Region();
                Session["BRCList"] = BRCList;
                ddlBRCList.DataSource = BRCList;
                ddlBRCList.DataBind();
                ddlBRCList.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRCList.Items.Insert(1, new ListItem("None", "-1"));

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void chkHeaderSelectAccountCnt_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdAccountList.HeaderRow.FindControl("chkHeaderSelectAccountCnt");

            foreach (GridViewRow row in grdAccountTeam.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
        }

        #region Move Account Contact GridView Rows
        protected void MoveGridViewRows(object sender, EventArgs e)
        {

            List<UserDetails> TempUserList = (List<UserDetails>)Session["lstUserDetails"];

            Button btnUp = (Button)sender;
            GridViewRow row = (GridViewRow)btnUp.NamingContainer;

            switch (btnUp.CommandName)
            {
                case "Up":
                    //If First Item, insert at end (rotating positions)  
                    if (row.RowIndex.Equals(0))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('This is First Record.')</script>", false);
                    }
                    else
                    {
                        UserDetails PrevRec = TempUserList.ElementAt(row.RowIndex - 1);
                        UserDetails CurrRec = TempUserList.ElementAt(row.RowIndex);

                        TempUserList.RemoveAt(row.RowIndex);
                        TempUserList.Insert(row.RowIndex, PrevRec);

                        TempUserList.RemoveAt(row.RowIndex - 1);
                        TempUserList.Insert(row.RowIndex - 1, CurrRec);
                    }
                    break;
                case "Down":
                    //if last item, insert at beginning (rotating positions)  
                    if (row.RowIndex.Equals(grdAccountTeam.Rows.Count - 1))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('This is Last Record.')</script>", false);
                    }
                    else
                    {
                        UserDetails PrevRec = TempUserList.ElementAt(row.RowIndex + 1);
                        UserDetails CurrRec = TempUserList.ElementAt(row.RowIndex);

                        TempUserList.RemoveAt(row.RowIndex);
                        TempUserList.Insert(row.RowIndex, PrevRec);

                        TempUserList.RemoveAt(row.RowIndex + 1);
                        TempUserList.Insert(row.RowIndex + 1, CurrRec);
                    }
                    break;
            }

            grdAccountTeam.DataSource = TempUserList;
            grdAccountTeam.DataBind();


        }
        #endregion

        private void LoadingAccountConactList()
        {
            if (Convert.ToString(Session["Summary"]) == "AdditionalLetter" && Convert.ToInt32(ddlClient.SelectedValue) > 0)
            {
                //lblMessage.Visible = false;
                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();
                SessionId = Session["SessionId"].ToString();
                List<string> lstUser = new List<string>();
                DataSet AccountTeamMemberDS = new DataSet();

                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                UserDetails objUserDetails = new UserDetails();

                if (AccountTeamMemberDS.Tables.Count > 0)
                {
                    if (AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < AccountTeamMemberDS.Tables[0].Rows.Count; i++)
                        {
                            lstUser = sd.GetUserDetails(Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"].ToString()), SessionId);

                            objUserDetails = new UserDetails();

                            objUserDetails.UserId = Convert.ToInt32(AccountTeamMemberDS.Tables[0].Rows[i]["UserId"]);
                            objUserDetails.First_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            objUserDetails.Last_Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]);
                            //objUserDetails.Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]);
                            /********* AS PER CAT - 6/5 - Cat -On USI Contact Details, some names are showing Last Name first.All Names should be displayed FirstName LastName.*/
                            objUserDetails.Name = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["FirstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["LastName"]);
                            //objUserDetails.Role = Convert.ToString(lstUser[0]);
                            objUserDetails.Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["role"]);
                            objUserDetails.WorkPhone = Convert.ToString(lstUser[1]);
                            objUserDetails.Email = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[i]["Email"]);

                            lstUserDetails.Add(objUserDetails);
                        }
                    }
                }

                lblAccountContactPage2.Visible = true;
                lblAccountContactHeadermsg.Visible = true;
                grdAccountTeam.Visible = true;
                pnlGrdAccounTeam.Visible = true;

                if (lstUserDetails.Count > 0)
                {
                    pnlGrdAccounTeam.Height = 150;
                    Session["lstUserDetails"] = lstUserDetails;

                    grdAccountTeam.DataSource = lstUserDetails;
                    grdAccountTeam.DataBind();
                    grdAccountTeam.Height = 130;

                    pnlHeader.Visible = true;
                    grdAccountList.DataSource = lstUserDetails;
                    grdAccountList.DataBind();

                }
                else
                {
                    //lblMessage.Visible = true;
                    pnlGrdAccounTeam.Height = 50;
                }
            }

        }

        protected void ddlPlanContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    //AdditionalInfoTable = GetPlanInfoTable();
                    AdditionalInfoTable = GetPlanInfoTable_ForAdditionalLetters();
                    BindPlanContactGrid();
                }
                else
                {
                    lblPlanContactMessage.Text = "";
                    dvPlanContacts.DataSource = null;
                    dvPlanContacts.DataBind();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void BindPlanContactGrid()
        {
            try
            {
                if (ddlPlanContacts.SelectedValue == "0")
                {
                    List<int> lstProductIds = new List<int>();

                    foreach (GridViewRow oItem in grdPlansAdditional.Rows)
                    {
                        CheckBox chkSelect = oItem.Cells[8].FindControl("chkItemSelect") as CheckBox;
                        if (chkSelect != null)
                        {
                            if (chkSelect.Checked)
                            {
                                lstProductIds.Add(Convert.ToInt32(oItem.Cells[5].Text));
                            }
                        }
                    }

                    try
                    {
                        dtPlanContactInfo.Clear();
                        dtPlanContactInfo = sd.GetPlanContactInformation(lstProductIds, Session["SessionId"].ToString());
                        dtPlanContactInfo.Columns.Add("CarrierName", typeof(string));

                        Session["DataTable_PlanContactInfo"] = dtPlanContactInfo;
                    }
                    catch (Exception ex)
                    {
                        dtPlanContactInfo.Clear();
                        Session["DataTable_PlanContactInfo"] = null;
                    }

                    if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                    {
                        string[] TobeDistinct = { "ProductId" };
                        //dt = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct);
                        dvPlanContacts.DataSource = dtPlanContactInfo.DefaultView.ToTable(true, TobeDistinct); ;
                        dvPlanContacts.DataBind();
                    }
                    else
                    {
                        lblPlanContactMessage.Text = "No contacts found for the selected Plans/Products.";
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void dvPlanContacts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblProductID = (e.Row.FindControl("lblProductID") as Label);
                Label lblName = (e.Row.FindControl("lblName") as Label);
                DropDownList ddlItemPlanContact = (e.Row.FindControl("ddlItemPlanContact") as DropDownList);

                var name = (from a in AdditionalInfoTable.AsEnumerable()
                            where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                            select a.Field<string>("Name")).FirstOrDefault();

                var carrier = (from a in AdditionalInfoTable.AsEnumerable()
                               where Convert.ToInt32(a.Field<string>("ProductId")) == Convert.ToInt32(lblProductID.Text)
                               select a.Field<string>("Carrier")).FirstOrDefault();

                foreach (DataRow row in dtPlanContactInfo.Rows)
                {
                    DataRow dr = dtPlanContactInfo.Rows[rowvalue];
                    dr["CarrierName"] = carrier;
                    if (dr["ProductId"].ToString() == row["ProductId"].ToString())
                    {
                        row["CarrierName"] = carrier;
                    }
                }

                lblName.Text = name;

                var planContact = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ProductId") == Convert.ToInt32(lblProductID.Text)
                                   select new { ContactId = (n.Field<int>("ContactId")), ContactName = (n.Field<string>("ContactName")), ContactPhoneNumber = (n.Field<string>("ContactWorkPhone")), ContactEmail = (n.Field<string>("ContactEmail")) });

                foreach (var item in planContact.ToList())
                {
                    ListItem li = new ListItem();
                    li.Text = item.ContactName + " - " + carrier;
                    li.Value = Convert.ToString(item.ContactId);

                    ddlItemPlanContact.Items.Add(li);
                }

                //Add Default Item in the DropDownList
                ddlItemPlanContact.Items.Insert(0, new ListItem("Select"));
                ddlItemPlanContact.Items.Insert(1, new ListItem("None"));
                rowvalue++;


            }
        }

        protected void rdlPlanSection2_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlansAdditional.DataSource = null;
            grdPlansAdditional.DataBind();
            ddlPlanContacts.SelectedIndex = 1;
            dvPlanContacts.DataSource = null;
            dvPlanContacts.DataBind();
            lblPlanContactMessage.Text = "";
        }


        /*-------------- Button Next Button -----------*/
        protected void btnNext_Click(object sender, EventArgs e)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            Eligibility eligibilityItem = new Eligibility();
            string _PlanName = string.Empty;
            string selected_Value = string.Empty;
            bool flag = true;

            try
            {
                if (mvClientContact.ActiveViewIndex == 0) //**** When on First Criteria Page
                {
                    if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                    {
                        if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                            ddlClient.Focus();
                            flag = false;
                        }
                        // Commented by Vaibhav all validations performed at client side
                        //else
                        //{
                        //   // flag = CheckAccountContactsClientIntakeSelected();
                        //}

                        if (flag == true)
                        {
                            mvClientContact.ActiveViewIndex = 1;
                            btnNext.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage2');";
                            if (grdAccountTeam.Rows.Count <= 0)
                            {
                                //Loading Account Contact List 
                                LoadingAccountConactList();
                            }

                            divBtnPrevious.Style.Add("Display", "block");
                            divBtnNext.Style.Add("Display", "block");
                            divBtnSummary.Style.Add("Display", "none");
                        }
                    }
                }
                else if (mvClientContact.ActiveViewIndex == 1) //**** When on SECOND Criteria Page
                {
                    if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                        ddlClient.Focus();
                        flag = false;
                    }
                    else if (ddlBRCList.SelectedIndex == -1 || ddlBRCList.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select BRC.')</script>", false);
                        ddlClient.Focus();
                        flag = false;
                    }
                    else
                    {
                        flag = CheckAccountContactsSelected(); //**** CHECK WEATHER USER SELECT ACCOUNT CONTACT OR NOT 
                    }


                    if (flag == true)
                    {
                        mvClientContact.ActiveViewIndex = 2;
                        ddlPlanContacts.SelectedIndex = 1;
                        lblPlanContactMessage.Text = "";
                        dvPlanContacts.DataSource = null;
                        dvPlanContacts.DataBind();
                        divBtnPrevious.Style.Add("Display", "block");
                        divBtnNext.Style.Add("Display", "none");
                        divBtnSummary.Style.Add("Display", "block");
                        btnSummary.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage3');";
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /*------- Previous Button Click*/
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (mvClientContact.ActiveViewIndex == 2)
                {
                    mvClientContact.ActiveViewIndex = 1;
                    divBtnPrevious.Style.Add("Display", "block");
                    divBtnNext.Style.Add("Display", "block");
                    divBtnSummary.Style.Add("Display", "none");
                    btnNext.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage2');";
                }
                else if (mvClientContact.ActiveViewIndex == 1)
                {
                    mvClientContact.ActiveViewIndex = 0;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "block");
                    divBtnSummary.Style.Add("Display", "none");
                    btnNext.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage1');";
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /******************************************************/
        /*   This button load Plan for Criteria Page 3       */
        /******************************************************/
        protected void btnAdditionalViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                {
                    grdPlansAdditional.DataSource = null;
                    grdPlansAdditional.DataBind();
                    ddlPlanContacts.SelectedIndex = 1;
                    lblPlanContactMessage.Text = "";
                    dvPlanContacts.DataSource = null;
                    dvPlanContacts.DataBind();

                    flag = CheckAccountContactsSelected();
                }
                if (flag)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "Tools1")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlanSection2.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    commonPlanList.Add(item);
                                }
                            }

                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            grdPlansAdditional.DataSource = lstPlanList;
                            grdPlansAdditional.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlansAdditional.Visible = true;
                                pnlPlansAdditional.Height = 320;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlansAdditional.HeaderRow.FindControl("chkAdditionalHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlansAdditional.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlansAdditional');</script>", false);
                            }
                            else
                            {
                                grdPlansAdditional.DataSource = null;
                                grdPlansAdditional.DataBind();
                                pnlPlansAdditional.Visible = true;
                                pnlPlansAdditional.Height = 50;
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }//IfFlagCloseHere 

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        private bool CheckAccountContactsSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;

                foreach (GridViewRow row in grdAccountTeam.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[4].FindControl("chkItemSelect") as CheckBox);
                        if (chkRow.Checked)
                        {
                            cnt++;
                        }
                    }
                }

                if (cnt == 0)
                {
                    string script = "alert(\"Please select Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        protected void ddlFormat_SelectedIndexChangeds(object sender, EventArgs e)
        {
            ddlUSI_City.Items.Clear();
            ddlUSI_State.SelectedIndex = 0;
            if (ddlFormat.SelectedValue == "Email")
            {
                hsnStateCityRequired.Value = "no";
                StateCityTable.Style.Add("display", "none");
            }
            else if (ddlFormat.SelectedValue == "Word")
            {
                StateCityTable.Style.Add("display", dictStateDropDownDisplayValue[ddlcontents.SelectedValue].ToLower() == "yes" ? "" : "none");
                hsnStateCityRequired.Value = dictStateDropDownDisplayValue[ddlcontents.SelectedValue].ToLower();
            }
            else
            {
                StateCityTable.Style.Add("display", dictStateDropDownDisplayValue[ddlcontents.SelectedValue].ToLower() == "yes" ? "" : "none");
                StateCityTable.Style.Add("display", "none");
            }
        }

        protected void ddlcontents_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            btnReset_Click(null, null);
            txtLetterDecription.Visible = false;
            txtLetterDecription.Text = "";
            ddlUSI_State.SelectedIndex = 0;
            ddlUSI_City.Items.Clear();
            hdnLetterPlanCount.Value = dictLetterPlanCount[ddlcontents.SelectedValue].ToString();
            hdnLetterPlanRequired.Value = dictLetterPlanRequiredValue[ddlcontents.SelectedValue].ToLower();
            if (dictClientContactSheetDisplayValue[ddlcontents.SelectedValue].ToLower() == "yes")
            {
                tblClientContactSheet.Style.Add("display", "");
                ddlClientContactSheet.SelectedIndex = 0;
                divBtnSummary.Style.Add("display", "none");
                divBtnNext.Style.Add("display", "");
                hdnContactSheetRequired.Value = "yes";
                btnSummary.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage3');";
            }
            else
            {
                tblClientContactSheet.Style.Add("display", "none");
                divBtnSummary.Style.Add("display", "");
                divBtnNext.Style.Add("display", "none");
                hdnContactSheetRequired.Value = "no";
                btnSummary.OnClientClick = "javascript:return ValidateForm();";
            }

            #region StateCity dropdown visibility
            if (dictStateDropDownDisplayValue[ddlcontents.SelectedValue].ToLower().Equals("yes"))
            {
                StateCityTable.Style.Add("display", "");
                hsnStateCityRequired.Value = "yes";
            }
            else
            {
                StateCityTable.Style.Add("display", "none");
                hsnStateCityRequired.Value = "no";
            }
            #endregion
            hdnContactValue.Value = dictContactValue[ddlcontents.SelectedValue].ToLower();
            hdnLetterCarrierValue.Value = dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower();
            #region Letter Format
            if (dictLetterFormat[ddlcontents.SelectedValue].ToLower().Equals("both"))
            {
                ddlFormat.Enabled = true;
                ddlFormat.SelectedValue = "0";
            }
            else if (dictLetterFormat[ddlcontents.SelectedValue].ToLower().Equals("word"))
            {
                ddlFormat.SelectedValue = "Word";
                ddlFormat.Enabled = false;
            }
            else
            {
                ddlFormat.Enabled = false;
                ddlFormat.SelectedValue = "0";
            }

            #endregion
            #region Letter Description
            if (dictLetterDescriptions[ddlcontents.SelectedValue.Trim()] != string.Empty)
            {
                txtLetterDecription.Text = dictLetterDescriptions[ddlcontents.SelectedValue.Trim()];
                txtLetterDecription.Visible = true;
            }
            else
            {
                txtLetterDecription.Text = ""; ;
                txtLetterDecription.Visible = false;
            }
            #endregion

            ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);
        }


        /* As Per Catherine Boynton  IF New Client Thank You Letter is selected, 
          Format: WORD should be the default and this field should not be editable.[March 22, 2018 7:46 PM]*/
        private void forNewClientThankYouLetter()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            panelGrid1.Style.Add("display", "none");
            ddlFormat.SelectedIndex = 2;
            ddlFormat.Enabled = false;
        }

        private void IsNotThankYouLetter()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            ddlFormat.SelectedIndex = 0;
            ddlFormat.Enabled = true;
            ddlClientContactSheet.SelectedIndex = 0;
            ddlBRCList.SelectedIndex = 0;
            grdAccountTeam.DataSource = null;
            grdAccountTeam.DataBind();
            grdPlansAdditional.DataSource = null;
            grdPlansAdditional.DataBind();
            ddlPlanContacts.SelectedIndex = 1;
            lblPlanContactMessage.Text = "";
            dvPlanContacts.DataSource = null;
            dvPlanContacts.DataBind();
        }

        protected void chkAdditionalHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlansAdditional.HeaderRow.FindControl("chkAdditionalHeaderSelect");
            if (ChkBoxHeader.Checked == true)
            {
                if (dictLetterPlanCount[ddlcontents.SelectedValue] <= 1 && ChkBoxHeader.Checked == true)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select only " + dictLetterPlanCount[ddlcontents.SelectedValue] + " plan from Grid.')</script>", false);
                    ChkBoxHeader.Checked = false;
                    return;
                }
                else
                {
                    foreach (GridViewRow row in grdPlansAdditional.Rows)
                    {
                        CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                        ChkBoxRows.Checked = true;
                    }
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                }
            }
            else
            {
                foreach (GridViewRow row in grdPlansAdditional.Rows)
                {
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                    ChkBoxRows.Checked = false;
                }
            }

            //foreach (GridViewRow row in grdPlansAdditional.Rows)
            //{
            //    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
            //    if (ChkBoxHeader.Checked == true)
            //    {
            //        ChkBoxRows.Checked = true;
            //    }
            //    else
            //    {
            //        ChkBoxRows.Checked = false;
            //    }
            //}
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlansAdditional');</script>", false);
        }

        /// <summary>
        /// HERE WE CHECK AND UNCHECKED GRID VIEW PLAN 
        /// </summary>
        private void ClearGridView()
        {
            //grdPlans.DataSource = null;
            //grdPlans.DataBind();
            //ddlFormat.Enabled = true;
            //ddlClientContactSheet.SelectedIndex = 0;
            //ddlBRCList.SelectedIndex = 0;
            //grdAccountTeam.DataSource = null;
            //grdAccountTeam.DataBind();

            //grdPlansAdditional.DataSource = null;
            //grdPlansAdditional.DataBind();
            //ddlPlanContacts.SelectedIndex = 1;
            //lblPlanContactMessage.Text = "";
            //dvPlanContacts.DataSource = null;
            //dvPlanContacts.DataBind();

            if (grdPlans.Rows.Count > 1)
            {
                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                ChkBoxHeader.Checked = false;
                foreach (GridViewRow row in grdPlans.Rows)
                {
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                    ChkBoxRows.Checked = false;
                }
            }
        }

        protected void ddlUSI_State_SelectedIndexChanged(object sender, EventArgs e)
        {
            //USI State
            DataTable dtOfficeCity = new DataTable();
            if (ddlUSI_State.SelectedIndex > 0)
            {
                dtOfficeCity = bp.GetOfficeCityList(ddlUSI_State.SelectedValue);
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            else
            {
                ddlUSI_City.DataSource = dtOfficeCity;
                ddlUSI_City.DataBind();
            }
            ddlUSI_City.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlUSI_City.SelectedIndex = 0;
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                grdPlansAdditional.DataSource = null;
                grdPlansAdditional.DataBind();
                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();
                ddlPlanContacts.SelectedIndex = 1;
                dvPlanContacts.DataSource = null;
                dvPlanContacts.DataBind();
                lblPlanContactMessage.Text = "";

                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

                panelGrid1.Style.Add("display", "none");
                // StateCityTable.Style.Add("display", "none");
                //  tblClientContact.Style.Add("display", "none");



                //ddlcontents.SelectedIndex = 0;
                //ddlUSI_State.SelectedIndex = 0;
                // ddlUSI_City.Items.Clear();
                // ddlClientContactSheet.SelectedIndex = 0;
                //  ddlFormat.Enabled = true;
                // ddlFormat.SelectedIndex = 0;
                //  cblistAccountContact.Items.Clear();
                ddlBRCList.SelectedIndex = 0;
                rdlPlanSection2.SelectedIndex = 0;
                rdlPlan.SelectedIndex = 0;
                ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        private void ClearCommunicationFields()
        {
            txtLetterDecription.Visible = false;
            txtLetterDecription.Text = "";
            ddlUSI_State.SelectedIndex = 0;
            ddlUSI_City.Items.Clear();
            tblClientContactSheet.Style.Add("display", "none");
            StateCityTable.Style.Add("display", "none");
            ddlFormat.Enabled = true;
            ddlFormat.SelectedValue = "0";

            hsnStateCityRequired.Value = dictStateDropDownDisplayValue[ddlcontents.SelectedValue];
            hdnContactValue.Value = dictContactValue[ddlcontents.SelectedValue];
            hdnContactSheetRequired.Value = dictClientContactSheetDisplayValue[ddlcontents.SelectedValue];
            hdnLetterPlanCount.Value = dictLetterPlanCount[ddlcontents.SelectedValue].ToString();
            hdnLetterPlanRequired.Value = dictLetterPlanRequiredValue[ddlcontents.SelectedValue].ToString();
            hdnLetterCarrierValue.Value = dictLetterCarriersValue[ddlcontents.SelectedValue];
        }

        /// <summary>
        /// Reset page.
        /// </summary>

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                if (sender != null)
                {
                    ddlcontents.SelectedIndex = 0;
                    ClearCommunicationFields();
                }

                txtsearch.Text = "";
                rdlClient.SelectedIndex = 0;
                ddlClient.Items.Clear();
                //cblistAccountContact.Items.Clear();

                trAccountContact.Style.Add("display", "none");
                ddlAccountContacts.Items.Clear();
                ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
                ddlAccountContacts.SelectedIndex = 0;
                panelGrid1.Style.Add("display", "none");
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                grdPlansAdditional.DataSource = null;
                grdPlansAdditional.DataBind();
                grdAccountTeam.DataSource = null;
                grdAccountTeam.DataBind();
                ddlPlanContacts.SelectedIndex = 1;
                dvPlanContacts.DataSource = null;
                dvPlanContacts.DataBind();
                lblPlanContactMessage.Text = "";
                ddlBRCList.SelectedIndex = 0;
                rdlPlanSection2.SelectedIndex = 0;
                rdlPlan.SelectedIndex = 0;

                ddlCarriers.Items.Clear();
                ddlCarriers.Items.Insert(0, new ListItem("Select", "0"));
                ddlCarriers.SelectedValue = "0";
                spanCarrierFilter.Style.Add("display", "none");

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                SessionId = Session["SessionId"].ToString();




                // StateCityTable.Style.Add("display", "none");
                // tblClientContact.Style.Add("display", "none");
                // ddlcontents.SelectedIndex = 0;
                //  ddlUSI_State.SelectedIndex = 0;
                //  ddlUSI_City.Items.Clear();
                // ddlClientContactSheet.SelectedIndex = 0;
                // ddlFormat.Enabled = true;
                //ddlFormat.SelectedIndex = 0;




                ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    grdPlans.DataSource = null;
        //    grdPlans.DataBind();

        //    lblMessage.Visible = false;
        //    grdAccountTeam.DataSource = null;
        //    grdAccountTeam.DataBind();
        //    grdPlansAdditional.DataSource = null;
        //    grdPlansAdditional.DataBind();

        //    ddlPlanContacts.SelectedIndex = 1;
        //    dvPlanContacts.DataSource = null;
        //    dvPlanContacts.DataBind();
        //    lblPlanContactMessage.Text = "";

        //    panelGrid1.Style.Add("display", "none");

        //    ////divBtnPrevious.Style.Add("Display", "none");
        //    ////divBtnNext.Style.Add("Display", "none");
        //    ////divBtnSummary.Style.Add("Display", "block");

        //    //ddlcontents.SelectedIndex = 0;
        //    //ddlUSI_State.SelectedIndex = 0;
        //   // ddlUSI_City.Items.Clear();
        //    //ddlClientContactSheet.SelectedIndex = 0;
        //    //ddlFormat.Enabled = true;
        //    //ddlFormat.SelectedIndex = 0;
        //    ddlBRCList.SelectedIndex = 0;
        //    ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);

        //    lblMessage.Visible = false;
        //    cblistAccountContact.Items.Clear();
        //    SessionId = Session["SessionId"].ToString();
        //    List<Contact> acctContact = new List<Contact>();
        //    List<Contact> ContactList = new List<Contact>();
        //    Contact cont = new Contact();
        //    if (ddlClient.SelectedValue != "")
        //    {
        //        ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
        //    }

        //    ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
        //    if (ContactList != null)
        //    {
        //        for (int i = 0; i < ContactList.Count; i++)
        //        {
        //            cont = new Contact();
        //            cont.ContactId = ContactList[i].ContactId;

        //            if (!string.IsNullOrEmpty(ContactList[i].Title))
        //            {
        //                cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
        //            }
        //            else
        //            {
        //                cont.Name = ContactList[i].Name;
        //            }

        //            acctContact.Add(cont);
        //        }
        //    }

        //    lblAccountContact.Visible = true;
        //    pnlChkAccountContact.Visible = true;

        //    if (acctContact.Count > 0)
        //    {
        //        ddlAccountContacts.Items.Clear();
        //        ddlAccountContacts.DataSource = acctContact;
        //        ddlAccountContacts.DataBind();
        //        ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
        //        ddlAccountContacts.SelectedIndex = 0;
        //        cblistAccountContact.DataSource = acctContact;
        //        cblistAccountContact.DataBind();
        //        pnlChkAccountContact.Height = 130;
        //    }
        //    else
        //    {
        //        lblMessage.Visible = true;
        //        pnlChkAccountContact.Height = 50;
        //        ddlAccountContacts.Items.Clear();
        //        ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
        //        ddlAccountContacts.SelectedIndex = 0;
        //    }

        //}

        protected void ddlClientContactSheet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlClientContactSheet.SelectedValue == "Include")
            {
                divBtnSummary.Style.Add("display", "none");
                divBtnNext.Style.Add("display", "");
                hdnContactSheetRequired.Value = "yes";
                btnSummary.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage3');";
                btnNext.OnClientClick = "javascript:return ValidateOnNextClick('CriteriaPage1');";
            }
            else
            {
                divBtnSummary.Style.Add("display", "");
                divBtnNext.Style.Add("display", "none");
                hdnContactSheetRequired.Value = "no";
                btnSummary.OnClientClick = "javascript:return ValidateForm();";
                if (ddlcontents.SelectedValue == "NewClientThankYouLetter")
                {
                    dictLetterPlanRequiredValue[ddlcontents.SelectedValue] = "no";
                    hdnLetterPlanRequired.Value = dictLetterPlanRequiredValue[ddlcontents.SelectedValue];
                    panelGrid1.Style.Add("display", "none");
                }
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();

            //lblMessage.Visible = false;
            grdAccountTeam.DataSource = null;
            grdAccountTeam.DataBind();
            grdPlansAdditional.DataSource = null;
            grdPlansAdditional.DataBind();

            ddlPlanContacts.SelectedIndex = 1;
            dvPlanContacts.DataSource = null;
            dvPlanContacts.DataBind();
            lblPlanContactMessage.Text = "";
            if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower().Equals("yes"))
            {
                lblAvailablePlansHeader.Text = "Carriers";
                lblAvailablePlansText.Text = "Select the applicable Carrier you would like to include in your document based on what is available in BenefitPoint.";
                spanCarrierFilter.Style.Add("display", "");
            }
            else
            {
                lblAvailablePlansHeader.Text = "Available Plans and Products";
                lblAvailablePlansText.Text = "Select the applicable plans and products you would like to include in your document based on what is available in BenefitPoint.";
                spanCarrierFilter.Style.Add("display", "none");
            }


            ddlBRCList.SelectedIndex = 0;
            //lblMessage.Visible = false;
            //   cblistAccountContact.Items.Clear();
            SessionId = Session["SessionId"].ToString();
            BindContacts();
            BindCarriers();
            SetPlansAndProductVisibility();




            ScriptManager.RegisterStartupScript(Page, GetType(), "HideShowButton", "<script>ddlcontents_changed(" + ddlClientContactSheet.SelectedIndex + ")</script>", false);
        }

        private void SetPlansAndProductVisibility()
        {
            bool IsShow = false;
            if (hdnContactSheetRequired.Value.ToLower() == "yes")
            {
                if (ddlClientContactSheet.SelectedValue == "Include")
                {
                    IsShow = false;
                    divBtnSummary.Style.Add("display", "none");
                    divBtnNext.Style.Add("display", "");
                    hdnContactSheetRequired.Value = "yes";
                }
                else
                {
                    IsShow = true;
                    divBtnSummary.Style.Add("display", "");
                    divBtnNext.Style.Add("display", "none");
                    hdnContactSheetRequired.Value = "no";
                }

            }
            else
            {
                IsShow = true;
                divBtnSummary.Style.Add("display", "");
                divBtnNext.Style.Add("display", "none");
                hdnContactSheetRequired.Value = "no";
            }

            if (IsShow)
            {
                if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower() == "yes" && dictLetterPlanRequiredValue[ddlcontents.SelectedValue].ToLower() == "yes")
                {
                    panelGrid1.Style.Add("display", "");
                    btnViewPlans.Visible = true;
                    spanCarrierFilter.Style.Add("display", "");
                }
                else if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower() == "no" && dictLetterPlanRequiredValue[ddlcontents.SelectedValue].ToLower() == "yes")
                {
                    panelGrid1.Style.Add("display", "");
                    btnViewPlans.Visible = true;
                    spanCarrierFilter.Style.Add("display", "none");
                }
                else if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower() == "yes" && dictLetterPlanRequiredValue[ddlcontents.SelectedValue].ToLower() == "no")
                {
                    panelGrid1.Style.Add("display", "");
                    btnViewPlans.Visible = false;
                    spanCarrierFilter.Style.Add("display", "");
                }
                else
                {
                    panelGrid1.Style.Add("display", "none");
                    btnViewPlans.Visible = false;
                    spanCarrierFilter.Style.Add("display", "none");
                }
            }

        }

        private void BindContacts()
        {
            if (dictContactValue[ddlcontents.SelectedValue].ToLower().Equals("account"))
            {
                trAccountContact.Style.Add("display", "");
                //cblistAccountContact.Visible = false;
                //pnlChkAccountContact.Visible = false;
                //lblAccountContact.Visible = false;
                //lblMessage.Visible = false;
                List<Contact> acctContact = new List<Contact>();
                List<Contact> ContactList = new List<Contact>();
                Contact cont = new Contact();
                if (ddlClient.SelectedValue != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                }
                ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
                if (ContactList != null)
                {
                    for (int i = 0; i < ContactList.Count; i++)
                    {
                        cont = new Contact();
                        cont.ContactId = ContactList[i].ContactId;

                        if (!string.IsNullOrEmpty(ContactList[i].Title))
                        {
                            cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                        }
                        else
                        {
                            cont.Name = ContactList[i].Name;
                        }

                        acctContact.Add(cont);
                    }
                }

                if (acctContact.Count > 0)
                {
                    ddlAccountContacts.Items.Clear();
                    ddlAccountContacts.DataSource = acctContact;
                    ddlAccountContacts.DataBind();
                    ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
                    ddlAccountContacts.SelectedIndex = 0;
                }
                else
                {
                    ddlAccountContacts.Items.Clear();
                    ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
                    ddlAccountContacts.SelectedIndex = 0;
                }
            }
            else if (dictContactValue[ddlcontents.SelectedValue].ToLower().Equals("carrier"))
            {
                ddlAccountContacts.Items.Clear();
                ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
                ddlAccountContacts.SelectedIndex = 0;
                trAccountContact.Style.Add("display", "none");
            }
            else
            {
                ddlAccountContacts.Items.Clear();
                ddlAccountContacts.Items.Insert(0, new ListItem("Select", ""));
                ddlAccountContacts.SelectedIndex = 0;
                trAccountContact.Style.Add("display", "none");
            }


        }

        private void BindCarriers()
        {
            try
            {
                if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower().Equals("yes"))
                {
                    spanCarrierFilter.Style.Add("display", "");
                    bool flag = true;
                    List<Plan> commonPlanList = new List<Plan>();
                    ddlCarriers.Items.Clear();
                    // Hash tabe for list of plans to show in the grid view
                    Hashtable htSortedPlanList = new Hashtable();
                    if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                    {
                        htSortedPlanList = PatraTransmittal_planList();
                    }
                    if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                    {
                        if (ddlClient.SelectedIndex == -1)
                        {
                            flag = false;
                        }
                    }

                    if (flag == true)
                    {
                        List<Plan> PlanList = new List<Plan>();
                        SessionId = Session["SessionId"].ToString();
                        if (ddlClient.SelectedIndex > 0)
                        {
                            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        }
                        if (PlanList != null)
                        {
                            if (PlanList.Count > 0)
                            {
                                if (rdlPlan.SelectedIndex == 0)
                                {
                                    // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                    if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                                    {
                                        foreach (Plan item in PlanList)
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                            {
                                                /************************************AS PER REQUIREMENT ******************************
                                                  Cat - The following letters are only showing available carriers and plans for Life and Disability plan types. 
                                                  They should show all carriers and all plan types
                                                ***************************************************************************/
                                                if (lstCarriersAndAvailableAllPlans.Contains(ddlcontents.SelectedValue.Trim()))
                                                {
                                                    commonPlanList.Add(item);
                                                }
                                                else
                                                {
                                                    if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                                    {
                                                        commonPlanList.Add(item);
                                                    }
                                                }

                                            }
                                        }
                                    }
                                    // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                                }
                                if (rdlPlan.SelectedIndex == 1)
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (lstCarriersAndAvailableAllPlans.Contains(ddlcontents.SelectedValue.Trim()))
                                        {
                                            commonPlanList.Add(item);
                                        }
                                        else
                                        {
                                            if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }

                                //  commonPlanList.OrderBy(a => a.ProductTypeId);
                                List<Carrier> lstPlanList = new List<Carrier>();
                                List<int> lstCarrierID = new List<int>();
                                foreach (Plan item in commonPlanList)
                                {
                                    if (!lstCarrierID.Contains(item.CarrierId))
                                    {
                                        lstCarrierID.Add(item.CarrierId);
                                        Carrier objCarrier = new Carrier();
                                        objCarrier.CarrierId = item.CarrierId;
                                        objCarrier.CarrierName = item.CarrierName;
                                        lstPlanList.Add(objCarrier);
                                    }
                                }



                                ddlCarriers.DataSource = lstPlanList;
                                ddlCarriers.Items.Insert(0, new ListItem("Select", "0"));
                                ddlCarriers.DataBind();
                                ddlCarriers.SelectedValue = "0";

                            }
                            else
                            {
                                string script = "alert(\"No carriers for selected client.\");";
                                ddlCarriers.Items.Insert(0, new ListItem("Select", "0"));
                                ddlCarriers.SelectedValue = "0";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                        else
                        {
                            string script = "alert(\"No carriers for selected client.\");";
                            ddlCarriers.Items.Insert(0, new ListItem("Select", "0"));
                            ddlCarriers.SelectedValue = "0";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                }
                else
                {
                    spanCarrierFilter.Style.Add("display", "none");
                    ddlCarriers.Items.Clear();
                    ddlCarriers.Items.Insert(0, new ListItem("Select", "0"));
                    ddlCarriers.SelectedValue = "0";
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                //TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable PlanInfoTable = new DataTable();

                dtPlanContact = new DataTable();
                dtPlanContact = CreateContactTable();
                dtPlanContact.Clear();
                AdditionalInfoTable = GetPlanInfoTable_ForAdditionalLetters();

                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }

                    // Commented By Vaibhav for additional letters added
                    //else
                    //{
                    //    flag = CheckAccountContactsClientIntakeSelected();
                    //}
                }

                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    List<Carrier> carrierList = new List<Carrier>();
                    string mynewfile = "";
                    int parentProductID = 0;
                    int carrierID = 0;
                    string priorCarrierName = String.Empty;

                    sd.BuildAccountTable();
                    //sd.BuildBenefitSummaryTable();
                    //sd.BuildBenifitSummaryStructureTable();
                    //sd.BuildContributionTable_Pilot();
                    //sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    //sd.BuildRateTable();

                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    //code used for contract review and benchmark audit report
                    #region common for both
                    PlanInfoTable = GetPlanInfoTable();

                    DataTable PlanTable = new DataTable();
                    PlanTable.Merge(PlanInfoTable);

                    //RateDS = sd.GetRateForTools_Pilot(PlanTable, SessionId);
                    // ContributionDS = sd.GetContributionForPilot(PlanTable, SessionId);

                    
                    ////var table = from x in PlanInfoTable.AsEnumerable() where !string.IsNullOrEmpty(x.Field<string>("PlanType")) select x;

                    ////PlanTable.Clear();
                    ////foreach (dynamic i in table)
                    ////{
                    ////    PlanTable.NewRow();
                    ////    PlanTable.ImportRow(i);
                    ////}

                    ProductDS = sd.GetProductDetail(PlanTable, SessionId);
                    //BenefitDS = sd.GetBenefitSummaryPilot(PlanTable, SessionId);
                    //Updated as per Amogh's CR dated 19 June 2018 for issue raised by Lisa
                    if (hdnLetterPlanRequired.Value.ToLower().Equals("yes"))
                    {
                        if (dictClientContactSheetDisplayValue[ddlcontents.SelectedValue].ToLower().Equals("yes") && ddlClientContactSheet.SelectedValue == "Include")
                        {
                            if (AdditionalInfoTable.Rows.Count <= 0)
                            {
                                if (pnlPlansAdditional.Visible == true)
                                {
                                    if (grdPlansAdditional.Rows.Count > 0)
                                    {
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                    }
                                    else
                                    {
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('No plans found for selected criteria.')</script>", false);
                                    }
                                }
                                else
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please click on \"View Plans\" to select plans from plan grid. ')</script>", false);
                                }

                                return;
                            }
                        }
                        else
                        {
                            if (PlanTable.Rows.Count <= 0)
                            {
                                if (pnlPlans.Visible == true)
                                {
                                    if (grdPlans.Rows.Count > 0)
                                    {
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                    }
                                    else
                                    {
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('No plans found for selected criteria.')</script>", false);
                                    }

                                }
                                else
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please click on \"View Plans\" to select plans from plan grid. ')</script>", false);
                                }

                                return;
                            }
                        }
                    }


                    //if (ddlcontents.SelectedValue == "LifeDisability_CarrierToCarrier" || ddlcontents.SelectedValue == "LifeDisability_CarrierToClient")
                    //{
                    //    if (PlanTable.Rows.Count <= 0)
                    //    {
                    //        if (grdPlans.Rows.Count > 0)
                    //        {
                    //            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                    //        }
                    //        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                    //        return;
                    //    }
                    //}
                    //else if (ddlcontents.SelectedValue == "NewClientThankYouLetter" && ddlClientContactSheet.SelectedValue == "Include")
                    //{
                    //    if (AdditionalInfoTable.Rows.Count <= 0)
                    //    {
                    //        if (grdPlansAdditional.Rows.Count > 0)
                    //        {
                    //            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                    //        }
                    //        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                    //        return;
                    //    }

                    //}


                    DataTable ProductType = new DataTable();
                    ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductType.Columns.Add("PlanNumber", typeof(string));
                    ProductType.Columns.Add("ProductId", typeof(Int32));
                    DataRow[] foundrow = null;

                    for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    {
                        ProductType.Rows.Add();
                        ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);

                        foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                        ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                        ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                        ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);
                        if (ddlcontents.SelectedValue == "LifeDisability_CarrierToClient")
                        {
                            parentProductID = Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[i]["parentProductID"]);
                        }
                    }

                    //BenefitStructureDS = sd.GetBenefitSummaryStructurePilot(ProductType, SessionId);
                    if (ddlcontents.SelectedValue == "LifeDisability_CarrierToClient")
                    {
                        if (parentProductID != 0)
                        {
                            carrierID = sd.GetProductDetail_Letters(parentProductID, SessionId);
                            carrierList = bp.GetAllCarriers(SessionId);
                            foreach (var carrier in carrierList)
                            {
                                if (carrier.CarrierId == carrierID)
                                    priorCarrierName = carrier.CarrierName;
                            }
                        }
                        else
                        {
                            priorCarrierName = " ";

                        }
                    }

                    if (AdditionalInfoTable.Rows.Count > 0)
                    {
                        foreach (DataRow r in AdditionalInfoTable.Rows)
                        {
                            DataRow dr = dtPlanContact.NewRow();
                            dr["CarrierName"] = r["Carrier"].ToString();
                            dr["ProductId"] = r["ProductId"].ToString();
                            dtPlanContact.Rows.Add(dr);
                        }
                        foreach (GridViewRow oItem in dvPlanContacts.Rows)
                        {
                            DropDownList dropdwn = oItem.Cells[1].FindControl("ddlItemPlanContact") as DropDownList;
                            Label lblProductID = oItem.Cells[2].FindControl("lblProductID") as Label;

                            foreach (DataRow r in dtPlanContactInfo.Rows)
                            {
                                foreach (DataRow rowContact in dtPlanContact.Rows)
                                {
                                    if (dropdwn.SelectedIndex > 1)
                                    {
                                        if (dropdwn.SelectedValue == r["ContactId"].ToString() && lblProductID.Text == r["ProductId"].ToString())
                                        {
                                            string productId = r["ProductId"].ToString();
                                            if (dtPlanContact.AsEnumerable().Any(row => productId == row.Field<String>("ProductId")))
                                            {
                                                //DataRow rowno = dtPlanContact.AsEnumerable().Where(x => x["ProductId"].ToString() == productId).First();
                                                var matchingRows = from row in dtPlanContact.AsEnumerable()
                                                                   where row.Field<string>("ProductId") == productId
                                                                   select row;

                                                DataRow rowno = matchingRows.FirstOrDefault();
                                                if (rowno != null)
                                                {
                                                    rowno["ContactId"] = r["ContactId"].ToString();
                                                    rowno["ContactName"] = r["ContactName"].ToString();
                                                    rowno["ContactWorkPhone"] = r["ContactWorkPhone"].ToString();
                                                    rowno["ContactEmail"] = r["ContactEmail"].ToString();
                                                }
                                            }
                                            else
                                            {
                                                dtPlanContact.ImportRow(r);
                                            }
                                            break;
                                        }
                                    }

                                }
                            }
                        }
                        DataView view = new DataView(dtPlanContact);
                        dtPlanContact = view.ToTable(true, "ContactId", "ContactName", "ContactEmail", "ContactWorkPhone", "Contact_FirstName", "Contact_LastName", "Contact_Address", "CarrierName");
                        dtPlanContact.AcceptChanges();
                    }

                    #endregion

                    if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                    {
                        if (ddlcontents.SelectedValue == "BOR")
                        {
                            if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_BOR(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_BORToCarrier(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "LifeDisability_CarrierToCarrier")
                        {
                            if (PlanTable.Rows.Count > 0)
                            {
                                if (ddlFormat.SelectedValue == "Email")
                                {
                                    CreateReports_BenefitPointEmail_LifeDisability_CarrierToCarrier(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                                }
                                else if (ddlFormat.SelectedValue == "Word")
                                {
                                    mynewfile = CreateLetters_LifeDisabilityCarrierToCarrier(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                                }
                            }
                            else
                            {
                                if (grdPlans.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                return;
                            }
                        }
                        if (ddlcontents.SelectedValue == "LifeDisability_CarrierToClient")
                        {
                            if (PlanTable.Rows.Count > 0)
                            {
                                if (ddlFormat.SelectedValue == "Email")
                                {
                                    CreateReports_BenefitPointEmail_LifeDisability_CarrierToClient(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList, priorCarrierName);
                                }
                                else if (ddlFormat.SelectedValue == "Word")
                                {
                                    mynewfile = CreateLetters_LifeDisabilityCarrierToClient(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList, priorCarrierName);
                                }
                            }
                            else
                            {
                                if (grdPlans.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                return;
                            }
                        }
                        if (ddlcontents.SelectedValue == "NewClientThankYouLetter")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_NewClientThankYouLetter(SessionId, AdditionalInfoTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "USITerminationLetter")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_TerminationLetter(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_USITermination_Letter(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "AMBestRatingClientLetter_MidyearDowngrade")
                        {
                            if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_AM_Best_Rating_MidyearDowngrade(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                            else
                            {
                                mynewfile = CreateLetters_AMBestRatingClientLetter_MidyearDowngrade(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                        }

                        if (ddlcontents.SelectedValue == "AMBestRatingClientLetter_InitialCoveragePlacement")
                        {
                            if (ddlFormat.SelectedValue == "Email")
                            {
                                // NA - Only word format
                                return;
                            }
                            else
                            {
                                mynewfile = CreateLetters_AMBestRatingClientLetter_InitialCoveragePlacement(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "Authorization_to_Share_PHI")
                        {
                            if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_Authorization_To_Share_PHI(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                            else
                            {
                                mynewfile = CreateLetters_Authorization_to_Share_PHI(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                        }
                        // Developed By Shravan
                        if (ddlcontents.SelectedValue == "BAA_Cover_Letter")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_BAA_Cover_Letter(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_BAA_Cover_Letter(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "Renewal_Request_Letter_to_Carrier")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_RenewalRequestLettertoCarrier(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_Renewal_Request_Letter_to_Carrier(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }
                        if (ddlcontents.SelectedValue == "Carrier_Not_Rated")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_Carrier_Not_Rated(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                // NA - Only word format
                                return;
                            }
                        }
                        if (ddlcontents.SelectedValue == "HICA_Cover_Letter")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_HICA_Cover_Letter(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_HICA_Cover_Letter(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }

                        if (ddlcontents.SelectedValue == "Marketing_Declination_Letter_To_Carrier")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_Marketing_Declination_Letter_To_Carrier(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_Marketing_Declination_Letter_To_Carrier(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }


                        if (ddlcontents.SelectedValue == "Carrier_Contract_to_Client")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_CarrierContracttoClient(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_Carrier_Contract_to_Client(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }

                        if (ddlcontents.SelectedValue == "Small_Business-Welcome_Kit_Letter")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_Small_Business_Welcome_Kit_Letter(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_Small_Business_Welcome_Kit_Letter(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }

                        if (ddlcontents.SelectedValue == "RenewalAnalysisCoverLetter")
                        {
                            if (PlanTable.Rows.Count > 0)
                            {
                                if (ddlFormat.SelectedValue == "Word")
                                {
                                    mynewfile = CreateLetters_RenewalAnalysisCoverLetter(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                                }
                                else if (ddlFormat.SelectedValue == "Email")
                                {
                                    //NA - Only word format s
                                    return;
                                }
                            }
                            else
                            {
                                if (grdPlans.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select one or more plans.')</script>", false);
                                return;
                            }
                        }
                        if (ddlcontents.SelectedValue == "TerminationLetterfromClienttoCarrier")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_TerminationLetterfromClienttoCarrier(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                CreateReports_BenefitPointEmail_TerminationLetter_Client_to_Carrier(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }

                        if (ddlcontents.SelectedValue == "Client_Logo_Usage_Release")
                        {
                            if (ddlFormat.SelectedValue == "Word")
                            {
                                mynewfile = CreateLetters_ClientLogoUsageRelease(SessionId, PlanTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList);
                            }
                            else if (ddlFormat.SelectedValue == "Email")
                            {
                                // CreateReports_BenefitPointEmail_Carrier_Contract_to_Client(SessionId, PlanTable, ProductDS, BenefitDS, BenefitStructureDS, AccountTeamMemberDS, AccountDS, carrierList, ContactList);
                            }
                        }

                    }
                    if (ddlFormat.SelectedValue == "Word")
                        DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        private bool CheckAccountContactsClientIntakeSelected()
        {
            bool flag = true;
            //Commented by Vaibhav
            //try
            //{
            //    int cnt = 0;
            //    for (int i = 0; i < cblistAccountContact.Items.Count; i++)
            //    {
            //        if (cblistAccountContact.Items[i].Selected == true)
            //        {
            //            cnt++;
            //        }
            //    }

            //    //if (cnt > 2)
            //    //{
            //    //    string script = "alert(\"Please select max 2 Account Contacts.\");";
            //    //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            //    //    flag = false;
            //    //}
            //    // else if (cnt == 0)
            //    if (cnt == 0)
            //    {
            //        string script = "alert(\"Please select Account Contacts.\");";
            //        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            //        flag = false;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    //Response.Write(ex.Message);
            //    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            //    Response.Redirect("~/view/ErrorNotification.aspx");
            //}
            return flag;
        }
        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File in Excel Format.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Create PatraTransmittal Report
        /// </summary>

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;

                // Hash tabe for list of plans to show in the grid view
                Hashtable htSortedPlanList = new Hashtable();
                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                {
                    htSortedPlanList = PatraTransmittal_planList();
                }
                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        flag = false;
                    }
                }

                if (flag == true)
                {
                    grdPlans.DataSource = null;
                    grdPlans.DataBind();

                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        //PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "AdditionalLetter")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            /************************************AS PER REQUIREMENT ******************************
                                              Cat - The following letters are only showing available carriers and plans for Life and Disability plan types. 
                                              They should show all carriers and all plan types
                                            ***************************************************************************/
                                            if (lstCarriersAndAvailableAllPlans.Contains(ddlcontents.SelectedValue.Trim()))
                                            {
                                                commonPlanList.Add(item);
                                            }
                                            else
                                            {
                                                if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                                {
                                                    commonPlanList.Add(item);
                                                }
                                            }
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    if (lstCarriersAndAvailableAllPlans.Contains(ddlcontents.SelectedValue.Trim()))
                                    {
                                        commonPlanList.Add(item);
                                    }
                                    else
                                    {
                                        if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            if (dictLetterCarriersValue[ddlcontents.SelectedValue].ToLower().Equals("yes"))
                            {
                                int CarrierId = 0;
                                int.TryParse(ddlCarriers.SelectedValue, out CarrierId);
                                lstPlanList = (from l in commonPlanList
                                               where l.CarrierId == CarrierId
                                               orderby l.ProductTypeId, l.SummaryName, l.CarrierName ascending
                                               select l).ToList();
                            }
                            else
                            {
                                lstPlanList = (from l in commonPlanList
                                               orderby l.ProductTypeId, l.SummaryName, l.CarrierName ascending
                                               select l).ToList();
                            }
                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {

                                //pnlPlans.Style.Add("display", "");
                                pnlPlans.Visible = true;
                                pnlPlans.Height = 320;
                                ////CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ////ChkBoxHeader.Checked = true;
                                ////foreach (GridViewRow row in grdPlans.Rows)
                                ////{
                                ////    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                ////    ChkBoxRows.Checked = true;
                                ////}

                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                grdPlans.DataSource = null;
                                grdPlans.DataBind();
                                pnlPlans.Height = 50;
                                pnlPlans.Visible = true;
                                //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('No active plans.')</script>");
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                        else
                        {
                            string script = "alert(\"No plans for selected client.\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                    else
                    {
                        string script = "alert(\"No plans for selected client.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void ddlCarriers_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        private Hashtable PatraTransmittal_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            ////htSortedPlanList.Add(1, 100);   // Medical
            ////htSortedPlanList.Add(2, 110);   // Medical
            ////htSortedPlanList.Add(3, 120);   // Medical
            ////htSortedPlanList.Add(4, 140);   // Medical
            ////htSortedPlanList.Add(5, 150);   // Medical
            ////htSortedPlanList.Add(6, 160);   // Medical
            ////htSortedPlanList.Add(7, 170);   // Medical

            ////htSortedPlanList.Add(8, 180);   // Dental
            ////htSortedPlanList.Add(9, 190);   // Dental
            ////htSortedPlanList.Add(10, 200);   // Dental
            ////htSortedPlanList.Add(11, 210);   // Dental

            ////htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            htSortedPlanList.Add(15, 260);   // Voluntary Life
            htSortedPlanList.Add(16, 270);   // AD&D
            htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125


            ////htSortedPlanList.Add(21, 130);   // Medical
            ////htSortedPlanList.Add(22, 310);   // EAP
            ////htSortedPlanList.Add(23, 178);   // HRA
            ////htSortedPlanList.Add(24, 179);   // HSA
            ////htSortedPlanList.Add(25, 235);   //Stop Loss
            ////htSortedPlanList.Add(26, 1108);   //Fees for Service
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }



        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            BindCarriers();
        }

        private DataTable GetPlanInfoTable()
        {

            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();

            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length >= 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{
                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;
                        }
                        else
                        {

                        }
                    }
                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanInfoTable.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.RowIndex == 0)
                    e.Row.Style.Add("width", "8px");
            }
        }

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");


            if (ChkBoxHeader.Checked == true)
            {
                if (dictLetterPlanCount[ddlcontents.SelectedValue] <= 1 && ChkBoxHeader.Checked == true)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select only " + dictLetterPlanCount[ddlcontents.SelectedValue] + " plan from Grid.')</script>", false);
                    ChkBoxHeader.Checked = false;
                    return;
                }
                else
                {
                    foreach (GridViewRow row in grdPlans.Rows)
                    {
                        CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                        ChkBoxRows.Checked = true;
                    }
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                }
            }
            else
            {
                foreach (GridViewRow row in grdPlans.Rows)
                {
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                    ChkBoxRows.Checked = false;
                }
            }

        }



        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                ////Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");


                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");


                //////Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");


                GroupTermLifeBenefitColumnIdList.Add("250");

                // AD&D
                ////ADDBenefitColumnIdList.Add("129");

                //Stop Loss
                StopLossBenefitColumnIdList.Add("235");
                StopLossBenefitColumnIdList.Add("141");

                ////Fees for Service
                FeesForServiceBenefitColumnIdList.Add("1108");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void CreateReports_BenefitPointEmail_BOR(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span style='background-color: #FFFF00'>%3C%3CINSERT CARRER CONTACT NAME%3E%3E:</span></span> <br/>%0D%0A";
                //                lit.Text += " <span style='background-color: #FFFF00'><<INSERT CARRER CONTACT NAME>>:</span></span> <br/>%0D%0A";
                lit.Text += "%0D%0A<p>Enclosed is a letter from <span style='background-color: #00FF00'>" + Account_Contacts + "</span> at <span style='background-color: #00FF00'>" + CompanyName + " </span>naming";
                lit.Text += " USI Insurance Services as broker of record for all of their employee benefit plans effective <span style='background-color: #00FF00'>" + Broker_Of_Record + "</span>.</p>%0D%0A";
                lit.Text += "<p>In order to ensure uninterrupted, quality service to our mutual customer, please furnish the following information:%0D%0A";
                lit.Text += "<ul><li>      &bull;   Copy of the summary plan description</li>%0D%0A";
                lit.Text += "<li>      &bull;   Copy of the group application</li>%0D%0A";
                lit.Text += "<li>      &bull;   Copy of the contract</li>%0D%0A";
                lit.Text += "<li>      &bull;   Copy of the last renewal</li>%0D%0A";
                lit.Text += "<li>      &bull;   Commission agreement</li>%0D%0A";
                lit.Text += "<li>      &bull;   Contact sheet showing member services toll-free number and claim office mailing address</li>%0D%0A";
                lit.Text += "<li>      &bull;   Rate history for the past three years (if applicable)</li>%0D%0A";
                lit.Text += "<li>      &bull;   Schedule A for past plan years (if applicable)</li>%0D%0A";
                lit.Text += "<li>      &bull;   Copy of most recent premium statement</li>%0D%0A";
                lit.Text += "<li>      &bull;   Plan policy numbers </li></ul></p>%0D%0A";
                lit.Text += "%0D%0A<p>Please note that we require a minimum 90-day notification on all renewals. Also, USI Insurance Services should be";
                lit.Text += " copied on all future correspondence pertaining to <span style='background-color: #00FF00'>" + CompanyName + "</span>.</p>%0D%0A";
                lit.Text += "<p>Please notify us immediately if any of these requests cannot be fulfilled. We thank you for your assistance in these";
                lit.Text += " matters and look forward to working with you on this account.</p>%0D%0A";
                lit.Text += "<span>Sincerely,</span><br/>%0D%0A";
                lit.Text += "<span style='background-color: #00FF00'>" + ServiceLead_FirstName + " " + ServiceLead_LastName + "<br/>%0D%0A" + ServiceLead_Role + "<br/>%0D%0A" + ServiceLead_WorkPhone + "</span></div>";

                try
                {
                    string emailAddress = " ";
                    string subject = "Broker of Letter Change for " + CompanyName;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ");", true);
                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "Window.close();", true);

                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.location.href=" + mailto + ";", true);

                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void CreateReports_BenefitPointEmail_LifeDisability_CarrierToClient(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList, string priorCarrierName)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Emails = string.Empty;
                string AccountContact_Emails = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                //  Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                Name = ContactList[i].First_Name;

                                ID = Convert.ToString(ContactList[i].ContactId);
                                Emails = Convert.ToString(ContactList[i].Email);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                {
                                    Account_Contacts += Name;
                                    AccountContact_Emails += Emails;
                                }
                                else
                                {
                                    Account_Contacts += ", " + Name;
                                    AccountContact_Emails += ";" + Emails;
                                }

                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion
                //oWordDoc.Tables[medicalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                //oWordDoc.Tables[medicalTableNo].Cell(1, 2).Range.Text = "Group#: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                //oWordDoc.Tables[medicalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");

                string Plan_Type = Convert.ToString(PlanTable.Rows[0]["Name"]).Replace("&", "&#38;");
                string Prior_Carrier_Name = priorCarrierName;
                string Carrier_Name = Convert.ToString(PlanTable.Rows[0]["Carrier"]).Replace("&", "&#38;");
                string Effective_Date = Convert.ToDateTime(PlanTable.Rows[0]["Effective"].ToString().Trim()).ToString("MMMM d, yyyy");


                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span style='background-color: #FFFF00'>" + Account_Contacts + ":</span></span> <br/>%0D%0A";
                // lit.Text += " <span style='background-color: #FFFF00'>Carrier Contact Name:</span>,</span> <br/>%0D%0A";
                lit.Text += "%0D%0A<p>As part of the decision to change your " + Plan_Type + "</span> benefits from " + Prior_Carrier_Name + " to " + Carrier_Name + "</span>";
                //lit.Text += " effective " + Effective_Date + "</span> is an important contractual feature to be aware of.</p>%0D%0A"; //Shravan Letters Issue #18 5/11/2018
                lit.Text += " effective " + Effective_Date + "</span>, there are important contractual features that may need to be addressed.</p>%0D%0A";

                lit.Text += "<p>You indicated that there were no employees currently disabled. This is crucial because any employees in this category will not have " + Plan_Type;
                lit.Text += " coverage upon termination of your policy with " + Prior_Carrier_Name + " and they will not have any coverage with " + Carrier_Name + ".";


                lit.Text += "%0D%0A<p>You must file a disability waiver of premium claim with " + Prior_Carrier_Name + " on anyone who becomes disabled prior to ";
                lit.Text += "" + Effective_Date + ". The waiver of premium must be filed in a timely manner and no later than 12 months from the date of disability.";
                lit.Text += " Please refer to the " + Prior_Carrier_Name + " booklet, contract, or administrative manual for a more comprehensive explanation.</p>%0D%0A";

                lit.Text += "<p>You must notify employees whose employment ends prior to " + Effective_Date + " and who have";
                lit.Text += " life insurance that they can convert their coverage to an individual policy offered by " + Prior_Carrier_Name + ".";
                lit.Text += " The terminated employees must submit the conversion applications to " + Prior_Carrier_Name + " within the time period required by the contract";
                lit.Text += " following the date of termination. Proof of good health is not required. Please review the contract for the maximum coverage amount and the exact, necessary qualifications for conversion coverage.</p>%0D%0A";

                lit.Text += "<p>If you care to discuss this more fully, please do not hesitate to call me.</p>%0D%0A";

                lit.Text += "%0D%0A<span>Sincerely,</span><br/>%0D%0A";
                lit.Text += "<span style='background-color: #00FF00'>" + ServiceLead_FirstName + " " + ServiceLead_LastName + "<br/>%0D%0A" + ServiceLead_Role + "<br/>%0D%0A" + ServiceLead_WorkPhone + "</span></div>";

                try
                {
                    string emailAddress = AccountContact_Emails;
                    string subject = "Life Disability Carrier Change";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text.Replace("&#38;", "%26"));
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ");", true);
                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "Window.close();", true);

                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.location.href=" + mailto + ";", true);

                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void CreateReports_BenefitPointEmail_LifeDisability_CarrierToCarrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                string PlanType;
                string PolicyNumber;
                string PlanData = "";
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    PlanType = Convert.ToString(PlanTable.Rows[i]["Name"]).Replace("&", "&#38;");
                    PolicyNumber = Convert.ToString(PlanTable.Rows[i]["PolicyNumber"]);

                    if (PolicyNumber.Contains('#'))
                        PolicyNumber = PolicyNumber.Replace("#", "%23");

                    if (i == 0)
                        PlanData += "&nbsp;&nbsp;&nbsp;" + PlanType + ", " + PolicyNumber + "%0D%0A";

                    if (i > 0)
                        PlanData += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + PlanType + ", " + PolicyNumber + "%0D%0A";
                }


                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Emails = string.Empty;
                string AccountContact_Emails = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                Emails = Convert.ToString(ContactList[i].Email);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                {
                                    Account_Contacts += Name;
                                    AccountContact_Emails += Emails;
                                }
                                else
                                {
                                    Account_Contacts += ", " + Name;
                                    AccountContact_Emails += ";" + Emails;
                                }

                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion
                //oWordDoc.Tables[medicalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                //oWordDoc.Tables[medicalTableNo].Cell(1, 2).Range.Text = "Group#: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                //oWordDoc.Tables[medicalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");

                // string Plan_Type = Convert.ToString(PlanTable.Rows[0]["Name"]);
                // string Prior_Carrier_Name = "Prior_Carrier_Name";
                string Carrier_Name = Convert.ToString(PlanTable.Rows[0]["Carrier"]).Replace("&", "&#38;");
                DateTime Effective_Date1 = Convert.ToDateTime(PlanTable.Rows[0]["Renewal"].ToString().Trim()).Date.AddDays(-1);

                string Renewal_Date_minus1 = Effective_Date1.ToString("MMMM d, yyyy"); ;
                string Renewal_Date = Convert.ToDateTime(PlanTable.Rows[0]["Renewal"].ToString().Trim()).ToString("MMMM d, yyyy"); ;


                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span> Dear";
                lit.Text += " <span style='background-color: #FFFF00'>%3C%3CINSERT CARRER CONTACT NAME%3E%3E:</span></span> <br/>%0D%0A%0D%0A";
                //lit.Text += " <span style='background-color: #FFFF00'>" + Account_Contacts + ":</span></span> <br/>%0D%0A";
                lit.Text += " <span>Re:  " + CompanyName + "</span> <br/>%0D%0A";
                lit.Text += " <span>    " + PlanData + "</span> <br/>%0D%0A";

                lit.Text += "%0D%0A<p>After long and careful consideration, we have decided to terminate our above referenced policy(ies) and services with " + Carrier_Name + " effective " + Renewal_Date_minus1 + ".</p>%0D%0A";

                lit.Text += "<p>It is our understanding that " + Carrier_Name + " will be liable for any claims that are incurred prior to " + Renewal_Date + ". In addition, " + Carrier_Name + " will continue to extend coverage to those individuals approved under the Waiver of Premium provision until they are no longer eligible based on the provisions of the waiver. ";


                lit.Text += "%0D%0A<p>We appreciate your past service to our company. If you have any questions or require additional information, please contact me or " + ServiceLead_FirstName + " " + ServiceLead_LastName + " at USI Insurance Services, " + ServiceLead_WorkPhone + ".</p>%0D%0A";


                //lit.Text += "<span>Sincerely,</span><br/>%0D%0A";
                //lit.Text += "<span style='background-color: #00FF00'>" + ServiceLead_FirstName + " " + ServiceLead_LastName + "<br/>%0D%0A" + ServiceLead_Role + "<br/>%0D%0A" + ServiceLead_WorkPhone + "</span></div>";

                try
                {
                    string emailAddress = " ";
                    string subject = "Life Disability Carrier Change";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text.Replace("&#38;", "%26"));
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ");", true);

                    //ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "Window.close();", true);
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.location.href=" + mailto + ";", true);

                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        private void CreateReports_BenefitPointEmail_USITermination_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented by Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}


                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Emails = string.Empty;
                string AccountContact_Emails = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                //Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                Name = ContactList[i].First_Name;

                                ID = Convert.ToString(ContactList[i].ContactId);
                                Emails = Convert.ToString(ContactList[i].Email);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                {
                                    Account_Contacts += Name;
                                    AccountContact_Emails += Emails;
                                }
                                else
                                {
                                    Account_Contacts += ", " + Name;
                                    AccountContact_Emails += ";" + Emails;
                                }

                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                if (string.IsNullOrEmpty(ServiceLead_WorkPhone))
                {
                    ServiceLead_WorkPhone = "%3C%3CService Info / Primary Service Lead / Work Phone%3E%3E";

                }
                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span style='background-color: #FFFF00'>" + Account_Contacts + ":</span></span> <br/>%0D%0A";
                lit.Text += "%0D%0A<p>USI Insurance Services would like to thank " + CompanyName + " for the opportunity to provide employee benefits consulting services. Although we no longer represent your organization, we want to be sure to address any issues or projects that are currently outstanding.</p>%0D%0A";

                lit.Text += "%0D%0A<p>Please note that USI Insurance Services will no longer receive information from your carriers and no further reporting will be completed. </p>";


                lit.Text += "%0D%0A<p>We have enjoyed working with you and hope to have the opportunity to be of service to you in the future. Please contact me at " + ServiceLead_WorkPhone + " should you have any further questions.</p>%0D%0A";


                lit.Text += "<span>%0D%0ASincerely,</span><br/>%0D%0A";
                lit.Text += "<span style='background-color: #00FF00'>" + ServiceLead_FirstName + " " + ServiceLead_LastName + "<br/>%0D%0A" + ServiceLead_Role + "<br/>%0D%0A" + ServiceLead_WorkPhone + "</span></div>";

                try
                {
                    string emailAddress = AccountContact_Emails;
                    string subject = "Termination of services for " + CompanyName;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ");", true);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "Window.close();", true);

                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.location.href=" + mailto + ";", true);

                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }


        protected string CreateLetters_LifeDisabilityCarrierToClient(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList, string priorCarrierName)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Client Template - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Client/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Client")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Client"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented by Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_LifeDisabilityCarrierToClient(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, priorCarrierName, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlCarriers.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                /////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateLetters_LifeDisabilityCarrierToCarrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Carrier Template - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Carrier/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Carrier")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Life Disability Carrier Change to Carrier"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                //if (ddlUSI_City.SelectedIndex > 0)
                //{
                //    string[] office = ddlUSI_City.SelectedValue.Split('~');
                //    string City = Convert.ToString(office[0]).Trim();
                //    string BPOffice = Convert.ToString(office[1]).Trim();
                //    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                //    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                //}

                wt.WriteLetters_LifeDisabilityCarrierToCarrier(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlCarriers.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateLetters_BORToCarrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_BORToCarrier(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateLetters_TerminationLetter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - USITerminationLetter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - USITerminationLetter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - USITerminationLetter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - USITerminationLetter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_USITerminationLetter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateLetters_NewClientThankYouLetter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            string strFileName = string.Empty;

            if (ddlClientContactSheet.SelectedIndex == 0) // Include
            {
                strFileName = "New Client Thank You Letter";
            }
            else if (ddlClientContactSheet.SelectedIndex == 1) // Exclude
            {
                strFileName = "New Client Thank You Letter - Without ContactSheet";
            }

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - " + strFileName + " - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - " + strFileName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - " + strFileName)))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - " + strFileName));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                if (ddlClientContactSheet.SelectedIndex == 0) // Include
                {
                    wt.WriteLetters_NewClientThankYouLetter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress, BRCList, ddlBRCList, grdAccountTeam, dtPlanContact);
                    RunMacro(oWordApp, new Object[] { "CleanContactSheetDocument" });
                }
                else if (ddlClientContactSheet.SelectedIndex == 1) // Exclude
                {
                    wt.WriteLetters_NewClientThankYouLetter_WithoutContactSheet(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);
                }

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlClientContactSheet.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected void CreateReports_BenefitPointEmail_AM_Best_Rating_MidyearDowngrade(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //Commented By Vaibhav
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;
                string PlanInfo_Carrier_VendorName = ddlCarriers.SelectedItem.Text;
                // Added by Vaibhav Acc



                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Email = string.Empty;
                string AccountContactFirstName = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                AccountContactFirstName = ContactList[i].First_Name;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                Email = ContactList[i].Email;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook

                Literal lit = new Literal();
                lit.Text = "Dear " + AccountContactFirstName + ":%0D%0A%0D%0A";
                lit.Text += "Events of the past several years have brought many changes and challenges to the insurance market. These changes in the ";
                lit.Text += "market have affected the ability of all brokers to locate insurance coverage at a scope and cost of insurance placed in prior ";
                lit.Text += "years. In addition, insurance carriers have suffered significant losses that may jeopardize their financial stability.%0D%0A";

                lit.Text += "As a matter of policy, USI endeavors to obtain quotations and indications from insurance companies who meet or exceed the ";
                lit.Text += "USI minimum guidelines for A. M. Best Ratings of companies. Due to the current insurance market conditions, USI has ";
                //lit.Text += "increased its minimum standard for insurers to A-. [A. M. Best’s current rating scale is attached].%0D%0A";
                lit.Text += "increased its minimum standard for insurers to A-." + "http://usi-sp-01/Operations/AM%2520Documents/AM%2520Best%2520Guide.pdf" + " .%0D%0A";

                lit.Text += "It has come to our attention that the " + PlanInfo_Carrier_VendorName + " has recently been downgraded by the A. M. Best ";
                lit.Text += "Company. The new Best rating for the company is [fill in Best’s rating]. %0D%0A";

                lit.Text += "The A. M. Best Company is a recognized publisher of information concerning insurers. It rates companies based on many ";
                lit.Text += "factors, including financial stability. An insurance carrier’s financial condition may affect its ability to properly pay claims. In ";
                lit.Text += "the event of the insolvency of this carrier, there may be reduced coverage available through a state’s Guaranty Association.%0D%0A";

                lit.Text += "If you would prefer to explore possible placement with another carrier, please contact our office immediately. Please be ";
                lit.Text += "advised that another carrier may have more restrictive terms, increased premiums, increased deductibles or other terms not  ";
                lit.Text += "present with your current carrier.";

                lit.Text += "%0D%0A%0D%0AVery truly yours,%0D%0A%0D%0A%0D%0A";
                lit.Text += "" + ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";

                try
                {

                    string subject = "A.M. Best Rating " + CompanyName;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + Email + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        protected void CreateReports_BenefitPointEmail_Authorization_To_Share_PHI(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;
                // Added by Vaibhav Acc

                string AccountName = "";//string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "";
                lit.Text += "Dear [CARRIER CONTACT FIRST NAME],%0D%0A%0D%0A"; // Dear line
                lit.Text += "To document previous instructions, " + CompanyName + " directs you to share Protected Health Information (%22PHI%22) as defined by 45 C.F.R. §160.103 as necessary to support payment and plan operations"; // Line1
                lit.Text += " in accordance with the regulations and administrative guidance of Health Insurance Portability and Accountability Act of 1996, Public Law 104-191 (%22HIPAA%22), including as amended by the Health"; // Line2
                lit.Text += " Information Technology for Economic and Clinical Health Act as set forth in Title XIII of Division A and Title IV of Division B of the American Recovery and Reinvestment Act of 2009"; // Line4
                lit.Text += " (HITECH Act), with the following vendors:%0D%0A%0D%0A"; // Line6
                lit.Text += "              _____________________________________ %0D%0A"; // Line7
                lit.Text += "              _____________________________________ %0D%0A"; // Line8
                lit.Text += "              _____________________________________ %0D%0A"; // Line8
                lit.Text += "              _____________________________________ %0D%0A%0D%0A%0D%0A"; // Line9

                lit.Text += CompanyName + " certifies that it has executed Business Associate Agreements with these vendors. " + AccountName + " will immediately notify USI Insurance Services of any change";
                lit.Text += " to this list of vendors authorized to receive PHI. Failure to timely notify USI Insurance Services of a change to this list will not result in a breach.%0D%0A"; // Line11

                lit.Text += "%0D%0A%0D%0ASincerely,%0D%0A%0D%0A";
                lit.Text += "[ACCOUNT CONTACT]";
                //lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A" + ServiceLead_Role + "%0D%0A";

                //lit.Text += (ServiceLead_WorkPhone.Trim() == string.Empty ? "%3C%3C Service Info %2F Primary Service Work Phone%3E%3E" : ServiceLead_WorkPhone.Trim());

                try
                {
                    string emailAddress = " ";
                    string subject = "Authorization to Share PHI";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        //Developed by Shravans
        protected void CreateReports_BenefitPointEmail_BAA_Cover_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;
                // code added by shravan
                string Account_Contact_Email = string.Empty;    // Update Account contact Email address 
                string Account_First_Name = string.Empty;       // Update Account First Name
                string Account_Contact_WorkPhone = string.Empty;
                string Account_Contact_Title = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);

                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                                //Code added by shravan
                                if (ContactList[i].First_Name != "")
                                    Account_First_Name = ContactList[i].First_Name;
                                if (ContactList[i].Email != "")
                                    Account_Contact_Email = ContactList[i].Email;
                                //if (ContactList[i].Phone[0] != "")
                                //    Account_Contact_WorkPhone = ContactList[i].Phone[0];
                                if (ContactList[i].Title != "")
                                    Account_Contact_Title = ContactList[i].Title;

                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook

                Literal lit = new Literal();
                lit.Text += "Dear " + Account_First_Name + "%3A%0D%0A";      // Account_First_Name 
                lit.Text += "%0D%0A";
                lit.Text += "As you may know, the Health Insurance Portability and Accountability Act of 1996 %28%22HIPAA%22%29, the Health Information Technology for Economics and Clinical Health Act %28%22HITECH%22%29 and their accompanying regulations are designed to protect the privacy and provide for the security of participants%27 Protected Health Information %28%22PHI%22%29. USI Insurance Services is currently providing services on behalf of your %28%22Plan%22%29 which may result in our receiving your participants%27 PHI. In this role, we are considered a Business Associate of your Plan.%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "The Plan as the Covered Entity is responsible for ensuring a Business Associate Agreement %28BAA%29 is in place with its Business Associates. For your convenience, I have included a standard BAA. The BAA is designed to cover both self%2Dfunded and fully%2Dinsured plans that are a part of your organized health care arrangement. Please review it carefully and consult with your legal counsel if necessary.%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Without a BAA in place, sharing of PHI will be limited to your self%2Dfunded Plans and to the individuals holding positions%2Ftitles listed on the attached document. If there are changes to this list, please provide me with the updated information.";
                lit.Text += "%0D%0A";
                lit.Text += "Please return a signed copy of the BAA to me as soon as possible.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Thank you for your business. We look forward to working with you.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0ASincerely,%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";
                lit.Text += ServiceLead_Role + "%0D%0A";
                lit.Text += ServiceLead_WorkPhone + "%0D%0A";
                try
                {
                    string emailAddress = Account_Contact_Email;     //Update the Account_Contact_Email variable
                    string subject = "BAA Cover Letter";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    //  mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed by Shravans
        protected string CreateLetters_BAA_Cover_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BAA Cover Letter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BAA Cover Letter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BAA Cover Letter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BAA Cover Letter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_BAA_Cover_Letter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed by Shravans
        protected void CreateReports_BenefitPointEmail_Renewal_Request_Letter_to_Carrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                // code added by shravan
                DateTime Effective_Date = DateTime.Now;                          //Update Effective Date
                DateTime Renewal_Date = DateTime.Now;                           //Update  Renewal Date
                string CarrierName = string.Empty;                          //Update Carriername
                string Account_Contact_Email = string.Empty;    // Update Account contact Email address 
                string Account_First_Name = string.Empty;       // Update Account First Name
                string Account_Contact_WorkPhone = string.Empty;
                string Account_Contact_Title = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;

                                //Code added by shravan
                                if (ContactList[i].First_Name != "")
                                    Account_First_Name = ContactList[i].First_Name;
                                if (ContactList[i].Email != "")
                                    Account_Contact_Email = ContactList[i].Email;
                                if (ContactList[i].Phone[0] != "")
                                    Account_Contact_WorkPhone = ContactList[i].Phone[0];
                                if (ContactList[i].Title != "")
                                    Account_Contact_Title = ContactList[i].Title;

                            }
                        }

                    }
                }
                //Code Added by shravan
                if (PlanTable != null)
                {
                    for (int i = 0; i < PlanTable.Rows.Count; i++)
                    {
                        Effective_Date = Convert.ToDateTime(PlanTable.Rows[i]["Effective"]);
                        Renewal_Date = Convert.ToDateTime(PlanTable.Rows[i]["Renewal"]);
                        CarrierName = Convert.ToString(PlanTable.Rows[i]["Carrier"]);
                        break;
                    }
                }

                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook
                Literal lit = new Literal();
                lit.Text = "Dear %5BCARRIER CONTACT FIRST NAME%5D,";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Our mutual customer, " + CompanyName + " is scheduled to renew their benefit plan on " + Renewal_Date.ToString("MMMM d, yyyy") + ". We recently completed a pre%2Drenewal strategy session and would appreciate receiving their renewal information no later than %5BDUE DATE%5D. Meeting this target date is imperative to plan effectively and provide ample time to assess and set%2Dup possible benefit plan modifications.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Along with your renewal letter, please include any claims experience, utilization reports, claims projections, and premium rates. In addition, please provide premium adjustments for the following options:";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "       &bull; Insert Options to be quoted here or delete";
                lit.Text += "%0D%0A";
                lit.Text += "       &bull; Insert Options to be quoted here or delete";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Please call me with any questions and to confirm your ability to meet this timeline.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Sincerely, ";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";
                lit.Text += ServiceLead_Role + "%0D%0A";
                lit.Text += ServiceLead_WorkPhone + "%0D%0A";





                try
                {
                    string emailAddress = "";
                    string subject = "Renewal Request for " + CompanyName;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    //mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed By Shravan
        protected string CreateLetters_Authorization_to_Share_PHI(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Authorization to Share PHI Letter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Authorization to Share PHI Letter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Authorization to Share PHI Letter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Authorization to Share PHI Letter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_Authorization_to_Share_PHI(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Develop bY Shravan
        protected string CreateLetters_Carrier_Not_Rated(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Not Rated Letter  - Client Signature Required - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Not Rated Letter  - Client Signature Required/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Not Rated Letter  - Client Signature Required")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Not Rated Letter  - Client Signature Required"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_Carrier_Not_Rated(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        // Developed by Shravans
        protected string CreateLetters_HICA_Cover_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - HICA Cover Letter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - HICA Cover Letter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - HICA Cover Letter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - HICA Cover Letter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_HICA_Cover_Letter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed by SHravan
        protected void CreateReports_BenefitPointEmail_HICA_Cover_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;
                // code added by shravan
                string Account_Contact_Email = string.Empty;    // Update Account contact Email address 
                string Account_First_Name = string.Empty;       // Update Account First Name
                string Account_Contact_WorkPhone = string.Empty;
                string Account_Contact_Title = string.Empty;


                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                                //Code added by shravan
                                if (ContactList[i].First_Name != "")
                                    Account_First_Name = ContactList[i].First_Name;
                                if (ContactList[i].Email != "")
                                    Account_Contact_Email = ContactList[i].Email;
                                if (ContactList[i].Phone[0] != "")
                                    Account_Contact_WorkPhone = ContactList[i].Phone[0];
                                if (ContactList[i].Title != "")
                                    Account_Contact_Title = ContactList[i].Title;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook

                Literal lit = new Literal();
                lit.Text += "Dear " + Account_First_Name + "%3A%0D%0A";      // Account_First_Name 
                lit.Text += "%0D%0A";
                lit.Text += "The Health Insurance Portability and Accountability Act of 1996 %28%22HIPAA%22%29, the Health Information Technology for ";
                lit.Text += "Economics and Clinical Health Act %28%22HITECH%22%29 and their accompanying regulations are designed to protect the ";
                lit.Text += "privacy and provide for the security of participants%27 Protected Health Information %28%22PHI%22%29. USI Insurance Services is ";
                lit.Text += "currently providing services related to your fully-insured group health plan %28%22Plan%22%29 which may result in our ";
                lit.Text += "receiving your participants%27 PHI. In this role, we are a Business Associate of your Plan.%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "The HIPAA privacy rules impose specific conditions on the ability of a group health plan %28or its Business Associates%29 to share PHI with the plan sponsor %28i.e. the employer%29. In particular, to be %22hands on%22 with respect to PHI, a plan sponsor must satisfy certain plan amendment, certification, and firewall requirements.  Even then, PHI may only be shared with a plan sponsor for certain plan administration functions.";
                lit.Text += "%0D%0A";
                lit.Text += "If you want us, in our capacity as a Business Associate of your Plan, to share PHI with you, please execute and return the enclosed Health Information Confidentiality Agreement %28%22Confidentiality Agreement%22%29. The Confidentiality Agreement provides us with assurance that you understand the HIPAA privacy requirements that must be satisfied before we can share PHI with you.";
                lit.Text += "%0D%0A";
                lit.Text += "If you intend to be %22hands off%22 with respect to PHI, with you and a Confidentiality Agreement is not needed. If this is the case, please let me know and I will update your file to reflect your preference.";
                lit.Text += "%0D%0A";
                lit.Text += "Before signing the Confidentiality Agreement, please review it carefully and consult with your legal counsel if necessary.";
                lit.Text += "%0D%0A";
                lit.Text += "Thank you for your business. We look forward to working with you.";
                lit.Text += "%0D%0A";
                //lit.Text = "Economics and Clinical Health Act (%22HITECH%22) and  their accompanying regulations are designed the privacy and provide for the security of participants Protected Health Information %28%22PHI%22%29. USI Insurance Services is currently providing services related to your fully-insured group health plan (%22Plan%22) which may result in our receiving your participants’ PHI. In this role, we are a Business Associate of your Plan.%0D%0A%0D%0AThe HIPAA privacy rules impose specific conditions on the ability of a group health plan (or its Business Associates) to share PHI with the plan sponsor (i.e. the employer). In particular, to be “hands on” with respect to PHI, a plan sponsor must satisfy certain plan amendment, certification, and firewall requirements.  Even then, PHI may only be shared with a plan sponsor for certain plan administration functions.%0D%0AIf you want us, in our capacity as a Business Associate of your Plan, to share PHI with you, please execute and return the enclosed Health Information Confidentiality Agreement (%22Confidentiality Agreement%22).The Confidentiality Agreement provides us with assurance that you understand the HIPAA privacy requirements that must be satisfied before we can share PHI with you%0D%0Aif you intended to be to %22hands of%22 then we will not share PHI with you and a Confidentiality Agreement is not needed If this is the case, please let me know and I will update your file to reflect your preference%0D%0ASincerely,%0D%0ACristin Steding%0D%0AReception/Office Administration%0D%0A%0D%0A";
                lit.Text += "%0D%0ASincerely,%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";
                lit.Text += ServiceLead_Role + "%0D%0A";
                lit.Text += ServiceLead_WorkPhone + "%0D%0A";
                try
                {
                    string emailAddress = Account_Contact_Email;
                    string subject = "HICA";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    //  mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed by Shravan
        protected string CreateLetters_Marketing_Declination_Letter_To_Carrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Marketing Declination Letter to Carrier - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Marketing Declination Letter to Carrier/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Marketing Declination Letter to Carrier")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Marketing Declination Letter to Carrier"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_Marketing_Declination_Letter_To_Carrier(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed By Shravan
        protected void CreateReports_BenefitPointEmail_Marketing_Declination_Letter_To_Carrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                // code added by shravan
                string Account_Contact_Email = string.Empty;    // Update Account contact Email address 
                string Account_First_Name = string.Empty;       // Update Account First Name
                string Account_Contact_WorkPhone = string.Empty;
                string Account_Contact_Title = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();   //Client_Name

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;

                                //Code added by shravan
                                if (ContactList[i].First_Name != "")
                                    Account_First_Name = ContactList[i].First_Name;
                                if (ContactList[i].Email != "")
                                    Account_Contact_Email = ContactList[i].Email;
                                if (ContactList[i].Phone[0] != "")
                                    Account_Contact_WorkPhone = ContactList[i].Phone[0];
                                if (ContactList[i].Title != "")
                                    Account_Contact_Title = ContactList[i].Title;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook

                Literal lit = new Literal();
                lit.Text = "Dear %5BCARRIER CONTACT FIRST NAME%5D,";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Thank you very much for your response to our proposal request.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "We have carefully reviewed the information in your proposal and evaluated it along with the current carrier%28s%29 and the marketplace. " + CompanyName + " has decided not to contract with %5BCARRIER NAME%5D at this time.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "We appreciate your time and effort and look forward to working with you in the near future.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Sincerely, ";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";

                //lit.Text += Name + "%0D%0A";
                //lit.Text += Account_Contact_Title + "%0D%0A";
                //lit.Text += Account_Contact_WorkPhone + "%0D%0A";
                //FEEDBACK 1: New Deliverables Request - Letters Criteria Page Changes and Additional Letters  by  shravan 28th may, 2018
                lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";
                lit.Text += ServiceLead_Role + "%0D%0A";
                lit.Text += ServiceLead_WorkPhone + "%0D%0A";


                try
                {
                    string emailAddress = "";
                    string subject = "Market Survey Analysis for " + CompanyName;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    //  mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed By Shravan
        protected void CreateReports_BenefitPointEmail_Carrier_Contract_to_Client(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {

                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;


                // code added by shravan
                string Account_Contact_Email = string.Empty;    // Update Account contact Email address 
                string Account_First_Name = string.Empty;       // Update Account First Name
                string Account_Contact_WorkPhone = string.Empty;
                string Account_Contact_Title = string.Empty;

                DateTime Effective_Date = DateTime.Now;                          //Update Effective Date
                DateTime Renewal_Date = DateTime.Now;                           //Update  Renewal Date
                string CarrierName = string.Empty;                          //Update Carriername

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();   //Client_Name

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                                //Code added by shravan
                                if (ContactList[i].First_Name != "")
                                    Account_First_Name = ContactList[i].First_Name;
                                if (ContactList[i].Email != "")
                                    Account_Contact_Email = ContactList[i].Email;
                                if (ContactList[i].Phone[0] != "")
                                    Account_Contact_WorkPhone = ContactList[i].Phone[0];
                                if (ContactList[i].Title != "")
                                    Account_Contact_Title = ContactList[i].Title;

                            }
                        }

                    }
                }
                if (PlanTable != null)
                {
                    for (int i = 0; i < PlanTable.Rows.Count; i++)
                    {
                        Effective_Date = Convert.ToDateTime(PlanTable.Rows[i]["Effective"]);
                        Renewal_Date = Convert.ToDateTime(PlanTable.Rows[i]["Renewal"]);
                        CarrierName = Convert.ToString(PlanTable.Rows[i]["Carrier"]);
                        break;
                    }
                }

                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook


                Literal lit = new Literal();
                lit.Text = "Dear " + Account_First_Name + ":";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "Enclosed please find the " + CarrierName + " contract for the plan year " + Effective_Date.ToString("MMMM d, yyyy") + " - " + Renewal_Date.ToString("MMMM d, yyyy") + ".  This is the final version and is consistent with negotiations with respect to terms, conditions and benefit levels. ";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "After your review, please sign the contract. Please review the information immediately. We recommend you pay special attention to the eligibility and leave of absence sections to make sure they match your current administration of the plan. Since USI Insurance Services is not authorized to practice law you may wish to have your attorney review. If you have any questions, or find any discrepancies, please contact me immediately. Once your review is complete, please sign the enclosed contract.";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0ASincerely,%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += "%0D%0A";
                lit.Text += ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A";
                lit.Text += ServiceLead_Role + "%0D%0A";
                lit.Text += ServiceLead_WorkPhone + "%0D%0A";


                try
                {
                    string emailAddress = Account_Contact_Email;             //Update Account Contact Email
                    string subject = CarrierName + " Contract Review";     //Update Carrier Name
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    //  mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed By SHravan
        protected string CreateLetters_Small_Business_Welcome_Kit_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            // Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - BOR Letter to Carrier Template - Word.docm");

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Small Business - Welcome Kit Letter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Small Business - Welcome Kit Letter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Small Business - Welcome Kit Letter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Small Business - Welcome Kit Letter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_Small_Business_Welcome_Kit_Letter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed by Vinod
        protected string CreateLetters_AMBestRatingClientLetter_InitialCoveragePlacement(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Initial Coverage Placement - Word.docm");

            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Initial Coverage Placement/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Initial Coverage Placement")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Initial Coverage Placement"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_BestRatingClientLetter_InitialCoveragePlacement(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlAccountContacts.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Develop by Vinod
        protected string CreateLetters_RenewalAnalysisCoverLetter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Analysis Cover Letter - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Analysis Cover Letter/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Analysis Cover Letter")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Analysis Cover Letter"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_RenewalAnalysisCoverLetter(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                /////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed By Vinod
        protected string CreateLetters_TerminationLetterfromClienttoCarrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Termination Letter from Client to Carrier - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Termination Letter from Client to Carrier/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Termination Letter from Client to Carrier")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Termination Letter from Client to Carrier"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_TerminationLettefromClienttoCarrier(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        // Developed By Vinod
        protected string CreateLetters_AMBestRatingClientLetter_MidyearDowngrade(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Midyear Downgrade - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Midyear Downgrade/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Midyear Downgrade")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - AM Best Rating Client Letter - Midyear Downgrade"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                string PlanInfo_Carrier = ddlCarriers.SelectedItem.Text;

                wt.WriteLetters_AMBestRatingClientLetter_MidyearDowngrade(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress, PlanInfo_Carrier);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlCarriers.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlAccountContacts.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed By Vinod
        protected string CreateLetters_CarrierContracttoClient(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Contract to Client - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Contract to Client/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Contract to Client")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Carrier Contract to Client"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_CarrierContracttoClient(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Developed By Vinods
        protected string CreateLetters_RenewalRequestLettertoCarrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Request Letter to Carrier - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Request Letter to Carrier/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Request Letter to Carrier")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Renewal Request Letter to Carrier"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_RenewalRequestLettertoCarrier(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }
        //Develop By Vinod
        protected void CreateReports_BenefitPointEmail_Small_Business_Welcome_Kit_Letter(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;

                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();

                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Email = string.Empty;

                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name;
                                Email = ContactList[i].Email;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                #region for Email body for Outlook
                Literal lit = new Literal();
                //  lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span>" + Account_Contacts + "</span>:</span>%0D%0A";
                lit.Text += "%0D%0A<p>Once again, welcome to USI Insurance Services. As your dedicated Account Executive, I am here to help with";
                lit.Text += "strategic planning, renewal negotiation, and employee communication. I look forward to building our relationship";
                lit.Text += " and working together.</p>%0D%0A";

                lit.Text += "<p>I am pleased to share the enclosed Employee Benefits Welcome Kit, designed to provide you with key information,";
                lit.Text += "including:</p>%0D%0A";


                lit.Text += "<p><ul><li>&bull;   <span style='font-weight:bold'>Your Member Services Advocate and Benefit HelpLine cards.</span>Employees can each receive a Benefit";//&#8226; //&#x2022; //& #8226
                lit.Text += " HelpLine card for their Member Services Advocate,[insert Member Services Advocate], whom they may"; //9679  //25CF
                lit.Text += " call for help with claims issues, network questions, requests for I.D. cards, qualifying event changes, or"; // &#183;
                lit.Text += " other benefits-related questions. They can also assist you and your staff with a variety of daily"; //U+02022  //&#x2022; //&#8226; //\2022
                lit.Text += " administration needs from adding or removing employees to helping with billing issues or questions on ";
                lit.Text += " documents or completing paperwork.</li></p>%0D%0A";

                lit.Text += "<li>&bull;   <span style='font-weight:bold'>An overview of available employee benefits value-added services.</span>As a large national broker, we deliver";
                lit.Text += " the resources,depth of talent,and market clout that you would expect,combined with personal service";
                lit.Text += " designed to meet your needs.I will schedule a call to review these services and determine which services";
                lit.Text += " you would like to implement. </li></ul>%0D%0A";

                lit.Text += "As members of your team, we are here to help with your employee benefits administration so you can focus on";
                lit.Text += "running your business. Please do not hesitate to contact me for your long-term planning needs, renewal questions,";
                lit.Text += "or benefits compliance concerns.%0D%0A";
                lit.Text += "%0D%0AThank you for your business. We look forward to working with you.%0D%0A";
                lit.Text += "%0D%0ASincerely,%0D%0A";
                lit.Text += "" + ServiceLead_FirstName + " " + ServiceLead_LastName + "%0D%0A" + ServiceLead_Role + "%0D%0A" + ServiceLead_WorkPhone;


                try
                {
                    string emailAddress = Email;
                    string subject = "Employee Benefits Welcome Kit";
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion

                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        //Developed By Vinod
        protected void CreateReports_BenefitPointEmail_TerminationLetter_Client_to_Carrier(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Carrier> carrierList, List<Contact> ContactList)
        {

            try
            {
                SessionId = Session["SessionId"].ToString();


                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}

                #region mail send


                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_Role = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;
                string CompanyName = string.Empty;
                string Broker_Of_Record = string.Empty;
                string frenewalDate = string.Empty;
                string FirstrenewalDate = string.Empty;
                string FirstrenewalDateMinus = string.Empty;
                string ClientName = string.Empty;



                string Account_Contacts = string.Empty;
                DateTime dateValue = new DateTime();

                #region added for mail body section
                string Carrier_Name = string.Empty;
                DateTime Renewal_Date = Convert.ToDateTime(System.DateTime.Now);  // please note Renewal Date is : <<Renewal Date>> minus one day.
                string Client_Name = string.Empty;
                #endregion

                CompanyName = ddlClient.SelectedItem.Text.ToString().Trim();
                Client_Name = ddlClient.SelectedItem.Text.ToString().Trim();

                #region

                foreach (DataRow dr in PlanTable.Rows)
                {
                    //fEffectiveDate = Convert.ToString(dr["Effective"]);
                    //FirstPlaneffectiveDate = Convert.ToString(Convert.ToDateTime(fEffectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(fEffectiveDate.ToString()).Year.ToString());

                    frenewalDate = Convert.ToString(dr["Renewal"]);
                    FirstrenewalDate = Convert.ToString(Convert.ToDateTime(frenewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(frenewalDate.ToString()).Year.ToString());
                    FirstrenewalDateMinus = Convert.ToString(Convert.ToDateTime(FirstrenewalDate.ToString()).AddDays(-1).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(FirstrenewalDate.ToString()).Year.ToString());

                    break;
                }


                #endregion




                #region Account ContactList
                string ID = string.Empty;
                string Name = string.Empty;
                string Title = string.Empty;
                if (ContactList != null)
                {
                    int count = 0;
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (ContactList[i].ContactId.ToString() == Convert.ToString(arrAcctContact[j]))
                            {
                                count++;
                                Name = ContactList[i].First_Name + " " + ContactList[i].Last_Name;
                                Title = ContactList[i].Title;
                                ID = Convert.ToString(ContactList[i].ContactId);
                                //dtNewAcctContactList.Rows.Add(Name, ID);
                                if (count == 1)
                                    Account_Contacts += Name;
                                else
                                    Account_Contacts += ", " + Name;
                            }
                        }

                    }
                }
                #endregion
                foreach (DataRow dr in PlanTable.Rows)
                {
                    //planDetails.Append(planType + ", " + policyNo + "\n");
                    Carrier_Name = Convert.ToString(dr["Carrier"]).Replace("&amp;", "&");
                    //.Replace("&", "&#38;")
                }


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                    ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                    ServiceLead_Role = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["role"]);
                                    ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                }


                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                    {
                                        Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                    }
                                }

                            }
                        }
                    }
                }
                #endregion

                //Added by Amogh to replace & 
                Carrier_Name = Carrier_Name.Replace("&", "%26");  
 
                #region for Email body for Outlook
                Literal lit = new Literal();

                lit.Text = "<div style='font-size:10pt; font-family:calibri;'>";
                lit.Text += "<span>Dear";
                lit.Text += " <span style='background-color: #FFFF00'>[CARRIER CONTACT FIRST NAME]</span>,</span> <br/>%0D%0A";
                lit.Text += "%0D%0A<p>After long and careful consideration, we have decided to terminate our above referenced policy(ies) and services</p>";
                lit.Text += " with " + Carrier_Name + " effective " + FirstrenewalDateMinus + ".</p>%0D%0A";
                lit.Text += "%0D%0A<p>We appreciate your past service to our company. If you have any questions or require additional information,";
                lit.Text += " please contact me or " + ServiceLead_FirstName + " " + ServiceLead_LastName + " at USI Insurance Services, " + ServiceLead_WorkPhone + ".</p>%0D%0A";
                lit.Text += "%0D%0A<span>Sincerely,</span>%0D%0A";
                lit.Text += "%0D%0A<span style='background-color: #00FF00'>";
                lit.Text += "[ACCOUNT CONTACT]";
                lit.Text += "</span>";

                try
                {
                    string emailAddress = " ";
                    //string subject = Client_Name; // <<Account Summary / Client Name>>
                    string subject = Client_Name;
                    string mailbody = HttpUtility.HtmlDecode(lit.Text);
                    mailbody = WebUtility.HtmlDecode(Regex.Replace(mailbody, "<[^>]*(>|$)", string.Empty));
                    string mailto = "'mailto:" + emailAddress + "?Subject=" + subject + "&body=" + mailbody + "'";
                    ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + mailto + ",'_self');", true);


                    ////string lStrMailto = string.Format("mailto:{0}?Subject={1}&Body={2}", emailAddress, subject, mailbody);
                    ////System.Diagnostics.Process.Start(lStrMailto);
                    ////ClientScript.RegisterStartupScript(this.GetType(), "FormLoading", "window.open(" + lStrMailto + ",'email');", true);
                }
                catch (System.Net.Mail.SmtpException) {/*errors can happen*/ }


                #endregion
                #endregion

                string AdditionalCrtieriaOption_1 = ddlcontents.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_City.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlFormat.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {


                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        //added by shravan
        protected string CreateLetters_ClientLogoUsageRelease(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Client Logo Usage Release - Word.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Client Logo Usage Release - Word/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Client Logo Usage Release - Word")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Letters - Client Logo Usage Release - Word"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteLetters wt = new WriteLetters();

                ArrayList arrAcctContact = new ArrayList();
                arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                //{
                //    if (cblistAccountContact.Items[i].Selected == true)
                //    {
                //        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                //    }
                //}
                if (ddlUSI_City.SelectedIndex > 0)
                {
                    string[] office = ddlUSI_City.SelectedValue.Split('~');
                    string City = Convert.ToString(office[0]).Trim();
                    string BPOffice = Convert.ToString(office[1]).Trim();
                    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                }

                wt.WriteLetters_ClientLogoUsageRelease(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, dtOfficeAddress);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlFormat.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlAccountContacts.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlUSI_State.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlUSI_City.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }


        //private DataTable GetPlanInfoTable_ForAdditionalLetters()
        //{
        //    DataTable PlanInfoTable = new DataTable();
        //    PlanInfoTable = CreatePlanInfoTable();


        //    DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
        //    objCommFun.LoadPlanTypeIds();


        //    try
        //    {
        //        int rowCount = 0;
        //        CheckBox chkItemSelect = new CheckBox();

        //        if (grdPlans != null)
        //        {
        //            foreach (GridViewRow grRow in grdPlansAdditional.Rows)
        //            {
        //                chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

        //                if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
        //                {
        //                    PlanInfoTable.Rows.Add();
        //                    // For Name
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Name"] = " ";
        //                    }

        //                    // For Carrier Name
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
        //                    }

        //                    // For Effective date
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Effective"] = " ";
        //                    }

        //                    // For Renewal Date
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
        //                    }

        //                    // For Policy number
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
        //                    }

        //                    // For ProductID
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
        //                    }

        //                    // For ProductName
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
        //                    }

        //                    if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
        //                    {
        //                        if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
        //                        {
        //                            PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
        //                        }
        //                        else
        //                        {
        //                            PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
        //                        }
        //                    }

        //                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
        //                    }
        //                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
        //                    }
        //                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
        //                    }
        //                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
        //                    }
        //                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
        //                    }

        //                    if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
        //                    }

        //                    if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
        //                    }

        //                    if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
        //                    }

        //                    if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
        //                    }
        //                    if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
        //                    }

        //                    if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
        //                    }

        //                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
        //                    }

        //                    if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
        //                    }

        //                    if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
        //                    }


        //                    rowCount++;
        //                }
        //                else
        //                {

        //                }

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //    return PlanInfoTable;
        //}

        private DataTable GetPlanInfoTable_ForAdditionalLetters()
        {
            //DataTable PlanInfoTable = new DataTable();
            AdditionalInfoTable = CreatePlanInfoTable();


            //DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            //objCommFun.LoadPlanTypeIds();


            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlansAdditional.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            AdditionalInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                AdditionalInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[7].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                                {
                                    AdditionalInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[7].Text);
                                }
                                else
                                {
                                    AdditionalInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                AdditionalInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }


                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return AdditionalInfoTable;
        }

        protected DataTable CreateContactTable()
        {
            try
            {
                dtPlanContact.Columns.Add("ProductId", typeof(string));
                dtPlanContact.Columns.Add("ContactId", typeof(string));
                dtPlanContact.Columns.Add("ContactName", typeof(string));
                dtPlanContact.Columns.Add("ContactEmail", typeof(string));
                dtPlanContact.Columns.Add("ContactWorkPhone", typeof(string));
                dtPlanContact.Columns.Add("Contact_FirstName", typeof(string));
                dtPlanContact.Columns.Add("Contact_LastName", typeof(string));
                dtPlanContact.Columns.Add("Contact_Address", typeof(string));
                dtPlanContact.Columns.Add("CarrierName", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return dtPlanContact;
        }

        protected void rdlCarrierPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCarriers();
        }


    }
}