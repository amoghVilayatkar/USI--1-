﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using System.Text;

namespace BenefitPointSummaryPortal.BAL.ClientServiceUtility
{
    /// <summary>
    /// BenefitPoint Service Version 2
    /// </summary>
    public class Wf_BPBrokerConnectV2 : ClientServiveFactory
    {
        public Wf_BPBrokerConnectV2()
        {
            BuildAccountTable();
        }
        #region properties
        //account
        DataTable account_table = new DataTable();
        DataTable accountCustomFieldValues_table = new DataTable();
        DataTable accountEmployeeTypesValues_table = new DataTable();
        DataTable account_Team_memeber = new DataTable();
        #endregion
        public override List<Account> FindAccounts(int Selectedindex, string SessionId, string txtsearch)
        {

            List<Account> AccountList = new List<Account>();
            try
            {


                wf_benefitpoint_V4.Account new_account = new wf_benefitpoint_V4.Account();

                wf_benefitpoint_V4.BrokerConnectV4 new_connection = new wf_benefitpoint_V4.BrokerConnectV4();

                wf_benefitpoint_V4.AccountSearchCriteria new_account_search = new wf_benefitpoint_V4.AccountSearchCriteria();

                wf_benefitpoint_V4.AccountSummary[] new_account_summary = new wf_benefitpoint_V4.AccountSummary[0];

                wf_benefitpoint_V4.AccountClassificationType[] Search_Type = new wf_benefitpoint_V4.AccountClassificationType[1];

                Search_Type[0] = wf_benefitpoint_V4.AccountClassificationType.Group;

                new_account_search.accountClassifications = Search_Type;
                new_account_search.accountNameMatch = txtsearch;
                wf_benefitpoint_V4.SessionIdHeader SIH = new wf_benefitpoint_V4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;

                new_account_summary = new_connection.findAccounts(new_account_search);
                int i = 0;
                if (new_account_summary != null)
                {
                    foreach (wf_benefitpoint_V4.AccountSummary item in new_account_summary)
                    {
                        Account acc = new Account();

                        acc.AccountId = item.accountID;
                        acc.AccountName = item.accountName.ToString();

                        if (Selectedindex == 0)
                        {
                            if (item.active == true)
                            {
                                AccountList.Add(acc);
                            }

                        }
                        else if (Selectedindex == 1)
                        {
                            if (item.active == false)
                            {
                                AccountList.Add(acc);
                            }

                        }
                        else if (Selectedindex == 2)
                        {

                            AccountList.Add(acc);


                        }
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return AccountList;
        }
        /// <summary>
        /// Get HR  contact Data
        /// </summary>
        /// <param name="Selectedindex">To find contact information of  selected HR. </param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Contact data</returns>
        public override List<Contact> FindContacts(string Selectedindex, string SessionId, string reportname = "")
        {

            List<Contact> ContactList = new List<Contact>();
            try
            {

                wf_benefitpoint_V4.AccountContact new_accountcontact = new wf_benefitpoint_V4.AccountContact();

                wf_benefitpoint_V4.BrokerConnectV4 new_connection = new wf_benefitpoint_V4.BrokerConnectV4();

                wf_benefitpoint_V4.AccountContactSearchCriteria new_accountcontact_search = new wf_benefitpoint_V4.AccountContactSearchCriteria();

                wf_benefitpoint_V4.AccountContact[] new_account_contact = new wf_benefitpoint_V4.AccountContact[0];



                new_accountcontact_search.accountID = Selectedindex.ToString();

                wf_benefitpoint_V4.SessionIdHeader SIH = new wf_benefitpoint_V4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;
                string strState = "";
                string strCountry = "";
                string strZip = "";

                new_account_contact = new_connection.findAccountContacts(new_accountcontact_search);

                if (new_account_contact != null)
                {
                    foreach (wf_benefitpoint_V4.AccountContact item in new_account_contact)
                    {

                        Contact c = new Contact();
                        c.ContactId = item.contact.contactID;
                        c.Name = item.contact.firstName + " " + item.contact.lastName;
                        c.First_Name = item.contact.firstName;
                        c.Last_Name = item.contact.lastName;
                        c.Title = item.title;
                        c.Email = item.contact.email;
                        c.PrimaryFlag = item.primary;

                        if (item.responsibilities != null)
                        {
                            c.Responsibility = item.responsibilities[0].ToString();
                        }

                        StringBuilder sb = new StringBuilder();

                        if (item.contact.address.street1 != null)
                        {
                            if (item.contact.address.street1.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.street1);
                                if (item.contact.address.street2 != null)
                                {
                                    sb.Append(", ");
                                }
                            }
                        }

                        //if (item.contact.address.street2 != null)
                        //{
                        if (item.contact.address.street1 != null || item.contact.address.street2 != null)
                        {
                            if (item.contact.address.street2 != null && item.contact.address.street2.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.street2);
                            }
                            sb.Append("\n");
                        }
                        //}

                        if (item.contact.address.city != null)
                        {
                            if (item.contact.address.city.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.city);
                                sb.Append(", ");
                            }
                        }

                        if (item.contact.address.state != null)
                        {
                            if (item.contact.address.state.ToString() != "None_Selected")
                            {
                                strState = item.contact.address.state.ToString();
                            }
                        }
                        if (item.contact.address.country != null)
                        {
                            if (reportname == "Enrollment Summary")
                            {
                                strCountry = "";
                            }
                            else
                            {
                                if (item.contact.address.country.ToString() != "None_Selected")
                                {
                                    strCountry = item.contact.address.country.ToString();
                                }
                            }
                        }
                        if (item.contact.address.zip != null)
                        {
                            if (item.contact.address.zip.ToString() != "None_Selected")
                            {
                                strZip = item.contact.address.zip.ToString();
                            }
                        }
                        //sb.Append(item.contact.address.state + " " + item.contact.address.country.ToString().Replace("_", " ") + " " + item.contact.address.zip);
                        if (string.IsNullOrEmpty(strState))
                        {
                            if (!string.IsNullOrEmpty(strCountry))
                            {
                                sb.Append(strCountry.ToString().Replace("_", " ") + " " + strZip);
                            }
                            else
                            {
                                sb.Append(strZip);
                            }
                        }
                        else if (string.IsNullOrEmpty(strState) && string.IsNullOrEmpty(strCountry))
                        {
                            sb.Append(strZip);
                        }
                        else
                        {
                            sb.Append(strState + " " + strCountry.ToString().Replace("_", " ") + " " + strZip);
                        }

                        if (sb != null)
                        {
                            c.Address = sb.ToString();
                        }
                        List<string> phoneList = new List<string>();
                        if (item.contact.phones != null)
                        {
                            foreach (wf_benefitpoint_V4.Phone phone in item.contact.phones)
                            {
                                if (phone.type == wf_benefitpoint_V4.PhoneType.Work)
                                {
                                    if (phone.number != null && phone.areaCode != null)
                                    {
                                        phoneList.Add(phone.areaCode + "-" + phone.number);
                                    }
                                }
                            }
                        }
                        c.Phone = phoneList;
                        c.Postion = " ";

                        if (c.Postion == " " || string.IsNullOrEmpty(c.Postion))
                        {
                            c.Address.Trim();
                        }
                        ContactList.Add(c);

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return ContactList;
        }
        /// <summary>
        /// Get Account Information 
        /// </summary>
        /// <param name="account_id">AccountID</param>
        /// <param name="SessionId">SessionId</param>
        /// <returns></returns>
        public override DataSet GetAccountDetail(int account_id, string SessionId)
        {



            wf_benefitpoint_V4.BrokerConnectV4 new_connection = new wf_benefitpoint_V4.BrokerConnectV4();

            wf_benefitpoint_V4.SessionIdHeader SIH = new wf_benefitpoint_V4.SessionIdHeader();

            wf_benefitpoint_V4.Account new_account = new wf_benefitpoint_V4.Account();

            DataSet AccountDS = new DataSet();
            int account_row_counter = 0;
            int accountCustomFieldValues_row_counter = 0;

            // wf_benefitpoint_V4.Contact cn = new wf_benefitpoint_V4.Contact();
            //new_connection.getplanc


            try
            {

                SIH.sessionId = SessionId;//myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);
                string website = string.Empty;


                if (new_account != null)
                {
                    #region account_table
                    website = new_account.groupAccountInfo.commonGroupAccountInfo.website;
                    account_table.Rows.Add();
                    account_table.Rows[account_row_counter][0] = new_account.accountID;
                    if (new_account.active != null && new_account.active.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][1] = new_account.active.ToString();
                    if (new_account.inactiveAsOf != null && new_account.inactiveAsOf.Year != 1) account_table.Rows[account_row_counter][2] = new_account.inactiveAsOf;
                    if (new_account.inactiveReason != null) account_table.Rows[account_row_counter][3] = new_account.inactiveReason.ToString();
                    if (new_account.accountClassification != null) account_table.Rows[account_row_counter][4] = new_account.accountClassification.ToString();
                    if (new_account.accountType != null) account_table.Rows[account_row_counter][5] = new_account.accountType.ToString();
                    if (new_account.officeID != null) account_table.Rows[account_row_counter][6] = new_account.officeID.ToString();
                    if (new_account.departmentID != null) account_table.Rows[account_row_counter][7] = new_account.departmentID.ToString();
                    if (new_account.administratorUserID != null) account_table.Rows[account_row_counter][8] = new_account.administratorUserID.ToString();
                    if (new_account.primaryContactUserID != null) account_table.Rows[account_row_counter][9] = new_account.primaryContactUserID.ToString();
                    if (new_account.primarySalesLeadUserID != null) account_table.Rows[account_row_counter][10] = new_account.primarySalesLeadUserID.ToString();
                    if (new_account.primaryServiceLeadUserID != null) account_table.Rows[account_row_counter][11] = new_account.primaryServiceLeadUserID.ToString();
                    if (new_account.notes != null) account_table.Rows[account_row_counter][12] = new_account.notes.ToString();
                    if (new_account.lastReviewedByUserID != null) account_table.Rows[account_row_counter][13] = new_account.lastReviewedByUserID.ToString();
                    if (new_account.lastReviewedOn != null && new_account.lastReviewedOn.Year != 1) account_table.Rows[account_row_counter][14] = new_account.lastReviewedOn.ToString();
                    if (new_account.createdOn != null && new_account.createdOn.Year != 1) account_table.Rows[account_row_counter][15] = new_account.createdOn.ToString();
                    if (new_account.lastModifiedOn != null && new_account.lastModifiedOn.Year != 1) account_table.Rows[account_row_counter][16] = new_account.lastModifiedOn.ToString();



                    if (new_account.mainAddress != null)
                    {
                        if (new_account.mainAddress.street1 != null) account_table.Rows[account_row_counter][18] = new_account.mainAddress.street1.ToString();
                        if (new_account.mainAddress.street2 != null) account_table.Rows[account_row_counter][19] = new_account.mainAddress.street2.ToString();
                        if (new_account.mainAddress.city != null) account_table.Rows[account_row_counter][20] = new_account.mainAddress.city.ToString();
                        if (new_account.mainAddress.state != null) account_table.Rows[account_row_counter][21] = new_account.mainAddress.state.ToString();
                        if (new_account.mainAddress.zip != null) account_table.Rows[account_row_counter][22] = new_account.mainAddress.zip.ToString();
                        if (new_account.mainAddress.country != null) account_table.Rows[account_row_counter][23] = new_account.mainAddress.country.ToString().Replace("_", " ");
                    }

                    if (new_account.billingAddress != null)
                    {
                        if (new_account.billingAddress.street1 != null) account_table.Rows[account_row_counter][24] = new_account.billingAddress.street1.ToString();
                        if (new_account.billingAddress.street2 != null) account_table.Rows[account_row_counter][25] = new_account.billingAddress.street2.ToString();
                        if (new_account.billingAddress.city != null) account_table.Rows[account_row_counter][26] = new_account.billingAddress.city.ToString();
                        if (new_account.billingAddress.state != null) account_table.Rows[account_row_counter][27] = new_account.billingAddress.state.ToString();
                        if (new_account.billingAddress.zip != null) account_table.Rows[account_row_counter][28] = new_account.billingAddress.zip.ToString();
                        if (new_account.billingAddress.country != null) account_table.Rows[account_row_counter][29] = new_account.billingAddress.country.ToString().Replace("_", " ");


                    }

                    if (new_account.mailingAddress != null)
                    {
                        if (new_account.mailingAddress.street1 != null) account_table.Rows[account_row_counter][30] = new_account.mailingAddress.street1.ToString();
                        if (new_account.mailingAddress.street2 != null) account_table.Rows[account_row_counter][31] = new_account.mailingAddress.street2.ToString();
                        if (new_account.mailingAddress.city != null) account_table.Rows[account_row_counter][32] = new_account.mailingAddress.city.ToString();
                        if (new_account.mailingAddress.state != null) account_table.Rows[account_row_counter][33] = new_account.mailingAddress.state.ToString();
                        if (new_account.mailingAddress.zip != null) account_table.Rows[account_row_counter][34] = new_account.mailingAddress.zip.ToString();
                        if (new_account.mailingAddress.country != null) account_table.Rows[account_row_counter][35] = new_account.mailingAddress.country.ToString().Replace("_", " ");

                    }

                    if (new_account.groupAccountInfo != null)
                    {

                        if (new_account.groupAccountInfo.accountName != null) account_table.Rows[account_row_counter][36] = new_account.groupAccountInfo.accountName.ToString();
                        if (new_account.groupAccountInfo.DBA != null) account_table.Rows[account_row_counter][37] = new_account.groupAccountInfo.DBA.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][38] = new_account.groupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEsAsOf != null) account_table.Rows[account_row_counter][39] = new_account.groupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.groupAccountInfo.marketSize != null) account_table.Rows[account_row_counter][40] = new_account.groupAccountInfo.marketSize.ToString();
                        if (new_account.groupAccountInfo.businessType != null) account_table.Rows[account_row_counter][41] = new_account.groupAccountInfo.businessType.ToString();
                        if (new_account.groupAccountInfo.SICCode != null) account_table.Rows[account_row_counter][42] = new_account.groupAccountInfo.SICCode.ToString();
                        if (new_account.groupAccountInfo.NAICSCode != null) account_table.Rows[account_row_counter][43] = new_account.groupAccountInfo.NAICSCode.ToString();
                        if (new_account.groupAccountInfo.requires5500 != null && new_account.groupAccountInfo.requires5500.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][44] = new_account.groupAccountInfo.requires5500.ToString();
                        if (new_account.groupAccountInfo.locationsByZip != null) account_table.Rows[account_row_counter][45] = new_account.groupAccountInfo.locationsByZip.ToString();
                        if (new_account.groupAccountInfo.affiliates != null) account_table.Rows[account_row_counter][46] = new_account.groupAccountInfo.affiliates.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][47] = new_account.groupAccountInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][48] = new_account.groupAccountInfo.budgetedTotalAnnualRevenue.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCycles != null && new_account.groupAccountInfo.multiplePayrollCycles.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][49] = new_account.groupAccountInfo.multiplePayrollCycles.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCyclesDifferBy != null) account_table.Rows[account_row_counter][50] = new_account.groupAccountInfo.multiplePayrollCyclesDifferBy.ToString();
                        if (new_account.groupAccountInfo.singlePayrollCycle != null) account_table.Rows[account_row_counter][51] = new_account.groupAccountInfo.singlePayrollCycle.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][52] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][53] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][54] = new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][55] = new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][56] = new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][57] = new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][58] = new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][59] = new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][60] = new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][61] = new_account.groupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][62] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.Year != 1) account_table.Rows[account_row_counter][63] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][64] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][65] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalents != null) account_table.Rows[account_row_counter][145] = new_account.groupAccountInfo.numberOfFullTimeEquivalents.ToString();
                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate != null) account_table.Rows[account_row_counter][146] = new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate.ToString();

                        if (new_account.groupAccountInfo.accountIntegrationInfo != null)
                        {

                            if (new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID != null)
                                account_table.Rows[account_row_counter][140] = new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.sourceCode != null)
                                account_table.Rows[account_row_counter][141] = new_account.groupAccountInfo.accountIntegrationInfo.sourceCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode != null)
                                account_table.Rows[account_row_counter][142] = new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode != null)
                                account_table.Rows[account_row_counter][143] = new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer != null)
                                account_table.Rows[account_row_counter][144] = new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer;


                        }

                    }


                    if (new_account.individualAccountInfo != null)
                    {
                        if (new_account.individualAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][66] = new_account.individualAccountInfo.personInfo.firstName.ToString();
                        if (new_account.individualAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][67] = new_account.individualAccountInfo.personInfo.middleName.ToString();
                        if (new_account.individualAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][68] = new_account.individualAccountInfo.personInfo.lastName.ToString();
                        if (new_account.individualAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][69] = new_account.individualAccountInfo.personInfo.salutation.ToString();
                        if (new_account.individualAccountInfo.personInfo.dateOfBirth != null && new_account.individualAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][70] = new_account.individualAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.individualAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][71] = new_account.individualAccountInfo.personInfo.gender.ToString();
                        if (new_account.individualAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][72] = new_account.individualAccountInfo.personInfo.ssn.ToString();
                        if (new_account.individualAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][73] = new_account.individualAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.individualAccountInfo.email != null) account_table.Rows[account_row_counter][74] = new_account.individualAccountInfo.email.ToString();
                        if (new_account.individualAccountInfo.phone.areaCode != null) account_table.Rows[account_row_counter][75] = new_account.individualAccountInfo.phone.areaCode.ToString();
                        if (new_account.individualAccountInfo.phone.number != null) account_table.Rows[account_row_counter][76] = new_account.individualAccountInfo.phone.number.ToString();
                        if (new_account.individualAccountInfo.phone.type != null) account_table.Rows[account_row_counter][77] = new_account.individualAccountInfo.phone.type.ToString();
                        if (new_account.individualAccountInfo.affiliatedGroupAccountID != null) account_table.Rows[account_row_counter][78] = new_account.individualAccountInfo.affiliatedGroupAccountID.ToString();

                    }



                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.marketingGroupName != null) account_table.Rows[account_row_counter][79] = new_account.marketingGroupAccountInfo.marketingGroupName.ToString();
                        if (new_account.marketingGroupAccountInfo.marketingGroupType != null) account_table.Rows[account_row_counter][80] = new_account.marketingGroupAccountInfo.marketingGroupType.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][81] = new_account.marketingGroupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEsAsOf != null && new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.Year != 1) account_table.Rows[account_row_counter][82] = new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.associatedAccountIDs != null) account_table.Rows[account_row_counter][83] = new_account.marketingGroupAccountInfo.associatedAccountIDs.ToString();

                    }

                    if (new_account.agencyAccountInfo != null)
                    {
                        if (new_account.agencyAccountInfo.agencyName != null) account_table.Rows[account_row_counter][84] = new_account.agencyAccountInfo.agencyName.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.email != null) account_table.Rows[account_row_counter][85] = new_account.agencyAccountInfo.agencyInfo.email.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][86] = new_account.agencyAccountInfo.agencyInfo.phone1.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][87] = new_account.agencyAccountInfo.agencyInfo.phone2.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][88] = new_account.agencyAccountInfo.agencyInfo.phone3.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][89] = new_account.agencyAccountInfo.agencyInfo.phone4.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.number != null) account_table.Rows[account_row_counter][90] = new_account.agencyAccountInfo.agencyInfo.phone1.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.number != null) account_table.Rows[account_row_counter][91] = new_account.agencyAccountInfo.agencyInfo.phone2.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.number != null) account_table.Rows[account_row_counter][92] = new_account.agencyAccountInfo.agencyInfo.phone3.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.number != null) account_table.Rows[account_row_counter][93] = new_account.agencyAccountInfo.agencyInfo.phone4.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.type != null) account_table.Rows[account_row_counter][94] = new_account.agencyAccountInfo.agencyInfo.phone1.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.type != null) account_table.Rows[account_row_counter][95] = new_account.agencyAccountInfo.agencyInfo.phone2.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.type != null) account_table.Rows[account_row_counter][96] = new_account.agencyAccountInfo.agencyInfo.phone3.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.type != null) account_table.Rows[account_row_counter][97] = new_account.agencyAccountInfo.agencyInfo.phone4.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.taxPayerID != null) account_table.Rows[account_row_counter][98] = new_account.agencyAccountInfo.agencyInfo.taxPayerID.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][99] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][100] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.agentAccountInfo != null)
                    {
                        if (new_account.agentAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][101] = new_account.agentAccountInfo.personInfo.firstName.ToString();
                        if (new_account.agentAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][102] = new_account.agentAccountInfo.personInfo.middleName.ToString();
                        if (new_account.agentAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][103] = new_account.agentAccountInfo.personInfo.lastName.ToString();
                        if (new_account.agentAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][104] = new_account.agentAccountInfo.personInfo.salutation.ToString();
                        if (new_account.agentAccountInfo.personInfo.dateOfBirth != null && new_account.agentAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][105] = new_account.agentAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.agentAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][106] = new_account.agentAccountInfo.personInfo.gender.ToString();
                        if (new_account.agentAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][107] = new_account.agentAccountInfo.personInfo.ssn.ToString();
                        if (new_account.agentAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][108] = new_account.agentAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.agentAccountInfo.agencyAccountID != null) account_table.Rows[account_row_counter][109] = new_account.agentAccountInfo.agencyAccountID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.email != null) account_table.Rows[account_row_counter][110] = new_account.agentAccountInfo.agentInfo.email.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][111] = new_account.agentAccountInfo.agentInfo.phone1.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][112] = new_account.agentAccountInfo.agentInfo.phone2.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][113] = new_account.agentAccountInfo.agentInfo.phone3.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][114] = new_account.agentAccountInfo.agentInfo.phone4.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.number != null) account_table.Rows[account_row_counter][115] = new_account.agentAccountInfo.agentInfo.phone1.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.number != null) account_table.Rows[account_row_counter][116] = new_account.agentAccountInfo.agentInfo.phone2.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.number != null) account_table.Rows[account_row_counter][117] = new_account.agentAccountInfo.agentInfo.phone3.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.number != null) account_table.Rows[account_row_counter][118] = new_account.agentAccountInfo.agentInfo.phone4.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.type != null) account_table.Rows[account_row_counter][119] = new_account.agentAccountInfo.agentInfo.phone1.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.type != null) account_table.Rows[account_row_counter][120] = new_account.agentAccountInfo.agentInfo.phone2.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.type != null) account_table.Rows[account_row_counter][121] = new_account.agentAccountInfo.agentInfo.phone3.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.type != null) account_table.Rows[account_row_counter][122] = new_account.agentAccountInfo.agentInfo.phone4.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.taxPayerID != null) account_table.Rows[account_row_counter][123] = new_account.agentAccountInfo.agentInfo.taxPayerID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][124] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][125] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][126] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][127] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][128] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][129] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][130] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][131] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][132] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][133] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][134] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][135] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][136] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null) account_table.Rows[account_row_counter][137] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][138] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][139] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                    }

                    #endregion

                    if (new_account.accountCustomFieldValues != null)
                    {
                        #region accountCustomFieldValues_table

                        foreach (wf_benefitpoint_V4.CustomFieldValue cfv in new_account.accountCustomFieldValues)
                        {
                            accountCustomFieldValues_table.Rows.Add();
                            accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][0] = new_account.accountID;
                            if (cfv.customFieldValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][1] = cfv.customFieldValueID;
                            if (cfv.customFieldID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][2] = cfv.customFieldID;
                            if (cfv.optionValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][3] = cfv.optionValueID;
                            if (cfv.valueText != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][4] = cfv.valueText;
                            accountCustomFieldValues_row_counter++;

                        }

                        #endregion

                    }


                    account_row_counter++;

                }



                AccountDS.Tables.Add(accountCustomFieldValues_table);
                AccountDS.Tables[0].TableName = "AccountCustomFieldValuesTable";
                AccountDS.Tables.Add(account_table);
                AccountDS.Tables[1].TableName = "AccountTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountDS;

        }
        /// <summary>
        /// Return Team Members of Client
        /// </summary>
        /// <param name="account_id">account_id </param>
        /// <param name="SessionId">SessionId </param>
        /// <returns>DataSet</returns>
        public override DataSet GetTeamMembers(int account_id, string SessionId)
        {
            //DataTable account_Team_memeber = new DataTable();

            wf_benefitpoint_V4.BrokerConnectV4 new_connection = new wf_benefitpoint_V4.BrokerConnectV4();

            wf_benefitpoint_V4.SessionIdHeader SIH = new wf_benefitpoint_V4.SessionIdHeader();

            wf_benefitpoint_V4.AccountTeamMember[] TeamMember = new wf_benefitpoint_V4.AccountTeamMember[100];

            wf_benefitpoint_V4.AccountTeamRole[] TeamRole = new wf_benefitpoint_V4.AccountTeamRole[100]; // This array is used to get the Role's of team members

            DataSet AccountTeamMemberDS = new DataSet();
            int account_row_counter = 0;

            //wf_benefitpoint_V4.User phn = new wf_benefitpoint_V4.User();
            try
            {
                account_Team_memeber = new DataTable();

                //BuildAccountTeamMamberTable();
                account_Team_memeber.Columns.Add("userID", typeof(string));  // Row 0
                account_Team_memeber.Columns.Add("firstName", typeof(string));  // Row 1
                account_Team_memeber.Columns.Add("lastName", typeof(string));  // Row 2
                account_Team_memeber.Columns.Add("email", typeof(string));  // Row 3
                account_Team_memeber.Columns.Add("role", typeof(string));  // Row 4

                SIH.sessionId = SessionId;  //myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                TeamMember = new_connection.getTeamMembers(account_id);

                TeamRole = new_connection.getAccountTeamRoles(); //  Get all the roles of the team members
                //phn = new_connection.getUser(account_id);

                foreach (wf_benefitpoint_V4.AccountTeamMember item in TeamMember)
                {
                    account_Team_memeber.Rows.Add();
                    account_Team_memeber.Rows[account_row_counter][0] = item.userID.ToString();
                    account_Team_memeber.Rows[account_row_counter][1] = item.firstName;
                    account_Team_memeber.Rows[account_row_counter][2] = item.lastName;
                    account_Team_memeber.Rows[account_row_counter][3] = item.email;

                    // Get the exact role from TeamRole array by providing brokerClientRoleID

                    //need to checked 
                    //var role = (from n in TeamRole.AsEnumerable()
                    //            where n.roleID == item.brokerClientRoleID
                    //            select n.description).FirstOrDefault();

                    //account_Team_memeber.Rows[account_row_counter][4] = role;
                    account_row_counter++;

                }
                AccountTeamMemberDS.Tables.Add(account_Team_memeber);
                AccountTeamMemberDS.Tables[0].TableName = "AccountTeamMember";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountTeamMemberDS;

        }
        /// <summary>
        /// Get Office Details.DataTable having Column OfficeName,RegionName and OfficeID
        /// </summary>
        /// <param name="account_id">account_id</param>
        /// <param name="SessionId">SessionId</param>
        /// <returns></returns>
        public override DataTable GetOfficeDetail(int account_id, string SessionId)
        {

            wf_benefitpoint_V4.BrokerConnectV4 new_connection = new wf_benefitpoint_V4.BrokerConnectV4();
            wf_benefitpoint_V4.SessionIdHeader SIH = new wf_benefitpoint_V4.SessionIdHeader();
            wf_benefitpoint_V4.Account new_account = new wf_benefitpoint_V4.Account();
            wf_benefitpoint_V4.Office offData = new wf_benefitpoint_V4.Office();
            DataTable OfficeDT = new DataTable();

            try
            {
                OfficeDT.Columns.Add("OfficeID", typeof(Int32));     // Column 0
                OfficeDT.Columns.Add("OfficeName", typeof(String));  // Column 1
                OfficeDT.Columns.Add("RegionName", typeof(String));  // Column 2

                DataRow OfficeDTRow = OfficeDT.NewRow();
                OfficeDT.Rows.Add(OfficeDTRow);

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);

                if (new_account != null)
                {
                    if (new_account.officeID > 0)
                    {
                        offData = new_connection.getOffice(new_account.officeID);
                        if (offData != null)
                        {
                            OfficeDT.Rows[0][0] = offData.officeID;
                            OfficeDT.Rows[0][1] = offData.officeName;
                            OfficeDT.Rows[0][2] = offData.regionName;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return OfficeDT;
        }
    }
}