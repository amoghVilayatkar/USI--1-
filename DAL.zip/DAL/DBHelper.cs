﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace BenefitPointSummaryPortal.DAL
{
    public  class DBHelper
    {
        private  SqlConnection connection;
        public  SqlConnection Connection
        {

            get
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                if (connection == null)
                {
                    connection = new SqlConnection(connectionString);
                    connection.Open();
                }
                else if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }
                else if (connection.State == System.Data.ConnectionState.Broken)
                {
                    connection.Close();
                    connection.Open();
                }
                return connection;
            }
        }

        public  void ExecProc(string strProName, SqlParameter[] para)
        {
          
            try
            {
                SqlCommand sqlcmd = Connection.CreateCommand();
                if (Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                }
                sqlcmd.CommandText = strProName;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter paras in para)
                {
                    sqlcmd.Parameters.Add(paras);
                }
                sqlcmd.ExecuteNonQuery();
            }
            finally
            {
                Connection.Close();
            }
        }

        public  bool ExecNoQuery(string sql)
        {

            try
            {
                SqlCommand cmd = Connection.CreateCommand();
                cmd.CommandText = sql;
                return true;
            }
            catch
            {
                return false;
            }

        }

        public  DataTable ExecQuery(string Sql)
        {
            //Connection.Open();
            if (Connection.State == ConnectionState.Closed)
            {
                Connection.Open();
            }
            SqlDataAdapter da = new SqlDataAdapter(Sql, Connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Connection.Close();
            return dt;
           

        }

        public  int ExecuteCommand(string safeSql)
        {
            SqlCommand cmd = new SqlCommand(safeSql, Connection);
            int result = cmd.ExecuteNonQuery();
            return result;
        }

        public  int ExecuteCommand(string sql, params SqlParameter[] values)
        {
            SqlCommand cmd = new SqlCommand(sql, Connection);
            cmd.Parameters.AddRange(values);
            return cmd.ExecuteNonQuery();
        }

        public  int GetScalar(string safeSql)
        {
            SqlCommand cmd = new SqlCommand(safeSql, Connection);
            int result = Convert.ToInt32(cmd.ExecuteScalar());
            return result;
        }

        public  int GetScalar(string sql, params SqlParameter[] values)
        {
            SqlCommand cmd = new SqlCommand(sql, Connection);
            cmd.Parameters.AddRange(values);
            int result = Convert.ToInt32(cmd.ExecuteScalar());
            return result;
        }

        public  SqlDataReader GetReader(string safeSql)
        {
            SqlDataReader reader = null ;
            try
            {
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                reader = cmd.ExecuteReader();
                return reader;
            }
            finally
            {
                reader.Close();
            }
        }

        public  SqlDataReader GetReader(string sql, params SqlParameter[] values)
        {
            SqlDataReader reader = null;
            try
            {
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                reader = cmd.ExecuteReader();
                return reader;
            }
            finally
            {
                reader.Close();
            }

        }

        public  DataTable GetDataSet(string safeSql)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(safeSql, Connection);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

        public  DataTable GetDataSet(string sql, params SqlParameter[] values)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(sql, Connection);
            cmd.Parameters.AddRange(values);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

        public  DataTable ExecProcedure(string strProName, SqlParameter[] para)
        {
            SqlDataAdapter da =null;
            SqlCommand sqlcmd=null;
            try
            {
                sqlcmd = Connection.CreateCommand();
                if (Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                }
                sqlcmd.CommandText = strProName;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                if (para!=null)
                {
                    foreach (SqlParameter paras in para)
                    {
                        sqlcmd.Parameters.Add(paras);
                    }
                }
                DataSet ds = new DataSet();
                da = new SqlDataAdapter(sqlcmd);
                da.Fill(ds);
                return ds.Tables[0];
            }
            finally
            {
                Connection.Close();
                da.Dispose();
                sqlcmd.Dispose();
            }
        }

        public  string ReturnStringScalar(string sql)
        {
            if (Connection.State == ConnectionState.Closed)
            {
                Connection.Open();
            }
            SqlCommand cmd = new SqlCommand(sql, Connection);
            try
            {
                string result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                
            }
            finally
            {

                Connection.Close();
            }
        }

        public  bool ExecTSQL(string[] sqls)
        {
            //connection.Open();
            SqlTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                for (int i = 0; i < sqls.Length; i++)
                {
                    if (sqls[i] == "" || sqls[i] == null)
                    {
                        continue;
                    }
                    SqlCommand cmd = Connection.CreateCommand();
                    if (Connection.State == ConnectionState.Closed)
                    {
                        Connection.Open();
                    }
                    cmd.Transaction = trans;
                    cmd.CommandText = sqls[i];
                    cmd.ExecuteNonQuery();
                }
                trans.Commit();
                return true;
            }
            catch
            {

                trans.Rollback();
                return false;
            }
            finally
            {
                trans = null;
                Connection.Close();
            }
           
        }
        public  DataTable GetXmlData(string path)
        {
            DataSet ds = new DataSet();
           
            ds.ReadXml(path);
            return ds.Tables[0];

        }
    }
}