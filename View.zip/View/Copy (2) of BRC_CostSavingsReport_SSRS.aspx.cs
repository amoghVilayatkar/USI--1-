﻿using System;
using Microsoft.Reporting.WebForms;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Reflection;
using BenefitPointSummaryPortal.BAL;

namespace BenefitPointSummaryPortal.View
{
    public partial class BRC_CostSavingsReport_SSRS : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        SummaryDetail sd = new SummaryDetail();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            ////string Activity = "BRC Cost Savings Report";
            ////string Activity_Group = "BRC";
            //DisableUnwantedExportFormat(rptViewer, "PDF");
            div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                TitleSpan.InnerText = "BRC Cost Savings Report";
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                ServerReport serverReport = rptViewer.ServerReport;
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                // serverReport.ReportServerUrl = new Uri("http://reports.dev.usii.com/reportserver"); //Dev version
                 serverReport.ReportServerUrl = new Uri("http://reports.qa.usii.com/reportserver"); //QA version
                // serverReport.ReportServerUrl = new Uri("http://reports.usii.com/Reportserver"); // Production Version

                serverReport.ReportPath = "/CRM BRC/BRC_Cost_Saving";
                //rptViewer.ServerReport.GetParameters();
                //rptViewer.ShowParameterPrompts = true;
                //rptViewer.ServerReport.SetParameters(Param);
                rptViewer.ServerReport.Refresh();

                string Activity = string.Empty;
                string Activity_Group = string.Empty;
                Activity = "Cost Savings Report";
                Activity_Group = "Reports";
                string AdditionalCrtieriaOption_1 = Activity;// string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;

                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "", Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "");
                // bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
        }
    }
}