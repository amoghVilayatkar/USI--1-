﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using StringTrimmer;


namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTools2_AccountProfileDetails : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        ConstantValue cv = new ConstantValue();


        public void WriteFieldToTools2_AccountProfileDetails(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                string SalesLead_EMail = string.Empty;
                string SalesLead_WorkPhone = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_EMail = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string AnalyticalSupport_FirstName = string.Empty;
                string AnalyticalSupport_LastName = string.Empty;
                string AnalyticalSupport_EMail = string.Empty;
                string AnalyticalSupport_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }

                            // BRC Status
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "35479")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    BRC_Status = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }

                            // BRC Date Implemented
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "35480")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]), out dateValue) == true)
                                    {
                                        BRC_Date_Implemented = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])).ToString("MM/dd/yyyy");
                                    }
                                    continue;
                                }
                            }
                        }
                    }

                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        AnalyticalSupport_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        AnalyticalSupport_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        AnalyticalSupport_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        AnalyticalSupport_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"])))
                            {
                                Required_5500 = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"]);

                                if (Required_5500.ToLower() == "false")
                                {
                                    Required_5500 = "No";
                                }
                                else if (Required_5500.ToLower() == "true")
                                {
                                    Required_5500 = "Yes";
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"])))
                            {
                                Primary_Industry = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"]);
                                Primary_Industry = Primary_Industry.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"])))
                            {
                                Num_Of_Retiree = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_Retiree_As_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(MainAddress);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainPhone))
                            {
                                oWordApp.Selection.TypeText(MainPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("5500 Required"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Required_5500))
                            {
                                oWordApp.Selection.TypeText(Required_5500);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Industry"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Primary_Industry))
                            {
                                oWordApp.Selection.TypeText(Primary_Industry);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("BRC Status"))
                        {
                            myMergeField.Select();
                            if (BRC_Status.ToLower() == "select")
                            {
                                BRC_Status = "";
                            }
                            if (!string.IsNullOrEmpty(BRC_Status) && !(string.IsNullOrEmpty(BRC_Date_Implemented)) && BRC_Date_Implemented != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(BRC_Status + " as of " + BRC_Date_Implemented);
                            }
                            else if (!string.IsNullOrEmpty(BRC_Status) && (string.IsNullOrEmpty(BRC_Date_Implemented)))
                            {
                                if (BRC_Status == "0" && string.IsNullOrEmpty(BRC_Date_Implemented))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRC_Status);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Employees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Equivalents"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && !(string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)) && Num_Of_FTEquivalents_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTEquivalents = Convert.ToDecimal(Num_Of_FTEquivalents);
                                oWordApp.Selection.TypeText(Number_Of_FTEquivalents.ToString("#,##0") + " as of " + Num_Of_FTEquivalents_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && (string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)))
                            {
                                if (Num_Of_FTEquivalents == "0" && string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTEquivalents);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Retirees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_Retiree) && !(string.IsNullOrEmpty(Num_Of_Retiree_As_Of)) && Num_Of_Retiree_As_Of != "01/01/0001")
                            {
                                decimal Number_Retiree = Convert.ToDecimal(Num_Of_Retiree);
                                oWordApp.Selection.TypeText(Number_Retiree.ToString("#,##0") + " as of " + Num_Of_Retiree_As_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_Retiree) && (string.IsNullOrEmpty(Num_Of_Retiree_As_Of)))
                            {
                                if (Num_Of_Retiree == "0" && string.IsNullOrEmpty(Num_Of_Retiree_As_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_Retiree);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_EMail))
                            {
                                oWordApp.Selection.TypeText(SalesLead_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(SalesLead_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_EMail))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_FirstName) || !string.IsNullOrEmpty(AnalyticalSupport_LastName))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_FirstName + " " + AnalyticalSupport_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_EMail))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }
                #endregion

                #region Merge field for footer
                foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                {
                    foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                    {
                        Word.Fields fields = footer.Range.Fields;

                        foreach (Word.Field field in fields)
                        {
                            Word.Range rngFieldCode = field.Code;
                            string fieldText = rngFieldCode.Text;
                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Current_Date"))
                                {
                                    field.Select();
                                    oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                                    continue;
                                }
                            }
                        }
                    }
                }

                #endregion

                #region Write Table of Account Contacts
                Tools_Constant tc = new Tools_Constant();
                string accountInfo = string.Empty;
                int clmCnt = 1;
                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                    //{
                                    ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                    //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                    //{
                                    if (clmCnt > 1)
                                    {
                                        //oWordDoc.Tables[2].Columns.Add();
                                        oWordDoc.Tables[2].Rows.Add();
                                    }

                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        email = ContactList[i].Email;
                                    }
                                    else
                                    {
                                        email = " ";
                                    }

                                    if (ContactList[i].Phone.Count > 0)
                                    {
                                        phoneNumber = ContactList[i].Phone[0];
                                    }
                                    else
                                    {
                                        phoneNumber = " ";
                                    }
                                    //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                    //oWordDoc.Tables[2].Cell(1, clmCnt).Range.Text = "Client Contact:";
                                    //oWordDoc.Tables[2].Cell(2, clmCnt).Range.Text = accountInfo;
                                    //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);
                                    oWordDoc.Tables[2].Cell(j + 2, 1).Range.Text = name;
                                    oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = title;
                                    oWordDoc.Tables[2].Cell(j + 2, 3).Range.Text = phoneNumber;
                                    oWordDoc.Tables[2].Cell(j + 2, 4).Range.Text = email;

                                    clmCnt++;

                                    //if (clmCnt > 3)
                                    //{
                                    //    break;
                                    //}
                                    //}
                                    //}
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                int iTotalFields = 0;
                int medicalCount = 1; //For 6 different plans
                int limitedMedicalCount = 1;
                int stoplossCount = 1;
                int intmedicalCount = 1;
                int prescriptionCount = 1;
                string value = string.Empty;
                DataTable Emp = new DataTable();


                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }
                //Emp= bp.GetEmployeeData(ClientID);

                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();

                HashtableMedical.Add(1, "45");              //Annual Deductible[Per Person]
                HashtableMedical.Add(2, "44");              //Annual Deductible[Maximum Per Family]
                HashtableMedical.Add(3, "53");              //Annual Out-of-Pocket Maximum[Per Person]
                HashtableMedical.Add(4, "52");              //Annual Out-of-Pocket Maximum[Maximum Per Family]
                HashtableMedical.Add(5, "112");            //Out-of-Network Benefits[Coinsurance]
                HashtableMedical.Add(6, "386");            //Physician Office Visit (Primary)
                HashtableMedical.Add(7, "295");            //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(8, "409");            //Hospital/Facility[Outpatient Care]
                HashtableMedical.Add(9, "184");            //Other Services[Emergency Room]
                HashtableMedical.Add(10, "213");          // Prescription Categories[Generic]
                HashtableMedical.Add(11, "78");          // Prescription Categories[Formulary]
                HashtableMedical.Add(12, "84");          // Prescription Categories[Non Formulary]
                HashtableMedical.Add(13, "386");         //Professional[Office Visit]
                HashtableMedical.Add(14, "138");         //Specific Stop Loss - Deductible 
                HashtableMedical.Add(15, "25");          //Specific Stop Loss - Aggregating Specific Corridor
                HashtableMedical.Add(16, "125");         //Specific Stop Loss - Contract Type
                HashtableMedical.Add(17, "61");          //Aggregate Stop Loss - Attachment Level/Corridor
                HashtableMedical.Add(18, "124");         //Aggregate Stop Loss - Contract Type
                HashtableMedical.Add(19, "565");         //Additional Features[Waiting Periods]
                HashtableMedical.Add(20, "615");         //Prescription Drug Allowance / Individual
                HashtableMedical.Add(21, "616");         //Prescription Drug Allowance / Family  

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    #region Limited
                    if (Convert.ToString(PlanTable.Rows[k]["PlanType"]).ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 233)  //Limited Benefit 2-Tier
                    {
                        if (Convert.ToString(PlanTable.Rows[k]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[k]["productID"]))
                        {
                            string Inpatient_Care = string.Empty;
                            string Emergency_Room = string.Empty;
                            string Office_Visit = string.Empty;
                            string PrescriptionDrugIndividual = string.Empty;
                            string PrescriptionDrugFamily = string.Empty;
                            string FundingType = "";
                            int limitedTableNo = 0;

                            if (limitedMedicalCount == 1)
                            {
                                limitedTableNo = 17;
                            }
                            if (limitedMedicalCount == 2)
                            {
                                limitedTableNo = 18;
                            }
                            if (limitedMedicalCount == 3)
                            {
                                limitedTableNo = 19;
                            }
                            if (limitedMedicalCount == 4)
                            {
                                limitedTableNo = 20;
                            }
                            if (limitedMedicalCount == 5)
                            {
                                limitedTableNo = 21;
                            }
                            if (limitedMedicalCount == 6)
                            {
                                limitedTableNo = 22;
                            }
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }
                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }

                            #region MedicalTable
                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        value = Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"]);
                                        switch (key)
                                        {
                                            case 7: Inpatient_Care = value; break;
                                            case 9: Emergency_Room = value; break;
                                            case 13: Office_Visit = value; break;
                                            case 20: PrescriptionDrugIndividual = value; break;
                                            case 21: PrescriptionDrugFamily = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Limited Medical Plan Info writing
                            string LtdMedical_Data = "";
                            oWordDoc.Tables[limitedTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            oWordDoc.Tables[limitedTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[limitedTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[limitedTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[limitedTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[limitedTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {

                                string DefinationOf_eligible_Emplyee = " ";
                                /******************COMMENTED BY AMOGH ****************/
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                oWordDoc.Tables[limitedTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                //oWordDoc.Tables[limitedTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                            }

                            LtdMedical_Data = "Office Visit/Exam: " + Office_Visit.Trim();
                            LtdMedical_Data += "\n" + "Inpatient Hospitalization: " + Inpatient_Care.Trim();
                            LtdMedical_Data += "\n" + "Emergency Room: " + Emergency_Room.Trim();
                            LtdMedical_Data += "\n" + "Prescription Drug Allowance: " + PrescriptionDrugIndividual.Trim() + " / " + PrescriptionDrugFamily.Trim();

                            oWordDoc.Tables[limitedTableNo].Cell(1, 3).Range.Text = LtdMedical_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Office Visit/Exam: ", "Inpatient Hospitalization: ", "Emergency Room: ", "Prescription Drug Allowance: ", "Contributions: ", "Rates: " };
                            //string[] makeBold = new string[] { " ", "Carrier:", "Group#: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Office Visit/Exam: ", "Inpatient Hospitalization: ", "Emergency Room: ", "Prescription Drug Allowance: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, limitedTableNo);

                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("LIMITED_PLANTYPE" + limitedMedicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                                    }
                                    if (fieldName.Contains("LIMITED_BENEFITSUMMARY" + limitedMedicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                                    }
                                }
                            }
                            #endregion
                            limitedMedicalCount++;
                        }
                    }
                    #endregion
                    #region Stop Loss
                    ////else if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 235)  //Stop Loss
                    ////{
                    ////    if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                    ////    {
                    ////        string StopLoss_Deductible = string.Empty;
                    ////        string StopLoss_Aggregating = string.Empty;
                    ////        string StopLoss_SpeContractType = string.Empty;
                    ////        string StopLoss_Corridor = string.Empty;
                    ////        string StopLoss_AggContractType = string.Empty;
                    ////        int stoplossTableNo = 0;

                    ////        if (stoplossCount == 1)
                    ////        {
                    ////            stoplossTableNo = 23;
                    ////        }
                    ////        if (stoplossCount == 2)
                    ////        {
                    ////            stoplossTableNo = 24;
                    ////        }
                    ////        if (stoplossCount == 3)
                    ////        {
                    ////            stoplossTableNo = 25;
                    ////        }
                    ////        if (stoplossCount == 4)
                    ////        {
                    ////            stoplossTableNo = 26;
                    ////        }
                    ////        if (stoplossCount == 5)
                    ////        {
                    ////            stoplossTableNo = 27;
                    ////        }
                    ////        if (stoplossCount == 6)
                    ////        {
                    ////            stoplossTableNo = 28;
                    ////        }

                    ////        #region Stop Loss Table
                    ////        foreach (int key in HashtableMedical.Keys)
                    ////        {
                    ////            foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                    ////            {
                    ////                if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                    ////                {
                    ////                    value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                    ////                    switch (key)
                    ////                    {
                    ////                        case 14: StopLoss_Deductible = value; break;
                    ////                        case 15: StopLoss_Aggregating = value; break;
                    ////                        case 16: StopLoss_SpeContractType = value; break;
                    ////                        case 17: StopLoss_Corridor = value; break;
                    ////                        case 18: StopLoss_AggContractType = value; break;
                    ////                    }
                    ////                }
                    ////            }
                    ////        }
                    ////        #endregion
                    ////        #region Stop Loss Plan Info writing
                    ////        string StopLoss_Data = "";
                    ////        oWordDoc.Tables[stoplossTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                    ////        oWordDoc.Tables[stoplossTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                    ////        oWordDoc.Tables[stoplossTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                    ////        oWordDoc.Tables[stoplossTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");

                    ////        StopLoss_Data = "Specific Deductible: " + StopLoss_Deductible.Trim();
                    ////        StopLoss_Data += "\n" + "Aggregating Specific Corridor: " + StopLoss_Aggregating.Trim();
                    ////        StopLoss_Data += "\n" + "Specific Contract Type: " + StopLoss_SpeContractType.Trim();
                    ////        StopLoss_Data += "\n" + "Aggregate Corridor: " + StopLoss_Corridor.Trim();
                    ////        StopLoss_Data += "\n" + "Aggregate Contract Type: " + StopLoss_AggContractType.Trim();

                    ////        oWordDoc.Tables[stoplossTableNo].Cell(1, 3).Range.Text = StopLoss_Data;
                    ////        string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Specific Deductible: ", "Aggregating Specific Corridor: ", "Specific Contract Type: ", "Aggregate Corridor: ", "Aggregate Contract Type: " };
                    ////        sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, stoplossTableNo);

                    ////        #endregion
                    ////        # region MergeField
                    ////        foreach (Word.Field myMergeField in oWordDoc.Fields)
                    ////        {
                    ////            iTotalFields++;

                    ////            Word.Range rngFieldCode = myMergeField.Code;

                    ////            String fieldText = rngFieldCode.Text;

                    ////            if (fieldText.StartsWith(" MERGEFIELD"))
                    ////            {
                    ////                Int32 endMerge = fieldText.IndexOf("\\");
                    ////                if (endMerge == -1)
                    ////                {
                    ////                    endMerge = fieldText.Length;
                    ////                }

                    ////                Int32 fieldNameLength = fieldText.Length - endMerge;

                    ////                String fieldName = fieldText.Substring(11, endMerge - 11);

                    ////                fieldName = fieldName.Trim();
                    ////                if (fieldName.Contains("STOPLOSS_PLANTYPE" + stoplossCount))
                    ////                {
                    ////                    myMergeField.Select();
                    ////                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                    ////                }
                    ////                if (fieldName.Contains("STOPLOSS_BENEFITSUMMARY" + stoplossCount))
                    ////                {
                    ////                    myMergeField.Select();
                    ////                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                    ////                }
                    ////            }
                    ////        }
                    ////        #endregion
                    ////        stoplossCount++;
                    ////    }
                    ////}
                    #endregion
                    #region International
                    else if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 410)  //International Bundled Plan (3-Tier)
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string FundingType = "";
                            int intmedicalTableNo = 0;

                            if (intmedicalCount == 1)
                            {
                                intmedicalTableNo = 11;
                            }
                            if (intmedicalCount == 2)
                            {
                                intmedicalTableNo = 12;
                            }
                            if (intmedicalCount == 3)
                            {
                                intmedicalTableNo = 13;
                            }
                            if (intmedicalCount == 4)
                            {
                                intmedicalTableNo = 14;
                            }
                            if (intmedicalCount == 5)
                            {
                                intmedicalTableNo = 15;
                            }
                            if (intmedicalCount == 6)
                            {
                                intmedicalTableNo = 16;
                            }
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }

                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }
                            #region International Medical Plan Info writing
                            oWordDoc.Tables[intmedicalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            oWordDoc.Tables[intmedicalTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[intmedicalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[intmedicalTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[intmedicalTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[intmedicalTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                /************COMMENTED BY AMOGH **/
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                oWordDoc.Tables[intmedicalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                // oWordDoc.Tables[intmedicalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                            }

                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, intmedicalTableNo);

                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("INT PLAN TYPE" + intmedicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                                    }
                                    if (fieldName.Contains("INT_BENEFITSUMMARY" + intmedicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                                    }
                                }
                            }
                            #endregion
                            intmedicalCount++;
                        }
                    }
                    #endregion
                    #region Prescription Drug (Carve-Out)
                    ////else if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 173)   //Prescription Drug (Carve-Out)
                    ////{
                    ////    if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                    ////    {
                    ////        int prescriptionTableNo = 0;

                    ////        if (prescriptionCount == 1)
                    ////        {
                    ////            prescriptionTableNo = 29;
                    ////        }
                    ////        if (prescriptionCount == 2)
                    ////        {
                    ////            prescriptionTableNo = 30;
                    ////        }
                    ////        if (prescriptionCount == 3)
                    ////        {
                    ////            prescriptionTableNo = 31;
                    ////        }
                    ////        if (prescriptionCount == 4)
                    ////        {
                    ////            prescriptionTableNo = 32;
                    ////        }
                    ////        if (prescriptionCount == 5)
                    ////        {
                    ////            prescriptionTableNo = 33;
                    ////        }
                    ////        if (prescriptionCount == 6)
                    ////        {
                    ////            prescriptionTableNo = 34;
                    ////        }

                    ////        #region Prescription Medical Plan Info writing
                    ////        oWordDoc.Tables[prescriptionTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                    ////        oWordDoc.Tables[prescriptionTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                    ////        oWordDoc.Tables[prescriptionTableNo].Cell(1, 3).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                    ////        oWordDoc.Tables[prescriptionTableNo].Cell(1, 4).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");

                    ////        string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:" };
                    ////        sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, prescriptionTableNo);

                    ////        #endregion
                    ////        # region MergeField
                    ////        foreach (Word.Field myMergeField in oWordDoc.Fields)
                    ////        {
                    ////            iTotalFields++;

                    ////            Word.Range rngFieldCode = myMergeField.Code;

                    ////            String fieldText = rngFieldCode.Text;

                    ////            if (fieldText.StartsWith(" MERGEFIELD"))
                    ////            {
                    ////                Int32 endMerge = fieldText.IndexOf("\\");
                    ////                if (endMerge == -1)
                    ////                {
                    ////                    endMerge = fieldText.Length;
                    ////                }

                    ////                Int32 fieldNameLength = fieldText.Length - endMerge;

                    ////                String fieldName = fieldText.Substring(11, endMerge - 11);

                    ////                fieldName = fieldName.Trim();
                    ////                if (fieldName.Contains("PRESCRIPTION_PLANTYPE" + prescriptionCount))
                    ////                {
                    ////                    myMergeField.Select();
                    ////                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                    ////                }
                    ////                if (fieldName.Contains("PRESCRIPTION_BENEFITSUMMARY" + prescriptionCount))
                    ////                {
                    ////                    myMergeField.Select();
                    ////                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                    ////                }
                    ////            }
                    ////        }
                    ////        #endregion
                    ////        prescriptionCount++;
                    ////    }
                    ////}
                    #endregion
                    #region Medical
                    else if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string AnnualDeductible_Individual = string.Empty;
                            string AnnualDeductible_Family = string.Empty;
                            string OutOfPocketMax_Individual = string.Empty;
                            string OutOfPocketMax_Family = string.Empty;
                            string Coinsurance = string.Empty;
                            string Physician_Office_Visit = string.Empty;
                            string Inpatient_Care = string.Empty;
                            string Outpatient_Care = string.Empty;
                            string Emergency_Room = string.Empty;
                            string Generic = string.Empty;
                            string Formulary = string.Empty;
                            string Non_Formulary = string.Empty;
                            string WaitingPeriod = string.Empty;
                            string FundingType = "";
                            int medicalTableNo = 0;

                            if (medicalCount == 1)
                            {
                                medicalTableNo = 5;
                            }
                            if (medicalCount == 2)
                            {
                                medicalTableNo = 6;
                            }
                            if (medicalCount == 3)
                            {
                                medicalTableNo = 7;
                            }
                            if (medicalCount == 4)
                            {
                                medicalTableNo = 8;
                            }
                            if (medicalCount == 5)
                            {
                                medicalTableNo = 9;
                            }
                            if (medicalCount == 6)
                            {
                                medicalTableNo = 10;
                            }
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }

                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }
                            #region MedicalTable
                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: AnnualDeductible_Individual = value; break;
                                            case 2: AnnualDeductible_Family = value; break;
                                            case 3: OutOfPocketMax_Individual = value; break;
                                            case 4: OutOfPocketMax_Family = value; break;
                                            case 5: Coinsurance = value; break;
                                            case 6: Physician_Office_Visit = value; break;
                                            case 7: Inpatient_Care = value; break;
                                            case 8: Outpatient_Care = value; break;
                                            case 9: Emergency_Room = value; break;
                                            case 10: Generic = value; break;
                                            case 11: Formulary = value; break;
                                            case 12: Non_Formulary = value; break;
                                            case 19: WaitingPeriod = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Medical Plan Info writing
                            string Medical_Data = "";
                            oWordDoc.Tables[medicalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            oWordDoc.Tables[medicalTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[medicalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[medicalTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[medicalTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[medicalTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            string DefinationOf_eligible_Emplyee = "";
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                //string DefinationOf_eligible_Emplyee = " ";
                                /**************** CODE COMMENTED BY AMOGH *****/
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}

                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }

                                oWordDoc.Tables[medicalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                ////oWordDoc.Tables[medicalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                // commented and moved below after loop
                                //string domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                //oWordDoc.Tables[medicalTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                                //oWordDoc.Tables[medicalTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);
                            }
                            if (DefinationOf_eligible_Emplyee=="")
                            {
                                oWordDoc.Tables[medicalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]);
                            }
                            string domesticPartner = Convert.ToString(EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"]);
                            if (domesticPartner!="")
                            {
                                domesticPartner = domesticPartner.Trim();
                            }
                            oWordDoc.Tables[medicalTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                            oWordDoc.Tables[medicalTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);


                            Medical_Data = "Deductible (Indv/Family): " + AnnualDeductible_Individual.Trim() + " / " + AnnualDeductible_Family.Trim();
                            Medical_Data += "\n" + "OOPM (Indv/Family): " + OutOfPocketMax_Individual.Trim() + " / " + OutOfPocketMax_Family.Trim();
                            Medical_Data += "\n" + "Coinsurance: " + Coinsurance.Trim();
                            Medical_Data += "\n" + "Physician Office Visit: " + Physician_Office_Visit.Trim();
                            Medical_Data += "\n" + "Hospitalization: Inpatient (" + Inpatient_Care.Trim() + ") / Outpatient (" + Outpatient_Care.Trim() + ")";
                            Medical_Data += "\n" + "Emergency Room: " + Emergency_Room.Trim();
                            Medical_Data += "\n" + "Retail Rx: " + Generic.Trim() + " / " + Formulary.Trim() + " / " + Non_Formulary.Trim();


                            oWordDoc.Tables[medicalTableNo].Cell(1, 3).Range.Text = Medical_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Domestic Partners Status: ", "Dependent Child Age: ", "Deductible (Indv/Family): ", "OOPM (Indv/Family): ", "Coinsurance: ", "Physician Office Visit: ", "Hospitalization: ", "Emergency Room: ", "Retail Rx: ", "Rates: ", "Contributions:" };
                            //string[] makeBold = new string[] { " ", "Carrier:", "Group#: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Domestic Partners Status: ", "Dependent Child Age: ", "Deductible: ", "OOPM: ", "Coinsurance: ", "Physician Office Visit: ", "Hospitalization: ", "Emergency Room: ", "Retail Rx: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, medicalTableNo);

                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("MEDICAL PLAN TYPE" + medicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                                    }
                                    if (fieldName.Contains("MED_BENEFITSUMMARY" + medicalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                                    }
                                }
                            }
                            #endregion
                            medicalCount++;
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// THIS METHOD WE CALLED FOR STOP LOSS PLAN WRITING 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList"></param>
        /// <param name="SessionId"></param>
        /// <param name="ClientID"></param>
        public void WriteStopLossSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList StopLossBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string SessionId, string ClientID)
        {
            try
            {
                int iTotalFields = 0;
                int stoplossCount = 1;
                string value = string.Empty;
                ////DataTable Emp = new DataTable();
                ////Emp = bp.GetEmployeeData(ClientID);

                #region HashTableStopLoss
                Hashtable HashtableStopLoss = new Hashtable();
                HashtableStopLoss.Add(14, "138");         //Specific Stop Loss - Deductible 
                HashtableStopLoss.Add(15, "25");          //Specific Stop Loss - Aggregating Specific Corridor
                HashtableStopLoss.Add(16, "125");         //Specific Stop Loss - Contract Type
                HashtableStopLoss.Add(17, "61");          //Aggregate Stop Loss - Attachment Level/Corridor
                HashtableStopLoss.Add(18, "124");         //Aggregate Stop Loss - Contract Type
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.StopLoss.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 235)  //Stop Loss
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string StopLoss_Deductible = string.Empty;
                            string StopLoss_Aggregating = string.Empty;
                            string StopLoss_SpeContractType = string.Empty;
                            string StopLoss_Corridor = string.Empty;
                            string StopLoss_AggContractType = string.Empty;
                            int stoplossTableNo = 0;

                            if (stoplossCount == 1)
                            {
                                stoplossTableNo = 23;
                            }
                            if (stoplossCount == 2)
                            {
                                stoplossTableNo = 24;
                            }
                            if (stoplossCount == 3)
                            {
                                stoplossTableNo = 25;
                            }
                            if (stoplossCount == 4)
                            {
                                stoplossTableNo = 26;
                            }
                            if (stoplossCount == 5)
                            {
                                stoplossTableNo = 27;
                            }
                            if (stoplossCount == 6)
                            {
                                stoplossTableNo = 28;
                            }

                            #region Stop Loss Table
                            foreach (int key in HashtableStopLoss.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.StopLoss.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && StopLossBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableStopLoss[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 14: StopLoss_Deductible = value; break;
                                            case 15: StopLoss_Aggregating = value; break;
                                            case 16: StopLoss_SpeContractType = value; break;
                                            case 17: StopLoss_Corridor = value; break;
                                            case 18: StopLoss_AggContractType = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Stop Loss Plan Info writing
                            string StopLoss_Data = "";
                            oWordDoc.Tables[stoplossTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            oWordDoc.Tables[stoplossTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[stoplossTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[stoplossTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");

                            StopLoss_Data = "Specific Deductible: " + StopLoss_Deductible.Trim();
                            StopLoss_Data += "\n" + "Aggregating Specific Corridor: " + StopLoss_Aggregating.Trim();
                            StopLoss_Data += "\n" + "Specific Contract Type: " + StopLoss_SpeContractType.Trim();
                            StopLoss_Data += "\n" + "Aggregate Corridor: " + StopLoss_Corridor.Trim();
                            StopLoss_Data += "\n" + "Aggregate Contract Type: " + StopLoss_AggContractType.Trim();

                            oWordDoc.Tables[stoplossTableNo].Cell(1, 3).Range.Text = StopLoss_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Specific Deductible: ", "Aggregating Specific Corridor: ", "Specific Contract Type: ", "Aggregate Corridor: ", "Aggregate Contract Type: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, stoplossTableNo);

                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("STOPLOSS_PLANTYPE" + stoplossCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                                    }
                                    if (fieldName.Contains("STOPLOSS_BENEFITSUMMARY" + stoplossCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                                    }
                                }
                            }
                            #endregion
                            stoplossCount++;
                        }
                    }//OuterIfClose
                }//ForClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// THIS METHOD IS CALLED FOR PRESCRIPTION DRUG SECTION 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList"></param>
        /// <param name="SessionId"></param>
        /// <param name="ClientID"></param>
        public void WritePrescriptionDrugSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList PrescriptionDrugBenefitColumnIdList, string ClientID)
        {
            try
            {
                int iTotalFields = 0;
                int prescriptionCount = 1;
                string value = string.Empty;

                //DataTable Emp = new DataTable();
                //Emp = bp.GetEmployeeData(ClientID);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.PrescriptionDrug.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["productTypeID"]) == 173)   //Prescription Drug (Carve-Out)
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            int prescriptionTableNo = 0;

                            if (prescriptionCount == 1)
                            {
                                prescriptionTableNo = 29;
                            }
                            if (prescriptionCount == 2)
                            {
                                prescriptionTableNo = 30;
                            }
                            if (prescriptionCount == 3)
                            {
                                prescriptionTableNo = 31;
                            }
                            if (prescriptionCount == 4)
                            {
                                prescriptionTableNo = 32;
                            }
                            if (prescriptionCount == 5)
                            {
                                prescriptionTableNo = 33;
                            }
                            if (prescriptionCount == 6)
                            {
                                prescriptionTableNo = 34;
                            }

                            #region Prescription Medical Plan Info writing
                            oWordDoc.Tables[prescriptionTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            oWordDoc.Tables[prescriptionTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[prescriptionTableNo].Cell(1, 3).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[prescriptionTableNo].Cell(1, 4).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");

                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:" };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, prescriptionTableNo);

                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;
                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("PRESCRIPTION_PLANTYPE" + prescriptionCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]));
                                    }
                                    if (fieldName.Contains("PRESCRIPTION_BENEFITSUMMARY" + prescriptionCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]));
                                    }
                                }
                            }
                            #endregion
                            prescriptionCount++;
                        }
                    }
                }//ForClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLifeADDSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, ArrayList ADDBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                int iTotalFields = 0;
                string value = string.Empty;
                int lifeCount = 1;
                int grouptermCount = 1;
                int addCount = 1;
                DataTable Emp = new DataTable();

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                #region HashtableGroupLifeADDBenifit
                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                HashtableGroupLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(2, "187");     //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(3, "188");     //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(4, "517");     //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(5, "518");     //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(6, "519");     //Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(7, "102");    //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(8, "103");    //Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(9, "104");    //Child(ren)[Overall Maximum] 
                #endregion

                #region HashtableADD
                Hashtable hashTableADDBenifit = new Hashtable();
                hashTableADDBenifit.Add(1, "186");  //Employee [Benefit Amount]
                #endregion


                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    bool containsadd = ProductDS.Tables["ProductTable"].AsEnumerable().Any(row => row.Field<Int32>("productTypeID") == 270);
                    string FundingType = "";

                    int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                    int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);

                    switch (OptionFieldValueiD)
                    {
                        case 52403: FundingType = "Self Funded"; break;
                        case 52401: FundingType = "Fully Insured"; break;
                        case 52400: FundingType = ""; break;
                        default: FundingType = ""; break;
                    }

                    if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.LifeADDLOC))
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                string Emp_Benefit = string.Empty;
                                string Emp_GuaranteeAmt = string.Empty;
                                string Emp_Overall = string.Empty;
                                string Spouse_Benefit = string.Empty;
                                string Spouse_GuaranteeAmt = string.Empty;
                                string Spouse_Overall = string.Empty;
                                string Child_Benefit = string.Empty;
                                string Child_GuaranteeAmt = string.Empty;
                                string Child_Overall = string.Empty;
                                int lifeTableNo = 0;

                                if (lifeCount == 1)
                                {
                                    lifeTableNo = 59;
                                }
                                if (lifeCount == 2)
                                {
                                    lifeTableNo = 60;
                                }
                                if (lifeCount == 3)
                                {
                                    lifeTableNo = 61;
                                }
                                if (lifeCount == 4)
                                {
                                    lifeTableNo = 62;
                                }
                                if (lifeCount == 5)
                                {
                                    lifeTableNo = 63;
                                }
                                if (lifeCount == 6)
                                {
                                    lifeTableNo = 64;
                                }
                                DataTable EligibilityDS = new DataTable();

                                if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                                {
                                    int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                    EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                                }

                                #region LifeADDBenifitTable

                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: if (value.Trim() != string.Empty) { Emp_Benefit = value; } break;
                                                case 2: if (value.Trim() != string.Empty) { Emp_GuaranteeAmt = value; } break;
                                                case 3: if (value.Trim() != string.Empty) { Emp_Overall = value; } break;
                                                case 4: if (value.Trim() != string.Empty) { Spouse_Benefit = value; } break;
                                                case 5: if (value.Trim() != string.Empty) { Spouse_GuaranteeAmt = value; } break;
                                                case 6: if (value.Trim() != string.Empty) { Spouse_Overall = value; } break;
                                                case 7: if (value.Trim() != string.Empty) { Child_Benefit = value; } break;
                                                case 8: if (value.Trim() != string.Empty) { Child_GuaranteeAmt = value; } break;
                                                case 9: if (value.Trim() != string.Empty) { Child_Overall = value; } break;
                                            }
                                        }
                                    }
                                }
                                //if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().ToLower() != cv.LifeADDLOC.ToLower())
                                //{
                                //    //oWordDoc.Tables[6].Rows[16].Delete();
                                //    //oWordDoc.Tables[6].Rows[15].Delete();
                                //    //oWordDoc.Tables[6].Rows[14].Delete();
                                //}
                                #endregion
                                #region Life Plan Info writing
                                string Life_Data = "";
                                oWordDoc.Tables[lifeTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]).Replace("&amp;", "&");
                                oWordDoc.Tables[lifeTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                                oWordDoc.Tables[lifeTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                                oWordDoc.Tables[lifeTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                                oWordDoc.Tables[lifeTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                                oWordDoc.Tables[lifeTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                                if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                                {
                                    string DefinationOf_eligible_Emplyee = " ";
                                    /***************commented by amogh ***/
                                    ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                    ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                    ////                             select product;
                                    ////foreach (DataRow Def_Eligible_Emp in query)
                                    ////{
                                    ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                    ////}
                                    //  oWordDoc.Tables[lifeTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                    IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                                 where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                                 select product;
                                    foreach (DataRow Def_Eligible_Emp in query)
                                    {
                                        DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                    }
                                    oWordDoc.Tables[lifeTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                }

                                Life_Data = "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:";
                                Life_Data += "\n" + "• Employee: " + Emp_Benefit.Trim() + " / " + Emp_GuaranteeAmt.Trim() + " / " + Emp_Overall.Trim();
                                Life_Data += "\n" + "• Spouse: " + Spouse_Benefit.Trim() + " / " + Spouse_GuaranteeAmt.Trim() + " / " + Spouse_Overall.Trim();
                                Life_Data += "\n" + "• Child(ren): " + Child_Benefit.Trim() + " / " + Child_GuaranteeAmt.Trim() + " / " + Child_Overall.Trim();

                                oWordDoc.Tables[lifeTableNo].Cell(1, 3).Range.Text = Life_Data;
                                string[] makeBold = new string[] { " ", "Carrier:", "Group #:", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:", "Employee: ", "Spouse: ", "Child(ren): " };
                                sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, lifeTableNo);

                                #endregion
                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("LIFEPLANTYPE" + lifeCount))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]).Replace("&amp;", "&"));
                                        }
                                        if (fieldName.Contains("LIFEBENEFITNAME" + lifeCount))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&"));
                                        }
                                    }
                                }
                                #endregion
                                lifeCount++;
                            }
                        }
                    }
                    else if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.GroupTermLifePlanType_CommonCriteria))
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                string Emp_Benefit = string.Empty;
                                string Emp_GuaranteeAmt = string.Empty;
                                string Emp_Overall = string.Empty;
                                string Spouse_Benefit = string.Empty;
                                string Spouse_GuaranteeAmt = string.Empty;
                                string Spouse_Overall = string.Empty;
                                string Child_Benefit = string.Empty;
                                string Child_GuaranteeAmt = string.Empty;
                                string Child_Overall = string.Empty;
                                int grouptermTableNo = 0;

                                if (grouptermCount == 1)
                                {
                                    grouptermTableNo = 71;
                                }
                                if (grouptermCount == 2)
                                {
                                    grouptermTableNo = 72;
                                }
                                if (grouptermCount == 3)
                                {
                                    grouptermTableNo = 73;
                                }
                                if (grouptermCount == 4)
                                {
                                    grouptermTableNo = 74;
                                }
                                if (grouptermCount == 5)
                                {
                                    grouptermTableNo = 75;
                                }
                                if (grouptermCount == 6)
                                {
                                    grouptermTableNo = 76;
                                }
                                DataTable EligibilityDS = new DataTable();

                                if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                                {
                                    int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                    EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                                }

                                #region GroupLifeADDBenifitTable

                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: if (value.Trim() != string.Empty) { Emp_Benefit = value; } break;
                                                case 2: if (value.Trim() != string.Empty) { Emp_GuaranteeAmt = value; } break;
                                                case 3: if (value.Trim() != string.Empty) { Emp_Overall = value; } break;
                                                case 4: if (value.Trim() != string.Empty) { Spouse_Benefit = value; } break;
                                                case 5: if (value.Trim() != string.Empty) { Spouse_GuaranteeAmt = value; } break;
                                                case 6: if (value.Trim() != string.Empty) { Spouse_Overall = value; } break;
                                                case 7: if (value.Trim() != string.Empty) { Child_Benefit = value; } break;
                                                case 8: if (value.Trim() != string.Empty) { Child_GuaranteeAmt = value; } break;
                                                case 9: if (value.Trim() != string.Empty) { Child_Overall = value; } break;
                                            }
                                        }
                                    }
                                }
                                #endregion
                                #region Group Term Plan Info writing
                                string Group_Term_Data = "";
                                oWordDoc.Tables[grouptermTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]).Replace("&amp;", "&");
                                oWordDoc.Tables[grouptermTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                                oWordDoc.Tables[grouptermTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                                oWordDoc.Tables[grouptermTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                                oWordDoc.Tables[grouptermTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                                oWordDoc.Tables[grouptermTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                                if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                                {
                                    string DefinationOf_eligible_Emplyee = " ";
                                    //////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                    //////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                    //////                             select product;
                                    //////foreach (DataRow Def_Eligible_Emp in query)
                                    //////{
                                    //////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                    //////}
                                    //oWordDoc.Tables[grouptermTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();

                                    IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                                 where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                                 select product;
                                    foreach (DataRow Def_Eligible_Emp in query)
                                    {
                                        DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                    }
                                    oWordDoc.Tables[grouptermTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                }

                                Group_Term_Data = "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:";
                                Group_Term_Data += "\n" + "• Employee: " + Emp_Benefit.Trim() + " / " + Emp_GuaranteeAmt.Trim() + " / " + Emp_Overall.Trim();
                                Group_Term_Data += "\n" + "• Spouse: " + Spouse_Benefit.Trim() + " / " + Spouse_GuaranteeAmt.Trim() + " / " + Spouse_Overall.Trim();
                                Group_Term_Data += "\n" + "• Child(ren): " + Child_Benefit.Trim() + " / " + Child_GuaranteeAmt.Trim() + " / " + Child_Overall.Trim();

                                oWordDoc.Tables[grouptermTableNo].Cell(1, 3).Range.Text = Group_Term_Data;
                                string[] makeBold = new string[] { " ", "Carrier:", "Group #:", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:", "Employee: ", "Spouse: ", "Child(ren): " };
                                sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, grouptermTableNo);

                                #endregion
                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("GROUPPLANTYPE" + grouptermCount))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]).Replace("&amp;", "&"));
                                        }
                                        if (fieldName.Contains("GROUPBENEFITNAME" + grouptermCount))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&"));
                                        }
                                    }
                                }
                                #endregion
                                grouptermCount++;
                            }
                        }
                    }
                    //else if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.ADNDPlanType_CommonCriteria))
                    else if (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Contains(cv.ADNDPlanType_CommonCriteria) && containsadd)
                    {
                        string ADD_Benefit = string.Empty;
                        int addTableNo = 0;

                        if (addCount == 1)
                        {
                            addTableNo = 65;
                        }
                        if (addCount == 2)
                        {
                            addTableNo = 66;
                        }
                        if (addCount == 3)
                        {
                            addTableNo = 67;
                        }
                        if (addCount == 4)
                        {
                            addTableNo = 68;
                        }
                        if (addCount == 5)
                        {
                            addTableNo = 69;
                        }
                        if (addCount == 6)
                        {
                            addTableNo = 70;
                        }
                        DataTable EligibilityDS = new DataTable();

                        if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                        {
                            int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                            EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                        }

                        #region ADDBenifitTable

                        foreach (int key in hashTableADDBenifit.Keys)
                        {
                            foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            {
                                if (dr["section"].ToString().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableADDBenifit[key].ToString())
                                {
                                    value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    switch (key)
                                    {
                                        case 1: if (value.Trim() != string.Empty) { ADD_Benefit = value; } break;
                                    }
                                }
                            }
                        }
                        #endregion
                        #region ADD Plan Info writing
                        string ADD_Data = "";
                        oWordDoc.Tables[addTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]).Replace("&amp;", "&");
                        oWordDoc.Tables[addTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                        oWordDoc.Tables[addTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[addTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                        oWordDoc.Tables[addTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                        oWordDoc.Tables[addTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                        if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                        {
                            string DefinationOf_eligible_Emplyee = " ";
                            ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                            ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                            ////                             select product;
                            ////foreach (DataRow Def_Eligible_Emp in query)
                            ////{
                            ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                            ////}
                            IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                         where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                         select product;
                            foreach (DataRow Def_Eligible_Emp in query)
                            {
                                DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                            }
                            //oWordDoc.Tables[addTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                            oWordDoc.Tables[addTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                        }

                        ADD_Data = "Employee: " + ADD_Benefit.Trim();

                        oWordDoc.Tables[addTableNo].Cell(1, 3).Range.Text = ADD_Data;
                        string[] makeBold = new string[] { " ", "Carrier:", "Group #:", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Employee:" };
                        sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, addTableNo);

                        #endregion
                        #region merge fields
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("ADDPLANTYPE" + addCount))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]).Replace("&amp;", "&"));
                                }
                                if (fieldName.Contains("ADDBENEFITNAME" + addCount))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&"));
                                }
                            }
                        }
                        #endregion
                        addCount++;
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteMonthlyPremiumSection(Word.Document oWordDoc, Word.Application oWordApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable, DataSet ProductDS)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;
                //(table number - 1 ) for plans
                int medicalCount = 4;
                int limitedmedicalCount = 16;
                int lifeCount = 58;
                int grouptermCount = 70;
                int addCount = 64;
                int DentalCount = 46;
                int VisionCount = 52;
                int STDCount = 88;
                int LTDCount = 94;
                int disability_NJCount = 100;
                int disability_NYCount = 106;
                int disability_HTCount = 112;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    DataTable PremiumTable_Contribution = new DataTable();
                    int premium_row_counter = 0;
                    int premium_Contribution_row_counter = 0;
                    int monthly_premium_row_counter = 0;
                    int monthly_Contribution_col_counter = 0;
                    int rate_column = 0;
                    int contriCount = 1;
                    string Frequency_Of_Contribution = String.Empty;
                    ArrayList arrRateId = new ArrayList();
                    ArrayList arrContributionId = new ArrayList();
                    int Start = 0;
                    int End = 0;
                    int Interval = 0;
                    int PremiumTable_counter = 0;
                    bool containsadd = ProductDS.Tables["ProductTable"].AsEnumerable().Any(row => row.Field<Int32>("productTypeID") == 270);


                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 233)
                    {
                        limitedmedicalCount++;
                        PremiumTable_counter = limitedmedicalCount;
                        monthly_premium_row_counter = 5;
                        monthly_Contribution_col_counter = 5;
                        rate_column = 1;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) != 235 && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) != 233 && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) != 410 && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) != 173)
                    {
                        medicalCount++;
                        PremiumTable_counter = medicalCount;
                        monthly_premium_row_counter = 7;
                        monthly_Contribution_col_counter = 7;
                        rate_column = 1;
                    }
                    else if (PlanTable.Rows[index]["ProductTypeDescription"].ToString().Contains(cv.LifeADDLOC))
                    {
                        lifeCount++;
                        PremiumTable_counter = lifeCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["ProductTypeDescription"].ToString().Contains(cv.GroupTermLifePlanType_CommonCriteria))
                    {
                        grouptermCount++;
                        PremiumTable_counter = grouptermCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        DentalCount++;
                        PremiumTable_counter = DentalCount;
                        monthly_premium_row_counter = 7; //rate
                        monthly_Contribution_col_counter = 7;//contribution
                        rate_column = 1;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        VisionCount++;
                        PremiumTable_counter = VisionCount;
                        monthly_premium_row_counter = 7; //rate
                        monthly_Contribution_col_counter = 7;//contribution
                        rate_column = 1;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        STDCount++;
                        PremiumTable_counter = STDCount;
                        monthly_premium_row_counter = 4; //rate
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        LTDCount++;
                        PremiumTable_counter = LTDCount;
                        monthly_premium_row_counter = 4; //rate
                        rate_column = 2;
                    }
                    else if (containsadd)
                    {
                        addCount++;
                        PremiumTable_counter = addCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 292) // Disability New York
                    {
                        disability_NYCount++;
                        PremiumTable_counter = disability_NYCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 293) //Disability New Jersey
                    {
                        disability_NJCount++;
                        PremiumTable_counter = disability_NJCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }
                    else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 294) //Disability Hawaii
                    {
                        disability_HTCount++;
                        PremiumTable_counter = disability_HTCount;
                        monthly_premium_row_counter = 4;
                        rate_column = 2;
                    }

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                    PremiumTable_Contribution.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable_Contribution.Columns.Add("contributionTierID", typeof(Int16));
                    PremiumTable_Contribution.Columns.Add("contributionTier_description", typeof(string));
                    PremiumTable_Contribution.Columns.Add("monthlycost", typeof(string));
                    PremiumTable_Contribution.Columns.Add("contributioncost", typeof(string));
                    PremiumTable_Contribution.Columns.Add("summaryname", typeof(string));
                    PremiumTable_Contribution.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable_Contribution.Columns.Add("contributionid", typeof(string));
                    PremiumTable_Contribution.Columns.Add("rateid", typeof(string));
                    PremiumTable_Contribution.Columns.Add("contributionFieldValueID", typeof(string));
                    PremiumTable_Contribution.Columns.Add("ageBandIndex", typeof(int));
                    StringBuilder ratebuilder = new StringBuilder();

                    //int iTotalFields = 0;
                    #endregion
                    #region Rate
                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"] && Convert.ToInt32(PlanTable.Rows[index]["RateID"]) != -1)
                        {
                            if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "fully insured equivalent") && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_summaryID"].ToString()) == int.Parse(PlanTable.Rows[index]["SummaryID"].ToString()))
                            {
                                if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                {
                                    //Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
                                    //End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
                                    //Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
                                    ////  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
                                    //if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
                                    //{
                                    //    PremiumTable.Rows.Add();
                                    //    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    //    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    //    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                    //    {
                                    //        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                    //    }
                                    //    else
                                    //    {
                                    //        PremiumTable.Rows[premium_row_counter][1] = 0;
                                    //    }
                                    //    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    //    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    //    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    //    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    //    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                    //    premium_row_counter++;
                                    //}
                                }
                                else
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                    {
                                        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                    }
                                    else
                                    {
                                        PremiumTable.Rows[premium_row_counter][1] = 0;
                                    }
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                    ////for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                    ////{
                                    ////    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    ////    {
                                    ////        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                    ////        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                    ////        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                    ////        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                    ////        break;
                                    ////    }
                                    ////}
                                    premium_row_counter++;
                                }
                            }
                        }
                    }

                    #endregion
                    #region contribution
                    //new change
                    Boolean flag = false;

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim() || PlanTable.Rows[index]["ContributionId_2"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                        {
                            for (int i = 0; i < PremiumTable_Contribution.Rows.Count; i++)
                            {
                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable_Contribution.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag == false)
                            {
                                PremiumTable_Contribution.Rows.Add();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][3] = "";
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                //PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim();
                                PremiumTable_Contribution.Rows[premium_Contribution_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString();
                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                //break;
                                premium_Contribution_row_counter++;
                            }
                        }
                    }
                    //end change
                    #endregion
                    #region AddTable

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateID] , [rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt;

                    DataTable dt1 = new DataTable();

                    //  PremiumTable_Contribution.DefaultView.Sort = "[contributionid] , [contributionTierID] asc";
                    dt1 = PremiumTable_Contribution.DefaultView.ToTable(true);
                    PremiumTable_Contribution = dt1;

                    #endregion
                    #region FillTable Rate

                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                    {
                        if (!arrRateId.Contains(PremiumTable.Rows[i]["rateid"].ToString()))
                        {
                            arrRateId.Add(PremiumTable.Rows[i]["rateid"].ToString());

                            var rateDesriptions = (from a in RateDS.Tables["RateTable"].AsEnumerable()
                                                   where a.Field<Int32>("rateID") == Convert.ToInt32(PremiumTable.Rows[i]["rateid"])
                                                   select a.Field<string>("description")).FirstOrDefault();
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = Convert.ToString(ratebuilder.Append("Rates: " + rateDesriptions.Replace("&amp;", "&")));
                        }
                        //if (!header_created)
                        //{
                        //    ////oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
                        //    ////oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = PlanTable.Rows[index]["ContributionName"].ToString();
                        //    header_created = true;
                        //}

                        if (PremiumTable.Rows[i][1].ToString() == "8")
                        {
                            //if (oWordDoc.Tables[PremiumTable_counter].Cell(2, 1).Range.Text.Replace("\r\a", "") == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                            //{

                            //    //monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
                            //    monthly_premium_row_counter = 7;
                            //    monthly_premium_row_counter++;
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns.Add();
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[3].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[3].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                            //    //oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = PlanTable.Rows[index]["ContributionName_2"].ToString(); 
                            //    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee") + ": " + "$" + PremiumTable.Rows[i][3].ToString();
                            //    //oWordDoc.Tables[PremiumTable_counter].PreferredWidth = oWordApp.InchesToPoints(7.01f);

                            //}
                            //else
                            //{
                            //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                            //monthly_premium_row_counter = 7;
                            monthly_premium_row_counter++;
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee") + ": " + "$" + Convert.ToString(PremiumTable.Rows[i][3]);
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee") + ": " + "$" + String.Format("{0:#.00}", Convert.ToDouble(PremiumTable.Rows[i][3]));
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            //oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(3.9f);
                            //}
                        }
                        else
                        {
                            if ((PlanTable.Rows[index]["ProductTypeDescription"].ToString().Contains(cv.LifeADDLOC)) || (PlanTable.Rows[index]["ProductTypeDescription"].ToString().Contains(cv.GroupTermLifePlanType_CommonCriteria)) || (PlanTable.Rows[index]["ProductTypeDescription"].ToString().Contains(cv.ADNDPlanType_CommonCriteria) && containsadd) || PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() || PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() || (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 292) || (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 293) || (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 294))
                            {
                                //    //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                //    monthly_premium_row_counter++;
                                //    //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                //    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString() + ": " + "$" + PremiumTable.Rows[i][3].ToString();
                                //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                //monthly_premium_row_counter++;
                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = Convert.ToString(ratebuilder.Append("\n" + PremiumTable.Rows[i][2].ToString() + ": " + "$" + Convert.ToString(PremiumTable.Rows[i][3])));
                                if ((Convert.ToDecimal(PremiumTable.Rows[i][3]) % 1) == 0)
                                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = Convert.ToString(ratebuilder.Append("\n" + PremiumTable.Rows[i][2].ToString() + ": " + "$" + String.Format("{0:#.00}", Convert.ToDouble(PremiumTable.Rows[i][3]))));
                                else
                                    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = Convert.ToString(ratebuilder.Append("\n" + PremiumTable.Rows[i][2].ToString() + ": " + "$" + Convert.ToString(PremiumTable.Rows[i][3])));
                            }
                            else
                            {
                                oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                                monthly_premium_row_counter++;
                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString() + ": " + "$" + Convert.ToString(PremiumTable.Rows[i][3]);
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, rate_column).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString() + ": " + "$" + String.Format("{0:#.00}", Convert.ToDouble(PremiumTable.Rows[i][3]));
                                //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            }
                        }
                    }

                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                    {
                        string[] makeBold = new string[] { " ", "Rates:" };
                        sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, PremiumTable_counter);
                    }

                    #endregion
                    #region FillTable Contribution

                    for (int i = 0; i < PremiumTable_Contribution.DefaultView.ToTable(true, "contributionFieldValueID").Rows.Count; i++)
                    {
                        if (!arrContributionId.Contains(PremiumTable_Contribution.Rows[i]["contributionid"].ToString()))
                        {
                            arrContributionId.Add(PremiumTable_Contribution.Rows[i]["contributionid"].ToString());

                            if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[index]["productTypeID"]) == 233)
                            {
                                monthly_Contribution_col_counter = 5;
                            }
                            else if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() || PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() || PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                            {
                                monthly_Contribution_col_counter = 7;
                            }

                            contriCount++;
                            var ContriDesriptions = (from a in ContributionDS.Tables["contributionTable"].AsEnumerable()
                                                     where a.Field<Int32>("contributionid") == Convert.ToInt32(PremiumTable_Contribution.Rows[i]["contributionid"])
                                                     select a.Field<string>("description")).FirstOrDefault();
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, contriCount).Range.Text = "Contributions: " + ContriDesriptions.Replace("&amp;", "&");
                            //string[] makeBold1 = new string[] { " ", "Contributions:", "Contributions:" };
                            //sd.makeboldtabletext(oWordDoc, oWordApp, makeBold1, PremiumTable_counter);
                        }
                        if (Convert.ToString(PremiumTable_Contribution.Rows[i][1]) == "8")
                        {
                            //if (oWordDoc.Tables[PremiumTable_counter].Cell(2, 1).Range.Text.Replace("\r\a", "") == PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee"))
                            //{

                            //    //monthly_premium_row_counter = Convert.ToInt32(((dynamic)oRngC).Row);
                            //    monthly_Contribution_col_counter = 7;
                            //    monthly_Contribution_col_counter++;
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns.Add();
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[3].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(1.95f);
                            //    //oWordDoc.Tables[PremiumTable_counter].Columns[3].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                            //    //oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = PlanTable.Rows[index]["ContributionName_2"].ToString(); 
                            //    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, 3).Range.Text = PremiumTable_Contribution.Rows[i][2].ToString().Replace("EE", "Employee") + ": " + "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                            //    //oWordDoc.Tables[PremiumTable_counter].PreferredWidth = oWordApp.InchesToPoints(7.01f);

                            //}
                            //else
                            //{
                            //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                            //monthly_Contribution_col_counter = 7;
                            monthly_Contribution_col_counter++;
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, contriCount).Range.Text = Convert.ToString(PremiumTable_Contribution.Rows[i][2]).Replace("EE", "Employee") + ": " + "$" + Convert.ToString(PremiumTable_Contribution.Rows[i][4]);
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, contriCount).Range.Text = Convert.ToString(PremiumTable_Contribution.Rows[i][2]).Replace("EE", "Employee") + ": " + "$" + String.Format("{0:#.00}", Convert.ToDouble(PremiumTable_Contribution.Rows[i][4]));
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            //oWordDoc.Tables[PremiumTable_counter].Columns[2].PreferredWidth = oWordApp.InchesToPoints(3.9f);
                            //}
                        }
                        else
                        {
                            //if (oWordDoc.Tables[PremiumTable_counter].Cell((monthly_Contribution_col_counter + 1), 1).Range.Text.Replace("\r\a", "") == "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString())
                            //{
                            //    //oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                            //    monthly_Contribution_col_counter++;
                            //    //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
                            //    oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, 3).Range.Text = "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString() + ": " + "$" + PremiumTable_Contribution.Rows[i][4].ToString();
                            //}
                            if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count == 0 && arrContributionId[0].ToString() == PremiumTable_Contribution.Rows[i]["contributionid"].ToString())
                            {
                                oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                            }
                            monthly_Contribution_col_counter++;
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, contriCount).Range.Text = "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString() + ": " + "$" + Convert.ToString(PremiumTable_Contribution.Rows[i][4]);
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_Contribution_col_counter, contriCount).Range.Text = "Employee & " + PremiumTable_Contribution.Rows[i][2].ToString() + ": " + "$" + String.Format("{0:#.00}", Convert.ToDouble(PremiumTable_Contribution.Rows[i][4]));
                            //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                            //}
                        }
                    }

                    #endregion
                }
                //oWordDoc.Tables[PremiumTable_counter].Delete();
                //PremiumTable_counter = PremiumTable_counter - 1;
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life * Voluntary AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeADDSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;


                DataTable Emp = new DataTable();
                SummaryDetail sd = new SummaryDetail();
                sd.BuildEligibilityRuleTable();

                int VoluntaryLifeTableNo = 77;
                int VoluntaryLifeCount = 1; //For 6 different Voluntary plans
                int VoluntaryADnDTableNo = 83;
                int VoluntaryADnDLifeCount = 1; //For 6 different Voluntary AD&D plans

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(7, "516");//Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(8, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(9, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(11, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(13, "103"); //Child(ren)[Guarantee Issue Amount]

                ////HashtableVoluntaryLifeADDBenifit.Add(14, "2");//age--
                ////HashtableVoluntaryLifeADDBenifit.Add(15, "3");//age
                ////HashtableVoluntaryLifeADDBenifit.Add(16, "4");//age
                ////HashtableVoluntaryLifeADDBenifit.Add(17, "5");//age
                #endregion

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.VoluntaryLifeADDLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 260)
                    {
                        /*********************** Voluntary Life - 260 ***********************/
                        #region Veriable Decleration
                        string FundingType = string.Empty;
                        string Employee_BenefitAmount = string.Empty;
                        string Employee_OverallMaximum = string.Empty;
                        string Employee_GuaranteeIssueAmount = string.Empty;

                        string Spouse_BenefitAmount = string.Empty;
                        string Spouse_OverallMaximum = string.Empty;
                        string Spouse_GuaranteeIssueAmount = string.Empty;

                        string Child_BenefitAmount = string.Empty;
                        string Child_OverallMaximum = string.Empty;
                        string Child_GuaranteeIssueAmount = string.Empty;

                        string VoluntoryLife_SummaryName = string.Empty;
                        string VoluntoryLife_PlanType = string.Empty;

                        #endregion

                        if (VoluntaryLifeCount == 1)
                        {
                            VoluntaryLifeTableNo = 77;
                        }
                        if (VoluntaryLifeCount == 2)
                        {
                            VoluntaryLifeTableNo = 78;
                        }
                        if (VoluntaryLifeCount == 3)
                        {
                            VoluntaryLifeTableNo = 79;
                        }
                        if (VoluntaryLifeCount == 4)
                        {
                            VoluntaryLifeTableNo = 80;
                        }
                        if (VoluntaryLifeCount == 5)
                        {
                            VoluntaryLifeTableNo = 81;
                        }
                        if (VoluntaryLifeCount == 6)
                        {
                            VoluntaryLifeTableNo = 82;
                        }
                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            VoluntoryLife_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            VoluntoryLife_PlanType = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();

                            DataTable EligibilityDS = new DataTable();
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            #region VoluntaryTable
                            string value = string.Empty;
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (Convert.ToString(dr["section"]).ToLower().Trim() == cv.VoluntaryLifeADDLOC.ToLower().Trim() && Convert.ToString(dr["benefitSummaryID"]) == Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"]) && VoluntaryLifeBenefitColumnIdList.Contains(Convert.ToString(dr["benefitColumnID"])) && Convert.ToString(dr["attributeID"]) == Convert.ToString(HashtableVoluntaryLifeADDBenifit[key]))
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();

                                        switch (key)
                                        {
                                            case 3: Employee_BenefitAmount = value; break;
                                            case 4: Employee_OverallMaximum = value; break;
                                            case 5: Employee_GuaranteeIssueAmount = value; break;

                                            case 7: Spouse_BenefitAmount = value; break;
                                            case 8: Spouse_OverallMaximum = value; break;
                                            case 9: Spouse_GuaranteeIssueAmount = value; break;

                                            case 11: Child_BenefitAmount = value; break;
                                            case 12: Child_OverallMaximum = value; break;
                                            case 13: Child_GuaranteeIssueAmount = value; break;
                                        }//SwitchClose
                                    }//IfClose
                                }
                            }
                            #endregion

                            #region Voluntary Life Plan Info writing

                            string Voluntary_Life = "";
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType.Trim();
                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[VoluntaryLifeTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[VoluntaryLifeTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }
                            Voluntary_Life = "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:";
                            Voluntary_Life += "\n" + "• Employee: " + Employee_BenefitAmount.Trim() + " / " + Employee_GuaranteeIssueAmount.Trim() + " / " + Employee_OverallMaximum.Trim();
                            Voluntary_Life += "\n" + "• Spouse: " + Spouse_BenefitAmount.Trim() + " / " + Spouse_GuaranteeIssueAmount.Trim() + " / " + Spouse_OverallMaximum.Trim();
                            Voluntary_Life += "\n" + "• Child(ren): " + Child_BenefitAmount.Trim() + " / " + Child_GuaranteeIssueAmount.Trim() + " / " + Child_OverallMaximum.Trim();


                            oWordDoc.Tables[VoluntaryLifeTableNo].Cell(1, 3).Range.Text = Voluntary_Life;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:", "Eligibility: ", "Employee: ", "Spouse:", "Child(ren):" };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, VoluntaryLifeTableNo);

                            #endregion


                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VOLUNTARYLIFE PLAN TYPE" + VoluntaryLifeCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Replace("&amp;", "&").Trim());
                                    }
                                    if (fieldName.Contains("VOLUNTARYLIFEBENEFITSUMMERY" + VoluntaryLifeCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Replace("&amp;", "&").Trim());
                                    }

                                }
                            }
                            #endregion
                            VoluntaryLifeCount++;
                        }
                    }
                    else if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.VoluntaryLifeADDLOC.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 280)
                    {
                        /**********************Voluntary AD&D- 280 ***********************/
                        #region Veriable Decleration
                        string FundingType = string.Empty;
                        string Employee_BenefitAmount = string.Empty;
                        string Employee_OverallMaximum = string.Empty;
                        string Employee_GuaranteeIssueAmount = string.Empty;

                        string Spouse_BenefitAmount = string.Empty;
                        string Spouse_OverallMaximum = string.Empty;
                        string Spouse_GuaranteeIssueAmount = string.Empty;

                        string Child_BenefitAmount = string.Empty;
                        string Child_OverallMaximum = string.Empty;
                        string Child_GuaranteeIssueAmount = string.Empty;

                        string VoluntoryLife_SummaryName = string.Empty;
                        string VoluntoryLife_PlanType = string.Empty;

                        #endregion

                        if (VoluntaryADnDLifeCount == 1)
                        {
                            VoluntaryADnDTableNo = 83;
                        }
                        if (VoluntaryADnDLifeCount == 2)
                        {
                            VoluntaryADnDTableNo = 84;
                        }
                        if (VoluntaryADnDLifeCount == 3)
                        {
                            VoluntaryADnDTableNo = 85;
                        }
                        if (VoluntaryADnDLifeCount == 4)
                        {
                            VoluntaryADnDTableNo = 86;
                        }
                        if (VoluntaryADnDLifeCount == 5)
                        {
                            VoluntaryADnDTableNo = 87;
                        }
                        if (VoluntaryADnDLifeCount == 6)
                        {
                            VoluntaryADnDTableNo = 88;
                        }

                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            VoluntoryLife_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            VoluntoryLife_PlanType = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();

                            DataTable EligibilityDS = new DataTable();
                            //int EleigibilityRuleId = 2849011;
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            #region VoluntaryTable
                            string value = string.Empty;
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VoluntaryLifeADDLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 3: Employee_BenefitAmount = value; break;
                                            case 4: Employee_OverallMaximum = value; break;
                                            case 5: Employee_GuaranteeIssueAmount = value; break;

                                            case 7: Spouse_BenefitAmount = value; break;
                                            case 8: Spouse_OverallMaximum = value; break;
                                            case 9: Spouse_GuaranteeIssueAmount = value; break;

                                            case 11: Child_BenefitAmount = value; break;
                                            case 12: Child_OverallMaximum = value; break;
                                            case 13: Child_GuaranteeIssueAmount = value; break;
                                        }//SwitchClose
                                    }//IfClose
                                }
                            }
                            #endregion

                            #region Voluntary AD&D Plan Info writing

                            string Voluntary_ADnD = "";
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType.Trim();
                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[VoluntaryADnDTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[VoluntaryADnDTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }

                            Voluntary_ADnD = "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:";
                            Voluntary_ADnD += "\n" + "• Employee: " + Employee_BenefitAmount.Trim() + " / " + Employee_GuaranteeIssueAmount.Trim() + " / " + Employee_OverallMaximum.Trim();
                            Voluntary_ADnD += "\n" + "• Spouse: " + Spouse_BenefitAmount.Trim() + " / " + Spouse_GuaranteeIssueAmount.Trim() + " / " + Spouse_OverallMaximum.Trim();
                            Voluntary_ADnD += "\n" + "• Child(ren): " + Child_BenefitAmount.Trim() + " / " + Child_GuaranteeIssueAmount.Trim() + " / " + Child_OverallMaximum.Trim();

                            oWordDoc.Tables[VoluntaryADnDTableNo].Cell(1, 3).Range.Text = Voluntary_ADnD;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Benefit Amount / Guarantee Issue Amount / Benefit Maximum:", "Employee: ", "Spouse:", "Child(ren):" };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, VoluntaryADnDTableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VOLUNTARYADND PLAN TYPE" + VoluntaryADnDLifeCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Replace("&amp;", "&"));
                                    }
                                    if (fieldName.Contains("VOLUNTARYADNDBENEFITNAME" + VoluntaryADnDLifeCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Replace("&amp;", "&"));
                                    }

                                }
                            }
                            #endregion
                            VoluntaryADnDLifeCount++;
                        }

                    }//
                }//forLoopHere 
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Method for Disability 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="AccidentalBenefitColumnIdList"></param>
        /// <param name="SessionId"></param>
        public void WriteDisabilitySection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DisabilityBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                ArrayList arrCarrierName = new ArrayList();
                int iTotalFields = 0;

                DataTable Emp = new DataTable();
                SummaryDetail sd = new SummaryDetail();
                sd.BuildEligibilityRuleTable();

                int Disability_NJTableNo = 101;
                int Disability_NJCount = 1; //For 6 different Disability plans

                int Disability_NYTableNo = 107;
                int Disability_NYCount = 1; //For 6 different Disability plans

                int Disability_HTTableNo = 113;
                int Disability_HTCount = 1; //For 6 different dental plans

                #region HashtableDisability
                Hashtable hashTableDisability = new Hashtable();
                hashTableDisability.Add(1, "8");       //Accident Elimination Period - 8 rence
                hashTableDisability.Add(2, "505");     //Elimination Period[Sickness] -505
                hashTableDisability.Add(3, "350");     //Maximum Period of Payment -350
                hashTableDisability.Add(4, "569");     //Weekly Benefit Maximum - 569
                hashTableDisability.Add(5, "252");     //Hospitalization -- 252
                #endregion

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    /******************  New York DBL ********************/
                    if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 292)
                    {
                        string FundingType = string.Empty;
                        if (Disability_NYCount == 1)
                        {
                            Disability_NYTableNo = 107;
                        }
                        if (Disability_NYCount == 2)
                        {
                            Disability_NYTableNo = 108;
                        }
                        if (Disability_NYCount == 3)
                        {
                            Disability_NYTableNo = 109;
                        }
                        if (Disability_NYCount == 4)
                        {
                            Disability_NYTableNo = 110;
                        }
                        if (Disability_NYCount == 5)
                        {
                            Disability_NYTableNo = 111;
                        }
                        if (Disability_NYCount == 6)
                        {
                            Disability_NYTableNo = 112;
                        }

                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (Convert.ToString(PlanTable.Rows[rowindex]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"]))
                        {
                            #region Variable Decleration

                            string accidentEliminationPeriod = string.Empty;
                            string sicknessEliminationPeriod = string.Empty;
                            string hospitalization = string.Empty;
                            string weeklyBenefitMaximum = string.Empty;
                            string maximumPeriodofPayment = string.Empty;

                            string carrier = string.Empty;
                            string group = string.Empty;
                            string effectiveDate = string.Empty;
                            string renewalDate = string.Empty;
                            string eligibleEmployees = string.Empty;

                            string Carrier = "";
                            string OldCarrier = "";
                            string value = string.Empty;
                            string Disability_SummaryName = string.Empty;
                            string Disability_PlanType = string.Empty;

                            #endregion

                            Disability_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            Disability_PlanType = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();

                            DataTable EligibilityDS = new DataTable();
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            #region HashRotation

                            foreach (int key in hashTableDisability.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DisabilityBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableDisability[key].ToString())
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                accidentEliminationPeriod = value; break;
                                            case 2:
                                                sicknessEliminationPeriod = value; break;
                                            case 3:
                                                //maximumPeriodofPayment = value; break;
                                                maximumPeriodofPayment = value + " " + Convert.ToString(dr["UOM"]); break;   // As Per Nicole [Account Profile-Detailed - Issue #24 - Include unit of measure]
                                            case 4:
                                                weeklyBenefitMaximum = value; break;
                                            case 5:
                                                hospitalization = value; break;

                                        }//SwicthClose
                                    }
                                }//InnerForEachClose
                            }//OuterForEachClose
                            #endregion

                            #region Disability Plan Info writing

                            string DisablityNY_Data = "";
                            oWordDoc.Tables[Disability_NYTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);

                            oWordDoc.Tables[Disability_NYTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[Disability_NYTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_NYTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_NYTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType.Trim();
                            oWordDoc.Tables[Disability_NYTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[Disability_NYTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[Disability_NYTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }
                            DisablityNY_Data = "Accident Elimination Period: " + accidentEliminationPeriod.Trim();
                            DisablityNY_Data += "\n" + "Sickness Elimination Period: " + sicknessEliminationPeriod.Trim();
                            DisablityNY_Data += "\n" + "Hospitalization: " + hospitalization.Trim();
                            DisablityNY_Data += "\n" + "Weekly Benefit Maximum: " + weeklyBenefitMaximum.Trim();
                            DisablityNY_Data += "\n" + "Maximum Period of Payment: " + maximumPeriodofPayment.Trim();

                            oWordDoc.Tables[Disability_NYTableNo].Cell(1, 3).Range.Text = DisablityNY_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Accident Elimination Period: ", "Sickness Elimination Period: ", "Hospitalization: ", "Weekly Benefit Maximum: ", "Maximum Period of Payment: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, Disability_NYTableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("DISABILITY_NY_PLAN TYPE" + Disability_NYCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim());
                                    }

                                    if (fieldName.Contains("DISABILITY_NY_BENEFITNAME" + Disability_NYCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Trim());
                                    }


                                }
                            }
                            #endregion
                            Disability_NYCount++;
                        }//OuterIF
                    }
                    else if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 293)
                    {
                        /******************  New Jersey TDB ********************/
                        #region Variable Decleration

                        string accidentEliminationPeriod = string.Empty;
                        string sicknessEliminationPeriod = string.Empty;
                        string hospitalization = string.Empty;
                        string weeklyBenefitMaximum = string.Empty;
                        string maximumPeriodofPayment = string.Empty;

                        string carrier = string.Empty;
                        string group = string.Empty;
                        string effectiveDate = string.Empty;
                        string renewalDate = string.Empty;
                        string eligibleEmployees = string.Empty;
                        string FundingType = string.Empty;

                        string value = string.Empty;
                        string Disability_SummaryName = string.Empty;
                        string Disability_PlanType = string.Empty;

                        #endregion

                        if (Disability_NJCount == 1)
                        {
                            Disability_NJTableNo = 101;
                        }
                        if (Disability_NJCount == 2)
                        {
                            Disability_NJTableNo = 102;
                        }
                        if (Disability_NJCount == 3)
                        {
                            Disability_NJTableNo = 103;
                        }
                        if (Disability_NJCount == 4)
                        {
                            Disability_NJTableNo = 104;
                        }
                        if (Disability_NJCount == 5)
                        {
                            Disability_NJTableNo = 105;
                        }
                        if (Disability_NJCount == 6)
                        {
                            Disability_NJTableNo = 106;
                        }

                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }
                        if (Convert.ToString(PlanTable.Rows[rowindex]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"]))
                        {
                            Disability_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            Disability_PlanType = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();

                            DataTable EligibilityDS = new DataTable();
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            #region HashRotation

                            foreach (int key in hashTableDisability.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DisabilityBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableDisability[key].ToString())
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                accidentEliminationPeriod = value; break;
                                            case 2:
                                                sicknessEliminationPeriod = value; break;
                                            case 3:
                                                //maximumPeriodofPayment = value; break;
                                                maximumPeriodofPayment = value + " " + Convert.ToString(dr["UOM"]); break;   // As Per Nicole [Account Profile-Detailed - Issue #24 - Include unit of measure]
                                            case 4:
                                                weeklyBenefitMaximum = value; break;
                                            case 5:
                                                hospitalization = value; break;

                                        }//SwicthClose
                                    }
                                }//InnerForEachClose
                            }//OuterForEachClose
                            #endregion

                            #region Disability Plan Info writing

                            string DisablityNJ_Data = "";
                            oWordDoc.Tables[Disability_NJTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);

                            oWordDoc.Tables[Disability_NJTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[Disability_NJTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_NJTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_NJTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType.Trim();
                            oWordDoc.Tables[Disability_NJTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[Disability_NJTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[Disability_NJTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }

                            DisablityNJ_Data = "Accident Elimination Period: " + accidentEliminationPeriod.Trim();
                            DisablityNJ_Data += "\n" + "Sickness Elimination Period: " + sicknessEliminationPeriod.Trim();
                            DisablityNJ_Data += "\n" + "Hospitalization: " + hospitalization.Trim();
                            DisablityNJ_Data += "\n" + "Weekly Benefit Maximum: " + weeklyBenefitMaximum.Trim();
                            DisablityNJ_Data += "\n" + "Maximum Period of Payment: " + maximumPeriodofPayment.Trim();

                            oWordDoc.Tables[Disability_NJTableNo].Cell(1, 3).Range.Text = DisablityNJ_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Accident Elimination Period: ", "Sickness Elimination Period: ", "Hospitalization: ", "Weekly Benefit Maximum: ", "Maximum Period of Payment: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, Disability_NJTableNo);

                            #endregion


                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();


                                    if (fieldName.Contains("DISABILITY_NJ_PLAN TYPE" + Disability_NJCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim());
                                    }
                                    if (fieldName.Contains("DISABILITY_NJ_BENEFITNAME" + Disability_NJCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Trim());
                                    }

                                }
                            }
                            #endregion
                            Disability_NJCount++;
                        }
                    }
                    else if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.Disability.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 294)
                    {
                        /******************  Hawaii TDI ********************/
                        #region Variable Decleration

                        string accidentEliminationPeriod = string.Empty;
                        string sicknessEliminationPeriod = string.Empty;
                        string hospitalization = string.Empty;
                        string weeklyBenefitMaximum = string.Empty;
                        string maximumPeriodofPayment = string.Empty;

                        string carrier = string.Empty;
                        string group = string.Empty;
                        string effectiveDate = string.Empty;
                        string renewalDate = string.Empty;
                        string eligibleEmployees = string.Empty;
                        string FundingType = string.Empty;

                        string value = string.Empty;
                        string Disability_SummaryName = string.Empty;
                        string Disability_PlanType = string.Empty;

                        #endregion

                        if (Disability_HTCount == 1)
                        {
                            Disability_HTTableNo = 113;
                        }
                        if (Disability_HTCount == 2)
                        {
                            Disability_HTTableNo = 114;
                        }
                        if (Disability_HTCount == 3)
                        {
                            Disability_HTTableNo = 115;
                        }
                        if (Disability_HTCount == 4)
                        {
                            Disability_HTTableNo = 116;
                        }
                        if (Disability_HTCount == 5)
                        {
                            Disability_HTTableNo = 117;
                        }
                        if (Disability_HTCount == 6)
                        {
                            Disability_HTTableNo = 118;
                        }
                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (Convert.ToString(PlanTable.Rows[rowindex]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"]))
                        {
                            Disability_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            Disability_PlanType = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();

                            DataTable EligibilityDS = new DataTable();
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }



                            #region HashRotation

                            foreach (int key in hashTableDisability.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.Disability.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DisabilityBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableDisability[key].ToString())
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                accidentEliminationPeriod = value; break;
                                            case 2:
                                                sicknessEliminationPeriod = value; break;
                                            case 3:
                                                //maximumPeriodofPayment = value; break;
                                                maximumPeriodofPayment = value + " " + Convert.ToString(dr["UOM"]); break;   // As Per Nicole [Account Profile-Detailed - Issue #24 - Include unit of measure]
                                            case 4:
                                                weeklyBenefitMaximum = value; break;
                                            case 5:
                                                hospitalization = value; break;

                                        }//SwicthClose
                                    }
                                }//InnerForEachClose
                            }//OuterForEachClose
                            #endregion

                            #region Disability Plan Info writing

                            string DisablityHT_Data = "";
                            oWordDoc.Tables[Disability_HTTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);

                            oWordDoc.Tables[Disability_HTTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[Disability_HTTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_HTTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[Disability_HTTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[Disability_HTTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                //////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                //////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                //////                             select product;
                                //////foreach (DataRow Def_Eligible_Emp in query)
                                //////{
                                //////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                //////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[Disability_HTTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[Disability_HTTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }


                            DisablityHT_Data = "Accident Elimination Period: " + accidentEliminationPeriod.Trim();
                            DisablityHT_Data += "\n" + "Sickness Elimination Period: " + sicknessEliminationPeriod.Trim();
                            DisablityHT_Data += "\n" + "Hospitalization: " + hospitalization.Trim();
                            DisablityHT_Data += "\n" + "Weekly Benefit Maximum: " + weeklyBenefitMaximum.Trim();
                            DisablityHT_Data += "\n" + "Maximum Period of Payment: " + maximumPeriodofPayment.Trim();

                            oWordDoc.Tables[Disability_HTTableNo].Cell(1, 3).Range.Text = DisablityHT_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Accident Elimination Period: ", "Sickness Elimination Period: ", "Hospitalization: ", "Weekly Benefit Maximum: ", "Maximum Period of Payment: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, Disability_HTTableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("DISABILITY_HT_PLAN TYPE" + Disability_HTCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim());
                                    }
                                    if (fieldName.Contains("DISABILITY_HT_BENEFITNAME" + Disability_HTCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Trim());
                                    }


                                }
                            }
                            #endregion
                            Disability_HTCount++;
                        }
                    }

                }//ForClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }//FunDisabilityClose

        /// <summary>
        /// Additional Product 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="AccidentalBenefitColumnIdList"></param>
        /// <param name="SessionId"></param>
        public void WriteAdditionalProductSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList AdditionalProductBenefitColumnIdList, string SessionId)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                ArrayList arrCarrierName = new ArrayList();

                string FundingType = string.Empty;
                int rowCnt = 4;
                //int rowNum = 1;
                int m = 1;
                string contributionMethod = string.Empty;
                int AdditionalProductTableNO = 143;

                Color rowsColor_4 = Color.FromArgb(242, 242, 242);
                int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
                Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;

                foreach (DataRow dr in PlanTable.Rows)
                {
                    int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(int.Parse(dr["ProductId"].ToString()), SessionId);
                    int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(dr["ProductId"].ToString()), SessionId);

                    switch (OptionFieldValueiD)
                    {
                        case 52403: FundingType = "Self Funded"; break;
                        case 52401: FundingType = "Fully Insured"; break;
                        case 52400: FundingType = ""; break;
                        default: FundingType = ""; break;
                    }


                    if (Convert.ToString(dr["ProductName"]) != null)
                    {
                        if (Convert.ToString(dr["ProductName"]).Trim().ToLower().Contains("shared"))
                        {
                            contributionMethod = "Shared";
                        }
                        else if (Convert.ToString(dr["ProductName"]).Trim().ToLower().Contains("er paid"))
                        {
                            contributionMethod = "Employer Paid";
                        }
                        else if (Convert.ToString(dr["ProductName"]).Trim().ToLower().Contains("ee paid"))
                        {
                            contributionMethod = "Employee Paid";
                        }
                        else
                        {
                            contributionMethod = "Not Listed";
                        }
                    }
                    else
                    {
                        contributionMethod = "Not Listed";
                    }

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {


                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("ADDITIONAL"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("Additional");
                            }
                        }
                    }


                    if (rowCnt > 4)
                    {
                        oWordDoc.Tables[AdditionalProductTableNO].Rows.Add();
                        oWordDoc.Tables[AdditionalProductTableNO].Rows.Add();
                        oWordDoc.Tables[AdditionalProductTableNO].Rows.Add();
                        oWordDoc.Tables[AdditionalProductTableNO].Rows.Add();

                        oWordDoc.Tables[AdditionalProductTableNO].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                        oWordDoc.Tables[AdditionalProductTableNO].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                    }


                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 1).Range.Text = "Product Type: " +Convert.ToString(dr["Name"]).Replace("\r", "").Replace("\a", "").Trim();
                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 2).Range.Text = "Carrier: " + Convert.ToString(dr["Carrier"]).Trim();
                    //oWordDoc.Tables[AdditionalProductTableNO].Cell(1, 2).Range.Text = "Group#: " + Convert.ToString(dr["PolicyNumber"]);  //ProductTypeDescription
                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(dr["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 1).Range.Text = "Contribution Method: " + contributionMethod.Trim();
                    oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0").Trim();


                    Word.Range boldrange_1 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 1).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.
                    boldrange_1.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 1).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 1).Range.Words[2].End);
                    boldrange_1.Bold = 1;

                    Word.Range boldrange_2 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 2).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.
                    boldrange_2.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 2).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m, 2).Range.Words[1].End);
                    boldrange_2.Bold = 1;


                    Word.Range boldrange_3 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 1).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.
                    boldrange_3.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 1).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 1).Range.Words[2].End);
                    boldrange_3.Bold = 1;

                    Word.Range boldrange_4 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 2).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.
                    boldrange_4.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 2).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 1, 2).Range.Words[2].End);
                    boldrange_4.Bold = 1;



                    Word.Range boldrange_5 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 1).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.2
                    boldrange_5.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 1).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 1).Range.Words[2].End);
                    boldrange_5.Bold = 1;

                    Word.Range boldrange_6 = oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 2).Range;//Assign the whole cell range to boldrange, then adjust it with SetRange method.
                    boldrange_6.SetRange(oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 2).Range.Start, oWordDoc.Tables[AdditionalProductTableNO].Cell(m + 2, 2).Range.Words[2].End);
                    boldrange_6.Bold = 1;


                    m = m + 4;

                    rowCnt++;
                }//ForEachClose


                for (int rowNum = 4; rowNum <= oWordDoc.Tables[AdditionalProductTableNO].Rows.Count; rowNum++)
                {
                    oWordDoc.Tables[AdditionalProductTableNO].Rows[rowNum].Delete();
                    rowNum = rowNum + 2;
                }



                /**************** THIS CODE IS FOR COLOR THE ALTERNATE TABLE COLUMN *************/
                int cnt = 1;
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[AdditionalProductTableNO].Rows.Count; rowNum++)
                {
                    if (cnt <= rowNum)
                    {
                        oWordDoc.Tables[AdditionalProductTableNO].Rows[cnt].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        oWordDoc.Tables[AdditionalProductTableNO].Rows[cnt + 1].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        oWordDoc.Tables[AdditionalProductTableNO].Rows[cnt + 2].Range.Shading.BackgroundPatternColor = wdColor_rows4;

                        rowNum = cnt + 5;
                        cnt = rowNum + 1;
                    }
                }

                ////string[] makeBold = new string[] { " ", "Carrier:", "Product Type", "Effective Date:", "Renewal Date:", "Contribution Method:", "Eligible Employees:" };
                ////sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, AdditionalProductTableNO);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Method to Retrive Accidental Plan Details
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="VoluntaryLifeBenefitColumnIdList"></param>
        /// <param name="SessionId"></param>
        public void WriteAccidentSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList AccidentalBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                string covrageType = string.Empty;
                string benefitAmount = string.Empty;
                string aggregateLimitPerOccurence = string.Empty;
                string carrier = string.Empty;
                string group = string.Empty;
                string effectiveDate = string.Empty;
                string renewalDate = string.Empty;
                string eligibleEmployees = string.Empty;
                string FundingType = string.Empty;

                string value = string.Empty;
                ArrayList arrCarrierName = new ArrayList();
                int iTotalFields = 0;

                string Accident_SummaryName = string.Empty;
                string Accident_PlanType = string.Empty;

                DataTable Emp = new DataTable();
                SummaryDetail sd = new SummaryDetail();
                sd.BuildEligibilityRuleTable();

                int AccidentalTableNo = 137;
                int AccidentalCount = 1; //For 6 different Accidental plans

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                #region HashtableAccident
                Hashtable hashTableAccident = new Hashtable();
                hashTableAccident.Add(1, "23");//Aggregate Limit per Occurrence
                hashTableAccident.Add(2, "69");//Benefit Amount
                hashTableAccident.Add(3, "134");//Coverage Type
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.Accident.ToLower().Trim())
                    {
                        if (AccidentalCount == 1)
                        {
                            AccidentalTableNo = 137;
                        }
                        if (AccidentalCount == 2)
                        {
                            AccidentalTableNo = 138;
                        }
                        if (AccidentalCount == 3)
                        {
                            AccidentalTableNo = 139;
                        }
                        if (AccidentalCount == 4)
                        {
                            AccidentalTableNo = 140;
                        }
                        if (AccidentalCount == 5)
                        {
                            AccidentalTableNo = 141;
                        }
                        if (AccidentalCount == 6)
                        {
                            AccidentalTableNo = 142;
                        }

                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (Convert.ToString(PlanTable.Rows[rowindex]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"]))
                        {
                            Accident_SummaryName = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Replace("'", "''");
                            Accident_PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);


                            DataTable EligibilityDS = new DataTable();
                            //int EleigibilityRuleId = 2849011;

                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            #region HashRotation

                            foreach (int key in hashTableAccident.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.Accident.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && AccidentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableAccident[key].ToString())
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                aggregateLimitPerOccurence = value; break;
                                            case 2:
                                                benefitAmount = value; break;
                                            case 3:
                                                covrageType = value; break;
                                        }//SwicthClose
                                    }
                                }//InnerForEachClose
                            }//OuterForEachClose
                            #endregion

                            #region Accidental Plan Info writing

                            string Accidental_Data = "";
                            oWordDoc.Tables[AccidentalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);

                            oWordDoc.Tables[AccidentalTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[AccidentalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[AccidentalTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[AccidentalTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[AccidentalTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                if (!string.IsNullOrEmpty(Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])))
                                {
                                    ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                    ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                    ////                             select product;
                                    ////foreach (DataRow Def_Eligible_Emp in query)
                                    ////{
                                    ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                    ////}
                                    IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                                 where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                                 select product;
                                    foreach (DataRow Def_Eligible_Emp in query)
                                    {
                                        DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                    }
                                }
                                //oWordDoc.Tables[AccidentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();                       
                                oWordDoc.Tables[AccidentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }


                            Accidental_Data = "Coverage Type: " + covrageType.Trim();
                            Accidental_Data += "\n" + "Benefit Amount: " + benefitAmount.Trim();
                            Accidental_Data += "\n" + "Aggregate Limit per Occurrence: " + aggregateLimitPerOccurence.Trim();

                            oWordDoc.Tables[AccidentalTableNo].Cell(1, 3).Range.Text = Accidental_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date: ", "Renewal Date: ", "Funding Type: ", "Eligible Employees: ", "Eligibility: ", "Coverage Type: ", "Benefit Amount:", "Aggregate Limit per Occurrence: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, AccidentalTableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("ACCIDENTAL_PLAN TYPE" + AccidentalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim());
                                    }
                                    if (fieldName.Contains("ACCIDENTAL_BENEFITNAME" + AccidentalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Trim());
                                    }

                                }
                            }
                            #endregion
                            AccidentalCount++;
                        }
                    }//OuterIF
                }//ForCloseHere
            }//TryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Method for WellNess Plan 
        /// </summary>
        /// <param name="oWordDoc"></param>
        /// <param name="oWordApp"></param>
        /// <param name="PlanTable"></param>
        /// <param name="ProductDS"></param>
        /// <param name="BenefitDS"></param>
        /// <param name="AdditionalProductBenefitColumnIdList"></param>
        /// <param name="SessionId"></param>
        public void WriteWellNessSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList WellnesBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                DataTable Emp = new DataTable();
                SummaryDetail sd = new SummaryDetail();
                sd.BuildEligibilityRuleTable();

                int WellnessTableNo = 119;
                int WellnessCount = 1; //For 6 different wellness plans


                #region HashtableAccident
                Hashtable hashTableWellness = new Hashtable();
                hashTableWellness.Add(1, "887");  //Compliance Program Designation - 887
                hashTableWellness.Add(2, "894");  //Tobacco Non-use Affidavit - 894
                hashTableWellness.Add(3, "901"); // Preventive visit/Physician form Campaign- 901
                hashTableWellness.Add(4, "910"); // Health Assessments - 910
                hashTableWellness.Add(5, "934"); // Rewards - Premium Reduction-934
                hashTableWellness.Add(6, "935"); // Rewards – HRA Contribution- 935
                hashTableWellness.Add(7, "936"); //Rewards – HSA Contribution - 936
                #endregion


                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (Convert.ToString(PlanTable.Rows[rowindex]["PlanType"]).ToLower().Trim() == cv.Wellness.ToLower().Trim() && Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[rowindex]["productTypeID"]) == 317)
                    {
                        /********************** Wellness Program ***********************/
                        #region VeriableDecleration
                        string complianceProgramDesignation = string.Empty;
                        string tobaccoNonuseAffidavit = string.Empty;
                        string preventiveVisit_PhysicianFormCampaign = string.Empty;
                        string HealthAssessments = string.Empty;
                        string RewardsPremiumReduction = string.Empty;
                        string RewardsHRAContribution = string.Empty;
                        string RewardsHSAContribution = string.Empty;
                        string carrier = string.Empty;
                        string group = string.Empty;
                        string effectiveDate = string.Empty;
                        string renewalDate = string.Empty;
                        string eligibleEmployees = string.Empty;
                        string FundingType = string.Empty;
                        ArrayList arrCarrierName = new ArrayList();

                        string value = string.Empty;

                        string WellNess_SummaryName = string.Empty;
                        string WellNess_PlanType = string.Empty;
                        #endregion

                        if (WellnessCount == 1)
                        {
                            WellnessTableNo = 119;
                        }
                        if (WellnessCount == 2)
                        {
                            WellnessTableNo = 120;
                        }
                        if (WellnessCount == 3)
                        {
                            WellnessTableNo = 121;
                        }
                        if (WellnessCount == 4)
                        {
                            WellnessTableNo = 122;
                        }
                        if (WellnessCount == 5)
                        {
                            WellnessTableNo = 123;
                        }
                        if (WellnessCount == 6)
                        {
                            WellnessTableNo = 124;
                        }

                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }

                        if (Convert.ToString(PlanTable.Rows[rowindex]["ProductId"]) == Convert.ToString(ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"]))
                        {
                            WellNess_SummaryName = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Replace("'", "''");
                            WellNess_PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);

                            DataTable EligibilityDS = new DataTable();
                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }



                            #region HashRotation

                            foreach (int key in hashTableWellness.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.Wellness.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && WellnesBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableWellness[key].ToString())
                                    {
                                        value = (Convert.ToString(dr["prefix"]) + Convert.ToString(dr["value"]) + Convert.ToString(dr["suffix"]) + " " + Convert.ToString(dr["ancillaryText"]) + " " + Convert.ToString(dr["exclusionsLimitations"])).Trim();
                                        switch (key)
                                        {
                                            case 1:
                                                complianceProgramDesignation = value; break; //Compliance Program Designation - 887
                                            case 2:
                                                tobaccoNonuseAffidavit = value; break;      //Tobacco Non-use Affidavit - 894
                                            case 3:
                                                preventiveVisit_PhysicianFormCampaign = value; break; //Preventive visit/Physician form Campaign- 901
                                            case 4:
                                                HealthAssessments = value; break;           // Health Assessments - 910
                                            case 5:
                                                RewardsPremiumReduction = value; break;     // Rewards - Premium Reduction-934
                                            case 6:
                                                RewardsHRAContribution = value; break;      // Rewards – HRA Contribution- 935
                                            case 7:
                                                RewardsHSAContribution = value; break;       //Rewards – HSA Contribution - 936
                                        }//SwicthClose
                                    }
                                }//InnerForEachClose
                            }//OuterForEachClose
                            #endregion

                            #region WellNess Plan Writing
                            string Wellness_Data = "";
                            oWordDoc.Tables[WellnessTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);

                            oWordDoc.Tables[WellnessTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[WellnessTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[WellnessTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[WellnessTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType.Trim();
                            oWordDoc.Tables[WellnessTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[WellnessTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[WellnessTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }
                            Wellness_Data = "Compliance Program Designation: " + complianceProgramDesignation.Trim();
                            Wellness_Data += "\n" + "Tobacco Non-Use Affidavit: " + tobaccoNonuseAffidavit.Trim();
                            Wellness_Data += "\n" + "Preventive visit/Physician form Campaign: " + preventiveVisit_PhysicianFormCampaign.Trim();
                            Wellness_Data += "\n" + "Health Assessments: " + HealthAssessments.Trim();
                            Wellness_Data += "\n" + "Rewards - Premium Reduction: " + RewardsPremiumReduction.Trim();
                            Wellness_Data += "\n" + "Rewards – HRA Contribution: " + RewardsHRAContribution.Trim();
                            Wellness_Data += "\n" + "Rewards – HSA Contribution: " + RewardsHSAContribution.Trim();


                            oWordDoc.Tables[WellnessTableNo].Cell(1, 3).Range.Text = Wellness_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Compliance Program Designation: ", "Tobacco Non-Use Affidavit: ", "Preventive visit/Physician form Campaign: ", "Health Assessments: ", "Rewards - Premium Reduction: ", "Rewards – HRA Contribution: ", "Rewards – HSA Contribution: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, WellnessTableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();


                                    if (fieldName.Contains("WELLNESS_PLAN TYPE" + WellnessCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim());
                                    }
                                    if (fieldName.Contains("WELLNESS_BENEFITNAME" + WellnessCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]).Trim());
                                    }
                                }
                            }
                            #endregion
                            WellnessCount++;
                        }
                    }//WellnessPrgOuterIFClose
                }//ForClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="selectedColor">selectedColor contain selected color (Optional Paramter)</param>
        public void WriteDentalSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(8, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalInNetwork.Add(7, "45");  //Calendar Year Deductible - Individual
                HashtableDentalInNetwork.Add(6, "44");  //Calendar Year Deductible - Family
                HashtableDentalInNetwork.Add(5, "55");  //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(4, "164"); //Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(3, "64");  //Basic Services – Basic
                HashtableDentalInNetwork.Add(2, "336"); //Major Services – Major
                HashtableDentalInNetwork.Add(1, "314"); //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(9, "392");     //Orthodontic Services

                #endregion

                #region variables for Plan 1
                string Dental_PlanType = string.Empty;
                string Dental_SummaryName = string.Empty;
                string Dental_Policynumber_1 = string.Empty;
                string Dental_Carrier_Plan1 = string.Empty;
                string Dental_Summary_Plan1 = string.Empty;
                string Dental_EffectivedatePlan1 = string.Empty;
                string Dental_RenewaldatePlan1 = string.Empty;
                string Dental_FundingType_Plan1 = string.Empty;
                string Annual_Deductible_Individual_Plan1 = string.Empty;
                string Annual_Deductible_Family_Plan1 = string.Empty;
                string Annual_Benefit_Maximum_Plan1 = string.Empty;
                string Dental_Preventive_Care_Waived_Plan1 = string.Empty;
                string Dental_Basic_Services_Plan1 = string.Empty;
                string Dental_Major_Services_Plan1 = string.Empty;
                string Dental_Orthodontia_Plan1 = string.Empty;
                string Dental_Orthodontia_Maximum_Plan1 = string.Empty;
                string Dental_Waiting_Periods_Plan1 = string.Empty;
                string Dental_Preventive_And_Diagnostic_Care_Plan1 = string.Empty;

                #endregion
                //SummaryDetail sd = new SummaryDetail();
                //sd.BuildEligibilityRuleTable();

                int DentalTableNo = 47;
                int dentalCount = 1; //For 6 different dental plans
                string value = "";
                string FundingType = "";
                DataTable Emp = new DataTable();

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        if (dentalCount == 1)
                        {
                            DentalTableNo = 47;
                        }
                        if (dentalCount == 2)
                        {
                            DentalTableNo = 48;
                        }
                        if (dentalCount == 3)
                        {
                            DentalTableNo = 49;
                        }
                        if (dentalCount == 4)
                        {
                            DentalTableNo = 50;
                        }
                        if (dentalCount == 5)
                        {
                            DentalTableNo = 51;
                        }
                        if (dentalCount == 6)
                        {
                            DentalTableNo = 52;
                        }
                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            Dental_SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            Dental_PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);

                            DataTable EligibilityDS = new DataTable();
                            //int EleigibilityRuleId = 2849011;

                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }
                            #region DentalTable
                            // Iterate the loop for above created HashTable to get the value for selected Key
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {

                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        // Set value = Prefix + Value + Suffix + AncillaryTest + ExclusionsLimitations
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 8:
                                                Dental_Preventive_Care_Waived_Plan1 = value; break;
                                            case 7:
                                                Annual_Deductible_Individual_Plan1 = value; break;
                                            case 6:
                                                Annual_Deductible_Family_Plan1 = value; break;
                                            case 5:
                                                Annual_Benefit_Maximum_Plan1 = value; break;
                                            case 4:
                                                Dental_Preventive_And_Diagnostic_Care_Plan1 = value; break;
                                            case 3:
                                                Dental_Basic_Services_Plan1 = value; break;
                                            case 2:
                                                Dental_Major_Services_Plan1 = value; break;
                                            case 1:
                                                Dental_Orthodontia_Maximum_Plan1 = value; break;
                                            case 9:
                                                Dental_Orthodontia_Plan1 = value; break;
                                        }

                                    }
                                }

                            }


                            #endregion
                            #region Dental Plan Info writing

                            //string DefinationOf_eligible_Emplyee=" ";

                            string Dental_Data = "";
                            oWordDoc.Tables[DentalTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            //oWordDoc.Tables[DentalTableNo].Cell(1, 1).Range.Characters[1].Bold = 1;
                            oWordDoc.Tables[DentalTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);
                            oWordDoc.Tables[DentalTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[DentalTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[DentalTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[DentalTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            string DefinationOf_eligible_Emplyee = "";
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                //string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[DentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[DentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                //string domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                //oWordDoc.Tables[DentalTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                                //oWordDoc.Tables[DentalTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);
                            }

                            if (DefinationOf_eligible_Emplyee == "")
                            {
                                oWordDoc.Tables[DentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]);
                            }

                            string domesticPartner = Convert.ToString(EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"]);
                            if (domesticPartner != "")
                            {
                                domesticPartner = domesticPartner.Trim();
                            }
                            oWordDoc.Tables[DentalTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                            oWordDoc.Tables[DentalTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);

                            Dental_Data = "Annual Deductible: " + Annual_Deductible_Individual_Plan1 + " / " + Annual_Deductible_Family_Plan1;
                            Dental_Data += "\n" + "Waived for Preventive: " + Dental_Preventive_Care_Waived_Plan1;
                            Dental_Data += "\n" + "Annual Plan Maximum: " + Annual_Benefit_Maximum_Plan1;
                            Dental_Data += "\n" + "Preventive & Diagnostic: " + Dental_Preventive_And_Diagnostic_Care_Plan1;
                            Dental_Data += "\n" + "Basic Services: " + Dental_Basic_Services_Plan1;
                            Dental_Data += "\n" + "Major Services: " + Dental_Major_Services_Plan1;
                            Dental_Data += "\n" + "Orthodontia Services: " + Dental_Orthodontia_Plan1;
                            Dental_Data += "\n" + "Orthodontia Maximum: " + Dental_Orthodontia_Maximum_Plan1;


                            oWordDoc.Tables[DentalTableNo].Cell(1, 3).Range.Text = Dental_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Domestic Partners Status: ", "Dependent Child Age: ", "Annual Deductible: ", "Waived for Preventive:", "Annual Plan Maximum: ", "Preventive & Diagnostic: ", "Basic Services: ", "Major Services: ", "Orthodontia Services: ", "Orthodontia Maximum: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, DentalTableNo);
                            //foreach (string s in makeBold)
                            //{                                oWordDoc.Tables[DentalTableNo].Select();
                            //    oWordApp.Selection.Find.Text = s; //changes with each iteration
                            //    oWordApp.Selection.Find.Execute();
                            //    oWordApp.Selection.Font.Bold = 1;
                            //    oWordApp.Selection.Collapse(); //used to 'clear' the selection
                            //    oWordApp.Selection.Find.ClearFormatting();
                            //}


                            #endregion
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    //if (fieldName.Contains("Definition of Eligible Employee"))
                                    //{
                                    //    myMergeField.Select();

                                    //    if (Emp.Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText();
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //}


                                    if (fieldName.Contains("DENTALSUMMARYNAME" + dentalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(Dental_SummaryName));
                                    }
                                    if (fieldName.Contains("DENTAL PLAN TYPE" + dentalCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(Dental_PlanType));
                                    }


                                }
                            }
                            #endregion
                            dentalCount++;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        public void WriteHSA(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HSABenefitColumnIdList, string SessionId)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                int HSAcount = 1;
                int HSATableNo = 35;

                #region HashtableHSA
                Hashtable HashtableHSA = new Hashtable();
                //HashtableHSA.Add(1, "628");  //Trustee/Custodian
                //HashtableHSA.Add(2, "629");  //Primary Fees Paid by
                //HashtableHSA.Add(3, "635"); // General Plan Information – Maximum Annual Contribution / Individual
                //HashtableHSA.Add(4, "636"); // General Plan Information – Maximum Annual Contribution / Family
                //HashtableHSA.Add(5, "638"); //Type of Account

                HashtableHSA.Add(6, "640"); //  Individual

                //HashtableHSA.Add(7, "641"); //Individual + One
                //HashtableHSA.Add(8, "642"); //Individual + Two
                //HashtableHSA.Add(9, "643"); //Individual + Three or More

                HashtableHSA.Add(10, "644"); // Family

                //HashtableHSA.Add(11, "645"); //Frequency
                //HashtableHSA.Add(12, "648"); //Matching Contributions / Percentage
                //HashtableHSA.Add(13, "649"); //Matching Contributions / Maximum Dollar Amount
                //HashtableHSA.Add(14, "650"); //Matching Contributions / Frequency
                #endregion
                int var = 0;
                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (HSAcount == 1)
                        {
                            HSATableNo = 35;
                        }
                        if (HSAcount == 2)
                        {
                            HSATableNo = 36;
                        }
                        if (HSAcount == 3)
                        {
                            HSATableNo = 37;
                        }
                        if (HSAcount == 4)
                        {
                            HSATableNo = 38;
                        }
                        if (HSAcount == 5)
                        {
                            HSATableNo = 39;
                        }
                        if (HSAcount == 6)
                        {
                            HSATableNo = 40;
                        }
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string SummaryName = PlanTable.Rows[k]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]);
                            #region HSATable
                            string value = string.Empty;
                            string ERContribution_Indivisual = string.Empty;
                            string ERContribution_Family = string.Empty;

                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {

                                            case 6: ERContribution_Indivisual = value; break;

                                            case 10: ERContribution_Family = value; break;

                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Plan Info
                            string HRA_Data = "";
                            oWordDoc.Tables[HSATableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            //oWordDoc.Tables[HSATableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[HSATableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);

                            oWordDoc.Tables[HSATableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[HSATableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            HRA_Data = "ER Contribution Individual: " + ERContribution_Indivisual;
                            HRA_Data += "\n" + "ER Contribution Family: " + ERContribution_Family;
                            oWordDoc.Tables[HSATableNo].Cell(1, 3).Range.Text = HRA_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "ER Contribution Individual: ", "ER Contribution Family: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, HSATableNo);

                            #endregion

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("HSASUMMARYNAME" + HSAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("HSA PLAN TYPE" + HSAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            HSAcount++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">HRABenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        public void WriteHRA(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, string SessionId, DataTable PlanInfoTable)
        {
            try
            {
                int HRATableNo = 41;
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                int HRAcount = 1;
                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "239"); // Health Reimbursement Account Tier 2 
                HashtableHRA.Add(3, "240"); // Health Reimbursement Account Tier 3 
                HashtableHRA.Add(4, "241"); // Health Reimbursement Account Tier 4 
                //HashtableHRA.Add(5, "253"); //HRA Eligible Expenses
                //HashtableHRA.Add(6, "486"); //Rollover of HRA
                //HashtableHRA.Add(7, "572"); //Wellness Account/Tier 1
                //HashtableHRA.Add(8, "475"); //Reimbursement Options
                //HashtableHRA.Add(9, "489"); //Run Out Period
                #endregion
                int var = 0;
                string attributeView = String.Empty;
                string HRATier1 = String.Empty;
                string HRATier2 = String.Empty;
                string HRATier3 = String.Empty;
                string HRATier4 = String.Empty;

                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (HRAcount == 1)
                        {
                            HRATableNo = 41;
                        }
                        if (HRAcount == 2)
                        {
                            HRATableNo = 42;
                        }
                        if (HRAcount == 3)
                        {
                            HRATableNo = 43;
                        }
                        if (HRAcount == 4)
                        {
                            HRATableNo = 44;
                        }
                        if (HRAcount == 5)
                        {
                            HRATableNo = 45;
                        }
                        if (HRAcount == 6)
                        {
                            HRATableNo = 46;
                        }
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {

                            #region HRATable
                            string value = string.Empty;
                            foreach (int key in HashtableHRA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 1: HRATier1 = value; break;
                                            case 2: HRATier2 = value; break;
                                            case 3: HRATier3 = value; break;
                                            case 4: HRATier4 = value; break;

                                        }
                                    }
                                }

                            }

                            #endregion
                            #region Plan Info
                            string HRA_Data = "";
                            oWordDoc.Tables[HRATableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            //oWordDoc.Tables[HRATableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[HRATableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);

                            oWordDoc.Tables[HRATableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[HRATableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            HRA_Data = "HRA Tier 1: " + HRATier1 + "\n" + "HRA Tier 2: " + HRATier2;
                            HRA_Data += "\n" + "HRA Tier 3: " + HRATier3 + "\n" + "HRA Tier 4: " + HRATier4;
                            oWordDoc.Tables[HRATableNo].Cell(1, 3).Range.Text = HRA_Data;

                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "HRA Tier 1: ", "HRA Tier 2: ", "HRA Tier 3: ", "HRA Tier 4: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, HRATableNo);

                            #endregion
                            string SummaryName = PlanTable.Rows[k]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("HRASUMMARYNAME" + HRAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("HRA PLAN TYPE" + HRAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            HRAcount++;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteLTDSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                int var = 0;

                int LTDcount = 1;
                int LTDTableNo = 95;
                DataTable Emp = new DataTable();

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }


                #region HashtableLTD
                HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period 6
                HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage 1
                HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum 3
                HashtableLTD.Add(4, "351");     //General Plan Information – Maximum Period of Payment 4
                HashtableLTD.Add(5, "449");     //Benefits[Pre-Existing Condition Limitation]
                HashtableLTD.Add(6, "141");     //Benefits[Definition of Disability] 7
                HashtableLTD.Add(7, "142");     //Definition of Earnings 8
                HashtableLTD.Add(8, "582");     //Guaranteed Issue  2
                HashtableLTD.Add(9, "371");     //Minimum Monthly Benefit 5

                HashtableLTD.Add(10, "501");     //Self-Reported Symptoms - Limitations
                HashtableLTD.Add(11, "365");     //Mental Illness - Limitations
                HashtableLTD.Add(12, "526");     //Substance Abuse - Limitations


                ////HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period 1
                ////HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage 2
                ////HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum 3
                ////HashtableLTD.Add(4, "351");     //General Plan Information – Maximum Period of Payment
                ////HashtableLTD.Add(5, "449");     //Benefits[Pre-Existing Condition Limitation]
                ////HashtableLTD.Add(6, "141");     //Benefits[Definition of Disability] 4
                ////HashtableLTD.Add(7, "142");     //Definition of Earnings
                ////HashtableLTD.Add(8, "582");     //Guaranteed Issue
                ////HashtableLTD.Add(9, "371");     //Minimum Monthly Benefit
                ////HashtableLTD.Add(9, "501");     //Self-Reported Symptoms - Limitations
                ////HashtableLTD.Add(9, "365");     //Mental Illness - Limitations
                ////HashtableLTD.Add(9, "526");     //Substance Abuse - Limitations
                ////HashtableLTD.Add(9, "449");     //Pre-Existing Condition Limitations
                #endregion

                string value = "";
                string Elimination_Period = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Maximum_Period_Of_Payment = string.Empty;
                string Pre_Existing_Condition = string.Empty;
                string Disability = string.Empty;
                string Defination_Erning = string.Empty;
                string Guaranteed_Issue = string.Empty;
                string renewal = string.Empty;
                string Minimum_Monthly_Benefit = string.Empty;
                string Self_Reported_Symptoms = string.Empty;
                string Mental_Illness = string.Empty;
                string SubstanceAbuse = string.Empty;

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (LTDcount == 1)
                        {
                            LTDTableNo = 95;
                        }
                        if (LTDcount == 2)
                        {
                            LTDTableNo = 96;
                        }
                        if (LTDcount == 3)
                        {
                            LTDTableNo = 97;
                        }
                        if (LTDcount == 4)
                        {
                            LTDTableNo = 98;
                        }
                        if (LTDcount == 5)
                        {
                            LTDTableNo = 99;
                        }
                        if (LTDcount == 6)
                        {
                            LTDTableNo = 100;
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD

                            string FundingType = "";
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }

                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }


                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {

                                            case 1:
                                                Elimination_Period = value.Trim();
                                                break;
                                            case 2: Benefit_Percentage = value.Trim(); break;
                                            case 3: Monthly_Benefit_Maximum = value.Trim(); break;
                                            case 4: //Maximum_Period_Of_Payment = value.Trim() + " " + dr["UOM"].ToString().Trim(); 
                                                Maximum_Period_Of_Payment = value.Trim();
                                                break;
                                            //case 5: Pre_Existing_Condition = value.Trim(); break;
                                            case 6: Disability = value.Trim(); break;
                                            //case 7: Defination_Erning = value.Trim(); break;
                                            //case 8: Guaranteed_Issue = value.Trim(); break;
                                            //case 9: Minimum_Monthly_Benefit = value.Trim(); break;

                                            //case 10: Self_Reported_Symptoms = value.Trim(); break;
                                            //case 11: Mental_Illness = value.Trim(); break;
                                            //case 12: SubstanceAbuse = value.Trim(); break;

                                            ////HashtableLTD.Add(10, "501");     //Self-Reported Symptoms - Limitations
                                            ////HashtableLTD.Add(11, "365");     //Mental Illness - Limitations
                                            ////HashtableLTD.Add(12, "526");     //Substance Abuse - Limitations
                                            ////HashtableLTD.Add(13, "449");     //Pre-Existing Condition Limitations
                                        }
                                    }
                                }
                            }





                            #endregion

                            #region Plan Info
                            string LTD_Data = "";
                            oWordDoc.Tables[LTDTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            //oWordDoc.Tables[LTDTableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[LTDTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);

                            oWordDoc.Tables[LTDTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[LTDTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[LTDTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[LTDTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {

                                string DefinationOf_eligible_Emplyee = " ";
                                //////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                //////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                //////                             select product;
                                //////foreach (DataRow Def_Eligible_Emp in query)
                                //////{
                                //////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                //////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[DentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                //oWordDoc.Tables[DentalTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                oWordDoc.Tables[LTDTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;

                            }
                            LTD_Data = "Elimination Period: " + Elimination_Period;
                            LTD_Data += "\nBenefit Percentage: " + Benefit_Percentage;
                            LTD_Data += "\nMonthly Benefit Maximum: " + Monthly_Benefit_Maximum;
                            LTD_Data += "\nMaximum Period of Benefit: " + Maximum_Period_Of_Payment;
                            LTD_Data += "\nDefinition of Disability: " + Disability;
                            oWordDoc.Tables[LTDTableNo].Cell(1, 3).Range.Text = LTD_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Elimination Period: ", "Benefit Percentage: ", "Monthly Benefit Maximum: ", "Maximum Period of Benefit: ", "Definition of Disability: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, LTDTableNo);

                            #endregion
                            string SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {


                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("LTDSUMMARYNAME" + LTDcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("LTD PLAN TYPE" + LTDcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            LTDcount++;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteSTDSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                string FundingType = string.Empty;
                int STDcount = 1;
                int STDTableNo = 89;
                DataTable Emp = new DataTable();

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }

                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                int var = 0;

                #region HashtableSTD
                HashtableSTD.Add(1, "181");       //STD General Information – Elimination Period 
                HashtableSTD.Add(2, "142");       //STD General Information – Defination of Erning 6
                HashtableSTD.Add(3, "71");       //STD General Plan Information – Benefit Percentage  4
                HashtableSTD.Add(4, "141");     //STD General Information – Defination of Disability 3
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment 7
                HashtableSTD.Add(6, "449");     //Benefit Features[Pre-Existing Condition Limitation]9
                HashtableSTD.Add(7, "569");     //STD General Information – Weekly Benefit Maximum 5
                HashtableSTD.Add(8, "373");     //Minimum Weekly Benefit       8
                HashtableSTD.Add(9, "8");       //Elimination Period[Accident] 1
                HashtableSTD.Add(10, "505");    //Elimination Period[Sickness] 2
                HashtableSTD.Add(11, "521");    //State Statutory Plan Integration     10
                #endregion

                string EliminationPeriod = string.Empty;
                string Defination_of_Erning = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Defination_of_Disability = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Pre_Existing_Condition_Limitation = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string Minimum_Weekly_Benefit = string.Empty;
                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string State_Statutory_Plan_Integration = string.Empty;
                string ProductName = "";
                string renewal = string.Empty;
                string value = "";

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (STDcount == 1)
                        {
                            STDTableNo = 89;
                        }
                        if (STDcount == 2)
                        {
                            STDTableNo = 90;
                        }
                        if (STDcount == 3)
                        {
                            STDTableNo = 91;
                        }
                        if (STDcount == 4)
                        {
                            STDTableNo = 92;
                        }
                        if (STDcount == 5)
                        {
                            STDTableNo = 93;
                        }
                        if (STDcount == 6)
                        {
                            STDTableNo = 94;
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {

                            #region STD
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }

                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }
                            //ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            //case 1:
                                            //    if (value.Contains("days"))
                                            //    {
                                            //        EliminationPeriod = value.Trim().Replace("days", "day");
                                            //    }
                                            //    else
                                            //    {
                                            //        EliminationPeriod = value.Trim();
                                            //    }
                                            //    break;
                                            // case 2: Defination_of_Erning = value.Trim(); break;
                                            case 3: Benefit_Percentage = value.Trim(); break;
                                            //case 4: Defination_of_Disability = value.Trim(); break;
                                            case 5: Maximum_Period_of_Payment = value.Trim() + " " + dr["UOM"].ToString().Trim(); break;
                                            // case 6: Pre_Existing_Condition_Limitation = value.Trim(); break;
                                            case 7: Weekly_Benefit_Maximum = value.Trim(); break;
                                            // case 8: Minimum_Weekly_Benefit = value.Trim(); break;
                                            case 9: EliminationPeriod_Accident = value.Trim(); break;
                                            case 10: if (!string.IsNullOrEmpty(value.Trim()))
                                                {
                                                    // EliminationPeriod_Sickness = " / " + value.Trim();
                                                    EliminationPeriod_Sickness = value.Trim();
                                                }
                                                else
                                                {
                                                    EliminationPeriod_Sickness = value.Trim();
                                                }
                                                break;
                                            // case 11: State_Statutory_Plan_Integration = value.Trim(); break;



                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Plan Info
                            string STD_Data = "";
                            oWordDoc.Tables[STDTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            //oWordDoc.Tables[STDTableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[STDTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);

                            oWordDoc.Tables[STDTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[STDTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[STDTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[STDTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //oWordDoc.Tables[STDTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " +  Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[STDTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }

                            STD_Data = "Accident Elimination Period: " + EliminationPeriod_Accident;
                            STD_Data += "\nSickness Elimination Period: " + EliminationPeriod_Sickness;
                            STD_Data += "\nWeekly Benefit Percentage: " + Benefit_Percentage;
                            STD_Data += "\nMaximum Benefit Period: " + Maximum_Period_of_Payment;

                            oWordDoc.Tables[STDTableNo].Cell(1, 3).Range.Text = STD_Data;

                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Accident Elimination Period: ", "Sickness Elimination Period: ", "Weekly Benefit Percentage: ", "Maximum Benefit Period: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, STDTableNo);

                            #endregion
                            string SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {


                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("STDSUMMARYNAME" + STDcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("STD PLAN TYPE" + STDcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            STDcount++;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for Life EAP Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="AccountDS">Dataset AccountDS contain Group Account Information</param>
        /// <param name="OptionFieldValueiD"></param>
        /// <param name="BenefitStructureDS"></param>
        /// <param name="AccountTeamMemberDS">Dataset AccountTeamMemberDS contain Account Team Member information</param>
        public void WriteEAPSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                ArrayList arrMedical = new ArrayList();
                string Number_of_Visits = string.Empty;
                string FundingType = string.Empty;
                int EAPcount = 1;
                int EAPTableNo = 125;
                DataTable Emp = new DataTable();

                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }
                ////Emp = bp.GetEmployeeData(ClientID);

                #region Hashtable for EAP
                Hashtable hashTableEAP = new Hashtable();
                hashTableEAP.Add(1, "384");     //Number of Visits
                #endregion

                for (int rowindex = 0; rowindex < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (EAPcount == 1)
                        {
                            EAPTableNo = 125;
                        }
                        if (EAPcount == 2)
                        {
                            EAPTableNo = 126;
                        }
                        if (EAPcount == 3)
                        {
                            EAPTableNo = 127;
                        }
                        if (EAPcount == 4)
                        {
                            EAPTableNo = 128;
                        }
                        if (EAPcount == 5)
                        {
                            EAPTableNo = 129;
                        }
                        if (EAPcount == 6)
                        {
                            EAPTableNo = 130;
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            DataTable EligibilityDS = new DataTable();
                            //int EleigibilityRuleId = 2849011;

                            if (PlanTable.Rows[rowindex]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[rowindex]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }


                            int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);
                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[rowindex]["ProductId"]), SessionId);

                            switch (OptionFieldValueiD)
                            {
                                case 52403: FundingType = "Self Funded"; break;
                                case 52401: FundingType = "Fully Insured"; break;
                                case 52400: FundingType = ""; break;
                                default: FundingType = ""; break;
                            }
                            #region EAP Table
                            foreach (int key in hashTableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == hashTableEAP[key].ToString())
                                    {
                                        var value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Number_of_Visits = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Plan Info
                            string EAP_Data = "";
                            oWordDoc.Tables[EAPTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]);
                            //oWordDoc.Tables[EAPTableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[EAPTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]);

                            oWordDoc.Tables[EAPTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[EAPTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[EAPTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[EAPTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                                string DefinationOf_eligible_Emplyee = " ";
                                ////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                ////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                ////                             select product;
                                ////foreach (DataRow Def_Eligible_Emp in query)
                                ////{
                                ////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                ////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                //  oWordDoc.Tables[EAPTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();
                                oWordDoc.Tables[EAPTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                            }
                            EAP_Data = "Number of Visits : " + Number_of_Visits;



                            oWordDoc.Tables[EAPTableNo].Cell(1, 3).Range.Text = EAP_Data;

                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees:", "Eligibility:", "Number of Visits :" };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, EAPTableNo);

                            #endregion
                            string SummaryName = PlanTable.Rows[rowindex]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {


                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("EAPSUMMARYNAME" + EAPcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("EAP PLAN TYPE" + EAPcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            EAPcount++;

                        }
                    }
                }// forLoopClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="ddlClient">DropDownList ddlClient is used to show selected client name.</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WriteFSASection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, string SessionId)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                int FSAcount = 1;
                int FSATableNo = 131;

                Hashtable HashtableFSA = new Hashtable();

                #region HashtableFSA
                HashtableFSA.Add(1, "451");//Premium Only Plan
                HashtableFSA.Add(2, "355");//Administration Services-Medical Spending Accounts - Minimum
                HashtableFSA.Add(3, "354");//Administration Services-Medical Spending Accounts - Maximum
                HashtableFSA.Add(4, "151");//Administration Services – Dependent Care Accounts-Minimum
                HashtableFSA.Add(5, "150");//Administration Services – Dependent Care Accounts-Maximum
                // HashtableFSA.Add(6, "489");//Administration Services – Run Out Period

                #endregion
                #region variables for Plan 1

                string premium_only = string.Empty;
                string MedicalSpendingAccountMinimum = string.Empty;
                string MedicalSpendingAccountMaximum = string.Empty;
                string DependentCareAccountMinimum = string.Empty;
                string DependentCareAccountMaximum = string.Empty;

                #endregion
                for (int k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (FSAcount == 1)
                        {
                            FSATableNo = 131;
                        }
                        if (FSAcount == 2)
                        {
                            FSATableNo = 132;
                        }
                        if (FSAcount == 3)
                        {
                            FSATableNo = 133;
                        }
                        if (FSAcount == 4)
                        {
                            FSATableNo = 134;
                        }
                        if (FSAcount == 5)
                        {
                            FSATableNo = 135;
                        }
                        if (FSAcount == 6)
                        {
                            FSATableNo = 136;
                        }
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region FSA plan
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: premium_only = value; break;//Premium Only 
                                            case 2: MedicalSpendingAccountMinimum = value; break;//Medical Spending Account Minimum Exam Copay
                                            case 3: MedicalSpendingAccountMaximum = value; break;//Medical Spending Accounts - Maximum     Exam Benefit (in/out)
                                            case 4: DependentCareAccountMinimum = value; break;//Dependent Care Account Minimum   
                                            case 5: DependentCareAccountMaximum = value; break;//Dependent Care Account Maximum   
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Plan Info
                            string FSA_Data = "";
                            oWordDoc.Tables[FSATableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            //oWordDoc.Tables[FSATableNo].Cell(1, 1).Range.Bold = 1;
                            oWordDoc.Tables[FSATableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);

                            oWordDoc.Tables[FSATableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[FSATableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            FSA_Data = "Premium Only Plan: " + premium_only;
                            FSA_Data += "\n" + "Medical Spending Account: " + MedicalSpendingAccountMinimum + " / " + MedicalSpendingAccountMaximum;
                            FSA_Data += "\n" + "Dependent Care Accounts: " + DependentCareAccountMinimum + " / " + DependentCareAccountMaximum;


                            oWordDoc.Tables[FSATableNo].Cell(1, 3).Range.Text = FSA_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Premium Only Plan:", "Medical Spending Account:", "Dependent Care Accounts: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, FSATableNo);
                            #endregion
                            string SummaryName = PlanTable.Rows[k]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {


                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("FSASUMMARYNAME" + FSAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("FSA PLAN TYPE" + FSAcount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            FSAcount++;


                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        public void WriteVisionSection(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, string SessionId, string ClientID, DataSet AccountDS)
        {
            try
            {
                Hashtable HashtableVisionBenefit = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefit.Add(3, "195");   //Examination[Copay]
                HashtableVisionBenefit.Add(4, "344");   //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefit.Add(6, "194");   //Examination[Frequency]
                HashtableVisionBenefit.Add(7, "309");   //Hardware[Lenses]
                HashtableVisionBenefit.Add(8, "207");   //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefit.Add(9, "122");   //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(11, "507");      //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefit.Add(12, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(13, "208");     //Covered Services – Frames
                #endregion
                string FundingType = "";
                string value = "";
                int VisionTableNo = 53;
                int VisionCount = 1; //For 6 different dental plans
                DataTable Emp = new DataTable();

                ////Emp = bp.GetEmployeeData(ClientID);
                if (AccountDS.Tables.Count > 2)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0 && AccountDS.Tables[0].Rows != null)
                    {
                        Emp = AccountDS.Tables[2];
                    }
                }


                string CopayExamination_Plan1 = string.Empty;
                string CopayMaterials_Plan1 = string.Empty;
                string BenefitFrequency_Examination_Plan1 = string.Empty;
                string Single_Vision_Lenses_Plan1 = string.Empty;
                string Covered_Services_Frames_Plan1 = string.Empty;
                string Medically_Necessary_Plan1 = string.Empty;
                string BenefitFrequency_Lenses_Plan1 = string.Empty;
                string BenefitFrequency_Frames_Plan1 = string.Empty;
                string BenefitFrequency_Contacts_Plan1 = string.Empty;
                string Vision_Carrier_Plan1 = string.Empty;
                string Vision_Summary_Plan1 = string.Empty;
                string Elective_Contacts_Plan1 = string.Empty;
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (VisionCount == 1)
                        {
                            VisionTableNo = 53;
                        }
                        if (VisionCount == 2)
                        {
                            VisionTableNo = 54;
                        }
                        if (VisionCount == 3)
                        {
                            VisionTableNo = 55;
                        }
                        if (VisionCount == 4)
                        {
                            VisionTableNo = 56;
                        }
                        if (VisionCount == 5)
                        {
                            VisionTableNo = 57;
                        }
                        if (VisionCount == 6)
                        {
                            VisionTableNo = 58;
                        }
                        int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);
                        int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(Convert.ToInt32(PlanTable.Rows[k]["ProductId"]), SessionId);
                        switch (OptionFieldValueiD)
                        {
                            case 52403: FundingType = "Self Funded"; break;
                            case 52401: FundingType = "Fully Insured"; break;
                            case 52400: FundingType = ""; break;
                            default: FundingType = ""; break;
                        }
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            DataTable EligibilityDS = new DataTable();

                            if (PlanTable.Rows[k]["EligibilityId"] != null && Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]) != -1)
                            {
                                int EleigibilityRuleId = Convert.ToInt32(PlanTable.Rows[k]["EligibilityId"]);
                                EligibilityDS = sd.GetEligibilityRule_AccountProfile(PlanTable, SessionId, EleigibilityRuleId);
                            }
                            #region Vision




                            //ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {

                                            case 3: CopayExamination_Plan1 = value.Trim_String(); break;
                                            case 6: BenefitFrequency_Examination_Plan1 = value.Trim_String(); break;
                                            //case 5: Medically_Necessary_Plan1 = value.Trim_String(); break;

                                            /*------------------------*************************************************
                                             This code is commented by Amogh as per Nicole [Account Profile-Detailed - Issue #23 - Vision data not correct]
                                            case 9: BenefitFrequency_Lenses_Plan1 = value.Trim_String(); break;
                                            ****************************************************************************/
                                            case 7: BenefitFrequency_Lenses_Plan1 = value.Trim_String(); break;
                                            case 8: BenefitFrequency_Frames_Plan1 = value.Trim_String(); break;
                                            case 11: Single_Vision_Lenses_Plan1 = value.Trim_String(); break;
                                            case 12: Elective_Contacts_Plan1 = value.Trim_String(); break;
                                            case 13: Covered_Services_Frames_Plan1 = value.Trim_String(); break;

                                            //case 8: BenefitFrequency_Contacts_Plan1 = value.Trim_String(); break;
                                            case 4: CopayMaterials_Plan1 = value.Trim_String(); break;

                                        }
                                    }
                                }
                            }


                            #endregion
                            #region Vision Plan Info writing


                            string Vision_Data = "";
                            oWordDoc.Tables[VisionTableNo].Cell(1, 1).Range.Text = "Carrier: " + Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            //oWordDoc.Tables[VisionTableNo].Cell(1, 1).Range.Characters[1].Bold = 1;
                            oWordDoc.Tables[VisionTableNo].Cell(1, 2).Range.Text = "Group #: " + Convert.ToString(PlanTable.Rows[k]["PolicyNumber"]);
                            oWordDoc.Tables[VisionTableNo].Cell(2, 1).Range.Text = "Effective Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VisionTableNo].Cell(2, 2).Range.Text = "Renewal Date: " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                            oWordDoc.Tables[VisionTableNo].Cell(3, 1).Range.Text = "Funding Type: " + FundingType;
                            oWordDoc.Tables[VisionTableNo].Cell(3, 2).Range.Text = "Eligible Employees: " + NoofELGEmployee.ToString("#,##0");

                            string DefinationOf_eligible_Emplyee = "";
                            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
                            {
                               // string DefinationOf_eligible_Emplyee = " ";
                                //////IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                //////                             where product.Field<double>("EMPLOYEE_TYPE_ID") == Convert.ToDouble(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                //////                             select product;
                                //////foreach (DataRow Def_Eligible_Emp in query)
                                //////{
                                //////    DefinationOf_eligible_Emplyee = Def_Eligible_Emp.Field<string>("EMPLOYEE_STATUS_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYMENT_TYPE_DESC") + " " + Def_Eligible_Emp.Field<double>("VALUE") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_UOM_DESC") + " " + Def_Eligible_Emp.Field<string>("EMPLOYEE_FREQUENCY_DESC");
                                //////}
                                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                                             select product;
                                foreach (DataRow Def_Eligible_Emp in query)
                                {
                                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                                }
                                // oWordDoc.Tables[VisionTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Convert.ToString(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"]).Trim();

                                oWordDoc.Tables[VisionTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]) + " for " + DefinationOf_eligible_Emplyee;
                                //string domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                //oWordDoc.Tables[VisionTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                                //oWordDoc.Tables[VisionTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);
                            }

                            if (DefinationOf_eligible_Emplyee=="")
                            {
                                oWordDoc.Tables[VisionTableNo].Cell(4, 1).Range.Text = "Eligibility: " + Convert.ToString(EligibilityDS.Rows[0]["item"]);
                            }
                            string domesticPartner = Convert.ToString(EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"]);
                            if (domesticPartner != "")
                            {
                                domesticPartner = domesticPartner.Trim();
                            }
                            oWordDoc.Tables[VisionTableNo].Cell(5, 1).Range.Text = "Domestic Partners Status: " + domesticPartner;
                            oWordDoc.Tables[VisionTableNo].Cell(6, 1).Range.Text = "Dependent Child Age: " + Convert.ToString(EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"]);

                            Vision_Data = "Exam Copay: " + CopayExamination_Plan1;
                            Vision_Data += "\n" + "Exam Frequency: " + BenefitFrequency_Examination_Plan1;
                            Vision_Data += "\n" + "Materials Copay: " + CopayMaterials_Plan1;
                            Vision_Data += "\n" + "Lens / Frame Frequency: " + BenefitFrequency_Lenses_Plan1 + " / " + BenefitFrequency_Frames_Plan1;
                            Vision_Data += "\n" + "Single Lenses: " + Single_Vision_Lenses_Plan1;
                            Vision_Data += "\n" + "Elective Contact Lens: " + Elective_Contacts_Plan1;
                            Vision_Data += "\n" + "Frames: " + Covered_Services_Frames_Plan1;


                            oWordDoc.Tables[VisionTableNo].Cell(1, 3).Range.Text = Vision_Data;
                            string[] makeBold = new string[] { " ", "Carrier:", "Group #: ", "Effective Date:", "Renewal Date:", "Funding Type:", "Eligible Employees: ", "Eligibility: ", "Domestic Partners Status: ", "Dependent Child Age: ", "Exam Copay: ", "Exam Frequency: ", "Materials Copay: ", "Lens / Frame Frequency: ", "Single Lenses: ", "Elective Contact Lens: ", "Frames: " };
                            sd.makeboldtabletext(oWordDoc, oWordApp, makeBold, VisionTableNo);
                            //foreach (string s in makeBold)
                            //{                                oWordDoc.Tables[DentalTableNo].Select();
                            //    oWordApp.Selection.Find.Text = s; //changes with each iteration
                            //    oWordApp.Selection.Find.Execute();
                            //    oWordApp.Selection.Font.Bold = 1;
                            //    oWordApp.Selection.Collapse(); //used to 'clear' the selection
                            //    oWordApp.Selection.Find.ClearFormatting();
                            //}

                            #endregion
                            string SummaryName = PlanTable.Rows[k]["SummaryName"].ToString().Replace("'", "''");
                            string PlanType = Convert.ToString(PlanTable.Rows[k]["ProductTypeDescription"]);
                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {


                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("VISIONSUMMARYNAME" + VisionCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(SummaryName));
                                    }
                                    if (fieldName.Contains("VISION PLAN TYPE" + VisionCount))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Convert.ToString(PlanType));
                                    }


                                }
                            }
                            #endregion
                            VisionCount++;

                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}




