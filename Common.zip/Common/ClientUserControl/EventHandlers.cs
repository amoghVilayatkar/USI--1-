﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.ClientUserControl
{
    public delegate void ClientChanged(object sender, ClientSelectedEventArgs Args);
    public delegate void ClientReset(object sender);
    public delegate void ClientSearchClicked(object sender);
}