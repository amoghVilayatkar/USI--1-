﻿using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.Runtime.InteropServices;

using BenefitPointSummaryPortal.BAL.AnalysisTemplate; 
namespace BenefitPointSummaryPortal.View
{
    public partial class AncillaryPanelCarrier : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        string SessionId = "";
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        Dictionary<string, List<string>> dictRegionCarrierMap = new Dictionary<string, List<string>>();
        Dictionary<string, string> AccountRegionMatrix = new Dictionary<string, string>();
        Dictionary<string, string> CarrierNameAssignedFiles = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        List<string> SelecetdfileName = new List<string>();
        WriteAncillaryPanelCarrierTemplate wr = new WriteAncillaryPanelCarrierTemplate();
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
               
                if (Session["Summary"] == "AncillaryPanelCarrier")
                {
                    Page.MaintainScrollPositionOnPostBack = true;
                    div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                    LoadRegionCarriers();
                    LoadAccountRegionMatrix();
                     LoadCarrierAssignedFile();
                    if (!IsPostBack)
                    {
                        mvMedicalLOC.ActiveViewIndex = 0;
                        SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                        SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                        Session["SessionId"] = SessionId;
                        objCommFun.GetUserDetails();
                        Activity_Group = "Analytics";
                        Activity = TitleSpan.InnerText;
                        Session["DeliverableCategory"] = "Analytics";
                        ddlcontents.SelectedValue = "0";
                        ddlcontents_SelectedIndexChanged(null, null);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void ddlcontents_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtLetterDecription.Text = "";
            txtLetterDecription.Visible = false;
            tblCarrierDetails.Style.Add("display", "none");
            switch (ddlcontents.SelectedValue)
            {
                case "Ancillary_Panel_Matrix":
                    txtLetterDecription.Visible = true;
                    txtLetterDecription.Text = "The Ancillary Panel Matrix is a summary of panel carriers for the specified region including information for each carrier’s product capability, segments covered, and differentiators.";
                    break;
                case "Ancillary_Carriers_Detailed_Information":
                    txtLetterDecription.Visible = true;
                    txtLetterDecription.Text = "Select the carrier(s) below for an Ancillary Carriers Detailed Information – a summary of the specific carrier’s product capability, segments covered, differentiators, and value added offerings.";
                    tblCarrierDetails.Style.Add("display", "");
                    break;
            }
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {

                if (ValidateForm())
                {
                    if (ddlcontents.SelectedValue == "Ancillary_Panel_Matrix")
                    {
                        Download_AncillaryPanelCarrierMatrix();
                    }
                    else if (ddlcontents.SelectedValue == "Ancillary_Carriers_Detailed_Information")
                    {

                        string filename = CreateTemplate_AncillaryPanelCarriers();
                        DownloadFileNew_PDFFormat(filename);
                    }

                    #region ------- Code for Add Activity Log --------
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    List<Contact> ContactList = new List<Contact>();
                    SessionId = Session["SessionId"].ToString();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, " ");
                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    string AdditionalCrtieriaOption_1 = ddlcontents.SelectedValue;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DictDepartment = sd.getDepartmentDetails();
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                    #endregion

                }

                
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SessionId = Session["SessionId"].ToString();
                hdnAccountRegion.Value = "";
                hdnAccountOffice.Value = ""; ;
                if (ddlClient.SelectedIndex > 0)
                {
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    hdnAccountRegion.Value = Account_Region.ToLower();
                    hdnAccountOffice.Value = Account_Office;
                }
                BindCarrierCheckBoxList();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        private void ResetForm()
        {
            txtsearch.Text = "";
            rdlClient.SelectedIndex = 0;
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", "0"));
            ddlcontents.SelectedValue = "0";
            ddlcontents_SelectedIndexChanged(null, null);
            ddlClient_SelectedIndexChanged(null, null);


        }

         


        //private void LoadRegionCarriers_old()
        //{
        //    dictRegionCarrierMap["mid-atlantic"] = new List<string>() { "Anthem", "Guardian", "The Hartford", "Lincoln", "Metlife", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["midsouth"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "The Standard", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["midwest"] = new List<string>() { "Anthem", "Guardian", "The Hartford", "Lincoln", "Metlife", "SunLife" };
        //    dictRegionCarrierMap["mountain"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["new england"] = new List<string>() { "Anthem", "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["northeast"] = new List<string>() { "Anthem", "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["northwest"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "The Standard", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["southeast"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "The Standard", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["southwest"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "The Standard", "SunLife", "UnitedHealthcare", "Voya" };
        //    dictRegionCarrierMap["west"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "The Standard", "SunLife", "UnitedHealthcare", "Voya" };
        //}
        private void LoadRegionCarriers()
        {
            dictRegionCarrierMap["mid-atlantic"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Anthem"}; //"Voya"
            dictRegionCarrierMap["midsouth"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Cigna","Reliance Standard","The Standard" }; //"Voya"
            dictRegionCarrierMap["midwest"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Anthem" }; //"Voya"
            dictRegionCarrierMap["mountain"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC" }; //"Voya"
            dictRegionCarrierMap["new england"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Anthem","Cigna", "The Standard" }; //"Voya"
            dictRegionCarrierMap["northeast"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Anthem", "Reliance Standard"}; //"Voya"
            dictRegionCarrierMap["northwest"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC","Cigna", "The Standard" }; //"Voya"
            dictRegionCarrierMap["southeast"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Cigna", "The Standard" }; //"Voya"
            dictRegionCarrierMap["southwest"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "The Standard" }; //"Voya"
            dictRegionCarrierMap["west"] = new List<string>() { "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha", "Prudential", "SunLife", "UnitedHealthcare", "AFLAC", "Cigna" }; //"Voya"
            // {  "Guardian", "The Hartford", "Lincoln", "Metlife", "Mutual of Omaha","Prudential", "SunLife", "UnitedHealthcare", "AFLAC","Anthem","The Standard" }; //"Voya"
        }


        private void BindCarrierCheckBoxList()
        {
            if (dictRegionCarrierMap.ContainsKey(hdnAccountRegion.Value))
            {
                List<string> Carriers = dictRegionCarrierMap[hdnAccountRegion.Value];
                cblCarries.DataSource = Carriers;
                cblCarries.DataBind();
            }
            else
            {
                cblCarries.Items.Clear();
            }
        }
        private bool ValidateForm()
        {

            List<string> SelecetdCarrier = new List<string>();
            foreach (ListItem ch in cblCarries.Items)
            {
                if (ch.Selected == true)
                {
                    SelecetdCarrier.Add(ch.Value);

                }
            }
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return false;
            }
            if (ddlcontents.SelectedIndex == 0 || ddlcontents.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Content.')</script>");
                ddlcontents.Focus();
                return false;
            }
            
            if ((SelecetdCarrier.Count == 0) && (ddlcontents.SelectedValue == "Ancillary_Carriers_Detailed_Information"))
            {

                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select at least one carrier.')</script>");
                ddlcontents.Focus();
                return false;
            }
            return true;
        }
        //private void LoadAccountRegionMatrix()
        //{
        //    AccountRegionMatrix.Add("mid-atlantic", "USI_Ancillary_Panel_Matrix_v7_30_2018_MA.pdf");
        //    AccountRegionMatrix.Add("midsouth", "To be provided");
        //    AccountRegionMatrix.Add("midwest", "USI_Ancillary_Panel_Matrix_v7_30_2018_MW.pdf");
        //    AccountRegionMatrix.Add("mountain", "USI_Ancillary_Panel_Matrix_v7_30_201_MT.pdf");
        //    AccountRegionMatrix.Add("new england", "USI_Ancillary_Panel_Matrix_v7_30_2018_NG.pdf");
        //    AccountRegionMatrix.Add("northeast", "USI_Ancillary_Panel_Matrix_v7_30_2018_NE.pdf");
        //    AccountRegionMatrix.Add("northwest", "To be provided");
        //    AccountRegionMatrix.Add("southeast", "USI_Ancillary_Panel_Matrix_v7_30_2018_SE.pdf");
        //    AccountRegionMatrix.Add("southwest", "USI_Ancillary_Panel_Matrix_v7_30_2018_SW.pdf");
        //    AccountRegionMatrix.Add("west", "USI_Ancillary_Panel_Matrix_v7_30_2018_WE.pdf");
        //}

        private void LoadAccountRegionMatrix()
        {
            AccountRegionMatrix.Add("mid-atlantic", "MA_USI_Ancillary_Panel_Matrix_v7_9_2019.pdf");
            AccountRegionMatrix.Add("midsouth", "MS_USI_Ancillary_Panel_Matrix_v6_26_2019.pdf");
            AccountRegionMatrix.Add("midwest", "MW_USI_Ancillary_Panel_Matrix_v7_9_2019.pdf");
            AccountRegionMatrix.Add("mountain", "MT_USI_Ancillary_Panel_Matrix_v7_9_2019.pdf");
            AccountRegionMatrix.Add("new england", "NG_USI_Ancillary_Panel_Matrix_v6_26_2019.pdf");
            AccountRegionMatrix.Add("northeast", "NE_USI_Ancillary_Panel_Matrix_v7_9_2019.pdf");
            AccountRegionMatrix.Add("northwest", "NW_USI_Ancillary_Panel_Matrix_v6_26_2019.pdf");
            AccountRegionMatrix.Add("southeast", "SE_USI_Ancillary_Panel_Matrix_v6_26_2019.pdf");
            AccountRegionMatrix.Add("southwest", "SW_USI_Ancillary_Panel_Matrix_v3_26_2019.pdf");
            AccountRegionMatrix.Add("west", "WE_USI_Ancillary_Panel_Matrix_v6_26_2019.pdf");
        }
        private void LoadCarrierAssignedFile()
        {
            CarrierNameAssignedFiles.Add("Guardian", "Guardian_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("The Hartford", "Hartford_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("Lincoln", "Lincoln One Pager - February 2019.docx");
            CarrierNameAssignedFiles.Add("Metlife", "Metlife One Pager - March 2019.docx");
            CarrierNameAssignedFiles.Add("Mutual of Omaha", "Omaha_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("Prudential", "Prudential One Pager - March 2019.docx");
            CarrierNameAssignedFiles.Add("SunLife", "Sunlife_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("UnitedHealthcare", "UHC_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("AFLAC", "AFLAC One Pager - July 2018.docx");
            CarrierNameAssignedFiles.Add("Anthem", "Anthem_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("The Standard", "Standard_One_Pager_July_2018.docx");
            CarrierNameAssignedFiles.Add("Cigna", "Cigna_One_Pager_June_2019.docx");
            CarrierNameAssignedFiles.Add("Reliance Standard", "Reliance_Standard_One_Pager_June_2019.docx");


            //CarrierNameAssignedFiles.Add("Voya", "Voya_One_Pager_July_2018.docx");
        }
        private void Download_AncillaryPanelCarrierMatrix()

            {
                try
                {

                    string myPath = Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/");

                    if (AccountRegionMatrix.ContainsKey(hdnAccountRegion.Value))
                    {

                        string filename = AccountRegionMatrix[hdnAccountRegion.Value];
                        myPath = myPath + filename;
                        if (filename == "To be provided")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('USI Ancillary Panel Matrix is not available for " + hdnAccountRegion.Value + " region')</script>");
                            ddlClient.Focus();
                            return;
                        }
                        string savefilename = Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/download/NewDocument" + System.DateTime.Now.Year.ToString() +
                        System.DateTime.Now.Month.ToString() +
                                         System.DateTime.Now.Day.ToString() +
                                          System.DateTime.Now.Hour.ToString() +
                                           System.DateTime.Now.Minute.ToString() +
                                          System.DateTime.Now.Second.ToString() +
                                          System.DateTime.Now.Millisecond.ToString() +
                                         ".PDF");

                        if (!Directory.Exists(Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/download/")))
                        {
                            Directory.CreateDirectory(Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/download/"));
                        }

                        File.Copy(myPath, savefilename, true);
                        DownloadFileNew_PDFFormat(savefilename.ToString());
                    }
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
               
        }

        public void DownloadFileNew_PDFFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "Application/pdf";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DownloadFileNew_WordFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                  

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected string CreateTemplate_AncillaryPanelCarriers()
        {
            Object missing = System.Reflection.Missing.Value;
            //Global variables
            Word_Office officeobj = new Common.BenefitSummary.Word_Office();
            WordOpenClose wobj = new WordOpenClose();
            string PDFPath = string.Empty;
            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/download")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/AncillaryPanelCarrier/Documents/Templates/download"));
                }
                string filename = "~/Files/AncillaryPanelCarrier/Documents/Templates/Blank.docm";
                string _savefilename = "~/Files/AncillaryPanelCarrier/Documents/Templates/download/NewDocument";
                PDFPath = "~/Files/AncillaryPanelCarrier/Documents/Templates/download/NewDocument";
                PDFPath = Server.MapPath(_savefilename + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +

                                 ".pdf");

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);


                foreach (ListItem ch in cblCarries.Items)
                {
                    if (ch.Selected == true)
                    {
                        if (CarrierNameAssignedFiles.ContainsKey(ch.Value))
                        {
                            string filenames = CarrierNameAssignedFiles[ch.Value];
                            SelecetdfileName.Add(filenames);
                        }

                    }
                }
                Word.Range range = wobj.office.oWordDoc.Bookmarks["AddCarriers"].Range;
                wr.AttacheWordFiles(SelecetdfileName, range, wobj.office.oWordDoc);
                wobj.office.oWordDoc.Bookmarks["AddCarriers"].Range.Delete();
                wobj.office.oWordDoc.Save();
                wobj.ExportToPDF(PDFPath);
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }
            return (PDFPath);
        }
    }
}