﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.DAL;
using BenefitPointSummaryPortal.BAL.BenifitPointServiceSetting;
using BenefitPointSummaryPortal.BAL.BenefitSummary;


namespace BenefitPointSummaryPortal.View
{
    public partial class ServiceSetting : System.Web.UI.Page
    {
        BPSummary bp = new BPSummary();
        DBHelper DB_helper = new DBHelper();
        ServiceSettingOperations serviceSettingOp;
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                objCommFun.GetUserDetails();
                btnSearch_Click(null, null);
                txtSearchServiceName.Focus();
                mvServicesSetting.ActiveViewIndex = 0;
                hdnSrNo.Value = "0";
                btnSearch_Click(null, null);

            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            hdnSrNo.Value = "0";
            mvServicesSetting.ActiveViewIndex = 1;
            txtServiceName.Focus();
            ClearServiceSettingDetailForm();
            bntSave.Text = "Save";
            txtServiceCode.Enabled = true;
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchServiceSettingData();
        }
        private void SearchServiceSettingData()
        {
            try
            {
                string strSericeName = txtSearchServiceName.Text.Trim();
                string strUserName = txtSearchUserName.Text.Trim();
                string strActiveStatus = ddlSearchStatus.SelectedValue;
                serviceSettingOp = new ServiceSettingOperations();
                DataTable dtblServiceSetting = serviceSettingOp.SearchServiceSettingData(strSericeName, strUserName, strActiveStatus);
                grdAddresses.DataSource = dtblServiceSetting;
                grdAddresses.DataBind();
                ClearServiceSettingDetailForm();
            }
            catch (Exception ex)
            {
            }
        }
        protected void bntSave_Click(object sender, EventArgs e)
        {
            try
            {
                serviceSettingOp = new ServiceSettingOperations();

                string UserLogin = Session["UserLoginName"].ToString();
                bool ISActive = chkStatus.Checked ? true : false;
                bool IsDuplicate = serviceSettingOp.IsDuplicateBenifitPointService(int.Parse(hdnSrNo.Value), txtServiceName.Text.Trim(), txtServiceCode.Text.Trim());
                if (!IsDuplicate)
                {
                    DataTable dtblresult = serviceSettingOp.InsertUpdateBenifitPointServices(int.Parse(hdnSrNo.Value), txtServiceName.Text.Trim(), txtUrl.Text.Trim(), txtUserName.Text.Trim(), txtPassword.Text.Trim(), ISActive, false, UserLogin, txtServiceCode.Text.Trim());
                    bool flag = dtblresult.Rows[0]["IsSuccess"].ToString().ToLower() == "true" ? true : false;
                    if (flag)
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Benifit point service updated successfully.')</script>", false);
                        mvServicesSetting.ActiveViewIndex = 0;
                        ClearServiceSettingDetailForm();
                        hdnSrNo.Value = "0";
                        btnClear_Click(null, null);
                        btnSearch_Click(null, null);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while insert/updating record, please try again')</script>", false);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Duplicate Service Name or Service Code')</script>", false);
                }
            }
            catch (Exception ex)
            {
                BPBusiness bp = new BPBusiness();
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearServiceSettingDetailForm();
            mvServicesSetting.ActiveViewIndex = 0;
            txtSearchServiceName.Focus();
            hdnSrNo.Value = "0";
        }
        protected void grdServices_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string RowCommand = e.CommandName;
            if (RowCommand == "EditService")
            {
                mvServicesSetting.ActiveViewIndex = 1;
                txtServiceName.Focus();
                ClearServiceSettingDetailForm();
                FillServicesSettingDetails(int.Parse(e.CommandArgument.ToString()));
                bntSave.Text = "Update";
            }
            else if (RowCommand == "DeleteService")
            {
                try
                {
                    serviceSettingOp = new ServiceSettingOperations();
                    bool IsSuccess = serviceSettingOp.DeleteServiceSetting(int.Parse(e.CommandArgument.ToString()));
                    if (IsSuccess)
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Benifit Point service deleted successfully.')</script>", false);
                        btnSearch_Click(null, null);
                    }
                    else
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while deleting record, please try again')</script>", false);
                }
                catch (Exception ex)
                {

                }
            }
        }
        private void FillServicesSettingDetails(int ServiceID)
        {
            hdnSrNo.Value = ServiceID.ToString();

            if (hdnSrNo.Value != "0")
            {
                txtServiceCode.Enabled = false;
            }
            serviceSettingOp = new ServiceSettingOperations();

            DataTable dtblServiceSetting = serviceSettingOp.GetServiceSettingById(ServiceID);
            if (dtblServiceSetting != null && dtblServiceSetting.Rows.Count > 0)
            {

                txtServiceName.Text = dtblServiceSetting.Rows[0]["ServiceName"].ToString();
                txtServiceCode.Text = dtblServiceSetting.Rows[0]["ServiceCode"].ToString();
                txtUrl.Text = dtblServiceSetting.Rows[0]["ServiceUrl"].ToString();
                txtUserName.Text = dtblServiceSetting.Rows[0]["UserName"].ToString();
                txtPassword.TextMode = TextBoxMode.SingleLine;
                txtPassword.Attributes["value"] = serviceSettingOp.Decrypt(dtblServiceSetting.Rows[0]["Password"].ToString());
                txtPassword.TextMode = TextBoxMode.Password;
                txtConfirmPassword.TextMode = TextBoxMode.SingleLine;
                txtConfirmPassword.Attributes["value"] = serviceSettingOp.Decrypt(dtblServiceSetting.Rows[0]["Password"].ToString());
                txtConfirmPassword.TextMode = TextBoxMode.Password;
                chkStatus.Checked = bool.Parse(dtblServiceSetting.Rows[0]["IsActive"].ToString());
            }
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearchServiceName.Text = "";
            txtSearchUserName.Text = "";
            ddlSearchStatus.SelectedValue = "2";
        }
        private void ClearServiceSettingDetailForm()
        {
            txtUrl.Text = "";
            txtServiceName.Text = "";
            txtServiceCode.Text = "";
            txtPassword.Attributes["value"] = "";
            txtConfirmPassword.Attributes["value"] = "";
            txtUserName.Text = "";
            chkStatus.Checked = false;

        }


    }
}