﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Drawing;
using System.Configuration;

namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTools_ClientRevenueSummary : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        int Row_No = 8;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="myExcelApp"></param>
        /// <param name="ddlClient"></param>
        /// <param name="ProductTypeDescription"></param>
        /// <param name="AccountDS"></param>
        /// <param name="AccountTeamMemberDS"></param>
        public void WriteClientOverview(Excel.Application myExcelApp, DropDownList ddlClient, string ProductTypeDescription, DataSet AccountDS, DataSet AccountTeamMemberDS)
        {

            int count = 1;

            Excel.Worksheet wkSheet = null;
            if (count == 1)
            {
                wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets[ProductTypeDescription];
            }

            string SalesLead_FirstName = string.Empty;
            string SalesLead_LastName = string.Empty;
            string ServiceLead_FirstName = string.Empty;
            string ServiceLead_LastName = string.Empty;
            string Num_Of_FTE = string.Empty;
            string Num_Of_FTE_AS_Of = string.Empty;
            try
            {
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]).Trim();
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]).Trim();
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            //{
                            //    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                            //    {
                            //        Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                            //    }
                            //}
                        }
                    }
                }
                //Primary Industry
                var pIndustry = from acct1 in AccountDS.Tables[1].AsEnumerable()
                                select acct1.Field<string>("groupAccountInfo_commonGroupAccountInfo_primaryIndustry");
                string primaryIndustry = Convert.ToString(pIndustry.First());


                wkSheet.Cells[1, 1] = Convert.ToString(ddlClient.SelectedItem.Text);
                //wkSheet.Cells[1, 9] = Num_Of_FTE + " as of " + Num_Of_FTE_AS_Of;
                wkSheet.Cells[1, 10] = Num_Of_FTE;
                wkSheet.Cells[2, 10] = SalesLead_FirstName + " " + SalesLead_LastName;
                wkSheet.Cells[3, 10] = ServiceLead_FirstName + " " + ServiceLead_LastName;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Plan Section to template.
        /// </summary>
        /// <param name="myExcelApp">Excel Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="ddlClient">DropDownList ddlClient for showing client name</param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="SummaryId">string SummaryId for summary id</param>
        /// <param name="ProductTypeDescription">string ProductTypeDescription</param>
        /// <param name="EligibilityDS">DataSet EligibilityDS</param>
        /// <param name="MainAddress">string MainAddress</param>
        /// <param name="UOM">string UOM</param>
        public void WritePlanSection(Excel.Application myExcelApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet RateDS, DropDownList ddlClient, DataSet AccountDS, DataSet BenefitStructureDS, DataSet AccountTeamMemberDS, List<Carrier> carrierList, string SummaryId, int OptionFieldValueiD)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();

                //Funding
                string FundingType = "";
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self Funded"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }

                int k = 0;
                double monthlypremiumvalue = 0;
                double Annuallypremiumvalue = 0;
                double monthlypremiumvalueTotal = 0;
                double AnnuallypremiumvalueTotal = 0;
                double annualrevenue = 0;
                double monthlyrevenue = 0;
                double annualrevenueTotal = 0;
                double monthlyrevenueTotal = 0;
                Excel.Worksheet wkSheet = (Excel.Worksheet)myExcelApp.ActiveWorkbook.Worksheets["Revenue Summary"];

                for (k = 0; k < BenefitDS.Tables["BenefitSummaryTable"].Rows.Count; k++)
                {
                    if (SummaryId == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString())
                    {
                        # region Common Field for All Plans
                        bool containsSummaryID = RateDS.Tables["BenefitSummaryRateTable"].AsEnumerable().Any(row => row.Field<Int32>("associatedBenefitSummaries_benefitSummaryID") == Convert.ToInt32(SummaryId));
                        if (!containsSummaryID)
                        {
                            wkSheet.Cells[Row_No, 1] = Convert.ToString(PlanTable.Rows[k]["Name"]).Replace("&amp;", "&");
                            wkSheet.Cells[Row_No, 2] = Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&");
                            wkSheet.Cells[Row_No, 4] = Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                            wkSheet.Cells[Row_No, 5] = FundingType;
                        }

                        for (int i = 0; i < RateDS.Tables["RateTable"].Rows.Count; i++)
                        {
                            if (SummaryId == RateDS.Tables["BenefitSummaryRateTable"].Rows[i]["associatedBenefitSummaries_benefitSummaryID"].ToString())
                            {
                                wkSheet.Cells[Row_No, 1] = Convert.ToString(PlanTable.Rows[k]["Name"]).Replace("&amp;", "&");
                                wkSheet.Cells[Row_No, 2] = Convert.ToString(PlanTable.Rows[k]["SummaryName"]).Replace("&amp;", "&");
                                wkSheet.Cells[Row_No, 4] = Convert.ToString(PlanTable.Rows[k]["Carrier"]);
                                wkSheet.Cells[Row_No, 5] = FundingType;

                                //monthlypremiumvalue = Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyPremium"]));
                                Annuallypremiumvalue = Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyPremium"]));
                                //	Annual Premium value will be Monthly Premium multiplied by 12
                                //Annuallypremiumvalue = monthlypremiumvalue * 12;
                                monthlypremiumvalue = Convert.ToDouble(Annuallypremiumvalue / 12);
                                annualrevenue = Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyRevenue"]));
                                monthlyrevenue = Convert.ToDouble(annualrevenue / 12);

                                wkSheet.Cells[Row_No, 3] = Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["description"]);
                                wkSheet.Cells[Row_No, 6] = Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["CommissionType"]).Replace("_", " ");
                                wkSheet.Cells[Row_No, 7] = Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["effectiveAsOf"]);
                                wkSheet.Cells[Row_No, 8] = Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["expirationOn"]);
                                wkSheet.Cells[Row_No, 9] = monthlypremiumvalue;
                                wkSheet.Cells[Row_No, 10] = monthlyrevenue;
                                wkSheet.Cells[Row_No, 11] = Annuallypremiumvalue;
                                wkSheet.Cells[Row_No, 12] = annualrevenue;

                                Row_No++;
                                wkSheet.Rows[Row_No].EntireRow.Insert();
                            }

                            monthlypremiumvalueTotal += Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyPremium"])) / 12;
                            //•	Annual Premium value (in Column J) will be Monthly Premium multiplied by 12
                            AnnuallypremiumvalueTotal += Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyPremium"]));
                            monthlyrevenueTotal += Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyRevenue"])) / 12;
                            annualrevenueTotal += Convert.ToDouble(Convert.ToString(RateDS.Tables["RateTable"].Rows[i]["estimatedMonthlyRevenue"]));
                        }

                        if (!containsSummaryID)
                        {
                            Row_No++;
                            wkSheet.Rows[Row_No].EntireRow.Insert();
                        }
                        #endregion
                    }
                }
                wkSheet.Cells[Row_No + 1, 9] = monthlypremiumvalueTotal;
                wkSheet.Cells[Row_No + 1, 10] = monthlyrevenueTotal;
                wkSheet.Cells[Row_No + 1, 11] = AnnuallypremiumvalueTotal;
                wkSheet.Cells[Row_No + 1, 12] = annualrevenueTotal;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}