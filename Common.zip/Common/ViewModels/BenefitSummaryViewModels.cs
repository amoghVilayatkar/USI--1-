﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.ViewModels
{
    public class BenefitSummaryStructure
    {
        string _LOC;
        int _MaxBenefitSummary;
        int _MaxContributionPerSummary;
        bool _BenefitSummaryApplicable = false;
        bool _ContributionApplicable = false;
        bool _IsRequired = false;
        bool _RateApplicable = false;
        int _MaxRatePerBenefitSummary;

        public string LOC
        {
            get { return _LOC; }
            set { _LOC = value; }
        }
        public int MaxBenefitSummary
        {
            get { return _MaxBenefitSummary; }
            set { _MaxBenefitSummary = value; }
        }
        public int MaxContributionPerSummary
        {
            get { return _MaxContributionPerSummary; }
            set { _MaxContributionPerSummary = value; }
        }
        public bool BenefitSummaryApplicable
        {
            get { return _BenefitSummaryApplicable; }
            set { _BenefitSummaryApplicable = value; }
        }
        public bool ContributionApplicable
        {
            get { return _ContributionApplicable; }
            set { _ContributionApplicable = value; }
        }
        public bool IsRequired
        {
            get { return _IsRequired; }
            set { _IsRequired = value; }
        }
        public bool RateApplicable
        {
            get { return _RateApplicable; }
            set { _RateApplicable = value; }
        }
        public int MaxRatePerBenefitSummary
        {
            get { return _MaxRatePerBenefitSummary; }
            set { _MaxRatePerBenefitSummary = value; }
        }
    }
    public class SummarySelectionViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductTypeDescription { get; set; }
        public string CarrierName { get; set; }
        public string EffectiveDate { get; set; }
        public string RenewalDate { get; set; }
        public string PolicyNumber { get; set; }
        public string SummaryName { get; set; }
        public int SummaryId { get; set; }
        public string LOC;
    }
    public class ValidationViewModel
    {
        public bool IsSuccess = true;
        public string ErrorMessage = string.Empty;
    }
    public class SummaryOptionItemViewModel
    {
        public string LOC { get; set; }
        public string OrderText { get; set; }
        public int OrderNumber { get; set; }

        public bool SummaryApplicable { get; set; }
        public string SummaryText { get; set; }
        public int SummaryId { get; set; }
        public int PlanId { get; set; }
        public int MaxBenefitSummaries { get; set; }


        public bool ContributionApplicable { get; set; }
        public int ContributionId1 { get; set; }
        public string ContributionText1 { get; set; }
        public int ContributionId2 { get; set; }
        public string ContributionText2 { get; set; }
        public int MaxContributionCount { get; set; }

        public bool RateApplicable { get; set; }
        public int RateId1 { get; set; }
        public string RateText1 { get; set; }
        public int RateId2 { get; set; }
        public string RateText2 { get; set; }
        public int MaxRateCount { get; set; }

        public List<BenefitSummaryDropDownViewModel> SummaryDataSource { get; set; }
    }
    public class BenefitSummaryDropDownViewModel
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
    public class ClientBenefitSummaryUIViewModel
    {
        public bool IsNextButtonVisibles;
        public bool IsPreviousButtonVisibles;
        public bool IsCreateButtonVisibles;
        public bool IsDeliverableDescriptionVisible;
        public bool IsCriteriaInformarionVisible;


        public string NextButtonText;
        public string PreviousButtonText;
        public string CreateButtonText;
        public string CriteraPageIndexText;
    }
}