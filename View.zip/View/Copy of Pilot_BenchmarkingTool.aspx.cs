﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using BenefitPointSummaryPortal.BAL.Tools;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.Pilot;


namespace BenefitPointSummaryPortal.View
{
    public partial class Pilot_BenchmarkingTool : System.Web.UI.Page
    {
        Hashtable myHashtable;

        #region Global Variable
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList(); // For newly added AD&D plan
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        ArrayList StopLossBenefitColumnIdList = new ArrayList();
        ArrayList FeesForServiceBenefitColumnIdList = new ArrayList();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                DictDepartment = sd.getDepartmentDetails();
                //if (Convert.ToString(Session["Summary"]) == "PatraTransmittal")
                //{
                //    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceContractReviewToBenchmarkAudit", "<script>ReplaceContractReviewToBenchmarkAudit()</script>", false);
                //    spanBenchmarkingAuditReport.Visible = true;
                //    spanContractReviewChecklists_Plan.Visible = false;
                //    spanBenchmarkingAuditReport_Pan.Visible = true;
                //    TitleSpan.InnerText = "Patra Transmittal";
                //}

                TitleSpan.InnerText = "Benchmarking Tool";
                if (!IsPostBack)
                {
                    // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    //if (Convert.ToString(Session["Summary"]) == "Tools_ContractReview")
                    //{
                    //    TitleSpan.InnerText = "Contract Review Checklist";
                    //}
                    //else if (Convert.ToString(Session["Summary"]) == "Benchmarking_AuditReport")
                    //{
                    //    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceContractReviewToBenchmarkAudit", "<script>ReplaceContractReviewToBenchmarkAudit()</script>", false);

                    //    TitleSpan.InnerText = "Benchmarking Audit Report";
                    //}

                    txtsearch.Focus();
                    Activity = TitleSpan.InnerText;
                    Activity_Group = "Analytics";
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                //pnlPlans.Visible = false;
                //grdPlans.DataSource = null;
                //grdPlans.DataBind();
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                // pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();

                //grdPlans.DataSource = null;
                //grdPlans.DataBind();

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    grdPlans.DataSource = null;
        //    grdPlans.DataBind();
        //}

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                DataTable PlanInfoTable = new DataTable();


                if (Convert.ToString(Session["Summary"]) == "BenchmarkingTool")
                {
                    if (ddlProspect_Client.SelectedIndex == 0 || ddlProspect_Client.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client/Prospect .')</script>");
                        flag = false;
                    }
                    if (ddlProspect_Client.SelectedValue == "Prospect" && string.IsNullOrEmpty(txtProspectName.Text))
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please Enter Prospect .')</script>");
                        flag = false;
                    }
                    if (ddlClient.SelectedIndex == -1 && ddlProspect_Client.SelectedValue == "Client")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }
                }

                if (flag == true)
                {

                    string Client = string.Empty;
                   
                    if (Convert.ToString(Session["Summary"]) == "BenchmarkingTool")
                    {
                        if (ddlProspect_Client.SelectedValue == "Prospect")
                        {
                            Client = Convert.ToString(txtProspectName.Text);
                        }
                        else if (ddlProspect_Client.SelectedValue == "Client")
                        {
                            Client = Convert.ToString(ddlClient.SelectedItem);
                        }
                        CreateReports_BenchmarkingTool(SessionId, Client);
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File in Excel Format.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void CheckExcellProcesses()
        {
            Process[] AllProcesses = Process.GetProcessesByName("Excel");
            myHashtable = new Hashtable();
            int iCount = 0;

            foreach (Process ExcelProcess in AllProcesses)
            {
                myHashtable.Add(ExcelProcess.Id, iCount);
                iCount = iCount + 1;
            }
        }

        private void KillExcel()
        {
            Process[] AllProcesses = Process.GetProcessesByName("Excel");

            // check to kill the right process
            foreach (Process ExcelProcess in AllProcesses)
            {
                if (myHashtable.ContainsKey(ExcelProcess.Id) == false)
                    ExcelProcess.Kill();
            }

            AllProcesses = null;
        }

        /// <summary>
        /// Create PatraTransmittal Report
        /// </summary>
        protected void CreateReports_BenchmarkingTool(string SessionId, string Client)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Workbook myWorkbookdest = null;

            Excel.Worksheet myWorksheet = null;
            Excel.Worksheet myWorksheetdest = null;

            try
            {
                SessionId = Session["SessionId"].ToString();
                myExcelApp = new Excel.Application();
                Object missing = System.Reflection.Missing.Value;
                string myPath = Server.MapPath("~/Files/Pilot/Documents/Templates/BenchmarkingTool.xlsm");
                string myPathdest = Server.MapPath("~/Files/Pilot/Documents/Templates/BenchmarkingTool_Secondary.xlsm");

                myExcelApp.Visible = false;
                myExcelApp.DisplayAlerts = false;

                myWorkbook = myExcelApp.Workbooks.Open(myPath, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);

                myWorkbookdest = myExcelApp.Workbooks.Open(myPathdest, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);


                //myWorksheet = (Excel.Worksheet)myWorkbook.Sheets[1];
                ////   myWorksheet.Copy(missing, myWorksheetdest);   //Copy from source to destination


                // myWorksheetdest = (Excel.Worksheet)myWorkbookdest.Worksheets.Add(missing, missing, missing, missing);

                myWorksheetdest = myWorkbookdest.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Report3/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsm");

                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Report3")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Report3"));
                }

                myWorkbookdest.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                WritePilot_BenchmarkingTool wr = new WritePilot_BenchmarkingTool();

                //// get process ids before running the excel codes
                //CheckExcellProcesses();

                //Excel.Worksheet wkSheet1 = (Excel.Worksheet)myWorkbook.Worksheets[1];
                //(myWorkbook.Worksheets[wkSheet1.Name] as Excel.Worksheet).Copy(Before: myWorkbookdest.Worksheets[1]);
                // myWorksheetdest = myWorkbookdest.Worksheets[1];
                wr.WriteClientOverview(myExcelApp, Client);



                /////Deleting Sheet1(Default Sheet)
                if (myWorkbookdest.Worksheets.Count > 1)
                {
                    for (int i = 1; i <= myWorkbookdest.Worksheets.Count; i++)
                    {
                        Excel.Worksheet wkSheet = (Excel.Worksheet)myWorkbookdest.Worksheets[i];
                        if (wkSheet.Name == "Sheet1")
                        {
                            wkSheet.Delete();
                        }
                    }
                }
                myWorksheetdest = (Excel.Worksheet)myWorkbookdest.Worksheets[1];
                myWorksheetdest.Activate();

                myWorkbookdest.Save();
                //myWorkbook.Save();
                myWorkbookdest.Close(true, Type.Missing, Type.Missing);
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(Convert.ToString(savefilename));
                if (ddlProspect_Client.SelectedValue == "Client")
                {
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    List<Contact> ContactList = new List<Contact>();

                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }

                    string AdditionalCrtieriaOption_1 = txtsearch.Text;
                    string AdditionalCrtieriaOption_2 = rdlClient.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlClient.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                else if (ddlProspect_Client.SelectedValue == "Prospect") 
                {
                    string AdditionalCrtieriaOption_1 = txtsearch.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    ////DicActivityLog.Clear();
                    ////DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(txtProspectName.Text), Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                    ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(txtProspectName.Text), Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office);
                }

                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;

                Marshal.FinalReleaseComObject(myWorksheetdest);
                myWorksheetdest = null;
                Marshal.FinalReleaseComObject(myWorkbookdest);
                myWorkbookdest = null;

                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myWorksheetdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheetdest);
                    myWorksheetdest = null;
                }
                if (myWorkbookdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }
                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheetdest != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheetdest);
                    myWorksheetdest = null;
                }
                if (myWorkbookdest != null)
                {
                    myWorkbookdest.Close();
                    Marshal.FinalReleaseComObject(myWorkbookdest);
                    myWorkbookdest = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }

        //protected void btnViewPlans_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        bool flag = true;

        //        // Hash tabe for list of plans to show in the grid view
        //        Hashtable htSortedPlanList = new Hashtable();
        //        if (Convert.ToString(Session["Summary"]) == "PatraTransmittal")
        //        {
        //            htSortedPlanList = PatraTransmittal_planList();
        //        }
        //        if (Convert.ToString(Session["Summary"]) == "PatraTransmittal")
        //        {
        //            if (ddlClient.SelectedIndex == -1)
        //            {
        //                flag = false;
        //            }
        //        }

        //        if (flag == true)
        //        {
        //            grdPlans.DataSource = null;
        //            grdPlans.DataBind();

        //            List<Plan> PlanList = new List<Plan>();
        //            List<Plan> commonPlanList = new List<Plan>();
        //            Session["PlanList"] = null;
        //            SessionId = Session["SessionId"].ToString();
        //            if (ddlClient.SelectedIndex > 0)
        //            {
        //                PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
        //            }
        //            Session["PlanList"] = PlanList;

        //            if (PlanList != null)
        //            {
        //                if (PlanList.Count > 0)
        //                {
        //                    if (rdlPlan.SelectedIndex == 0)
        //                    {
        //                        // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
        //                        if (Convert.ToString(Session["Summary"]) == "PatraTransmittal")
        //                        {
        //                            foreach (Plan item in PlanList)
        //                            {
        //                                if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
        //                                {
        //                                    if (htSortedPlanList.ContainsValue(item.ProductTypeId))
        //                                    {
        //                                        commonPlanList.Add(item);
        //                                    }
        //                                }
        //                            }
        //                        }
        //                        // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
        //                    }
        //                    if (rdlPlan.SelectedIndex == 1)
        //                    {
        //                        foreach (Plan item in PlanList)
        //                        {
        //                            if (htSortedPlanList.ContainsValue(item.ProductTypeId))
        //                            {
        //                                commonPlanList.Add(item);
        //                            }
        //                        }
        //                    }

        //                    //  commonPlanList.OrderBy(a => a.ProductTypeId);
        //                    List<Plan> lstPlanList = new List<Plan>();

        //                    lstPlanList = (from l in commonPlanList
        //                                   orderby l.ProductTypeId, l.SummaryName, l.CarrierName ascending
        //                                   select l).ToList();

        //                    grdPlans.DataSource = lstPlanList;
        //                    grdPlans.DataBind();

        //                    if (commonPlanList.Count > 0)
        //                    {
        //                        pnlPlans.Visible = true;
        //                        CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
        //                        ChkBoxHeader.Checked = true;
        //                        foreach (GridViewRow row in grdPlans.Rows)
        //                        {
        //                            CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
        //                            ChkBoxRows.Checked = true;
        //                        }

        //                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        //                    }
        //                    else
        //                    {
        //                        //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('No active plans.')</script>");
        //                        string script = "alert(\"No active plans.\");";
        //                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
        //                    }
        //                }
        //                else
        //                {
        //                    string script = "alert(\"No plans for selected client.\");";
        //                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
        //                }
        //            }
        //            else
        //            {
        //                string script = "alert(\"No plans for selected client.\");";
        //                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }

        //}

        private Hashtable PatraTransmittal_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            htSortedPlanList.Add(15, 260);   // Voluntary Life
            htSortedPlanList.Add(16, 270);   // AD&D
            htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125


            htSortedPlanList.Add(21, 130);   // Medical
            htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            htSortedPlanList.Add(25, 235);   //Stop Loss
            htSortedPlanList.Add(26, 1108);   //Fees for Service
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        //protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    grdPlans.DataSource = null;
        //    grdPlans.DataBind();
        //}

        //private DataTable GetPlanInfoTable()
        //{
        //    DataTable PlanInfoTable = new DataTable();
        //    PlanInfoTable = CreatePlanInfoTable();


        //    DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

        //    objCommFun.LoadPlanTypeIds_Pilot();
        //    //List<int> MedicalPlanTypeList = new List<int>();

        //    ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
        //    //MedicalPlanTypeList.Add(100);
        //    //MedicalPlanTypeList.Add(110);
        //    //MedicalPlanTypeList.Add(120);
        //    //MedicalPlanTypeList.Add(130);
        //    //MedicalPlanTypeList.Add(140);
        //    //MedicalPlanTypeList.Add(150);
        //    //MedicalPlanTypeList.Add(160);
        //    //MedicalPlanTypeList.Add(170);
        //    //MedicalPlanTypeList.Add(1116);

        //    //List<int> DentalPlanTypeList = new List<int>();
        //    //DentalPlanTypeList.Add(180);
        //    //DentalPlanTypeList.Add(190);
        //    //DentalPlanTypeList.Add(200);
        //    //DentalPlanTypeList.Add(210);

        //    //List<int> VisionPlanTypeList = new List<int>();
        //    //VisionPlanTypeList.Add(230);

        //    //List<int> LifeADDPlanTypeList = new List<int>();
        //    //LifeADDPlanTypeList.Add(240);
        //    ////  LifeADDPlanTypeList.Add(250);

        //    //List<int> GroupTermLifePlanTypeList = new List<int>();
        //    //GroupTermLifePlanTypeList.Add(250);

        //    //List<int> VoluntaryLifeList = new List<int>();
        //    //VoluntaryLifeList.Add(260);

        //    //List<int> ADD = new List<int>();
        //    //ADD.Add(270);

        //    //List<int> VoluntaryLife_ADDList = new List<int>();
        //    //VoluntaryLife_ADDList.Add(280);

        //    //List<int> STDPlanTypeList = new List<int>();
        //    //STDPlanTypeList.Add(290);

        //    //List<int> LTDPlanTypeList = new List<int>();
        //    //LTDPlanTypeList.Add(300);

        //    //List<int> FSAPlanTypeList = new List<int>();
        //    //FSAPlanTypeList.Add(330);

        //    ////List<int> EAPPlanTypeList = new List<int>();
        //    ////EAPPlanTypeList.Add(310);

        //    ////List<int> HSAPlanTypeList = new List<int>();
        //    ////HSAPlanTypeList.Add(179);

        //    ////List<int> HRAPlanTypeList = new List<int>();
        //    ////HRAPlanTypeList.Add(178);

        //    try
        //    {
        //        int rowCount = 0;
        //        CheckBox chkItemSelect = new CheckBox();

        //        if (grdPlans != null)
        //        {
        //            foreach (GridViewRow grRow in grdPlans.Rows)
        //            {
        //                chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
        //                // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

        //                if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 5))
        //                {
        //                    //foreach (var data in BenefitSummaryList)
        //                    //{

        //                    PlanInfoTable.Rows.Add();
        //                    // For Name
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Name"] = " ";
        //                    }
        //                    // For SummaryName
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
        //                    }
        //                    // For Carrier Name
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
        //                    }

        //                    // For Effective date
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[3].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Effective"] = " ";
        //                    }

        //                    // For Renewal Date
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[4].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
        //                    }

        //                    // For Policy number
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
        //                    }

        //                    // For ProductID
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[6].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
        //                    }

        //                    // For ProductName
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[7].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
        //                    }

        //                    // For ProductTypeId
        //                    // If ProductTypeId is > 3 then it gives an error 'You are not authorized to access the requested information.'
        //                    // So we are taking ProductTypeId < 4
        //                    if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
        //                    {
        //                        if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
        //                        {
        //                            PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
        //                        }
        //                        else
        //                        {
        //                            PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
        //                        }
        //                    }

        //                    // For SummaryID
        //                    if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["SummaryID"] = Convert.ToString(grRow.Cells[9].Text);
        //                    }
        //                    else
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["SummaryID"] = " ";
        //                    }

        //                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
        //                    }
        //                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
        //                    }
        //                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
        //                    }
        //                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
        //                    }
        //                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
        //                    }

        //                    if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
        //                    }

        //                    if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
        //                    }

        //                    if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
        //                    }

        //                    if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
        //                    }
        //                    if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
        //                    }

        //                    if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
        //                    }

        //                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
        //                    }

        //                    if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
        //                    }

        //                    if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
        //                    }

        //                    if (CommonFunctionsBS.StopLossPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.StopLoss;
        //                    }
        //                    if (CommonFunctionsBS.FeesForServicePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
        //                    {
        //                        PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FeesForService;
        //                    }

        //                    rowCount++;
        //                }
        //                else
        //                {

        //                }

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //    return PlanInfoTable;
        //}

        //protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        if (e.Row.RowIndex == 0)
        //            e.Row.Style.Add("width", "8px");
        //    }
        //}

        //protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        //{
        //    CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

        //    foreach (GridViewRow row in grdPlans.Rows)
        //    {
        //        CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
        //        if (ChkBoxHeader.Checked == true)
        //        {
        //            ChkBoxRows.Checked = true;
        //        }
        //        else
        //        {
        //            ChkBoxRows.Checked = false;
        //        }
        //    }
        //    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        //}

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");


                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");


                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // AD&D
                ADDBenefitColumnIdList.Add("129");

                //Stop Loss
                //StopLossBenefitColumnIdList.Add("235");
                StopLossBenefitColumnIdList.Add("141");

                //Fees for Service
                FeesForServiceBenefitColumnIdList.Add("1108");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}