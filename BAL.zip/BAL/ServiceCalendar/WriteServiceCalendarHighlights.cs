﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.ServiceCalendar;

namespace BenefitPointSummaryPortal.BAL.ServiceCalendar
{
    public class WriteServiceCalendarHighlights : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        string census_Request = "Census Request";
        string preRenewal_Meeting = "Pre-Renewal Meeting";
        string renewal_Meeting = "Renewal Meeting";
        CommonFunctions objCommFun = new CommonFunctions();

        /// <summary>
        /// WriteFieldToSC_Highlights_Landscape
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="SelectedMonthNo">Int16 SelectedMonthNo for to check which month is selected</param>
        /// <param name="Report_5500">int Report_5500 is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="USI_Holidays">int USI_Holidays is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Experience">int Experience is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Wellness">int Wellness is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Cust_Field_1">int Cust_Field_1 for to check which month is selected</param>
        /// <param name="Cust_Field_2">int Cust_Field_2 for to check which month is selected</param>
        /// <param name="Cust_Field_3">int Cust_Field_3 for to check which month is selected</param>
        /// <param name="strCustField1">string strCustField1 is used to write the text provided in the text box in the selected month for Cust_Field_1</param>
        /// <param name="strCustField2">string strCustField2 is used to write the text provided in the text box in the selected month for Cust_Field_2</param>
        /// <param name="strCustField3">string strCustField3 is used to write the text provided in the text box in the selected month for Cust_Field_3</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="ddlServiceCalYear">DropDownList ddlServiceCalYear is used to check which year to show on the report (Current Year / Next Year)</param>
        /// <param name="Renewal_Cycle">int Renewal_Cycle is used to check which Renewal Cycle is chosen (45 Day / 60 Day / 90 Day / 120 Day)</param>
        public void WriteFieldToSC_Highlights_Landscape(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, Int16 SelectedMonthNo,
           int Report_5500, int USI_Holidays, int Experience, int Wellness, int Cust_Field_1, int Cust_Field_2, int Cust_Field_3, string strCustField1, string strCustField2, string strCustField3, GridView grdAccountTeam, DropDownList ddlServiceCalYear, int Renewal_Cycle, DropDownList ddlReportStyle)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;
                string value = string.Empty;
                int cnt = 0;
                int cnt1 = 0;
                int cntDiff = 0;

                string strUSI_Holidays = string.Empty;

                #region For writing table values

                // For showing static text in 4th row and 4th and 6th column -- Renewal_Cycle = 45
                if (Renewal_Cycle == 45)
                {
                    oWordDoc.Tables[2].Cell(4, 4).Select();
                    oWordDoc.Tables[2].Cell(4, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 4).Range.Text = census_Request;
                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(4, 4).Range.Text = oWordDoc.Tables[2].Cell(4, 4).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = renewal_Meeting;
                }
                // For showing static text in 4th row and 3rd and 5th column -- Renewal_Cycle = 60
                else if (Renewal_Cycle == 60)
                {
                    oWordDoc.Tables[2].Cell(4, 3).Select();
                    oWordDoc.Tables[2].Cell(4, 3).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 3).Range.Text = census_Request;
                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(4, 3).Range.Text = oWordDoc.Tables[2].Cell(4, 3).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 5).Select();
                    oWordDoc.Tables[2].Cell(4, 5).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 5).Range.Text = renewal_Meeting;
                }
                // For showing static text in 4th row and 2nd and 4th column -- Renewal_Cycle = 90
                else if (Renewal_Cycle == 90)
                {
                    oWordDoc.Tables[2].Cell(4, 2).Select();
                    oWordDoc.Tables[2].Cell(4, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 2).Range.Text = census_Request;
                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(4, 2).Range.Text = oWordDoc.Tables[2].Cell(4, 2).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 4).Select();
                    oWordDoc.Tables[2].Cell(4, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 4).Range.Text = renewal_Meeting;
                }
                // For showing static text in4th row and 1st and 3rd column -- Renewal_Cycle = 120
                else if (Renewal_Cycle == 120)
                {
                    oWordDoc.Tables[2].Cell(4, 1).Select();
                    oWordDoc.Tables[2].Cell(4, 1).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 1).Range.Text = census_Request;
                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(4, 1).Range.Text = oWordDoc.Tables[2].Cell(4, 1).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 3).Select();
                    oWordDoc.Tables[2].Cell(4, 3).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 3).Range.Text = renewal_Meeting;
                }

                // Condition for Experience -- for first 6 months
                if (Experience == 1) // Experience Included
                {
                    oWordDoc.Tables[2].Cell(2, 2).Select();
                    oWordDoc.Tables[2].Cell(2, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(2, 2).Range.Text = "Post Renewal Meeting / 4th Quarter Experience Report";

                    oWordDoc.Tables[2].Cell(2, 5).Select();
                    oWordDoc.Tables[2].Cell(2, 5).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(2, 5).Range.Text = "1st Quarter Experience Report";
                }
                //else if (Experience == 2) // Experience Excluded
                //{
                //    oWordDoc.Tables[2].Cell(2, 2).Select();
                //    oWordDoc.Tables[2].Cell(2, 2).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(2, 2).Range.Text = "Post Renewal Meeting";
                //}

                // Condition for Experience -- for next 6 months
                if (Experience == 1) // Experience Included
                {
                    oWordDoc.Tables[2].Cell(4, 3).Select();
                    if (oWordDoc.Tables[2].Cell(4, 3).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(4, 3).Range.Text = oWordDoc.Tables[2].Cell(4, 3).Range.Text + "Pre Renewal Meeting / Experience Report";
                    }
                    else
                    {
                        oWordDoc.Tables[2].Cell(4, 3).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(4, 3).Range.Text = "Pre Renewal Meeting / Experience Report";
                    }
                }
                /*****************************AS PER NICOLE WE DISPLAY THIS TEXT ONLY IN ONCE******/
                ////else if (Experience == 2) // Experience Excluded
                ////{
                ////    oWordDoc.Tables[2].Cell(4, 3).Select();
                ////    if (oWordDoc.Tables[2].Cell(4, 3).Range.Text.Length > 2)
                ////    {
                ////        if (Renewal_Cycle != 60)
                ////        {
                ////            oWordDoc.Tables[2].Cell(4, 3).Range.Text = oWordDoc.Tables[2].Cell(4, 3).Range.Text + "Pre Renewal Meeting";
                ////        }
                ////    }
                ////    else
                ////    {
                ////        oWordDoc.Tables[2].Cell(4, 3).Range.ListFormat.ApplyBulletDefault();
                ////        oWordDoc.Tables[2].Cell(4, 3).Range.Text = "Pre Renewal Meeting";
                ////    }
                ////}

                // CODE COMMENTED BY AMOGH AS PER NICOLE REQUIREMENT 
                ////// Condition for 5500 Report -- for next 6 months
                ////if (Report_5500 == 1) // 5500 Report Included
                ////{
                ////    oWordDoc.Tables[2].Cell(4, 2).Select();
                ////    if (oWordDoc.Tables[2].Cell(4, 2).Range.Text.Length > 2)
                ////    {
                ////        oWordDoc.Tables[2].Cell(4, 2).Range.Text = oWordDoc.Tables[2].Cell(4, 2).Range.Text + "File Annual IRS Forms (5500, Schedule A, etc.)";
                ////        oWordDoc.Tables[2].Cell(4, 1).Range.Text = oWordDoc.Tables[2].Cell(4, 1).Range.Text + "File Form 5500+Amogh";
                ////    }
                ////    else
                ////    {
                ////        oWordDoc.Tables[2].Cell(4, 2).Range.ListFormat.ApplyBulletDefault();
                ////        oWordDoc.Tables[2].Cell(4, 2).Range.Text = "File Annual IRS Forms (5500, Schedule A, etc.)";
                ////        oWordDoc.Tables[2].Cell(4, 1).Range.Text = oWordDoc.Tables[2].Cell(4, 1).Range.Text + "File Form 5500+Amogh";
                ////    }
                ////}

                /*******************************CODE UPDATED BY AMOGH - AS PER NICOLE Service Calendar - Highlights - Criteria Page and Template Updates
                 * 5.	Change 5500 bullet text, currently under Renewal Month +7 
                 * a.	Move to Renewal Month +6
                   b.	Change text
                 ********/

                // Condition for 5500 Report -- for next 6 months
                if (Report_5500 == 1) // 5500 Report Included
                {
                    oWordDoc.Tables[2].Cell(4, 1).Select();
                    if (oWordDoc.Tables[2].Cell(4, 1).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(4, 1).Range.Text = oWordDoc.Tables[2].Cell(4, 1).Range.Text + "File Form 5500";
                    }
                    else
                    {
                        oWordDoc.Tables[2].Cell(4, 1).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(4, 1).Range.Text = "File Form 5500";
                    }
                }

                // For static text to be shown in 2nd row and 2nd column code updated by amogh

                if (oWordDoc.Tables[2].Cell(2, 2).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(2, 2).Select();

                    /*******************************************AS PER NICOLE - Service Calendar - Highlights - Criteria Page and Template Updates 
                     * a.	Move bullet above “Population Health”
                       b.	Only include if Experience = Exclude
                    *******/
                    if (Experience == 2) // Experience Excluded
                    {
                        oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Post Renewal Meeting";
                    }
                    /* As per requirement here we add the "Population Health Management Strategy" */
                    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Population Health Management Strategy";
                    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Contract & Booklet Review";

                }
                else
                {
                    oWordDoc.Tables[2].Cell(2, 2).Select();
                    oWordDoc.Tables[2].Cell(2, 2).Range.ListFormat.ApplyBulletDefault();

                    /*******************************************AS PER NICOLE - Service Calendar - Highlights - Criteria Page and Template Updates 
                     * a.	Move bullet above “Population Health”
                       b.	Only include if Experience = Exclude
                    *******/
                    if (Experience == 2)  // Experience Excluded
                    {
                        oWordDoc.Tables[2].Cell(2, 2).Range.Text = "Post Renewal Meeting";
                    }
                    /* As per requirement here we add the "Population Health Management Strategy" */
                    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Population Health Management Strategy";
                    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Contract & Booklet Review";

                }
                // For static text to be shown in 2nd row and 2nd column
                //if (oWordDoc.Tables[2].Cell(2, 2).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(2, 2).Select();
                //    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Contract & Booklet Review";
                //    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Post Renewal Meeting";
                //}
                //else
                //{
                //    oWordDoc.Tables[2].Cell(2, 2).Select();
                //    oWordDoc.Tables[2].Cell(2, 2).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(2, 2).Range.Text = "Contract & Booklet Review";
                //    oWordDoc.Tables[2].Cell(2, 2).Range.Text = oWordDoc.Tables[2].Cell(2, 2).Range.Text + "Post Renewal Meeting";
                //}

                // For showing static text in 4th row and 6th column
                if (oWordDoc.Tables[2].Cell(4, 6).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = oWordDoc.Tables[2].Cell(4, 6).Range.Text + "Open Enrollment Communications";
                }
                else
                {
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = "Open Enrollment Communications";
                }

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    #region Code for first 6 months
                    if (cnt < 6)
                    {
                        cnt++;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cnt, 2, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cnt, 2, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // Code for next 6 columns (Months)
                    #region Code for next 6 months
                    else if (cnt >= 6)
                    {
                        cnt1++;
                        oWordDoc.Tables[2].Cell(3, cnt1).Select();
                        oWordDoc.Tables[2].Cell(3, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cnt1, 4, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cnt1, 4, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    cntDiff++;
                }

                // Take a difference from above loop so that to iterate another loop for the 12 - cntDiff 
                // (i.e. Total 12 months minus the total months for which the loop is already executed
                if (cntDiff < 12)
                {
                    for (int j = 1; j <= 12 - cntDiff; j++)
                    {
                        #region Code for first 6 months
                        if (cnt < 6)
                        {
                            cnt++;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(j, cnt, 2, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(j, cnt, 2, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        #region Code for next 6 months
                        else if (cnt >= 6)
                        {
                            cnt1++;
                            oWordDoc.Tables[2].Cell(3, cnt1).Select();
                            oWordDoc.Tables[2].Cell(3, cnt1).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(j, cnt1, 4, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(j, cnt1, 4, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion
                    }
                }
                #endregion

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Short Office Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        // To show current or next year on the CalYear merge field
                        if (fieldName.Contains("CalYear"))
                        {
                            myMergeField.Select();
                            if (ddlServiceCalYear.SelectedItem.Value == "1") // Current Year
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(DateTime.Now.Year));
                            }
                            else if (ddlServiceCalYear.SelectedItem.Value == "2") // Next Year
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(DateTime.Now.Year + 1));
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }

                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Renewal Month"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dictionaryMonth[SelectedMonthNo].ToString());
                            continue;
                        }

                        // To include the graphics image in the report
                        // if value = 0 ('Graphics') is selected then graphics image will be displayed
                        // if value = 1 ('No Graphics') is selected then graphics image will not be displayed
                        if (fieldName.Contains("Graphics_Image"))
                        {
                            myMergeField.Select();
                            if (ddlReportStyle.SelectedItem.Value == "1")
                            {
                                oWordApp.Selection.TypeText(" ");
                                object missing = System.Type.Missing;
                                Word.Range rng = rngFieldCode;
                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/Service_Calendar_Graphics.jpg"));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (ddlOffice.SelectedIndex > -1)
                        {
                            DataRow[] FoundRow = null;
                            FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                            if (FoundRow.Count() > 0)
                            {
                                if (fieldName.Contains("Office Full Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeName"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeName"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Address"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeAddress"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Phone Number"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["PhoneNumber"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["PhoneNumber"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("OFFICE LOGO"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                    object missing = System.Type.Missing;
                                    Word.Range rng = rngFieldCode;
                                    rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                    string imageName = FoundRow[0]["OfficeLogo"].ToString().Replace("jpg", "png");
                                    rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/CompanyLogo/" + imageName));
                                }
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 6;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    CheckBox chkItemSelect = new CheckBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (cntAT <= 9)
                        {
                            if (chkItemSelect.Checked == true)
                            {
                                name = "";
                                role = "";
                                workPhone = "";
                                email = "";

                                name = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "") + " " + Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "");
                                role = Convert.ToString(grRow.Cells[1].Text).Replace("&nbsp;", "");
                                workPhone = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                                email = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");

                                cntAT++;
                                oWordDoc.Tables[2].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[2].Cell(cntAT, 1).Range.Text = name + ", " + role + ": " + workPhone + " / " + email;

                                if (cntAT == 9)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// WriteFieldToSC_Highlights_Portrait
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="SelectedMonthNo">Int16 SelectedMonthNo for to check which month is selected</param>
        /// <param name="Report_5500">int Report_5500 is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="USI_Holidays">int USI_Holidays is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Experience">int Experience is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Wellness">int Wellness is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Cust_Field_1">int Cust_Field_1 for to check which month is selected</param>
        /// <param name="Cust_Field_2">int Cust_Field_2 for to check which month is selected</param>
        /// <param name="Cust_Field_3">int Cust_Field_3 for to check which month is selected</param>
        /// <param name="strCustField1">string strCustField1 is used to write the text provided in the text box in the selected month for Cust_Field_1</param>
        /// <param name="strCustField2">string strCustField2 is used to write the text provided in the text box in the selected month for Cust_Field_2</param>
        /// <param name="strCustField3">string strCustField3 is used to write the text provided in the text box in the selected month for Cust_Field_3</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="ddlServiceCalYear">DropDownList ddlServiceCalYear is used to check which year to show on the report (Current Year / Next Year)</param>
        /// <param name="Renewal_Cycle">int Renewal_Cycle is used to check which Renewal Cycle is chosen (45 Day / 60 Day / 90 Day / 120 Day)</param>
        public void WriteFieldToSC_Highlights_Portrait(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, Int16 SelectedMonthNo,
           int Report_5500, int USI_Holidays, int Experience, int Wellness, int Cust_Field_1, int Cust_Field_2, int Cust_Field_3, string strCustField1, string strCustField2, string strCustField3, GridView grdAccountTeam, DropDownList ddlServiceCalYear, int Renewal_Cycle, DropDownList ddlReportStyle)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;
                string value = string.Empty;
                int cnt = -1;
                int cnt1 = -1;
                int cnt2 = -1;
                int cnt3 = -1;
                int cntDiff = 0;

                #region For writing table values

                // For showing static text in 2nd and 6th column -- Renewal_Cycle = 45
                if (Renewal_Cycle == 45)
                {
                    oWordDoc.Tables[2].Cell(4, 2).Select();
                    oWordDoc.Tables[2].Cell(4, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 2).Range.Text = census_Request;

                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(4, 2).Range.Text = oWordDoc.Tables[2].Cell(4, 2).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = renewal_Meeting;
                }
                // For showing static text in 6th and 4th column -- Renewal_Cycle = 60
                else if (Renewal_Cycle == 60)
                {
                    oWordDoc.Tables[2].Cell(3, 6).Select();
                    oWordDoc.Tables[2].Cell(3, 6).Range.ListFormat.ApplyBulletDefault();

                    oWordDoc.Tables[2].Cell(3, 6).Range.Text = census_Request;

                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(3, 6).Range.Text = oWordDoc.Tables[2].Cell(3, 6).Range.Text + preRenewal_Meeting;
                    }

                    oWordDoc.Tables[2].Cell(4, 4).Select();
                    oWordDoc.Tables[2].Cell(4, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 4).Range.Text = renewal_Meeting;
                }
                // For showing static text in 4th and 2nd column -- Renewal_Cycle = 90
                else if (Renewal_Cycle == 90)
                {
                    oWordDoc.Tables[2].Cell(3, 4).Select();
                    oWordDoc.Tables[2].Cell(3, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(3, 4).Range.Text = census_Request;

                    if (Experience == 2) // Experience Excluded check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(3, 4).Range.Text = oWordDoc.Tables[2].Cell(3, 4).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(4, 2).Select();
                    oWordDoc.Tables[2].Cell(4, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 2).Range.Text = renewal_Meeting;
                }
                // For showing static text in 2nd and 6th column -- Renewal_Cycle = 120
                else if (Renewal_Cycle == 120)
                {
                    oWordDoc.Tables[2].Cell(3, 2).Select();
                    oWordDoc.Tables[2].Cell(3, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(3, 2).Range.Text = census_Request;

                    if (Experience == 2) // Experience Excluded  - check as per Nicole - Only include bullet if Experience = Exclude
                    {
                        oWordDoc.Tables[2].Cell(3, 2).Range.Text = oWordDoc.Tables[2].Cell(3, 2).Range.Text + preRenewal_Meeting;
                    }
                    oWordDoc.Tables[2].Cell(3, 6).Select();
                    oWordDoc.Tables[2].Cell(3, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(3, 6).Range.Text = renewal_Meeting;
                }

                // Condition for Experience -- for first 6 months
                if (Experience == 1) // Experience Included
                {
                    oWordDoc.Tables[2].Cell(1, 4).Select();
                    oWordDoc.Tables[2].Cell(1, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(1, 4).Range.Text = "Post Renewal Meeting / 4th Quarter Experience Report";

                    oWordDoc.Tables[2].Cell(2, 4).Select();
                    oWordDoc.Tables[2].Cell(2, 4).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(2, 4).Range.Text = "1st Quarter Experience Report";
                }
                //else if (Experience == 2) // Experience Excluded
                //{
                //oWordDoc.Tables[2].Cell(1, 4).Select();
                //oWordDoc.Tables[2].Cell(1, 4).Range.ListFormat.ApplyBulletDefault();
                //oWordDoc.Tables[2].Cell(1, 4).Range.Text = "Post Renewal Meeting";
                //}

                // Condition for Experience -- for next 6 months
                if (Experience == 1) // Experience Included
                {
                    oWordDoc.Tables[2].Cell(3, 6).Select();
                    if (oWordDoc.Tables[2].Cell(3, 6).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(3, 6).Range.Text = oWordDoc.Tables[2].Cell(3, 6).Range.Text + "Pre Renewal Meeting / Experience Report";
                    }
                    else
                    {
                        oWordDoc.Tables[2].Cell(3, 6).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(3, 6).Range.Text = "Pre Renewal Meeting / Experience Report";
                    }
                }
                /*******************AS PER NICOLE THIS TEXT DISPLAY ONLY ONCE **************************************/
                ////else if (Experience == 2) // Experience Excluded
                ////{
                ////    oWordDoc.Tables[2].Cell(3, 6).Select();
                ////    if (oWordDoc.Tables[2].Cell(3, 6).Range.Text.Length > 2)
                ////    {
                ////        if (Renewal_Cycle != 60)
                ////        {
                ////            oWordDoc.Tables[2].Cell(3, 6).Range.Text = oWordDoc.Tables[2].Cell(3, 6).Range.Text + "Pre Renewal Meeting";
                ////        }
                ////    }
                ////    else
                ////    {
                ////        oWordDoc.Tables[2].Cell(3, 6).Range.ListFormat.ApplyBulletDefault();
                ////        oWordDoc.Tables[2].Cell(3, 6).Range.Text = "Pre Renewal Meeting";
                ////    }
                ////}

                // Commented as per nicole requirement by Amogh Vilayatkar
                ////// Condition for 5500 Report -- for next 6 months
                ////if (Report_5500 == 1) // 5500 Report Included
                ////{
                ////    oWordDoc.Tables[2].Cell(3, 4).Select();
                ////    if (oWordDoc.Tables[2].Cell(3, 4).Range.Text.Length > 2)
                ////    {
                ////        oWordDoc.Tables[2].Cell(3, 4).Range.Text = oWordDoc.Tables[2].Cell(3, 4).Range.Text + "File Annual IRS Forms (5500, Schedule A, etc.)";
                ////    }
                ////    else
                ////    {
                ////        oWordDoc.Tables[2].Cell(3, 4).Range.ListFormat.ApplyBulletDefault();
                ////        oWordDoc.Tables[2].Cell(3, 4).Range.Text = "File Annual IRS Forms (5500, Schedule A, etc.)";
                ////    }
                ////}


                /*******************************CODE UPDATED BY AMOGH - AS PER NICOLE Service Calendar - Highlights - Criteria Page and Template Updates
                 * 5.	Change 5500 bullet text, currently under Renewal Month +7 
                 * a.	Move to Renewal Month +6
                   b.	Change text
                 ********/
                // Condition for 5500 Report -- for next 6 months
                if (Report_5500 == 1) // 5500 Report Included
                {
                    oWordDoc.Tables[2].Cell(3, 2).Select();
                    if (oWordDoc.Tables[2].Cell(3, 2).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(3, 2).Range.Text = oWordDoc.Tables[2].Cell(3, 2).Range.Text + "File Form 5500";
                    }
                    else
                    {
                        oWordDoc.Tables[2].Cell(3, 2).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(3, 2).Range.Text = "File Form 5500";
                    }
                }


                // For static text to be shown in 1st row and 4th column code updaetd by amogh
                if (oWordDoc.Tables[2].Cell(1, 4).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(1, 4).Select();
                    /*******************************************AS PER NICOLE - Service Calendar - Highlights - Criteria Page and Template Updates 
                    * a.	Move bullet above “Population Health”
                      b.	Only include if Experience = Exclude
                   *******/
                    if (Experience == 2) // Experience Excluded
                    {
                        oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Post Renewal Meeting";
                    }
                    /* As per requirement here we add the "Population Health Management Strategy" */
                    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Population Health Management Strategy";
                    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Contract & Booklet Review";

                }
                else
                {
                    oWordDoc.Tables[2].Cell(1, 4).Select();
                    oWordDoc.Tables[2].Cell(1, 4).Range.ListFormat.ApplyBulletDefault();

                    /*******************************************AS PER NICOLE - Service Calendar - Highlights - Criteria Page and Template Updates 
                    * a.	Move bullet above “Population Health”
                      b.	Only include if Experience = Exclude
                   *******/
                    if (Experience == 2) // Experience Excluded
                    {
                        oWordDoc.Tables[2].Cell(1, 4).Range.Text = "Post Renewal Meeting";
                    }
                    /* As per requirement here we add the "Population Health Management Strategy" */
                    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Population Health Management Strategy";
                    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Contract & Booklet Review";

                }


                // For static text to be shown in 1st row and 4th column
                ////if (oWordDoc.Tables[2].Cell(1, 4).Range.Text.Length > 2)
                ////{
                ////    oWordDoc.Tables[2].Cell(1, 4).Select();
                ////    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Contract & Booklet Review";
                ////    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Post Renewal Meeting";
                ////}
                ////else
                ////{
                ////    oWordDoc.Tables[2].Cell(1, 4).Select();
                ////    oWordDoc.Tables[2].Cell(1, 4).Range.ListFormat.ApplyBulletDefault();
                ////    oWordDoc.Tables[2].Cell(1, 4).Range.Text = "Contract & Booklet Review";
                ////    oWordDoc.Tables[2].Cell(1, 4).Range.Text = oWordDoc.Tables[2].Cell(1, 4).Range.Text + "Post Renewal Meeting";
                ////}

                //// For showing static text in 4th column
                //oWordDoc.Tables[2].Cell(4, 4).Select();
                //oWordDoc.Tables[2].Cell(4, 4).Range.ListFormat.ApplyBulletDefault();
                //oWordDoc.Tables[2].Cell(4, 4).Range.Text = "Renewal Meeting";

                //// For showing static text in 6th column
                //oWordDoc.Tables[2].Cell(4, 6).Select();
                //oWordDoc.Tables[2].Cell(4, 6).Range.ListFormat.ApplyBulletDefault();
                //oWordDoc.Tables[2].Cell(4, 6).Range.Text = "Open Enrollment Communications";



                // For showing static text in 6th column
                if (oWordDoc.Tables[2].Cell(4, 6).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = oWordDoc.Tables[2].Cell(4, 6).Range.Text + "Open Enrollment Communications";
                }
                else
                {
                    oWordDoc.Tables[2].Cell(4, 6).Select();
                    oWordDoc.Tables[2].Cell(4, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(4, 6).Range.Text = "Open Enrollment Communications";
                }

                int cntFirst3_Month = 0;
                int cntSecond3_Month = 0;
                int cntThird3_Month = 0;
                int cntFourth3_Month = 0;

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    // For first 3 months
                    #region For first 3 months
                    if (cnt < 5)
                    {
                        cnt = cnt + 2;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntFirst3_Month = cnt + 1;

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntFirst3_Month, 1, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntFirst3_Month, 1, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For second 3 months
                    #region For second 3 months
                    if (cntDiff >= 3 && cnt1 < 5)
                    {
                        cnt1 = cnt1 + 2;
                        oWordDoc.Tables[2].Cell(2, cnt1).Select();
                        oWordDoc.Tables[2].Cell(2, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntSecond3_Month = cnt1 + 1;

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntSecond3_Month, 2, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntSecond3_Month, 2, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For third 3 months
                    #region For third 3 months
                    if (cntDiff >= 6 && cnt2 < 5)
                    {
                        cnt2 = cnt2 + 2;
                        oWordDoc.Tables[2].Cell(3, cnt2).Select();
                        oWordDoc.Tables[2].Cell(3, cnt2).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntThird3_Month = cnt2 + 1;

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntThird3_Month, 3, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntThird3_Month, 3, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For fourth 3 months
                    #region For fourth 3 months
                    if (cntDiff >= 9 && cnt3 < 5)
                    {
                        cnt3 = cnt3 + 2;
                        oWordDoc.Tables[2].Cell(4, cnt3).Select();
                        oWordDoc.Tables[2].Cell(4, cnt3).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntFourth3_Month = cnt3 + 1;

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntFourth3_Month, 4, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntFourth3_Month, 4, oWordDoc, Wellness);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    cntDiff++;
                }

                // If the month difference is less than 12 then execute the below
                int cntDiff1 = cntDiff;
                if (cntDiff < 12)
                {
                    for (int i = 1; i <= 12 - cntDiff; i++)
                    {
                        // For first 3 months
                        #region For first 3 months
                        if (cnt < 5)
                        {
                            cnt = cnt + 2;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntFirst3_Month = cnt + 1;

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntFirst3_Month, 1, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntFirst3_Month, 1, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For second 3 months
                        #region For second 3 months
                        if (cntDiff1 >= 3 && cnt1 < 5)
                        {
                            cnt1 = cnt1 + 2;
                            oWordDoc.Tables[2].Cell(2, cnt1).Select();
                            oWordDoc.Tables[2].Cell(2, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntSecond3_Month = cnt1 + 1;

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntSecond3_Month, 2, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntSecond3_Month, 2, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For third 3 months
                        #region For third 3 months
                        if (cntDiff1 >= 6 && cnt2 < 5)
                        {
                            cnt2 = cnt2 + 2;
                            oWordDoc.Tables[2].Cell(3, cnt2).Select();
                            oWordDoc.Tables[2].Cell(3, cnt2).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntThird3_Month = cnt2 + 1;

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntThird3_Month, 3, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntThird3_Month, 3, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For fourth 3 months
                        #region For fourth 3 months
                        if (cntDiff1 >= 9 && cnt3 < 5)
                        {
                            cnt3 = cnt3 + 2;
                            oWordDoc.Tables[2].Cell(4, cnt3).Select();
                            oWordDoc.Tables[2].Cell(4, cnt3).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntFourth3_Month = cnt3 + 1;

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntFourth3_Month, 4, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntFourth3_Month, 4, oWordDoc, Wellness);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        cntDiff1++;
                    }
                }

                #endregion

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Short Office Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        // To show current or next year on the CalYear merge field
                        if (fieldName.Contains("CalYear"))
                        {
                            myMergeField.Select();
                            if (ddlServiceCalYear.SelectedItem.Value == "1") // Current Year
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(DateTime.Now.Year));
                            }
                            else if (ddlServiceCalYear.SelectedItem.Value == "2") // Next Year
                            {
                                oWordApp.Selection.TypeText(Convert.ToString(DateTime.Now.Year + 1));
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }

                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Renewal Month"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dictionaryMonth[SelectedMonthNo].ToString());
                            continue;
                        }

                        // To include the graphics image in the report
                        // if value = 0 ('Graphics') is selected then graphics image will be displayed
                        // if value = 1 ('No Graphics') is selected then graphics image will not be displayed
                        if (fieldName.Contains("Graphics_Image"))
                        {
                            myMergeField.Select();
                            if (ddlReportStyle.SelectedItem.Value == "1")
                            {
                                oWordApp.Selection.TypeText(" ");
                                object missing = System.Type.Missing;
                                Word.Range rng = rngFieldCode;
                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/Service_Calendar_Graphics.jpg"));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (ddlOffice.SelectedIndex > -1)
                        {
                            DataRow[] FoundRow = null;
                            FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                            if (FoundRow.Count() > 0)
                            {
                                if (fieldName.Contains("Office Full Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeName"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeName"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Address"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeAddress"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Phone Number"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["PhoneNumber"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["PhoneNumber"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("OFFICE LOGO"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                    object missing = System.Type.Missing;
                                    Word.Range rng = rngFieldCode;
                                    rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                    string imageName = FoundRow[0]["OfficeLogo"].ToString().Replace("jpg", "png");
                                    rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/CompanyLogo/" + imageName));
                                }
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 6;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    CheckBox chkItemSelect = new CheckBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (cntAT <= 9)
                        {
                            if (chkItemSelect.Checked == true)
                            {
                                name = "";
                                role = "";
                                workPhone = "";
                                email = "";

                                name = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "") + " " + Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "");
                                role = Convert.ToString(grRow.Cells[1].Text).Replace("&nbsp;", "");
                                workPhone = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                                email = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");

                                cntAT++;
                                oWordDoc.Tables[2].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[2].Cell(cntAT, 1).Range.Text = name + ", " + role + ": " + workPhone + " / " + email;

                                if (cntAT == 9)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


    }
}