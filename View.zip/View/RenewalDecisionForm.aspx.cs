﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.Runtime.InteropServices;
using BenefitPointSummaryPortal.BAL.RenewalDecisionForm;
namespace BenefitPointSummaryPortal.View
{
    public partial class RenewalDecisionForm : System.Web.UI.Page
    {
        #region Golbal Variables
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        public ConstantValue cv = new ConstantValue();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        enum AccessKeys { SessionID, DeliverableCategory, AvailablePlanList, AvailableProductList, SelectedSummaries, SelectedProducts, BenefitSummaryOptionDataSource };
        enum PlanStatus { Pending, Current, ArchivedPriorYear };
        public Dictionary<string, string> DictSelectedRates = new Dictionary<string, string>();
        DataSet AccountDS = new DataSet();
        DataSet AccountTeamMemberDS = new DataSet();
        List<Contact> ContactList = new List<Contact>();

        string SessionId
        {
            get
            {
                return Session[AccessKeys.SessionID.ToString()].ToString();
            }
            set
            {
                Session[AccessKeys.SessionID.ToString()] = value;
            }
        }
        public static Dictionary<string, List<int>> DictPlanType = new Dictionary<string, List<int>>();
        public List<int> MedicalPlanTypes = new List<int> { 100, 110, 120, 130, 140, 150, 160, 170, 233 };
        public List<int> DentalPlanTypes = new List<int> { 180, 190, 200, 210 };
        public List<int> VisionPlanTypes = new List<int> { 230 };

        #endregion

        #region UI Event Handler
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnSummary);
            if (!IsPostBack)
            {
                mvMainContainer.ActiveViewIndex = 0;
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                objCommFun.GetUserDetails();
                Activity_Group = "Tools";
                Activity = TitleSpan.InnerText;
                Session[AccessKeys.DeliverableCategory.ToString()] = "Client Management Tools";
                DictDepartment = sd.getDepartmentDetails();
                //  ddlcontents_SelectedIndexChanged(null, null);
                CriteriaPageIndexChanged();
                trPlanContainer.Visible = false;
                LoadDictplanTypes();

                btnNext.Visible = false;
                btnPrevious.Visible = false;
                btnSummary.Visible = false;
            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            int ActivePageIndex = mvMainContainer.ActiveViewIndex;
            switch (ActivePageIndex)
            {
                case 1:
                    mvMainContainer.ActiveViewIndex = 0;
                    break;
            }
            CriteriaPageIndexChanged();
            AddSelectedPlanRatesToSession();
        }
        protected void btnNext_Click(object sender, EventArgs e)
        {
            bool IsSuccess = false;


            AddSelctedPlanBenefitSummaryToSessions();
            List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary = (List<RenewalPlanSelectionViewModel>)Session["SelectedPlansList"];
            DictSelectedRates = (Dictionary<string, string>)Session["SelectedPlanRates"];

            if (ValidateCriteriaPage1() == false)
            {
                return;
            }

            if (SelectedPlansBenefitSummary == null || SelectedPlansBenefitSummary.Count == 0)
            {
                ShowAlertMessage("Please select at least one plan.");
                return;
            }

            int ActivePageIndex = mvMainContainer.ActiveViewIndex;
            if (ActivePageIndex == 0)
            {
                mvMainContainer.ActiveViewIndex = 1;
                AddSelctedPlanBenefitSummaryToSessions();
                BindEligibilities();
                gvPlanBernefitSummaryOptions.DataSource = SelectedPlansBenefitSummary;
                gvPlanBernefitSummaryOptions.DataBind();
                gvPlanBernefitSummaryOptions.Visible = true;
                IsSuccess = true;
            }

            if (IsSuccess)
                CriteriaPageIndexChanged();

        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            //if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
            //    ddlClient.Focus();
            //    return;
            //}
            bool isPlanStatusSelected = false;

            for (int i = 0; i <= 2; i++)
            {
                if (chkPlanStatus.Items[i].Selected == true)
                {
                    isPlanStatusSelected = true;
                }
            }

            if (ValidateCriteriaPage1())
            {
                if (isPlanStatusSelected == false)
                {
                    ShowAlertMessage("Please select plan status.");
                    chkPlanStatus.Focus();
                    return;
                }

                trPlanContainer.Visible = true;
                if (ddlContents.SelectedValue == "Summary")
                {
                    grdPlans.Columns[1].Visible = false;
                    btnNext.Visible = false;
                    btnSummary.Visible = true;
                }
                else
                {
                    grdPlans.Columns[1].Visible = true;
                    btnNext.Visible = true;
                    btnSummary.Visible = false;
                }
                LoadPlansAndProducts();
            }

        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ClearPlanGrid();
            ddlContents_SelectedIndexChanged(null, null);
            ddlAccountContact.Items.Clear();

            ddlContents.SelectedIndex = 0;
            ddlFormStyle.SelectedIndex = 0;
            // ddlOutputFormat.SelectedIndex = 0;

            //  tblPlanProductCriteria.Style.Add("display", "none");
            chkPlanStatus.SelectedValue = PlanStatus.Pending.ToString();
            // BenefitSummaryOptionDataSource = null;
            ddlAccountContact.Items.Clear();

            btnNext.Visible = false;
            btnPrevious.Visible = false;
            btnSummary.Visible = false;

            if (ddlClient.SelectedIndex > 0)
            {
                // tblPlanProductCriteria.Style.Add("display", "");
                BindAccountContact();
            }
        }
        protected void rdlPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
        }

        void chkPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void chkPlanHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }
        protected void ddlContents_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();

            if (ddlContents.SelectedValue == "Summary")
            {
                btnNext.Visible = false;
                btnSummary.Visible = true;
            }
            else if (ddlContents.SelectedValue == "Detailed")
            {
                btnNext.Visible = true;
                btnSummary.Visible = false;
            }
            else
            {
                btnNext.Visible = false;
                btnPrevious.Visible = false;
                btnSummary.Visible = false;
            }
        }
        protected void gvPlanBernefitSummaryOptions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // SummaryOptionItemViewModel objItemViewModel = e.Row.DataItem as SummaryOptionItemViewModel;
                RenewalPlanSelectionViewModel SelectedPlansBenefitSummaryItem = e.Row.DataItem as RenewalPlanSelectionViewModel;

                Label lblBenefitSummary = e.Row.FindControl("lblBenefitSummary") as Label;
                Label lblRates1 = e.Row.FindControl("lblRates1") as Label;
                HiddenField hdnHasRates = e.Row.FindControl("hdnHasRates") as HiddenField;

                lblBenefitSummary.Text = SelectedPlansBenefitSummaryItem.ProductTypeDescription + " | " + SelectedPlansBenefitSummaryItem.SummaryName + " | " + SelectedPlansBenefitSummaryItem.CarrierName + " | " + SelectedPlansBenefitSummaryItem.EffectiveDate;

                DropDownList ddlRates1 = e.Row.FindControl("ddlRates1") as DropDownList;
                List<Rate> RateList = new List<Rate>();

                RateList = bp.FindRates(SelectedPlansBenefitSummaryItem.ProductId, SessionId);
                if (RateList != null && RateList.Count != 0)
                {
                    ddlRates1.DataSource = RateList;
                    ddlRates1.DataBind();
                    ddlRates1.Visible = true;
                    ddlRates1.Items.Insert(0, new ListItem("Do Not Include", "Do Not Include"));
                    ddlRates1.SelectedIndex = 0;
                    hdnHasRates.Value = "Yes";
                }
                else
                {
                    lblRates1.Visible = true;
                    ddlRates1.Visible = false;
                    lblRates1.Text = "There are no rate schedules";
                    hdnHasRates.Value = "No";
                }

                if (DictSelectedRates != null)
                {
                    if (DictSelectedRates.ContainsKey(lblBenefitSummary.Text))
                    {
                        ddlRates1.SelectedValue = DictSelectedRates[lblBenefitSummary.Text];
                    }
                }

            }



        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {

                string filename = "";
                AddSelctedPlanBenefitSummaryToSessions();
                List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary = (List<RenewalPlanSelectionViewModel>)Session["SelectedPlansList"];  // Used for Summary type
                DataTable PlanTable = BuildPlanTable();    //USed for Detailed type

                #region Validation
                if (mvMainContainer.ActiveViewIndex == 0)
                {
                    if (ValidateCriteriaPage1() == false)
                    {
                        return;
                    }

                    if (SelectedPlansBenefitSummary.Count == 0 || SelectedPlansBenefitSummary == null)
                    {
                        ShowAlertMessage("Please select at least one plan.");
                        return;
                    }
                }
                else if (mvMainContainer.ActiveViewIndex == 1)
                {
                    PlanTable = getAllSelectedPlansWithRates();
                    if (PlanTable.Rows.Count == 0)
                    {
                        ShowAlertMessage("Please select atleast one rates.");
                        return;
                    }
                }

                #endregion

                #region fetch data
                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                #endregion

                //Add if-block's with methods to generate reports
                if (ddlFormStyle.SelectedValue == "Simple" && ddlContents.SelectedValue == "Summary")
                {
                    filename = CreateSimpleSummery(SelectedPlansBenefitSummary, AccountTeamMemberDS, AccountDS);
                }
                else
                {
                    return;  // Since at there is only simple - summery
                }

                //activity log

                DownloadFileNew(filename);

                InsertLog(ddlFormStyle.SelectedItem.Text, ddlContents.SelectedItem.Text);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        #endregion

        #region methods
        protected void LoadDictplanTypes()
        {
            List<int> MedicalPlanList = new List<int> { 100, 110, 120, 130, 140, 150, 160, 170, 233 };
            List<int> DentalPlanList = new List<int> { 180, 190, 200, 210 };
            List<int> VisionPlanList = new List<int> { 230 };
            List<int> StopLossPlanList = new List<int> { 235 };

            List<int> HSAPlanList = new List<int> { 179 };
            List<int> HRAPlanList = new List<int> { 178 };
            List<int> LifeADnDPlanList = new List<int> { 240 };
            List<int> GroupLifePlanList = new List<int> { 250 };

            List<int> VoluntaryLifePlanList = new List<int> { 260 };
            List<int> STDPlanList = new List<int> { 290 };
            List<int> LTDPlanList = new List<int> { 300 };

            List<int> EAPPlanList = new List<int> { 310 };
            List<int> FSAPlanList = new List<int> { 330 };
            List<int> WellnessPlanList = new List<int> { 317 };

            DictPlanType.Clear();
            DictPlanType.Add(cv.MedicalLOC, MedicalPlanList);
            DictPlanType.Add(cv.DentalLOC, DentalPlanList);
            DictPlanType.Add(cv.VisionLOC, VisionPlanList);
            DictPlanType.Add(cv.StopLoss, StopLossPlanList);
            DictPlanType.Add(cv.HRALOC, HRAPlanList);
            DictPlanType.Add(cv.HSALOC, HSAPlanList);
            DictPlanType.Add(cv.LifeADDLOC, LifeADnDPlanList);
            DictPlanType.Add(cv.GroupTermLifePlanType_CommonCriteria, GroupLifePlanList);
            DictPlanType.Add(cv.EAPLOC, EAPPlanList);
            DictPlanType.Add(cv.FSAPlanType, FSAPlanList);
            DictPlanType.Add(cv.Wellness, WellnessPlanList);
            DictPlanType.Add(cv.VoluntaryLife, VoluntaryLifePlanList);
            DictPlanType.Add(cv.STDLOC, STDPlanList);
            DictPlanType.Add(cv.LTDLOC, LTDPlanList);


        }
        protected void ResetForm()
        {
            ddlAccountContact.Items.Clear();
            ddlClient.Items.Clear();
            rdlClient.SelectedIndex = 0;
            txtsearch.Text = "";
            ddlContents.SelectedIndex = 0;
            ddlFormStyle.SelectedIndex = 0;
            //ddlOutputFormat.SelectedIndex = 0;
            btnNext.Visible = false;
            btnPrevious.Visible = false;
            btnSummary.Visible = false;

            chkPlanStatus.Items[0].Selected = true;
            chkPlanStatus.Items[1].Selected = false;
            chkPlanStatus.Items[2].Selected = false;
            trPlanContainer.Visible = false;
            ClearPlanGrid();

        }

        private void CriteriaPageIndexChanged()
        {
            int ActivePageIndex = mvMainContainer.ActiveViewIndex;
            pnlCriteriaInformation.Visible = false;
            pnlFormDescription.Visible = false;
            switch (ActivePageIndex)
            {
                case 0:
                    pnlFormDescription.Visible = true;
                    lblCriteriaPageIndex.Text = "1 of 2";
                    btnPrevious.Visible = false;
                    btnNext.Visible = true;
                    btnNext.Text = "Next";
                    btnSummary.Visible = false;
                    break;

                case 1:
                    pnlCriteriaInformation.Visible = true;
                    lblCriteriaPageIndex.Text = "2 of 2";
                    FillCriteriaInformation();
                    btnPrevious.Visible = true;
                    btnPrevious.Text = "Previous";
                    btnNext.Visible = false;
                    btnSummary.Visible = true;
                    break;
            }
        }
        private void FillCriteriaInformation()
        {
            lblSelectedClient.Text = ddlClient.SelectedItem.Text;
            //  lblSelectedContentOption.Text = ddlContents.SelectedItem.Text;
            lblSelectedStyle.Text = ddlFormStyle.SelectedItem.Text;

        }

        private void LoadPlansAndProducts()
        {

            List<Plan> PlanList = new List<Plan>();
            List<Plan> FilteredPlanList = new List<Plan>();
            PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            LoadPlans(PlanList);

        }
        private void LoadPlans(List<Plan> PlanList)
        {
            ClearPlanGrid();
            List<Plan> FilteredPlanList = new List<Plan>();
            List<Plan> FilteredSummeryPlanList = new List<Plan>();
            bool isAdded = false;

            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        isAdded = false;

                        if (chkPlanStatus.Items[0].Selected && isAdded == false)
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                foreach (string key in DictPlanType.Keys)
                                {
                                    if (DictPlanType[key].Contains(item.ProductTypeId))
                                    {
                                        FilteredPlanList.Add(item);
                                        isAdded = true;
                                        break;
                                    }
                                }
                                //if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                //{
                                //    FilteredPlanList.Add(item);
                                //}
                            }
                        }
                        if (chkPlanStatus.Items[1].Selected && isAdded == false)
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                foreach (string key in DictPlanType.Keys)
                                {
                                    if (DictPlanType[key].Contains(item.ProductTypeId))
                                    {
                                        FilteredPlanList.Add(item);
                                        isAdded = true;
                                        break;
                                    }
                                }
                                //if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                //{
                                //    FilteredPlanList.Add(item);
                                //}
                            }
                        }
                        if (chkPlanStatus.Items[2].Selected && isAdded == false)
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                foreach (string key in DictPlanType.Keys)
                                {
                                    if (DictPlanType[key].Contains(item.ProductTypeId))
                                    {
                                        FilteredPlanList.Add(item);
                                        isAdded = true;
                                        break;
                                    }
                                }
                                //if (ApplicablePlanTypes.Contains(item.ProductTypeId))
                                //{
                                //    FilteredPlanList.Add(item);
                                //}
                            }
                        }
                    }
                }
            }

            FilteredPlanList = (from l in FilteredPlanList
                                orderby l.ProductTypeId ascending
                                select l).ToList();


            #region filter plan for summery --

            Dictionary<string, string> DictUniquePlan = new Dictionary<string, string>();
            if (ddlContents.SelectedValue == "Summary")
            {
                foreach (Plan plan in FilteredPlanList)
                {
                    if (!DictUniquePlan.ContainsKey(plan.ProductTypeDescription + plan.CarrierName + plan.PolicyNumber + plan.RenewalDate))
                    {
                        DictUniquePlan.Add(plan.ProductTypeDescription + plan.CarrierName + plan.PolicyNumber + plan.RenewalDate, "");
                        FilteredSummeryPlanList.Add(plan);
                    }
                }
            }


            if (ddlContents.SelectedValue == "Detailed")
            {
                grdPlans.DataSource = FilteredPlanList;
            }
            else if (ddlContents.SelectedValue == "Summary")
            {
                grdPlans.DataSource = FilteredSummeryPlanList;
            }

            #endregion


            //grdPlans.DataSource = FilteredPlanList;
            grdPlans.DataBind();

            trPlanContainer.Style.Add("display", "");

            if (FilteredPlanList.Count > 0)
            {
                //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                grdPlans.Style.Add("display", "");
            }
            else
            {
                tblEmptyPlanTemplate.Style.Add("display", "");
            }

            //  AvailablePlans = FilteredPlanList;
        }

        private void ClearPlanGrid()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            trPlanContainer.Style.Add("display", "none");
            tblEmptyPlanTemplate.Style.Add("display", "none");
            grdPlans.Style.Add("display", "none");
            Session["SelectedPlanRates"] = null;
            if (ddlEligibilityRule.Items.Count > 0)
                ddlEligibilityRule.SelectedIndex = 0;
        }

        private void BindAccountContact()
        {
            List<Contact> ContactList = new List<Contact>();
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId, "Enrollment Summary");
            Session["Contact"] = ContactList;
            ddlAccountContact.DataSource = ContactList;
            ddlAccountContact.DataBind();
            ddlAccountContact.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlAccountContact.Items.Insert(1, new ListItem("None", "-1"));

        }
        private void BindEligibilities()
        {
            List<Eligibility> lstEligibilityNames = new List<Eligibility>();
            List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary = (List<RenewalPlanSelectionViewModel>)Session["SelectedPlansList"];
            string PreviousSlectedValue = string.Empty;
            try
            {
                PreviousSlectedValue = ddlEligibilityRule.SelectedValue;
            }
            catch (Exception ex)
            {

            }
            ddlEligibilityRule.Items.Clear();
            List<Eligibility> EligibilityList = new List<Eligibility>();
            foreach (RenewalPlanSelectionViewModel plan in SelectedPlansBenefitSummary)
            {
                if (MedicalPlanTypes.Contains(plan.ProductTypeId) || DentalPlanTypes.Contains(plan.ProductTypeId) || VisionPlanTypes.Contains(plan.ProductTypeId))
                {
                    EligibilityList = bp.FindEligibility(plan.ProductId, SessionId);

                    foreach (var item in EligibilityList)
                    {
                        Eligibility eligibilityItem = new Eligibility();
                        eligibilityItem.EligibilityId = item.EligibilityId;
                        eligibilityItem.EligibilityDescription = plan.ProductTypeDescription + " - " + Convert.ToString(plan.PolicyNumber) + " - " + item.EligibilityDescription;

                        if (!lstEligibilityNames.Equals(eligibilityItem.EligibilityDescription))
                        {
                            lstEligibilityNames.Add(eligibilityItem);
                        }
                    }
                }
            }
            ddlEligibilityRule.DataSource = lstEligibilityNames;
            ddlEligibilityRule.DataBind();
            ddlEligibilityRule.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlEligibilityRule.SelectedIndex = ddlEligibilityRule.Items.IndexOf(ddlEligibilityRule.Items.FindByValue(PreviousSlectedValue));
        }
        private void AddSelctedPlanBenefitSummaryToSessions()
        {
            ConstantValue cv = new ConstantValue();
            List<RenewalPlanSelectionViewModel> lstSelectedSummaries = new List<RenewalPlanSelectionViewModel>();
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true)
                        {
                            RenewalPlanSelectionViewModel BenefitSummaryItem = new RenewalPlanSelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                BenefitSummaryItem.SummaryName = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryName = string.Empty;
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 the 'You are not authorized to access the requesn it gives an errorted information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                                }
                                else
                                {
                                    BenefitSummaryItem.ProductTypeId = 0;
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                BenefitSummaryItem.SummaryId = int.Parse((grRow.Cells[9].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryId = 0;
                            }

                            LoadDictplanTypes();
                            foreach (string key in DictPlanType.Keys)
                            {
                                if (DictPlanType[key].Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                                {
                                    BenefitSummaryItem.LOC = key;
                                    break;
                                }
                            }

                            //if (MedicalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.MedicalLOC;
                            //}
                            //if (DentalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.DentalLOC;
                            //}
                            //if (VisionPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.VisionLOC;
                            //}
                            //if (LifeADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.LifeADDLOC;
                            //}
                            //if (GroupTermPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                            //}
                            ////if (ADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            ////{
                            ////    BenefitSummaryItem.LOC = cv.ADNDPlanType_CommonCriteria;  
                            ////}
                            //if (VoluntaryLifeADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.VoluntaryLife;
                            //}
                            ////if (VoluntaryADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            ////{
                            ////    BenefitSummaryItem.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                            ////}
                            //if (LTDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.LTDLOC;
                            //}

                            //if (STDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.STDLOC;
                            //}

                            //if (EAPPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.EAPLOC;
                            //}

                            //if (FSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.FSAPlanType;
                            //}
                            //if (HSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.HSALOC;
                            //}
                            //if (HRAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.HRALOC;
                            //}
                            //if (StopLossPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.StopLoss;
                            //}
                            //if (WellnessPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            //{
                            //    BenefitSummaryItem.LOC = cv.Wellness;
                            //}
                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }
                    }//Foreach Close
                    Session["SelectedPlansList"] = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected bool ValidateCriteriaPage1()
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ShowAlertMessage("Please select client name.");
                ddlClient.Focus();
                return false;
            }
            if (ddlAccountContact.SelectedIndex == 0)
            {
                ShowAlertMessage("Please select account contact.");
                ddlAccountContact.Focus();
                return false;
            }
            //if (ddlFormStyle.SelectedIndex == 0)
            //{
            //    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Form Style.')</script>");
            //    ddlFormStyle.Focus();
            //    return false;
            //}
            //if (ddlOutputFormat.SelectedIndex == 0)
            //{
            //    ShowAlertMessage("Please select Output Format.");
            //    ddlOutputFormat.Focus();
            //    return false;     
            //}
            if (ddlContents.SelectedIndex == 0)
            {
                ShowAlertMessage("Please select content.");
                ddlContents.Focus();
                return false;
            }

            return true;

        }
        public static void ShowAlertMessage(string error)
        {
            Page page = HttpContext.Current.Handler as Page;

            if (page != null)
            {
                error = error.Replace("'", "\'");

                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
            }
        }

        protected DataTable getAllSelectedPlansWithRates()
        {
            DataTable PlanTable = BuildPlanTable();

            DropDownList ddlRates = new DropDownList();

            foreach (GridViewRow grRow in gvPlanBernefitSummaryOptions.Rows)
            {
                if (grRow.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnHasRates = grRow.FindControl("hdnHasRates") as HiddenField;

                    if (hdnHasRates.Value == "Yes")
                    {
                        ddlRates = ((System.Web.UI.WebControls.DropDownList)grRow.FindControl("ddlRates1"));
                        if (ddlRates.SelectedValue != "Do Not Include")
                        {
                            // fetch data from hiddenvalues
                            HiddenField hdnLOC = grRow.FindControl("hdnLOC") as HiddenField;
                            HiddenField hdnProductId = grRow.FindControl("hdnProductId") as HiddenField;
                            HiddenField hdnProductName = grRow.FindControl("hdnProductName") as HiddenField;
                            HiddenField hdnSummaryId = grRow.FindControl("hdnSummaryId") as HiddenField;
                            HiddenField hdnProductTypeId = grRow.FindControl("hdnProductTypeId") as HiddenField;
                            HiddenField hdnProductTypeDescription = grRow.FindControl("hdnProductTypeDescription") as HiddenField;
                            HiddenField hdnCarrierName = grRow.FindControl("hdnCarrierName") as HiddenField;
                            HiddenField hdnEffectiveDate = grRow.FindControl("hdnEffectiveDate") as HiddenField;
                            HiddenField hdnRenewalDate = grRow.FindControl("hdnRenewalDate") as HiddenField;
                            HiddenField hdnPolicyNumber = grRow.FindControl("hdnPolicyNumber") as HiddenField;
                            HiddenField hdnSummaryName = grRow.FindControl("hdnSummaryName") as HiddenField;

                            DataRow row = PlanTable.NewRow();
                            row["ProductId"] = hdnProductId.Value;
                            row["ProductName"] = hdnProductName.Value;
                            row["Carrier"] = hdnCarrierName.Value;
                            row["Effective"] = hdnEffectiveDate.Value;
                            row["Renewal"] = hdnRenewalDate.Value;
                            row["PolicyNumber"] = hdnPolicyNumber.Value;
                            row["ProductTypeId"] = hdnProductTypeId.Value;
                            row["PlanType"] = hdnProductTypeDescription.Value;
                            row["SummaryId"] = hdnSummaryId.Value;
                            row["SummaryName"] = hdnSummaryName.Value;
                            row["RateId"] = ddlRates.SelectedValue;
                            row["RateName"] = ddlRates.SelectedItem.Text;
                            row["LOC"] = hdnLOC.Value;
                            PlanTable.Rows.Add(row);
                        }
                    }
                }
            }

            return PlanTable;

        }

        protected void AddSelectedPlanRatesToSession()
        {
            Dictionary<string, string> DictSelectedRates = new Dictionary<string, string>();
            DropDownList ddlRates = new DropDownList();

            foreach (GridViewRow grRow in gvPlanBernefitSummaryOptions.Rows)
            {
                if (grRow.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnHasRates = grRow.FindControl("hdnHasRates") as HiddenField;
                    //lblBenefitSummary
                    Label lblBenefitSummary = grRow.FindControl("lblBenefitSummary") as Label;

                    if (hdnHasRates.Value == "Yes")
                    {
                        ddlRates = ((System.Web.UI.WebControls.DropDownList)grRow.FindControl("ddlRates1"));
                        if (ddlRates.SelectedValue != "Do Not Include")
                        {
                            if (!DictSelectedRates.ContainsKey(lblBenefitSummary.Text))
                            {
                                DictSelectedRates.Add(lblBenefitSummary.Text, ddlRates.SelectedValue);
                            }
                        }
                    }
                }
            }


            Session["SelectedPlanRates"] = DictSelectedRates;
        }

        protected DataTable BuildPlanTable()
        {
            DataTable planstable = new DataTable();

            planstable.Columns.Add("ProductId", typeof(Int32));
            planstable.Columns.Add("ProductName", typeof(string));
            planstable.Columns.Add("Carrier", typeof(string));
            planstable.Columns.Add("Effective", typeof(string));
            planstable.Columns.Add("Renewal", typeof(string));
            planstable.Columns.Add("PolicyNumber", typeof(string));
            planstable.Columns.Add("ProductTypeId", typeof(string));
            planstable.Columns.Add("PlanType", typeof(string));
            planstable.Columns.Add("SummaryId", typeof(Int32));
            planstable.Columns.Add("SummaryName", typeof(string));
            planstable.Columns.Add("RateId", typeof(Int32));
            planstable.Columns.Add("RateName", typeof(string));
            planstable.Columns.Add("LOC", typeof(string));


            return planstable;
        }
        #endregion

        private string CreateSimpleSummery(List<RenewalPlanSelectionViewModel> SelectedPlans, DataSet AccountTeamMemberDS, DataSet AccountDS)
        {
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            List<RenewalPlanSelectionViewModel> SelectedPlansBenefitSummary = new List<RenewalPlanSelectionViewModel>();

            Object fileName = "";

            #region Remove Duplicate rows based on PlanType and Carrier

            Dictionary<string, string> UniquePlanCarrier = new Dictionary<string, string>();

            foreach (RenewalPlanSelectionViewModel plan in SelectedPlans)
            {
                if (!UniquePlanCarrier.ContainsKey(plan.ProductTypeDescription + plan.CarrierName))
                {
                    UniquePlanCarrier.Add(plan.ProductTypeDescription + plan.CarrierName, plan.ProductTypeDescription + plan.CarrierName);
                    SelectedPlansBenefitSummary.Add(plan);
                }
            }
            #endregion

            fileName = Server.MapPath("~/Files/RenewalDecisionForm/Documents/Templates/RenewalDecision_Simple_Summary_Word.docx");


            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/RenewalDecisionForm/Documents/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docx");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/RenewalDecisionForm/Documents/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/RenewalDecisionForm/Documents/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                //----------
                WriteSimpleSummeryWord wr = new WriteSimpleSummeryWord();
                wr.WriteUpperDescription(oWordDoc, oWordApp, ddlClient, ddlAccountContact, SelectedPlansBenefitSummary, SessionId);
                wr.WriteMedicalPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteStopLossPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteDentalPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteVisionPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteLifeADnDPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteGroupTermLifePlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteVoluntaryADnDPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteSTDPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteLTDPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteEAPPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteFSAPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteHRAPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteHSAPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteWellnessPlan(oWordDoc, oWordApp, SelectedPlansBenefitSummary);
                wr.WriteBottomContent(oWordDoc, oWordApp, AccountTeamMemberDS, AccountDS);
                wr.DeleteBookmarks(oWordDoc, oWordApp, SelectedPlansBenefitSummary);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            string deliverableCategory = "Client Management Tools";
            Activity = "Renewal Decision Form";
            Activity_Group = "Tools";

            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedValue), Account_Region, Account_Office, deliverableCategory, Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }

    }
}