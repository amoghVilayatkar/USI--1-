﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using System.Runtime.InteropServices;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.IO;
using System.Data;
using System.Collections;


namespace BenefitPointSummaryPortal.BAL.PowerPoint
{
    public class WritePowerPoint1 : System.Web.UI.Page
    {
        Microsoft.Office.Interop.PowerPoint.Shapes objShapes;
        BPBusiness bp = new BPBusiness();

        /// <summary> 
        /// Write Field to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        public void WriteFieldToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                int index = -1;

                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;

                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                                    {
                                    }
                                    else
                                    {
                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Client Name>>"))
                                        {
                                            txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                            txtRange.Replace("<<Client Name1>>", ddlClient.SelectedItem.Text.ToString());
                                            txtRange.Replace("<<Client Name2>>", ddlClient.SelectedItem.Text.ToString());
                                        }
                                        // Firstly client told to take renewal date, now told to take Effective date
                                        //if (txtRange.Text.Contains("<<First Med Plan Renewal Year>>"))
                                        //{
                                        //    string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        //    txtRange.Replace("<<First Med Plan Renewal Year>>", Convert.ToDateTime(renewal.ToString()).Year.ToString());
                                        //}

                                        if (txtRange.Text.Contains("<<First Med Plan Effective Year>>"))
                                        {
                                            string effective = PlanTable.Rows[k]["Effective"].ToString();
                                            txtRange.Replace("<<First Med Plan Effective Year>>", Convert.ToDateTime(effective.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Eff Date Year>>"))
                                        {
                                            string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                            txtRange.Replace("<<First Med Plan Eff Date Year>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year1>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year2>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Expiration Year>>"))
                                        {
                                            //txtRange.Replace("<<First Med Plan Expiration Year>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).ToShortDateString()));
                                            txtRange.Replace("<<First Med Plan Expiration Year>>", Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year.ToString());

                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Effective Date>>"))
                                        {
                                            txtRange.Replace("<<First Med Plan Effective Date>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).ToShortDateString()));
                                        }
                                        if (Emp.Rows.Count > 0)
                                        {
                                            if (txtRange.Text.Contains("<<Employee Status>>"))
                                            {
                                                txtRange.Replace("<<Employee Status>>", Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString());
                                            }
                                            if (txtRange.Text.Contains("<<working>>"))
                                            {
                                                txtRange.Replace("<<working>>", Emp.Rows[0]["VALUE"].ToString() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString());
                                            }
                                        }
                                        else
                                        {
                                            txtRange.Replace("<<Employee Status>>", " ");
                                            txtRange.Replace("<<working>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<< Eligibility Rule – Waiting Period>>"))
                                        {
                                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                            {
                                                txtRange.Replace("<< Eligibility Rule – Waiting Period>>", EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString());
                                            }
                                            else
                                            {
                                                txtRange.Replace("<< Eligibility Rule – Waiting Period>>", " ");

                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Spouse>>"))
                                        {
                                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                            {
                                                string str = " ";
                                                if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString() != "")
                                                {
                                                    str = "Legally married Spouse";
                                                    str = str + "\n" + "Domestic Partner - " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                                }
                                                else
                                                {
                                                    str = str + "\n" + " ";
                                                }

                                                //txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString());
                                                txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", str);
                                            }
                                            else
                                            {
                                                string str1 = " ";
                                                txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Spouse>>", str1 + "\n");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>"))
                                        {
                                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                            {
                                                if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString() != "")
                                                {
                                                    txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", "Covered up to age " + EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", " ");
                                                }
                                            }
                                            else
                                            {
                                                txtRange.Replace("<<Eligibility Rule – Definition of Dependent – Unmarried Child to Age>>", " ");
                                            }
                                        }
                                        if (BRCindex > -1)
                                        {
                                            if (txtRange.Text.Contains("<<BRC Phone Number>>"))
                                            {
                                                txtRange.Replace("<<BRC Phone Number>>", BRCList[BRCindex].BRCPhone);
                                            }
                                            if (txtRange.Text.Contains("<<BRC Email>>"))
                                            {
                                                txtRange.Replace("<<BRC Email>>", BRCList[BRCindex].BRCEmail);
                                            }
                                            if (txtRange.Text.Contains("<<BRC Hours>>"))
                                            {
                                                txtRange.Replace("<<BRC Hours>>", BRCList[BRCindex].BRCDayHours);
                                            }
                                        }
                                        else
                                        {
                                            txtRange.Replace("<<BRC Phone Number>>", " ");
                                            txtRange.Replace("<<BRC Email>>", " ");
                                            txtRange.Replace("<<BRC Hours>>", " ");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="ddlClient">For showing client name on the fields.</param> 
        /// <param name="ddlHSANoOfPlan">To check whether the HSA plan is selected or not, if selected then show attribute values for HSA in medical section.</param>
        public void WriteMedicalSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, DropDownList ddlClient, DropDownList ddlHSANoOfPlan, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(1, "45");    //Calendar Year Deductible indivisual
                HashtableMedicalInNetwork1.Add(2, "44");    //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(3, "53");    //Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalInNetwork1.Add(4, "52");    //Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalInNetwork1.Add(5, "112");   //General Plan Information Coinsurence
                HashtableMedicalInNetwork1.Add(6, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork1.Add(7, "386");   //Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(8, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalInNetwork1.Add(9, "555");   //Other Services[Urgent Care]
                HashtableMedicalInNetwork1.Add(10, "184");  //Emergency Room
                HashtableMedicalInNetwork1.Add(11, "409");  //Hospital/Facility[Outpatient Care]
                HashtableMedicalInNetwork1.Add(12, "295");  //Hospital/Facility[Inpatient Care]
                HashtableMedicalInNetwork1.Add(13, "971");            //Other Services[Complex Radiology]

                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedicalOutNetwork.Add(1, "112");   //Out-of-Network Benefits[Coinsurance]

                #endregion

                int count = 1;
                string InNetwork_Indivisual_Plan1 = string.Empty;
                string InNetwork_Family_Plan1 = string.Empty;
                string OutOfPocket_Individual_Plan1 = string.Empty;
                string OutOfPocket_Family_Plan1 = string.Empty;
                string InNetwork_Coinsurance_Plan1 = string.Empty;
                string InNetwork_PreventiveCare_Plan1 = string.Empty;
                string InNetwork_Office_Visit_Plan1 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan1 = string.Empty;
                string InNetwork_cardio_Plan1 = string.Empty;
                string InNetwork_Urgent_Care_Plan1 = string.Empty;
                string InNetwork_Emergency_Plan1 = string.Empty;
                string InNetwork_Outpatient_Plan1 = string.Empty;
                string InNetwork_Inpatient_Plan1 = string.Empty;
                string Medical_Plan_Name_Plan1 = string.Empty;
                string Medical_Carrier_Plan1 = string.Empty;
                string Medical_Summary_Plan1 = string.Empty;

                string InNetwork_Indivisual_Plan2 = string.Empty;
                string InNetwork_Family_Plan2 = string.Empty;
                string OutOfPocket_Individual_Plan2 = string.Empty;
                string OutOfPocket_Family_Plan2 = string.Empty;
                string InNetwork_Coinsurance_Plan2 = string.Empty;
                string InNetwork_PreventiveCare_Plan2 = string.Empty;
                string InNetwork_Office_Visit_Plan2 = string.Empty;
                string InNetwork_XRay_And_LabTest_Plan2 = string.Empty;
                string InNetwork_cardio_Plan2 = string.Empty;
                string InNetwork_Urgent_Care_Plan2 = string.Empty;
                string InNetwork_Emergency_Plan2 = string.Empty;
                string InNetwork_Outpatient_Plan2 = string.Empty;
                string InNetwork_Inpatient_Plan2 = string.Empty;
                string Medical_Plan_Name_Plan2 = string.Empty;
                string Medical_Carrier_Plan2 = string.Empty;
                string Medical_Summary_Plan2 = string.Empty;

                string medicalcarrier = "";
                string value = string.Empty;
                double coInsurance_Value = 0;
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (count == 1)
                            {
                                Medical_Plan_Name_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (count == 2)
                            {
                                Medical_Plan_Name_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Medical_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Medical_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            #region MedicalTable

                            // Store the value for each attribute in the respective variables by iterating each key from hashtable for both the medical plans
                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan1 = value; break;
                                                case 2: InNetwork_Family_Plan1 = value; break;
                                                case 3: OutOfPocket_Individual_Plan1 = value; break;
                                                case 4: OutOfPocket_Family_Plan1 = value; break;
                                                //case 5: InNetwork_Coinsurance_Plan1 = value;
                                                //    string Str = dr["value"].ToString().Trim();
                                                //    bool isNum = double.TryParse(Str, out coInsurance_Value);
                                                //    if (isNum)
                                                //    {
                                                //    }
                                                //    else
                                                //    {
                                                //        coInsurance_Value = 0;
                                                //    }
                                                //    break;
                                                case 6: InNetwork_PreventiveCare_Plan1 = value; break;
                                                case 7: InNetwork_Office_Visit_Plan1 = value; break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan1 = value; break;
                                                case 9: InNetwork_Urgent_Care_Plan1 = value; break;
                                                case 10: InNetwork_Emergency_Plan1 = value; break;
                                                case 11: InNetwork_Outpatient_Plan1 = value; break;
                                                case 12: InNetwork_Inpatient_Plan1 = value; break;
                                                case 13: InNetwork_cardio_Plan1 = value; break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Indivisual_Plan2 = value; break;
                                                case 2: InNetwork_Family_Plan2 = value; break;
                                                case 3: OutOfPocket_Individual_Plan2 = value; break;
                                                case 4: OutOfPocket_Family_Plan2 = value; break;
                                                //case 5: InNetwork_Coinsurance_Plan2 = value; break;
                                                case 6: InNetwork_PreventiveCare_Plan2 = value; break;
                                                case 7: InNetwork_Office_Visit_Plan2 = value; break;
                                                case 8: InNetwork_XRay_And_LabTest_Plan2 = value; break;
                                                case 9: InNetwork_Urgent_Care_Plan2 = value; break;
                                                case 10: InNetwork_Emergency_Plan2 = value; break;
                                                case 11: InNetwork_Outpatient_Plan2 = value; break;
                                                case 12: InNetwork_Inpatient_Plan2 = value; break;
                                                case 13: InNetwork_cardio_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }


                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Coinsurance_Plan1 = value;
                                                    string Str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(Str, out coInsurance_Value);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        coInsurance_Value = 0;
                                                    }
                                                    break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: InNetwork_Coinsurance_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            medicalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region MergeField
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;

                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value
                                        if (objShapes[j].Name.ToString().Equals("Medical_Rate_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Plan_Name_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Plan_Name_Plan2);
                                                    }
                                                }
                                            }
                                        }

                                        if (objShapes[j].Name.ToString().Equals("Medical_Plan_Table_1"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<First Medical Carrier>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Carrier>>", Medical_Carrier_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<Second Medical Carrier>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Carrier>>", Medical_Carrier_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual ded/Individual>>", InNetwork_Indivisual_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", InNetwork_Indivisual_Plan1.Trim() + " single enrollment");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual ded/Family>>", InNetwork_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", InNetwork_Family_Plan1.Trim() + " family enrollment*");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Individual2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual ded/Individual2>>", InNetwork_Indivisual_Plan2);
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual2>>", InNetwork_Indivisual_Plan2.Trim() + " per person");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Individual2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual ded/Family2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual ded/Family2>>", InNetwork_Family_Plan2);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family2>>", InNetwork_Family_Plan2.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual ded/Family2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Client Name>>"))
                                                    {
                                                        txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                                    }
                                                    if (txtRange.Text.Contains("<<Health Saving Account Plan -Employer Contributions –Individual>>"))
                                                    {
                                                        if (ddlHSANoOfPlan.SelectedIndex == 0)
                                                        {
                                                            txtRange.Replace("<<Health Saving Account Plan -Employer Contributions –Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Health Saving Account Plan - Employer Contributions –Family>>"))
                                                    {
                                                        if (ddlHSANoOfPlan.SelectedIndex == 0)
                                                        {
                                                            txtRange.Replace("<<Health Saving Account Plan - Employer Contributions –Family>>", " ");
                                                        }
                                                    }

                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Individual>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", OutOfPocket_Individual_Plan1);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", OutOfPocket_Individual_Plan1.Trim() + " single enrollment*");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Individual>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of-Pocket Limit/Family>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", OutOfPocket_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", OutOfPocket_Family_Plan1.Trim() + " family enrollment*");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of-Pocket Limit/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of Pocket Limit/Individual2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Individual_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", OutOfPocket_Individual_Plan2.Trim() + " per person");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of Pocket Limit/Individual2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<Annual Out-of Pocket Limit/Family2>>"))
                                                    {
                                                        //txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", OutOfPocket_Family_Plan2);
                                                        if (!string.IsNullOrEmpty(OutOfPocket_Family_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", OutOfPocket_Family_Plan2.Trim() + " per family");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<Annual Out-of Pocket Limit/Family2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<General Plan Info – Coinsurance>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Coinsurance>>", InNetwork_Coinsurance_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", InNetwork_Coinsurance_Plan1.Trim() + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<General Plan Info – Coinsurance2>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Coinsurance2>>", InNetwork_Coinsurance_Plan2);
                                                        if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan2.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance2>>", InNetwork_Coinsurance_Plan2.Trim() + " in most cases");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Coinsurance2>>", " ");
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (objShapes[j].Name.ToString().Equals("Medical_Plan_Table_2"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Adult Periodic Exams w/ Preventative tests>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Adult Periodic Exams w/ Preventative tests>>", InNetwork_PreventiveCare_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Adult Periodic Exams w/ Preventative tests2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Adult Periodic Exams w/ Preventative tests2>>", InNetwork_PreventiveCare_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam>>", InNetwork_Office_Visit_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Office Visit/Exam2>>"))
                                                    {
                                                        txtRange.Replace("<<General Plan Info – Office Visit/Exam2>>", InNetwork_Office_Visit_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests>>", InNetwork_XRay_And_LabTest_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Diagnostic X-Ray and Lab Tests2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Diagnostic X-Ray and Lab Tests2>>", InNetwork_XRay_And_LabTest_Plan2.Trim());
                                                    }
                                                    #region Outpatient Services – Complex Radiology
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology>>", InNetwork_cardio_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Services – Complex Radiology2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Services – Complex Radiology2>>", InNetwork_cardio_Plan2.Trim());
                                                    }
                                                    #endregion
                                                    if (txtRange.Text.Contains("<<Urgent Care – Urgent Care Facility>>"))
                                                    {
                                                        txtRange.Replace("<<Urgent Care – Urgent Care Facility>>", InNetwork_Urgent_Care_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Urgent Care – Urgent Care Facility2>>"))
                                                    {
                                                        txtRange.Replace("<<Urgent Care – Urgent Care Facility2>>", InNetwork_Urgent_Care_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room>>", InNetwork_Emergency_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Emergency Services – Emergency Room2>>"))
                                                    {
                                                        txtRange.Replace("<<Emergency Services – Emergency Room2>>", InNetwork_Emergency_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Hospital Services – Outpatient Facility Charges>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Hospital Services – Outpatient Facility Charges>>", InNetwork_Outpatient_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Outpatient Hospital Services – Outpatient Facility Charges2>>"))
                                                    {
                                                        txtRange.Replace("<<Outpatient Hospital Services – Outpatient Facility Charges2>>", InNetwork_Outpatient_Plan2.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization>>", InNetwork_Inpatient_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Inpatient Hospital Services – Inpatient Hospitalization2>>"))
                                                    {
                                                        txtRange.Replace("<<Inpatient Hospital Services – Inpatient Hospitalization2>>", InNetwork_Inpatient_Plan2.Trim());
                                                    }
                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_Example_1_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Individual>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Individual>>", InNetwork_Indivisual_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Individual2>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Individual2>>", InNetwork_Indivisual_Plan2.Trim());
                                                    }

                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_Example_2_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family>>", InNetwork_Family_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family2>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family2>>", InNetwork_Family_Plan2.Trim());
                                                    }
                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_Example_3_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family>>", InNetwork_Family_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family2>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family2>>", InNetwork_Family_Plan2.Trim());
                                                    }

                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_Example_4_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family>>", InNetwork_Family_Plan1.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Med Plan Ded/Family2>>"))
                                                    {
                                                        txtRange.Replace("<<Med Plan Ded/Family2>>", InNetwork_Family_Plan2.Trim());
                                                    }
                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_Plan_Comp_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                }
                                            }
                                        }
                                        if (objShapes[j].Name.ToString().Equals("Medical_HSA_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Ded/Ind>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Ded/Ind>>", InNetwork_Indivisual_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Ind>>", InNetwork_Indivisual_Plan1.Trim() + " Deductible");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Ind>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Out-of-Pocket/Ind>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Ind>>", OutOfPocket_Individual_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Individual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Ind>>", " / " + OutOfPocket_Individual_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else if (string.IsNullOrEmpty(InNetwork_Indivisual_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Individual_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Ind>>", OutOfPocket_Individual_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Ind>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Ded/Family>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Ded/Family>>", InNetwork_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family>>", InNetwork_Family_Plan1.Trim() + " Deductible");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Out-of-Pocket/Family>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", OutOfPocket_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", " / " + OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else if (string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", " ");
                                                        }
                                                    }

                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Ded/Family1>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Ded/Family>>", InNetwork_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family1>>", InNetwork_Family_Plan1.Trim() + " Deductible");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family1>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Out-of-Pocket/Family1>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", OutOfPocket_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family1>>", " / " + OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else if (string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family1>>", OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family1>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Ded/Family2>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Ded/Family>>", InNetwork_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family2>>", InNetwork_Family_Plan1.Trim() + " Deductible");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Ded/Family2>>", " ");
                                                        }
                                                    }
                                                    if (txtRange.Text.Contains("<<General Plan Info – Annual Out-of-Pocket/Family2>>"))
                                                    {
                                                        //txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family>>", OutOfPocket_Family_Plan1);
                                                        if (!string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family2>>", " / " + OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else if (string.IsNullOrEmpty(InNetwork_Family_Plan1.Trim()) && !string.IsNullOrEmpty(OutOfPocket_Family_Plan1.Trim()))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family2>>", OutOfPocket_Family_Plan1.Trim() + " Out-of-Pocket Maximum");
                                                        }
                                                        else
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Annual Out-of-Pocket/Family2>>", " ");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                                    {
                                    }
                                    else
                                    {
                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;
                                        if (txtRange.Text.Contains("<<First Medical Carrier and Plan Name>>"))
                                        {
                                            //txtRange.Replace("<<First Medical Carrier and Plan Name>>", Medical_Carrier_Plan1 + " " + Medical_Summary_Plan1);
                                            txtRange.Replace("<<First Medical Carrier and Plan Name>>", Medical_Plan_Name_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<First Medical Plan Name>>"))
                                        {
                                            txtRange.Replace("<<First Medical Plan Name>>", Medical_Plan_Name_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<First Medical Plan Name2>>"))
                                        {
                                            txtRange.Replace("<<First Medical Plan Name2>>", Medical_Plan_Name_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                        {
                                            txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<Second Medical Carrier and Plan Name>>"))
                                        {
                                            //txtRange.Replace("<<Second Medical Carrier and Plan Name>>", Medical_Carrier_Plan2 + " " + Medical_Summary_Plan2);
                                            txtRange.Replace("<<Second Medical Carrier and Plan Name>>", Medical_Plan_Name_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<Second Medical Plan Name>>"))
                                        {
                                            txtRange.Replace("<<Second Medical Plan Name>>", Medical_Plan_Name_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                        {
                                            txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<First Medical Carrier>>"))
                                        {
                                            txtRange.Replace("<<First Medical Carrier>>", Medical_Carrier_Plan1);
                                        }
                                        if (txtRange.Text.Contains("<<Second Medical Carrier>>"))
                                        {
                                            txtRange.Replace("<<Second Medical Carrier>>", Medical_Carrier_Plan2);
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Renewal Year>>"))
                                        {
                                            string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                            txtRange.Replace("<<First Med Plan Renewal Year>>", Convert.ToDateTime(renewal.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Eff Date Year>>"))
                                        {
                                            string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                            txtRange.Replace("<<First Med Plan Eff Date Year>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year1>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            txtRange.Replace("<<First Med Plan Eff Date Year2>>", Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Expiration Year>>"))
                                        {
                                            txtRange.Replace("<<First Med Plan Expiration Year>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).ToShortDateString()));
                                        }
                                        if (txtRange.Text.Contains("<<First Med Plan Effective Date>>"))
                                        {
                                            txtRange.Replace("<<First Med Plan Effective Date>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).ToShortDateString()));
                                        }

                                        // If HSA plan is selected then only we have to write on slide number 23 and we have to do calculation for coinsurance
                                        if (ddlHSANoOfPlan.SelectedIndex > 0)
                                        {
                                            if (txtRange.Text.Contains("<<Annual Ded/Individual>>"))
                                            {
                                                txtRange.Replace("<<Annual Ded/Individual>>", InNetwork_Indivisual_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual Ded/Family>>"))
                                            {
                                                txtRange.Replace("<<Annual Ded/Family>>", InNetwork_Family_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual Ded/Individual1>>"))
                                            {
                                                txtRange.Replace("<<Annual Ded/Individual1>>", InNetwork_Indivisual_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual Out-of-Pocket  Limit/Individual1>>"))
                                            {
                                                txtRange.Replace("<<Annual Out-of-Pocket  Limit/Individual1>>", OutOfPocket_Individual_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual Ded/Family1>>"))
                                            {
                                                txtRange.Replace("<<Annual Ded/Family1>>", InNetwork_Family_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual OOP Limit/Family1>>"))
                                            {
                                                txtRange.Replace("<<Annual OOP Limit/Family1>>", OutOfPocket_Family_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual OOP Limit/Ind>>"))
                                            {
                                                txtRange.Replace("<<Annual OOP Limit/Ind>>", OutOfPocket_Individual_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Annual Out-of-Pocket  Limit/Family>>"))
                                            {
                                                txtRange.Replace("<<Annual Out-of-Pocket  Limit/Family>>", OutOfPocket_Family_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<First Med General Plan Info – Coinsurance>>"))
                                            {
                                                if (!string.IsNullOrEmpty(InNetwork_Coinsurance_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<First Med General Plan Info – Coinsurance>>", InNetwork_Coinsurance_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<First Med General Plan Info – Coinsurance>>", "0%");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Outpatient Services - Adult Periodic Exams>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Outpatient Services - Adult Periodic Exams>>", InNetwork_PreventiveCare_Plan1.Trim());
                                            }
                                            if (txtRange.Text.Contains("<<Calculation>>"))
                                            {
                                                double coinsurance = 100 - coInsurance_Value;
                                                txtRange.Replace("<<Calculation>>", Convert.ToString(coinsurance) + "%");
                                            }
                                        }

                                        if (txtRange.Text.Contains("<<Plan Renewal Date>>"))
                                        {
                                            txtRange.Replace("<<Plan Renewal Date>>", Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).ToShortDateString()));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        public void WritePrescriptionDrugsSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string deductible_Plan1 = "";
                string Generic_Plan1 = "";
                string Formulary_Plan1 = "";
                string NonFormulary_Plan1 = "";
                string Preferred_Specialty_Plan1 = "";

                string deductible_Plan2 = "";
                string Generic_Plan2 = "";
                string Formulary_Plan2 = "";
                string NonFormulary_Plan2 = "";
                string Preferred_Specialty_Plan2 = "";
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213"); //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");  //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");  //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "578"); //Deductible[Individual]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211"); //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");  //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");  //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "578"); //Deductible[Individual]
                HashtableMailOrder.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                string Medical_Plan_Name_Plan1 = string.Empty;
                string Medical_Summary_Plan1 = string.Empty;
                string Medical_Plan_Name_Plan2 = string.Empty;
                string Medical_Summary_Plan2 = string.Empty;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            Medical_Plan_Name_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan1 = value; break;
                                                case 2: Formulary_Plan1 = value; break;
                                                case 3: NonFormulary_Plan1 = value; break;
                                                case 4: deductible_Plan1 = value; break;
                                                case 5: Preferred_Specialty_Plan1 = value; break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            Medical_Plan_Name_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                            Medical_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: Generic_Plan2 = value; break;
                                                case 2: Formulary_Plan2 = value; break;
                                                case 3: NonFormulary_Plan2 = value; break;
                                                case 4: deductible_Plan2 = value; break;
                                                case 5: Preferred_Specialty_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }

                            //foreach (int key in HashtableMailOrder.Keys)
                            //{
                            //    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                            //    {
                            //        if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                            //        {
                            //            if (count == 1)
                            //            {
                            //                value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                            //                switch (key)
                            //                {
                            //                    case 1: Generic_Plan1 = value; break;
                            //                    case 2: Formulary_Plan1 = value; break;
                            //                    case 3: NonFormulary_Plan1 = value; break;
                            //                    case 4: deductible_Plan1 = value; break;
                            //                }
                            //            }

                            //            if (count == 2)
                            //            {
                            //                value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                            //                switch (key)
                            //                {
                            //                    case 1: Generic_Plan2 = value; break;
                            //                    case 2: Formulary_Plan2 = value; break;
                            //                    case 3: NonFormulary_Plan2 = value; break;
                            //                    case 4: deductible_Plan2 = value; break;
                            //                }
                            //            }
                            //        }
                            //    }
                            //}
                            count++;

                            value = "";
                        }
                    }
                }

                #region Merge Fields
                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value
                                        if (objShapes[j].Name.ToString().Equals("Medical_Prescription_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<First Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<First Medical Plan Summary Name>>", Medical_Summary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Second Medical Plan Summary Name>>"))
                                                    {
                                                        txtRange.Replace("<<Second Medical Plan Summary Name>>", Medical_Summary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible>>", deductible_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Prescription Drug Deductible2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Prescription Drug Deductible2>>", deductible_Plan2);
                                                    }

                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic>>", Generic_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Generic2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Generic2>>", Generic_Plan2);
                                                    }

                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred>>", Formulary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Formulary/Preferred2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Formulary/Preferred2>>", Formulary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred>>", NonFormulary_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred2>>"))
                                                    {
                                                        txtRange.Replace("<<Prescription Drug Benefits – Brand (Non-Formulary/Non-Preferred2>>", NonFormulary_Plan2);
                                                    }
                                                    if (txtRange.Text.Contains("<<PreferredSpecialty1>>"))
                                                    {
                                                        txtRange.Replace("<<PreferredSpecialty1>>", Preferred_Specialty_Plan1);
                                                    }
                                                    if (txtRange.Text.Contains("<<PreferredSpecialty2>>"))
                                                    {
                                                        txtRange.Replace("<<PreferredSpecialty2>>", Preferred_Specialty_Plan2);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(1, "45");      //Annual Deductible[Individual]
                HashtableDentalInNetwork.Add(2, "55");      //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(3, "566");     //Deductible waived for Preventive
                HashtableDentalInNetwork.Add(4, "64");      //Basic Restorative Care - Basic 
                HashtableDentalInNetwork.Add(5, "336");     //Major Restorative Care - Major
                HashtableDentalInNetwork.Add(6, "392");     //Orthodontic Services
                HashtableDentalInNetwork.Add(7, "314");     //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(8, "565");     //Additional Features[Waiting Periods]

                #endregion
                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(1, "45");      //Annual Deductible[Individual]
                HashtableDentalOutNetwork.Add(2, "55");      //Calendar Year Benefit Maximum
                HashtableDentalOutNetwork.Add(3, "566");     //Deductible waived for Preventive
                HashtableDentalOutNetwork.Add(4, "64");      //Basic Restorative Care - Basic 
                HashtableDentalOutNetwork.Add(5, "336");     //Major Restorative Care - Major
                HashtableDentalOutNetwork.Add(6, "392");     //Orthodontic Services
                HashtableDentalOutNetwork.Add(7, "314");     //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDentalOutNetwork.Add(8, "565");     //Additional Features[Waiting Periods]

                #endregion
                int count = 1;

                string value = "";

                string InNetwork_Calendar_Year_Deductible_Plan1 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan1 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan1 = string.Empty;
                string InNetwork_Basic_Services_Plan1 = string.Empty;
                string InNetwork_Major_Services_Plan1 = string.Empty;
                string InNetwork_Orthodontia_Plan1 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan1 = string.Empty;
                string InNetwork_Waiting_Periods_Plan1 = string.Empty;
                string Dental_Plan_1 = string.Empty;
                string Dental_Carrier_Plan1 = string.Empty;
                string Dental_Summary_Plan1 = string.Empty;

                string OutNetwork_Calendar_Year_Deductible_Plan1 = string.Empty;
                string OutNetwork_Calendar_Year_Benefit_Maximum_Plan1 = string.Empty;
                string OutNetwork_Preventive_Care_Waived_Plan1 = string.Empty;
                string OutNetwork_Basic_Services_Plan1 = string.Empty;
                string OutNetwork_Major_Services_Plan1 = string.Empty;
                string OutNetwork_Orthodontia_Plan1 = string.Empty;
                string OutNetwork_Orthodontia_Maximum_Plan1 = string.Empty;
                string OutNetwork_Waiting_Periods_Plan1 = string.Empty;
                string Dental_Plan_2 = string.Empty;
                string Dental_Carrier_Plan2 = string.Empty;
                string Dental_Summary_Plan2 = string.Empty;

                string InNetwork_Calendar_Year_Deductible_Plan2 = string.Empty;
                string InNetwork_Calendar_Year_Benefit_Maximum_Plan2 = string.Empty;
                string InNetwork_Preventive_Care_Waived_Plan2 = string.Empty;
                string InNetwork_Basic_Services_Plan2 = string.Empty;
                string InNetwork_Major_Services_Plan2 = string.Empty;
                string InNetwork_Orthodontia_Plan2 = string.Empty;
                string InNetwork_Orthodontia_Maximum_Plan2 = string.Empty;
                string InNetwork_Waiting_Periods_Plan2 = string.Empty;

                string OutNetwork_Calendar_Year_Deductible_Plan2 = string.Empty;
                string OutNetwork_Calendar_Year_Benefit_Maximum_Plan2 = string.Empty;
                string OutNetwork_Preventive_Care_Waived_Plan2 = string.Empty;
                string OutNetwork_Basic_Services_Plan2 = string.Empty;
                string OutNetwork_Major_Services_Plan2 = string.Empty;
                string OutNetwork_Orthodontia_Plan2 = string.Empty;
                string OutNetwork_Orthodontia_Maximum_Plan2 = string.Empty;
                string OutNetwork_Waiting_Periods_Plan2 = string.Empty;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (count == 1)
                            {
                                Dental_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Dental_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                Dental_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                                Dental_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Dental_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            #region DentalTable

                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Plan1 = value; break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan1 = value; break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan1 = value; break;
                                                case 4: InNetwork_Basic_Services_Plan1 = value; break;
                                                case 5: InNetwork_Major_Services_Plan1 = value; break;
                                                case 6: InNetwork_Orthodontia_Plan1 = value; break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan1 = value; break;
                                                case 8: InNetwork_Waiting_Periods_Plan1 = value; break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: InNetwork_Calendar_Year_Deductible_Plan2 = value; break;
                                                case 2: InNetwork_Calendar_Year_Benefit_Maximum_Plan2 = value; break;
                                                case 3: InNetwork_Preventive_Care_Waived_Plan2 = value; break;
                                                case 4: InNetwork_Basic_Services_Plan2 = value; break;
                                                case 5: InNetwork_Major_Services_Plan2 = value; break;
                                                case 6: InNetwork_Orthodontia_Plan2 = value; break;
                                                case 7: InNetwork_Orthodontia_Maximum_Plan2 = value; break;
                                                case 8: InNetwork_Waiting_Periods_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {

                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: OutNetwork_Calendar_Year_Deductible_Plan1 = value; break;
                                                case 2: OutNetwork_Calendar_Year_Benefit_Maximum_Plan1 = value; break;
                                                case 3: OutNetwork_Preventive_Care_Waived_Plan1 = value; break;
                                                case 4: OutNetwork_Basic_Services_Plan1 = value; break;
                                                case 5: OutNetwork_Major_Services_Plan1 = value; break;
                                                case 6: OutNetwork_Orthodontia_Plan1 = value; break;
                                                case 7: OutNetwork_Orthodontia_Maximum_Plan1 = value; break;
                                                case 8: OutNetwork_Waiting_Periods_Plan1 = value; break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            switch (key)
                                            {
                                                case 1: OutNetwork_Calendar_Year_Deductible_Plan2 = value; break;
                                                case 2: OutNetwork_Calendar_Year_Benefit_Maximum_Plan2 = value; break;
                                                case 3: OutNetwork_Preventive_Care_Waived_Plan2 = value; break;
                                                case 4: OutNetwork_Basic_Services_Plan2 = value; break;
                                                case 5: OutNetwork_Major_Services_Plan2 = value; break;
                                                case 6: OutNetwork_Orthodontia_Plan2 = value; break;
                                                case 7: OutNetwork_Orthodontia_Maximum_Plan2 = value; break;
                                                case 8: OutNetwork_Waiting_Periods_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion


                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region MergeField

                objSlides = objPres.Slides;

                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;

                    if (objSlides[i].SlideNumber == 8 || objSlides[i].SlideNumber == 13 || objSlides[i].SlideNumber == 29 || objSlides[i].SlideNumber == 30)
                    {
                        //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                        for (int j = 1; j <= objShapes.Count; j++)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                // If shape is table then iterate through each row and each column 
                                // and find the attribute name and replace it with respective value
                                if (objShapes[j].Name.ToString().Equals("Dental_Rate_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First Dental Plan Name>>"))
                                            {
                                                txtRange.Replace("<<First Dental Plan Name>>", Dental_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Second Dental Plan Name>>"))
                                            {
                                                txtRange.Replace("<<Second Dental Plan Name>>", Dental_Plan_2);
                                            }
                                        }
                                    }
                                }
                                if (objShapes[j].Name.ToString().Equals("Dental_Plan_1_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Deductible Individual - In>>", InNetwork_Calendar_Year_Deductible_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual- Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Deductible Individual- Out>>", OutNetwork_Calendar_Year_Deductible_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Plan Max - In>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Plan Max - Out>>", OutNetwork_Calendar_Year_Benefit_Maximum_Plan1);
                                            }

                                            if (txtRange.Text.Contains("<<General Plan Info – Preventative Care - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Preventative Care - In>>", InNetwork_Preventive_Care_Waived_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Preventative  Care - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Preventative  Care - Out>>", OutNetwork_Preventive_Care_Waived_Plan1);
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Basic - In>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Basic - In>>", InNetwork_Basic_Services_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Basic - Out>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Basic - Out>>", OutNetwork_Basic_Services_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Major - In>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Major - In>>", InNetwork_Major_Services_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Major - Out>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Major - Out>>", OutNetwork_Major_Services_Plan1);
                                            }

                                            if (txtRange.Text.Contains("<<Orthodontia Services – Orthodontia - In>"))
                                            {
                                                txtRange.Replace("<<Orthodontia Services – Orthodontia - In>>", InNetwork_Orthodontia_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<Orthodontia Services – Orthodontia - Out>>"))
                                            {
                                                txtRange.Replace("<<Orthodontia Services – Orthodontia - Out>>", OutNetwork_Orthodontia_Plan1);
                                            }

                                            if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max - In>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max - In>>", InNetwork_Orthodontia_Maximum_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max - Out>>", OutNetwork_Orthodontia_Maximum_Plan1);
                                            }

                                            if (txtRange.Text.Contains("<<Eligibility – Waiting Period - In>"))
                                            {
                                                txtRange.Replace("<<Eligibility – Waiting Period - In>>", InNetwork_Waiting_Periods_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<Eligibility – Waiting Period- Out>>"))
                                            {
                                                txtRange.Replace("<<Eligibility – Waiting Period- Out>>", OutNetwork_Waiting_Periods_Plan1);
                                            }
                                        }
                                    }
                                }

                                if (objShapes[j].Name.ToString().Equals("Dental_Plan_2_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Deductible Individual - In>>", InNetwork_Calendar_Year_Deductible_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Deductible Individual- Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Deductible Individual- Out>>", OutNetwork_Calendar_Year_Deductible_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Plan Max - In>>", InNetwork_Calendar_Year_Benefit_Maximum_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Annual Plan Max - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Annual Plan Max - Out>>", OutNetwork_Calendar_Year_Benefit_Maximum_Plan2);
                                            }

                                            if (txtRange.Text.Contains("<<General Plan Info – Preventative Care - In>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Preventative Care - In>>", InNetwork_Preventive_Care_Waived_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Preventative  Care - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Preventative  Care - Out>>", OutNetwork_Preventive_Care_Waived_Plan2);
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Basic - In>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Basic - In>>", InNetwork_Basic_Services_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Basic - Out>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Basic - Out>>", OutNetwork_Basic_Services_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Major - In>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Major - In>>", InNetwork_Major_Services_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<Covered Services – Major - Out>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Major - Out>>", OutNetwork_Major_Services_Plan2);
                                            }

                                            if (txtRange.Text.Contains("<<Orthodontia Services – Orthodontia - In>"))
                                            {
                                                txtRange.Replace("<<Orthodontia Services – Orthodontia - In>>", InNetwork_Orthodontia_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<Orthodontia Services – Orthodontia - Out>>"))
                                            {
                                                txtRange.Replace("<<Orthodontia Services – Orthodontia - Out>>", OutNetwork_Orthodontia_Plan2);
                                            }

                                            if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max - In>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max - In>>", InNetwork_Orthodontia_Maximum_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Lifetime Ortho Plan Max - Out>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Lifetime Ortho Plan Max - Out>>", OutNetwork_Orthodontia_Maximum_Plan2);
                                            }

                                            if (txtRange.Text.Contains("<<Eligibility – Waiting Period - In>"))
                                            {
                                                txtRange.Replace("<<Eligibility – Waiting Period - In>>", InNetwork_Waiting_Periods_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<Eligibility – Waiting Period- Out>>"))
                                            {
                                                txtRange.Replace("<<Eligibility – Waiting Period- Out>>", OutNetwork_Waiting_Periods_Plan2);
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                txtFrame = objShapes[j].TextFrame;
                                txtRange = txtFrame.TextRange;
                                if (txtRange.Text.Contains("<<First Dental Summary Name>>"))
                                {
                                    txtRange.Replace("<<First Dental Summary Name>>", Dental_Summary_Plan1);
                                }
                                if (txtRange.Text.Contains("<<Second Dental Summary Name>>"))
                                {
                                    txtRange.Replace("<<Second Dental Summary Name>>", Dental_Summary_Plan2);
                                }
                                if (txtRange.Text.Contains("<<First Dental Carrier and Plan Name>>"))
                                {
                                    //txtRange.Replace("<<First Dental Carrier and Plan Name>>", Dental_Carrier_Plan1 + " " + Dental_Summary_Plan1);
                                    txtRange.Replace("<<First Dental Carrier and Plan Name>>", Dental_Plan_1);
                                }
                                if (txtRange.Text.Contains("<<First Dental Plan Name>>"))
                                {
                                    txtRange.Replace("<<First Dental Plan Name>>", Dental_Plan_1);
                                }
                                if (txtRange.Text.Contains("<<Second Dental Carrier and Plan Name>>"))
                                {
                                    //txtRange.Replace("<<Second Dental Carrier and Plan Name>>", Dental_Carrier_Plan2 + " " + Dental_Summary_Plan2);
                                    txtRange.Replace("<<Second Dental Carrier and Plan Name>>", Dental_Plan_2);
                                }
                                if (txtRange.Text.Contains("<<Second Dental Plan Name>>"))
                                {
                                    txtRange.Replace("<<Second Dental Plan Name>>", Dental_Plan_2);
                                }
                                if (txtRange.Text.Contains("<<Delete_Dental_Heading>>"))
                                {
                                    if (!string.IsNullOrEmpty(Dental_Plan_1))
                                    {
                                        txtRange.Replace("<<Delete_Dental_Heading>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Dental_Heading1>>"))
                                {
                                    if (!string.IsNullOrEmpty(Dental_Plan_2))
                                    {
                                        txtRange.Replace("<<Delete_Dental_Heading1>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Dental>>"))
                                {
                                    if (!string.IsNullOrEmpty(Dental_Plan_1))
                                    {
                                        txtRange.Replace("<<Delete_Dental>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Dental_2>>"))
                                {
                                    if (!string.IsNullOrEmpty(Dental_Plan_2))
                                    {
                                        txtRange.Replace("<<Delete_Dental_2>>", " ");
                                    }
                                }

                                if (txtRange.Text.Contains("<<Vision_Dental_Plans>>"))
                                {
                                    if (!string.IsNullOrEmpty(Dental_Plan_1) || !string.IsNullOrEmpty(Dental_Plan_2))
                                    {
                                        txtRange.Replace("<<Vision_Dental_Plans>>", " ");
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, DataTable CarrierSpecific, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(1, "195");     //General Plan Information – Copay – Examination Deductible
                //HashtableVisionBenefitInNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(2, "194");     //General Plan Information – Benefit Frequency – Examination
                //HashtableVisionBenefitInNetwork.Add(43, "309");     //General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefitInNetwork.Add(42, "122");     //General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefitInNetwork.Add(4, "207");      //General Plan Information – Benefit Frequency – Frames
                //HashtableVisionBenefitInNetwork.Add(5, "195");      //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(3, "507");      //Covered Services – Lenses – Single Vision Lens
                //HashtableVisionBenefitInNetwork.Add(7, "73");       //Covered Services – Lenses – Bifocal Lens
                //HashtableVisionBenefitInNetwork.Add(8, "553");      //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitInNetwork.Add(4, "208");      //Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(5, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitInNetwork.Add(6, "309");     //General Plan Information – Benefit Frequency – Lenses
                HashtableVisionBenefitInNetwork.Add(7, "207");     //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(8, "122");     //General Plan Information – Benefit Frequency – Contacts

                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                string CopayExamination_Plan1 = string.Empty;
                string BenefitFrequency_Examination_Plan1 = string.Empty;
                string Single_Vision_Lenses_Plan1 = string.Empty;
                string Covered_Services_Frames_Plan1 = string.Empty;
                string Medically_Necessary_Plan1 = string.Empty;
                string BenefitFrequency_Lenses_Plan1 = string.Empty;
                string BenefitFrequency_Frames_Plan1 = string.Empty;
                string BenefitFrequency_Contacts_Plan1 = string.Empty;
                string Vision_Carrier_Plan1 = string.Empty;
                string Vision_Summary_Plan1 = string.Empty;

                string CopayExamination_Plan2 = string.Empty;
                string BenefitFrequency_Examination_Plan2 = string.Empty;
                string Single_Vision_Lenses_Plan2 = string.Empty;
                string Covered_Services_Frames_Plan2 = string.Empty;
                string Medically_Necessary_Plan2 = string.Empty;
                string BenefitFrequency_Lenses_Plan2 = string.Empty;
                string BenefitFrequency_Frames_Plan2 = string.Empty;
                string BenefitFrequency_Contacts_Plan2 = string.Empty;
                string Vision_Carrier_Plan2 = string.Empty;
                string Vision_Summary_Plan2 = string.Empty;

                string Vision_Plan_1 = string.Empty;
                string Vision_Plan_2 = string.Empty;

                int count = 1;

                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (count == 1)
                            {
                                Vision_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                                Vision_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Vision_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            else if (count == 2)
                            {
                                Vision_Plan_2 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]; ;
                                Vision_Carrier_Plan2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                                Vision_Summary_Plan2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }

                            # region VisionBenefitTable

                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: CopayExamination_Plan1 = value; break;
                                                case 2: BenefitFrequency_Examination_Plan1 = value; break;
                                                case 3: Single_Vision_Lenses_Plan1 = value; break;
                                                case 4: Covered_Services_Frames_Plan1 = value; break;
                                                case 5: Medically_Necessary_Plan1 = value; break;
                                                case 6: BenefitFrequency_Lenses_Plan1 = value; break;
                                                case 7: BenefitFrequency_Frames_Plan1 = value; break;
                                                case 8: BenefitFrequency_Contacts_Plan1 = value; break;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 1: CopayExamination_Plan2 = value; break;
                                                case 2: BenefitFrequency_Examination_Plan2 = value; break;
                                                case 3: Single_Vision_Lenses_Plan2 = value; break;
                                                case 4: Covered_Services_Frames_Plan2 = value; break;
                                                case 5: Medically_Necessary_Plan2 = value; break;
                                                case 6: BenefitFrequency_Lenses_Plan2 = value; break;
                                                case 7: BenefitFrequency_Frames_Plan2 = value; break;
                                                case 8: BenefitFrequency_Contacts_Plan2 = value; break;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            count++;
                        }
                    }
                }

                // Iterate through each slide for putting the attribute values for respective fields
                #region merge fields

                objSlides = objPres.Slides;

                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    if (objSlides[i].SlideNumber == 8 || objSlides[i].SlideNumber == 14 || objSlides[i].SlideNumber == 31 || objSlides[i].SlideNumber == 32)
                    {
                        //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                        for (int j = 1; j <= objShapes.Count; j++)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                // If shape is table then iterate through each row and each column 
                                // and find the attribute name and replace it with respective value
                                if (objShapes[j].Name.ToString().Equals("Vision_Rate_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First Vision Plan Name>>"))
                                            {
                                                txtRange.Replace("<<First Vision Plan Name>>", Vision_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Second Vision Plan Name>>"))
                                            {
                                                txtRange.Replace("<<Second Vision Plan Name>>", Vision_Plan_2);
                                            }
                                        }
                                    }
                                }
                                #region For Vision Plan 1
                                if (objShapes[j].Name.ToString().Equals("Vision_Plan_1_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Copay – Examination>>"))
                                            {
                                                objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace("<<General Plan Info – Copay – Examination>>", CopayExamination_Plan1);
                                            }
                                            if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains("<<General Plan Info – Ben Freq – Examination>>"))
                                            {
                                                //txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", BenefitFrequency_Examination_Plan1);
                                                if (!string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", " / " + BenefitFrequency_Examination_Plan1.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", BenefitFrequency_Examination_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<General Plan Info – Copay – Examination2>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Copay – Examination2>>", CopayExamination_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Examination2>>"))
                                            {
                                                //txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", BenefitFrequency_Examination_Plan1);
                                                if (!string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", " / " + BenefitFrequency_Examination_Plan1.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", BenefitFrequency_Examination_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Lenses - Single Vision Lens>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Lenses - Single Vision Lens>>", Single_Vision_Lenses_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Lenses>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Single_Vision_Lenses_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " / " + BenefitFrequency_Lenses_Plan1.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Single_Vision_Lenses_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", BenefitFrequency_Lenses_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Frames>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Frames>>", Covered_Services_Frames_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Frames>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Covered_Services_Frames_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " / " + BenefitFrequency_Frames_Plan1.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Covered_Services_Frames_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", BenefitFrequency_Frames_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Contact Lenses – Medically Necessary>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Contact Lenses – Medically Necessary>>", Medically_Necessary_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Contacts>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Medically_Necessary_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " / " + BenefitFrequency_Contacts_Plan1.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Medically_Necessary_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", BenefitFrequency_Contacts_Plan1.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                                #endregion

                                #region For Vision Plan 2

                                if (objShapes[j].Name.ToString().Equals("Vision_Plan_2_Table"))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<General Plan Info – Copay – Examination>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Copay – Examination>>", CopayExamination_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Examination>>"))
                                            {
                                                if (!string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", " / " + BenefitFrequency_Examination_Plan2.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", BenefitFrequency_Examination_Plan2.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<General Plan Info – Copay – Examination2>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Copay – Examination2>>", CopayExamination_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Examination2>>"))
                                            {
                                                if (!string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan1.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", " / " + BenefitFrequency_Examination_Plan2.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(CopayExamination_Plan1.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Examination_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", BenefitFrequency_Examination_Plan2.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Examination2>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Lenses - Single Vision Lens>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Lenses - Single Vision Lens>>", Single_Vision_Lenses_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Lenses>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Single_Vision_Lenses_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " / " + BenefitFrequency_Lenses_Plan2.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Single_Vision_Lenses_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Lenses_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", BenefitFrequency_Lenses_Plan2.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Lenses>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Frames>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Frames>>", Covered_Services_Frames_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Frames>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Covered_Services_Frames_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " / " + BenefitFrequency_Frames_Plan2.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Covered_Services_Frames_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Frames_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", BenefitFrequency_Frames_Plan2.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Frames>>", " ");
                                                }
                                            }

                                            if (txtRange.Text.Contains("<<Covered Services – Contact Lenses – Medically Necessary>>"))
                                            {
                                                txtRange.Replace("<<Covered Services – Contact Lenses – Medically Necessary>>", Medically_Necessary_Plan2);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Ben Freq – Contacts>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Medically_Necessary_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " / " + BenefitFrequency_Contacts_Plan2.Trim());
                                                }
                                                else if (string.IsNullOrEmpty(Medically_Necessary_Plan2.Trim()) && !string.IsNullOrEmpty(BenefitFrequency_Contacts_Plan2.Trim()))
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", BenefitFrequency_Contacts_Plan2.Trim());
                                                }
                                                else
                                                {
                                                    txtRange.Replace("<<General Plan Info – Ben Freq – Contacts>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                                #endregion
                            }
                            else
                            {
                                txtFrame = objShapes[j].TextFrame;
                                txtRange = txtFrame.TextRange;

                                if (txtRange.Text.Contains("<<First Vision Summary Name>>"))
                                {
                                    txtRange.Replace("<<First Vision Summary Name>>", Vision_Summary_Plan1);
                                }
                                if (txtRange.Text.Contains("<<Second Vision Summary Name>>"))
                                {
                                    txtRange.Replace("<<Second Vision Summary Name>>", Vision_Summary_Plan2);
                                }
                                if (txtRange.Text.Contains("<<First Vision Carrier and Plan Name>>"))
                                {
                                    //txtRange.Replace("<<First Vision Carrier and Plan Name>>", Vision_Carrier_Plan1 + " " + Vision_Summary_Plan1);
                                    txtRange.Replace("<<First Vision Carrier and Plan Name>>", Vision_Plan_1);
                                }
                                if (txtRange.Text.Contains("<<First Vision Plan Name>>"))
                                {
                                    txtRange.Replace("<<First Vision Plan Name>>", Vision_Plan_1);
                                }
                                if (txtRange.Text.Contains("<<Second Vision Carrier and Plan Name>>"))
                                {
                                    //txtRange.Replace("<<Second Vision Carrier and Plan Name>>", Vision_Carrier_Plan2 + " " + Vision_Summary_Plan2);
                                    txtRange.Replace("<<Second Vision Carrier and Plan Name>>", Vision_Plan_2);
                                }
                                if (txtRange.Text.Contains("<<Second Vision Plan Name>>"))
                                {
                                    txtRange.Replace("<<Second Vision Plan Name>>", Vision_Plan_2);
                                }
                                if (txtRange.Text.Contains("<<Delete_Vision_Heading>>"))
                                {
                                    if (!string.IsNullOrEmpty(Vision_Plan_1))
                                    {
                                        txtRange.Replace("<<Delete_Vision_Heading>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Vision_Heading1>>"))
                                {
                                    if (!string.IsNullOrEmpty(Vision_Plan_2))
                                    {
                                        txtRange.Replace("<<Delete_Vision_Heading1>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Vision>>"))
                                {
                                    if (!string.IsNullOrEmpty(Vision_Plan_1))
                                    {
                                        txtRange.Replace("<<Delete_Vision>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Delete_Vision_2>>"))
                                {
                                    if (!string.IsNullOrEmpty(Vision_Plan_2))
                                    {
                                        txtRange.Replace("<<Delete_Vision_2>>", " ");
                                    }
                                }
                                if (txtRange.Text.Contains("<<Vision_Dental_Plans>>"))
                                {
                                    if (!string.IsNullOrEmpty(Vision_Plan_1) || !string.IsNullOrEmpty(Vision_Plan_2))
                                    {
                                        txtRange.Replace("<<Vision_Dental_Plans>>", " ");
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ddlClient">ddlClient is used for showing client name in field.</param>
        public void WriteLifeADDToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlClient, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string Benefit_Amt_Employee = string.Empty;
                string Benefit_Amt_Spouse = string.Empty;
                string Benefit_Amt_Children = string.Empty;
                string Life_Carrier_Plan1 = string.Empty;
                string Life_Summary_Plan1 = string.Empty;
                string Life_Plan_1 = string.Empty;

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(2, "517");     //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(3, "102");     //Child(ren)[Benefit Amount] 
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            Life_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            Life_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            Life_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region GroupLifeADDBenifitTable

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Benefit_Amt_Employee = value; break;
                                            case 2: Benefit_Amt_Spouse = value; break;
                                            case 3: Benefit_Amt_Children = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                if (objSlides[i].SlideNumber == 9 || objSlides[i].SlideNumber == 33)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                        {
                                        }
                                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            // If shape is table then iterate through each row and each column 
                                            // and find the attribute name and replace it with respective value
                                            if (objShapes[j].Name.ToString().Equals("Life_ADD_Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<Client Name>>"))
                                                        {
                                                            txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Employee>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Employee>>", Benefit_Amt_Employee);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Spouse>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Spouse>>", Benefit_Amt_Spouse);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Child(ren)>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Child(ren)>>", Benefit_Amt_Children);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First Life AD&D Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First Life AD&D Carrier and Plan Name>>", Life_Carrier_Plan1 + " " + Life_Summary_Plan1);
                                                txtRange.Replace("<<First Life AD&D Carrier and Plan Name>>", Life_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_Life>>"))
                                            {
                                                txtRange.Replace("<<Delete_Life>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_Life_AD&D_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Life_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Delete_Life_AD&D_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Life_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Life_STD_LTD_VolLife_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVoluntaryLifeToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, DataTable CarrierSpecific, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();

                string value = "";
                string Benefit_Amt_Employee = string.Empty;
                string Benefit_Amt_Spouse = string.Empty;
                string Benefit_Amt_Children = string.Empty;
                string Voluntary_Life_Carrier_Plan1 = string.Empty;
                string Voluntary_Life_Summary_Plan1 = string.Empty;
                string Voluntary_Life_Plan_1 = string.Empty;

                #region HashtablHashtableVoluntaryLife

                HashtableVoluntaryLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(2, "516");     //Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(3, "106");     //Child(ren)[Benefit Amount] 
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            Voluntary_Life_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            Voluntary_Life_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            Voluntary_Life_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region VoluntaryLifeADDBenifitTable

                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Benefit_Amt_Employee = value; break;
                                            case 2: Benefit_Amt_Spouse = value; break;
                                            case 3: Benefit_Amt_Children = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;


                                if (objSlides[i].SlideNumber == 9 || objSlides[i].SlideNumber == 34)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                        {
                                        }
                                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            // If shape is table then iterate through each row and each column 
                                            // and find the attribute name and replace it with respective value
                                            if (objShapes[j].Name.ToString().Equals("Voluntary_Life_ADD_Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<General Plan Info – Employee>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Employee>>", Benefit_Amt_Employee);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Spouse>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Spouse>>", Benefit_Amt_Spouse);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Child(ren)>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Child(ren)>>", Benefit_Amt_Children);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First Voluntary Life Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First Voluntary Life Carrier and Plan Name>>", Voluntary_Life_Carrier_Plan1 + " " + Voluntary_Life_Summary_Plan1);
                                                txtRange.Replace("<<First Voluntary Life Carrier and Plan Name>>", Voluntary_Life_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_Voluntary_Life>>"))
                                            {
                                                txtRange.Replace("<<Delete_Voluntary_Life>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_Voluntary_Life_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Voluntary_Life_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Delete_Voluntary_Life_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Voluntary_Life_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Life_STD_LTD_VolLife_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLTDSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableLTD = new Hashtable();

                string value = "";
                string Elimination_Periode = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Definition_Of_Disability = string.Empty;
                string Pre_Existing_Condition_Limit = string.Empty;
                string Disability_Carrier = string.Empty;
                string STD_Summary_Plan1 = string.Empty;
                string STD_Plan_1 = string.Empty;

                #region HashtableLTD
                HashtableLTD.Add(1, "181");     //General Plan Information – Elimination Period
                HashtableLTD.Add(2, "71");      //General Plan Information – Benefit Percentage
                HashtableLTD.Add(3, "374");     //General Plan Information – Monthly Benefit Maximum
                HashtableLTD.Add(4, "141");     //Benefits[Definition of Disability]
                HashtableLTD.Add(5, "449");     //Benefits[Pre-Existing Condition Limitation]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTDBenifitTable
                            STD_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            Disability_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            STD_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LTDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Elimination_Periode = value; break;
                                            case 2: Benefit_Percentage = value; break;
                                            case 3: Monthly_Benefit_Maximum = value; break;
                                            case 4: Definition_Of_Disability = value; break;
                                            case 5: Pre_Existing_Condition_Limit = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                if (objSlides[i].SlideNumber == 9 || objSlides[i].SlideNumber == 35)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                        {
                                        }
                                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            // If shape is table then iterate through each row and each column 
                                            // and find the attribute name and replace it with respective value
                                            if (objShapes[j].Name.ToString().Equals("LTD_Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Elimination Period>>", Elimination_Periode);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Benefit Percentage>>", Benefit_Percentage);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max>>"))
                                                        {
                                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum.Trim()))
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum.Trim() + " / month");
                                                            }
                                                            else
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", " ");
                                                            }

                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Definition of Disability>>", Definition_Of_Disability);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit>>", Pre_Existing_Condition_Limit);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;


                                            if (txtRange.Text.Contains("<<First LTD Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First LTD Carrier and Plan Name>>", Disability_Carrier + " " + STD_Summary_Plan1);
                                                txtRange.Replace("<<First LTD Carrier and Plan Name>>", STD_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<LTD Disability Carrier>>"))
                                            {
                                                txtRange.Replace("<<LTD Disability Carrier>>", Disability_Carrier);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_LTD>>"))
                                            {
                                                txtRange.Replace("<<Delete_LTD>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_LTD_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Disability_Carrier))
                                                {
                                                    txtRange.Replace("<<Delete_LTD_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Disability_Carrier))
                                                {
                                                    txtRange.Replace("<<Life_STD_LTD_VolLife_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP plan</param>
        public void WriteEAPSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableEAP = new Hashtable();

                string value = "";
                string No_Of_Visits = string.Empty;
                string EAP_Plan_Type = string.Empty;
                string EAP_Carrier_Plan1 = string.Empty;
                string EAP_Summary_Plan1 = string.Empty;
                string EAP_Plan1 = string.Empty;
                bool bAssistantOn;

                #region HashtableEAP

                HashtableEAP.Add(1, "384");     //Number of Visit 
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.EAPPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            EAP_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            EAP_Plan_Type = PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString();
                            EAP_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            EAP_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region EAP

                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.EAPPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        //value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        value = dr["value"].ToString() + " " + dr["UOM"].ToString();

                                        switch (key)
                                        {
                                            case 1: No_Of_Visits = value.Trim() + " per person"; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            objSlides = objPres.Slides;

                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //if (mySlide.SlideNumber == 37)
                                if (i == 10 || i == 37)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First EAP Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First EAP Carrier and Plan Name>>", EAP_Carrier_Plan1 + " " + EAP_Summary_Plan1);
                                                txtRange.Replace("<<First EAP Carrier and Plan Name>>", EAP_Plan1);
                                            }
                                            if (txtRange.Text.Contains("<<First EAP Plan Type>>"))
                                            {
                                                txtRange.Replace("<<First EAP Plan Type>>", EAP_Plan_Type);
                                            }
                                            if (txtRange.Text.Contains("<<General Plan Info – Number of Visits>>"))
                                            {
                                                txtRange.Replace("<<General Plan Info – Number of Visits>>", No_Of_Visits);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_EAP>>"))
                                            {
                                                txtRange.Replace("<<Delete_EAP>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_EAP_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(EAP_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Delete_EAP_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(EAP_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<EAP_FSA_HSA_HRA_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint presentation Object</param>
        /// <param name="objPresSet">PowerPoint presentations Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteSTDSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableSTD = new Hashtable();

                string value = "";
                string Elimination_Period_Accident = string.Empty;
                string Elimination_Period_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit_Maximum = string.Empty;
                string Definition_Of_Disability = string.Empty;
                string Pre_Existing_Condition_Limit = string.Empty;
                string Disability_Carrier = string.Empty;
                string STD_Summary_Plan1 = string.Empty;
                string STD_Plan_1 = string.Empty;

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //General Plan Information – Elimination Period - Accident
                HashtableSTD.Add(2, "505");     //General Plan Information – Elimination Period - Sickness
                HashtableSTD.Add(3, "71");      //General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //General Plan Information – Monthly Benefit Maximum
                HashtableSTD.Add(5, "141");     //Benefits[Definition of Disability]
                HashtableSTD.Add(6, "449");     //Benefits[Pre-Existing Condition Limitation]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {

                            #region STDBenifitTable
                            STD_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            Disability_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            STD_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.STDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Elimination_Period_Accident = value; break;
                                            case 2: Elimination_Period_Sickness = value; break;
                                            case 3: Benefit_Percentage = value; break;
                                            case 4: Monthly_Benefit_Maximum = value; break;
                                            case 5: Definition_Of_Disability = value; break;
                                            case 6: Pre_Existing_Condition_Limit = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                if (objSlides[i].SlideNumber == 9 || objSlides[i].SlideNumber == 36)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                        {
                                        }
                                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            // If shape is table then iterate through each row and each column 
                                            // and find the attribute name and replace it with respective value
                                            if (objShapes[j].Name.ToString().Equals("STD_Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period - Accident>>"))
                                                        {
                                                            //txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", Elimination_Period_Accident);
                                                            if (!string.IsNullOrEmpty(Elimination_Period_Sickness.Trim()))
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", Elimination_Period_Accident.Trim() + " / ");
                                                            }
                                                            else
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Elimination Period - Accident>>", " ");
                                                            }
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Elimination Period - Sickness>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Elimination Period - Sickness>>", Elimination_Period_Sickness);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Benefit Percentage>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Benefit Percentage>>", Benefit_Percentage);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Monthly Benefit Max>>"))
                                                        {
                                                            //txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum);
                                                            if (!string.IsNullOrEmpty(Monthly_Benefit_Maximum.Trim()))
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", Monthly_Benefit_Maximum.Trim() + " / week");
                                                            }
                                                            else
                                                            {
                                                                txtRange.Replace("<<General Plan Info – Monthly Benefit Max>>", " ");
                                                            }
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Definition of Disability>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Definition of Disability>>", Definition_Of_Disability);
                                                        }
                                                        if (txtRange.Text.Contains("<<General Plan Info – Pre-Existing Condition Limit>>"))
                                                        {
                                                            txtRange.Replace("<<General Plan Info – Pre-Existing Condition Limit>>", Pre_Existing_Condition_Limit);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First STD Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First STD Carrier and Plan Name>>", Disability_Carrier + " " + STD_Summary_Plan1);
                                                txtRange.Replace("<<First STD Carrier and Plan Name>>", STD_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<STD Disability Carrier>>"))
                                            {
                                                txtRange.Replace("<<STD Disability Carrier>>", Disability_Carrier);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_STD>>"))
                                            {
                                                txtRange.Replace("<<Delete_STD>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_STD_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Disability_Carrier))
                                                {
                                                    txtRange.Replace("<<Delete_STD_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(Disability_Carrier))
                                                {
                                                    txtRange.Replace("<<Life_STD_LTD_VolLife_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP plan</param>
        public void WriteFSASectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DropDownList ddlFSABenefitSummary, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;

                Hashtable HashtableFSA = new Hashtable();

                string value = "";
                string Dependant_Care_Max = string.Empty;
                string Med_Spending_Account_Max_GP = string.Empty;
                string Med_Spending_Account_Max_LP = string.Empty;
                string HSA_Carrier = string.Empty;
                string FSA_Carrier_Plan1 = string.Empty;
                string FSA_Summary_Plan1 = string.Empty;
                string FSA_Plan_1 = string.Empty;

                #region HashHashtableFSAtableEAP

                HashtableFSA.Add(1, "150");     //Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "354");     //Administration Services – Medical Spending
                #endregion


                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HSAPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            HSA_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                    }
                }

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.FSAPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            FSA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            FSA_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            FSA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region FSA

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.FSAPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Dependant_Care_Max = value; break;
                                            case 2:
                                                //if (ddlFSABenefitSummary.SelectedItem.Text.Contains("General"))
                                                //{
                                                //    Med_Spending_Account_Max_GP = value;
                                                //}
                                                //else if (ddlFSABenefitSummary.SelectedItem.Text.Contains("Limited"))
                                                //{
                                                //    Med_Spending_Account_Max_LP = value;
                                                //}
                                                Med_Spending_Account_Max_GP = value;
                                                break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;
                                //objShapes = mySlide.Shapes;

                                //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                for (int j = 1; j <= objShapes.Count; j++)
                                {
                                    if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                    {
                                    }
                                    else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                    {
                                        // If shape is table then iterate through each row and each column 
                                        // and find the attribute name and replace it with respective value
                                        if (objShapes[j].Name.ToString().Equals("FSA_VS_HSA_Table"))
                                        {
                                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                            {
                                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                {
                                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                    txtRange = txtFrame.TextRange;

                                                    if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>"))
                                                    {
                                                        txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>", Med_Spending_Account_Max_GP.Trim());
                                                    }
                                                    if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>"))
                                                    {
                                                        txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>", Med_Spending_Account_Max_GP.Trim());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        txtFrame = objShapes[j].TextFrame;
                                        txtRange = txtFrame.TextRange;

                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>"))
                                        {
                                            txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>", Med_Spending_Account_Max_GP.Trim());
                                        }
                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>"))
                                        {
                                            txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>", Med_Spending_Account_Max_GP.Trim());
                                        }
                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Dependent  Care – Max>>"))
                                        {
                                            txtRange.Replace("<<Section 125 – Admin Services – Dependent  Care – Max>>", Dependant_Care_Max.Trim());
                                        }
                                        if (txtRange.Text.Contains("<<First FSA Carrier and Plan Name>>"))
                                        {
                                            //txtRange.Replace("<<First FSA Carrier and Plan Name>>", FSA_Carrier_Plan1 + " " + FSA_Summary_Plan1);
                                            txtRange.Replace("<<First FSA Carrier and Plan Name>>", FSA_Plan_1);
                                        }
                                        if (txtRange.Text.Contains("<<HSA Carrier>>"))
                                        {
                                            txtRange.Replace("<<HSA Carrier>>", HSA_Carrier);
                                        }
                                        if (txtRange.Text.Contains("<<FSA_HSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_HSA_PLAN>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<<FSA_PLAN>>"))
                                        {
                                            txtRange.Replace("<<FSA_PLAN>>", " ");
                                        }
                                        if (txtRange.Text.Contains("<<Delete_FSA_Heading>>"))
                                        {
                                            if (!string.IsNullOrEmpty(FSA_Carrier_Plan1))
                                            {
                                                txtRange.Replace("<<Delete_FSA_Heading>>", " ");
                                            }
                                        }
                                        if (txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>"))
                                        {
                                            if (!string.IsNullOrEmpty(FSA_Carrier_Plan1))
                                            {
                                                txtRange.Replace("<<EAP_FSA_HSA_HRA_Plans>>", " ");
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, DataSet ProductDS, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();
                int DentalCount = 0;
                int VisionCount = 0;
                int DentalPlanCount = 0;
                int VisionPlanCount = 0;
                string Frequency_Of_Contribution = string.Empty;
                string Frequency_Of_Contribution_Med = string.Empty;
                string Frequency_Of_Contribution_Dental = string.Empty;
                string Frequency_Of_Contribution_Vision = string.Empty;

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {

                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    //PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    //PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    //PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    //PremiumTable.Columns.Add("summaryname", typeof(string));
                    //PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    //PremiumTable.Columns.Add("contributionid", typeof(string));
                    //PremiumTable.Columns.Add("rateid", typeof(string));
                    //PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("contributionDescription", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                premium_row_counter++;
                            }
                        }
                    }

                    #region Commented Rate Code
                    /*
                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        Frequency_Of_Contribution = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }
                                }
                                premium_row_counter++;
                            }
                        }
                    }
                    */
                    #endregion

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);

                    // The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    for (int k = 0; k < dt.Rows.Count; k++)
                    {
                        if (Convert.ToDecimal(dt.Rows[k]["contributioncost"]) == 0)
                        {
                            dt.Rows[k].Delete();
                            k = k - 1;
                        }
                    }
                    PremiumTable = dt;

                    if (Frequency_Of_Contribution == "Bi_Weekly_26_or_yr")
                    {
                        Frequency_Of_Contribution = "Bi-Weekly (26 Per Year) Cost";
                    }

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Frequency_Of_Contribution_Med = Frequency_Of_Contribution;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }
                        }
                        if (index == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Frequency_Of_Contribution_Dental = Frequency_Of_Contribution;
                            DentalPlanCount = 1;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            DentalPlanCount = 2;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Frequency_Of_Contribution_Vision = Frequency_Of_Contribution;
                            VisionPlanCount = 1;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            VisionPlanCount = 2;
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee"))
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                objSlides = objPres.Slides;
                // Iterate through each slide for putting the attribute values for respective fields
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    if (objSlides[i].SlideNumber == 12 || objSlides[i].SlideNumber == 13 || objSlides[i].SlideNumber == 14)
                    {
                        //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                        for (int j = 1; j <= objShapes.Count; j++)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                if (objShapes[j].Name.ToString().Equals("Medical_Rate_Table"))
                                {
                                    int MediCalTableRowCounter = 2;
                                    int kl = 0;
                                    for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
                                    {
                                        if (kl > 0)
                                        {
                                            objShapes[j].Table.Rows.Add();
                                        }
                                        objShapes[j].Table.Cell(MediCalTableRowCounter, 1).Shape.TextFrame.TextRange.Text = PremiumTableWriteMedical.Rows[d][0].ToString();
                                        objShapes[j].Table.Cell(MediCalTableRowCounter, 2).Shape.TextFrame.TextRange.Text = PremiumTableWriteMedical.Rows[d][1].ToString();
                                        objShapes[j].Table.Cell(MediCalTableRowCounter, 3).Shape.TextFrame.TextRange.Text = PremiumTableWriteMedical.Rows[d][2].ToString();
                                        MediCalTableRowCounter++;
                                        kl++;
                                    }
                                }
                                if (objShapes[j].Name.ToString().Equals("Dental_Rate_Table"))
                                {
                                    int DentalTableRowCounter = 2;
                                    int kl = 0;
                                    for (int d = 0; d < PremiumTableWriteDental.Rows.Count; d++)
                                    {
                                        if (kl > 0)
                                        {
                                            objShapes[j].Table.Rows.Add();
                                        }
                                        objShapes[j].Table.Cell(DentalTableRowCounter, 1).Shape.TextFrame.TextRange.Text = PremiumTableWriteDental.Rows[d][0].ToString();
                                        objShapes[j].Table.Cell(DentalTableRowCounter, 2).Shape.TextFrame.TextRange.Text = PremiumTableWriteDental.Rows[d][1].ToString();
                                        objShapes[j].Table.Cell(DentalTableRowCounter, 3).Shape.TextFrame.TextRange.Text = PremiumTableWriteDental.Rows[d][2].ToString();
                                        DentalTableRowCounter++;
                                        kl++;
                                    }

                                    if (DentalPlanCount == 1)
                                    {
                                        objShapes[j].Table.Columns[3].Delete();
                                        objShapes[j].Table.Columns[2].Width = 2 * objShapes[j].Table.Columns[2].Width;
                                    }
                                }
                                if (objShapes[j].Name.ToString().Equals("Vision_Rate_Table"))
                                {
                                    int VisionTableRowCounter = 2;
                                    int kl = 0;
                                    for (int d = 0; d < PremiumTableWriteVision.Rows.Count; d++)
                                    {
                                        if (kl > 0)
                                        {
                                            objShapes[j].Table.Rows.Add();
                                        }
                                        objShapes[j].Table.Cell(VisionTableRowCounter, 1).Shape.TextFrame.TextRange.Text = PremiumTableWriteVision.Rows[d][0].ToString();
                                        objShapes[j].Table.Cell(VisionTableRowCounter, 2).Shape.TextFrame.TextRange.Text = PremiumTableWriteVision.Rows[d][1].ToString();
                                        objShapes[j].Table.Cell(VisionTableRowCounter, 3).Shape.TextFrame.TextRange.Text = PremiumTableWriteVision.Rows[d][2].ToString();
                                        VisionTableRowCounter++;
                                        kl++;
                                    }

                                    if (VisionPlanCount == 1)
                                    {
                                        objShapes[j].Table.Columns[3].Delete();
                                        objShapes[j].Table.Columns[2].Width = 2 * objShapes[j].Table.Columns[2].Width;
                                    }
                                }
                            }
                            else
                            {
                                if (objShapes[j].TextFrame.TextRange.Text.Contains("<<Frequency of Contributions_Med>>"))
                                {
                                    objShapes[j].TextFrame.TextRange.Replace("<<Frequency of Contributions_Med>>", Frequency_Of_Contribution_Med);
                                }
                                if (objShapes[j].TextFrame.TextRange.Text.Contains("<<Frequency of Contributions_Dental>>"))
                                {
                                    objShapes[j].TextFrame.TextRange.Replace("<<Frequency of Contributions_Dental>>", Frequency_Of_Contribution_Dental);
                                }
                                if (objShapes[j].TextFrame.TextRange.Text.Contains("<<Frequency of Contributions_Vision>>"))
                                {
                                    objShapes[j].TextFrame.TextRange.Replace("<<Frequency of Contributions_Vision>>", Frequency_Of_Contribution_Vision);
                                }
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteHSAToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HSABenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlClient, DropDownList ddlFSANoOfPlan, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                Hashtable HashtableHSABenifit = new Hashtable();

                string value = "";
                string Max_Annual_Contribution_Individual = string.Empty;
                string Max_Annual_Contribution_Family = string.Empty;
                string HSA_Carrier = string.Empty;
                string HSA_Summary_Plan1 = string.Empty;
                string HSA_Plan_1 = string.Empty;

                #region HashtablHashtableHSA

                HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HSAPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            HSA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            HSA_Carrier = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            HSA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region HSABenifitTable

                            foreach (int key in HashtableHSABenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSABenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual = value; break;
                                            case 2: Max_Annual_Contribution_Family = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            objSlides = objPres.Slides;
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                objShapes = objSlides[i].Shapes;
                                //objShapes = mySlide.Shapes;


                                if (objSlides[i].SlideNumber == 10 || objSlides[i].SlideNumber == 16 || objSlides[i].SlideNumber == 24 || objSlides[i].SlideNumber == 25 || objSlides[i].SlideNumber == 26 || objSlides[i].SlideNumber == 27 || objSlides[i].SlideNumber == 38 || objSlides[i].SlideNumber == 40 || objSlides[i].SlideNumber == 41 || objSlides[i].SlideNumber == 42)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture)
                                        {
                                        }
                                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                            // If shape is table then iterate through each row and each column 
                                            // and find the attribute name and replace it with respective value
                                            if (objShapes[j].Name.ToString().Equals("Medical_Plan_Table_1"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<Health Saving Account Plan -Employer Contributions –Individual>>"))
                                                        {
                                                            //txtRange.Replace("<<General Plan Info – Max Annual Contribution/Individual>>", Max_Annual_Contribution_Individual);
                                                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual.Trim()))
                                                            {
                                                                txtRange.Replace("<<Health Saving Account Plan -Employer Contributions –Individual>>", Max_Annual_Contribution_Individual.Trim() + " Individual Max");
                                                            }
                                                            else
                                                            {
                                                                txtRange.Replace("<<Health Saving Account Plan -Employer Contributions –Individual>>", " ");
                                                            }
                                                        }
                                                        if (txtRange.Text.Contains("<<Health Saving Account Plan - Employer Contributions –Family>>"))
                                                        {
                                                            //txtRange.Replace("<<General Plan Info – Max Annual Contribution/Family>>", Max_Annual_Contribution_Family);
                                                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual.Trim()) && !string.IsNullOrEmpty(Max_Annual_Contribution_Family.Trim()))
                                                            {
                                                                txtRange.Replace("<<Health Saving Account Plan - Employer Contributions –Family>>", " / " + Max_Annual_Contribution_Family.Trim() + " Family Max");
                                                            }
                                                            else if (string.IsNullOrEmpty(Max_Annual_Contribution_Individual.Trim()) && !string.IsNullOrEmpty(Max_Annual_Contribution_Family.Trim()))
                                                            {
                                                                txtRange.Replace("<<Health Saving Account Plan - Employer Contributions –Family>>", Max_Annual_Contribution_Family.Trim() + " Family Max");
                                                            }
                                                            else
                                                            {
                                                                txtRange.Replace("<<Health Saving Account Plan - Employer Contributions –Family>>", " ");
                                                            }
                                                        }
                                                        if (txtRange.Text.Contains("<<Client Name>>"))
                                                        {
                                                            txtRange.Replace("<<Client Name>>", ddlClient.SelectedItem.Text.ToString());
                                                        }
                                                    }
                                                }
                                            }
                                            if (objShapes[j].Name.ToString().Equals("FSA_VS_HSA_Table"))
                                            {
                                                for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                                {
                                                    for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                                    {
                                                        txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                                        txtRange = txtFrame.TextRange;

                                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>"))
                                                        {
                                                            if (ddlFSANoOfPlan.SelectedIndex == 0)
                                                            {
                                                                txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_GP>>", " ");
                                                            }
                                                        }
                                                        if (txtRange.Text.Contains("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>"))
                                                        {
                                                            if (ddlFSANoOfPlan.SelectedIndex == 0)
                                                            {
                                                                txtRange.Replace("<<Section 125 – Admin Services – Med Spending Account – Max_LP>>", " ");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First HSA Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First HSA Carrier and Plan Name>>", HSA_Carrier + " " + HSA_Summary_Plan1);
                                                txtRange.Replace("<<First HSA Carrier and Plan Name>>", HSA_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<HSA Carrier>>"))
                                            {
                                                txtRange.Replace("<<HSA Carrier>>", HSA_Carrier);
                                            }
                                            if (txtRange.Text.Contains("<<HSA_PLAN>>"))
                                            {
                                                txtRange.Replace("<<HSA_PLAN>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<FSA_HSA_PLAN>>"))
                                            {
                                                txtRange.Replace("<<FSA_HSA_PLAN>>", " ");
                                            }
                                            if (txtRange.Text.Contains("<<Delete_HSA_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(HSA_Carrier))
                                                {
                                                    txtRange.Replace("<<Delete_HSA_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(HSA_Carrier))
                                                {
                                                    txtRange.Replace("<<EAP_FSA_HSA_HRA_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        public void DeleteUnwantedSectionFromPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            Microsoft.Office.Interop.PowerPoint.Shape oShape = null;
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                #region merge fields
                bool isShapeDeleted = false;
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)

                objSlides = objPres.Slides;
                for (int sldNum = 1; sldNum <= objSlides.Count; sldNum++)
                {
                    //mySlide = objPres.Slides[sldNum];
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[sldNum].Shapes;

                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                    for (int shp = 1; shp <= objShapes.Count; shp++)
                    {
                        oShape = objShapes[shp];

                        isShapeDeleted = false;
                        if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoGroup || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoPicture || oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            //if (sldNum == 12 || sldNum == 13 || sldNum == 14)
                            //{
                            if (oShape.Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                if (oShape.Name.ToString().Equals("Medical_Rate_Table") || oShape.Name.ToString().Equals("Dental_Rate_Table") || oShape.Name.ToString().Equals("Vision_Rate_Table"))
                                {
                                    txtFrame = oShape.Table.Cell(2, 1).Shape.TextFrame;
                                    txtRange = txtFrame.TextRange;
                                    if (string.IsNullOrEmpty(txtRange.Text))
                                    {
                                        objSlides[sldNum].Delete();
                                        sldNum = sldNum - 1;
                                        break;
                                    }
                                }
                            }
                            //}
                        }
                        else
                        {
                            txtFrame = objShapes[shp].TextFrame;
                            txtRange = txtFrame.TextRange;

                            if (txtRange.Text.Contains("<<Delete_Dental_Heading>>") || txtRange.Text.Contains("<<Delete_Dental_Heading1>>") || txtRange.Text.Contains("<<Delete_Vision_Heading>>") || txtRange.Text.Contains("<<Delete_Vision_Heading1>>") || txtRange.Text.Contains("<<Delete_Life_AD&D_Heading>>") || txtRange.Text.Contains("<<Delete_STD_Heading>>") || txtRange.Text.Contains("<<Delete_LTD_Heading>>") || txtRange.Text.Contains("<<Delete_Voluntary_Life_Heading>>") || txtRange.Text.Contains("<<Delete_EAP_Heading>>") || txtRange.Text.Contains("<<Delete_FSA_Heading>>") || txtRange.Text.Contains("<<Delete_HSA_Heading>>") || txtRange.Text.Contains("<<Delete_HRA_Heading>>"))
                            {
                                oShape.Delete();
                                isShapeDeleted = true;
                                shp = shp - 1;
                            }

                            if (isShapeDeleted == false)
                            {
                                if (txtRange.Text.Contains("<<Delete_Dental>>") || txtRange.Text.Contains("<<Delete_Dental_2>>") || txtRange.Text.Contains("<<Delete_Vision>>") || txtRange.Text.Contains("<<Delete_Vision_2>>") || txtRange.Text.Contains("<<Delete_Life>>") || txtRange.Text.Contains("<<Delete_Voluntary_Life>>") || txtRange.Text.Contains("<<Delete_LTD>>") || txtRange.Text.Contains("<<Delete_STD>>") || txtRange.Text.Contains("<<Delete_EAP>>") || txtRange.Text.Contains("<<FSA_HSA_PLAN>>") || txtRange.Text.Contains("<<FSA_PLAN>>") || txtRange.Text.Contains("<<HSA_PLAN>>") || txtRange.Text.Contains("<<Other_Plans>>") || txtRange.Text.Contains("<<Vision_Dental_Plans>>") || txtRange.Text.Contains("<<Life_STD_LTD_VolLife_Plans>>") || txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>"))
                                {
                                    //mySlide.Delete();
                                    objSlides[sldNum].Delete();
                                    sldNum = sldNum - 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oShape != null)
                {
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(oShape) > 0) ;
                    oShape = null;
                }
            }
        }

        public void UpdateOtherPlansToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DropDownList ddlDentalNoOfPlan, DropDownList ddlVisionNoOfPlan, DropDownList ddlLifeADDNoOfPlan, DropDownList ddlVoluntaryLifeADDNoOfPlan, DropDownList ddlLTDNoOfPlan, DropDownList ddlSTDNoOfPlan, DropDownList ddlEAPNoOfPlan, DropDownList ddlFSANoOfPlan, DropDownList ddlHSANoOfPlan, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                bool isOtherPlanSelected = false;
                bool isDental_Vision_PlanSelected = false;
                #region merge fields
                objSlides = objPres.Slides;
                //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                for (int i = 1; i <= objSlides.Count; i++)
                {
                    //objShapes = mySlide.Shapes;
                    objShapes = objSlides[i].Shapes;

                    if (objSlides[i].SlideNumber == 28)
                    {
                        //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                        for (int j = 1; j <= objShapes.Count; j++)
                        {

                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                            {
                                txtFrame = objShapes[j].TextFrame;
                                txtRange = txtFrame.TextRange;

                                if (objShapes[j].Name == "Selected_Plan_List_Title")
                                {
                                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = "Dental";
                                        isOtherPlanSelected = true;
                                        isDental_Vision_PlanSelected = true;
                                    }
                                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "Vision";
                                        isOtherPlanSelected = true;
                                        isDental_Vision_PlanSelected = true;
                                    }
                                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "Life/AD&D";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "Voluntary Life";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "LTD";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "STD";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "EAP";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "FSA";
                                        isOtherPlanSelected = true;
                                    }
                                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                                    {
                                        txtRange.Text = txtRange.Text + "\n" + "HSA";
                                        isOtherPlanSelected = true;
                                    }
                                }
                            }
                            else
                            {
                                txtFrame = objShapes[j].TextFrame;
                                txtRange = txtFrame.TextRange;

                                if (objSlides[i].SlideNumber == 28)
                                {
                                    if (isOtherPlanSelected == true)
                                    {
                                        if (txtRange.Text.Contains("<<Other_Plans>>"))
                                        {
                                            txtRange.Replace("<<Other_Plans>>", " ");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="objPres">PowerPoint Object</param>
        /// <param name="objPresSet">PowerPoint Presentation Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HRABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA plan</param>
        public void WriteHRASectionToPowerPointTemplate1(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                objSlides = null;
                objShapes = null;
                txtFrame = null;
                txtRange = null;

                ConstantValue cv = new ConstantValue();

                int count = 1;
                DataRow[] foundRows = null;

                string value = "";
                string No_Of_Visits = string.Empty;
                string HRA_Carrier_Plan1 = string.Empty;
                string HRA_Summary_Plan1 = string.Empty;
                string HRA_Plan_1 = string.Empty;
                bool bAssistantOn;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.HRAPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            HRA_Plan_1 = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            HRA_Carrier_Plan1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            HRA_Summary_Plan1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();

                            #region merge fields
                            // Iterate through each slide for putting the attribute values for respective fields
                            //foreach (Microsoft.Office.Interop.PowerPoint.Slide mySlide in objPres.Slides)
                            objSlides = objPres.Slides;

                            for (int i = 1; i <= objSlides.Count; i++)
                            {
                                //objShapes = mySlide.Shapes;
                                objShapes = objSlides[i].Shapes;

                                //if (mySlide.SlideNumber == 10)
                                if (i == 10)
                                {
                                    //foreach (Microsoft.Office.Interop.PowerPoint.Shape oShape in objShapes)
                                    for (int j = 1; j <= objShapes.Count; j++)
                                    {
                                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                                        {
                                        }
                                        else
                                        {
                                            txtFrame = objShapes[j].TextFrame;
                                            txtRange = txtFrame.TextRange;

                                            if (txtRange.Text.Contains("<<First HRA Carrier and Plan Name>>"))
                                            {
                                                //txtRange.Replace("<<First HRA Carrier and Plan Name>>", HRA_Carrier_Plan1 + " " + HRA_Summary_Plan1);
                                                txtRange.Replace("<<First HRA Carrier and Plan Name>>", HRA_Plan_1);
                                            }
                                            if (txtRange.Text.Contains("<<Delete_HRA_Heading>>"))
                                            {
                                                if (!string.IsNullOrEmpty(HRA_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<Delete_HRA_Heading>>", " ");
                                                }
                                            }
                                            if (txtRange.Text.Contains("<<EAP_FSA_HSA_HRA_Plans>>"))
                                            {
                                                if (!string.IsNullOrEmpty(HRA_Carrier_Plan1))
                                                {
                                                    txtRange.Replace("<<EAP_FSA_HSA_HRA_Plans>>", " ");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}