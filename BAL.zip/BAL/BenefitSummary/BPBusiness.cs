﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.DAL;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using System.IO;
using System.Reflection;
using System.Data.SqlClient;
using System.Text;
using System.Collections;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.BPTimeLine;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class BPBusiness
    {

        BPSummary bp = new BPSummary();
        DBHelper DB_helper = new DBHelper();

        /// <summary>
        /// Get Office name from datadase BPPortal.
        /// </summary>
        /// <returns>Office name</returns>
        public DataTable GetOfficeList()
        {
            try
            {
                bp.Office = DB_helper.ExecProcedure("GetOfficeData", null);//("select Office_name from dbo.BROKER_OFFICE");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.Office;
        }


        /// <summary>
        /// Get Office State name from datadase BPPortal.
        /// </summary>
        /// <returns>Office name</returns>
        public DataTable GetOfficeStateList()
        {
            try
            {
                bp.OfficeState = DB_helper.ExecProcedure("GetOfficeStateData", null);//("select Office_State from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.OfficeState;
        }

        public DataTable StateListforClientAgreement()
        {
            try
            {
                bp.OfficeState = DB_helper.ExecProcedure("SP_GetStateList", null);//("select Office_State from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.OfficeState;
        }

        // Added by Mahesh for P&C Client Agreement 
        public DataTable StateListforPCClientAgreement()
        {
            try
            {
                bp.OfficeState = DB_helper.ExecProcedure("SP_PC_GetStateList", null);//("select Office_State from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.OfficeState;
        }


        /// <summary>
        /// Get Office City name from datadase BPPortal.
        /// </summary>
        /// <returns>Office name</returns>
        public DataTable GetOfficeCityList(string State)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@State", SqlDbType.NVarChar, 100) };
                parameters[0].Value = State;
                bp.OfficeCity = DB_helper.ExecProcedure("GetOfficeCityData", parameters);//("select Office_City using selected state from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.OfficeCity;
        }

        /// <summary>
        /// Get Office City name from datadase BPPortal.
        /// </summary>
        /// <returns>Office name</returns>
        public DataTable GetOfficeAddress(string City, string BPOffice, string OfficeStreetAddress)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@City", SqlDbType.NVarChar, 100), new SqlParameter("@BP_Office_Name", SqlDbType.NVarChar, 300), new SqlParameter("@OfficeStreetAddress", SqlDbType.NVarChar, 300) };
                parameters[0].Value = City;
                parameters[1].Value = BPOffice;
                parameters[2].Value = OfficeStreetAddress;
                bp.OfficeAddress = DB_helper.ExecProcedure("GetOfficeAddressData", parameters);//("select Office_City using selected state from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.OfficeAddress;
        }

        /// <summary>
        /// Get IRC details from datadase BPPortal.
        /// </summary>
        /// <returns>IRC Tables</returns>
        public DataTable GetIRCList(string CalendarYear)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@CalendarYear", SqlDbType.NVarChar, 100) };
                parameters[0].Value = CalendarYear;
                bp.IRC = DB_helper.ExecProcedure("GetIRCDataByCalendarYear", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.IRC;
        }

        /// <summary>
        /// Get CarrierSpecific from datadase BPPortal.
        /// </summary>
        /// <returns>CarrierSpecific</returns>
        public DataTable GetCarrierSpecific()//(string CarrierName)
        {
            try
            {

                bp.CarrierSpecific = DB_helper.ExecProcedure("GetCarrierByBenefitPointCarrierName-Dev", null);//,parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.CarrierSpecific;
        }

        /// <summary>
        /// Get PlanTypeSpecific from datadase BPPortal.
        /// </summary>
        /// <returns>PlanTypeSpecific</returns>
        public DataTable GetPlanTypeSpecific()//(string PlanType)
        {
            try
            {

                bp.PlanTypeSpecific = DB_helper.ExecProcedure("GetPlanTypeDetailsByPlanTypeName-Dev", null);//, parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.PlanTypeSpecific;
        }

        /// <summary>
        /// Get Employee information from datadase BPPortal.
        /// </summary>
        /// <param name="EmpTypeId">EmpTypeId of selected medical Plan</param>
        /// <returns>Employee Data</returns>
        public DataTable GetEmployeeData(string ClientID) //EmpTypeId)
        {

            try
            {
                SqlParameter[] parameters = { new SqlParameter("@CLIENTID ", SqlDbType.NVarChar, 100) };
                parameters[0].Value = ClientID;
                bp.Employee = DB_helper.ExecProcedure("GetEmployeeeData", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.Employee;
        }

        /// <summary>
        /// Get BRC
        /// </summary>
        /// <returns>BRC</returns>
        public List<BRC> GetBRC()
        {
            List<BRC> BRCList = new List<BRC>();
            DataTable dtBRC = new DataTable();

            try
            {
                dtBRC = DB_helper.ExecProcedure("GetBRCData", null);

                foreach (DataRow dr in dtBRC.Rows)
                {
                    BRC br = new BRC();
                    br.BRCId = int.Parse(dr["BRCID"].ToString());
                    br.BRCName = dr["BRCName"].ToString();
                    br.BRCLocation = dr["BRCLocation"].ToString();
                    br.BRCDayHours = dr["BenefitResourceCenterDaysHours"].ToString();
                    br.BRCPhone = dr["Phone"].ToString();
                    br.BRCEmail = dr["Email"].ToString();
                    br.BRCFax = dr["Fax"].ToString();
                    BRCList.Add(br);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return BRCList;
        }


        /// <summary>
        /// Get BRC Region
        /// </summary>
        /// <returns>BRC</returns>
        public List<BRC> GetBRC_Region()
        {
            List<BRC> BRC_RegionList = new List<BRC>();
            DataTable dtBRC_Region = new DataTable();

            try
            {
                dtBRC_Region = DB_helper.ExecProcedure("GetBRC_Region_Data", null);

                foreach (DataRow dr in dtBRC_Region.Rows)
                {
                    BRC br = new BRC();
                    br.BRC_Region_Id = int.Parse(dr["BRC_Region_ID"].ToString());
                    br.BRCId = int.Parse(dr["BRCID"].ToString());
                    br.BRC_Region_Desc = Convert.ToString(dr["BRC_REGION_DESC"].ToString());
                    br.BRCName = Convert.ToString(dr["BRCName"].ToString());
                    br.BRCLocation = Convert.ToString(dr["BRCLocation"].ToString());
                    br.BRCDayHours = Convert.ToString(dr["BenefitResourceCenterDaysHours"].ToString());
                    br.BRCPhone = Convert.ToString(dr["Phone"].ToString());
                    br.BRCEmail = Convert.ToString(dr["Email"].ToString());
                    br.BRCFax = Convert.ToString(dr["Fax"].ToString());
                    BRC_RegionList.Add(br);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return BRC_RegionList;
        }

        //Added By Vaibhav For Flyers V2 written by Sanchari
        public List<BRCData> GetBRCDetails(string officeName)
        {
            List<BRCData> BRC_List = new List<BRCData>();
            DataTable dtBRC_Region = new DataTable();

            try
            {
                SqlParameter[] parameters = { new SqlParameter("@BrcOffice", SqlDbType.NVarChar, 100) };
                parameters[0].Value = officeName;

                dtBRC_Region = DB_helper.ExecProcedure("GetBRCDetails", parameters);

                foreach (DataRow dr in dtBRC_Region.Rows)
                {
                    BRCData br = new BRCData();
                    //br.BRC_Region_Id = int.Parse(dr["BRC_Region_ID"].ToString());
                    br.BRCId = int.Parse(dr["BRCID"].ToString());
                    //br.BRC_Region_Desc = Convert.ToString(dr["BRC_REGION_DESC"].ToString());
                    br.BRCName = Convert.ToString(dr["BRCName"].ToString());
                    br.BRCLocation = Convert.ToString(dr["BRCLocation"].ToString());
                    br.BRCDayHours = Convert.ToString(dr["BenefitResourceCenterDaysHours"].ToString());
                    br.BRCPhone = Convert.ToString(dr["Phone"].ToString());
                    br.BRCEmail = Convert.ToString(dr["Email"].ToString());
                    br.BRCFax = Convert.ToString(dr["Fax"].ToString());
                    br.BRCTimezone = Convert.ToString(dr["BRCTimezone"].ToString());
                    BRC_List.Add(br);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return BRC_List;
        }

        /// <summary>
        ///Find account list from  BP_BrokerConnectV4 web service using findAccounts webmethod.
        /// </summary>
        /// <param name="Selectedindex">To Find active or dactive or all account.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <param name="txtsearch">To find perticular client.</param>
        /// <returns>List of Account</returns>   

        public List<Account> FindAccounts(int Selectedindex, string SessionId, string txtsearch)
        {

            List<Account> AccountList = new List<Account>();
            try
            {

                BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

                BP_BrokerConnectV4.AccountSearchCriteria new_account_search = new BP_BrokerConnectV4.AccountSearchCriteria();

                BP_BrokerConnectV4.AccountSummary[] new_account_summary = new BP_BrokerConnectV4.AccountSummary[0];

                BP_BrokerConnectV4.AccountClassificationType[] Search_Type = new BP_BrokerConnectV4.AccountClassificationType[1];

                Search_Type[0] = BP_BrokerConnectV4.AccountClassificationType.Group;

                new_account_search.accountClassifications = Search_Type;
                new_account_search.accountNameMatch = txtsearch;
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;

                new_account_summary = new_connection.findAccounts(new_account_search);
                int i = 0;
                if (new_account_summary != null)
                {
                    foreach (BP_BrokerConnectV4.AccountSummary item in new_account_summary)
                    {
                        Account acc = new Account();

                        acc.AccountId = item.accountID;
                        acc.AccountName = item.accountName.ToString();

                        if (Selectedindex == 0)
                        {
                            if (item.active == true)
                            {
                                AccountList.Add(acc);
                            }

                        }
                        else if (Selectedindex == 1)
                        {
                            if (item.active == false)
                            {
                                AccountList.Add(acc);
                            }

                        }
                        else if (Selectedindex == 2)
                        {

                            AccountList.Add(acc);


                        }
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return AccountList;
        }

        /// <summary>
        /// Find product list from  BP_BrokerConnectV4 web service using findProducts webmethod.
        /// </summary>
        /// <param name="AccountId">To Find plan for selected account</param>
        /// <param name="PlanType">To Find plan for selected plantype</param>
        /// <param name="LOC">To Find plan for selected plantype</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of Product i.e Plan</returns>

        public List<Plan> FindPlans(int AccountId, string PlanType, string LOC, string SessionId, string SummaryName = "")
        {
            List<Plan> PlanList = new List<Plan>();
            try
            {

                BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

                BP_BrokerConnectV4.ProductSearchCriteria new_product_search = new BP_BrokerConnectV4.ProductSearchCriteria();
                BP_BrokerConnectV4.ProductSummary[] new_product_summary = new BP_BrokerConnectV4.ProductSummary[0];
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


                SIH.sessionId = SessionId;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;

                new_product_search = new BP_BrokerConnectV4.ProductSearchCriteria();
                new_product_search.accountID = AccountId;

                new_product_summary = new_connection.findProducts(new_product_search);



                if (new_product_summary != null)
                {

                    int oldProductId = 0;
                    foreach (BP_BrokerConnectV4.ProductSummary item in new_product_summary)
                    {
                        Plan p = new Plan();

                        p.ProductId = item.productID;
                        p.UsiProductName = item.name;
                        if (SummaryName == "EnrollmentSummary")
                        {
                            p.ProductName = item.productTypeDescription.ToString() + " - " + item.carrierName + " - " + item.policyNumber;
                        }
                        else if (SummaryName == "RFPReport")
                        {
                            p.ProductName = item.name.ToString() + " | " + item.carrierName + " | " + item.effectiveAsOf.ToShortDateString();// Added by Kiran for spacing
                        }
                        else if (SummaryName == "MedicalLOCTemplate")
                        {
                            p.ProductName = item.productTypeDescription.ToString() + " | " + item.name.ToString() + " | " + item.carrierName + " | " + item.effectiveAsOf.ToShortDateString();// Added Vaibhav
                        }
                        else
                        {
                            p.ProductName = item.name.ToString() + "|" + item.carrierName + "|" + item.effectiveAsOf.ToShortDateString();
                        }
                        p.CarrierId = item.carrierID;
                        p.CarrierName = item.carrierName;
                        p.RenewalDate = item.renewalOn;
                        p.EffectiveDate = item.effectiveAsOf;
                        p.ProductTypeDescription = item.productTypeDescription;
                        p.ProductTypeId = item.productTypeID;
                        p.ProductStatus = item.productStatus.ToString();
                        p.ProductStatusCurrent = BP_BrokerConnectV4.ProductStatus.Current.ToString();
                        p.ProductStatusPending = BP_BrokerConnectV4.ProductStatus.Pending.ToString();

                        //if (p.PolicyNumber == null)
                        //{
                        //    p.PolicyNumber = "";
                        //}
                        //else
                        //{
                        //    p.PolicyNumber = item.policyNumber;
                        //}

                        if (item.policyNumber == null)
                        {
                            p.PolicyNumber = "";
                        }
                        else
                        {
                            p.PolicyNumber = item.policyNumber;
                        }

                        if (p.ProductId != oldProductId)
                        {
                            PlanList.Add(p);
                            oldProductId = p.ProductId;
                        }


                    }
                }
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return PlanList;

        }

        /// <summary>
        ///Find benefit summary from  BP_BrokerConnectV4 web service using findBenefitSummaries webmethod. 
        /// </summary>
        /// <param name="AccountId">To Find  benefit summary for selected account.</param>
        /// <param name="PlanId">To Find  benefit summary for selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of benefitsummary</returns>
        public List<BenefitSummarydata> FindBenefitSummarys(int AccountId, int PlanId, string SessionId)
        {
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            try
            {

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.BenefitSummarySearchCriteria new_benefits_search = new BP_BrokerConnectV4.BenefitSummarySearchCriteria();
                BP_BrokerConnectV4.BenefitSummaryDescription[] new_benefit_description_summary = new BP_BrokerConnectV4.BenefitSummaryDescription[0];

                SIH.sessionId = SessionId;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;

                new_benefits_search.accountID = AccountId;
                new_benefits_search.productID = PlanId;
                new_benefits_search.productIDSpecified = true;
                new_benefit_description_summary = new_connection.findBenefitSummaries(new_benefits_search);
                if (new_benefit_description_summary != null)
                {

                    int oldBPId = 0;
                    foreach (BP_BrokerConnectV4.BenefitSummaryDescription item in new_benefit_description_summary)
                    {
                        BenefitSummarydata bs = new BenefitSummarydata();
                        bs.ProductId = PlanId;
                        bs.BenefitsummmaryId = item.benefitSummaryID;
                        bs.BenefitDescription = item.description;
                        if (bs.BenefitsummmaryId != oldBPId)
                        {
                            BenefitSummaryList.Add(bs);
                        }
                        oldBPId = bs.BenefitsummmaryId;
                    }

                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return BenefitSummaryList;
        }

        /// <summary>
        ///Find rate from  BP_BrokerConnectV4 web service using findRates webmethod. 
        /// </summary>
        /// <param name="PlanId">To Find rate for selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of Rate</returns>
        public List<Rate> FindRates(int PlanId, string SessionId)
        {
            List<Rate> RateList = new List<Rate>();

            try
            {

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.RateSearchCriteria new_rate_search = new BP_BrokerConnectV4.RateSearchCriteria();
                BP_BrokerConnectV4.RateSummary[] new_rate_summary = new BP_BrokerConnectV4.RateSummary[0];

                List<int> ProductTypeList = new List<int>();

                SIH.sessionId = SessionId; //myloginresult.sessionID;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;


                new_rate_search.productID = PlanId;
                new_rate_search.productIDSpecified = true;

                new_rate_summary = new_connection.findRates(new_rate_search);
                if (new_rate_summary != null)
                {

                    int oldRateId = 0;
                    foreach (BP_BrokerConnectV4.RateSummary item in new_rate_summary)
                    {
                        Rate r = new Rate();
                        r.RateId = item.rateID;
                        r.RateDescription = item.description;
                        if (r.RateId != oldRateId)
                        {
                            RateList.Add(r);
                        }
                        oldRateId = r.RateId;

                    }

                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return RateList;
        }

        /// <summary>
        ///Find contribution from  BP_BrokerConnectV4 web service using findContributions webmethod. 
        /// </summary>
        /// <param name="PlanId">To Find Contribution for selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of Contribution</returns>
        public List<Contribution> FindContributions(int PlanId, string SessionId)
        {
            List<Contribution> ContributionList = new List<Contribution>();
            try
            {

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.ContributionSearchCriteria new_contribution_search = new BP_BrokerConnectV4.ContributionSearchCriteria();
                BP_BrokerConnectV4.ContributionSummary[] new_contribution_summary = new BP_BrokerConnectV4.ContributionSummary[0];

                List<int> ProductTypeList = new List<int>();

                SIH.sessionId = SessionId; //myloginresult.sessionID;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;

                new_contribution_search.productID = PlanId;//5415791;
                new_contribution_search.productIDSpecified = true;
                new_contribution_summary = new_connection.findContributions(new_contribution_search);
                if (new_contribution_summary != null)
                {

                    int oldContributionId = 0;
                    foreach (BP_BrokerConnectV4.ContributionSummary item in new_contribution_summary)
                    {
                        Contribution c = new Contribution();
                        c.ContributionId = item.contributionID;
                        c.ContributionDescription = item.description;
                        if (c.ContributionId != oldContributionId)
                        {
                            ContributionList.Add(c);
                        }
                        oldContributionId = c.ContributionId;

                    }

                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return ContributionList;
        }
        /// <summary>
        ///Find Eligibility from  BP_BrokerConnectV4 web service using FindEligibility webmethod. 
        /// </summary>
        /// <param name="PlanId">To Find Eligibility for selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of Eligibility</returns>
        public List<Eligibility> FindEligibility(int PlanId, string SessionId)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            try
            {

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.EligibilityRuleSearchCriteria new_Eligibility_search = new BP_BrokerConnectV4.EligibilityRuleSearchCriteria();
                BP_BrokerConnectV4.EligibilityRuleSummary[] new_Eligibility_summary = new BP_BrokerConnectV4.EligibilityRuleSummary[0];

                List<int> ProductTypeList = new List<int>();

                SIH.sessionId = SessionId; //myloginresult.sessionID;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;

                new_Eligibility_search.productID = PlanId;//5415791;
                new_Eligibility_search.productIDSpecified = true;
                new_Eligibility_summary = new_connection.findEligibilityRules(new_Eligibility_search);
                if (new_Eligibility_summary != null)
                {

                    int oldEligibilityId = 0;
                    foreach (BP_BrokerConnectV4.EligibilityRuleSummary item in new_Eligibility_summary)
                    {
                        Eligibility c = new Eligibility();
                        c.EligibilityId = item.eligibilityRuleID;
                        c.EligibilityDescription = item.description;
                        if (c.EligibilityId != oldEligibilityId)
                        {
                            EligibilityList.Add(c);
                        }
                        oldEligibilityId = c.EligibilityId;

                    }

                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return EligibilityList;
        }
        /// <summary>
        /// Get HR  contact Data
        /// </summary>
        /// <param name="Selectedindex">To find contact information of  selected HR. </param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Contact data</returns>
        public List<Contact> FindContacts(string Selectedindex, string SessionId, string reportname = "")
        {

            List<Contact> ContactList = new List<Contact>();
            try
            {

                BP_BrokerConnectV4.AccountContact new_accountcontact = new BP_BrokerConnectV4.AccountContact();

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

                BP_BrokerConnectV4.AccountContactSearchCriteria new_accountcontact_search = new BP_BrokerConnectV4.AccountContactSearchCriteria();

                BP_BrokerConnectV4.AccountContact[] new_account_contact = new BP_BrokerConnectV4.AccountContact[0];



                new_accountcontact_search.accountID = Selectedindex.ToString();

                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;
                string strState = "";
                string strCountry = "";
                string strZip = "";

                new_account_contact = new_connection.findAccountContacts(new_accountcontact_search);

                if (new_account_contact != null)
                {
                    foreach (BP_BrokerConnectV4.AccountContact item in new_account_contact)
                    {

                        Contact c = new Contact();
                        c.ContactId = item.contact.contactID;
                        c.Name = item.contact.firstName + " " + item.contact.lastName;
                        c.First_Name = item.contact.firstName;
                        c.Last_Name = item.contact.lastName;
                        c.Title = item.title;
                        c.Email = item.contact.email;

                        //Added for Account Plan / View 
                        c.PrimaryFlag = item.primary;

                        if (item.responsibilities != null)
                        {
                            c.Responsibility = item.responsibilities[0].ToString();
                        }

                        StringBuilder sb = new StringBuilder();

                        if (item.contact.address.street1 != null)
                        {
                            if (item.contact.address.street1.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.street1);
                                if (item.contact.address.street2 != null)
                                {
                                    sb.Append(", ");
                                }
                            }
                        }

                        //if (item.contact.address.street2 != null)
                        //{
                        if (item.contact.address.street1 != null || item.contact.address.street2 != null)
                        {
                            if (item.contact.address.street2 != null && item.contact.address.street2.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.street2);
                            }
                            sb.Append("\n");
                        }
                        //}

                        if (item.contact.address.city != null)
                        {
                            if (item.contact.address.city.ToString() != "None_Selected")
                            {
                                sb.Append(item.contact.address.city);
                                sb.Append(", ");
                            }
                        }

                        if (item.contact.address.state != null)
                        {
                            if (item.contact.address.state.ToString() != "None_Selected")
                            {
                                strState = item.contact.address.state.ToString();
                            }
                        }
                        if (item.contact.address.country != null)
                        {
                            if (reportname == "Enrollment Summary")
                            {
                                strCountry = "";
                            }
                            else
                            {
                                if (item.contact.address.country.ToString() != "None_Selected")
                                {
                                    strCountry = item.contact.address.country.ToString();
                                }
                            }
                        }
                        if (item.contact.address.zip != null)
                        {
                            if (item.contact.address.zip.ToString() != "None_Selected")
                            {
                                strZip = item.contact.address.zip.ToString();
                            }
                        }
                        //sb.Append(item.contact.address.state + " " + item.contact.address.country.ToString().Replace("_", " ") + " " + item.contact.address.zip);
                        if (string.IsNullOrEmpty(strState))
                        {
                            if (!string.IsNullOrEmpty(strCountry))
                            {
                                sb.Append(strCountry.ToString().Replace("_", " ") + " " + strZip);
                            }
                            else
                            {
                                sb.Append(strZip);
                            }
                        }
                        else if (string.IsNullOrEmpty(strState) && string.IsNullOrEmpty(strCountry))
                        {
                            sb.Append(strZip);
                        }
                        else
                        {
                            sb.Append(strState + " " + strCountry.ToString().Replace("_", " ") + " " + strZip);
                        }

                        if (sb != null)
                        {
                            c.Address = sb.ToString();
                        }
                        List<string> phoneList = new List<string>();
                        if (item.contact.phones != null)
                        {
                            foreach (BP_BrokerConnectV4.Phone phone in item.contact.phones)
                            {
                                if (phone.type == BP_BrokerConnectV4.PhoneType.Work)
                                {
                                    if (phone.number != null && phone.areaCode != null)
                                    {
                                        phoneList.Add(phone.areaCode + "-" + phone.number);
                                    }
                                }
                            }
                        }
                        c.Phone = phoneList;
                        c.Postion = " ";

                        if (c.Postion == " " || string.IsNullOrEmpty(c.Postion))
                        {
                            c.Address.Trim();
                        }
                        ContactList.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return ContactList;
        }


        /// <summary>
        /// Insert exception log in database
        /// </summary>
        /// <param name="@ExceptionMessage">Exception message to be inserted for given exception</param>
        /// <param name="@ExceptionSource">Exception source to be inserted for given exception</param>
        /// <param name="@ExceptionMethodName">Exception method name to be inserted for given exception</param>
        /// <param name="@ExceptionStackTrace">Exception stack trace to be inserted for given exception</param>
        /// <param name="@ExceptionCreateDateTime">Exception date and time to be inserted for given exception</param>
        /// <returns>void</returns>
        public void InsertExceptionLog(string ExceptionMessage, string ExceptionSource, string ExceptionMethodName, string ExceptionStackTrace, DateTime ExceptionDate)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@ExceptionMessage ", SqlDbType.NVarChar), new SqlParameter("@ExceptionSource", SqlDbType.NVarChar), new SqlParameter("@ExceptionMethodName", SqlDbType.NVarChar), new SqlParameter("@ExceptionStackTrace", SqlDbType.NVarChar), new SqlParameter("@ExceptionCreateDateTime", SqlDbType.DateTime) };
                parameters[0].Value = ExceptionMessage;
                parameters[1].Value = ExceptionSource;
                parameters[2].Value = ExceptionMethodName;
                parameters[3].Value = ExceptionStackTrace;
                parameters[4].Value = ExceptionDate;
                DB_helper.ExecProc("InsertExceptionLog", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }


        /// <summary>
        /// Insert activity log in database
        /// </summary>
        /// <param name="@UserName">UserName to be inserted for logged in user</param>
        /// <param name="@Office">Office to be inserted for logged in user</param>
        /// <param name="@Department">Department to be inserted for logged in user</param>
        /// <param name="@Region">Region to be inserted for logged in user</param>
        /// <param name="@ClientName">Client Name to be inserted for the selected client</param>
        /// <param name="@Activity">Activity to be inserted for logged in user</param>
        /// <param name="@Activity_Grp">Activity Group to be inserted for logged in user</param>
        /// <param name="@Created_Date">Date and time to be inserted for logged in user</param>
        /// <param name="@LoginName">Login Name to be inserted for the Logged In user</param>
        /// <param name="@Activity_Internal_Id">Client Name to be inserted for the selected client</param>
        /// <param name="@Account_Region">Account_Region to be inserted for the selected client</param>
        /// <param name="@Account_Office">Account_Office to be inserted for the selected client</param>
        /// <returns>void</returns>
        public void InsertActivityLog(string UserName, string Office, string Department, string Region, string Activity, string Activity_Group, DateTime Created_Date, string ClientName, string LoginName, long Activity_Internal_Id, string Account_Region, string Account_Office)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@UserName ", SqlDbType.NVarChar), new SqlParameter("@Office", SqlDbType.NVarChar), new SqlParameter("@Department", SqlDbType.NVarChar), new SqlParameter("@Region", SqlDbType.NVarChar), new SqlParameter("@ClientName", SqlDbType.NVarChar), new SqlParameter("@Activity", SqlDbType.NVarChar), new SqlParameter("@Activity_Grp", SqlDbType.NVarChar), new SqlParameter("@Created_Date", SqlDbType.DateTime), new SqlParameter("@LoginName ", SqlDbType.NVarChar), new SqlParameter("@Account_Internal_Id", SqlDbType.BigInt), new SqlParameter("@Account_Region ", SqlDbType.NVarChar), new SqlParameter("@Account_Office", SqlDbType.NVarChar) };
                parameters[0].Value = UserName;
                parameters[1].Value = Office;
                parameters[2].Value = Department;
                parameters[3].Value = Region;
                parameters[4].Value = ClientName;
                parameters[5].Value = Activity;
                parameters[6].Value = Activity_Group;
                parameters[7].Value = Created_Date;
                parameters[8].Value = LoginName;
                parameters[9].Value = Activity_Internal_Id;
                parameters[10].Value = Account_Region;
                parameters[11].Value = Account_Office;

                DB_helper.ExecProc("InsertActivityLog", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Get Activity Details
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetActivityDetails()
        {
            DataTable dtActivity = new DataTable();

            try
            {
                dtActivity = DB_helper.ExecProcedure("GetActivity", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivity;
        }

        /********************THIS METHOD IS CREATED FOR ADDED ACTIVITY LOG UPDATED VERSION ************************/
        public void InsertActivityLog_V2(string UserName, string Office, string Department, string Region, string Activity, string Activity_Group, DateTime Created_Date, string ClientName, string LoginName, long Activity_Internal_Id, string Account_Region, string Account_Office, string DeliverableCategory, string AccountDepartment, string FTE_Record, string PrimarySales, string PrimaryService, string PrimaryTeamContact, string AdditionalCrtieriaOption_1, string AdditionalCrtieriaOption_2, string AdditionalCrtieriaOption_3, string AdditionalCrtieriaOption_4)
        {
            try
            {
                SqlParameter[] parameters = 
                { 
                    new SqlParameter("@UserName ", SqlDbType.NVarChar), 
                    new SqlParameter("@Office", SqlDbType.NVarChar),
                    new SqlParameter("@Department", SqlDbType.NVarChar),
                    new SqlParameter("@Region", SqlDbType.NVarChar), new SqlParameter("@ClientName", SqlDbType.NVarChar), 
                    new SqlParameter("@Activity", SqlDbType.NVarChar), new SqlParameter("@Activity_Grp", SqlDbType.NVarChar), 
                    new SqlParameter("@Created_Date", SqlDbType.DateTime), new SqlParameter("@LoginName ", SqlDbType.NVarChar),
                    new SqlParameter("@Account_Internal_Id", SqlDbType.BigInt), 
                    new SqlParameter("@Account_Region ", SqlDbType.NVarChar),
                    new SqlParameter("@Account_Office", SqlDbType.NVarChar) ,
                    new SqlParameter("@DeliverableCategory", SqlDbType.NVarChar) ,
                    new SqlParameter("@AccountDepartment", SqlDbType.NVarChar) ,
                    new SqlParameter("@FTE_Record", SqlDbType.NVarChar) ,
                    new SqlParameter("@PrimarySales", SqlDbType.NVarChar) ,
                    new SqlParameter("@PrimaryService", SqlDbType.NVarChar) ,
                    new SqlParameter("@PrimaryTeamContact", SqlDbType.NVarChar) ,
                    new SqlParameter("@AdditionalCrtieriaOption_1", SqlDbType.NVarChar) ,
                    new SqlParameter("@AdditionalCrtieriaOption_2", SqlDbType.NVarChar), 
                    new SqlParameter("@AdditionalCrtieriaOption_3", SqlDbType.NVarChar) ,
                    new SqlParameter("@AdditionalCrtieriaOption_4", SqlDbType.NVarChar)
                };

                parameters[0].Value = UserName;
                parameters[1].Value = Office;
                parameters[2].Value = Department;
                parameters[3].Value = Region;
                parameters[4].Value = ClientName;
                parameters[5].Value = Activity;
                parameters[6].Value = Activity_Group;
                parameters[7].Value = Created_Date;
                parameters[8].Value = LoginName;
                parameters[9].Value = Activity_Internal_Id;
                parameters[10].Value = Account_Region;
                parameters[11].Value = Account_Office;
                //Added New file 
                parameters[12].Value = DeliverableCategory;
                parameters[13].Value = AccountDepartment;
                parameters[14].Value = FTE_Record;
                parameters[15].Value = PrimarySales;
                parameters[16].Value = PrimaryService;
                parameters[17].Value = PrimaryTeamContact;
                parameters[18].Value = AdditionalCrtieriaOption_1;
                parameters[19].Value = AdditionalCrtieriaOption_2;
                parameters[20].Value = AdditionalCrtieriaOption_3;
                parameters[21].Value = AdditionalCrtieriaOption_4;

                DB_helper.ExecProc("InsertActivityLog_V2", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }


        /******** THIS IS NEW FUNCTION CALLED FOR INSERT ACTIVITY LOG IN UPDATED FORMATE  *********************************/
        public Dictionary<string, string> ActivityLogData_V2(DataSet AccountDS, DataSet AccountTeamMemberDS, Dictionary<string, string> DictDepartment, List<Contact> ContactList = null)
        {
            Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
            //DicActivityLog.Clear();
            string AccountDepartment = string.Empty;
            string DepartmentID = string.Empty;
            string FTE_Record = string.Empty;
            string PrimarySales = string.Empty;
            string PrimaryService = string.Empty;
            string PrimaryTeamContact = string.Empty;

            if (AccountDS != null && AccountDS.Tables.Count > 0)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimarySales = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimaryService = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }

                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim() != "")
                        {
                            DepartmentID = Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim();
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                        {
                            FTE_Record = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                        }

                    }
                }
            }

            if (DictDepartment.ContainsKey(DepartmentID))
            {
                AccountDepartment = DictDepartment[DepartmentID];
            }


            //Logic for Primary Contact from Contact List
            if (ContactList.Count > 0)
            {
                var PrimaryName = ContactList.Where(c => c.PrimaryFlag == true).Select(x => x.Name).SingleOrDefault();
                if (PrimaryName != null)
                {
                    PrimaryTeamContact = PrimaryName.ToString();
                }
                else
                {
                    PrimaryTeamContact = "";
                }
            }

            DicActivityLog.Add("AccountDepartment", AccountDepartment);
            DicActivityLog.Add("PrimarySales", PrimarySales);
            DicActivityLog.Add("PrimaryService", PrimaryService);
            DicActivityLog.Add("PrimaryTeamContact", PrimaryTeamContact);
            DicActivityLog.Add("FTE_Record", FTE_Record);

            return DicActivityLog;
        }


        //********************************************** THIS METHOD IS SEPARATE FOR AcquisitionForm
        public Dictionary<string, string> ActivityLogData_V2_AcquisitionForm(DataSet AccountDS, DataSet AccountTeamMemberDS, Dictionary<string, string> DictDepartment, List<Wf_Contact> ContactList = null)
        {
            Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
            //DicActivityLog.Clear();
            string AccountDepartment = string.Empty;
            string DepartmentID = string.Empty;
            string FTE_Record = string.Empty;
            string PrimarySales = string.Empty;
            string PrimaryService = string.Empty;
            string PrimaryTeamContact = string.Empty;

            if (AccountDS != null && AccountDS.Tables.Count > 0)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimarySales = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimaryService = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }

                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim() != "")
                        {
                            DepartmentID = Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim();
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                        {
                            FTE_Record = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                        }
                    }
                }
            }

            if (DictDepartment.ContainsKey(DepartmentID))
            {
                AccountDepartment = DictDepartment[DepartmentID];
            }
            //Logic for Primary Contact from Contact List
            if (ContactList.Count > 0)
            {
                var PrimaryName = ContactList.Where(c => c.PrimaryFlag == true).Select(x => x.Name).SingleOrDefault();
                if (PrimaryName != null)
                {
                    PrimaryTeamContact = PrimaryName.ToString();
                }
                else
                {
                    PrimaryTeamContact = "";
                }
            }
            DicActivityLog.Add("AccountDepartment", AccountDepartment);
            DicActivityLog.Add("PrimarySales", PrimarySales);
            DicActivityLog.Add("PrimaryService", PrimaryService);
            DicActivityLog.Add("PrimaryTeamContact", PrimaryTeamContact);
            DicActivityLog.Add("FTE_Record", FTE_Record);

            return DicActivityLog;
        }
        
        public Dictionary<string, string> ActivityLogData_V2_AcquisitionForm_V2(DataSet AccountDS, DataSet AccountTeamMemberDS, Dictionary<string, string> DictDepartment, List<Contact> ContactList = null)
        {
            Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
            //DicActivityLog.Clear();
            string AccountDepartment = string.Empty;
            string DepartmentID = string.Empty;
            string FTE_Record = string.Empty;
            string PrimarySales = string.Empty;
            string PrimaryService = string.Empty;
            string PrimaryTeamContact = string.Empty;

            if (AccountDS != null && AccountDS.Tables.Count > 0)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimarySales = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    PrimaryService = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }

                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim() != "")
                        {
                            DepartmentID = Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim();
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                        {
                            FTE_Record = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                        }

                    }
                }
            }

            if (DictDepartment.ContainsKey(DepartmentID))
            {
                AccountDepartment = DictDepartment[DepartmentID];
            }


            //Logic for Primary Contact from Contact List
            if (ContactList.Count > 0)
            {
                var PrimaryName = ContactList.Where(c => c.PrimaryFlag == true).Select(x => x.Name).SingleOrDefault();
                if (PrimaryName != null)
                {
                    PrimaryTeamContact = PrimaryName.ToString();
                }
                else
                {
                    PrimaryTeamContact = "";
                }
            }
            DicActivityLog.Add("AccountDepartment", AccountDepartment);
            DicActivityLog.Add("PrimarySales", PrimarySales);
            DicActivityLog.Add("PrimaryService", PrimaryService);
            DicActivityLog.Add("PrimaryTeamContact", PrimaryTeamContact);
            DicActivityLog.Add("FTE_Record", FTE_Record);

            return DicActivityLog;
        }


        /// <summary>
        /// Get Activity Details
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetGetActivityLogDistinctValues()
        {
            DataTable dtActivityDistinct = new DataTable();

            try
            {
                dtActivityDistinct = DB_helper.ExecProcedure("GetActivityLogDistinctValues", null);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivityDistinct;
        }
        public DataTable GetAccountRegionOffices(string Account_Region)
        {
            DataTable dtActivityDistinct = new DataTable();

            try
            {
                SqlParameter[] parameters = { new SqlParameter("@Account_Region ", SqlDbType.NVarChar) };
                parameters[0].Value = Account_Region;
                dtActivityDistinct = DB_helper.ExecProcedure("GetDistinctRegionOffice", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivityDistinct;
        }

        /// <summary>
        /// Get Activity Information
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetActivityInformation(string whereClause)
        {
            DataTable dtActivityDetails = new DataTable();

            try
            {
                SqlParameter[] parameters = { new SqlParameter("@whereClause ", SqlDbType.NVarChar) };
                parameters[0].Value = whereClause;
                dtActivityDetails = DB_helper.ExecProcedure("GetActivityDetails3", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return dtActivityDetails;
        }

        /// <summary>
        ///Find office list from BP_BrokerConnectV4 web service using findOffices webmethod.
        /// </summary>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <param name="txtsearch">To find perticular offices based on search criteria.</param>
        /// <returns>List of Office</returns>   

        public List<Office> FindOffice(string SessionId, string txtsearch)
        {
            List<Office> OfficeList = new List<Office>();
            List<Office> OfficeListReturn = new List<Office>();

            try
            {
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.OfficeSearchCriteria new_office_search = new BP_BrokerConnectV4.OfficeSearchCriteria();
                BP_BrokerConnectV4.Office[] new_office = new BP_BrokerConnectV4.Office[0];
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;
                new_office = new_connection.findOffices(new_office_search);

                int i = 0;
                if (new_office != null)
                {
                    foreach (BP_BrokerConnectV4.Office item in new_office)
                    {
                        Office acc = new Office();

                        acc.OfficeId = item.officeID;
                        if (item.officeName != null)
                        {
                            acc.OfficeNameText = item.officeName;
                        }
                        if (item.regionName != null)
                        {
                            acc.RegionName = item.regionName;
                        }
                        OfficeList.Add(acc);
                        i++;
                    }

                    var office = (from p in OfficeList
                                  select p).Distinct();

                    foreach (var s in office)
                    {
                        OfficeListReturn.Add(s);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return OfficeListReturn;
        }

        /// <summary>
        ///Find account list from  BP_BrokerConnectV4 web service using findAccounts webmethod.
        /// </summary>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <param name="arrOfficeName">To write check how many offices are selected from the checkboxlist.</param>
        /// <param name="ProducerTeamID">To match with the OptionFieldId.</param>
        /// <returns>List of Account</returns>   
        public List<Account> FindFilteredClientListForReportsTab(string SessionId, ArrayList arrOfficeName, int ProducerTeamID, DateTime _fromdate, DateTime _todate, string dateType = "1")
        {
            List<Account> filteredAccountList = new List<Account>();
            List<Account> finalFilteredAccountList = new List<Account>();
            Timeline_Constant tc = new Timeline_Constant();
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();

            try
            {
                BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection_GetAcct = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.AccountSearchCriteria new_account_search = new BP_BrokerConnectV4.AccountSearchCriteria();
                BP_BrokerConnectV4.AccountSummary[] new_account_summary = new BP_BrokerConnectV4.AccountSummary[0];
                BP_BrokerConnectV4.AccountClassificationType[] Search_Type = new BP_BrokerConnectV4.AccountClassificationType[1];
                BP_BrokerConnectV4.AccountType[] acctType = new BP_BrokerConnectV4.AccountType[1];

                acctType[0] = BP_BrokerConnectV4.AccountType.Client;
                Search_Type[0] = BP_BrokerConnectV4.AccountClassificationType.Group;

                new_account_search.accountClassifications = Search_Type;
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_connection_GetAcct.SessionIdHeaderValue = SIH;
                new_connection_GetAcct.Timeout = 14400000;

                new_account_search.accountTypes = acctType;

                new_account_summary = new_connection.findAccounts(new_account_search);

                timeD.BuildActivitiesTable();
                if (new_account_summary != null)
                {
                    // Get the account list based on "Active = True" and "AccountType = Client"
                    var AcctList = (from n in new_account_summary.AsEnumerable()
                                    where
                                        n.active == true && n.accountType.ToString().ToLower() == "client"
                                    select n).ToList();
                    Account acc = new Account();
                    // List<Type> actList1 = (List<T>)AcctList;

                    // If any of the offices is selected from the checkboxlist from UI then get the accounts (Clients) related to that office only
                    // else take all the accounts (Clients) in the list
                    if (arrOfficeName.Count > 0)
                    {
                        for (int j = 0; j < arrOfficeName.Count; j++)
                        {
                            //var filtAcctList = (from m in AcctList.AsEnumerable()
                            //                    where m.officeName == arrOfficeName[j].ToString()
                            //                    select m);

                            var filtAcctList = (from m in AcctList.AsEnumerable()
                                                where m.officeName == arrOfficeName[j].ToString()
                                                select m).ToList();



                            //foreach (var x in filtAcctList)
                            for (int x = 0; x < filtAcctList.Count; x++)
                            {
                                //ActivityInfoTable = timeD.GetActivityInformation_For_Reports(Convert.ToInt32(x.accountId), SessionId, tc.Timeline1_SubjectID);
                                ActivityInfoTable = timeD.GetActivityInformation_For_Reports(Convert.ToInt32(filtAcctList[x].accountID), SessionId, tc.Timeline1_SubjectID);

                                if (ActivityInfoTable != null && ActivityInfoTable.Rows.Count > 0)
                                {
                                    dynamic ActivityInfoList = null;
                                    if (_fromdate == DateTime.MinValue && _todate == DateTime.MinValue)
                                    {
                                        ActivityInfoList = from l in ActivityInfoTable.AsEnumerable() select l;
                                    }
                                    else
                                    {
                                        // If ddlDateType = "Create Date"
                                        if (dateType == "1")
                                        {
                                            ActivityInfoList = from l in ActivityInfoTable.AsEnumerable()
                                                               where
                                                                   (Convert.ToDateTime(l.Field<string>("createdon")) >= _fromdate && Convert.ToDateTime(l.Field<string>("createdon")) <= _todate)
                                                               select l;
                                        }
                                        // If ddlDateType = "Renewal Date"
                                        else if (dateType == "2")
                                        {
                                            ActivityInfoList = from l in ActivityInfoTable.AsEnumerable() select l;
                                        }
                                    }

                                    if (ActivityInfoList != null)
                                    {
                                        foreach (var m in ActivityInfoList)
                                        {
                                            acc = new Account();
                                            //acc.AccountId = x.accountID;
                                            //acc.AccountName = x.accountName;
                                            //acc.OfficeName = x.officeName;
                                            //acc.RecordId = m.ItemArray[0];

                                            acc.AccountId = filtAcctList[x].accountID;
                                            acc.AccountName = filtAcctList[x].accountName;
                                            acc.OfficeName = filtAcctList[x].officeName;
                                            acc.RecordId = m.ItemArray[0];

                                            filteredAccountList.Add(acc);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        //foreach (var x in AcctList)
                        for (int x = 0; x < AcctList.Count; x++)
                        {
                            //ActivityInfoTable = timeD.GetActivityInformation_For_Reports(Convert.ToInt32(x.accountID), SessionId, tc.Timeline1_SubjectID);
                            ActivityInfoTable = timeD.GetActivityInformation_For_Reports(Convert.ToInt32(AcctList[x].accountID), SessionId, tc.Timeline1_SubjectID);

                            if (ActivityInfoTable != null && ActivityInfoTable.Rows.Count > 0)
                            {
                                dynamic ActivityInfoList = null;

                                if (_fromdate == DateTime.MinValue && _todate == DateTime.MinValue)
                                {
                                    ActivityInfoList = (from l in ActivityInfoTable.AsEnumerable() select l).ToList();
                                }
                                else
                                {
                                    ActivityInfoList = (from l in ActivityInfoTable.AsEnumerable()
                                                        where
                                                            (Convert.ToDateTime(l.Field<string>("createdon")) >= _fromdate && Convert.ToDateTime(l.Field<string>("createdon")) <= _todate)
                                                        select l).ToList();
                                }

                                if (ActivityInfoList != null)
                                {
                                    foreach (var m in ActivityInfoList)
                                    {
                                        acc = new Account();
                                        //acc.AccountId = x.accountID;
                                        //acc.AccountName = x.accountName;
                                        //acc.OfficeName = x.officeName;
                                        //acc.RecordId = m.ItemArray[0];

                                        acc.AccountId = AcctList[x].accountID;
                                        acc.AccountName = AcctList[x].accountName;
                                        acc.OfficeName = AcctList[x].officeName;
                                        acc.RecordId = m.ItemArray[0];

                                        filteredAccountList.Add(acc);
                                    }
                                }
                            }
                        }
                    }

                    dynamic optValueID = null;

                    // Iterate the loop on above filtered account list to check few conditions such as 
                    // 1. Check for CustomFieldId = 18418
                    // 2. Then check OptionValueId for the above field to match witch with the producer team OptionValueId
                    // 3. If the OptionValueId and Producer Team OptionValueId matches then create one entry for properties to add into new account list
                    // 4. Then return the newly created filtered account list

                    //foreach (var actList in filteredAccountList)
                    for (int actList = 0; actList < filteredAccountList.Count; actList++)
                    {
                        acc = new Account();
                        new_account = new BP_BrokerConnectV4.Account();
                        //new_account = null;
                        ////new_account = new_connection_GetAcct.getAccount(actList.AccountId);
                        new_account = new_connection_GetAcct.getAccount(filteredAccountList[actList].AccountId);

                        if (new_account != null)
                        {
                            if (new_account.accountCustomFieldValues != null)
                            {
                                optValueID = (from n in new_account.accountCustomFieldValues.AsEnumerable()
                                              where n.customFieldID == 18418
                                              select n.optionValueID).FirstOrDefault();
                                if (optValueID != null) acc.OptionValueID = optValueID;
                            }

                            // By default select all the producer team
                            if (ProducerTeamID == 1111)
                            {
                                ////acc.AccountId = actList.AccountId;
                                ////acc.AccountName = actList.AccountName;
                                ////acc.RecordId = actList.RecordId;

                                acc.AccountId = filteredAccountList[actList].AccountId;
                                acc.AccountName = filteredAccountList[actList].AccountName;
                                acc.RecordId = filteredAccountList[actList].RecordId;

                                if (new_account.primaryContactUserID != null) acc.PrimaryContactUserID = new_account.primaryContactUserID;
                                if (new_account.primarySalesLeadUserID != null) acc.PrimarySalesLeadUserID = new_account.primarySalesLeadUserID;
                                if (new_account.primaryServiceLeadUserID != null) acc.PrimaryServiceLeadUserID = new_account.primaryServiceLeadUserID;

                                finalFilteredAccountList.Add(acc);
                            }
                            else
                            {
                                if (optValueID == ProducerTeamID)
                                {
                                    ////acc.AccountId = actList.AccountId;
                                    ////acc.AccountName = actList.AccountName;
                                    ////acc.RecordId = actList.RecordId;

                                    acc.AccountId = filteredAccountList[actList].AccountId;
                                    acc.AccountName = filteredAccountList[actList].AccountName;
                                    acc.RecordId = filteredAccountList[actList].RecordId;

                                    if (new_account.primaryContactUserID != null) acc.PrimaryContactUserID = new_account.primaryContactUserID;
                                    if (new_account.primarySalesLeadUserID != null) acc.PrimarySalesLeadUserID = new_account.primarySalesLeadUserID;
                                    if (new_account.primaryServiceLeadUserID != null) acc.PrimaryServiceLeadUserID = new_account.primaryServiceLeadUserID;

                                    finalFilteredAccountList.Add(acc);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return finalFilteredAccountList;
        }

        /// <summary>
        /// Find product list from  BP_BrokerConnectV4 web service using findProducts webmethod For Tools.
        /// </summary>
        /// <param name="AccountId">To Find plan for selected account</param>
        /// <param name="PlanType">To Find plan for selected plantype</param>
        /// <param name="LOC">To Find plan for selected plantype</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>List of Product i.e Plan</returns>

        public List<Plan> FindPlans_Tools(int AccountId, string PlanType, string LOC, string SessionId)
        {
            List<Plan> PlanList = new List<Plan>();
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            try
            {

                BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

                BP_BrokerConnectV4.ProductSearchCriteria new_product_search = new BP_BrokerConnectV4.ProductSearchCriteria();
                BP_BrokerConnectV4.ProductSummary[] new_product_summary = new BP_BrokerConnectV4.ProductSummary[0];
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


                SIH.sessionId = SessionId;
                new_connection.Timeout = 14400000; //4hours
                new_connection.SessionIdHeaderValue = SIH;

                new_product_search = new BP_BrokerConnectV4.ProductSearchCriteria();
                new_product_search.accountID = AccountId;

                new_product_summary = new_connection.findProducts(new_product_search);



                if (new_product_summary != null)
                {
                    int oldProductId = 0;
                    string oldSummaryName = string.Empty;
                    foreach (BP_BrokerConnectV4.ProductSummary item in new_product_summary)
                    {
                        //  Plan p = new Plan();

                        if (item.productTypeID.ToString().Length == 3)
                        {
                            BenefitSummaryList = FindBenefitSummarys(AccountId, item.productID, SessionId);

                            foreach (var benifitsum in BenefitSummaryList)
                            {
                                Plan p = new Plan();
                                p.ProductId = item.productID;
                                p.ProductName = item.name.ToString() + "|" + item.carrierName + "|" + item.effectiveAsOf.ToShortDateString();
                                p.CarrierId = item.carrierID;
                                p.CarrierName = item.carrierName;
                                p.RenewalDate = item.renewalOn;
                                p.EffectiveDate = item.effectiveAsOf;
                                p.ProductTypeDescription = item.productTypeDescription;
                                p.ProductTypeId = item.productTypeID;
                                p.ProductStatus = item.productStatus.ToString();
                                p.ProductStatusCurrent = BP_BrokerConnectV4.ProductStatus.Current.ToString();
                                p.ProductStatusPending = BP_BrokerConnectV4.ProductStatus.Pending.ToString();
                                p.SummaryName = benifitsum.BenefitDescription;
                                p.SummaryID = benifitsum.BenefitsummmaryId;

                                if (item.policyNumber == null)
                                {
                                    p.PolicyNumber = "";
                                }
                                else
                                {
                                    p.PolicyNumber = item.policyNumber;
                                }

                                if (p.ProductId != oldProductId)
                                {
                                    PlanList.Add(p);
                                    oldProductId = p.ProductId;
                                    oldSummaryName = p.SummaryName;
                                }
                                else if (p.ProductId == oldProductId && p.SummaryName != oldSummaryName)
                                {
                                    PlanList.Add(p);
                                }

                            }
                        }
                        else
                        {
                            Plan p = new Plan();
                            p.ProductId = item.productID;
                            p.ProductName = item.name.ToString() + "|" + item.carrierName + "|" + item.effectiveAsOf.ToShortDateString();
                            p.CarrierId = item.carrierID;
                            p.CarrierName = item.carrierName;
                            p.RenewalDate = item.renewalOn;
                            p.EffectiveDate = item.effectiveAsOf;
                            p.ProductTypeDescription = item.productTypeDescription;
                            p.ProductTypeId = item.productTypeID;
                            p.ProductStatus = item.productStatus.ToString();
                            p.ProductStatusCurrent = BP_BrokerConnectV4.ProductStatus.Current.ToString();
                            p.ProductStatusPending = BP_BrokerConnectV4.ProductStatus.Pending.ToString();
                            p.SummaryName = item.name;
                            p.SummaryID = 0;

                            if (item.policyNumber == null)
                            {
                                p.PolicyNumber = "";
                            }
                            else
                            {
                                p.PolicyNumber = item.policyNumber;
                            }

                            if (p.ProductId != oldProductId)
                            {
                                PlanList.Add(p);
                                oldProductId = p.ProductId;
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return PlanList;

        }

        public int FindCustomField(string SessionId, int accoundId)
        {
            List<Account> filteredAccountList = new List<Account>();
            List<Account> finalFilteredAccountList = new List<Account>();
            Timeline_Constant tc = new Timeline_Constant();
            TimelineDetail timeD = new TimelineDetail();
            DataTable ActivityInfoTable = new DataTable();
            int optValueID = 0;

            try
            {
                BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection_GetAcct = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.AccountSearchCriteria new_account_search = new BP_BrokerConnectV4.AccountSearchCriteria();
                BP_BrokerConnectV4.AccountSummary[] new_account_summary = new BP_BrokerConnectV4.AccountSummary[0];
                BP_BrokerConnectV4.AccountClassificationType[] Search_Type = new BP_BrokerConnectV4.AccountClassificationType[1];
                BP_BrokerConnectV4.AccountType[] acctType = new BP_BrokerConnectV4.AccountType[1];

                acctType[0] = BP_BrokerConnectV4.AccountType.Client;
                Search_Type[0] = BP_BrokerConnectV4.AccountClassificationType.Group;

                new_account_search.accountClassifications = Search_Type;
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_connection_GetAcct.SessionIdHeaderValue = SIH;
                new_connection_GetAcct.Timeout = 14400000;

                new_account_search.accountTypes = acctType;
                new_account_summary = new_connection.findAccounts(new_account_search);

                timeD.BuildActivitiesTable();
                if (new_account_summary != null)
                {

                    new_account = new BP_BrokerConnectV4.Account();
                    //new_account = null;
                    ////new_account = new_connection_GetAcct.getAccount(actList.AccountId);
                    //new_account = new_connection_GetAcct.getAccount(filteredAccountList[actList].AccountId);
                    new_account = new_connection_GetAcct.getAccount(accoundId);

                    if (new_account != null)
                    {
                        if (new_account.accountCustomFieldValues != null)
                        {
                            optValueID = (from n in new_account.accountCustomFieldValues.AsEnumerable()
                                          where n.customFieldID == 52158
                                          select n.optionValueID).FirstOrDefault();
                        }

                    }
                }
                return optValueID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Get BenchmarkingGroup from datadase BPPortal.
        /// </summary>
        /// <returns>Office name</returns>
        public DataTable GetBenchmarkingGrp(string primaryIndustry)
        {
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@BenefitPoint_Primary_Industry", SqlDbType.NVarChar, 100) };
                parameters[0].Value = primaryIndustry;
                bp.BenchmarkingGrp = DB_helper.ExecProcedure("GetBenchmarking_Grouping", parameters);//("select Office_City using selected state from dbo.USIOfficeAddressListing");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return bp.BenchmarkingGrp;
        }

        /// <summary>
        /// Returns all avialable carrier list with ID and Name
        /// </summary>
        /// <param name="SessionId">SessionID</param>
        /// <returns></returns>
        public List<Carrier> GetAllCarriers(string SessionId)
        {
            List<Carrier> CarrierList = new List<Carrier>();
            try
            {

                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

                BP_BrokerConnectV4.CarrierSummary[] carrier_summary = new BP_BrokerConnectV4.CarrierSummary[0];

                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

                SIH.sessionId = SessionId;

                new_connection.SessionIdHeaderValue = SIH;

                carrier_summary = new_connection.getAvailableCarriers();
                if (carrier_summary != null)
                {
                    foreach (BP_BrokerConnectV4.CarrierSummary item in carrier_summary)
                    {
                        Carrier cc = new Carrier();

                        cc.CarrierId = item.carrierID;
                        cc.CarrierName = item.carrierName.ToString();
                        CarrierList.Add(cc);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return CarrierList;

        }


        // GETTTING CLIENT AGREEMNET MATRIX 
        public DataTable loadClientAgreementMatrix(string UserState)
        {
            DataTable ClientAgreementMatrix = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@STATENAME ", SqlDbType.NVarChar) };
                parameters[0].Value = UserState;
                ClientAgreementMatrix = DB_helper.ExecProcedure("SP_ClientAgreementMatrix", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return ClientAgreementMatrix;
        }

        // GETTTING CLIENT AGREEMNET MATRIX 
        public DataTable SP_loadClientAgreementMatrix(string UserState)
        {
            DataTable ClientAgreementMatrix = new DataTable();
            try
            {
                SqlParameter[] parameters = { new SqlParameter("@STATENAME ", SqlDbType.NVarChar) };
                parameters[0].Value = UserState;
                ClientAgreementMatrix = DB_helper.ExecProcedure("SP_CP_ClientAgreementMatrix", parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return ClientAgreementMatrix;
        }
    }
}