﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_SummerHealth : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string Std_Plan = string.Empty;
        int PremiumTable_counter = 2;
        List<int> lstPlanTier = new List<int>();

        static Dictionary<string, Dictionary<string, string>> AllBookmarks = new Dictionary<string, Dictionary<string, string>>();
        List<int> Medical_BenefitColumn_Level1 = new List<int>() { 100, 101, 103, 106, 108, 111, 112, 114 };
        List<int> Medical_BenefitColumn_Level2 = new List<int>() { 113, 109, 107, 104, 102 };
        List<int> Medical_BenefitColumn_Level3 = new List<int>() { 105, 110 };

        List<int> Dental_BenefitColumn_Level3 = new List<int>() { 120 };
        List<int> Dental_BenefitColumn_Level2 = new List<int>() { 119, 117 };
        List<int> Dental_BenefitColumn_Level1 = new List<int>() { 115, 116, 118, 121 };
        List<int> SkippedRowIndexesforWidth = new List<int>() { 3, 7, 10, 13, 16, 23, 26, 29, 31, 36 };

        public void WriteMedicalSectionToTemplateSummerHealth_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DropDownList ddlClient, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet EligibilityDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            lstPlanTier.Clear();
            List<int> SkippedRowIndexes = new List<int>() { 3, 7, 10, 13, 16, 23, 26, 29, 31, 36 };
            getBookmarks();

            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;
            DataTable Emp = new DataTable();
            Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();


            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }
            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 1;
            int WriteCount = 0;
            int ColumnIncreament = 0;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            List<int> Contributions = new List<int>();
            string strAllCarriers = "";
            string FirstRenewalDate = string.Empty;
            string FirstEffectiveDate = string.Empty;
            string ColumnNumber = string.Empty;
            int ContributionStartCount = 0;
            int TotalContributionCount = 0;

            float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
            float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;

            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    if (string.IsNullOrEmpty(FirstRenewalDate))
                    {
                        FirstRenewalDate = Renewaldate;
                        FirstEffectiveDate = Effectivedate;
                    }

                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                    int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        WriteCount++;
                        RemainingBenefitCount--;
                        lstPlanTier.Add(PlanTier);
                        switch (PlanTier)
                        {
                            case 1:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);
                                ColumnIncreament = 1;
                                break;
                            case 2:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);
                                ColumnIncreament = 2;
                                break;
                            case 3:
                                ColumnIncreament = 3;
                                break;
                        }
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AttributeValue = "";
                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;


                        #region Benefits Coverage

                        #region Annual Deductible Individual - 4
                        //In Network
                        DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                            int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                            oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                        }

                        oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                                int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Individual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                    int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3Individual["benefitColumnID"].ToString());
                                    string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }

                        }
                        // Out Network

                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Family - 5
                        //In Network
                        DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Family != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Family);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Coinsurance - 6
                        //In Network
                        DataRow drBenefitValues_InNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkCoinsurance != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkCoinsurance);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Coinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Coinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Coinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Maximum Pocket Individual - 8
                        //In Network
                        DataRow drBenefitValues_InNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPockIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockIndividual);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPockIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockIndividual);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3Individual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Maximum Pocket Family - 9
                        //In Network
                        DataRow drBenefitValues_InNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPockFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockFamily);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPockFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PockFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PockFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit -Primary Care -11
                        DataRow drBenefitValues_InNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPhysicalOfficePrimaryCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficePrimaryCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPhysicalOfficePrimaryCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficePrimaryCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PhysicalOfficePrimaryCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PhysicalOfficePrimaryCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit -Specialty Care - 12
                        //In Network
                        DataRow drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3PhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3PhysicalOfficeSpecialtyCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PhysicalOfficeSpecialtyCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit - Preventive Adult Periodic Exams - 14
                        //In Network
                        DataRow drBenefitValues_InNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPreventiveAdultPeriodicExams != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveAdultPeriodicExams);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPreventiveAdultPeriodicExams != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveAdultPeriodicExams);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3PreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3PreventiveAdultPeriodicExams != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PreventiveAdultPeriodicExams);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Physical Office Visit - Preventive Well-Child Care - 15
                        //InNetwork
                        DataRow drBenefitValues_InNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkPreventiveWellChildCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveWellChildCare);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkPreventiveWellChildCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveWellChildCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3PreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3PreventiveWellChildCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PreventiveWellChildCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - X-ray and Lab Tests = 17
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticXrayLabTest != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticXrayLabTest);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticXrayLabTest != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticXrayLabTest);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_level3DisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_level3DisgnisticXrayLabTest != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticXrayLabTest);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Complex Radiology = 18
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticComplexRadiology != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticComplexRadiology);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticComplexRadiology != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticComplexRadiology);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_level3DisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_level3DisgnisticComplexRadiology != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticComplexRadiology);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Urgent Care Facility - 19
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - EmergencyRoom - 20
                        //InNetwork
                        DataRow drBenefitValues_InNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkEmrgRoomFacilityCharge != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkEmrgRoomFacilityCharge);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkEmrgRoomFacilityCharge != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkEmrgRoomFacilityCharge);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Leve3EmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Leve3EmrgRoomFacilityCharge != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3EmrgRoomFacilityCharge);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Inpatient Facility Charges - 21
                        //InNetwork
                        DataRow drBenefitValues_InNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkInpatientFacilityCharges != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkInpatientFacilityCharges);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkInpatientFacilityCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkInpatientFacilityCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3InpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3InpatientFacilityCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3InpatientFacilityCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Dignistic Services - Outpatient Facility and Surgical Charges- 22
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientFacilityandSurgicalCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientFacilityandSurgicalCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Mental Health - Inpatient - 24
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalHealthInpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthInpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalHealthInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalHealthInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalHealthInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mental Health - Inpatient - 25
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalHealthOutpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthOutpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalHealthOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValuesLevel3MentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValuesLevel3MentalHealthOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValuesLevel3MentalHealthOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Substance Abuse - Inpatient - 27
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalSubAbuseInpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseInpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalSubAbuseInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalSubAbuseInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Substance Abuse - Outpatient - 28
                        //InNetwork
                        DataRow drBenefitValues_InNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkMentalSubAbuseOutpatient != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseOutpatient);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkMentalSubAbuseOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3MentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3MentalSubAbuseOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Other Services - Chiropractic - 30
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOtherServiceChiropractic != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOtherServiceChiropractic);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOtherServiceChiropractic != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOtherServiceChiropractic);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OtherServiceChiropractic != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OtherServiceChiropractic);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion
                        #endregion
                        #region PharmacySesion

                        #region Retail Pharmacy (30 Day Supply)- Generic (Tier 1)- 3
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutpatientGenericFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientGenericFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion


                        #region Retail Pharmacy (30 Day Supply)- Preferred (Tier 2)- 4
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Retail Pharmacy (30 Day Supply)- Non-Preferred (Tier 3)- 5
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutNonPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutNonPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutpatientNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutpatientNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Retail Pharmacy (30 Day Supply)- Preferred Specialty (Tier 4)- 6
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_LEVEL3OutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_LEVEL3OutPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LEVEL3OutPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }

                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Generic (Tier 1)- 8
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderGenericFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderGenericFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Preferred (Tier 2)- 9
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Non-Preferred (Tier 3)- 10
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderNonPreferredFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderNonPreferredFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Mail Order Pharmacy (90 Day Supply)- Preferred Specialty (Tier 4)- 11
                        //InNetwork
                        DataRow drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                            }
                        }
                        AttributeValue = "";
                        #endregion



                        #endregion

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                        ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                        int BookmarkStartIndex = (TablesUsed * 6) - 6 + 1;

                        for (int i = 0; i < ContributionStartCount; i++)
                        {
                            if (AllBookmarks["Medical"].ContainsKey("MedicalContribution" + BookmarkStartIndex))      //MedicalHMODescription1  MedicalPPODescription1
                            {
                                AllBookmarks["Medical"].Remove("MedicalContribution" + BookmarkStartIndex);
                            }
                            BookmarkStartIndex++;
                        }

                        if (AllBookmarks["Medical"].ContainsKey("MedicalPlanTables" + TablesUsed))      //MedicalHMODescription1  MedicalPPODescription1
                        {
                            AllBookmarks["Medical"].Remove("MedicalPlanTables" + TablesUsed);
                        }

                        FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                        TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;

                        if (WriteCount % 3 == 0)
                        {
                            AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 7;
                            RemainingBenefitCount = 3;
                            ContributionStartCount = 0;
                            TablesUsed += 1;
                            lstPlanTier.Clear();
                        }

                    }
                }
            }

            if (RemainingBenefitCount != 3)
            {
                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
            }


            #region MergeField

            int iTotalFields = 0;
            strAllCarriers = strAllCarriers.TrimEnd(',');
            if (WriteCount > 1 && strAllCarriers.Contains(","))
            {
                int lastIndex = strAllCarriers.LastIndexOf(',');
                strAllCarriers = (strAllCarriers.Substring(0, lastIndex) + " and " + strAllCarriers.Substring(lastIndex + 1));
            }
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("MedicalPlan_Client_1"))
                    {
                        myMergeField.Select();

                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }



                    if (fieldName.Contains("Notclient_Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }

                    #region Eligibility

                    if (fieldName.Contains("Eligibility_Client_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                    if (fieldName.Contains("First Medical Plan Renewal Year"))
                    {
                        myMergeField.Select();
                        string effectivedate = Effectivedate;
                        // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                        continue;
                    }
                    if (fieldName.Contains("First Medical Plan Renewal Date"))
                    {
                        string effectivedate = FirstEffectiveDate;
                        // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        DateTime effective_date = Convert.ToDateTime(effectivedate);

                        myMergeField.Select();
                        oWordApp.Selection.TypeText(effective_date.ToString("MMMM d, yyyy"));
                        continue; ;
                    }




                    #endregion

                }
            }
            #endregion
        }
        public void WriteDentalSectionToTemplateSummerHealth_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            lstPlanTier.Clear();
            List<int> SkippeRowSpan = new List<int>() { 3, 7, 12 };
            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            string strAllCarriers = "";
            int ContributionStartCount = 0;
            int TotalContributionCount = 0;

            foreach (object item in DentalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in DentalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 15;
            int WriteCount = 0;
            int ColumnIncreament = 0;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            List<int> Contributions = new List<int>();
            float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
            float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;
            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                    int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        WriteCount++;
                        RemainingBenefitCount--;
                        lstPlanTier.Add(PlanTier);
                        switch (PlanTier)
                        {
                            case 1:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                ColumnIncreament = 1;
                                break;
                            case 2:
                                // Benefits Table 
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                ColumnIncreament = 2;
                                break;
                            case 3:
                                ColumnIncreament = 3;
                                break;
                        }
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AttributeValue = "";
                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                        #region Benefits Coverage

                        #region Annual Deductible Individual - 4
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalIndividual != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalIndividual);
                            int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkDentalIndividual["benefitColumnID"].ToString());
                            string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                            oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                        }

                        oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        // Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalIndividual);
                                int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkDentalIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalIndividual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalIndividual);
                                    int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3DentalIndividual["benefitColumnID"].ToString());
                                    string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Family - 5
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalFamily != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalFamily);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDenatlFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDenatlFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DenatlFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DenatlFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }

                        AttributeValue = "";
                        #endregion

                        #region Annual Deductible Waived for Preventive Care - 6
                        //In Network
                        DataRow drBenefitValues_InNetworkDenatlCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDenatlCoinsurance != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDenatlCoinsurance);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalCoinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalCoinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Per Person/Family (indicate calendar/benefit year) - 8
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalAnnualPlanMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalAnnualPlanMaximum);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalAnnualPlanMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalAnnualPlanMaximum);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalAnnualPlanMaximum != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalAnnualPlanMaximum);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Preventive - 9 //
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalPreventive != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalPreventive);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalPreventive != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalPreventive);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalPreventive != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalPreventive);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Basic Services – Basic -10
                        DataRow drBenefitValues_InNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalBasicServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalBasicServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalBasicServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalBasicServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalBasicServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalBasicServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Major Services – Major - 11
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalMajorServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalMajorServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalMajorServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalMajorServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalMajorServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalMajorServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia-Orthodontia Services / Orthodontia - 13
                        //In Network
                        DataRow drBenefitValues_InNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalOrthodontiaServices != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontiaServices);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";
                        //Out Network
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalOrthodontiaServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontiaServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalOrthodontiaServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontiaServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia Services / Adults (and covered full-time students - 14
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalOrthodontia != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontia);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region Orthodontia Services / Dependent Children 15
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalDependentChildren != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalDependentChildren);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalDependentChildren != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalDependentChildren);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalDependentChildren != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalDependentChildren);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region General Plan Information – Lifetime Orthodontial Plan Maximum -16
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDentalLifetimeOrthodontia != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalLifetimeOrthodontia);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDentalLifetimeOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalLifetimeOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DentalLifetimeOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalLifetimeOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #region General Plan Information – Waiting Period - 17
                        //InNetwork
                        DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                        if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        //OutNetwork
                        if (PlanTier >= 2)
                        {
                            DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                            if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier == 3)
                            {
                                DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                AttributeValue = "";
                            }
                        }
                        AttributeValue = "";
                        #endregion

                        #endregion

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                        ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                        int BookmarkStartIndex = (TablesUsed * 6) - 6 + 1;

                        for (int i = 0; i < ContributionStartCount; i++)
                        {
                            if (AllBookmarks["Dental"].ContainsKey("DentalContribution" + BookmarkStartIndex))      //DentalContribution1  DentalContribution2
                            {
                                AllBookmarks["Dental"].Remove("DentalContribution" + BookmarkStartIndex);
                            }
                            BookmarkStartIndex++;
                        }

                        if (AllBookmarks["Dental"].ContainsKey("DentalPlanTables" + TablesUsed))
                        {
                            AllBookmarks["Dental"].Remove("DentalPlanTables" + TablesUsed);
                        }
                        FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                        TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;
                        if (WriteCount % 3 == 0)
                        {
                            AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 7;
                            RemainingBenefitCount = 3;
                            ContributionStartCount = 0;
                            lstPlanTier.Clear();
                            TablesUsed += 1;
                        }
                    }
                }
            }
            if (RemainingBenefitCount != 3)
            {
                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippeRowSpan);
                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
            }


            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("DentalPlan_Client_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteVisionSectionToTemplateSummerHealth_v1(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            lstPlanTier.Clear();
            string Renewaldate = string.Empty;
            string Effectivedate = string.Empty;
            List<int> SkippedRowIndexes = new List<int>() { 2, 4 };
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();


            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int TablesUsed = 1;
            int CurrentColumnIndex = 2;
            int CurrentTableIndex = 22;
            int WriteCount = 0;
            int ColumnIncreament = 1;
            int RemainingBenefitCount = 3;
            int HeaderColumnIndex = 2;
            int ContributionStartCount = 0;
            int TotalContributionCount = 0;
            List<int> Contributions = new List<int>();
            foreach (string PlanTypeDescription in dictMap.Keys)
            {
                foreach (int key in dictMap[PlanTypeDescription].Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    Renewaldate = drPlanRow["Renewal"].ToString();
                    Effectivedate = drPlanRow["Effective"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();
                    List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                    int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        WriteCount++;
                        RemainingBenefitCount--;
                        lstPlanTier.Add(PlanTier);
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                        string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                        string AttributeValue = "";
                        string AttributeValue1 = "";

                        oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                        #region benefitcoverage merge fields

                        #region Benefit Coverage-Copay-Routine Exam-3
                        //InNetwork
                        DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CopayRoutineExamFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(3, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Copay-Routine Materials-5
                        //InNetwork
                        DataRow drBenefitValues_CopayRoutineMaterialsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CopayRoutineMaterialsFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineMaterialsFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Frequency-Routine Lenses - 6
                        //InNetwork
                        DataRow drBenefitValues_GeneralPlanInformationLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationLensesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationLensesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = "Benefit varies by type of lens. Covered every " + AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Elective-7
                        //InNetwork
                        DataRow drBenefitValues_CoveredServicesElectiveFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredServicesElectiveFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesElectiveFacility);
                        }
                        DataRow drBenefitValues_GeneralPlanInformationContactsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationContactsFacility != null)
                        {
                            AttributeValue1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationContactsFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(7, CurrentColumnIndex).Range.Text = "Elective contacts covered " + AttributeValue + " every " + AttributeValue1;
                        AttributeValue = "";
                        AttributeValue1 = "";

                        #endregion

                        #region Benefit Coverage-Frames-Retail Equivalent-Frames-8
                        //InNetwork
                        DataRow drBenefitValues_CoveredServicesFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 208 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_CoveredServicesFramesFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesFramesFacility);
                        }
                        DataRow drBenefitValues_GeneralPlanInformationFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_GeneralPlanInformationFramesFacility != null)
                        {
                            AttributeValue1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationFramesFacility);
                        }
                        oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = "Covered at " + AttributeValue + " every " + AttributeValue1;
                        AttributeValue = "";
                        AttributeValue1 = "";
                        #endregion

                        #endregion

                        CurrentColumnIndex += ColumnIncreament;
                        HeaderColumnIndex += 1;
                        List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                        TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                        WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                        ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                        int BookmarkStartIndex = (TablesUsed * 6) - 6 + 1;

                        for (int i = 0; i < ContributionStartCount; i++)
                        {
                            if (AllBookmarks["Vision"].ContainsKey("VisionContribution" + BookmarkStartIndex))      //MedicalHMODescription1  MedicalPPODescription1
                            {
                                AllBookmarks["Vision"].Remove("VisionContribution" + BookmarkStartIndex);
                            }
                            BookmarkStartIndex++;
                        }

                        if (AllBookmarks["Vision"].ContainsKey("VisionPlanTables" + TablesUsed))
                        {
                            AllBookmarks["Vision"].Remove("VisionPlanTables" + TablesUsed);
                        }

                        if (WriteCount % 3 == 0)
                        {
                            oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
                            CurrentColumnIndex = 2;
                            HeaderColumnIndex = 2;
                            CurrentTableIndex += 2;
                            RemainingBenefitCount = 3;
                            ContributionStartCount = 0;
                            lstPlanTier.Clear();
                        }
                    }
                }
            }
            if (RemainingBenefitCount != 3)
            {
                int BodyMergeStartIndex = CurrentColumnIndex - 1;
                int BodyMergeEndIndex = BodyMergeStartIndex + RemainingBenefitCount;
                int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                // Benefits
                MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                oWordDoc.Tables[CurrentTableIndex + 1].Rows[2].Delete();
            }

            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Vision_ClientName_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                }
            }

            #endregion
        }
        public void WriteContribution(Word.Document oWordDoc, Word.Application oWordApp, int ContributionStartTableIndex, string CarrierName, string SummaryName, List<int> ContributionCollection, DataSet ContributionDS)
        {
            DataTable dtblContributionValues = ContributionDS.Tables["ContributionValueTable"].Copy();
            for (int i = 0; i < dtblContributionValues.Rows.Count; i++)
            {
                double PremiumPercentageValue = 0;
                double SalaryPercentageValue = 0;
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfPremium"].ToString(), out PremiumPercentageValue);
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfSalary"].ToString(), out SalaryPercentageValue);
                if (PremiumPercentageValue > 0 || SalaryPercentageValue > 0)
                {
                    dtblContributionValues.Rows[i].Delete();
                }
            }

            foreach (int ContId in ContributionCollection)
            {
                int RowIndex = 3;
                DataRow[] Contributions = dtblContributionValues.Select("ContributionValues_Contribution = " + ContId);
                List<int> UniqueRateTierIds = new List<int>();
                if (Contributions.Count() > 0)
                {
                    foreach (DataRow ContributionItem in Contributions)
                    {
                        if (!UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                        {
                            UniqueRateTierIds.Add(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                        }
                    }
                    if (UniqueRateTierIds.Count() > 0)
                    {
                        string str = Contributions[0]["contributionFrequency"].ToString().Replace("_", " ").Replace("or","per");
                        string value = str.Replace("_", " ");  //System.Text.RegularExpressions.Regex.Replace(str, @"[_]", "-");
                        oWordDoc.Tables[ContributionStartTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (" + value + ")";
                        //oWordDoc.Tables[ContributionStartTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (" + Contributions[0]["contributionFrequency"] + ")";

                        /****** WE COMMENTED THIS CODE AS PER NICOLE REQUIREMENT Basic Blue - Issue #10 - Contribution Table description change
                        oWordDoc.Tables[ContributionStartTableIndex].Cell(2, 1).Range.Text = CarrierName + "-" + SummaryName + "-" + Contributions[0]["description"].ToString();
                        ****/
                        oWordDoc.Tables[ContributionStartTableIndex].Cell(2, 1).Range.Text = Contributions[0]["description"].ToString();

                        oWordDoc.Tables[ContributionStartTableIndex].Rows[RowIndex].Range.Copy();
                        for (int a = 1; a < UniqueRateTierIds.Count(); a++)
                        {
                            oWordDoc.Tables[ContributionStartTableIndex].Rows[oWordDoc.Tables[ContributionStartTableIndex].Rows.Count].Range.Paste();
                        }
                        foreach (DataRow ContributionItem in Contributions)
                        {
                            if (UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                            {
                                UniqueRateTierIds.Remove(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                                oWordDoc.Tables[ContributionStartTableIndex].Cell(RowIndex, 1).Range.Text = ContributionItem["contributionDescriptionWithEEIncluded"].ToString().Replace("EE", "Employee");
                                oWordDoc.Tables[ContributionStartTableIndex].Cell(RowIndex, 2).Range.Text = "$" + comFunObj.GetBenefitFormattedValue_Contribtion(ContributionItem["contributionValues_amount"].ToString());
                                RowIndex++;
                            }

                        }
                        ContributionStartTableIndex++;
                    }
                }
            }
        }
        public bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        private void AdjustCellWidth(Word.Document oWordDoc, int TableIndex, List<int> planTierCount, List<int> SkippedRowIndexes, float TableWidth)
        {
            int colCount = oWordDoc.Tables[TableIndex].Columns.Count;
            double CellWidth = TableWidth / planTierCount.Count;
            int CurrentCellStartIndex = 2;
            int CurrentCellEndIndex = 2;
            for (int i = 1; i <= planTierCount.Count; i++)
            {
                CurrentCellStartIndex = CurrentCellEndIndex;
                CurrentCellEndIndex = CurrentCellEndIndex + planTierCount[i - 1];

                oWordDoc.Tables[TableIndex].Rows[1].Cells[i + 1].Width = (float)CellWidth;
                float InnerCellWisth = (float)(CellWidth / planTierCount[i - 1]);
                for (int Row = 2; Row <= oWordDoc.Tables[TableIndex].Rows.Count; Row++)
                {
                    int TempCellIndex = CurrentCellStartIndex;
                    while (TempCellIndex < CurrentCellEndIndex)
                    {
                        if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                        {
                            if (!SkippedRowIndexes.Contains(Row))
                            {
                                oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                            }
                        }
                        else
                        {
                            oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                        }
                        TempCellIndex++;
                    }
                }
            }
        }

        public void WriteLifeADDTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> LifeADDProducts)
        {
            //int GroupTermTableIndex = 22;
            int GroupTermTableIndex = 29;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            int PlanCount = 0;
            // Write for each disctinct plan selected
            #region Mark written tables by removing from "AllBookmarks"

            int noOfTables = LifeADDProducts.Count;
            string bookmark = string.Empty;

            if (AllBookmarks["Life and AD&D"].ContainsKey("LifeandADD"))
                AllBookmarks["Life and AD&D"].Remove("LifeandADD");

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "LifeandADDPlan" + i.ToString();     // DentalPlanTables1, DentalPlanTables2 etc....
                if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                {
                    AllBookmarks["Life and AD&D"].Remove(bookmark);
                }
            }


            #endregion

            foreach (int key in dictMap.Keys)
            {
                if (LifeADDProducts.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        oWordDoc.Tables[GroupTermTableIndex].Cell(1, 1).Range.Text = Carrier + "\n" + SummaryName;

                        #region Benefit Maximum-3
                        //InNetwork
                        DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                        if (drBenefitValues_BenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(3, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Guaranteed Issue-4
                        //InNetwork
                        DataRow drBenefitValues_Guaranteed_Issue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 187").FirstOrDefault();
                        if (drBenefitValues_Guaranteed_Issue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Guaranteed_Issue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(4, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Spouse Benifit Maximum-6
                        //InNetwork
                        DataRow drBenefitValues_SpouseBenifitMaximumFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 519").FirstOrDefault();
                        if (drBenefitValues_SpouseBenifitMaximumFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseBenifitMaximumFacility);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(6, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Spouse Guaranteed Issue-7
                        //InNetwork
                        DataRow drBenefitValues_SpouseGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 518").FirstOrDefault();
                        if (drBenefitValues_SpouseGuaranteedIssue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteedIssue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(7, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Child Benefit Maximum-9
                        //InNetwork
                        DataRow drBenefitValues_ChildBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 104").FirstOrDefault();
                        if (drBenefitValues_ChildBenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildBenefitMaximum);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(9, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Child Guaranteed Issue-10
                        //InNetwork
                        DataRow drBenefitValues_ChildGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 103").FirstOrDefault();
                        if (drBenefitValues_ChildGuaranteedIssue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildGuaranteedIssue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(10, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        //AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                        GroupTermTableIndex = GroupTermTableIndex + 1;
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Life_andADandD_ClientName_" + PlanCount))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName);
                                continue;
                            }
                        }
                    }

                    #endregion
                   // GroupTermTableIndex = GroupTermTableIndex + 1;
                }
            }
        }
        public void WriteGroupLifeADDTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> GroupTermProducts)
        {
            int GroupTermTableIndex = 31;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            int PlanCount = 0;
            #region Mark written tables by removing from "AllBookmarks"

            int noOfTables = GroupTermProducts.Count;
            string bookmark = string.Empty;

            if (AllBookmarks["Life and AD&D"].ContainsKey("Group_term_life_ins_Bookmark"))
                AllBookmarks["Life and AD&D"].Remove("Group_term_life_ins_Bookmark");

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "GroupTermLife" + i.ToString();     // DentalPlanTables1, DentalPlanTables2 etc....
                if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                {
                    AllBookmarks["Life and AD&D"].Remove(bookmark);
                }
            }

            #endregion

            foreach (int key in dictMap.Keys)
            {
                if (GroupTermProducts.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        oWordDoc.Tables[GroupTermTableIndex].Cell(1, 1).Range.Text = Carrier + "\n" + SummaryName;

                        #region Benefit Maximum-3
                        //InNetwork
                        DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                        if (drBenefitValues_BenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(3, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Guaranteed Issue-4
                        //InNetwork
                        DataRow drBenefitValues_Guaranteed_Issue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 187").FirstOrDefault();
                        if (drBenefitValues_Guaranteed_Issue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Guaranteed_Issue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(4, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Spouse Benifit Maximum-6
                        //InNetwork
                        DataRow drBenefitValues_SpouseBenifitMaximumFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 519").FirstOrDefault();
                        if (drBenefitValues_SpouseBenifitMaximumFacility != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseBenifitMaximumFacility);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(6, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Spouse Guaranteed Issue-7
                        //InNetwork
                        DataRow drBenefitValues_SpouseGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 518").FirstOrDefault();
                        if (drBenefitValues_SpouseGuaranteedIssue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteedIssue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(7, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Child Benefit Maximum-9
                        //InNetwork
                        DataRow drBenefitValues_ChildBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 104").FirstOrDefault();
                        if (drBenefitValues_ChildBenefitMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildBenefitMaximum);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(9, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Your Child Guaranteed Issue-10
                        //InNetwork
                        DataRow drBenefitValues_ChildGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 103").FirstOrDefault();
                        if (drBenefitValues_ChildGuaranteedIssue != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildGuaranteedIssue);
                        }
                        oWordDoc.Tables[GroupTermTableIndex].Cell(10, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                       // AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                        GroupTermTableIndex = GroupTermTableIndex + 1;
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Term_Life_Insurance_ClientName_" + PlanCount))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName);
                                continue;
                            }
                        }
                    }

                    #endregion
                    //GroupTermTableIndex = GroupTermTableIndex + 1;
                }
                // ContrbutionTableIndex = ContrbutionTableIndex + 2;
            }
        }
        public void WriteADDandDInsuranceTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> ADDProducts)
        {
            int ADDandDTableIndex = 33;

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

            int PlanCount = 0;
            int GroupPlanCount = ADDProducts.Count;
            // Write for each disctinct plan selected

            #region Mark written tables by removing from "AllBookmarks"
            int noOfTables = ADDProducts.Count;
            string bookmark = string.Empty;

            if (AllBookmarks["Life and AD&D"].ContainsKey("ADD_and_D_Bookmark"))
                AllBookmarks["Life and AD&D"].Remove("ADD_and_D_Bookmark");

            for (int i = 1; i <= noOfTables; i++)
            {
                bookmark = "ADDandD" + i.ToString();     // DentalPlanTables1, DentalPlanTables2 etc....
                if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                {
                    AllBookmarks["Life and AD&D"].Remove(bookmark);
                }
            }


            #endregion
            foreach (int key in dictMap.Keys)
            {
                if (ADDProducts.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        oWordDoc.Tables[ADDandDTableIndex].Cell(1, 1).Range.Text = Carrier + "\n" + SummaryName;
                        #region
                        //InNetwork
                        DataRow drBenefitValues_BenefitAmountEmployee = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 69").FirstOrDefault();
                        if (drBenefitValues_BenefitAmountEmployee != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitAmountEmployee);
                        }
                        oWordDoc.Tables[ADDandDTableIndex].Cell(2, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion
                        //AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                        ADDandDTableIndex = ADDandDTableIndex + 1;
                    }

                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("AccidentalDeathandAccidentalDeathandDisIns_ClientName_1"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName);
                                continue;
                            }

                        }
                    }

                    #endregion
                    //ADDandDTableIndex = ADDandDTableIndex + 1;
                }
            }
        }
        public void WriteVoluntaryLifeADDandDSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, List<int> VoluntoryLifeADD, List<int> VoluntoryLife, List<int> VolADD)
        {
            string Carrier = string.Empty;
            string bookmark = string.Empty;

            if (VoluntoryLifeADD.Count > 0 || VoluntoryLife.Count > 0 || VolADD.Count > 0)
            {
                bookmark = "VoluntaryLife";
                if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                {
                    AllBookmarks["Voluntary Life"].Remove(bookmark);
                }
            }

            foreach (int VolLifeADDProduct in VoluntoryLifeADD)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + VolLifeADDProduct.ToString()).FirstOrDefault();
                Carrier = drPlanRow["Carrier"].ToString();
                bookmark = "VoluntaryLifeDescription1";
                int BenefitSummaryID = int.Parse(drPlanRow["SummaryId"].ToString());
                if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                {
                    AllBookmarks["Voluntary Life"].Remove(bookmark);
                }
                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("Life_and_AD&D_Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }

                    }
                }

                #endregion
            }

            foreach (int VolLifeProduct in VoluntoryLife)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + VolLifeProduct.ToString()).FirstOrDefault();
                Carrier = drPlanRow["Carrier"].ToString();
                bookmark = "VoluntaryLifeDescription2";
                int BenefitSummaryID = int.Parse(drPlanRow["SummaryId"].ToString());
                if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                {
                    AllBookmarks["Voluntary Life"].Remove(bookmark);
                }
                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("Vol_Life_Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }

                    }
                }

                #endregion
            }

            foreach (int VolADDProduct in VolADD)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + VolADDProduct.ToString()).FirstOrDefault();
                Carrier = drPlanRow["Carrier"].ToString();
                bookmark = "VoluntaryLifeDescription3";
                int BenefitSummaryID = int.Parse(drPlanRow["SummaryId"].ToString());
                if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                {
                    AllBookmarks["Voluntary Life"].Remove(bookmark);
                }
                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("Vol_AD&D_Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }

                    }
                }

                #endregion
            }
        }
        public void WriteShortTermDisabilityDSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> STDProducts)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            int PlanCount = 0;
            string Elimination_Period_Accident = string.Empty;
            string weekly_benefit_Maximum = string.Empty;
            string Benefit_Percentage = string.Empty;
            string Maximum_Period_of_Payment = string.Empty;

            int STDPlanCount = STDProducts.Count;
            // Write for each disctinct plan selected
            foreach (int key in dictMap.Keys)
            {
                if (STDProducts.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;

                    List<int> BenefitSummarries = dictMap[key];
                    string PolicyNumber = "";

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        // BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        DataRow drBenefitValues_Elimination_Period_Accident = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Elimination_Period_Accident != null)
                        {
                            Elimination_Period_Accident = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period_Accident);
                        }
                        DataRow drBenefitValues_weekly_benefit_Maximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_weekly_benefit_Maximum != null)
                        {
                            weekly_benefit_Maximum = comFunObj.GetBenefitFormattedValue(drBenefitValues_weekly_benefit_Maximum);
                        }
                        DataRow drBenefitValues_Benefit_Percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Percentage != null)
                        {
                            Benefit_Percentage = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Percentage);
                        }
                        DataRow drBenefitValues_Period_of_Payment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Period_of_Payment != null)
                        {
                            Maximum_Period_of_Payment = comFunObj.GetBenefitFormattedValue(drBenefitValues_Period_of_Payment);
                            if (drBenefitValues_Period_of_Payment["UOM"].ToString() == "text")
                            {
                                drBenefitValues_Period_of_Payment["UOM"] = "";
                            }
                            Maximum_Period_of_Payment = (Maximum_Period_of_Payment.Trim() + " " + drBenefitValues_Period_of_Payment["UOM"].ToString().Trim().Replace("_", " ")).Trim();
                        }


                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                //STD_ClientName_1

                                if (fieldName.Contains("STD_ClientName_1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ClientName);
                                    continue;
                                }

                                if (fieldName.Contains("STD_Carrier_1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }
                                if (fieldName.Contains("STD_Policy_Number_1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(PolicyNumber);
                                    continue;
                                }

                                if (fieldName.Contains("General_Plan_STD_Information_Elimination_Period_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Elimination_Period_Accident))
                                    {
                                        oWordApp.Selection.TypeText(Elimination_Period_Accident);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_STD_Info_Benefit_Percentage_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Percentage))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Percentage);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_STD_Information_Maximum_PeriodofPayment_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                    {
                                        oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_STD_Info_Weekly_Benefit_Maximum_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(weekly_benefit_Maximum))
                                    {
                                        oWordApp.Selection.TypeText(weekly_benefit_Maximum);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }


                            }
                        }

                        #endregion

                        break;
                    }
                }
            }
        }
        public void WriteVoluntaryShortTermDisabilitySectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> VolSTDProducts)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            int PlanCount = 0;
            string Elimination_Period = string.Empty;
            string Weekly_benefit = string.Empty;
            string Benefit_Percentage = string.Empty;
            string Maximum_Period_of_Payment = string.Empty;
            string bookmark = string.Empty;

            int STDPlanCount = VolSTDProducts.Count;
            // Write for each disctinct plan selected

            #region Voluntary STD offering

            if (VolSTDProducts.Count > 0)
            {
                bookmark = "VoluntaryDisability";
                if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                {
                    AllBookmarks["Voluntary Life"].Remove(bookmark);
                }
            }
            #endregion

            foreach (int key in dictMap.Keys)
            {
                if (VolSTDProducts.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;

                    List<int> BenefitSummarries = dictMap[key];
                    string PolicyNumber = "";

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        // BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        DataRow drBenefitValues_Elimination_Period = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Elimination_Period != null)
                        {
                            Elimination_Period = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period);
                        }
                        DataRow drBenefitValues_Benefit_Percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Percentage != null)
                        {
                            Benefit_Percentage = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Percentage);
                        }
                        DataRow drBenefitValues_Weekly_benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Weekly_benefit != null)
                        {
                            Weekly_benefit = comFunObj.GetBenefitFormattedValue(drBenefitValues_Weekly_benefit);
                        }
                        DataRow drBenefitValues_Period_of_Payment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Period_of_Payment != null)
                        {
                            Maximum_Period_of_Payment = comFunObj.GetBenefitFormattedValue(drBenefitValues_Period_of_Payment);
                            if (drBenefitValues_Period_of_Payment["UOM"].ToString() == "text")
                            {
                                drBenefitValues_Period_of_Payment["UOM"] = "";
                            }
                            Maximum_Period_of_Payment = (Maximum_Period_of_Payment.Trim() + " " + drBenefitValues_Period_of_Payment["UOM"].ToString().Trim().Replace("_", " ")).Trim();
                        }


                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                //STD_ClientName_1

                                if (fieldName.Contains("Vol_STD_Client_1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ClientName);
                                    continue;
                                }

                                if (fieldName.Contains("Vol_STD_Insurance_Carrier_1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }


                                if (fieldName.Contains("General_Vol_STD_Plan_Information_Elimination_Period_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Elimination_Period))
                                    {
                                        oWordApp.Selection.TypeText(Elimination_Period);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Vol_STD_Plan_Information_Benefit_Percentage_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Percentage))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Percentage);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Vol_STD_Plan_Information_Maximum_Period_of_Payment_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                    {
                                        oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Vol_STD_Plan_Information–Weekly_Benefit_Maximum_1"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Weekly_benefit))
                                    {
                                        oWordApp.Selection.TypeText(Weekly_benefit);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                            }
                        }

                        #endregion

                        break;
                    }
                }
            }
        }
        public void WriteLongTermDisabilityDSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> LTD)
        {
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            int PlanCount = 0;
            string Elimination_Period = string.Empty;
            string Monthly_Benefit = string.Empty;
            string Benefit_Percentage = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                if (LTD.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;

                    List<int> BenefitSummarries = dictMap[key];
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {

                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        //Summary_Name = drPlanBenefitRow["SummaryName"].ToString();

                        DataRow drBenefitValues_Benefit_Percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Percentage != null)
                        {
                            Benefit_Percentage = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Percentage);
                        }

                        DataRow drBenefitValues_Monthly_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Monthly_Benefit != null)
                        {
                            Monthly_Benefit = comFunObj.GetBenefitFormattedValue(drBenefitValues_Monthly_Benefit);
                        }

                        DataRow drBenefitValues_Elimination_Period = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Elimination_Period != null)
                        {
                            Elimination_Period = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period);
                        }

                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("LTD_ClientName_1"))  //LTD Client Name
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ClientName);
                                    continue;
                                }
                                if (fieldName.Contains("LTD_Carrier_1"))  //LTD Carrier Name
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }
                                if (fieldName.Contains("General_LTD_Plan_Information_Benefit_Percentage_1"))  //benfit percentage 
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Percentage))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Percentage);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("General_Plan_LTD_Information_Monthly_Benefit_Maximum_1"))  //monthly benefit
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Monthly_Benefit))
                                    {
                                        oWordApp.Selection.TypeText(Monthly_Benefit);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_LTD_Information_Elimination_Period_1"))  //Elimination Period
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Elimination_Period))
                                    {
                                        oWordApp.Selection.TypeText(Elimination_Period);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }


                            }
                        }
                    }

                        #endregion
                }

            }
        }
        public void WriteVoluntoryLongTermDisabilityDSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> VoluntoryLTD)
        {
            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            int PlanCount = 0;
            string Elimination_Period = string.Empty;
            string Monthly_Benefit = string.Empty;
            string Benefit_Percentage = string.Empty;
            string Weekly_benefit = string.Empty;


            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            //#region Voluntary STD offering

            //if (VoluntoryLTD.Count > 0)
            //{
            //    bookmark = "VoluntaryDisability";
            //    if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
            //    {
            //        AllBookmarks["Voluntary Life"].Remove(bookmark);
            //    }
            //}
            //#endregion

            foreach (int key in dictMap.Keys)
            {
                if (VoluntoryLTD.Contains(key))
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;

                    List<int> BenefitSummarries = dictMap[key];

                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {

                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();

                        DataRow drBenefitValues_Benefit_Percentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit_Percentage != null)
                        {
                            Benefit_Percentage = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit_Percentage);
                        }

                        DataRow drBenefitValues_Elimination_Period = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Elimination_Period != null)
                        {
                            Elimination_Period = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period);
                        }

                        DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_Benefit != null)
                        {
                            Monthly_Benefit = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit);
                        }


                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("Vol_LTD_Client_1"))  //LTD Client Name
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ClientName);
                                    continue;
                                }
                                if (fieldName.Contains("Vol_LTD_Insurance_Carrier_1"))  //LTD Carrier Name
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Carrier);
                                    continue;
                                }
                                if (fieldName.Contains("General_Vol_LTD_Plan_Information_Benefit_Percentage_1"))  //Maximum Monthly Benefit
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Benefit_Percentage))
                                    {
                                        oWordApp.Selection.TypeText(Benefit_Percentage);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_Vol_LTD_Information_Monthly_Benefit_Maximum_1"))  //Maximum Monthly Benefit
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Monthly_Benefit))
                                    {
                                        oWordApp.Selection.TypeText(Monthly_Benefit);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("General_Plan_LTD_Information–Elimination_Period_1"))  //Elimination Period
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Elimination_Period))
                                    {
                                        oWordApp.Selection.TypeText(Elimination_Period);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }


                            }
                        }
                    }

                        #endregion
                }

            }
        }
        public void WriteHRASectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList, Dictionary<int, List<int>> dictMap)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            foreach (object item in HRABenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string HRA_Tier_1 = string.Empty;
            string HRA_Tier_2 = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;

            #region Mark written tables by removing from "AllBookmarks"
            string bookmark = string.Empty;

            if (AllBookmarks["HRA"].ContainsKey("HRA"))
                AllBookmarks["HRA"].Remove("HRA");

            #endregion

            // Write for each disctinct plan selected

            foreach (int key in dictMap.Keys)
            {
                // if (HRAProducts.Contains(key))
                // {

                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    DataRow drBenefitValues_HRA_Tier_1 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 238 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_HRA_Tier_1 != null)
                    {
                        HRA_Tier_1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_HRA_Tier_1);
                    }
                    DataRow drBenefitValues_HRA_Tier_2 = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 239 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_HRA_Tier_2 != null)
                    {
                        HRA_Tier_2 = comFunObj.GetBenefitFormattedValue(drBenefitValues_HRA_Tier_2);
                    }
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("HRA_CarrierName_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("HRA_Policy_Number_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                        if (fieldName.Contains("HRA_ClientName_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }

                        if (fieldName.Contains("HRA Tier One"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_1))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("HRA Tier Two"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(HRA_Tier_2))
                            {
                                oWordApp.Selection.TypeText(HRA_Tier_2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }

                #endregion
                // }
            }
        }
        public void WriteFSASectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string administration_service_medicalspending = string.Empty;
            string administration_service_DependentCare = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            #region Mark written tables by removing from "AllBookmarks"
            string bookmark = string.Empty;

            if (AllBookmarks["FSA"].ContainsKey("FSA"))
                AllBookmarks["FSA"].Remove("FSA");

            #endregion

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    #region Benefit Coverage - Medical Spending
                    //InNetwork

                    DataRow drBenefitValues_medicalspending = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 354 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_medicalspending != null)
                    {
                        administration_service_medicalspending = comFunObj.GetBenefitFormattedValue(drBenefitValues_medicalspending);
                    }

                    #endregion
                    #region Benefit Coverage-Dependant Care
                    //InNetwork
                    DataRow drBenefitValues_DependantCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 150 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_DependantCare != null)
                    {
                        administration_service_DependentCare = comFunObj.GetBenefitFormattedValue(drBenefitValues_DependantCare);
                    }

                    #endregion
                }

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("FSA_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("FSA_Policy_Number_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(PolicyNumber);
                            continue;
                        }
                        if (fieldName.Contains("FSA_ClientName_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }

                        if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(administration_service_medicalspending))
                            {
                                oWordApp.Selection.TypeText(administration_service_medicalspending);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(administration_service_DependentCare))
                            {
                                oWordApp.Selection.TypeText(administration_service_DependentCare);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }

                #endregion
            }
        }
        public void WriteEAPSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            #region Mark written tables by removing from "AllBookmarks"
            string bookmark = string.Empty;

            if (AllBookmarks["EAP"].ContainsKey("EAP"))
                AllBookmarks["EAP"].Remove("EAP");

            #endregion

            foreach (int key in dictMap.Keys)
            {

                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("EAP_Carrier_Name_" + PlanCount))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier);
                            continue;
                        }
                        if (fieldName.Contains("Company_Name_" + PlanCount))  //Company Name
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                    }
                }

                #endregion

            }
        }
        public void WriteHSASectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            string Max_Annual_Contribution_Individual1 = " ";
            string Max_Annual_Contribution_Family1 = " ";
            string FirstMedicalPlanRenewalYear = string.Empty;
            string value = "";

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            int PlanCount = 0;
            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected



            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;
                List<int> BenefitSummarries = dictMap[key];
                int AttributeValueColumnIndex = 2;
                // Write for each Benefit Summary selected
                int BenefitSummaryCount = 0;
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    string AttributeValue = "";
                    BenefitSummaryCount = BenefitSummaryCount + 1;
                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                    string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                    for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                    {
                        //if (PlanInfoTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.MedicalLOC.ToLower())
                        //{
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            FirstMedicalPlanRenewalYear = PlanTable.Rows[rowindex]["Effective"].ToString();
                            break;
                        }
                    }

                    //  oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                    #region Annual Deductible Individual - 4
                    //In Network
                    DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 635").FirstOrDefault();
                    if (drBenefitValues_InNetworkIndividual != null)
                    {
                        Max_Annual_Contribution_Individual1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                    }

                    DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 636").FirstOrDefault();
                    if (drBenefitValues_OutNetworkIndividual != null)
                    {
                        Max_Annual_Contribution_Family1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                    }
                    #endregion

                    AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                }



                #region merge fields
                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Delete HSA"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                        }
                        if (fieldName.Contains("HSA_Carrier_1"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Carrier))
                            {
                                oWordApp.Selection.TypeText(Carrier);
                            }
                            continue;
                        }
                        if (fieldName.Contains("Update_IRS_Employee_equal_to_Medical_Renewal_Plan_Year"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual1))
                            {
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Update_IRS_Family_equal_to_Medical_Renewal_Plan_Year"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Max_Annual_Contribution_Family1))
                            {
                                oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("First Medical Plan Renewal Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToDateTime(FirstMedicalPlanRenewalYear.ToString()).Year.ToString());
                            continue;
                        }
                    }
                }

                #endregion

            }

        }

        public void WriteHeaderSectionSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact, DataTable dtOfficeAddress)
        {
            #region Variable declaration
            int iTotalFields = 0;
            string name = string.Empty;
            string FirstName = string.Empty;
            string LastName = string.Empty;
            string title = string.Empty;
            #endregion

            #region Write Table of Account Contacts

            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    name = ContactList[i].Name;
                                    FirstName = ContactList[i].First_Name;
                                    LastName = ContactList[i].Last_Name;
                                }
                                else
                                {
                                    name = " ";
                                }

                                if (ContactList[i].Title != null)
                                {
                                    title = ContactList[i].Title;
                                }
                                else
                                {
                                    title = " ";
                                }
                            }
                        }
                    }
                }
            }
            #endregion

            #region MergeField

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Msg_Client_1"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                        continue;
                    }

                    if (fieldName.Contains("Client_Contact_First_Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(FirstName))
                        {
                            oWordApp.Selection.TypeText(FirstName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                    if (fieldName.Contains("Client_Contact_Last_Name"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(LastName))
                        {
                            oWordApp.Selection.TypeText(LastName);
                        }
                        else
                        {
                            myMergeField.Delete();
                        }
                        continue;
                    }

                }
            }
            #endregion
        }
        public void WriteVoluntaryDisabilityOfferingSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {

            DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            List<string> lstInNetworkColumnID = new List<string>();
            List<string> lstOutNetworkColumnID = new List<string>();
            foreach (object item in MedicalBenefitColumnIdList)
            {
                lstInNetworkColumnID.Add(item.ToString());
            }
            foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            {
                lstOutNetworkColumnID.Add(item.ToString());
            }

            int PlanCount = 0;
            string Elimination_Period = string.Empty;
            string Elimination_Period_Sickness = string.Empty;
            string Monthly_Benefit = string.Empty;
            string Maximum_Period_of_Payment = string.Empty;
            string Summary_Name = string.Empty;

            bool isVolDisOffer_Selected = false;
            bool isVolSTD_Selected = false;
            bool isVolLTD_Selected = false;
            string planType = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
            {
                if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                {
                    if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                    {
                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.STDPlanType.Trim().ToLower())
                        {
                            isVolSTD_Selected = true;

                            string bookmark = "VolSTDInsurance";
                            if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                            {
                                AllBookmarks["Voluntary Life"].Remove(bookmark);
                            }

                            planType = cv.VoluntaryLifeADD.ToLower().Trim().ToLower();
                        }
                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LTDPlanType.Trim().ToLower())
                        {
                            isVolLTD_Selected = true;

                            string bookmark = "VolLTDInsurance";
                            if (AllBookmarks["Voluntary Life"].ContainsKey(bookmark))
                            {
                                AllBookmarks["Voluntary Life"].Remove(bookmark);
                            }

                            planType = cv.VoluntaryLifeADD.ToLower().Trim().ToLower();
                        }
                    }
                }
            }



            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                List<int> BenefitSummarries = dictMap[key];
                int BenefitSummaryCount = 0;

                string PolicyNumber = "";
                foreach (int BenefitSummaryID in BenefitSummarries)
                {
                    if (PlanCount > 1)
                    {
                        BenefitSummaryCount = 2;
                    }
                    else
                    {
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                    }

                    DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                    PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                    Summary_Name = drPlanBenefitRow["SummaryName"].ToString();

                    DataRow drBenefitValues_Elimination_Period = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Elimination_Period != null)
                    {
                        //isVolLife_Selected = true;
                        Elimination_Period = comFunObj.GetBenefitFormattedValue(drBenefitValues_Elimination_Period);
                    }

                    DataRow drBenefitValues_Benefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Benefit != null)
                    {
                        //isVolLifeAndVolLifeADDD_Selected = true;
                        Monthly_Benefit = comFunObj.GetBenefitFormattedValue(drBenefitValues_Benefit);
                    }
                    DataRow drBenefitValues_Period_of_Payment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 141 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                    if (drBenefitValues_Period_of_Payment != null)
                    {
                        Maximum_Period_of_Payment = comFunObj.GetBenefitFormattedValue(drBenefitValues_Period_of_Payment);
                    }



                    #region MergeField

                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            #region  Voluntay Disability offering STD section

                            if (fieldName.Contains("Vol_STD_Client_" + BenefitSummaryCount))  //LTD Client Name
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ClientName);
                                continue;
                            }
                            if (fieldName.Contains("Vol_STD_Insurance_Carrier_" + BenefitSummaryCount))  //LTD Carrier Name //Vol_STD_Insurance_Carrier_1
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Carrier);
                                continue;
                            }

                            if (fieldName.Contains("General_Vol_STD_Plan_Information_Benefit_Percentage_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Monthly_Benefit))
                                {
                                    oWordApp.Selection.TypeText(Monthly_Benefit);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("General_Vol_STD_Plan_Information_Elimination_Period_" + BenefitSummaryCount))  //Elimination Period //General_Vol_STD_Plan_Information_Elimination_Period_1
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Elimination_Period))
                                {
                                    oWordApp.Selection.TypeText(Elimination_Period);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General_Vol_STD_Plan_Information_Maximum_Period_of_Payment_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                {
                                    oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("LTD_Policy_Number_" + BenefitSummaryCount)) //LTD Policy Number
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(PolicyNumber);
                                continue;
                            }
                            if (fieldName.Contains("LTD_Benefit_Summary_Name_" + BenefitSummaryCount)) //LTD Benefit Summary Name
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Summary_Name);
                                continue;
                            }
                            //General_Vol_STD_Plan_Information_Elimination_Period_1

                            #endregion

                            #region Voluntary Disability offering section(LTD)

                            if (fieldName.Contains("Vol_LTD_Client_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(ClientName))
                                {
                                    oWordApp.Selection.TypeText(ClientName);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("Vol_LTD_Insurance_Carrier_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Carrier))
                                {
                                    oWordApp.Selection.TypeText(Carrier);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            if (fieldName.Contains("General_Vol_LTD_Plan_Information_Benefit_Percentage_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Monthly_Benefit))
                                {
                                    oWordApp.Selection.TypeText(Monthly_Benefit);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General_Plan_LTD_Information–Elimination_Period_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Elimination_Period))
                                {
                                    oWordApp.Selection.TypeText(Elimination_Period);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General_Plan_Vol_LTD_Information_Monthly_Benefit_Maximum_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Monthly_Benefit))
                                {
                                    oWordApp.Selection.TypeText(Monthly_Benefit);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General_Plan_LTD_Information–Elimination_Period_" + BenefitSummaryCount))  //Maximum Monthly Benefit
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Elimination_Period))
                                {
                                    oWordApp.Selection.TypeText(Elimination_Period);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }

                            #endregion


                        }
                    }
                }

                    #endregion
            }
        }
        public void WriteChangesInBenefitElectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS)
        {
            int iTotalFields = 0;
            string RenewalDate = string.Empty;
            for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
            {
                if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                {
                    if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;
                            Word.Range rngFieldCode = myMergeField.Code;
                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();


                                if (fieldName.Contains("First Medical Plan Renewal Date"))
                                {
                                    DateTime dtRenewalDate = DateTime.Parse(PlanTable.Rows[k]["Renewal"].ToString());
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(dtRenewalDate.ToString("MM/dd/yyyy"));
                                    break; ;
                                }

                                //////if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                                //////{
                                //////    myMergeField.Select();
                                //////    oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                                //////    continue;
                                //////}

                            }
                        }
                    }
                }
            }

        }
        public void WriteHeaderandIndexSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet AccountTeamMemberDS, DataSet ProductDS, Dictionary<int, List<int>> dictMap, List<Contact> ContactList, ArrayList arrAcctContact)
        {

            //DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
            //List<string> lstInNetworkColumnID = new List<string>();
            //List<string> lstOutNetworkColumnID = new List<string>();
            //foreach (object item in MedicalBenefitColumnIdList)
            //{
            //    lstInNetworkColumnID.Add(item.ToString());
            //}
            //foreach (object item in MedicalBenefitColumnIdOutNetworkList)
            //{
            //    lstOutNetworkColumnID.Add(item.ToString());
            //}

            int PlanCount = 0;
            string administration_service_medicalspending = string.Empty;
            string administration_service_DependentCare = string.Empty;
            string AccountFirstName = string.Empty;
            string AccountLastName = string.Empty;
            string AccountFullName = string.Empty;
            string FirstMedicalPlanRenewalYear = string.Empty;

            int MedicalPlanCount = dictMap.Keys.Count;
            // Write for each disctinct plan selected

            #region Write Table of Account Contacts
            string AccountContactname = string.Empty;
            if (ContactList != null)
            {
                if (arrAcctContact.Count > 0)
                {
                    for (int j = 0; j < arrAcctContact.Count; j++)
                    {
                        for (int i = 0; i < ContactList.Count; i++)
                        {
                            if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                            {
                                if (ContactList[i].Name != null)
                                {
                                    AccountContactname = ContactList[i].Name;
                                    AccountFirstName = ContactList[i].First_Name;
                                    AccountLastName = ContactList[i].Last_Name;
                                }
                                else
                                {
                                    AccountContactname = " ";
                                }

                            }
                        }
                    }
                }
            }
            #endregion

            #region
            for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
            {
                //if (PlanInfoTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.MedicalLOC.ToLower())
                //{
                if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                {
                    FirstMedicalPlanRenewalYear = PlanTable.Rows[rowindex]["Effective"].ToString();
                    break;
                }

            }

            #endregion

            foreach (int key in dictMap.Keys)
            {
                DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                string Carrier = drPlanRow["Carrier"].ToString();

                PlanCount = PlanCount + 1;

                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }

                        if (fieldName.Contains("Index_Client_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                        if (fieldName.Contains("FName"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(AccountFirstName);
                            continue;
                        }
                        if (fieldName.Contains("LName"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(AccountLastName);
                            continue;
                        }
                        //if (fieldName.Contains("Account_Contact_Name"))
                        //{
                        //    myMergeField.Select();
                        //    oWordApp.Selection.TypeText(AccountFullName);
                        //    continue;
                        //}
                        if (fieldName.Contains("Msg_Client_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                        if (fieldName.Contains("First Medical Plan Renewal Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToDateTime(FirstMedicalPlanRenewalYear.ToString()).Year.ToString());
                            continue;
                        }

                    }
                }

                #endregion
            }
        }

        public void WriteNoticeSectionToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }

                        if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                            continue;
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteTableOfContentInformationToTemplateSummerHealth(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlAnnualLegalNotice, DropDownList ddlChipNotice, DropDownList ddlBRC, string color, DataTable PlanInfoTable, bool isAllPlansSelected)
        {
            try
            {
                string plantype = "";

                // Update Table of Content
                int contentPageNo = 5;
                int contentRowCnt = 5;

                int medicalCnt = 0;
                int dentalCnt = 0;
                int visionCnt = 0;
                int volLifeCount = 0;

                bool isGetMoreValues = false;
                bool isMedical = false;
                bool isDental = false;
                bool isVision = false;
                bool isFSA = false;
                bool isHSA = false;
                bool isHRA = false;
                bool isLife_STD_LTD = false;
                bool isSummary = false;
                bool isValueAdded = false;
                bool isPatientAdvocacy = false;
                bool isTelemedicine = false;
                bool isWorksiteProducts = false;
                bool isAddition_Benefit_Taken = false;
                bool isContact_Info_Taken = false;
                bool isBRC = false;
                bool isRequiredNotification = false;
                bool isContributionTableOnNextPage = false;

                // Create the arraylist for the headers other than default headers in the table
                ArrayList arrTOC = new ArrayList();
                arrTOC.Add("Get More Value From Your Plans");
                arrTOC.Add("Medical Benefits");
                arrTOC.Add("Dental Benefits");
                arrTOC.Add("Vision Benefits");
                arrTOC.Add("Health and Dependent Care Spending Accounts");
                arrTOC.Add("Health Savings Account (HSA)"); // New
                arrTOC.Add("Health Reimbursement Account (HRA)"); // New
                arrTOC.Add("Income Protection Benefit");
                arrTOC.Add("Summary of Coverage For Voluntary Life Insurance");
                arrTOC.Add("Value-added Programs and Services");
                arrTOC.Add("Patient Advocacy Program");  // New
                arrTOC.Add("Telemidicine"); // New
                arrTOC.Add("Worksite Products"); // New
                arrTOC.Add("Additional Benefits for Eligible Employees");
                arrTOC.Add("Contact Numbers & Website Links");
                arrTOC.Add("The Benefit Resource Center");
                arrTOC.Add("Required Notifications");

                // Check for the number of medical, dental and vision plans so that we can adjust the page numbers accordingly
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    if (plantype == cv.MedicalLOC)
                    {
                        medicalCnt++;
                    }
                    if (plantype == cv.DentalLOC)
                    {
                        dentalCnt++;
                    }
                    if (plantype == cv.VisionLOC)
                    {
                        visionCnt++;
                    }
                    if (plantype == cv.VoluntaryLifeADDLOC)
                    {
                        volLifeCount++;
                    }
                }

                // If the contribution table goes to next page 
                if (oWordDoc.Tables[4].Rows.Count > 22)
                {
                    contentPageNo = 6;
                    isContributionTableOnNextPage = true;
                }

                int characterLength = 0;
                int lengthDifference = 0;
                string tmpVar = string.Empty;

                DataTable dtPlanType = new DataTable();
                dtPlanType = PlanTable.DefaultView.ToTable(true, "PlanType");

                for (int j = 0; j < arrTOC.Count; j++)
                {
                    for (int i = 0; i < dtPlanType.Rows.Count; i++)
                    {
                        plantype = dtPlanType.Rows[i]["PlanType"].ToString();

                        // For Get More Value From Your Plans
                        #region For Get More Value From Your Plans page Number
                        if (j == 0)
                        {
                            if (isGetMoreValues == false)
                            {
                                oWordDoc.Tables[1].Rows.Add();

                                // Calculate the character length for selected heading
                                characterLength = arrTOC[0].ToString().Length;
                                lengthDifference = 69 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 69 - characterLength;
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 69 - characterLength;
                                    oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                                }

                                tmpVar = arrTOC[0].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isGetMoreValues = true;
                                break;
                            }
                            continue;
                        }
                        #endregion

                        //// For Medical
                        //#region For Medical page Number
                        //if (j == 1)
                        //{
                        //    if (plantype == cv.MedicalLOC)
                        //    {
                        //        if (isMedical == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();

                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[1].ToString().Length;
                        //            lengthDifference = 81 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 81 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 81 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[1].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;

                        //            // Based on the number of medical plans selected change the page number
                        //            if (medicalCnt == 1)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 8;
                        //                else
                        //                    contentPageNo = 7;
                        //            }
                        //            else if (medicalCnt == 2)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 9;
                        //                else
                        //                    contentPageNo = 8;
                        //            }
                        //            else if (medicalCnt == 3)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 10;
                        //                else
                        //                    contentPageNo = 9;
                        //            }
                        //            else if (medicalCnt == 4)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 11;
                        //                else
                        //                    contentPageNo = 10;
                        //            }
                        //            else if (medicalCnt == 5)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 12;
                        //                else
                        //                    contentPageNo = 11;
                        //            }
                        //            else if (medicalCnt == 6)
                        //            {
                        //                if (isContributionTableOnNextPage)
                        //                    contentPageNo = 13;
                        //                else
                        //                    contentPageNo = 12;
                        //            }
                        //            isMedical = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Dental
                        //#region For Detal page Number
                        //if (j == 2)
                        //{
                        //    if (plantype == cv.DentalLOC)
                        //    {
                        //        if (isDental == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();

                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[2].ToString().Length;
                        //            lengthDifference = 82 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 82 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 82 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[2].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;

                        //            if (dentalCnt == 3)
                        //            {
                        //                contentPageNo = contentPageNo + 6;
                        //            }
                        //            else if (dentalCnt == 2)
                        //            {
                        //                contentPageNo = contentPageNo + 4;
                        //            }
                        //            else
                        //            {
                        //                contentPageNo = contentPageNo + 2;
                        //            }
                        //            isDental = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Vision
                        //#region For Vision Page Number
                        //if (j == 3)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.VisionLOC)
                        //    {
                        //        if (isVision == false)
                        //        {
                        //            oWordDoc.Tables[3].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[3].ToString().Length;
                        //            lengthDifference = 83 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 83 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 83 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[3].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            if (visionCnt == 2)
                        //            {
                        //                contentPageNo = contentPageNo + 2;
                        //            }
                        //            else
                        //            {
                        //                contentPageNo++;
                        //            }
                        //            isVision = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For FSA
                        //#region For FSA Page Number
                        //if (j == 4)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.FSAPlanType_CommonCriteria)
                        //    {
                        //        if (isFSA == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[4].ToString().Length;
                        //            lengthDifference = 58 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 58 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 58 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[4].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            contentPageNo++;
                        //            isFSA = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For HSA
                        //#region For HSA Page Number
                        //if (j == 5)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.HSAPlanType_CommonCriteria)
                        //    {
                        //        if (isHSA == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[5].ToString().Length;
                        //            lengthDifference = 72 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 72 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 72 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[5].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            contentPageNo++;
                        //            isHSA = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For HRA
                        //#region For HRA Page Number
                        //if (j == 6)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.HRAPlanType_CommonCriteria)
                        //    {
                        //        if (isHRA == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[6].ToString().Length;
                        //            lengthDifference = 64 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 64 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 64 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[6].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            contentPageNo++;
                        //            isHRA = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For if Life ADD / LTD / STD is selected (Income Protectiion Plan)
                        //#region For Income Protection Benefit Page Number
                        //if (j == 7)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (isLife_STD_LTD == false)
                        //    {
                        //        if (plantype == cv.LifeADDLOC || plantype == cv.STDPlanType_CommonCriteria || plantype == cv.LTDPlanType_CommonCriteria)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[7].ToString().Length;
                        //            lengthDifference = 74 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 74 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 74 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }
                        //            tmpVar = arrTOC[7].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;

                        //            if (isAllPlansSelected == true)
                        //            {
                        //                contentPageNo = contentPageNo + 2;
                        //            }
                        //            else
                        //            {
                        //                contentPageNo++;
                        //            }
                        //            isLife_STD_LTD = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Voluntary Life
                        //#region For Voluntary Life Page Number
                        //if (j == 8)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.VoluntaryLifeADDLOC)
                        //    {
                        //        if (isSummary == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[8].ToString().Length;
                        //            lengthDifference = 57 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 57 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 57 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[8].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            if (volLifeCount == 2)
                        //            {
                        //                contentPageNo = contentPageNo + 2;
                        //            }
                        //            else
                        //            {
                        //                contentPageNo++;
                        //            }
                        //            isSummary = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For EAP
                        //#region For EAP Page Number
                        //if (j == 9)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (plantype == cv.EAPPlanType_CommonCriteria)
                        //    {
                        //        if (isValueAdded == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[9].ToString().Length;
                        //            lengthDifference = 67 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 67 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 67 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }

                        //            tmpVar = arrTOC[9].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            contentPageNo++;
                        //            isValueAdded = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// PATIENT ADVOCACY PROGRAM
                        //#region For Patient Advocacy Program Page Number
                        //if (j == 10)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (PlanInfoTable != null)
                        //    {
                        //        for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                        //        {
                        //            if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        //            {
                        //                if (isPatientAdvocacy == false)
                        //                {
                        //                    oWordDoc.Tables[1].Rows.Add();
                        //                    // Calculate the character length for selected heading
                        //                    characterLength = arrTOC[10].ToString().Length;
                        //                    lengthDifference = 73 - characterLength;

                        //                    if (contentPageNo.ToString().Length > 1)
                        //                    {
                        //                        //lengthDifference = 73 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //                    }
                        //                    else
                        //                    {
                        //                        //lengthDifference = 73 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //                    }

                        //                    tmpVar = arrTOC[10].ToString();

                        //                    // Append "." at the end of the header and after that the page number
                        //                    for (int len = 0; len < lengthDifference; len++)
                        //                    {
                        //                        tmpVar = tmpVar + ".";
                        //                    }

                        //                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //                    contentRowCnt++;
                        //                    contentPageNo++;
                        //                    isPatientAdvocacy = true;
                        //                    break;
                        //                }
                        //            }
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// TELEMEDICINE
                        //#region For Telemedicine Page Number
                        //if (j == 11)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (PlanInfoTable != null)
                        //    {
                        //        for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                        //        {
                        //            if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        //            {
                        //                if (isTelemedicine == false)
                        //                {
                        //                    oWordDoc.Tables[1].Rows.Add();
                        //                    // Calculate the character length for selected heading
                        //                    characterLength = arrTOC[11].ToString().Length;
                        //                    lengthDifference = 83 - characterLength;

                        //                    if (contentPageNo.ToString().Length > 1)
                        //                    {
                        //                        //lengthDifference = 83 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //                    }
                        //                    else
                        //                    {
                        //                        //lengthDifference = 83 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //                    }

                        //                    tmpVar = arrTOC[11].ToString();

                        //                    // Append "." at the end of the header and after that the page number
                        //                    for (int len = 0; len < lengthDifference; len++)
                        //                    {
                        //                        tmpVar = tmpVar + ".";
                        //                    }

                        //                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //                    contentRowCnt++;
                        //                    contentPageNo++;
                        //                    isTelemedicine = true;
                        //                    break;
                        //                }
                        //            }
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// WORKSITE PRODUCTS
                        //#region For Worksite Products Page Number
                        //if (j == 12)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (PlanInfoTable != null)
                        //    {
                        //        for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                        //        {
                        //            if ((Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        //                || (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        //                || (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness))
                        //            {
                        //                if (isWorksiteProducts == false)
                        //                {
                        //                    oWordDoc.Tables[1].Rows.Add();
                        //                    // Calculate the character length for selected heading
                        //                    characterLength = arrTOC[12].ToString().Length;
                        //                    lengthDifference = 79 - characterLength;

                        //                    if (contentPageNo.ToString().Length > 1)
                        //                    {
                        //                        //lengthDifference = 79 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //                    }
                        //                    else
                        //                    {
                        //                        //lengthDifference = 79 - characterLength;
                        //                        oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //                    }

                        //                    tmpVar = arrTOC[12].ToString();

                        //                    // Append "." at the end of the header and after that the page number
                        //                    for (int len = 0; len < lengthDifference; len++)
                        //                    {
                        //                        tmpVar = tmpVar + ".";
                        //                    }

                        //                    oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //                    contentRowCnt++;
                        //                    contentPageNo++;
                        //                    isWorksiteProducts = true;
                        //                    break;
                        //                }
                        //            }
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Additional Benefits for Eligible Employees
                        //#region For Additionla Benefits Page Number
                        //if (j == 13)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (isAddition_Benefit_Taken == false)
                        //    {
                        //        oWordDoc.Tables[1].Rows.Add();
                        //        // Calculate the character length for selected heading
                        //        characterLength = arrTOC[13].ToString().Length;
                        //        lengthDifference = 66 - characterLength;

                        //        if (contentPageNo.ToString().Length > 1)
                        //        {
                        //            //lengthDifference = 66 - characterLength;
                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //        }
                        //        else
                        //        {
                        //            //lengthDifference = 66 - characterLength;
                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //        }
                        //        tmpVar = arrTOC[13].ToString();

                        //        // Append "." at the end of the header and after that the page number
                        //        for (int len = 0; len < lengthDifference; len++)
                        //        {
                        //            tmpVar = tmpVar + ".";
                        //        }

                        //        oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //        contentRowCnt++;
                        //        contentPageNo++;
                        //        isAddition_Benefit_Taken = true;
                        //        break;
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Contact Information
                        //#region For Contact Information Page Number
                        //if (j == 14)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (isContact_Info_Taken == false)
                        //    {
                        //        oWordDoc.Tables[1].Rows.Add();
                        //        // Calculate the character length for selected heading
                        //        characterLength = arrTOC[14].ToString().Length;
                        //        lengthDifference = 68 - characterLength;

                        //        if (contentPageNo.ToString().Length > 1)
                        //        {
                        //            //lengthDifference = 68 - characterLength;
                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //        }
                        //        else
                        //        {
                        //            //lengthDifference = 68 - characterLength;
                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //        }
                        //        tmpVar = arrTOC[14].ToString();

                        //        // Append "." at the end of the header and after that the page number
                        //        for (int len = 0; len < lengthDifference; len++)
                        //        {
                        //            tmpVar = tmpVar + ".";
                        //        }

                        //        oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //        contentRowCnt++;
                        //        contentPageNo++;
                        //        isContact_Info_Taken = true;
                        //        break;
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For BRC
                        //#region For BRC Page Number
                        //if (j == 15)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (ddlBRC.SelectedIndex > 1)
                        //    {
                        //        if (isBRC == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[15].ToString().Length;
                        //            lengthDifference = 72 - characterLength;

                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                //lengthDifference = 72 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                //lengthDifference = 72 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }
                        //            tmpVar = arrTOC[15].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;
                        //            contentPageNo++;
                        //            isBRC = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion

                        //// For Notification (Annual Legal Notices)
                        //#region For Notification Page Number
                        //if (j == 16)
                        //{
                        //    characterLength = 0;
                        //    lengthDifference = 0;
                        //    tmpVar = "";
                        //    if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                        //    {
                        //        if (isRequiredNotification == false)
                        //        {
                        //            oWordDoc.Tables[1].Rows.Add();
                        //            // Calculate the character length for selected heading
                        //            characterLength = arrTOC[16].ToString().Length;
                        //            if (contentPageNo.ToString().Length > 1)
                        //            {
                        //                lengthDifference = 77 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                        //            }
                        //            else
                        //            {
                        //                lengthDifference = 77 - characterLength;
                        //                oWordDoc.Tables[1].Cell(contentRowCnt, 2).Range.Text = "0" + Convert.ToString(contentPageNo);
                        //            }
                        //            tmpVar = arrTOC[16].ToString();

                        //            // Append "." at the end of the header and after that the page number
                        //            for (int len = 0; len < lengthDifference; len++)
                        //            {
                        //                tmpVar = tmpVar + ".";
                        //            }

                        //            oWordDoc.Tables[1].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                        //            contentRowCnt++;

                        //            if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex > 0)
                        //            {
                        //                contentPageNo++;
                        //            }
                        //            else if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex == 0)
                        //            {
                        //                contentPageNo++;
                        //            }

                        //            if (ddlChipNotice.SelectedIndex > 0)
                        //            {
                        //                contentPageNo = contentPageNo + 2;
                        //            }

                        //            isRequiredNotification = true;
                        //            break;
                        //        }
                        //    }
                        //    continue;
                        //}
                        //#endregion
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteAdditionalProductsToTemplateSummmerHealth(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Wellness_Selected = false;
                bool is_Acc_Selected = false;
                bool is_Vol_Cancer_Selected = false;
                bool is_Vol_Cri_Ill_Selected = false;

                string Patient_Advocacy_CarrierName = string.Empty;
                string Telemedicine_CarrierName = string.Empty;
                string Wellness_CarrierName = string.Empty;
                string Critical_Illness = string.Empty;
                string Worksite_cancer = string.Empty;
                bool flagOne = false;
                bool flagTwo = false;
                bool flagThree = false;

                bool PAP = false;
                bool Tele = false;
                bool WELL = false;
                bool Worksite = false;


                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                            Patient_Advocacy_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                            PAP = true;
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                            Telemedicine_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                            Tele = true;
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Acc_Selected = true;
                            flagOne = true;
                            Worksite = true;
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Vol_Cancer_Selected = true;
                            flagThree = true;
                            Worksite_cancer = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                            Worksite = true;
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Vol_Cri_Ill_Selected = true;
                            flagTwo = true;
                            Critical_Illness = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                            Worksite = true;
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Wellness)
                        {
                            is_Wellness_Selected = true;
                            Wellness_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                            WELL = true;
                        }
                    }

                    if (PAP == false)
                    {
                        string bookmark = string.Empty;
                        DeleteIndivialBookmark(oWordDoc, "PatientAdvocacyProgram");
                    }
                    if (Tele == false)
                    {
                        string bookmark = "Telemedicine";
                        DeleteIndivialBookmark(oWordDoc, bookmark);
                    }
                    if (WELL == false)
                    {
                        string bookmark = "Wellness";
                        DeleteIndivialBookmark(oWordDoc, bookmark);
                    }
                    if (Worksite == false)
                    {
                        string bookmark = "WorksiteProductsSection";
                        DeleteIndivialBookmark(oWordDoc, bookmark);
                    }
                    if (Worksite == true)
                    {
                        if (is_Acc_Selected == false)
                        {
                            string bookmark = "WorksiteAccident";
                            DeleteIndivialBookmark(oWordDoc, bookmark);
                        }
                        if (is_Vol_Cri_Ill_Selected == false)
                        {
                            string bookmark = "WorksiteCriticalIllness";
                            DeleteIndivialBookmark(oWordDoc, bookmark);
                        }
                        if (is_Vol_Cancer_Selected == false)
                        {
                            string bookmark = "WorksiteCancer";
                            DeleteIndivialBookmark(oWordDoc, bookmark);
                        }
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("HEADING PATIENT ADVOCACY"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("PATIENT ADVOCACY");
                                continue;
                            }

                            if (fieldName.Contains("Patient Advocacy Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(Patient_Advocacy_CarrierName);
                                continue;
                            }

                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("HEADING TELEMEDICINE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("TELEMEDICINE");
                                continue;
                            }

                            if (fieldName.Contains("Telemedicine Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Telemedicine_CarrierName);
                                continue;
                            }

                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (is_Wellness_Selected == true)
                        {
                            if (fieldName.Contains("HEADING WELLNESS PROGRAM"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WELLNESS PROGRAM");
                                continue;
                            }

                            if (fieldName.Contains("Wellness Carrier Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Wellness_CarrierName);
                                continue;
                            }
                            if (fieldName.Contains("Wellness_ClientName_1"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text);
                                continue;
                            }



                            if (fieldName.Contains("Common_Wellness"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        if (is_Vol_Cri_Ill_Selected == true)
                        {
                            if (fieldName.Contains("Worksite_Products_Carrier_1"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Critical_Illness);
                                continue;
                            }

                        }
                        if (is_Vol_Cancer_Selected == true)
                        {
                            if (fieldName.Contains("Voluntary_Cancer_Carrier_Name"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Worksite_cancer);
                                continue;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteContactinformationToTemplateSummmerHealth(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor, DataSet AccountDS, List<Contact> ContactList, bool IsBRCSelected, List<BRCData> BRCList, string ClientName, DataTable dtPlanContactDetails = null)
        {
            try
            {

                int count = 37;
                List<string> lstUniquePlanTypeCarrier = new List<string>();
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                int index = 1;
                int BRCindex = 0;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;
                string BRCBookmark = "BRC";
                #region
                if (IsBRCSelected == false)
                {
                    //delete two BRC paragraphs
                    DeleteIndivialBookmark(oWordDoc, BRCBookmark);
                }
                #endregion


                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    carriername = PlanTable.Rows[i]["Carrier"].ToString();
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();

                    string lstUniquePlanTypeCarrierItem = carriername + "|" + ProductTypeDesc;
                    if (!lstUniquePlanTypeCarrier.Contains(lstUniquePlanTypeCarrierItem))
                    {
                        lstUniquePlanTypeCarrier.Add(lstUniquePlanTypeCarrierItem);
                        if (rowCnt > 2)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        var planContactFirstName = (from n in dtPlanContactDetails.AsEnumerable()
                                                    where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                    select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                        var planContactLastName = (from n in dtPlanContactDetails.AsEnumerable()
                                                   where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                   select n.Field<string>("Contact_LastName")).FirstOrDefault();

                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();



                        var Website = Convert.ToString(" | " + AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString());


                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"]); //Plant Type
                        oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(carriername);    //Carrier Name
                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(planContactPhone);
                        oWordDoc.Tables[count].Cell(rowCnt, 4).Range.Text = Convert.ToString(Website);
                        rowCnt++;
                    }

                }

                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("ContactInfoPlan_Client_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                        if (fieldName.Contains("BRCTimeZone"))
                        {
                            myMergeField.Select();

                            oWordApp.Selection.TypeText(BRCList[0].BRCDayHours);
                            continue;
                        }
                        if (fieldName.Contains("BRC_Phone_Number"))
                        {
                            myMergeField.Select();

                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                            {
                                myMergeField.Delete();
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                            }
                            continue;
                        }
                        if (fieldName.Contains("BRC_EMAIL"))
                        {
                            myMergeField.Select();

                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                            {
                                myMergeField.Delete();
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                            }
                            continue;
                        }
                        ////if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                        ////{
                        ////    myMergeField.Select();
                        ////    //oWordApp.Selection.Range.Font.Color = wdColor_font;
                        ////    oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                        ////    continue;
                        ////}

                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToSummarHealth(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string DefinationOf_eligible_Emplyee = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    DefinationOf_eligible_Emplyee = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-") + " " + Def_Eligible_Emp["EmployeeTypes_type"] + " " + Def_Eligible_Emp["EmployeeTypes_value"] + " " + Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"] + " " + Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();

                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Employee_Status"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unitofmeasure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency_Eligibility"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("UnmarriedChildToAge"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }

                    if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                    {
                        myMergeField.Select();
                        if (DefinationOf_eligible_Emplyee != string.Empty)
                            oWordApp.Selection.TypeText(DefinationOf_eligible_Emplyee);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period);
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }

        ////#region Get formating value
        ////private string GetBenefitFormattedValue(DataRow dr)
        ////{
        ////    if (dr != null)
        ////        return (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
        ////    return "";
        ////}
        ////#endregion

        #region getBookmarks
        public void getBookmarks()
        {
            AllBookmarks.Clear();

            #region Medical Bookmarks


            Dictionary<string, string> medicalBookmarks = new Dictionary<string, string>();
            medicalBookmarks.Add("MedicalPlanTables1", "MedicalPlanTables1");
            medicalBookmarks.Add("MedicalPlanTables2", "MedicalPlanTables2");
            medicalBookmarks.Add("MedicalPlanTables3", "MedicalPlanTables3");
            medicalBookmarks.Add("MedicalPlanTables4", "MedicalPlanTables4");
            medicalBookmarks.Add("MedicalPlanTables5", "MedicalPlanTables5");
            medicalBookmarks.Add("MedicalPlanTables6", "MedicalPlanTables6");

            medicalBookmarks.Add("MedicalContribution1", "MedicalContribution1");
            medicalBookmarks.Add("MedicalContribution2", "MedicalContribution2");
            medicalBookmarks.Add("MedicalContribution3", "MedicalContribution3");
            medicalBookmarks.Add("MedicalContribution4", "MedicalContribution4");
            medicalBookmarks.Add("MedicalContribution5", "MedicalContribution5");
            medicalBookmarks.Add("MedicalContribution6", "MedicalContribution6");
            medicalBookmarks.Add("MedicalContribution7", "MedicalContribution7");
            medicalBookmarks.Add("MedicalContribution8", "MedicalContribution8");
            medicalBookmarks.Add("MedicalContribution9", "MedicalContribution9");
            medicalBookmarks.Add("MedicalContribution10", "MedicalContribution10");
            medicalBookmarks.Add("MedicalContribution11", "MedicalContribution11");
            medicalBookmarks.Add("MedicalContribution12", "MedicalContribution12");
            #endregion

            #region Dental Bookmarks
            Dictionary<string, string> dentalBookmarks = new Dictionary<string, string>();
            dentalBookmarks.Add("DentalPlanTables1", "DentalPlanTables1");
            dentalBookmarks.Add("DentalPlanTables2", "DentalPlanTables2");
            dentalBookmarks.Add("DentalPlanTables3", "DentalPlanTables3");

            dentalBookmarks.Add("DentalContribution1", "DentalContribution1");
            dentalBookmarks.Add("DentalContribution2", "DentalContribution2");
            dentalBookmarks.Add("DentalContribution3", "DentalContribution3");
            dentalBookmarks.Add("DentalContribution4", "DentalContribution4");
            dentalBookmarks.Add("DentalContribution5", "DentalContribution5");
            dentalBookmarks.Add("DentalContribution6", "DentalContribution6");


            #endregion

            #region Vision Bookmarks
            Dictionary<string, string> visionBookmarks = new Dictionary<string, string>();
            visionBookmarks.Add("VisionPlanTables1", "VisionPlanTables1");
            visionBookmarks.Add("VisionPlanTables2", "VisionPlanTables2");
            visionBookmarks.Add("VisionPlanTables3", "VisionPlanTables3");

            visionBookmarks.Add("VisionContribution1", "VisionContribution1");
            visionBookmarks.Add("VisionContribution2", "VisionContribution2");
            visionBookmarks.Add("VisionContribution3", "VisionContribution3");
            visionBookmarks.Add("VisionContribution4", "VisionContribution4");
            visionBookmarks.Add("VisionContribution5", "VisionContribution5");
            visionBookmarks.Add("VisionContribution6", "VisionContribution6");

            #endregion

            #region HSA Bookmarks
            Dictionary<string, string> HSABookmarks = new Dictionary<string, string>();
            // HSABookmarks.Add("HSA", "HSA");
            // visionBookmarks.Add("Vision_Description2", "Vision_Description2");
            #endregion

            #region HRA Bookmarks
            Dictionary<string, string> HRABookmarks = new Dictionary<string, string>();
            HRABookmarks.Add("HRA", "HRA");
            #endregion

            #region FSA Bookmarks
            Dictionary<string, string> FSABookmarks = new Dictionary<string, string>();
            FSABookmarks.Add("FSA", "FSA");
            #endregion

            #region Life and AD&D Bookmarks
            Dictionary<string, string> ADDBookmarks = new Dictionary<string, string>();
            ADDBookmarks.Add("LifeandADD", "LifeandADD");
            ADDBookmarks.Add("LifeandADDPlan1", "LifeandADDPlan1");
            ADDBookmarks.Add("LifeandADDPlan2", "LifeandADDPlan2");

            ADDBookmarks.Add("Group_term_life_ins_Bookmark", "Group_term_life_ins_Bookmark");
            ADDBookmarks.Add("GroupTermLife1", "GroupTermLife1");
            ADDBookmarks.Add("GroupTermLife2", "GroupTermLife2");

            ADDBookmarks.Add("ADD_and_D_Bookmark", "ADD_and_D_Bookmark");
            ADDBookmarks.Add("ADDandD1", "ADDandD1");
            ADDBookmarks.Add("ADDandD2", "ADDandD2");

            #endregion

            #region Voluntary Life and AD&D Bookmarks
            Dictionary<string, string> VolLifeADDBookmarks = new Dictionary<string, string>();
            VolLifeADDBookmarks.Add("VoluntaryLifeDescription1", "VoluntaryLifeDescription1");
            VolLifeADDBookmarks.Add("VoluntaryLifeDescription2", "VoluntaryLifeDescription2");
            VolLifeADDBookmarks.Add("VoluntaryLifeDescription3", "VoluntaryLifeDescription3");
            #endregion

            #region STD Bookmarks
            Dictionary<string, string> STDBookmarks = new Dictionary<string, string>();
            //STDBookmarks.Add("STD", "STD");
            //STDBookmarks.Add("STD", "VolSTDInsurance");
            #endregion

            #region LTD Bookmarks
            Dictionary<string, string> LTDBookmarks = new Dictionary<string, string>();
            //  LTDBookmarks.Add("LTD", "LTD");

            #endregion

            #region EAP Bookmarks
            Dictionary<string, string> EAPBookmarks = new Dictionary<string, string>();
            EAPBookmarks.Add("EAP", "EAP");
            #endregion

            //#region Patient Program
            Dictionary<string, string> PAdProgram = new Dictionary<string, string>();
            PAdProgram.Add("PatientAdvocacyProgram", "PatientAdvocacyProgram");


            //#endregion

            #region Telemedicine Bookmarks
            Dictionary<string, string> Telemedicine = new Dictionary<string, string>();
            Telemedicine.Add("Telemedicine", "Telemedicine");
            #endregion

            #region Wellness section
            Dictionary<string, string> Wellness = new Dictionary<string, string>();
            Wellness.Add("Wellness", "Wellness");
            #endregion

            #region Worksite Products
            Dictionary<string, string> Worksite_Products_Section = new Dictionary<string, string>();
            Worksite_Products_Section.Add("Worksite_Products_Section", "Worksite_Products_Section");
            Worksite_Products_Section.Add("Worksite_Accident", "Worksite_Accident");
            Worksite_Products_Section.Add("Worksite_CriticalIllness", "Worksite_CriticalIllness");
            #endregion



            AllBookmarks.Add("Medical", medicalBookmarks);
            AllBookmarks.Add("Dental", dentalBookmarks);
            AllBookmarks.Add("Vision", visionBookmarks);
            AllBookmarks.Add("HSA", HSABookmarks);
            AllBookmarks.Add("HRA", HRABookmarks);
            AllBookmarks.Add("FSA", FSABookmarks);
            // AllBookmarks.Add("STD", STDBookmarks);
            AllBookmarks.Add("Voluntary Life", VolLifeADDBookmarks);
            AllBookmarks.Add("Life and AD&D", ADDBookmarks);
            // AllBookmarks.Add("LTD", LTDBookmarks);
            AllBookmarks.Add("EAP", EAPBookmarks);

           // AllBookmarks.Add("Worksite_Products_Section", Worksite_Products_Section);
           // AllBookmarks.Add("Wellness", Wellness);
           // AllBookmarks.Add("Telemedicine", Telemedicine);

        }
        #endregion

        #region Deletes Bookmarks which presents in "AllBookmarks" Dictonary
        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, Dictionary<string, Dictionary<int, List<int>>> dictProductMap, DataTable PlanInfoTable, bool isBRCSelected)
        {
            string formattedPlanType = string.Empty;   //to format special characters and spaces -- which are not detected in bookmarks
            string mainDesc = string.Empty;            //Main descrption on 1st page

            #region Delete non-selected plans and sub-sections including Header on 1st Page
            foreach (string plantype in AllBookmarks.Keys)
            {

                if (!dictProductMap.ContainsKey(plantype))
                {
                    formattedPlanType = plantype.Replace("&", "").Replace(" ", "");

                    mainDesc = formattedPlanType + "Main";        //If Plan not selected

                    if (oWordDoc.Bookmarks.Exists(mainDesc))    // Delete Main Description on 1st page
                    {
                        oWordDoc.Bookmarks[mainDesc].Range.Delete();
                    }

                    if (oWordDoc.Bookmarks.Exists(formattedPlanType))     // Delete Enitre Section
                    {
                        oWordDoc.Bookmarks[formattedPlanType].Range.Delete();
                    }
                    //DeleteIndivialBookmark(oWordDoc, mainDesc);              UnComment if bookmark not deleted
                    // DeleteIndivialBookmark(oWordDoc, formattedPlanType);

                }
                else
                {                                                                     //If PlanType is selected
                    if (AllBookmarks[plantype] != null)
                    {
                        foreach (string bookmark in AllBookmarks[plantype].Keys)     // Loop through inner bookmarks and delete unwanted sub-sections
                        {
                            formattedPlanType = bookmark.Replace("&", "").Replace(" ", "");

                            if (oWordDoc.Bookmarks.Exists(formattedPlanType))
                            {
                                oWordDoc.Bookmarks[bookmark].Range.Delete();
                            }
                            DeleteIndivialBookmark(oWordDoc, formattedPlanType);
                        }
                    }
                }
            }
            #endregion

            //#region Delete Product sections

            //bool is_Patient_Advocacy_Selected = false;
            //bool is_Consumer_Driven_Telemedicine_Selected = false;

            //if (PlanInfoTable != null)
            //{
            //    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
            //    {
            //        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
            //        {
            //            is_Patient_Advocacy_Selected = true;
            //        }
            //        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
            //        {
            //            is_Consumer_Driven_Telemedicine_Selected = true;
            //        }
            //    }
            //}


            //if (is_Patient_Advocacy_Selected == false)
            //{
            //    if (oWordDoc.Bookmarks.Exists("PatientAdvocacyProgram"))
            //    {
            //        oWordDoc.Bookmarks["PatientAdvocacyProgram"].Range.Delete();
            //    }
            //}
            //if (is_Consumer_Driven_Telemedicine_Selected == false)
            //{
            //    if (oWordDoc.Bookmarks.Exists("Telemedicine"))
            //    {
            //        oWordDoc.Bookmarks["Telemedicine"].Range.Delete();
            //    }

            //}


            //#endregion

            #region Delete BRC Section
            if (isBRCSelected == false)
            {
                if (oWordDoc.Bookmarks.Exists("BRC"))
                {
                    oWordDoc.Bookmarks["BRC"].Range.Delete();
                }
            }
            #endregion

            #region
            if (oWordDoc.TablesOfContents.Count > 0)
            {
                oWordDoc.TablesOfContents[1].Update();
            }
            #endregion

        }
        #endregion

        #region Call if bookmark which are not present in "AllBookmarks"
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        #endregion

        #region Deletecolumn and contact information
        public void DeleteColumn(Word.Document oWordDoc, int TableNo, int RowWithSplitColumns, int colStart, int ColEnd)
        {
            try
            {

                //Column delete
                Range ColumnsRange = oWordDoc.Range(oWordDoc.Tables[TableNo].Cell(RowWithSplitColumns, colStart).Range.Start, oWordDoc.Tables[TableNo].Cell(RowWithSplitColumns, ColEnd).Range.End);
                ColumnsRange.Columns.Delete();

                #region Commented -- Fixing 1st cloumns width and expanding remaining cloumns

                //Auto Fitting Table
                oWordDoc.Tables[TableNo].AllowAutoFit = true;
                oWordDoc.Tables[TableNo].AutoFitBehavior(WdAutoFitBehavior.wdAutoFitWindow);

                //Setting Left header i.e 1st Column to fixed width 2.18f
                Range LeftHeaderRange = oWordDoc.Tables[TableNo].Cell(1, 1).Range;
                LeftHeaderRange.Columns.PreferredWidthType = WdPreferredWidthType.wdPreferredWidthPoints;
                LeftHeaderRange.Columns.PreferredWidth = oWordDoc.Application.InchesToPoints(2.18f);

                #endregion

            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region merge table column
        public void MergeTableColumns(Word.Document oWordDoc, int TableIndex, int MergeStart, int MergeEnd, int RowStartIndex, int RowEndIndex, List<int> SkippedRowIndexes)
        {
            Microsoft.Office.Interop.Word.Table objTable;
            objTable = oWordDoc.Tables[TableIndex];

            for (int i = RowStartIndex; i <= RowEndIndex; i++)
            {
                if (i > objTable.Rows.Count) break;
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(i))
                    {
                        objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                        //objTable.Rows[i].Cells[MergeStart].Split(MergeStart, 2);                   
                    }
                }
                else
                {
                    objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                    // objTable.Rows[i].Cells[MergeStart].Split(MergeStart, 2);                   
                }
            }

        }
        #endregion

        #region merge table column
        public void EquallyDistributeTableColumns(Word.Document oWordDoc, Word.Application oWordApp, int TableIndex, int EquallyDisStart, int EquallyDisEnd, int RowStartIndex, int RowEndIndex, List<int> SkippedRowIndexes, int PlanTier)
        {
            Microsoft.Office.Interop.Word.Table objTable;
            objTable = oWordDoc.Tables[TableIndex];
            int rowCount = objTable.Rows.Count;
            int ColCount = objTable.Columns.Count;
            //float TotalWidth = (float)322.8;  total minus first column

            //float TotalWidth = (float)322.8;

            float TotalWidth = (float)60;

            for (int i = RowStartIndex; i <= RowEndIndex; i++)
            {
                if (i > objTable.Rows.Count) break;
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(i))
                    {
                        for (int j = EquallyDisStart; j <= EquallyDisEnd; j++)
                        {

                            objTable.Rows[i].Cells[j].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);

                            //objTable.Rows[i].Cells[3].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);
                            //objTable.Rows[i].Cells[4].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);

                            ////Then set fourth column width            
                            // objTable.Columns.Add(objTable.Columns[4]).SetWidth(oWordApp.Application.CentimetersToPoints(3.2f), Word.WdRulerStyle.wdAdjustNone);
                            //objTable.Columns[4].SetWidth(wrdApp.Application.CentimetersToPoints(4f), Word.WdRulerStyle.wdAdjustNone);

                        }
                    }
                    else
                    {
                        for (int j = EquallyDisStart; j <= EquallyDisEnd; j++)
                        {
                            objTable.Rows[i].Cells[j].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);

                            //objTable.Rows[i].Cells[3].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);
                            //objTable.Rows[i].Cells[4].SetWidth(TotalWidth, Word.WdRulerStyle.wdAdjustNone);
                        }
                    }
                }
            }
        }


        #endregion

        #region checking plan tier
        public int CheckPlanTier(int AttributeId, int BenefitSummaryId, DataTable BenefitTable)
        {
            int Count = 0;
            List<int> lstBenefitColumnID = new List<int>();
            foreach (DataRow dr in BenefitTable.Rows)
            {
                if (dr["attributeID"].ToString() == AttributeId.ToString() && dr["benefitSummaryID"].ToString() == BenefitSummaryId.ToString())
                {
                    int benefitColumnID = int.Parse(dr["benefitColumnID"].ToString());
                    if (!lstBenefitColumnID.Contains(benefitColumnID))
                        lstBenefitColumnID.Add(benefitColumnID);
                }
            }
            return lstBenefitColumnID.Count;
        }
        #endregion


    }

}