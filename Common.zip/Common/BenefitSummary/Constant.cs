﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class ConstantValue
    {
        #region Variable
        string _MedicalPlanType = "Medical Plan";
        string _MedicalLOC = "Medical";
        string _DentalPlanType = "Dental Plan";
        string _DentalLOC = "Dental";
        string _VisionPlanType = "Vision Plan";
        string _VisionLOC = "Vision";
        string _LifeADDPlanType = "Life and AD&D Plan";
        string _LifeADDLOC = "Life and AD&D";
        string _GroupTermLife = "Group Term Life Plan";

        string _VoluntaryLife = "Voluntary Life ";
        string _VaoluntaryLifeADD = "Voluntary Life ADD ";
        string _ADD = "ADD ";
        string _Wellness = "Wellness";

        string _STDPlanType = "STD Plan";
        string _STDLOC = "Short Term Disability";
        string _LTDPlanType = "LTD Plan";
        string _LTDLOC = "Long Term Disability";
        string _VoluntaryLifeADDPlanType = "Voluntary Life Plan";
        string _VoluntaryLifeADDLOC = "Voluntary Life";
        string _EAPPlanType = "EAP Plan";
        string _EAPLOC = "Employee Assistance Program";
        string _FSAPlanType = "FSA Plan";
        string _FSALOC = "Section 125";
        string _HSAPlanType = "HSA Plan";
        string _HSALOC = "Health Savings Account";
        string _HRAPlanType = "HRA Plan";
        string _HRALOC = "Health Reimbursement Arrangement";
        string _GroupTermLifeLOC = "Group Term Life";
        string _AdditionalProducts = "Additional Products";

        string _StopLossPlanType = "Stop Loss";
        string _FeesForServicePlanType = "Fees For Service";

        // CC - Common Criteria Page
        string _STDPlanType_CC = "STD";
        string _LTDPlanType_CC = "LTD";
        string _EAPPlanType_CC = "EAP";
        string _FSAPlanType_CC = "FSA";
        string _HSAPlanType_CC = "HSA";
        string _HRAPlanType_CC = "HRA";
        string _GroupTermLife_CC = "Group Term Life";
        string _ADD_CC = "AD&D";
        string _VoluntaryADD_CC = "Voluntary AD&D";

        /*-------ADDED BY AMOGH FOR ACCOUNT PROFILE DETAILS DEVELOPMENT -----*/
        string _Disability = "Disability";
        string _Accident = "Accident";
        string _PrescriptionDrug = "Prescription Drug";

        #region Added by Vaibhav
        public string TelemedicineLOC = "Telemedicine";
        public string PatientAdvocacyLOC = "Patient Advocacy";
        public string HospitalizationLOC = "Hospitalization";
        public string AccidentLOC = "Accident";
        public string CriticalIllnessLOC = "Critical illness";
        public string VoluntaryCancerLOC = "Voluntary Cancer";
        public string LifeADDProductLOC = "Life and AD&D";
        public string AbsenceManagementProductLOC = "Absence Management";
        public string PetInsuranceLOC = "Pet Insurance";
        public string COBRAAdministrationLOC = "COBRA Administration";
        public string FinancialProductsAllOthersLOC = "Financial Products - All Others";
        public string ExecutiveBenefitsLOC = "Excecutive Benefits";
        public string Filling500ProductLOC = "5500 Filing";
        public string TransitParkingAdminLOC = "Transit/Parking Admin";
        public string LegalServicesLOC = "Legal Services";
        public string IdentityTheftLOC = "Identity Theft";
        public string ShortTermMedicalLOC = "Short Term Medical";
        public string WholeLifeIndividualLOC = "Whole Life - Individual";
        public string Product401K = "401(k)";
        public string DiseaseManagementLOC = "Disease Management";
        public string TobacoPolicyLOC = "Tobaco Policy";
        public string GroupHomeAutoLOC = "Group Home and Auto";
        public string MinimumEssentialCoverageLOC = "Minimum Essential Coverage (MEC)";
        public string IND_INDIV_LONG_TERM_CARE_LOC = "IND - INDIV LONG TERM CARE (FCC)";
        public string IndividualDisabilityLOC = "Individual Disability";
        public string MedicareSupplementLOC = "Medicare Supplement";
        public string FeeForService_ConsultingProjecLOC = "Fee for Service - Consulting/Project";
        public string FeeForService_HRBENAdminServiceLOC = "Fee for Service - HR/BEN Admin Services";
        public string FeeForService_PBMConsultingLOC = "Fee for Service - PBM Consulting";
        public string LongTermCareLOC = "Long Term Care";
        public string MedicalPlanRidersLOC = "Medical Plan Riders";
        public string OnsiteMedicalCenterLOC = "Onsite Medical Center";
        #endregion

        public static int AdditionalProducts_Patient_Advocacy = 1790;
        public static int AdditionalProducts_Consumer_Driven_Telemedicine = 5460;
        public static int AdditionalProducts_Accident = 5500;
        public static int AdditionalProducts_Voluntary_Cancer = 1400;
        public static int AdditionalProducts_Voluntary_Critical_Illness = 1160;
        public static int AdditionalProducts_Wellness = 317;
        public static int Employee_Assistance_Program = 310;

        public static int OptionFieldValue_SelfInsured = 52403;
        public static int OptionFieldValue_FullyInsured = 52401;

        #endregion
        #region Properties

        // <summary>
        /// Get ADNDPlanType_CommonCriteria
        /// </summary>
        public string Voluntary_ADNDPlanType_CommonCriteria
        {
            get
            {
                return _VoluntaryADD_CC;
            }
        }

        // <summary>
        /// Get ADNDPlanType_CommonCriteria
        /// </summary>
        public string ADNDPlanType_CommonCriteria
        {
            get
            {
                return _ADD_CC;
            }
        }

        // <summary>
        /// Get GroupTermLifePlan_CommonCriteria
        /// </summary>
        public string GroupTermLifePlanType_CommonCriteria
        {
            get
            {
                return _GroupTermLife_CC;
            }
        }

        // <summary>
        /// Get STDPlanType_CommonCriteria
        /// </summary>
        public string STDPlanType_CommonCriteria
        {
            get
            {
                return _STDPlanType_CC;
            }

        }

        // <summary>
        /// Get LTDPlanType_CommonCriteria
        /// </summary>
        public string LTDPlanType_CommonCriteria
        {
            get
            {
                return _LTDPlanType_CC;
            }

        }

        // <summary>
        /// Get EAPPlanType_CommonCriteria
        /// </summary>
        public string EAPPlanType_CommonCriteria
        {
            get
            {
                return _EAPPlanType_CC;
            }

        }

        // <summary>
        /// Get FSAPlanType_CommonCriteria
        /// </summary>
        public string FSAPlanType_CommonCriteria
        {
            get
            {
                return _FSAPlanType_CC;
            }

        }

        // <summary>
        /// Get HSAPlanType_CommonCriteria
        /// </summary>
        public string HSAPlanType_CommonCriteria
        {
            get
            {
                return _HSAPlanType_CC;
            }

        }

        // <summary>
        /// Get HRAPlanType_CommonCriteria
        /// </summary>
        public string HRAPlanType_CommonCriteria
        {
            get
            {
                return _HRAPlanType_CC;
            }

        }



        /// <summary>
        /// Get MedicalPlanType
        /// </summary>
        public string MedicalPlanType
        {
            get
            {
                return _MedicalPlanType;
            }

        }
        /// <summary>
        /// Get MedicalLOC
        /// </summary>
        public string MedicalLOC
        {
            get
            {
                return _MedicalLOC;
            }

        }

        /// <summary>
        /// Get DentalPlanType
        /// </summary>

        public string DentalPlanType
        {
            get
            {
                return _DentalPlanType;
            }

        }
        /// <summary>
        /// Get DentalLOC
        /// </summary>

        public string DentalLOC
        {
            get
            {
                return _DentalLOC;
            }

        }

        /// <summary>
        /// Get VisionPlanType
        /// </summary>

        public string VisionPlanType
        {
            get
            {
                return _VisionPlanType;
            }

        }
        /// <summary>
        /// Get VisionLOC
        /// </summary>

        public string VisionLOC
        {
            get
            {
                return _VisionLOC;
            }

        }
        /// <summary>
        /// Get LifeADDPlanType
        /// </summary>

        public string LifeADDPlanType
        {
            get
            {
                return _LifeADDPlanType;
            }

        }
        /// <summary>
        /// Get LifeADDLOC
        /// </summary>
        public string LifeADDLOC
        {
            get
            {
                return _LifeADDLOC;
            }

        }
        /// <summary>
        /// Get STDPlanType
        /// </summary>
        public string STDPlanType
        {
            get
            {
                return _STDPlanType;
            }

        }
        /// <summary>
        /// Get STDLOC
        /// </summary>
        public string STDLOC
        {
            get
            {
                return _STDLOC;
            }

        }
        /// <summary>
        /// Get LTDPlanType
        /// </summary>
        public string LTDPlanType
        {
            get
            {
                return _LTDPlanType;
            }

        }
        /// <summary>
        /// Get LTDLOC
        /// </summary>
        public string LTDLOC
        {
            get
            {
                return _LTDLOC;
            }

        }
        /// <summary>
        /// Get VoluntaryLifeADDPlanType
        /// </summary>
        public string VoluntaryLifeADDPlanType
        {
            get
            {
                return _VoluntaryLifeADDPlanType;
            }

        }
        /// <summary>
        /// Get VoluntaryLifeADdLOC
        /// </summary>
        public string VoluntaryLifeADDLOC
        {
            get
            {
                return _VoluntaryLifeADDLOC;
            }

        }
        /// <summary>
        /// Get EAPPlanType
        /// </summary>
        public string EAPPlanType
        {
            get
            {
                return _EAPPlanType;
            }

        }
        /// <summary>
        /// Get EAPPlanLOC
        /// </summary>
        public string EAPLOC
        {
            get
            {
                return _EAPLOC;
            }

        }
        /// <summary>
        /// Get FSAPlanType
        /// </summary>
        public string FSAPlanType
        {
            get
            {
                return _FSAPlanType;
            }

        }
        /// <summary>
        /// Get FSALOC
        /// </summary>
        public string FSALOC
        {
            get
            {
                return _FSALOC;
            }

        }
        /// <summary>
        /// Get HSAPlanType
        /// </summary>
        public string HSAPlanType
        {
            get
            {
                return _HSAPlanType;
            }

        }
        /// <summary>
        /// Get HSALOC
        /// </summary>
        public string HSALOC
        {
            get
            {
                return _HSALOC;
            }

        }
        /// <summary>
        /// Get HRAPlanType
        /// </summary>
        public string HRAPlanType
        {
            get
            {
                return _HRAPlanType;
            }

        }
        /// <summary>
        /// Get HRALOC
        /// </summary>
        public string HRALOC
        {
            get
            {
                return _HRALOC;
            }

        }

        /// <summary>
        /// Get HRAPlanType
        /// </summary>
        public string GroupTermLifePlanType
        {
            get
            {
                return _GroupTermLife;
            }

        }

        /// <summary>
        /// Get VoultaryLife
        /// </summary>
        public string VoluntaryLife
        {
            get
            {
                return _VoluntaryLife;
            }

        }

        /// <summary>
        /// Get VoultaryLife ADD
        /// </summary>
        public string VoluntaryLifeADD
        {
            get
            {
                return _VaoluntaryLifeADD;
            }

        }

        /// <summary>
        /// Get ADD
        /// </summary>
        public string ADD
        {
            get
            {
                return _ADD;
            }

        }

        /// <summary>
        /// Get Wellness
        /// </summary>
        public string Wellness
        {
            get
            {
                return _Wellness;
            }

        }

        /// <summary>
        /// Get Disability - ADDED BY AMOGH 
        /// </summary>
        public string Disability
        {
            get
            {
                return _Disability;
            }
        }

        /// <summary>
        /// Get Disability - ADDED BY AMOGH 
        /// </summary>
        public string Accident
        {
            get
            {
                return _Accident;
            }
        }

        /// <summary>
        /// Get Prescription Drug - ADDED BY AMOGH 
        /// </summary>
        public string PrescriptionDrug
        {
            get
            {
                return _PrescriptionDrug;
            }
        }
        /// <summary>
        /// Get Additional Products
        /// </summary>
        public string AdditionalProducts
        {
            get
            {
                return _AdditionalProducts;
            }

        }
        /// <summary>
        /// Get StopLossPlanType
        /// </summary>
        public string StopLoss
        {
            get
            {
                return _StopLossPlanType;
            }

        }

        /// <summary>
        /// Get FeesForServicePlanType
        /// </summary>
        public string FeesForService
        {
            get
            {
                return _FeesForServicePlanType;
            }

        }
        #endregion


    }
}