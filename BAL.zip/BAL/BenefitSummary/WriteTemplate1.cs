﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate1 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        int PremiumTable_counter = 10;
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string Std_Plan = string.Empty;

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        public void WriteFieldToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                    }

                                    if (fieldName.Contains("Effective Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString().Trim());
                                    }

                                    if (fieldName.Contains("First Medical Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString().Trim());
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString().Trim());
                                    }

                                    if (fieldName.Contains("unmarriedchildtoage"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                        }
                                    }
                                    if (fieldName.Contains("definitionofdomesticpartner"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                            if (domesticPartner.Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(domesticPartner);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(domesticPartner.Trim());
                                            }
                                        }
                                    }

                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                            }
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["VALUE"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                            }
                                        }

                                        if (fieldName.Contains("Frequency"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                            }
                                        }
                                        if (fieldName.Contains("unitofmeasure"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("medicalplanwaitingperiod"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                            }
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                //oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours);
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                //oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone);
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                //oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail);
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                //oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax);
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Contact Information");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlMedicalNoOfPlan">Dropdownlist ddlMedicalNoOfPlan Object</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlMedicalNoOfPlan, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList)
        {
            try
            {
                int iTotalFields = 0;

                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string OldCarrier = "";

                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string Medical_Old_Carrier1 = null;
                ArrayList arrMedical = new ArrayList();

                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(3, "45");              //Annual Deductible[Per Person]
                HashtableMedical.Add(4, "44");              //Annual Deductible[Maximum Per Family]
                HashtableMedical.Add(6, "53");              //Annual Out-of-Pocket Maximum[Per Person]
                HashtableMedical.Add(7, "52");              //Annual Out-of-Pocket Maximum[Maximum Per Family]
                HashtableMedical.Add(9, "16");              //Preventive Care[Office Visit]
                HashtableMedical.Add(10, "571");            //Preventive Care[Well-Child Care]
                HashtableMedical.Add(12, "386");            //Professional[Office Visit]
                HashtableMedical.Add(13, "414");            //Professional [Outpatient Visit]
                HashtableMedical.Add(15, "295");            //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(16, "409");            //Hospital/Facility[Outpatient Care]
                HashtableMedical.Add(18, "407");            //Mental Health/Substance Abuse[Outpatient]
                HashtableMedical.Add(19, "287");            //Mental Health/Substance Abuse[Inpatient]
                HashtableMedical.Add(21, "168");            //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedical.Add(22, "971");            //Other Services[Complex Radiology]

                HashtableMedical.Add(23, "184");            //Other Services[Emergency Room]
                HashtableMedical.Add(24, "107");            //Other Services[Spinal Manipulations]
                HashtableMedical.Add(25, "555");            //Other Services[Urgent Care]
                HashtableMedicalOutNetwork.Add(27, "45");   //Out-of-Network Benefits[Annual Deductible Per Person]
                HashtableMedicalOutNetwork.Add(28, "44");   //Out-of-Network Benefits[Annual Deductible Family]
                HashtableMedicalOutNetwork.Add(29, "112");  //Out-of-Network Benefits[Coinsurance]
                HashtableMedicalOutNetwork.Add(30, "53");   //Out-of-Network Benefits[Annual Out-of-Pocket Max Per Person]
                HashtableMedicalOutNetwork.Add(31, "52");   //Out-of-Network Benefits[Annual Out-of-Pocket Max Family]
                HashtableMedicalOutNetwork.Add(32, "16");   //Out-of-Network Benefits[Preventive Care Office Visit]
                HashtableMedicalOutNetwork.Add(33, "386");  //Out-of-Network Benefits[Preventive Care Office Visit]
                HashtableMedicalOutNetwork.Add(34, "184");  //Out-of-Network Benefits[Emergency Room]
                HashtableMedical.Add(35, "315");            //Lifetime Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                                foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            }
                            # region MergeField

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Number of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlMedicalNoOfPlan.SelectedItem.Text.Trim());
                                    }

                                    if (fieldName.Contains("Offers"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("offers a choice between");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("offers");
                                        }
                                    }

                                    if (fieldName.Contains("Med_Plan"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("medical plans. You can choose the");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("medical plan, the");
                                        }
                                    }

                                    if (fieldName.Contains("Medical Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            // Previously 'ProductTypeDescription' was suggested by client
                                            //oWordApp.Selection.TypeText(" or the " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " plan with ");
                                            oWordApp.Selection.TypeText(" or the " + PlanTable.Rows[k]["SummaryName"].ToString() + " plan with ");
                                        }
                                        else
                                        {
                                            // Previously 'ProductTypeDescription' was suggested by client
                                            //oWordApp.Selection.TypeText(PlanTable.Rows[k]["ProductTypeDescription"].ToString());

                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        Medical_Old_Carrier1 = PlanTable.Rows[k]["Carrier"].ToString();
                                        oWordApp.Selection.TypeText(Medical_Old_Carrier1.Trim());
                                    }
                                    if (fieldName.Contains("Medical Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Medical Plans");
                                    }
                                    if (fieldName.Contains("Carrier Specific Wording for Pre-Existing Conditions"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["PreExistingConditions"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Carrier Specific Wording for Organ Transplant Waiting Period"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["OrganTransplantWaitingPeriod"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Carrier Specific Wording for Fourth Quarter Carry-over Benefit"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["FourthQuarterCarryOverBenefit"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Carrier Specific Wording for Out of Area Benefits"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["OutOfAreaBenefits"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Plan Type (PPO, HMO, POS) Specific Text"))
                                    {
                                        myMergeField.Select();
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            PlanSpecific = foundPlanTypeRows[0]["PlanSpecific"].ToString();
                                            oWordApp.Selection.TypeText(PlanSpecific.Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region MedicalTable

                            //if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            //{
                            //    oWordDoc.Tables[1].Cell(2, 2).Select();
                            //    if (count == 1)
                            //    {
                            //        oWordDoc.Tables[1].Cell(2, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                            //    }
                            //    else
                            //    {
                            //        oWordDoc.Tables[1].Cell(2, 2).Range.Text = oWordDoc.Tables[1].Cell(2, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                            //    }
                            //    OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            //}

                            if (!arrMedical.Contains(PlanTable.Rows[k]["Carrier"].ToString()))
                            {
                                oWordDoc.Tables[1].Cell(2, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(2, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(2, 2).Range.Text = oWordDoc.Tables[1].Cell(2, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString());
                            }

                            oWordDoc.Tables[2].Cell(1, count + 1).Select();
                            oWordDoc.Tables[2].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        public void WriteDentalSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, int dentalindex)
        {
            try
            {
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;

                string OldCarrier = "";
                string Dental_Old_Carrier = null;
                #region HashtableDental
                Hashtable HashtableDental = new Hashtable();
                HashtableDental.Add(3, "55");       //Benefit Year Maximum 
                HashtableDental.Add(5, "45");       //Annual Deductible[Individual]
                HashtableDental.Add(6, "44");       //Annual Deductible[Family]
                HashtableDental.Add(7, "566");      //Annual Deductible[Deductible waived for Preventive]
                HashtableDental.Add(9, "164");      //Dental Categories[Preventive & Diagnostic Care]
                HashtableDental.Add(10, "64");      //Dental Categories[Basic Restorative Care]
                HashtableDental.Add(11, "336");     //Dental Categories[Major Restorative Care]
                HashtableDental.Add(13, "392");     //Orthodontia[Benefits]
                HashtableDental.Add(14, "152");     //Orthodontia[Dependent Children]
                HashtableDental.Add(15, "314");     //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDental.Add(17, "565");     //Additional Features[Waiting Periods]
                HashtableDental.Add(18, "465");     //Additional Features[Usual Customary & Reasonable]
                #endregion
                int count = 1;

                ConstantValue cv = new ConstantValue();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Plans");
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (Dental_Old_Carrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" or " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Dental_Old_Carrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier-ToFind"))
                                    {
                                        myMergeField.Select();
                                        if (dentalindex == 2)
                                        {
                                            oWordApp.Selection.TypeText("To find a " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Carrier Phone Number" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            if (count > 1)
                                            {
                                                oWordApp.Selection.TypeText(" provider, call " + foundRows[0]["PhoneNumber"].ToString() + ".");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("Pull Plan Specific Text (PPO or Indemnity)"))
                                    {
                                        myMergeField.Select();
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region DetalTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(3, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(3, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(3, 2).Range.Text = oWordDoc.Tables[1].Cell(3, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            oWordDoc.Tables[4].Cell(1, count + 1).Select();
                            oWordDoc.Tables[4].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            foreach (int key in HashtableDental.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {

                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDental[key].ToString())
                                    {
                                        oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string minimum_weekly_benefit = "";

                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableSTD
                HashtableSTD.Add(3, "8");       //Elimination Period[Accident]
                HashtableSTD.Add(4, "505");     //Elimination Period[Sickness]
                HashtableSTD.Add(6, "569");     //Benefit Features[Maximum Benefit]
                HashtableSTD.Add(7, "350");     //Benefit Features[Maximum Benefit Duration]
                HashtableSTD.Add(66, "373");    //Benefit Features[Miniumum enefit]
                HashtableSTD.Add(8, "449");     //Benefit Features[Pre-Existing Condition Limitation]
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Group Short Term Disability Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Group Short Term Disability Benefits");
                                    }
                                }
                            }
                            #endregion
                            #region STDTable

                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(6, 2).Select();
                                //oWordDoc.Tables[1].Cell(count + 9, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();

                                //Chnage by client request  24-Jun-2014 
                                Std_Plan = PlanTable.Rows[k]["Carrier"].ToString();
                                if (!string.IsNullOrEmpty(Std_Plan))
                                {
                                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = Std_Plan;
                                }
                                //End Change
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            oWordDoc.Tables[7].Cell(1, count + 1).Select();
                            oWordDoc.Tables[7].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];



                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        if (key == 66)
                                        {
                                            minimum_weekly_benefit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 6)
                                        {
                                            oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = minimum_weekly_benefit + "up to a maximum of " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "per week";
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }


                                    }
                                }

                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LTDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan</param>
        public void WriteLTDSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string minimum_monthly_benefit = "";

                Hashtable HashtableLTD = new Hashtable();
                #region HashtableLTD
                HashtableLTD.Add(3, "181");     //Benefits[Elimination Period]
                HashtableLTD.Add(4, "374");     //Benefits[Maximum Monthly Benefit]
                HashtableLTD.Add(44, "371");    //Benefits[Minimum Monthly Benefit]
                HashtableLTD.Add(5, "351");     //Benefits[Maximum Benefit Period]
                HashtableLTD.Add(6, "141");     //Benefits[Definition of Disability]
                HashtableLTD.Add(7, "449");     //Benefits[Pre-Existing Condition Limitation]
                ConstantValue cv = new ConstantValue();

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Group Long Term Disability Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Group Long Term Disability Benefits");
                                    }
                                }
                            }
                            #endregion

                            #region LTDTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(6, 2).Select();
                                //Chnaged by client request  24-Jun-2014 
                                if (!string.IsNullOrEmpty(Std_Plan))
                                {
                                    if (Std_Plan != PlanTable.Rows[k]["Carrier"].ToString())
                                    {
                                        oWordDoc.Tables[1].Cell(6, 2).Range.Text = oWordDoc.Tables[1].Cell(6, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                    }
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(6, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                //End Change
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            oWordDoc.Tables[8].Cell(1, count + 1).Select();
                            oWordDoc.Tables[8].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        if (key == 44)
                                        {
                                            minimum_monthly_benefit = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 4)
                                        {
                                            oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = minimum_monthly_benefit + "upto a " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + "monthly maximum";
                                        }
                                        if (key == 5)
                                        {
                                            if (dr["UOM"].ToString() != "text")
                                            {
                                                oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[8].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        public void WriteVisionBenefitsSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList)
        {
            try
            {
                Hashtable HashtableVisionBenefit = new Hashtable();
                Hashtable HashtableVision = new Hashtable();
                #region HastableVisionBenefit


                HashtableVisionBenefit.Add(5, "195");   //Examination[Copay]
                HashtableVisionBenefit.Add(6, "194");   //Examination[Frequency]
                HashtableVisionBenefit.Add(8, "309");   //Hardware[Lenses]
                HashtableVisionBenefit.Add(9, "208");   //Hardware[Frames - Copay]
                HashtableVisionBenefit.Add(10, "207");  //Hardware[Frames - Frequency]
                HashtableVisionBenefit.Add(11, "122");  //Hardware[Contacts]

                HashtableVision.Add(-1, "344");         //Copay Materials

                #endregion

                int count = 1;

                string OldCarrier = "";

                string Vision_Old_Carrier = null;
                ConstantValue cv = new ConstantValue();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                    }

                                    if (fieldName.Contains("Vision Plan Carrier" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (Vision_Old_Carrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Vision_Old_Carrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                    }
                                }
                            }

                            #endregion

                            # region VisionBenefitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(4, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(4, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(4, 2).Range.Text = oWordDoc.Tables[1].Cell(4, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            oWordDoc.Tables[5].Cell(1, count + 1).Select();
                            oWordDoc.Tables[5].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];
                            string material = "";

                            foreach (int key in HashtableVision.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVision[key].ToString())
                                    {
                                        if (key == -1)
                                        {
                                            if (!string.IsNullOrEmpty(dr["value"].ToString()))
                                            {
                                                material = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + dr["exclusionsLimitations"].ToString() + " Once every ";
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        if (key == 8)
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = material + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteGroupLifeADDBenifitToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                double benefitamount = 0;
                string age = "";
                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(3, "186");     //Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(4, "188");     //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(5, "187");     //Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(7, "517");     //Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(8, "519");     //Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(9, "518");     //Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(11, "102");    //Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(12, "104");    //Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(13, "103");    //Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(14, "2");      //age
                HashtableGroupLifeADDBenifit.Add(15, "3");      //age
                HashtableGroupLifeADDBenifit.Add(16, "4");      //age
                HashtableGroupLifeADDBenifit.Add(17, "5");      //age

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(5, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(5, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(5, 2).Range.Text = oWordDoc.Tables[1].Cell(5, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            /* The following line changed beacause we merging the first cell of table to Display the carrier name in correct format*/
                            oWordDoc.Tables[6].Cell(1, 2).Select();
                            oWordDoc.Tables[6].Cell(1, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        if (key < 14)
                                        {
                                            oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Group Life and AD&D Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Group Life and AD&D Benefits");
                                    }
                                    if (fieldName.Contains("GroupLifeADDTaxation"))
                                    {
                                        if (benefitamount > 50000)
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Reduction of Benefit Schedule Return Age"))
                                    {
                                        myMergeField.Select();
                                        if (age != "")
                                        {
                                            oWordApp.Selection.TypeText(age.Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeADDBenefitToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string age = "";
                double benefitamount = 0;
                #region HashtableVoluntaryLifeADDBenifit
                /*Delete Overall maximum row from all catagory--29/05/2014*/
                HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                //HashtableVoluntaryLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(4, "187");//Employee[Guarantee Issue Amount]4
                HashtableVoluntaryLifeADDBenifit.Add(6, "516");//Spouse[Benefit Amount]6
                //HashtableVoluntaryLifeADDBenifit.Add(8, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(7, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(9, "106");//Child(ren)[Benefit Amount] 
                //HashtableVoluntaryLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(10, "103"); //Child(ren)[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(11, "2");//age--
                HashtableVoluntaryLifeADDBenifit.Add(12, "3");//age
                HashtableVoluntaryLifeADDBenifit.Add(13, "4");//age
                HashtableVoluntaryLifeADDBenifit.Add(14, "5");//age

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {

                            #region VoluntaryLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(7, 2).Select();
                                oWordDoc.Tables[1].Cell(7, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            oWordDoc.Tables[9].Cell(1, count + 1).Select();
                            oWordDoc.Tables[9].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];
                            string planname = PlanTable.Rows[k]["ProductTypeDescription"].ToString();
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        if (key < 11)
                                        {
                                            oWordDoc.Tables[9].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }

                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Voluntary Life and AD&D Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(planname.Trim());
                                    }
                                    if (fieldName.Contains("Reduction of Benefit Schedule Return Age"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(age.Trim());
                                    }
                                    if (fieldName.Contains("VoluntaryLifeADDTaxation"))
                                    {
                                        if (benefitamount > 50000)
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                string OldCarrier = "";

                Hashtable HashtableEAP = new Hashtable();
                #region HashtableEAP
                HashtableEAP.Add(1, "384");//Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            /*Added by client requirement --- starts here --- 03 June 2014*/
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(8, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = oWordDoc.Tables[1].Cell(7, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            /*Added by client requirement --- ends here --- 03 June 2014*/

                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Number of Visit Item"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                }

                                                if (fieldName.Contains("EAP Plan Carrier1"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                }
                                                if (fieldName.Contains("Employee Assistance Program"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Employee Assistance Program");
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable PlanTypeSpecific, DataSet BenefitDS, ArrayList FSABenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;
                string OldCarrier = "";

                Hashtable HashtableFSA = new Hashtable();

                DataRow[] foundPlanTypeRows = null;
                #region HashtableFSA
                HashtableFSA.Add(1, "150");//Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");//Administration Services – Grace Period
                HashtableFSA.Add(3, "354");//Administration Services-Medical Spending Accounts - Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            /*Added by client requirement*/
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(9, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(9, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(9, 2).Range.Text = oWordDoc.Tables[1].Cell(8, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();
                                                if (fieldName.Contains("Flexible Spending Accounts"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Flexible Spending Accounts");
                                                }
                                                if (key == 3)
                                                {
                                                    if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        string administration_service_medicalspending = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                        if (administration_service_medicalspending.Trim().Length == 0)
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_medicalspending);
                                                        }
                                                        else
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                        }
                                                    }
                                                }
                                                if (key == 1)
                                                {
                                                    if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        string administration_service_dependentcare = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                        if (administration_service_dependentcare.Trim().Length == 0)
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_dependentcare);
                                                        }
                                                        else
                                                        {
                                                            oWordApp.Selection.TypeText(administration_service_dependentcare.Trim());
                                                        }
                                                    }
                                                }
                                                if (fieldName.Contains("Administration Services – Grace Period"))
                                                {
                                                    myMergeField.Select();
                                                    string administration_service_graceperiod = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                                    if (administration_service_graceperiod.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_graceperiod);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_graceperiod.Trim());
                                                    }
                                                }
                                                if (fieldName.Contains("Pull Plan Type specific text"))
                                                {

                                                    myMergeField.Select();
                                                    if (foundPlanTypeRows.Count() > 0)
                                                    {
                                                        if (foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim().Length == 0)
                                                        {
                                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString());
                                                        }
                                                        else
                                                        {
                                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                                        }
                                                    }
                                                    else
                                                    {
                                                        myMergeField.Delete();
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        public void WriteHSASectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                string OldCarrier = "";

                DataRow[] foundRows = null;
                Hashtable HashtableHSA = new Hashtable();
                #region HashtableHSA
                HashtableHSA.Add(1, "635");//General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSA.Add(2, "636");//General Plan Information – Maximum Annual Contribution/Family

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                            string MaxAnnualContribution = "";
                            string MaxAnnualContribution_Family = "";
                            //Added by client requirement -- starts here
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(10, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(10, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(10, 2).Range.Text = oWordDoc.Tables[1].Cell(9, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }
                            //Added by client requirement -- ends here

                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            MaxAnnualContribution = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 2)
                                        {
                                            MaxAnnualContribution_Family = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Health Savings Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Health Savings Account");
                                    }

                                    if (fieldName.Contains("General Plan Information – Maximum Annual Contribution/Individual"))
                                    {
                                        myMergeField.Select();
                                        if (MaxAnnualContribution.Trim().Length == 0)
                                        {
                                            oWordApp.Selection.TypeText(MaxAnnualContribution);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(MaxAnnualContribution.Trim());
                                        }
                                    }

                                    if (fieldName.Contains("General Plan Information – Maximum Annual Contribution/Family"))
                                    {
                                        myMergeField.Select();
                                        if (MaxAnnualContribution_Family.Trim().Length == 0)
                                        {
                                            oWordApp.Selection.TypeText(MaxAnnualContribution_Family);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(MaxAnnualContribution_Family.Trim());
                                        }

                                    }

                                    if (fieldName.Contains("Pull Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[k]["Carrier"].ToString().Trim().Length != 0)
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                                        }
                                    }


                                    if (fieldName.Contains("Carrier Specific Website"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            if (foundRows[0]["Website"].ToString().Trim().Length != 0)
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                            }
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Carrier Specific Phone Number"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            if (foundRows[0]["PhoneNumber"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                            }
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        public void WriteHRASectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName)
        {
            try
            {
                int iTotalFields = 0;

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Health Reimbursement Account"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("Health Reimbursement Account");
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteContactinformationToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = PremiumTable_counter + 1;
                int k = 1;
                string carriername = "";
                string plantype = "";
                DataRow[] foundRows = null;

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        if (k > 1)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        oWordDoc.Tables[count].Cell(i + 2, 1).Range.Text = PlanTable.Rows[i]["Carrier"].ToString();
                        oWordDoc.Tables[count].Cell(i + 2, 2).Range.Text = PlanTable.Rows[i]["PlanType"].ToString();
                        foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");
                        if (foundRows.Count() > 0)
                        {
                            oWordDoc.Tables[count].Cell(i + 2, 3).Range.Text = foundRows[0]["Website"].ToString();
                            oWordDoc.Tables[count].Cell(i + 2, 4).Range.Text = foundRows[0]["PhoneNumber"].ToString();
                        }

                        k++;
                    }
                }
                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                }

                oWordDoc.Tables[count].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                oWordDoc.Tables[count].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS, DataTable PlanTable, DataTable CarrierSpecific, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;
                //List<Plan> PlanList = new List<Plan>();

                int count = 1;

                DataRow[] foundRows = null;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                HashtablePrescriptionDrugs.Add(4, "578");   //Deductible[Individual]
                HashtablePrescriptionDrugs.Add(6, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(7, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(8, "84");    //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(10, "380");   //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(9, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(6, "211");           //Mail Order[Generic]
                HashtableMailOrder.Add(7, "76");            //Mail Order[Formulary]
                HashtableMailOrder.Add(8, "82");            //Mail Order[Non Formulary]
                HashtableMailOrder.Add(10, "378");           //Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(9, "884");    //Mail Order[Preferred Specialty]
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[k]["Carrier"].ToString().Replace("'", "''") + "'");
                            }

                            # region MergeField
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Prescription Drugs"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Prescription Drugs");
                                    }

                                    if (fieldName.Contains("Carriers Website"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("Carrier Specific Text For Non-participating Pharmacy"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["NonparticipatingPharmacy"].ToString());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                    if (fieldName.Contains("Carrier specific Mandatory Generic Substitution text"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["MandatoryGenericSubstitution"].ToString());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region PrescriptionDrugsTable
                            //if (count < 3)
                            // {
                            oWordDoc.Tables[3].Cell(1, count + 1).Select();
                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];
                            // }

                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[3].Cell(key, count + 4).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        /// As suggested by client this code is commented -- 03 June 2014 start here
                        //if (fieldName.Equals("CHIPNotices"))
                        //{
                        //    if (ddlChipNotice.SelectedIndex == 1)
                        //    {
                        //        myMergeField.Select();
                        //        oWordApp.Selection.TypeText("CHIP NOTICE");
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //}
                        /// As suggested by client this code is commented -- 03 June 2014 end here

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //For word page break-03 June 2014
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_1_5.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("\f");
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                // Call common function to take notices
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        public void WriteMonthlyPremiumSectionToTemplate1(Word.Document oWordDoc, Word.Application oWordApp, DataSet RateDS, DataSet ContributionDS, DataTable PlanTable)
        {
            try
            {
                Object missing = System.Reflection.Missing.Value;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;
                    int monthly_premium_row_counter = 2;
                    bool header_created = false;
                    int Start = 0;
                    int End = 0;
                    int Interval = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                    PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                    int iTotalFields = 0;

                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {
                                if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                                {
                                    Start = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedStartOn"].ToString());
                                    End = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedEndOn"].ToString());
                                    Interval = int.Parse(RateDS.Tables["RateTable"].Rows[index]["ageBandedInterval"].ToString()) - 1;
                                    //  if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker" || RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "Spouse UniSmoker")
                                    if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"].ToString().Trim() == "EE UniSmoker")
                                    {
                                        PremiumTable.Rows.Add();
                                        PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                        //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                        if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                        {
                                            PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                        }
                                        else
                                        {
                                            PremiumTable.Rows[premium_row_counter][1] = 0;
                                        }
                                        PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                        PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                        PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                        PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                        PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                        premium_row_counter++;
                                    }
                                }
                                else
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                    {
                                        PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                    }
                                    else
                                    {
                                        PremiumTable.Rows[premium_row_counter][1] = 0;
                                    }
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][10] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());

                                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                    {
                                        if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                        {
                                            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                            PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                            PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                            PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                            break;
                                        }
                                    }
                                    premium_row_counter++;
                                }
                            }
                        }
                    }

                    #endregion

                    //new change
                    Boolean flag = false;

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["ContributionId"].ToString().Trim() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contribution"].ToString().Trim())
                        {
                            // Commented the "ContributionValues_amount != 0" condition on the request of Nicole on 07 April 2015 
                            //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
                            //{
                            //    flag = false;

                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString().Trim() == PremiumTable.Rows[i][2].ToString().Trim() && ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag == false)
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_rateTierId"];
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_Contributiondescription"].ToString();
                                PremiumTable.Rows[premium_row_counter][3] = "";
                                PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();

                                PremiumTable.Rows[premium_row_counter][9] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_ContributionValueId"].ToString(); ;
                                //break;
                                premium_row_counter++;
                            }
                            //}
                        }
                    }
                    //end change

                    #region AddTable

                    DataTable dt = new DataTable();
                    //change
                    if (PlanTable.Rows[index]["PlanType"].ToString().Trim() == "Voluntary Life Plan")
                    {
                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                    }
                    //End Change
                    else
                    {
                        PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                    }

                    if (PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count > 0)
                    {
                        Word.Table objTable;
                        Word.Range TableRng = oWordDoc.Tables[PremiumTable_counter].Range;

                        TableRng.SetRange(oWordDoc.Tables[PremiumTable_counter].Range.End + 1, oWordDoc.Tables[PremiumTable_counter].Range.End + 1);

                        objTable = oWordDoc.Tables.Add(TableRng, 2, 3, ref missing, ref missing);

                        objTable.Rows[1].Range.Shading.BackgroundPatternColor = Microsoft.Office.Interop.Word.WdColor.wdColorBlack;
                        objTable.Rows[1].Range.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorWhite;
                        objTable.Rows[1].Range.Font.Size = 9;
                        objTable.Rows[1].Range.Font.Bold = 1;
                        objTable.Columns.Width = 172;
                        objTable.Rows.Height = 12;
                        objTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                        objTable.Range.Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                        objTable.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {

                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("Monthly Premiums"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText("Monthly Premiums");
                                }

                                if (fieldName.Contains("UndereligibilityforMedicalPlan"))
                                {

                                    if (domesticPartner.ToString().ToLower() == "completed")
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanSpecific.Trim());
                                    }
                                    else
                                    {
                                        myMergeField.Delete();
                                    }
                                }
                            }
                        }
                    }

                    #endregion
                    Int16 recordCnt = 0;
                    #region FillTable
                    for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                    {
                        if (!header_created)
                        {
                            //oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["PolicyNumber"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString() + PremiumTable.Rows[i][5].ToString();
                            oWordDoc.Tables[PremiumTable_counter].Cell(1, 1).Range.Text = PlanTable.Rows[index]["Carrier"].ToString() + " " + PlanTable.Rows[index]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[index]["SummaryName"].ToString();
                            oWordDoc.Tables[PremiumTable_counter].Cell(1, 2).Range.Text = "Total Plan Cost"; //"Total Monthly Cost";

                            if (PremiumTable.Rows[i][6].ToString() == "Bi_Weekly_26_or_yr")
                            {
                                oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Your Bi-Weekly (26 Per Year) Cost";
                            }
                            else
                            {
                                oWordDoc.Tables[PremiumTable_counter].Cell(1, 3).Range.Text = "Employee Contribution";
                            }

                            header_created = true;
                        }

                        if (PremiumTable.Rows[i][1].ToString() == "8")
                        {
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = PremiumTable.Rows[i][2].ToString().Replace("EE", "Employee");
                            oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                        }
                        else
                        {
                            //Change

                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker")
                            {
                                if (Start < End - 1)
                                {
                                    if (monthly_premium_row_counter == 2)
                                    {
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Under " + Start.ToString();
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                                    }
                                    else
                                    {
                                        //oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                                        Start = Start + Interval + 1;
                                    }
                                }
                                else
                                {
                                    if (Start == End)
                                    {
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Over " + End.ToString();
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                                        Start = Start + Interval + 1;
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Composite";
                                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                                    }
                                }
                            }
                            //End Change
                            else
                            {
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 1).Range.Text = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 2).Range.Text = "$" + PremiumTable.Rows[i][3].ToString();
                            }
                        }
                        recordCnt++;
                        if (recordCnt != PremiumTable.Rows.Count)
                        {
                            oWordDoc.Tables[PremiumTable_counter].Rows.Add(ref missing);
                        }
                        oWordDoc.Tables[PremiumTable_counter].Cell(monthly_premium_row_counter, 3).Range.Text = "$" + PremiumTable.Rows[i][4].ToString();
                        monthly_premium_row_counter++;
                    }

                    #endregion

                    #region FormatTable
                    if (PremiumTable.Rows.Count > 0)
                    {
                        foreach (Word.Border border in oWordDoc.Tables[PremiumTable_counter].Borders)
                        {
                            border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                        }

                        oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                        oWordDoc.Tables[PremiumTable_counter].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                        oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                        oWordDoc.Tables[PremiumTable_counter].Range.Font.Size = 9;

                        for (int k = 2; k < oWordDoc.Tables[PremiumTable_counter].Rows.Count + 1; k++)
                        {
                            oWordDoc.Tables[PremiumTable_counter].Columns[1].Cells[k].Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphLeft;
                            oWordDoc.Tables[PremiumTable_counter].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;
                        }

                        PremiumTable_counter++;
                    }
                    #endregion
                }

                oWordDoc.Tables[PremiumTable_counter].Delete();
                PremiumTable_counter = PremiumTable_counter - 1;
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}