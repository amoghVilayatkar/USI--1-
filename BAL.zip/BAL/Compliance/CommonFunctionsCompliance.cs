﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.BAL.Compliance
{
    public class CommonFunctionsCompliance : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));                 //Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));               // Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));             // Plan Type ID
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        public DataTable GetPlanInfoTable(GridView grdPlans)
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true)
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                            }

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
    }
}