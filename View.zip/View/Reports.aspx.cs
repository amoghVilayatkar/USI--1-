﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using System.Collections;
using System.Globalization;
using BenefitPointSummaryPortal.BAL.Reports;

namespace BenefitPointSummaryPortal.View
{
    public partial class Reports : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                Page.MaintainScrollPositionOnPostBack = true;
                txtSearchOffice.Focus();
                if (!IsPostBack)
                {
                    Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    if (Convert.ToString(Session["Summary"]) == "Reports1")
                    {
                        lblHeading.Text = "Meeting Tracking Report";
                        //lblTemplateNo.Text = "#1";
                    }

                    Activity = lblHeading.Text;
                    Activity_Group = "Reports";
                    List<Office> OfficeList = new List<Office>();
                    OfficeList = bp.FindOffice(SessionId, "");

                    cblistOffice.DataSource = OfficeList;
                    cblistOffice.DataBind();

                    //Reading the data from Producer XML file and bind to ddlProducerTeam dropdown
                    DataSet procedure = new DataSet();
                    procedure.ReadXml(Server.MapPath("~/Common/Reports/Producer.xml"));
                    ddlProducerTeam.DataSource = procedure;
                    ddlProducerTeam.DataTextField = "description";
                    ddlProducerTeam.DataValueField = "id";
                    ddlProducerTeam.DataBind();

                    ddlProducerTeam.SelectedValue = "1111";
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            ddlProducerTeam.SelectedIndex = 0;
        }

        //protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    ddlActivity.Items.Clear();
        //    if (Session["Summary"].ToString() == "Reports1")
        //    {
        //        GetActivity_List(rdlActivity.SelectedItem.Text,tc.Timeline1_SubjectID);
        //    }

        //}

        //protected void rdlActivity_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    SummaryDetail.isClientChanged_ForMedical = true;
        //    if (ddlActivity.SelectedIndex >= 0)
        //    {
        //        ddlActivity.SelectedIndex = 0;
        //        ddlActivity.Items.Clear();
        //        if (Session["Summary"].ToString() == "Reports1")
        //        {
        //            GetActivity_List(rdlActivity.SelectedItem.Text, tc.Timeline1_SubjectID);
        //        }

        //    }
        //}


        //private void GetActivity_List(string rdlValue, int SubjectID)
        //{
        //    bool isActivityPresent = false;
        //    try
        //    {
        //        BPBusiness bp = new BPBusiness();
        //        TimelineDetail timeD = new TimelineDetail();
        //        DataTable ActivityTable = new DataTable();
        //        string ActivityName = string.Empty;
        //        string ActivityID = string.Empty;
        //        SessionId = Session["SessionId"].ToString();
        //        int rowIndex = 1;
        //        //Clear();


        //        //ActivityTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId,SubjectID);
        //        Session["ActivityTable"] = ActivityTable;

        //        if (ActivityTable.Rows.Count > 0)
        //        {
        //            ddlActivity.Items.Insert(0, new ListItem("Select", string.Empty));
        //            for (int i = 0; i < ActivityTable.Rows.Count; i++)
        //            {
        //                if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["recordID"])))
        //                {
        //                    ActivityID = Convert.ToString(ActivityTable.Rows[i]["recordID"]);
        //                }

        //                if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["subject"])))
        //                {
        //                    ActivityName = Convert.ToString(ActivityTable.Rows[i]["subject"]);
        //                }
        //                //-- Do not delete code starts here --------------------------------------------------
        //                ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["name"])))
        //                ////{
        //                ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["name"]);
        //                ////}

        //                ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["createdon"])))
        //                ////{
        //                ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["createdon"]);
        //                ////}

        //                ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["dueon"])))
        //                ////{
        //                ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["dueon"]);
        //                ////}

        //                ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["status"])))
        //                ////{
        //                ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["status"]);
        //                ////}
        //                //-- Do not delete code ends here --------------------------------------------------

        //                if (rdlValue == "Open" && Convert.ToString(ActivityTable.Rows[i]["status"]).Trim().ToLower() == "open")
        //                {
        //                    ddlActivity.Items.Insert(rowIndex, new ListItem(ActivityName, ActivityID));
        //                    rowIndex++;
        //                }
        //                else if (rdlValue == "All")
        //                {
        //                    ddlActivity.Items.Insert(i + 1, new ListItem(ActivityName, ActivityID));
        //                }
        //            }
        //            isActivityPresent = true;
        //        }

        //        if (isActivityPresent == false)
        //        {
        //            //if (ddlClient.SelectedItem.Text != "Select")
        //            //{
        //            //    string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text  + "'.\");";
        //            //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
        //            //}
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            ////ArrayList arrCheckedOffice = new ArrayList();
            ////List<Account> filteredAccountList = new List<Account>();
            ////TimelineDetail timeD = new TimelineDetail();
            ////DataTable ActivityTable = new DataTable();
            ////DataTable filteredActivityTable = new DataTable();

            ////filteredActivityTable.Columns.Add("recordID", typeof(Int32));  // Row 0  
            ////filteredActivityTable.Columns.Add("subject", typeof(string));  // Row 0  
            ////filteredActivityTable.Columns.Add("name", typeof(string));  // Row 0  
            ////filteredActivityTable.Columns.Add("createdon", typeof(string));  // Row 0   
            ////filteredActivityTable.Columns.Add("dueon", typeof(string));  // Row 0  
            ////filteredActivityTable.Columns.Add("status", typeof(string));  // Row 0  
            ////filteredActivityTable.Columns.Add("priority", typeof(string));  // Row 0  
            ////filteredActivityTable.Columns.Add("X", typeof(string));  // Row 0  

            SessionId = Session["SessionId"].ToString();
            bool flag = true;
            try
            {
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                //DateTime.TryParse(txtDateFrom.Text, out dtFrom);
                //DateTime.TryParse(txtDateTo.Text, out dtTo);

                DateTime.TryParseExact(txtDateFrom.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtFrom);
                DateTime.TryParseExact(txtDateTo.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dtTo);

                if (txtDateFrom.Text != "")
                {
                    if (DateTime.MinValue == dtFrom)
                    {
                        txtDateFrom.Focus();
                        string script = "alert(\"'Create Date From' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }

                    if (dtFrom > DateTime.Today)
                    {
                        txtDateFrom.Focus();
                        string script = "alert(\"'Create Date From' should not be greater than today's date.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (txtDateFrom.Text.Trim() != "" && txtDateTo.Text.Trim() == "")
                {
                    txtDateTo.Focus();
                    string script = "alert(\"Please enter 'Create Date To'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateFrom.Text.Trim() == "" && txtDateTo.Text.Trim() != "")
                {
                    txtDateFrom.Focus();
                    string script = "alert(\"Please enter 'Create Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }

                if (txtDateTo.Text != "")
                {
                    if (DateTime.MinValue == dtTo)
                    {
                        txtDateTo.Focus();
                        string script = "alert(\"'Create Date To' should be in 'mm/dd/yyyy' format.\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                }

                if (dtTo < dtFrom)
                {
                    string script = "alert(\"'Create Date To' should be greater than 'Create Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                    return;
                }

                if (flag == true)
                {
                    // Get the Account Office and Account Region for the selected client
                    ////Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    if (Convert.ToString(Session["Summary"]) == "Reports1")
                    {
                        CreateReports1(tc.Timeline1_SubjectID, SessionId);
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //protected void cblistOffice_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    ArrayList arrCheckedOffice = new ArrayList();

        //    try
        //    {

        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}





        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected void CreateReports1(int SubjectID, string SessionId)
        {
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;

            try
            {
                ArrayList arrCheckedOffice = new ArrayList();
                // Create ararylist of selected check box from office checkboxlist
                for (int i = 0; i < cblistOffice.Items.Count; i++)
                {
                    if (cblistOffice.Items[i].Selected == true)
                    {
                        arrCheckedOffice.Add(cblistOffice.Items[i].Text);
                    }
                }

                SessionId = Session["SessionId"].ToString();
                List<Account> filteredAccountList = new List<Account>();
                DateTime _fromdate = new DateTime();
                DateTime _todate = new DateTime();
                DateTime.TryParse(txtDateFrom.Text, out _fromdate);
                DateTime.TryParse(txtDateTo.Text, out _todate);


                if (_todate < _fromdate)
                {
                    string script = "alert(\"'Create Date To' should be greater than 'Create Date From'.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    return;
                }


                filteredAccountList = bp.FindFilteredClientListForReportsTab(SessionId, arrCheckedOffice, Convert.ToInt32(ddlProducerTeam.SelectedItem.Value), _fromdate, _todate);

                myExcelApp = new Excel.Application();

                myExcelApp.Visible = false;


                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Reports/Documents/Templates/Reports1_Meeting Tracker.xlsx");

                myExcelApp.DisplayAlerts = false;

                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Reports/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");


                if (!Directory.Exists(Server.MapPath("~/Files/Reports/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Reports/Documents/Templates/Report1"));
                }


                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                //int rowIndex = 5; int colIndex = 6;

                //myWorksheet.Cells[rowIndex, colIndex] = "Testing";
                //myWorksheet.Cells[rowIndex, 7] = "Mandar";

                WriteReports1 wr = new WriteReports1();
                wr.WriteFieldToReports1(myWorksheet, SubjectID, SessionId, cblistOffice, ddlProducerTeam, _fromdate, _todate, filteredAccountList);


                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew(savefilename.ToString());

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office);


                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

                //if (myExcelApp != null)
                //{

                //    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(myWorkbook);
                //    myWorkbook = null;
                //    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(myWorksheet);
                //    myWorksheet = null;
                //    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(myExcelApp);
                //    myExcelApp = null;
                //    GC.Collect();
                //}
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //if (myExcelApp != null)
                //{
                //    System.Runtime.InteropServices.Marshal.ReleaseComObject(myWorkbook);
                //    myWorkbook = null;
                //    System.Runtime.InteropServices.Marshal.ReleaseComObject(myWorksheet);
                //    myWorksheet = null;
                //    System.Runtime.InteropServices.Marshal.ReleaseComObject(myExcelApp);
                //    myExcelApp = null;
                //    GC.Collect();
                //}

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }

            ////return (savefilename.ToString());
        }

        protected void txtSearchOffice_TextChanged(object sender, EventArgs e)
        {
            txtSearchOffice.Focus();

            List<Office> OfficeList = new List<Office>();
            SessionId = Session["SessionId"].ToString();

            OfficeList = bp.FindOffice(SessionId, "");
            var data = from g in OfficeList where g.OfficeNameText.ToLower().StartsWith(txtSearchOffice.Text.ToLower()) select g;

            cblistOffice.Items.Clear();
            foreach (var s in data)
            {
                cblistOffice.Items.Add(s.OfficeNameText);
            }
            txtSearchOffice.Focus();
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //for (int i = 0; i < cblistOffice.Items.Count; i++)
                //{
                //    cblistOffice.Items[i].Selected = false;
                //}
                SessionId = Session["SessionId"].ToString();
                List<Office> OfficeList = new List<Office>();
                OfficeList = bp.FindOffice(SessionId, "");

                cblistOffice.DataSource = OfficeList;
                cblistOffice.DataBind();

                txtDateFrom.Text = "";
                txtDateTo.Text = "";
                txtSearchOffice.Text = "";
                ddlProducerTeam.SelectedValue = "1111";
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSearchOffice_Click(object sender, EventArgs e)
        {
            try
            {
                txtSearchOffice.Focus();

                List<Office> OfficeList = new List<Office>();
                SessionId = Session["SessionId"].ToString();

                OfficeList = bp.FindOffice(SessionId, "");
                var data = from g in OfficeList where g.OfficeNameText.ToLower().StartsWith(txtSearchOffice.Text.ToLower()) select g;

                cblistOffice.Items.Clear();
                foreach (var s in data)
                {
                    cblistOffice.Items.Add(s.OfficeNameText);
                }
                txtSearchOffice.Focus();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //[System.Web.Services.WebMethod]
        //public static void GetOfficeName()
        //{
        //    txtSearchOffice.Focus();

        //    List<Office> OfficeList = new List<Office>();
        //    SessionId = Session["SessionId"].ToString();

        //    OfficeList = bp.FindOffice(SessionId, "");
        //    var data = from g in OfficeList where g.OfficeNameText.ToLower().StartsWith(txtSearchOffice.Text.ToLower()) select g;

        //    cblistOffice.Items.Clear();
        //    foreach (var s in data)
        //    {
        //        cblistOffice.Items.Add(s.OfficeNameText);
        //    }
        //    txtSearchOffice.Focus();
        //}


    }
}