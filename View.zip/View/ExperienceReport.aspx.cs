﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.ExperienceReports;


namespace BenefitPointSummaryPortal.View
{
    public partial class ExperienceReport : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        ExperienceReports BLExperinece = new ExperienceReports();

        string SessionId = "";
        List<int> ApplicablePlanTypeIds = new List<int>();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        //Added by Amogh Activity Log V2 Changes
        SummaryDetail sd = new SummaryDetail();
        private static string Activity = "";
        private static string Activity_Group = "";
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    objCommFun.GetUserDetails();


                    DictDepartment = sd.getDepartmentDetails();
                    Activity_Group = "Analytics";
                    Activity = "Experience Templates";

                    mvExperienceReport.ActiveViewIndex = 0;
                    LoadTypeDropDown();
                    txtsearch.Focus();
                    ddlType_SelectedIndexChanged(null, null);


                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }

        }

        #region Event Handlers
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Hide sub options
            tblSubOptions.Style.Add("display", "none");
            string SelectedType = ddlType.SelectedValue;
            // Bind LOC Options
            List<string> lstLOCs = new List<string>();
            ddlLOC.Items.Clear();
            if (SelectedType != "Select")
            {
                lstLOCs = GetLOCItems(BLExperinece.CovertToReportType(SelectedType));
                ddlLOC.DataSource = lstLOCs;
                ddlLOC.DataBind();
            }
            ddlLOC.Items.Insert(0, new ListItem("Select"));
            if (ddlLOC.Items.Count == 2)
                ddlLOC.SelectedIndex = 1;

            ddlLOC_SelectedIndexChanged(null, null);

        }
        protected void ddlLOC_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlFundingMethod.Items.Clear();
            ddlOrientation.SelectedValue = "Select";

            tblSubOptions.Rows[0].Cells[0].Style.Add("display", "none");
            tblSubOptions.Rows[0].Cells[1].Style.Add("display", "none");
            tblSubOptions.Rows[0].Cells[2].Style.Add("display", "none");
            tblSubOptions.Rows[0].Cells[3].Style.Add("display", "none");


            if (ddlType.SelectedValue != "Select" && ddlLOC.SelectedValue != "Select")
            {
                tblSubOptions.Style.Add("display", "");

                if (ddlType.SelectedValue == ExperienceReports.ReportType.Experience.ToString())
                {
                    if (ddlLOC.SelectedValue.Equals(ExperienceReports.LineOfCoverages.Dental.ToString()))
                    {
                        ddlFundingMethod.Items.Add(new ListItem(ExperienceReports.FundingMethods.Fully_Insured.ToString().Replace("_", " "), ExperienceReports.FundingMethods.Fully_Insured.ToString()));
                        ddlFundingMethod.Items.Add(new ListItem(ExperienceReports.FundingMethods.Self_Funded.ToString().Replace("_", " "), ExperienceReports.FundingMethods.Self_Funded.ToString()));

                        tblSubOptions.Rows[0].Cells[0].Style.Add("display", "");
                        tblSubOptions.Rows[0].Cells[1].Style.Add("display", "");
                    }
                    else if (ddlLOC.SelectedValue.Equals(ExperienceReports.LineOfCoverages.Medical.ToString()))
                    {
                        ddlFundingMethod.Items.Add(new ListItem(ExperienceReports.FundingMethods.Fully_Insured.ToString().Replace("_", " "), ExperienceReports.FundingMethods.Fully_Insured.ToString()));
                        ddlFundingMethod.Items.Add(new ListItem(ExperienceReports.FundingMethods.Self_Funded.ToString().Replace("_", " "), ExperienceReports.FundingMethods.Self_Funded.ToString()));

                        tblSubOptions.Rows[0].Cells[0].Style.Add("display", "");
                        tblSubOptions.Rows[0].Cells[1].Style.Add("display", "");
                    }
                }
            }
            else
            {
                tblSubOptions.Style.Add("display", "none");
            }

            ddlFundingMethod.Items.Insert(0, new ListItem("Select"));
            if (ddlFundingMethod.Items.Count == 2)
                ddlFundingMethod.SelectedIndex = 1;
            else
                ddlFundingMethod.SelectedValue = "Select";

            ddlFundingMethod_SelectedIndexChanged(null, null);
        }
        protected void ddlFundingMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.tblSubOptions.Rows[0].Cells[2].Style.Add("display", "none");
            this.tblSubOptions.Rows[0].Cells[3].Style.Add("display", "none");
            ddlTemplateName.SelectedValue = "Select";


            if (ddlType.SelectedValue != "Select" && ddlLOC.SelectedValue != "Select" && ddlFundingMethod.SelectedValue != "Select")
            {
                if (ddlType.SelectedValue == ExperienceReports.ReportType.Experience.ToString())
                {
                    if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Medical.ToString())
                    {
                        if (ddlFundingMethod.SelectedValue == ExperienceReports.FundingMethods.Fully_Insured.ToString())
                        {
                            this.tblSubOptions.Rows[0].Cells[2].Style.Add("display", "");
                            this.tblSubOptions.Rows[0].Cells[3].Style.Add("display", "");
                        }
                    }

                }
            }
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            ExperienceReports.ConfigNames SelectedOption = ExperienceReports.ConfigNames.None;
            string ConfigName = string.Empty;
            if (ValidateForm())
            {
                if (ddlType.SelectedValue == ExperienceReports.ReportType.Experience.ToString())
                {
                    ConfigName = GetConfigName_Experience();
                    SelectedOption = BLExperinece.CovertToConfigName(ConfigName);
                    switch (SelectedOption)
                    {
                        case ExperienceReports.ConfigNames.None:
                            break;
                        case ExperienceReports.ConfigNames.Experience_Dental_FI_Landscape:
                            Experience_Dental_FI_Landscape_01();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Dental_FI_Portrait:
                            Experience_Dental_FI_Portrait_02();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Dental_SF_Landscape:
                            Experience_Dental_SF_Landscape_03();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Dental_SF_Portrait:
                            Experience_Dental_SF_Portrait_04();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_FI_SinglePlan_Landscape:
                            Experience_Medical_FI_SinglePlan_Landscape_05();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_FI_SinglePlan_Portrait:
                            Experience_Medical_FI_SinglePlan_Portrait_06();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_FI_MultiPlan_Landscape:
                            Experience_Medical_FI_MultiPlan_Landscape_07();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_FI_MultiPlan_Portrait:
                            Experience_Medical_FI_MultiPlan_Portrait_08();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_SF_Landscape:
                            Experience_Medical_SF_Landscape_09();
                            break;
                        case ExperienceReports.ConfigNames.Experience_Medical_SF_Portrait:
                            Experience_Medical_SF_Portrait_10();
                            break;
                    }
                }
                if (ddlType.SelectedValue == ExperienceReports.ReportType.Utilization.ToString())
                {
                    ConfigName = GetConfigName_Utilization();
                    SelectedOption = BLExperinece.CovertToConfigName(ConfigName);
                    switch (SelectedOption)
                    {
                        case ExperienceReports.ConfigNames.Utilization_Medical_Utilization_Landscape:
                            Utilization_Medical_Utilization_Landscape_11();
                            break;
                        case ExperienceReports.ConfigNames.Utilization_Medical_Utilization_Portrait:
                            Utilization_Medical_Utilization_Portrait_12();
                            break;
                    }
                }

                #region Activity Log V2 - Added by Amogh 
                List<Contact> ContactList = new List<Contact>();
                DataSet AccountDS = new DataSet();
                sd.BuildAccountTable();
                sd.BuildAccountTeamMamberTable();
                DataSet AccountTeamMemberDS = new DataSet();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                string AdditionalCrtieriaOption_1 = ddlType.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlLOC.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion
            }
        }
        #endregion

        #region Functions
        private void ResetForm()
        {
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;
            ddlType.SelectedIndex = 0;
            ddlType_SelectedIndexChanged(null, null);
        }
        private void LoadTypeDropDown()
        {
            ddlType.Items.Add(new ListItem(ExperienceReports.ReportType.Experience.ToString()));
            ddlType.Items.Add(new ListItem(ExperienceReports.ReportType.Utilization.ToString()));
        }
        private List<string> GetLOCItems(ExperienceReports.ReportType ReportType)
        {
            List<string> lstLocs = new List<string>();
            switch (ReportType)
            {
                case ExperienceReports.ReportType.Experience:
                    lstLocs.Add(ExperienceReports.LineOfCoverages.Medical.ToString());
                    lstLocs.Add(ExperienceReports.LineOfCoverages.Dental.ToString());
                    break;
                case ExperienceReports.ReportType.Utilization:
                    lstLocs.Add(ExperienceReports.LineOfCoverages.Medical.ToString());
                    break;
            }
            return lstLocs;
        }
        private void GetTemplateNameItems()
        {

        }
        private bool ValidateForm()
        {
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return false;
            }
            if (ddlType.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type.')</script>");
                ddlType.Focus();
                return false;
            }
            if (ddlLOC.SelectedValue == "Select")
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Line of Coverage.')</script>");
                ddlLOC.Focus();
                return false;
            }

            if (ddlType.SelectedValue == ExperienceReports.ReportType.Experience.ToString())
            {
                if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Dental.ToString())
                {
                    if (ddlFundingMethod.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Funding Method.')</script>");
                        ddlFundingMethod.Focus();
                        return false;
                    }
                    if (ddlOrientation.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation.')</script>");
                        ddlOrientation.Focus();
                        return false;
                    }
                }
                else if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Medical.ToString())
                {
                    if (ddlFundingMethod.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Funding Method.')</script>");
                        ddlFundingMethod.Focus();
                        return false;
                    }
                    if (ddlFundingMethod.SelectedValue == ExperienceReports.FundingMethods.Fully_Insured.ToString())
                    {
                        if (ddlTemplateName.SelectedValue == "Select")
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Template Name.')</script>");
                            ddlTemplateName.Focus();
                            return false;
                        }
                    }
                    if (ddlOrientation.SelectedValue == "Select")
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation.')</script>");
                        ddlOrientation.Focus();
                        return false;
                    }
                }

            }
            else if (ddlType.SelectedValue == ExperienceReports.ReportType.Utilization.ToString())
            {
                if (ddlOrientation.SelectedValue == "Select")
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Orientation.')</script>");
                    ddlOrientation.Focus();
                    return false;
                }
            }

            return true;
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        #region Experience Functions
        private string GetConfigName_Experience()
        {
            string ConfigName = string.Empty;
            if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Dental.ToString())
            {
                DataRow drDentalTemplate = BLExperinece.dtblReportConfig.Select("Type = '" + ExperienceReports.ReportType.Experience.ToString() + "' AND LOC = '" + ExperienceReports.LineOfCoverages.Dental.ToString() + "' AND FundingMethod = '" + ddlFundingMethod.SelectedValue.Replace("_", " ") + "' AND PageOrientation = '" + ddlOrientation.SelectedValue + "'").FirstOrDefault();
                if (drDentalTemplate != null)
                {
                    ConfigName = drDentalTemplate["ConfigName"].ToString();
                }
            }
            if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Medical.ToString())
            {
                if (ddlFundingMethod.SelectedValue == ExperienceReports.FundingMethods.Fully_Insured.ToString())
                {
                    DataRow drMedicalFullyInsuredTemplate = BLExperinece.dtblReportConfig.Select("Type = '" + ExperienceReports.ReportType.Experience.ToString() + "' AND LOC = '" + ExperienceReports.LineOfCoverages.Medical.ToString() + "' AND FundingMethod = '" + ddlFundingMethod.SelectedValue.Replace("_", " ") + "' AND TemplateName = '" + ddlTemplateName.SelectedValue + "'  AND PageOrientation = '" + ddlOrientation.SelectedValue + "'").FirstOrDefault();
                    if (drMedicalFullyInsuredTemplate != null)
                    {
                        ConfigName = drMedicalFullyInsuredTemplate["ConfigName"].ToString();
                    }
                }
                else if (ddlFundingMethod.SelectedValue == ExperienceReports.FundingMethods.Self_Funded.ToString())
                {
                    DataRow drMedicalSelfFundedTemplate = BLExperinece.dtblReportConfig.Select("Type = '" + ExperienceReports.ReportType.Experience.ToString() + "' AND LOC = '" + ExperienceReports.LineOfCoverages.Medical.ToString() + "' AND FundingMethod = '" + ddlFundingMethod.SelectedValue.Replace("_", " ") + "' AND PageOrientation = '" + ddlOrientation.SelectedValue + "'").FirstOrDefault();
                    if (drMedicalSelfFundedTemplate != null)
                    {
                        ConfigName = drMedicalSelfFundedTemplate["ConfigName"].ToString();
                    }
                }

            }

            return ConfigName;
        }
        private void Experience_Dental_FI_Landscape_01()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/01-Dental_FI_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "2016 Cost Summary";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Dental_FI_Portrait_02()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/02-Dental_FI_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "2016 Cost Summary";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Dental_SF_Landscape_03()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/03-Dental_SF_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "2016 Cost Summary";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Dental_SF_Portrait_04()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/04-Dental_SF_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "2016 Cost Summary";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_FI_SinglePlan_Landscape_05()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/05-Medical_FI_SinglePlan_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Data Entry";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_FI_SinglePlan_Portrait_06()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/06-Medical_FI_SinglePlan_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Data Entry";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_FI_MultiPlan_Landscape_07()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/07-Medical_FI_MultiPlan_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Data Entry";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_FI_MultiPlan_Portrait_08()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/08-Medical_FI_MultiPlan_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Data Entry";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_SF_Landscape_09()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/09-Medical_SF_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Month Data";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Experience_Medical_SF_Portrait_10()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/10-Medical_SF_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Month Data";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 4);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        #endregion

        #region Utilization Funcstions
        private string GetConfigName_Utilization()
        {
            string ConfigName = string.Empty;
            if (ddlLOC.SelectedValue == ExperienceReports.LineOfCoverages.Medical.ToString())
            {
                DataRow drUtilizationMedicalTemplate = BLExperinece.dtblReportConfig.Select("Type = '" + ExperienceReports.ReportType.Utilization.ToString() + "' AND LOC = '" + ExperienceReports.LineOfCoverages.Medical.ToString() + "' AND PageOrientation = '" + ddlOrientation.SelectedValue + "'").FirstOrDefault();
                if (drUtilizationMedicalTemplate != null)
                {
                    ConfigName = drUtilizationMedicalTemplate["ConfigName"].ToString();
                }
            }
            return ConfigName;
        }
        private void Utilization_Medical_Utilization_Landscape_11()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/11-Medical_Utilization_Landscape.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Claims by Type";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        private void Utilization_Medical_Utilization_Portrait_12()
        {

            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/12-Medical_Utilization_Portrait.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExperienceReports/Documents/Templates/Downloaded/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);


                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Claims by Type";
                BLExperinece.WriteClientNameToExperienceReport(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, 1, 1);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        #endregion

    }
}