﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections;



using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Microsoft.Office.Core;
using System.Threading;
using System.Globalization;
using BenefitPointSummaryPortal.BAL.BenefitsPointTools;

namespace BenefitPointSummaryPortal.View
{
    public partial class BenefitPointTools : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        string temperror = "cs";
        #region Added by vinod : global variables
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                TitleSpan.InnerText = "BenefitPoint Tools";

                
                if (!IsPostBack)
                {
                    ddlBenefitPointTool.SelectedValue = "NewBusiness";
                    ddlBenefitPointTool_SelectedIndexChanged(null, null);
                    txtsearch.Focus();
                    objCommFun.GetUserDetails();
                    #region Added by vinod : Get daprtment details
                    DictDepartment = sd.getDepartmentDetails();
                    #endregion
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                rdlClient.SelectedIndex = 0;
                ddlBenefitPointTool.SelectedIndex = 0;
                ddlBenefitPointTool_SelectedIndexChanged(null, null);
                txtBORDate.Text = "";
                txtCommissionEffectiveDate.Text = "";
                txtOriginalPlanEffectiveDate.Text = "";
                txtRenewalDate.Text = "";
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        protected void btnSummary_Click(object sender, EventArgs e)
        {
            string BenefitsPointOption = ddlBenefitPointTool.SelectedValue;
            string mynewfile = "";
            try
            {
                #region Common
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                    ddlClient.Focus();
                    return;
                }
                if (ddlBenefitPointTool.SelectedValue == "-Select-")
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select BenefitPoint Tool.')</script>", false);
                    ddlBenefitPointTool.Focus();
                    return;
                }

                if (txtBORDate.Text.Trim() == string.Empty)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Broker of Record (BOR) Date.')</script>", false);
                    txtBORDate.Focus();
                    return;
                }
                if (txtCommissionEffectiveDate.Text.Trim() == string.Empty)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Commission Effective Date.')</script>", false);
                    txtCommissionEffectiveDate.Focus();
                    return;
                }
                if (txtOriginalPlanEffectiveDate.Text.Trim() == string.Empty)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Original Plan Effective Date of In-Force Coverage.')</script>", false);
                    txtOriginalPlanEffectiveDate.Focus();
                    return;
                }
                if (txtRenewalDate.Text.Trim() == string.Empty)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Renewal Date of In-Force Coverage.')</script>", false);
                    txtRenewalDate.Focus();
                    return;
                }
                string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
                DateTime dtBORDate = DateTime.MinValue;
                DateTime dtCommissionEffectiveDate = DateTime.MinValue;
                DateTime dtOriginalPlanEffectiveDate = DateTime.MinValue;
                DateTime dtRenewalDate = DateTime.MinValue;
                try
                {
                    dtBORDate = DateTime.ParseExact(txtBORDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);//#1
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Broker of Record (BOR) Date. Date format should be MM/DD/YYYY.')</script>", false);
                    txtBORDate.Focus();
                    return;
                }
                try
                {
                    dtCommissionEffectiveDate = DateTime.ParseExact(txtCommissionEffectiveDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);//#2
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Commission Effective Date. Date format should be MM/DD/YYYY.')</script>", false);
                    txtCommissionEffectiveDate.Focus();
                    return;
                }
                try
                {
                    dtOriginalPlanEffectiveDate = DateTime.ParseExact(txtOriginalPlanEffectiveDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);//#3
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Original Plan Effective Date of In-Force Coverage. Date format should be MM/DD/YYYY.')</script>", false);
                    txtOriginalPlanEffectiveDate.Focus();
                    return;
                }
                try
                {
                    dtRenewalDate = DateTime.ParseExact(txtRenewalDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None); //#4
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Renewal Date of In-Force Coverage. Date format should be MM/DD/YYYY.')</script>", false);
                    txtRenewalDate.Focus();
                    return;
                }



                // #2 should be greater than or equal #1
                if (dtCommissionEffectiveDate < dtBORDate)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Commission Effective Date should be greater than or equal to Broker of Record (BOR) Date.')</script>", false);
                    txtCommissionEffectiveDate.Focus();
                    return;
                }
                // #4 should be greater than or equal #1
                if (dtRenewalDate < dtBORDate)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Renewal Date of In-Force Coverage should be greater than or equal to Broker of Record (BOR) Date.')</script>", false);
                    txtRenewalDate.Focus();
                    return;
                }

                // #3 should be less than or equal #4
                if (dtOriginalPlanEffectiveDate > dtRenewalDate)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Original Plan Effective Date of In-Force Coverage should be less than or equal to Renewal Date of In-Force Coverage.')</script>", false);
                    txtOriginalPlanEffectiveDate.Focus();
                    return;
                }

                // #4 should be greater than or equal #2
                if (dtRenewalDate < dtCommissionEffectiveDate)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Renewal Date of In-Force Coverage should be greater than or equal to Commission Effective Date.')</script>", false);
                    txtCommissionEffectiveDate.Focus();
                    return;
                }

                #endregion

                if (BenefitsPointOption.Equals("NewBusiness"))
                {
                    mynewfile = CreateNewBussinessReport();
                }
                DownloadFileNew(mynewfile);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #region New Business
        private string CreateNewBussinessReport()
        {
            SessionId = Session["SessionId"].ToString();
            string SaveFileName = "";
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            DateTime dtCommissionEffectiveDate = DateTime.ParseExact(txtCommissionEffectiveDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None);//#2
            DateTime dtRenewalDate = DateTime.ParseExact(txtRenewalDate.Text.Trim(), formats, new CultureInfo("en-US"), DateTimeStyles.None); //#4
            int DayDifference = (dtRenewalDate - dtCommissionEffectiveDate).Days;

            if (DayDifference < 365)
            {
                SaveFileName = CreateNewReplaceRenewReport();
            }
            else
            {
                SaveFileName = CreateNewRenewReport();
            }

            #region Storing the Activity Logs

            List<Contact> ContactList = new List<Contact>();
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
            DataSet AccountDS = new DataSet();
            DataSet AccountTeamMemberDS = new DataSet();
            sd.BuildAccountTable();
            AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            if (ddlClient.SelectedValue != "")
            {
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            }
            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
            string Office_Region = Account_Region + " / " + Account_Office;
            string AdditionalCrtieriaOption_1 = txtBORDate.Text;
            string AdditionalCrtieriaOption_2 = txtCommissionEffectiveDate.Text;
            string AdditionalCrtieriaOption_3 = txtOriginalPlanEffectiveDate.Text;
            string AdditionalCrtieriaOption_4 = txtRenewalDate.Text;
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

            #endregion
            return SaveFileName;
        }
        private string CreateNewReplaceRenewReport()
        {
            WriteNewBusinessTemplate objReplaceRenew = new WriteNewBusinessTemplate();
            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/New_Replace_Renew.docm");
            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewReplaceRenew/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewReplaceRenew")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewReplaceRenew"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);



                objReplaceRenew.WriteToReplaceRenewTemplate(oWordDoc, oWordApp, ddlClient.SelectedItem.Text, txtBORDate.Text.Trim(), txtRenewalDate.Text.Trim(), txtOriginalPlanEffectiveDate.Text.Trim(), txtCommissionEffectiveDate.Text);
                oWordDoc.Save();
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return savefilename.ToString();

        }
        private string CreateNewRenewReport()
        {
            WriteNewBusinessTemplate objReplaceRenew = new WriteNewBusinessTemplate();
            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/New_Renew.docm");
            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewRenew/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewRenew")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitsPointTools/Documents/Templates/NewRenew"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);



                objReplaceRenew.WriteToNewRenewTemplate(oWordDoc, oWordApp, ddlClient.SelectedItem.Text, txtBORDate.Text.Trim(), txtRenewalDate.Text.Trim(), txtOriginalPlanEffectiveDate.Text.Trim(), txtCommissionEffectiveDate.Text);
                oWordDoc.Save();
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return savefilename.ToString();

        }
        #endregion

        protected void ddlBenefitPointTool_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (ddlBenefitPointTool.SelectedValue == "-Select-")
            {
                tblNewBusiness.Style.Add("display", "none");
                ScriptManager.RegisterStartupScript(this, this.GetType(), "HideSummaryButton", "HideSummaryButton();", true);
            }
            if (ddlBenefitPointTool.SelectedValue == "NewBusiness")
            {
                txtBORDate.Text = "";
                txtCommissionEffectiveDate.Text = "";
                txtOriginalPlanEffectiveDate.Text = "";
                txtRenewalDate.Text = "";
                tblNewBusiness.Style.Add("display", "");
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowSummaryButton", "ShowSummaryButton();", true);
            }
        }


        private void ValidateDate(string Date)
        {

        }
    }
}