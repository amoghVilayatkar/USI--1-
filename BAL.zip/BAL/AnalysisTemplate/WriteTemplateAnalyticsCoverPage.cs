﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;

using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;



using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;

namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteTemplateAnalyticsCoverPage
    {
        Dictionary<string, string> DictSectionTab = new Dictionary<string, string>();   //Dictionary for Tab Names
        Dictionary<string, string> DictRomanNumbers = new Dictionary<string, string>();  //Dictionary for Roman Numbers
        Dictionary<string, string> DictSectionNames = new Dictionary<string, string>();  //Dictionary for Roman Numbers

        protected void BuiltDicts()
        {
            #region Building DictSectionTab

            DictSectionTab.Clear();

            //Summaries
            DictSectionTab.Add("SummariesVersion1", "Summ 1");
            DictSectionTab.Add("SummariesVersion2", "Summ 2");
            DictSectionTab.Add("SummariesVersion3", "Summ 3");

            //Current Rates and Benefits
            DictSectionTab.Add("CurrentRatesBenefitsVersion1", "Curr Benefits Rates 1");
            DictSectionTab.Add("CurrentRatesBenefitsVersion2", "Curr Benefits Rates 2");

            //Medical
            DictSectionTab.Add("MedicalPlanVersion1", "Medical Plan 1");
            DictSectionTab.Add("MedicalPlanVersion2", "Medical Plan 2");

            //Medical Experience
            DictSectionTab.Add("MedicalExperienceVersion1", "Medical Exp. 1");
            DictSectionTab.Add("MedicalExperienceVersion2", "Medical Exp. 2");

            //Dental
            DictSectionTab.Add("DentalPlanVersion1", "Dental Plan 1");
            DictSectionTab.Add("DentalPlanVersion2", "Dental Plan 2");

            //Dental & Vision Plan
            DictSectionTab.Add("DentalVisionPlansInclude", "Dental & Vision Plan");

            //Dental Experience
            DictSectionTab.Add("DentalExperienceVersion1", "Dental Exp. 1");
            DictSectionTab.Add("DentalExperienceVersion2", "Dental Exp. 2");

            //Vision
            DictSectionTab.Add("VisionPlanVersion1", "Vision Plan 1");
            DictSectionTab.Add("VisionPlanVersion2", "Vision Plan 2");

            //Life & Disability
            DictSectionTab.Add("LifeDisabilityInclude", "Life&Disability");

            //Account Administration
            DictSectionTab.Add("AccountAdministrationVersion1", "Account Admin 1");
            DictSectionTab.Add("AccountAdministrationVersion2", "Account Admin 2");

            //Compliance
            DictSectionTab.Add("ComplianceInclude", "Compliance");

            //3d Verisk Utilization
            DictSectionTab.Add("USI3DInclude", "USI 3D");

            //Benefit Resource Center Report
            DictSectionTab.Add("BenefitResourceCenterReportInclude", "Benefit Resc. Center");

            //Renewal Timeline
            DictSectionTab.Add("RenewalTimelineInclude", "Renewal Timeline");

            #endregion

            #region Building DictRomanNumbers

            DictRomanNumbers.Clear();
            DictRomanNumbers.Add("1", "I");
            DictRomanNumbers.Add("2", "II");
            DictRomanNumbers.Add("3", "III");
            DictRomanNumbers.Add("4", "IV");
            DictRomanNumbers.Add("5", "V");
            DictRomanNumbers.Add("6", "VI");
            DictRomanNumbers.Add("7", "VII");
            DictRomanNumbers.Add("8", "VIII");
            DictRomanNumbers.Add("9", "IX");
            DictRomanNumbers.Add("10", "X");
            DictRomanNumbers.Add("11", "XI");
            DictRomanNumbers.Add("12", "XII");
            DictRomanNumbers.Add("13", "XIII");
            DictRomanNumbers.Add("14", "XIV");
            DictRomanNumbers.Add("15", "XV");
            DictRomanNumbers.Add("16", "XVI");
            DictRomanNumbers.Add("17", "XVII");
            DictRomanNumbers.Add("18", "XVIII");

            #endregion

            DictSectionNames.Clear();
            DictSectionNames.Add("Summaries", "Summaries");
            DictSectionNames.Add("Current Rates & Benefits", "Current Rates & Benefits");
            DictSectionNames.Add("Medical Plan", "Medical Plan");
            DictSectionNames.Add("Medical Experience", "Medical Experience");
            DictSectionNames.Add("Dental Plan", "Dental Plan");

            DictSectionNames.Add("Dental Experience", "Dental Experience");
            DictSectionNames.Add("Dental & Vision Plans", "Dental & Vision Plans");
            DictSectionNames.Add("Vision Plan", "Vision Plan");
            DictSectionNames.Add("Life & Disability", "Life & Disability");
            DictSectionNames.Add("Account Administration", "Account Administration");

            DictSectionNames.Add("Compliance", "Compliance");
            DictSectionNames.Add("USI 3D", "USI 3D");
            DictSectionNames.Add("Benefit Resource Center Report", "Benefit Resource Center Report");
            DictSectionNames.Add("Renewal Timeline", "Renewal Timeline");
        }

        protected DataTable AddExcelTabCloumn(DataTable sectionTable)
        {
            if (!sectionTable.Columns.Contains("ExcelTabName"))
            {
                sectionTable.Columns.Add("ExcelTabName", typeof(string));

                foreach (DataRow row in sectionTable.Rows)
                {
                    string key = (row["Section"].ToString() + row["Version"].ToString()).Replace(" ", "").Replace("&", "");
                    if (DictSectionTab.ContainsKey(key))
                    {
                        row["ExcelTabName"] = DictSectionTab[key];
                    }
                    //DictSectionNames
                    string sectionName = (row["Section"].ToString().Trim());
                    if (DictSectionNames.ContainsKey(sectionName))
                    {
                        row["Section"] = DictSectionNames[sectionName];
                    }
                }

            }
            return sectionTable;
        }

        public void WriteTemplate_AnalyticsCoverPage_Landscape(Excel.Application myExcelApp, Excel.Workbook myWorkbook, Excel.Workbook myWorkbookdest, Excel.Worksheet myWorksheet, DataTable sectionTable, int NoOfAdditionalTabs)
        {
            BuiltDicts();

            DataTable TempSectionTable = AddExcelTabCloumn(sectionTable);
            DataTable dt = new DataTable();
            dt.Columns.Add("Section", typeof(string));
            dt.Columns.Add("Version", typeof(string));
            dt.Columns.Add("Order", typeof(Int32));
            dt.Columns.Add("ExcelTabName", typeof(string));

            #region Sort on Order for which order has selected
            foreach (DataRow row in TempSectionTable.Rows)
            {
                DataRow dtRow = dt.NewRow();
                if (row["Order"].ToString().Trim() != "_" && row["Order"].ToString().Trim() != "-")
                {
                    dtRow[0] = row[0];
                    dtRow[1] = row[1];
                    dtRow[2] = Convert.ToInt32(row[2]);
                    dtRow[3] = row[3];
                    dt.Rows.Add(dtRow);
                }
            }

            DataTable SectionTable = new DataTable();
            dt.DefaultView.Sort = "Order";
            SectionTable = dt.DefaultView.ToTable();
            #endregion

            #region Add Records with no order

            foreach (DataRow row in TempSectionTable.Rows)
            {
                DataRow dtRow = SectionTable.NewRow();
                if (row["Order"].ToString().Trim() == "_" || row["Order"].ToString().Trim() == "-")
                {
                    dtRow[0] = row[0];
                    dtRow[1] = row[1];
                    dtRow[2] = 0;
                    dtRow[3] = row[3];
                    SectionTable.Rows.Add(dtRow);
                }
            }
            #endregion

            #region Add Additional Sections
            for (int i = 1; i <= NoOfAdditionalTabs; i++)
            {
                DataRow ExtraRow = SectionTable.NewRow();

                ExtraRow["Section"] = "SECTION NAME";
                ExtraRow["Version"] = i.ToString();
                ExtraRow["Order"] = 0;
                ExtraRow["ExcelTabName"] = "Add Divider " + i.ToString();
                SectionTable.Rows.Add(ExtraRow);
            }


            #endregion

            #region Writing to Excel

            ((Excel.Worksheet)myWorkbookdest.Worksheets["Disclaimer"]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);
            ((Excel.Worksheet)myWorkbookdest.Worksheets["TOC"]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);

            int index = 13;
            for (int i = 0; i < SectionTable.Rows.Count; i++)
            {
                string TabName = SectionTable.Rows[i]["ExcelTabName"].ToString();
                ((Excel.Worksheet)myWorkbookdest.Worksheets[TabName]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);

                if (DictRomanNumbers.ContainsKey((i + 1).ToString()))
                {
                    if (TabName == "Summ 3" || SectionTable.Rows[i]["Section"].ToString() == "SECTION NAME")
                    {
                        myWorkbook.Worksheets[TabName].Cells[18, 4] = "Section " + DictRomanNumbers[(i + 1).ToString()];
                    }
                    else
                    {
                        myWorkbook.Worksheets[TabName].Cells[18, 5] = "Section " + DictRomanNumbers[(i + 1).ToString()];
                    }

                    myWorkbook.Worksheets[2].Cells[index, 3] = DictRomanNumbers[(i + 1).ToString()];
                    //Section
                    myWorkbook.Worksheets[2].Cells[index, 4] = SectionTable.Rows[i]["Section"].ToString();
                    myWorkbook.Worksheets[2].Cells[index, 9] = i + 3;

                    Excel.Range range = ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("D" + index.ToString(), "I" + index.ToString());


                    #region Applying BottomBorder Styles in TOC
                    //Page Number - Yellow Background
                    ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("I" + index.ToString(), "I" + index.ToString()).Interior.Color = Excel.XlRgbColor.rgbLightYellow;


                    if (SectionTable.Rows[i]["Section"].ToString() == "SECTION NAME")
                    {
                        ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("D" + index.ToString(), "I" + index.ToString()).Interior.Color = Excel.XlRgbColor.rgbLightYellow;
                    }

                    //Underline styling
                    range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlLineStyleNone;
                    range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = Excel.XlBorderWeight.xlThin;
                    range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].ColorIndex = Excel.XlColorIndex.xlColorIndexAutomatic;

                    #endregion

                    index++;
                }

            }

            #endregion

            //Deleting last sheet (i.e Empty-Sheet)
            myWorkbook.Worksheets[myWorkbook.Worksheets.Count].Delete();

            //Make 1st Sheet ACTIVE Before Saving
            myWorkbook.Worksheets[1].Activate();
        }

        public void WriteTemplate_AnalyticsCoverPage_Portrait(Excel.Application myExcelApp, Excel.Workbook myWorkbook, Excel.Workbook myWorkbookdest, Excel.Worksheet myWorksheet, DataTable sectionTable, int NoOfAdditionalTabs)
        {
            try
            {

                BuiltDicts();

                DataTable TempSectionTable = AddExcelTabCloumn(sectionTable);
                DataTable dt = new DataTable();
                dt.Columns.Add("Section", typeof(string));
                dt.Columns.Add("Version", typeof(string));
                dt.Columns.Add("Order", typeof(Int32));
                dt.Columns.Add("ExcelTabName", typeof(string));

                #region Sort on Order for which order has selected
                foreach (DataRow row in TempSectionTable.Rows)
                {
                    DataRow dtRow = dt.NewRow();
                    if (row["Order"].ToString().Trim() != "_" && row["Order"].ToString().Trim() != "-")
                    {
                        dtRow[0] = row[0];
                        dtRow[1] = row[1];
                        dtRow[2] = Convert.ToInt32(row[2]);
                        dtRow[3] = row[3];
                        dt.Rows.Add(dtRow);
                    }
                }

                DataTable SectionTable = new DataTable();
                dt.DefaultView.Sort = "Order";
                SectionTable = dt.DefaultView.ToTable();
                #endregion

                #region Add Records with no order

                foreach (DataRow row in TempSectionTable.Rows)
                {
                    DataRow dtRow = SectionTable.NewRow();
                    if (row["Order"].ToString().Trim() == "_" || row["Order"].ToString().Trim() == "-")
                    {
                        dtRow[0] = row[0];
                        dtRow[1] = row[1];
                        dtRow[2] = 0;
                        dtRow[3] = row[3];
                        SectionTable.Rows.Add(dtRow);
                    }
                }
                #endregion

                #region Add Additional Sections
                for (int i = 1; i <= NoOfAdditionalTabs; i++)
                {
                    DataRow ExtraRow = SectionTable.NewRow();

                    ExtraRow["Section"] = "SECTION NAME";
                    ExtraRow["Version"] = i.ToString();
                    ExtraRow["Order"] = 0;
                    ExtraRow["ExcelTabName"] = "Add Divider " + i.ToString();
                    SectionTable.Rows.Add(ExtraRow);
                }


                #endregion

                #region Writing to Excel

                ((Excel.Worksheet)myWorkbookdest.Worksheets["Disclaimer"]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);
                ((Excel.Worksheet)myWorkbookdest.Worksheets["TOC"]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);

                int index = 20;
                for (int i = 0; i < SectionTable.Rows.Count; i++)
                {
                    string TabName = SectionTable.Rows[i]["ExcelTabName"].ToString();
                    ((Excel.Worksheet)myWorkbookdest.Worksheets[TabName]).Copy((Excel.Worksheet)myWorkbook.Worksheets[myWorkbook.Worksheets.Count]);

                    if (DictRomanNumbers.ContainsKey((i + 1).ToString()))
                    {
                        if (TabName == "Summ 3" || SectionTable.Rows[i]["Section"].ToString() == "SECTION NAME")
                        {
                            myWorkbook.Worksheets[TabName].Cells[24, 4] = "Section " + DictRomanNumbers[(i + 1).ToString()];
                        }
                        else if (TabName == "Benefit Resc. Center")
                        {
                            myWorkbook.Worksheets[TabName].Cells[15, 7] = "Section " + DictRomanNumbers[(i + 1).ToString()];
                        }
                        else
                        {
                            myWorkbook.Worksheets[TabName].Cells[15, 8] = "Section " + DictRomanNumbers[(i + 1).ToString()];
                        }

                        myWorkbook.Worksheets[2].Cells[index, 4] = DictRomanNumbers[(i + 1).ToString()];
                        //Section
                        myWorkbook.Worksheets[2].Cells[index, 5] = SectionTable.Rows[i]["Section"].ToString();
                        myWorkbook.Worksheets[2].Cells[index, 10] = i + 3;

                        Excel.Range range = ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("E" + index.ToString(), "J" + index.ToString());


                        #region Applying BottomBorder Styles in TOC
                        //Page Number - Yellow Background
                        ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("J" + index.ToString(), "J" + index.ToString()).Interior.Color = Excel.XlRgbColor.rgbLightYellow;


                        if (SectionTable.Rows[i]["Section"].ToString() == "SECTION NAME")
                        {
                            ((Excel.Worksheet)myWorkbook.Worksheets[2]).get_Range("E" + index.ToString(), "J" + index.ToString()).Interior.Color = Excel.XlRgbColor.rgbLightYellow;
                        }

                        //Underline styling
                        range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlLineStyleNone;
                        range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = Excel.XlBorderWeight.xlThin;
                        range.Cells.Borders[Excel.XlBordersIndex.xlEdgeBottom].ColorIndex = Excel.XlColorIndex.xlColorIndexAutomatic;

                        #endregion

                        index++;
                    }

                }

                #endregion

                //Deleting last sheet (i.e Empty-Sheet)
                myWorkbook.Worksheets[myWorkbook.Worksheets.Count].Delete();

                //Make 1st Sheet ACTIVE Before Saving
                myWorkbook.Worksheets[1].Activate();

            }
            catch (Exception ex)
            {

            }
        }
    }
}