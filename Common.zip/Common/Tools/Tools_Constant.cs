﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.Tools
{
    public class Tools_Constant
    {
        #region Variable
        string _CEO = "CEO";
        string _CFO = "CFO";
        string _HumanResources = "Human_Resources_Management";
        string _VPFinance = "VP_Finance";
        string _VPHumanResources = "VP_Human_Resources";
       
        #endregion
        /// <summary>
        /// Get Timeline1 SubjectID
        /// </summary>
        public string Tools2_CEO
        {
            get
            {
                return _CEO;
            }

        }
        public string Tools2_CFO
        {
            get
            {
                return _CFO;
            }

        }
        public string Tools2__HumanResources
        {
            get
            {
                return _HumanResources;
            }

        }
        public string Tools2_VPFinance
        {
            get
            {
                return _VPFinance;
            }

        }
        public string Tools2_VPHumanResources
        {
            get
            {
                return _VPHumanResources;
            }

        }
    }
}