﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;

namespace BenefitPointSummaryPortal.View
{
    public partial class BenefitSummaryTemplate1aspx : System.Web.UI.Page
    {
        #region Global Variable
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        DataSet AccountDS = new DataSet();
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        DataSet EligibilityDS = new DataSet();
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string temperror = "cs";

        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList();
        ArrayList WellnessBenefitColumnIdList = new ArrayList();
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        #region Added by vinod : global variables
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        SummaryDetail sdd = new SummaryDetail();
        #endregion

        //PowerPoint.Presentations objPresSet;
        #endregion

        # region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    SummaryDetail.isClientChanged_ForMedical = false;
                    SummaryDetail.isClientChanged_ForDental = false;
                    SummaryDetail.isClientChanged_ForVision = false;
                    SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;

                    #region Added by vinod : Get daprtment details
                    DictDepartment = sdd.getDepartmentDetails();
                    #endregion

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    Session["ProductSummaryTable"] = null;
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();

                    if (Convert.ToString(Session["Summary"]) == "Template5")
                    {
                        lblHeading.Text = "Summary Brochure";
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        lblVisionHeading.Text = "Vision Plan";
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template2")
                    {
                        lblHeading.Text = "FAQ Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        lblVisionHeading.Text = "Vision Plan";
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template1")
                    {
                        lblHeading.Text = "Simple Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "Template3")
                    {
                        lblHeading.Text = "Enrollment Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "Template4")
                    {
                        lblHeading.Text = "Detail Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        lblVoluntaryLifeHeading.Text = "# Voluntary Life AD&D Plans";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                        lblImgOption.Visible = true;
                        ddlImageOption.Visible = true;
                    }

                    if (Convert.ToString(Session["Summary"]) == "Template6")
                    {
                        lblHeading.Text = "Value Summary";
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        Activity_Group = "Summaries";
                        lnkColorOption.Visible = true;
                    }

                    if (Convert.ToString(Session["Summary"]) == "Template7")
                    {
                        lblHeading.Text = "Highlights Summary";
                        ddlLifeADDNoOfPlan.Items[2].Enabled = true;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        lblLifeAddHeading.Text = "# Life AD&D Plan";
                        lblGroupTermLifeHeading.Text = "# Group Term Life Plan";
                        Activity_Group = "Summaries";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                        trBensumHighlights.Visible = true;
                        //trNotice_Options.Visible = false;
                        //trNotice_Heading.Visible = false;
                        //trChip_Notice.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint1")
                    {
                        lblHeading.Text = "HSA vs. PPO Dual Choice";
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;

                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        //lblTemplateNo.Text = "#1";

                        trNotice_Heading.Visible = false;
                        trNotice_Options.Visible = false;
                        trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint2")
                    {
                        lblHeading.Text = "Dual Choice Medical";
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false; ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        lblVisionHeading.Text = "Vision Plan";
                        //lblTemplateNo.Text = "#2";

                        trNotice_Heading.Visible = false;
                        trNotice_Options.Visible = false;
                        trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    if (Convert.ToString(Session["Summary"]) == "PowerPoint3")
                    {
                        lblHeading.Text = "Single Choice Medical";
                        ddlMedicalNoOfPlan.Items[2].Enabled = false;
                        ddlMedicalNoOfPlan.Items[3].Enabled = false;
                        ddlMedicalNoOfPlan.Items[4].Enabled = false;
                        ddlDentalNoOfPlan.Items[2].Enabled = false;
                        ddlDentalNoOfPlan.Items[3].Enabled = false;
                        ddlDentalNoOfPlan.Items[4].Enabled = false;
                        ddlVisionNoOfPlan.Items[2].Enabled = false;
                        ddlVisionNoOfPlan.Items[3].Enabled = false;
                        ddlVisionNoOfPlan.Items[4].Enabled = false;
                        ddlLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[2].Enabled = false;
                        ddlVoluntaryLifeADDNoOfPlan.Items[0].Text = "Not Offered";
                        ddlVoluntaryLifeADDNoOfPlan.Items[1].Text = "Offered";
                        lblMedicalHeading.Text = "Medical Plan";
                        lblDentalHeading.Text = "Dental Plan";
                        lblVisionHeading.Text = "Vision Plan";
                        //lblTemplateNo.Text = "#3";

                        trNotice_Heading.Visible = false;
                        trNotice_Options.Visible = false;
                        trChip_Notice.Visible = false;
                        trCreditableCoverage.Visible = false;
                        trNoticeOfMarketplace.Visible = false;
                        Activity_Group = "PowerPoint";
                        lblColor.Visible = false;
                        ddlColor.Visible = false;
                    }

                    Activity = lblHeading.Text;

                    txtsearch.Focus();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                Clear();
                ClearMedical();
                ClearDental();
                ClearVision();
                SummaryDetail.isClientChanged_ForMedical = true;
                SummaryDetail.isClientChanged_ForDental = true;
                SummaryDetail.isClientChanged_ForVision = true;
                SummaryDetail.isClientChanged_ForVoluntaryLifeADD = true;
                SummaryDetail.isClientChanged_ForGroupTermLife = true;
                SummaryDetail.isClientChanged_ForLifeADD = true;
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                FindPlans();
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                Session["Contact"] = ContactList;
                ddlHRContact.DataSource = ContactList;
                ddlHRContact.DataBind();
                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                SummaryDetail.isClientChanged_ForMedical = false;
                SummaryDetail.isClientChanged_ForDental = false;
                SummaryDetail.isClientChanged_ForVision = false;
                SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                Clear();

                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }
                ddlBRC.SelectedIndex = 0;
                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlMedicalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlMedicalNoOfPlan.SelectedIndex == 0)
                {
                    ClearMedical();
                    if (ddlMedicalPlanName1 != null)
                    {
                        ddlMedicalPlanName1.Items.Clear();
                    }
                    if (ddlMedicalPlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                    if (ddlMedicalPlanName3 != null)
                    {
                        ddlMedicalPlanName3.Items.Clear();
                    }
                    //change for 4 plan
                    if (ddlMedicalPlanName4 != null)
                    {
                        ddlMedicalPlanName4.Items.Clear();
                    }
                    //change for 4 plan
                }
                string ch = ddlMedicalNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> MedicalPlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> MedicalPlanTypeList = new List<int>();

                MedicalPlanTypeList.Add(100);
                MedicalPlanTypeList.Add(110);
                MedicalPlanTypeList.Add(120);
                MedicalPlanTypeList.Add(130);
                MedicalPlanTypeList.Add(140);
                MedicalPlanTypeList.Add(150);
                MedicalPlanTypeList.Add(160);
                MedicalPlanTypeList.Add(170);
                //  MedicalPlanTypeList.Add(173);Prescription Drugs
                MedicalPlanTypeList.Add(1116);

                if (rdlMedical.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (MedicalPlanTypeList.Contains(item.ProductTypeId))
                            {
                                MedicalPlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlMedical.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (MedicalPlanTypeList.Contains(item.ProductTypeId))
                        {
                            MedicalPlanList.Add(item);
                        }
                    }
                }
                ConstantValue cv = new ConstantValue();

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in MedicalPlanList)
                {

                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.MedicalPlanType;

                    ProductSummaryTable.Rows.Add(dr);

                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
                switch (ch)
                {
                    case "1": trMedicalSection1.Visible = true;
                        trMedicalSection11.Visible = true;
                        trMedicalSection111.Visible = true;
                        trMedicalSection2.Visible = false;
                        trMedicalSection22.Visible = false;
                        trMedicalSection3.Visible = false;
                        trMedicalSection33.Visible = false;
                        //change for 4 plan
                        trMedicalSection4.Visible = false;
                        trMedicalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName1.DataSource = MedicalPlanList;
                            ddlMedicalPlanName1.DataBind();
                            ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForMedical = false;
                        }

                        ddlMedicalPlanName2.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalRate2, ddlMedicalContribution2, null);
                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3, null);
                        //change for 4 plan
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
                        //change for 4 plan
                        break;


                    case "2": trMedicalSection1.Visible = true;
                        trMedicalSection11.Visible = true;
                        trMedicalSection111.Visible = true;
                        trMedicalSection2.Visible = true;
                        trMedicalSection22.Visible = true;
                        trMedicalSection3.Visible = false;
                        trMedicalSection33.Visible = false;
                        //change for 4 plan
                        trMedicalSection4.Visible = false;
                        trMedicalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName1.DataSource = MedicalPlanList;
                            ddlMedicalPlanName1.DataBind();
                            ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName2.DataSource = MedicalPlanList;
                            ddlMedicalPlanName2.DataBind();
                            ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        SummaryDetail.isClientChanged_ForMedical = false;

                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3, null);
                        //change for 4 plan
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
                        //change for 4 plan
                        break;

                    case "3": trMedicalSection1.Visible = true;
                        trMedicalSection11.Visible = true;
                        trMedicalSection111.Visible = true;
                        trMedicalSection2.Visible = true;
                        trMedicalSection22.Visible = true;
                        trMedicalSection3.Visible = true;
                        trMedicalSection33.Visible = true;
                        //change for 4 plan
                        trMedicalSection4.Visible = false;
                        trMedicalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName1.DataSource = MedicalPlanList;
                            ddlMedicalPlanName1.DataBind();
                            ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName2.DataSource = MedicalPlanList;
                            ddlMedicalPlanName2.DataBind();
                            ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName3.DataSource = MedicalPlanList;
                            ddlMedicalPlanName3.DataBind();
                            ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
                        //change for 4 plan
                        SummaryDetail.isClientChanged_ForMedical = false;
                        break;

                    //case 4 added - change for 4 plan
                    case "4": trMedicalSection1.Visible = true;
                        trMedicalSection11.Visible = true;
                        trMedicalSection111.Visible = true;
                        trMedicalSection2.Visible = true;
                        trMedicalSection22.Visible = true;
                        trMedicalSection3.Visible = true;
                        trMedicalSection33.Visible = true;
                        //change for 4 plan
                        trMedicalSection4.Visible = true;
                        trMedicalSection44.Visible = true;
                        //change for 4 plan

                        if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName1.DataSource = MedicalPlanList;
                            ddlMedicalPlanName1.DataBind();
                            ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName2.DataSource = MedicalPlanList;
                            ddlMedicalPlanName2.DataBind();
                            ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName3.DataSource = MedicalPlanList;
                            ddlMedicalPlanName3.DataBind();
                            ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        {
                            ddlMedicalPlanName4.DataSource = MedicalPlanList;
                            ddlMedicalPlanName4.DataBind();
                            ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        SummaryDetail.isClientChanged_ForMedical = false;
                        break;

                    case "_": trMedicalSection1.Visible = false;
                        trMedicalSection11.Visible = false;
                        trMedicalSection111.Visible = false;
                        trMedicalSection2.Visible = false;
                        trMedicalSection22.Visible = false;
                        trMedicalSection3.Visible = false;
                        trMedicalSection33.Visible = false;
                        //change for 4 plan
                        trMedicalSection4.Visible = false;
                        trMedicalSection44.Visible = false;
                        //change for 4 plan
                        break;


                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlMedicalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName1.SelectedValue), ddlMedicalBenefitSummary1, ddlMedicalRate1, ddlMedicalContribution1, ddlMedicalEligibility1);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalRate1, ddlMedicalContribution1, ddlMedicalEligibility1);
            }
        }

        protected void ddlMedicalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName2.SelectedValue), ddlMedicalBenefitSummary2, ddlMedicalRate2, ddlMedicalContribution2, null);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalRate2, ddlMedicalContribution2, null);
            }
        }

        protected void ddlMedicalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName3.SelectedValue), ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3, null);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3, null);
            }
        }

        protected void ddlMedicalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlMedicalPlanName4.SelectedValue), ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
            }
        }

        protected void ddlDentalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlDentalNoOfPlan.SelectedIndex == 0)
                {
                    ClearDental();
                    if (ddlDentalPlanName1 != null)
                    {
                        ddlDentalPlanName1.Items.Clear();
                    }
                    if (ddlDentalPlanName2 != null)
                    {
                        ddlDentalPlanName2.Items.Clear();
                    }
                    if (ddlDentalPlanName3 != null)
                    {
                        ddlDentalPlanName3.Items.Clear();
                    }
                    //change for 4 plan
                    if (ddlDentalPlanName4 != null)
                    {
                        ddlDentalPlanName4.Items.Clear();
                    }
                    //change for 4 plan
                }
                string ch = ddlDentalNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> DentalPlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> DentalPlanTypeList = new List<int>();

                DentalPlanTypeList.Add(180);
                DentalPlanTypeList.Add(190);
                DentalPlanTypeList.Add(200);
                DentalPlanTypeList.Add(210);
                if (rdlDental.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (DentalPlanTypeList.Contains(item.ProductTypeId))
                            {
                                DentalPlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlDental.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (DentalPlanTypeList.Contains(item.ProductTypeId))
                        {
                            DentalPlanList.Add(item);
                        }
                    }
                }

                ConstantValue cv = new ConstantValue();

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in DentalPlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.DentalPlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
                switch (ch)
                {
                    case "1": trDentalSection1.Visible = true;
                        trDentalSection11.Visible = true;
                        trDentalSection2.Visible = false;
                        trDentalSection22.Visible = false;
                        trDentalSection3.Visible = false;
                        trDentalSection33.Visible = false;
                        //change for 4 plan
                        trDentalSection4.Visible = false;
                        trDentalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName1.DataSource = DentalPlanList;
                            ddlDentalPlanName1.DataBind();
                            ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForDental = false;
                        }

                        ddlDentalPlanName2.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalRate2, ddlDentalContribution2, null);
                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3, null);
                        //change for 4 plan
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
                        //change for 4 plan
                        break;

                    case "2": trDentalSection1.Visible = true;
                        trDentalSection11.Visible = true;
                        trDentalSection2.Visible = true;
                        trDentalSection22.Visible = true;
                        trDentalSection3.Visible = false;
                        trDentalSection33.Visible = false;
                        //change for 4 plan
                        trDentalSection4.Visible = false;
                        trDentalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName1.DataSource = DentalPlanList;
                            ddlDentalPlanName1.DataBind();
                            ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName2.DataSource = DentalPlanList;
                            ddlDentalPlanName2.DataBind();
                            ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        SummaryDetail.isClientChanged_ForDental = false;
                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3, null);
                        //change for 4 plan
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
                        //change for 4 plan
                        break;

                    case "3": trDentalSection1.Visible = true;
                        trDentalSection11.Visible = true;
                        trDentalSection2.Visible = true;
                        trDentalSection22.Visible = true;
                        trDentalSection3.Visible = true;
                        trDentalSection33.Visible = true;
                        //change for 4 plan
                        trDentalSection4.Visible = false;
                        trDentalSection44.Visible = false;
                        //change for 4 plan

                        if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName1.DataSource = DentalPlanList;
                            ddlDentalPlanName1.DataBind();
                            ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName2.DataSource = DentalPlanList;
                            ddlDentalPlanName2.DataBind();
                            ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName3.DataSource = DentalPlanList;
                            ddlDentalPlanName3.DataBind();
                            ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
                        //change for 4 plan
                        SummaryDetail.isClientChanged_ForDental = false;
                        break;

                    // case start for change for 4 plan
                    case "4": trDentalSection1.Visible = true;
                        trDentalSection11.Visible = true;
                        trDentalSection2.Visible = true;
                        trDentalSection22.Visible = true;
                        trDentalSection3.Visible = true;
                        trDentalSection33.Visible = true;
                        //change for 4 plan
                        trDentalSection4.Visible = true;
                        trDentalSection44.Visible = true;
                        //change for 4 plan

                        if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName1.DataSource = DentalPlanList;
                            ddlDentalPlanName1.DataBind();
                            ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName2.DataSource = DentalPlanList;
                            ddlDentalPlanName2.DataBind();
                            ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName3.DataSource = DentalPlanList;
                            ddlDentalPlanName3.DataBind();
                            ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        if (ddlDentalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        {
                            ddlDentalPlanName4.DataSource = DentalPlanList;
                            ddlDentalPlanName4.DataBind();
                            ddlDentalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        SummaryDetail.isClientChanged_ForDental = false;
                        break;
                    // case end for change for 4 plan
                    case "None": trDentalSection1.Visible = false;
                        trDentalSection11.Visible = false;
                        trDentalSection2.Visible = false;
                        trDentalSection22.Visible = false;
                        trDentalSection3.Visible = false;
                        trDentalSection33.Visible = false;
                        //change for 4 plan
                        trDentalSection4.Visible = false;
                        trDentalSection44.Visible = false;
                        //change for 4 plan
                        break;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlDentalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName1.SelectedValue), ddlDentalBenefitSummary1, ddlDentalRate1, ddlDentalContribution1, null);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalRate1, ddlDentalContribution1, null);
            }
        }

        protected void ddlDentalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName2.SelectedValue), ddlDentalBenefitSummary2, ddlDentalRate2, ddlDentalContribution2, null);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalRate2, ddlDentalContribution2, null);
            }
        }

        protected void ddlDentalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName3.SelectedValue), ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3, null);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3, null);
            }
        }

        protected void ddlDentalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName4.SelectedValue), ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
            }
        }

        protected void ddlVisionNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlVisionNoOfPlan.SelectedIndex == 0)
                {
                    ClearVision();
                    if (ddlVisionPlanName1 != null)
                    {
                        ddlVisionPlanName1.Items.Clear();
                    }
                    if (ddlVisionPlanName2 != null)
                    {
                        ddlVisionPlanName2.Items.Clear();
                    }
                    //change for 4 plan
                    if (ddlVisionPlanName3 != null)
                    {
                        ddlVisionPlanName3.Items.Clear();
                    }
                    if (ddlVisionPlanName4 != null)
                    {
                        ddlVisionPlanName4.Items.Clear();
                    }
                    //change for 4 plan
                }
                string ch = ddlVisionNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> VisionPlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> VisionPlanTypeList = new List<int>();

                VisionPlanTypeList.Add(230);

                if (rdlVision.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (VisionPlanTypeList.Contains(item.ProductTypeId))
                            {
                                VisionPlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlVision.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (VisionPlanTypeList.Contains(item.ProductTypeId))
                        {
                            VisionPlanList.Add(item);
                        }
                    }
                }

                ConstantValue cv = new ConstantValue();
                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in VisionPlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.VisionPlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
                switch (ch)
                {
                    case "1": trVisionSection1.Visible = true;
                        trVisionSection11.Visible = true;
                        trVisionSection2.Visible = false;
                        trVisionSection22.Visible = false;

                        //change for 4 plan
                        trVisionSection3.Visible = false;
                        trVisionSection33.Visible = false;
                        trVisionSection4.Visible = false;
                        trVisionSection44.Visible = false;
                        //change for 4 plan

                        if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName1.DataSource = VisionPlanList;
                            ddlVisionPlanName1.DataBind();
                            ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForVision = false;
                        }

                        ddlVisionPlanName2.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionRate2, ddlVisionContribution2, null);
                        //change for 4 plan
                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3, null);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);
                        //change for 4 plan                       
                        break;

                    case "2": trVisionSection1.Visible = true;
                        trVisionSection11.Visible = true;
                        trVisionSection2.Visible = true;
                        trVisionSection22.Visible = true;
                        //change for 4 plan
                        trVisionSection3.Visible = false;
                        trVisionSection33.Visible = false;
                        trVisionSection4.Visible = false;
                        trVisionSection44.Visible = false;
                        //change for 4 plan

                        if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName1.DataSource = VisionPlanList;
                            ddlVisionPlanName1.DataBind();
                            ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName2.DataSource = VisionPlanList;
                            ddlVisionPlanName2.DataBind();
                            ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3, null);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);
                        //change for 4 plan 
                        SummaryDetail.isClientChanged_ForVision = false;
                        break;
                    case "3": trVisionSection1.Visible = true;
                        trVisionSection11.Visible = true;
                        trVisionSection2.Visible = true;
                        trVisionSection22.Visible = true;
                        //change for 4 plan
                        trVisionSection3.Visible = true;
                        trVisionSection33.Visible = true;
                        trVisionSection4.Visible = false;
                        trVisionSection44.Visible = false;
                        //change for 4 plan

                        if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName1.DataSource = VisionPlanList;
                            ddlVisionPlanName1.DataBind();
                            ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName2.DataSource = VisionPlanList;
                            ddlVisionPlanName2.DataBind();
                            ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName3.DataSource = VisionPlanList;
                            ddlVisionPlanName3.DataBind();
                            ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan                       
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);
                        //change for 4 plan 
                        SummaryDetail.isClientChanged_ForVision = false;
                        break;

                    case "4": trVisionSection1.Visible = true;
                        trVisionSection11.Visible = true;
                        trVisionSection2.Visible = true;
                        trVisionSection22.Visible = true;
                        //change for 4 plan
                        trVisionSection3.Visible = true;
                        trVisionSection33.Visible = true;
                        trVisionSection4.Visible = true;
                        trVisionSection44.Visible = true;
                        //change for 4 plan

                        if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName1.DataSource = VisionPlanList;
                            ddlVisionPlanName1.DataBind();
                            ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName2.DataSource = VisionPlanList;
                            ddlVisionPlanName2.DataBind();
                            ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan
                        if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName3.DataSource = VisionPlanList;
                            ddlVisionPlanName3.DataBind();
                            ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        if (ddlVisionPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        {
                            ddlVisionPlanName4.DataSource = VisionPlanList;
                            ddlVisionPlanName4.DataBind();
                            ddlVisionPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        //change for 4 plan                       

                        SummaryDetail.isClientChanged_ForVision = false;
                        break;

                    case "None": trVisionSection1.Visible = false;
                        trVisionSection11.Visible = false;
                        trVisionSection2.Visible = false;
                        trVisionSection22.Visible = false;
                        //change for 4 plan
                        trVisionSection3.Visible = false;
                        trVisionSection33.Visible = false;
                        trVisionSection4.Visible = false;
                        trVisionSection44.Visible = false;
                        //change for 4 plan

                        break;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlVisionPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName1.SelectedValue), ddlVisionBenefitSummary1, ddlVisionRate1, ddlVisionContribution1, null);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionRate1, ddlVisionContribution1, null);
            }
        }

        protected void ddlVisionPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName2.SelectedValue), ddlVisionBenefitSummary2, ddlVisionRate2, ddlVisionContribution2, null);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionRate2, ddlVisionContribution2, null);
            }
        }

        protected void ddlVisionPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName3.SelectedValue), ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3, null);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3, null);
            }
        }

        protected void ddlVisionPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName4.SelectedValue), ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);
            }
        }

        protected void ddlLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearLifeADD();
                    if (ddlLifeADDPlanName1 != null)
                    {
                        ddlLifeADDPlanName1.Items.Clear();
                    }
                    if (ddlLifeADDPlanName2 != null)
                    {
                        ddlLifeADDPlanName2.Items.Clear();
                    }
                }
                string ch = ddlLifeADDNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> LifeADDPlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> LifeADDPlanTypeList = new List<int>();

                LifeADDPlanTypeList.Add(240);
                if (Convert.ToString(Session["Summary"]) != "Template7")
                {
                    LifeADDPlanTypeList.Add(250);
                }
                if (rdlLifeADD.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (LifeADDPlanTypeList.Contains(item.ProductTypeId))
                            {
                                LifeADDPlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlLifeADD.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (LifeADDPlanTypeList.Contains(item.ProductTypeId))
                        {
                            LifeADDPlanList.Add(item);
                        }
                    }
                }

                ConstantValue cv = new ConstantValue();
                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in LifeADDPlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.LifeADDPlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }
                switch (ch)
                {
                    case "1": trLifeADDSection1.Visible = true;
                        trLifeADDSection2.Visible = false;

                        if (ddlLifeADDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                        {
                            ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                            ddlLifeADDPlanName1.DataBind();
                            ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForLifeADD = false;
                        }

                        ddlGroupTermLifePlanName2.Items.Clear();
                        ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null, null, null);
                        break;


                    case "2": trLifeADDSection1.Visible = true;
                        trLifeADDSection2.Visible = true;

                        //ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                        //ddlLifeADDPlanName1.DataBind();
                        //ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //ddlLifeADDPlanName2.DataSource = LifeADDPlanList;
                        //ddlLifeADDPlanName2.DataBind();
                        //ddlLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));

                        if (ddlLifeADDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                        {
                            ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                            ddlLifeADDPlanName1.DataBind();
                            ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        if (ddlLifeADDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                        {
                            ddlLifeADDPlanName2.DataSource = LifeADDPlanList;
                            ddlLifeADDPlanName2.DataBind();
                            ddlLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        SummaryDetail.isClientChanged_ForLifeADD = false;
                        break;


                    case "None": trLifeADDSection1.Visible = false;
                        trLifeADDSection2.Visible = false;

                        break;
                }

                LineShadingFormatting();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLifeADDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName1.SelectedValue), ddlLifeADDBenefitSummary1, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary1, null, null, null);
            }
        }

        protected void ddlLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName2.SelectedValue), ddlLifeADDBenefitSummary2, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary2, null, null, null);
            }
        }

        protected void ddlSTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                ClearSTD();
                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> STDPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> STDPlanTypeList = new List<int>();

                    STDPlanTypeList.Add(290);

                    if (rdlSTD.SelectedIndex == 0)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (STDPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    STDPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlSTD.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (STDPlanTypeList.Contains(item.ProductTypeId))
                            {
                                STDPlanList.Add(item);
                            }
                        }
                    }

                    ConstantValue cv = new ConstantValue();

                    trSTDSection.Visible = true;
                    LineShadingFormatting();


                    ddlSTDPlanName.DataSource = STDPlanList;
                    ddlSTDPlanName.DataBind();
                    ddlSTDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in STDPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.STDPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trSTDSection.Visible = false; ;
                    LineShadingFormatting();
                }

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void ddlSTDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName.SelectedIndex > 0)
            {
                if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                {
                    lblSTDRate.Visible = true;
                    ddlSTDRate.Visible = true;
                    trSTDSection11.Visible = true;
                    BindDataToPlan(int.Parse(ddlSTDPlanName.SelectedValue), ddlSTDBenefitSummary, ddlSTDRate, null, null);
                }
                else
                {
                    lblSTDRate.Visible = false;
                    ddlSTDRate.Visible = false;
                    trSTDSection11.Visible = false;
                    BindDataToPlan(int.Parse(ddlSTDPlanName.SelectedValue), ddlSTDBenefitSummary, null, null, null);
                }
            }
            else
            {
                if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary, ddlSTDRate, null, null);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary, null, null, null);
                }
            }

            LineShadingFormatting();


        }

        protected void ddlLTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearLTD();
                if (ddlLTDNoOfPlan.SelectedIndex == 1)
                {

                    BPBusiness bp = new BPBusiness();
                    List<Plan> LTDPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> LTDPlanTypeList = new List<int>();

                    LTDPlanTypeList.Add(300);

                    if (rdlLTD.SelectedIndex == 0)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (LTDPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    LTDPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlLTD.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (LTDPlanTypeList.Contains(item.ProductTypeId))
                            {
                                LTDPlanList.Add(item);
                            }
                        }
                    }

                    ConstantValue cv = new ConstantValue();

                    trLTDSection.Visible = true;
                    LineShadingFormatting();

                    ddlLTDPlanName.DataSource = LTDPlanList;
                    ddlLTDPlanName.DataBind();
                    ddlLTDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in LTDPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.LTDPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trLTDSection.Visible = false; ;
                    LineShadingFormatting();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLTDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName.SelectedIndex > 0)
            {
                if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                {
                    lblLTDRate.Visible = true;
                    ddlLTDRate.Visible = true;
                    trLTDSection11.Visible = true;
                    BindDataToPlan(int.Parse(ddlLTDPlanName.SelectedValue), ddlLTDBenefitSummary, ddlLTDRate, null, null);
                }
                else
                {
                    lblLTDRate.Visible = false;
                    ddlLTDRate.Visible = false;
                    trLTDSection11.Visible = false;
                    BindDataToPlan(int.Parse(ddlLTDPlanName.SelectedValue), ddlLTDBenefitSummary, null, null, null);

                }
            }
            else
            {
                if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary, ddlLTDRate, null, null);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary, null, null, null);
                }
            }

            LineShadingFormatting();
        }

        protected void ddlVoluntaryLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            #region Commented Code
            //try
            //{
            //    ClearVoluntaryLifeADD();

            //    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 1)
            //    {

            //        BPBusiness bp = new BPBusiness();
            //        List<Plan> VoluntaryLifeADDPlanList = new List<Plan>();
            //        List<Plan> PlanList = new List<Plan>();
            //        PlanList = (List<Plan>)Session["PlanList"];
            //        List<int> VoluntaryLifeADDPlanTypeList = new List<int>();

            //        VoluntaryLifeADDPlanTypeList.Add(260); // For Voluntary Life
            //        VoluntaryLifeADDPlanTypeList.Add(280); // For Voluntary AD&D Life
            //        if (rdlVoluntaryLifeADD.SelectedIndex == 0)
            //        {
            //            foreach (Plan item in PlanList)
            //            {
            //                if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
            //                {
            //                    if (VoluntaryLifeADDPlanTypeList.Contains(item.ProductTypeId))
            //                    {
            //                        VoluntaryLifeADDPlanList.Add(item);
            //                    }
            //                }
            //            }
            //        }
            //        if (rdlVoluntaryLifeADD.SelectedIndex == 1)
            //        {
            //            foreach (Plan item in PlanList)
            //            {

            //                if (VoluntaryLifeADDPlanTypeList.Contains(item.ProductTypeId))
            //                {
            //                    VoluntaryLifeADDPlanList.Add(item);
            //                }

            //            }
            //        }
            //        ConstantValue cv = new ConstantValue();

            //        trVoluntaryLifeADDSection.Visible = true;
            //        trVoluntaryLifeADDSection11.Visible = true;



            //        ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
            //        ddlVoluntaryLifeADDPlanName.DataBind();
            //        ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

            //        DataTable ProductSummaryTable = CreateProductSummaryTable();

            //        foreach (var item in VoluntaryLifeADDPlanList)
            //        {
            //            DataRow dr = ProductSummaryTable.NewRow();
            //            dr["ProductId"] = item.ProductId;
            //            dr["ProductName"] = item.ProductName;
            //            dr["Carrier"] = item.CarrierName;
            //            dr["Effective"] = item.EffectiveDate;
            //            dr["Renewal"] = item.RenewalDate;
            //            dr["PolicyNumber"] = item.PolicyNumber;
            //            dr["ProductTypeDescription"] = item.ProductTypeDescription;
            //            dr["PlanType"] = cv.VoluntaryLifeADDPlanType;

            //            ProductSummaryTable.Rows.Add(dr);
            //        }
            //    }
            //    else
            //    {
            //        trVoluntaryLifeADDSection.Visible = false;
            //        trVoluntaryLifeADDSection11.Visible = false;



            //    }
            //}
            //catch (Exception ex)
            //{
            //    //Response.Write(ex.Message);
            //    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            //    Response.Redirect("~/view/ErrorNotification.aspx");
            //}
            #endregion

            #region New Code
            try
            {
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearVoluntaryLifeADD();
                    if (ddlVoluntaryLifeADDPlanName != null)
                    {
                        ddlVoluntaryLifeADDPlanName.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName2 != null)
                    {
                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                    }
                }

                //if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 1)
                //{
                string ch = ddlVoluntaryLifeADDNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> VoluntaryLifeADDPlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> VoluntaryLifeADDPlanTypeList = new List<int>();

                VoluntaryLifeADDPlanTypeList.Add(260); // For Voluntary Life
                VoluntaryLifeADDPlanTypeList.Add(280); // For Voluntary AD&D Life
                if (rdlVoluntaryLifeADD.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (VoluntaryLifeADDPlanTypeList.Contains(item.ProductTypeId))
                            {
                                VoluntaryLifeADDPlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlVoluntaryLifeADD.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (VoluntaryLifeADDPlanTypeList.Contains(item.ProductTypeId))
                        {
                            VoluntaryLifeADDPlanList.Add(item);
                        }
                    }
                }

                ConstantValue cv = new ConstantValue();

                //trVoluntaryLifeADDSection.Visible = true;
                //trVoluntaryLifeADDSection11.Visible = true;

                //ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                //ddlVoluntaryLifeADDPlanName.DataBind();
                //ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in VoluntaryLifeADDPlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.VoluntaryLifeADDPlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }

                Session["ProductSummaryTable"] = ProductSummaryTable;
                //}
                //else
                //{
                //    trVoluntaryLifeADDSection.Visible = false;
                //    trVoluntaryLifeADDSection11.Visible = false;
                //}

                switch (ch)
                {
                    case "1": trVoluntaryLifeADDSection.Visible = true;
                        if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                            {
                                trVoluntaryLifeADDSection11.Visible = false;
                            }
                            else
                            {
                                trVoluntaryLifeADDSection11.Visible = true;
                            }
                        }
                        else
                        {
                            trVoluntaryLifeADDSection11.Visible = true;
                        }


                        trVoluntaryLifeADDSection2.Visible = false;
                        trVoluntaryLifeADDSection12.Visible = false;

                        if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        {
                            ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                            ddlVoluntaryLifeADDPlanName.DataBind();
                            ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                            ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                            ddlVoluntaryLifeADDRate.Items.Clear();
                        }

                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null, null);
                        break;

                    case "Offered": trVoluntaryLifeADDSection.Visible = true;
                        if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                            {
                                trVoluntaryLifeADDSection11.Visible = false;
                            }
                            else
                            {
                                trVoluntaryLifeADDSection11.Visible = true;
                            }
                        }
                        else
                        {
                            trVoluntaryLifeADDSection11.Visible = true;
                        }
                        trVoluntaryLifeADDSection2.Visible = false;
                        trVoluntaryLifeADDSection12.Visible = false;

                        if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        {
                            ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                            ddlVoluntaryLifeADDPlanName.DataBind();
                            ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                            ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                            ddlVoluntaryLifeADDRate.Items.Clear();
                        }

                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null, null);
                        break;

                    case "2": trVoluntaryLifeADDSection.Visible = true;
                        if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                            {
                                trVoluntaryLifeADDSection11.Visible = false;
                            }
                            else
                            {
                                trVoluntaryLifeADDSection11.Visible = true;
                            }
                        }
                        else
                        {
                            trVoluntaryLifeADDSection11.Visible = true;
                        }
                        trVoluntaryLifeADDSection2.Visible = true;
                        if (ddlVoluntaryLifeADDPlanName2 != null && ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
                        {
                            if (ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName2.SelectedItem.Text.Contains("ADandD"))
                            {
                                trVoluntaryLifeADDSection12.Visible = false;
                            }
                            else
                            {
                                trVoluntaryLifeADDSection12.Visible = true;
                            }
                        }
                        else
                        {
                            trVoluntaryLifeADDSection12.Visible = true;
                        }

                        if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        {
                            ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                            ddlVoluntaryLifeADDPlanName.DataBind();
                            ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                            ddlVoluntaryLifeADDRate.Items.Clear();
                        }
                        if (ddlVoluntaryLifeADDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        {
                            ddlVoluntaryLifeADDPlanName2.DataSource = VoluntaryLifeADDPlanList;
                            ddlVoluntaryLifeADDPlanName2.DataBind();
                            ddlVoluntaryLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                            ddlVoluntaryLifeADDBenefitSummary2.Items.Clear();
                            ddlVoluntaryLifeADDRate2.Items.Clear();
                        }
                        SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                        break;

                    case "None":
                        //trVisionSection1.Visible = false;
                        trVoluntaryLifeADDSection.Visible = false;
                        trVoluntaryLifeADDSection11.Visible = false;
                        trVoluntaryLifeADDSection2.Visible = false;
                        trVoluntaryLifeADDSection12.Visible = false;
                        break;

                    case "Not Offered":
                        //trVisionSection1.Visible = false;
                        trVoluntaryLifeADDSection.Visible = false;
                        trVoluntaryLifeADDSection11.Visible = false;
                        trVoluntaryLifeADDSection2.Visible = false;
                        trVoluntaryLifeADDSection12.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            #endregion

        }

        protected void ddlVoluntaryLifeADDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            trVoluntaryLifeADDSection11.Visible = true;
            DropDownList ddlVolName1 = (DropDownList)sender;
            ddlVoluntaryLifeADDRate.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
            {
                if (ddlVolName1.SelectedItem.Text.Contains("AD&D") || ddlVolName1.SelectedItem.Text.Contains("ADD") || ddlVolName1.SelectedItem.Text.Contains("ADnD") || ddlVolName1.SelectedItem.Text.Contains("ADandD"))
                {
                    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                    if (ddlVolName1.ID == "ddlVoluntaryLifeADDPlanName")
                    {
                        trVoluntaryLifeADDSection11.Visible = false;
                    }
                    else if (ddlVolName1.ID == "ddlVoluntaryLifeADDPlanName2")
                    {
                        trVoluntaryLifeADDSection12.Visible = false;
                    }
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate, null, null);
                }
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate, null, null);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            trVoluntaryLifeADDSection12.Visible = true;
            DropDownList ddlVolName2 = (DropDownList)sender;
            ddlVoluntaryLifeADDRate2.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
            {
                if (ddlVolName2.SelectedItem.Text.Contains("AD&D") || ddlVolName2.SelectedItem.Text.Contains("ADD") || ddlVolName2.SelectedItem.Text.Contains("ADnD") || ddlVolName2.SelectedItem.Text.Contains("ADandD"))
                {
                    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, null, null, null);
                    if (ddlVolName2.ID == "ddlVoluntaryLifeADDPlanName")
                    {
                        trVoluntaryLifeADDSection11.Visible = false;
                    }
                    else if (ddlVolName2.ID == "ddlVoluntaryLifeADDPlanName2")
                    {
                        trVoluntaryLifeADDSection12.Visible = false;
                    }
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null, null);
                }
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null, null);
            }
        }

        protected void ddlEAPNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearEAP();

                if (ddlEAPNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> EAPPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> EAPPlanTypeList = new List<int>();

                    EAPPlanTypeList.Add(310);

                    if (rdlEAP.SelectedIndex == 0)
                    {

                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (EAPPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    EAPPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlEAP.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (EAPPlanTypeList.Contains(item.ProductTypeId))
                            {
                                EAPPlanList.Add(item);
                            }
                        }
                    }
                    ConstantValue cv = new ConstantValue();

                    trEAPSection.Visible = true;

                    LineShadingFormatting();

                    ddlEAPPlanName.DataSource = EAPPlanList;
                    ddlEAPPlanName.DataBind();
                    ddlEAPPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in EAPPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.EAPPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trEAPSection.Visible = false;
                    LineShadingFormatting();
                }
            }

            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlEAPPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName.SelectedValue), ddlEAPBenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary, null, null, null);
            }
        }

        protected void ddlFSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                ClearFSA();

                if (ddlFSANoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> FSAPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> FSAPlanTypeList = new List<int>();

                    FSAPlanTypeList.Add(330);

                    if (rdlFSA.SelectedIndex == 0)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (FSAPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    FSAPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlFSA.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (FSAPlanTypeList.Contains(item.ProductTypeId))
                            {
                                FSAPlanList.Add(item);
                            }
                        }
                    }

                    ConstantValue cv = new ConstantValue();

                    trFSASection.Visible = true;
                    LineShadingFormatting();

                    ddlFSAPlanName.DataSource = FSAPlanList;
                    ddlFSAPlanName.DataBind();
                    ddlFSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in FSAPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.FSAPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trFSASection.Visible = false; ;
                    LineShadingFormatting();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void ddlFSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName.SelectedValue), ddlFSABenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary, null, null, null);
            }
        }

        protected void ddlHSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearHSA();

                if (ddlHSANoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> HSAPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> HSAPlanTypeList = new List<int>();

                    HSAPlanTypeList.Add(179);

                    if (rdlHSA.SelectedIndex == 0)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (HSAPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    HSAPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlHSA.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (HSAPlanTypeList.Contains(item.ProductTypeId))
                            {
                                HSAPlanList.Add(item);
                            }
                        }
                    }

                    ConstantValue cv = new ConstantValue();

                    trHSASection.Visible = true;
                    LineShadingFormatting();

                    ddlHSAPlanName.DataSource = HSAPlanList;
                    ddlHSAPlanName.DataBind();
                    ddlHSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in HSAPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.HSAPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }

                }
                else
                {
                    trHSASection.Visible = false;
                    LineShadingFormatting();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName.SelectedValue), ddlHSABenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary, null, null, null);
            }


        }

        protected void ddlHRANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearHRA();
                if (ddlHRANoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> HRAPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> HRAPlanTypeList = new List<int>();

                    HRAPlanTypeList.Add(178);

                    if (rdlHRA.SelectedIndex == 0)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (HRAPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    HRAPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlHRA.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (HRAPlanTypeList.Contains(item.ProductTypeId))
                            {
                                HRAPlanList.Add(item);
                            }
                        }
                    }

                    ConstantValue cv = new ConstantValue();

                    trHRASection.Visible = true;

                    LineShadingFormatting();

                    ddlHRAPlanName.DataSource = HRAPlanList;
                    ddlHRAPlanName.DataBind();
                    ddlHRAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));

                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in HRAPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.HRAPlanType;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trHRASection.Visible = false; ;
                    LineShadingFormatting();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHRAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName.SelectedValue), ddlHRABenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary, null, null, null);
            }
        }

        protected void ddlAnnualLegalNotice_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlAnnualLegalNotice.SelectedIndex == 1)
                {
                    trAnual.Visible = true;
                    LineShadingFormatting();
                }
                else
                {
                    trAnual.Visible = false;
                    LineShadingFormatting();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlMedical_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearMedical();
            SummaryDetail.isClientChanged_ForMedical = true;
            ddlMedicalNoOfPlan.SelectedIndex = 0;
            trMedicalSection1.Visible = false;
            trMedicalSection11.Visible = false;
            trMedicalSection111.Visible = false;
            trMedicalSection2.Visible = false;
            trMedicalSection22.Visible = false;
            trMedicalSection3.Visible = false;
            trMedicalSection33.Visible = false;
            //change for 4 plan
            trMedicalSection4.Visible = false;
            trMedicalSection44.Visible = false;
            //change for 4 plan

        }

        protected void rdlDental_SelectedIndexChanged(object sender, EventArgs e)
        {

            ClearDental();
            SummaryDetail.isClientChanged_ForDental = true;
            ddlDentalNoOfPlan.SelectedIndex = 0;
            trDentalSection1.Visible = false;
            trDentalSection11.Visible = false;
            trDentalSection2.Visible = false;
            trDentalSection22.Visible = false;
            trDentalSection3.Visible = false;
            trDentalSection33.Visible = false;
            trDentalSection4.Visible = false;
            trDentalSection44.Visible = false;
        }


        protected void rdlVision_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearVision();
            SummaryDetail.isClientChanged_ForVision = true;
            ddlVisionNoOfPlan.SelectedIndex = 0;
            trVisionSection1.Visible = false;
            trVisionSection11.Visible = false;
            trVisionSection2.Visible = false;
            trVisionSection22.Visible = false;
            trVisionSection3.Visible = false;
            trVisionSection33.Visible = false;
            trVisionSection4.Visible = false;
            trVisionSection44.Visible = false;
        }

        protected void rdlLifeADD_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearLifeADD();
            SummaryDetail.isClientChanged_ForLifeADD = true;
            ddlLifeADDNoOfPlan.SelectedIndex = 0;
            trLifeADDSection1.Visible = false;
            trLifeADDSection2.Visible = false;
            LineShadingFormatting();
        }

        protected void rdlSTD_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearSTD();
            ddlSTDNoOfPlan.SelectedIndex = 0;
            trSTDSection.Visible = false;
            LineShadingFormatting();
        }

        protected void rdlLTD_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearLTD();
            ddlLTDNoOfPlan.SelectedIndex = 0;
            trLTDSection.Visible = false;
            LineShadingFormatting();
        }

        protected void rdlVoluntaryLifeADD_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearVoluntaryLifeADD();
            SummaryDetail.isClientChanged_ForVoluntaryLifeADD = true;
            ddlVoluntaryLifeADDNoOfPlan.SelectedIndex = 0;
            trVoluntaryLifeADDSection.Visible = false;
            trVoluntaryLifeADDSection11.Visible = false;
        }


        protected void rdlEAP_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearEAP();
            ddlEAPNoOfPlan.SelectedIndex = 0;
            trEAPSection.Visible = false;
            LineShadingFormatting();
        }

        protected void rdlFSA_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearFSA();
            ddlFSANoOfPlan.SelectedIndex = 0;
            trFSASection.Visible = false;
            LineShadingFormatting();
        }

        protected void rdlHSA_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearHSA();
            ddlHSANoOfPlan.SelectedIndex = 0;
            trHSASection.Visible = false;

            LineShadingFormatting();
        }

        protected void rdlHRA_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearHRA();
            ddlHRANoOfPlan.SelectedIndex = 0;
            trHRASection.Visible = false;

            LineShadingFormatting();
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                SummaryDetail sd = new SummaryDetail();
                CreatePlanTable();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable PlanTable = new DataTable();
                PlanTable = (DataTable)Session["PlanTable"];
                DataTable PlansTable = PlanTable;
                PlansTable.DefaultView.Sort = "[PlanType] asc";

                // For PowerPoint template 2 medical plans are mandatory so below code is for validating the same
                if (Convert.ToString(Session["Summary"]) == "PowerPoint1" || Convert.ToString(Session["Summary"]) == "PowerPoint2")
                {
                    if (ddlMedicalNoOfPlan.SelectedIndex == 1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select 2 medical plans.')</script>");
                        flag = false;
                    }
                }


                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    for (int j = 0; j < PlanTable.Rows.Count; j++)
                    {
                        if (i == j)
                        {
                            continue;

                        }
                        else
                        {
                            if (int.Parse(PlansTable.Rows[i]["ProductId"].ToString()) == int.Parse(PlansTable.Rows[j]["ProductId"].ToString()) && int.Parse(PlansTable.Rows[i]["SummaryId"].ToString()) == int.Parse(PlansTable.Rows[j]["SummaryId"].ToString()) && int.Parse(PlansTable.Rows[i]["ContributionId"].ToString()) == int.Parse(PlansTable.Rows[j]["ContributionId"].ToString()) && int.Parse(PlansTable.Rows[i]["RateId"].ToString()) == int.Parse(PlansTable.Rows[j]["RateId"].ToString()))
                            {

                                flag = false;
                                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('There is Duplicate " + PlanTable.Rows[i]["PlanType"].ToString() + ". Please Select different " + PlanTable.Rows[i]["PlanType"].ToString() + "')</script>");
                                Session["PlanTable"] = null;
                                break;
                            }
                        }

                    }
                }
                if (flag == true)
                {
                    if (Session["PlanTable"] == null)
                    {
                        CreatePlanTable();
                        PlanTable = (DataTable)Session["PlanTable"];
                    }
                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();
                    sd.BuildContributionTable();
                    sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    sd.BuildRateTable();

                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ProductDS = sd.GetProductDetail(PlanTable, SessionId);
                    BenefitDS = sd.GetBenefitSummary(PlanTable, SessionId);
                    ////try
                    ////{
                    ////    DataTable dt = sd.GetPlanContactInformation(PlanTable, SessionId);
                    ////}
                    ////catch(Exception ex)
                    ////{}
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    DataTable ProductType = new DataTable();
                    ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductType.Columns.Add("PlanNumber", typeof(string));
                    ProductType.Columns.Add("ProductId", typeof(Int32));//need to confirm ,column added for tools

                    DataRow[] foundrow = null;
                    for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    {

                        ProductType.Rows.Add();
                        ProductType.Rows[i][0] = ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"];

                        foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                        ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                        ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                        ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);//need to confirm ,column added for tools

                    }
                    BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);
                    int EleigibilityRuleId = 0;
                    if (ddlMedicalEligibility1.SelectedIndex > 0)
                    {
                        EleigibilityRuleId = Convert.ToInt32(ddlMedicalEligibility1.SelectedValue);
                    }
                    EligibilityDS = sd.GetEligibilityRule(PlanTable, SessionId, EleigibilityRuleId);

                    RateDS = sd.GetRate(PlanTable, SessionId);
                    ContributionDS = sd.GetContribution(PlanTable, SessionId);

                    BPBusiness bp = new BPBusiness();

                    DataTable Carrierspecific = bp.GetCarrierSpecific();
                    Session["Carrierspecific"] = Carrierspecific;

                    DataTable PlanTypeSpecific = bp.GetPlanTypeSpecific();
                    Session["PlanTypeSpecific"] = PlanTypeSpecific;
                    string mynewfile = "";

                    #region Added by vinod : storing the activity logs
                    List<Contact> ContactList = new List<Contact>();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    DataSet AccountTeamMemberDS = new DataSet();
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    #endregion

                    if (Convert.ToString(Session["Summary"]) == "Template1")
                    {

                        mynewfile = CreateSummaryTemplate1();
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template5")
                    {
                        /////mynewfile = CreateSummaryTemplate5();
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate5(AccountDS, AccountTeamMemberDS);
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template2")
                    {
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate2(AccountDS, AccountTeamMemberDS);
                        //// mynewfile = CreateSummaryTemplate2();
                    }

                    if (Convert.ToString(Session["Summary"]) == "Template3")
                    {
                        mynewfile = CreateSummaryTemplate3();
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template4")
                    {
                        #region Added by vinod : As per new change
                        Activity = "Benefit Summaries";
                        Activity_Group = "Communications";
                        #endregion
                        mynewfile = CreateSummaryTemplate4(AccountDS, AccountTeamMemberDS);
                        //// mynewfile = CreateSummaryTemplate4();
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template6")
                    {
                        mynewfile = CreateSummaryTemplate6();
                    }
                    if (Convert.ToString(Session["Summary"]) == "Template7")
                    {
                        mynewfile = CreateSummaryTemplate7_Highlights();
                    }

                    // For PowerPoint 1
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint1")
                    {
                        mynewfile = CreateSummaryPowerPoint1();
                    }
                    // For PowerPoint 2
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint2")
                    {
                        mynewfile = CreateSummaryPowerPoint2();
                    }

                    // For PowerPoint 3
                    if (Convert.ToString(Session["Summary"]) == "PowerPoint3")
                    {
                        mynewfile = CreateSummaryPowerPoint3();
                    }
                    DownloadFileNew(mynewfile);

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }


        }

        protected void ddlGroupTermLifeNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 0)
                {
                    ClearGroupTermLife();
                    if (ddlGroupTermLifePlanName != null)
                    {
                        ddlGroupTermLifePlanName.Items.Clear();
                    }
                    if (ddlGroupTermLifePlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                }

                string ch = ddlGroupTermLifeNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> GroupTermLifePlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> GroupTermLifePlanTypeList = new List<int>();

                GroupTermLifePlanTypeList.Add(250);
                if (rdlGroupTermLife.SelectedIndex == 0)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                        {
                            if (GroupTermLifePlanTypeList.Contains(item.ProductTypeId))
                            {
                                GroupTermLifePlanList.Add(item);
                            }
                        }
                    }
                }
                if (rdlGroupTermLife.SelectedIndex == 1)
                {
                    foreach (Plan item in PlanList)
                    {
                        if (GroupTermLifePlanTypeList.Contains(item.ProductTypeId))
                        {
                            GroupTermLifePlanList.Add(item);
                        }
                    }
                }

                ConstantValue cv = new ConstantValue();
                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in GroupTermLifePlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.GroupTermLifePlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }

                switch (ch)
                {
                    case "1": trGroupTermLifeSection1.Visible = true;
                        trGroupTermLifeSection2.Visible = false;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            trADNDSection.Attributes.Add("class", "trodd");
                            trWellnessHeading.Attributes.Add("class", "treven");
                            trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            LineShading_EAP(0);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trADNDSection.Attributes.Add("class", "trodd");
                            trWellnessHeading.Attributes.Add("class", "treven");
                            trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            trWellnessProgramSection.Attributes.Add("class", "treven");
                            LineShading_EAP(1);
                        }
                        else
                        {
                            trADNDHeading.Attributes.Add("class", "trodd");
                            trADNDNoOfPlans.Attributes.Add("class", "treven");
                            trWellnessHeading.Attributes.Add("class", "trodd");
                            trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            LineShading_EAP(1);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        }

                        ddlGroupTermLifePlanName2.Items.Clear();
                        ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null, null, null);
                        break;

                    case "2": trGroupTermLifeSection1.Visible = true;
                        trGroupTermLifeSection2.Visible = true;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            trADNDSection.Attributes.Add("class", "treven");
                            trWellnessHeading.Attributes.Add("class", "trodd");
                            trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            LineShading_EAP(1);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trADNDSection.Attributes.Add("class", "treven");
                            trWellnessHeading.Attributes.Add("class", "trodd");
                            trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            trWellnessProgramSection.Attributes.Add("class", "trodd");
                            LineShading_EAP(0);
                        }
                        else
                        {
                            trADNDHeading.Attributes.Add("class", "treven");
                            trADNDNoOfPlans.Attributes.Add("class", "trodd");
                            trWellnessHeading.Attributes.Add("class", "treven");
                            trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            LineShading_EAP(0);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        if (ddlGroupTermLifePlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName2.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName2.DataBind();
                            ddlGroupTermLifePlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        break;

                    case "None": trGroupTermLifeSection1.Visible = false;
                        trGroupTermLifeSection2.Visible = false;

                        trADNDHeading.Attributes.Add("class", "treven");
                        trADNDNoOfPlans.Attributes.Add("class", "trodd");
                        trWellnessHeading.Attributes.Add("class", "treven");
                        trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                        LineShading_EAP(0);

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlGroupTermLife_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearGroupTermLife();
            SummaryDetail.isClientChanged_ForGroupTermLife = true;
            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            trGroupTermLifeSection1.Visible = false;
            trGroupTermLifeSection2.Visible = false;

            trADNDHeading.Attributes.Add("class", "treven");
            trADNDNoOfPlans.Attributes.Add("class", "trodd");
            trWellnessHeading.Attributes.Add("class", "treven");
            trWellnessNoOfPlans.Attributes.Add("class", "trodd");
            LineShading_EAP(0);
        }

        protected void ddlGroupTermLifePlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName.SelectedValue), ddlGroupTermLifeBenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary, null, null, null);
            }
        }

        protected void ddlGroupTermLifePlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName2.SelectedValue), ddlGroupTermLifeBenefitSummary2, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null, null, null);
            }
        }

        protected void rdlADND_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearADD();
            ddlADNDNoOfPlan.SelectedIndex = 0;
            trADNDSection.Visible = false;

            if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
            {
                trADNDSection.Attributes.Add("class", "treven");
                trWellnessHeading.Attributes.Add("class", "trodd");
                trWellnessNoOfPlans.Attributes.Add("class", "treven");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    trWellnessProgramSection.Attributes.Add("class", "trodd");
                    LineShading_EAP(0);
                }
                else
                {
                    LineShading_EAP(1);
                }
            }
            else
            {
                trADNDSection.Attributes.Add("class", "trodd");
                trWellnessHeading.Attributes.Add("class", "treven");
                trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    trWellnessProgramSection.Attributes.Add("class", "treven");
                    LineShading_EAP(1);
                }
                else
                {
                    LineShading_EAP(0);
                }
            }
        }

        protected void ddlADNDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearADD();

                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> ADDPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> ADDPlanTypeList = new List<int>();
                    // ADD - 270
                    // Wellness - 317
                    ADDPlanTypeList.Add(270);

                    if (rdlADND.SelectedIndex == 0)
                    {

                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (ADDPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    ADDPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlADND.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (ADDPlanTypeList.Contains(item.ProductTypeId))
                            {
                                ADDPlanList.Add(item);
                            }
                        }
                    }
                    ConstantValue cv = new ConstantValue();

                    trADNDSection.Visible = true;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        trADNDSection.Attributes.Add("class", "trodd");
                        trWellnessHeading.Attributes.Add("class", "treven");
                        trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trWellnessProgramSection.Attributes.Add("class", "treven");
                            LineShading_EAP(1);
                        }
                        else
                        {
                            LineShading_EAP(0);
                        }
                    }
                    else
                    {
                        trADNDSection.Attributes.Add("class", "treven");
                        trWellnessHeading.Attributes.Add("class", "trodd");
                        trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trWellnessProgramSection.Attributes.Add("class", "trodd");
                            LineShading_EAP(0);
                        }
                        else
                        {
                            LineShading_EAP(1);
                        }
                    }

                    ddlADNDPlanName.DataSource = ADDPlanList;
                    ddlADNDPlanName.DataBind();
                    ddlADNDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in ADDPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.ADD;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trADNDSection.Visible = false;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        trADNDSection.Attributes.Add("class", "treven");
                        trWellnessHeading.Attributes.Add("class", "trodd");
                        trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trWellnessProgramSection.Attributes.Add("class", "trodd");
                            LineShading_EAP(0);
                        }
                        else
                        {
                            LineShading_EAP(1);
                        }
                    }
                    else
                    {
                        trADNDSection.Attributes.Add("class", "trodd");
                        trWellnessHeading.Attributes.Add("class", "treven");
                        trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            trWellnessProgramSection.Attributes.Add("class", "treven");
                            LineShading_EAP(1);
                        }
                        else
                        {
                            LineShading_EAP(0);
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlADNDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlADNDPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlADNDPlanName.SelectedValue), ddlADNDBenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlADNDBenefitSummary, null, null, null);
            }
        }

        protected void rdlWellnessProgram_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearWellness();
            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            trWellnessProgramSection.Visible = false;

            if (ddlADNDNoOfPlan.SelectedIndex == 1)
            {
                trWellnessProgramSection.Attributes.Add("class", "treven");
                LineShading_EAP(1);
            }
            else
            {
                trWellnessProgramSection.Attributes.Add("class", "trodd");
                LineShading_EAP(0);
            }
        }

        protected void ddlWellnessProgramNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearWellness();

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> WellnessPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> WellnessPlanTypeList = new List<int>();
                    // ADD - 270
                    // Wellness - 317
                    WellnessPlanTypeList.Add(317);

                    if (rdlWellnessProgram.SelectedIndex == 0)
                    {

                        foreach (Plan item in PlanList)
                        {
                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                            {
                                if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                                {
                                    WellnessPlanList.Add(item);
                                }
                            }
                        }
                    }
                    if (rdlWellnessProgram.SelectedIndex == 1)
                    {
                        foreach (Plan item in PlanList)
                        {
                            if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                            {
                                WellnessPlanList.Add(item);
                            }
                        }
                    }
                    ConstantValue cv = new ConstantValue();

                    trWellnessProgramSection.Visible = true;

                    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                    {
                        trWellnessProgramSection.Attributes.Add("class", "trodd");
                        LineShading_EAP(0);
                    }
                    else
                    {
                        trWellnessProgramSection.Attributes.Add("class", "treven");
                        LineShading_EAP(1);
                    }

                    ddlWellnessProgramPlanName.DataSource = WellnessPlanList;
                    ddlWellnessProgramPlanName.DataBind();
                    ddlWellnessProgramPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in WellnessPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.Wellness;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    trWellnessProgramSection.Visible = false; ;
                    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                    {
                        trWellnessProgramSection.Attributes.Add("class", "treven");
                        LineShading_EAP(1);
                    }
                    else
                    {
                        trWellnessProgramSection.Attributes.Add("class", "trodd");
                        LineShading_EAP(0);
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlWellnessProgramPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName.SelectedValue), ddlWellnessProgramBenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary, null, null, null);
            }
        }

        #endregion

        #region Function
        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;

                ///** Office Dropdown Enabled=False by Amogh*/
                ddlOffice.Enabled = false;

                // BRC
                List<BRC> BRCList = new List<BRC>();
                BRCList = bp.GetBRC();
                Session["BRCList"] = BRCList;
                ddlBRC.DataSource = BRCList;
                ddlBRC.DataBind();
                ddlBRC.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlBRC.Items.Insert(1, new ListItem("None", "-1"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            ddlMedicalNoOfPlan.SelectedIndex = 0;
            trMedicalSection1.Visible = false;
            trMedicalSection11.Visible = false;
            trMedicalSection111.Visible = false;
            trMedicalSection2.Visible = false;
            trMedicalSection22.Visible = false;
            trMedicalSection3.Visible = false;
            trMedicalSection33.Visible = false;
            trMedicalSection4.Visible = false;
            trMedicalSection44.Visible = false;

            ddlDentalNoOfPlan.SelectedIndex = 0;
            trDentalSection1.Visible = false;
            trDentalSection11.Visible = false;
            trDentalSection2.Visible = false;
            trDentalSection22.Visible = false;
            trDentalSection3.Visible = false;
            trDentalSection33.Visible = false;
            trDentalSection4.Visible = false;
            trDentalSection44.Visible = false;
            ddlVisionNoOfPlan.SelectedIndex = 0;
            trVisionSection1.Visible = false;
            trVisionSection11.Visible = false;
            trVisionSection2.Visible = false;
            trVisionSection22.Visible = false;
            trVisionSection3.Visible = false;
            trVisionSection33.Visible = false;
            trVisionSection4.Visible = false;
            trVisionSection44.Visible = false;
            ddlLifeADDNoOfPlan.SelectedIndex = 0;
            trLifeADDSection1.Visible = false;
            trLifeADDSection2.Visible = false;
            ddlSTDNoOfPlan.SelectedIndex = 0;
            trSTDSection.Visible = false;
            trSTDSection11.Visible = false;
            ddlLTDNoOfPlan.SelectedIndex = 0;
            trLTDSection.Visible = false;
            trLTDSection11.Visible = false;
            ddlVoluntaryLifeADDNoOfPlan.SelectedIndex = 0;
            trVoluntaryLifeADDSection.Visible = false;
            trVoluntaryLifeADDSection11.Visible = false;
            trVoluntaryLifeADDSection2.Visible = false;
            trVoluntaryLifeADDSection12.Visible = false;
            ddlEAPNoOfPlan.SelectedIndex = 0;
            trEAPSection.Visible = false;
            ddlFSANoOfPlan.SelectedIndex = 0;
            trFSASection.Visible = false;
            ddlHSANoOfPlan.SelectedIndex = 0;
            trHSASection.Visible = false;
            ddlHRANoOfPlan.SelectedIndex = 0;
            trHRASection.Visible = false;
            ddlAnnualLegalNotice.SelectedIndex = 0;
            chkAnualNotice.SelectedIndex = -1;
            trAnual.Visible = false;
            // ddlHRContact.Visible = false;
            // lblHRContact.Visible = false;
            ddlChipNotice.SelectedIndex = 0;
            rdlDental.SelectedIndex = 0;
            rdlMedical.SelectedIndex = 0;
            rdlVision.SelectedIndex = 0;
            rdlLifeADD.SelectedIndex = 0;
            rdlVoluntaryLifeADD.SelectedIndex = 0;
            rdlSTD.SelectedIndex = 0;
            rdlLTD.SelectedIndex = 0;
            rdlEAP.SelectedIndex = 0;
            rdlHRA.SelectedIndex = 0;
            rdlHSA.SelectedIndex = 0;
            rdlFSA.SelectedIndex = 0;
            rdlADND.SelectedIndex = 0;
            rdlGroupTermLife.SelectedIndex = 0;
            rdlWellnessProgram.SelectedIndex = 0;


            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            trGroupTermLifeSection1.Visible = false;
            trGroupTermLifeSection2.Visible = false;

            ddlADNDNoOfPlan.SelectedIndex = 0;
            trADNDSection.Visible = false;

            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            trWellnessProgramSection.Visible = false;


        }

        /// <summary>
        /// Clear DropdownList
        /// </summary>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void ClearDropDownList(DropDownList Benefit, DropDownList Rate, DropDownList Contribution, DropDownList Eligibility)
        {
            try
            {
                if (Benefit != null)
                {
                    Benefit.Items.Clear();
                }
                if (Rate != null)
                {
                    Rate.Items.Clear();
                }
                if (Contribution != null)
                {
                    Contribution.Items.Clear();
                }
                if (Eligibility != null)
                {
                    Eligibility.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Clear Medical BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearMedical()
        {
            ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalRate1, ddlMedicalContribution1, ddlMedicalEligibility1);
            ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalRate2, ddlMedicalContribution2, null);
            ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3, null);
            ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4, null);
        }
        /// <summary>
        /// Clear Dental BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearDental()
        {
            ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalRate1, ddlDentalContribution1, null);
            ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalRate2, ddlDentalContribution2, null);
            ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3, null);
            ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4, null);
        }
        /// <summary>
        /// Clear Vision BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVision()
        {
            ClearDropDownList(ddlVisionBenefitSummary1, ddlVisionRate1, ddlVisionContribution1, null);
            ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionRate2, ddlVisionContribution2, null);
            ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3, null);
            ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4, null);

        }
        /// <summary>
        /// Clear LifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLifeADD()
        {
            ClearDropDownList(ddlLifeADDBenefitSummary1, null, null, null);
            ClearDropDownList(ddlLifeADDBenefitSummary2, null, null, null);
        }
        /// <summary>
        /// Clear GroupTermLife BenefitSummary.
        /// </summary>
        protected void ClearGroupTermLife()
        {
            ClearDropDownList(ddlGroupTermLifeBenefitSummary, null, null, null);
            ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null, null, null);
        }
        /// <summary>
        /// Clear STD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearSTD()
        {
            ClearDropDownList(ddlSTDBenefitSummary, null, null, null);
            lblSTDRate.Visible = false;
            ddlSTDRate.Visible = false;
            trSTDSection11.Visible = false;
        }
        /// <summary>
        /// Clear LTD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLTD()
        {
            ClearDropDownList(ddlLTDBenefitSummary, null, null, null);
            lblLTDRate.Visible = false;
            ddlLTDRate.Visible = false;
            trLTDSection11.Visible = false;
        }
        /// <summary>
        /// Clear VoluntaryLifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVoluntaryLifeADD()
        {
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate, null, null);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null, null);
        }
        /// <summary>
        /// Clear EAP BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearEAP()
        {
            ClearDropDownList(ddlEAPBenefitSummary, null, null, null);

        }
        /// <summary>
        /// Clear ADD BenefitSummary.
        /// </summary>
        protected void ClearADD()
        {
            ClearDropDownList(ddlADNDBenefitSummary, null, null, null);

        }
        /// <summary>
        /// Clear Wellness BenefitSummary.
        /// </summary>
        protected void ClearWellness()
        {
            ClearDropDownList(ddlWellnessProgramBenefitSummary, null, null, null);

        }
        /// <summary>
        /// Clear FSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearFSA()
        {

            ClearDropDownList(ddlFSABenefitSummary, null, null, null);

        }
        /// <summary>
        /// Clear HSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHSA()
        {

            ClearDropDownList(ddlHSABenefitSummary, null, null, null);


        }
        /// <summary>
        /// Clear HRA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHRA()
        {

            ClearDropDownList(ddlHRABenefitSummary, null, null, null);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PlanTypeId">Select Plan TypeId</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void BindDataToPlan(int PlanTypeId, DropDownList Benefit, DropDownList Rate, DropDownList Contribution, DropDownList Eligibility)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
                List<Rate> RateList = new List<Rate>();
                List<Contribution> ContributionList = new List<Contribution>();
                List<Eligibility> EligibilityList = new List<Eligibility>();

                SessionId = Session["SessionId"].ToString();

                if (ddlClient.SelectedIndex > 0)
                {
                    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), PlanTypeId, SessionId);
                    Benefit.DataSource = BenefitSummaryList;
                    Benefit.DataBind();
                    Benefit.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Rate != null)
                {
                    RateList = bp.FindRates(PlanTypeId, SessionId);
                    Rate.DataSource = RateList;
                    Rate.DataBind();
                    Rate.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution != null)
                {
                    ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution.DataSource = ContributionList;
                    Contribution.DataBind();
                    Contribution.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Eligibility != null)
                {
                    EligibilityList = bp.FindEligibility(PlanTypeId, SessionId);//(4765506);
                    Eligibility.DataSource = EligibilityList;
                    Eligibility.DataBind();
                    Eligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                }


            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Create Plan Table of selected Plan.
        /// </summary>
        protected void CreatePlanTable()
        {
            try
            {
                BindPlanTable(ddlMedicalPlanName1, ddlMedicalBenefitSummary1, ddlMedicalRate1, ddlMedicalContribution1);
                BindPlanTable(ddlMedicalPlanName2, ddlMedicalBenefitSummary2, ddlMedicalRate2, ddlMedicalContribution2);
                BindPlanTable(ddlMedicalPlanName3, ddlMedicalBenefitSummary3, ddlMedicalRate3, ddlMedicalContribution3);
                BindPlanTable(ddlMedicalPlanName4, ddlMedicalBenefitSummary4, ddlMedicalRate4, ddlMedicalContribution4);

                BindPlanTable(ddlDentalPlanName1, ddlDentalBenefitSummary1, ddlDentalRate1, ddlDentalContribution1);
                BindPlanTable(ddlDentalPlanName2, ddlDentalBenefitSummary2, ddlDentalRate2, ddlDentalContribution2);
                BindPlanTable(ddlDentalPlanName3, ddlDentalBenefitSummary3, ddlDentalRate3, ddlDentalContribution3);
                BindPlanTable(ddlDentalPlanName4, ddlDentalBenefitSummary4, ddlDentalRate4, ddlDentalContribution4);

                BindPlanTable(ddlVisionPlanName1, ddlVisionBenefitSummary1, ddlVisionRate1, ddlVisionContribution1);
                BindPlanTable(ddlVisionPlanName2, ddlVisionBenefitSummary2, ddlVisionRate2, ddlVisionContribution2);
                BindPlanTable(ddlVisionPlanName3, ddlVisionBenefitSummary3, ddlVisionRate3, ddlVisionContribution3);
                BindPlanTable(ddlVisionPlanName4, ddlVisionBenefitSummary4, ddlVisionRate4, ddlVisionContribution4);

                BindPlanTable(ddlLifeADDPlanName1, ddlLifeADDBenefitSummary1, null, null);
                BindPlanTable(ddlLifeADDPlanName2, ddlLifeADDBenefitSummary2, null, null);

                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                {
                    if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName, ddlSTDBenefitSummary, ddlSTDRate, null);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName, ddlSTDBenefitSummary, null, null);
                    }
                }

                if (ddlLTDNoOfPlan.SelectedIndex == 1)
                {
                    if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName, ddlLTDBenefitSummary, ddlLTDRate, null);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName, ddlLTDBenefitSummary, null, null);

                    }
                }
                BindPlanTable(ddlVoluntaryLifeADDPlanName, ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeADDRate, null);
                BindPlanTable(ddlVoluntaryLifeADDPlanName2, ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2, null);

                BindPlanTable(ddlEAPPlanName, ddlEAPBenefitSummary, null, null);
                BindPlanTable(ddlFSAPlanName, ddlFSABenefitSummary, null, null);
                BindPlanTable(ddlHSAPlanName, ddlHSABenefitSummary, null, null);
                BindPlanTable(ddlHRAPlanName, ddlHRABenefitSummary, null, null);

                // Added for service calendar highlights
                BindPlanTable(ddlGroupTermLifePlanName, ddlGroupTermLifeBenefitSummary, null, null);
                BindPlanTable(ddlGroupTermLifePlanName2, ddlGroupTermLifeBenefitSummary2, null, null);

                BindPlanTable(ddlADNDPlanName, ddlADNDBenefitSummary, null, null);

                BindPlanTable(ddlWellnessProgramPlanName, ddlWellnessProgramBenefitSummary, null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Bind data to Plan Table.
        /// </summary>
        /// <param name="PlanTypeId">DropDownList Plan Type</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void BindPlanTable(DropDownList PlanType, DropDownList Benefit, DropDownList Rate, DropDownList Contribution, int PlanNumber = 0)
        {

            try
            {
                DataTable planstable = new DataTable();
                if (Session["PlanTable"] != null)
                {
                    planstable = (DataTable)Session["PlanTable"];
                }
                else
                {
                    planstable.Columns.Add("ProductId", typeof(Int32));
                    planstable.Columns.Add("ProductName", typeof(string));
                    planstable.Columns.Add("Carrier", typeof(string));
                    planstable.Columns.Add("Effective", typeof(string));
                    planstable.Columns.Add("Renewal", typeof(string));
                    planstable.Columns.Add("PolicyNumber", typeof(string));
                    planstable.Columns.Add("ProductTypeDescription", typeof(string));
                    planstable.Columns.Add("SummaryName", typeof(string));
                    planstable.Columns.Add("SummaryId", typeof(Int32));
                    planstable.Columns.Add("RateName", typeof(string));
                    planstable.Columns.Add("RateId", typeof(Int32));
                    planstable.Columns.Add("ContributionName", typeof(string));
                    planstable.Columns.Add("ContributionId", typeof(Int32));
                    planstable.Columns.Add("ContributionName_2", typeof(string));
                    planstable.Columns.Add("ContributionId_2", typeof(Int32));
                    planstable.Columns.Add("PlanType", typeof(string));
                    planstable.Columns.Add("PlanNumber", typeof(string));
                }

                DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

                if (PlanType.SelectedIndex > 0)
                {
                    DataRow[] foundrow = null;
                    foundrow = ProductSummaryTable.Select("ProductId='" + int.Parse(PlanType.SelectedValue.ToString()) + "'");
                    DataRow dr = planstable.NewRow();
                    dr["ProductId"] = PlanType.SelectedValue;
                    dr["ProductName"] = PlanType.SelectedItem.Text;
                    if (foundrow.Count() > 0)
                    {
                        dr["Carrier"] = foundrow[0]["Carrier"];
                        dr["Effective"] = foundrow[0]["Effective"];
                        dr["Renewal"] = foundrow[0]["Renewal"];
                        dr["PolicyNumber"] = foundrow[0]["PolicyNumber"];
                        dr["ProductTypeDescription"] = foundrow[0]["ProductTypeDescription"];
                        dr["PlanType"] = foundrow[0]["PlanType"];
                        dr["PlanNumber"] = foundrow[0]["PlanType"] + " " + Convert.ToString(PlanNumber);
                    }
                    else
                    {
                        dr["Carrier"] = "";
                        dr["Effective"] = "";
                        dr["Renewal"] = "";
                        dr["PolicyNumber"] = "";
                        dr["ProductTypeDescription"] = "";
                        dr["PlanType"] = "";
                        dr["PlanNumber"] = "";
                    }
                    if (Benefit.SelectedIndex > 0)
                    {
                        dr["SummaryName"] = Benefit.SelectedItem.Text;
                        dr["SummaryId"] = Benefit.SelectedValue;
                    }
                    else
                    {
                        dr["SummaryName"] = "";
                        dr["SummaryId"] = -1;
                    }
                    if (Rate != null && Rate.SelectedIndex > 0)
                    {
                        dr["RateName"] = Rate.SelectedItem.Text;
                        dr["RateId"] = Rate.SelectedValue;
                    }
                    else
                    {
                        dr["RateName"] = "";
                        dr["RateId"] = -1;
                    }
                    if (Contribution != null && Contribution.SelectedIndex > 0)
                    {
                        dr["ContributionName"] = Contribution.SelectedItem.Text;
                        dr["ContributionId"] = Contribution.SelectedValue;
                    }
                    else
                    {
                        dr["ContributionName"] = "";
                        dr["ContributionId"] = -1;
                    }


                    planstable.Rows.Add(dr);
                    Session["PlanTable"] = planstable;
                    //     Response.Write(planstable.Rows.Count);
                }
                for (int i = 0; i < planstable.Rows.Count; i++)
                {
                    if (int.Parse(planstable.Rows[i]["SummaryId"].ToString()) == -1)
                    {
                        planstable.Rows[i].Delete();
                    }
                }
                Session["PlanTable"] = planstable;


            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Create Product Summary Table of selected Plan.
        /// </summary>
        /// <returns> ProductSummaryTable</returns>
        protected DataTable CreateProductSummaryTable()
        {
            DataTable ProductSummaryTable = new DataTable();
            try
            {
                if (Session["ProductSummaryTable"] != null)
                {
                    ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
                }
                else
                {
                    ProductSummaryTable.Columns.Add("ProductId", typeof(Int32));
                    ProductSummaryTable.Columns.Add("ProductName", typeof(string));
                    ProductSummaryTable.Columns.Add("Carrier", typeof(string));
                    ProductSummaryTable.Columns.Add("Effective", typeof(string));
                    ProductSummaryTable.Columns.Add("Renewal", typeof(string));
                    ProductSummaryTable.Columns.Add("PolicyNumber", typeof(string));
                    ProductSummaryTable.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductSummaryTable.Columns.Add("PlanType", typeof(string));
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return ProductSummaryTable;
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");


                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");


                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // Group Term Life
                GroupTermLifeBenefitColumnIdList.Add("127");

                // ADD
                ADDBenefitColumnIdList.Add("129");

                // Wellness
                WellnessBenefitColumnIdList.Add("162");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateSummaryTemplate1()
        {

            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report1"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example1_v5.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report1/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate1 wt = new WriteTemplate1();
                wt.WriteFieldToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice);
                wt.WriteMedicalSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WritePrescriptionDrugsSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable, CarrierSpecific, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, ddlDentalNoOfPlan.SelectedIndex);
                wt.WriteVisionBenefitsSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList);
                wt.WriteGroupLifeADDBenifitToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList);
                wt.WriteLTDSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList);
                wt.WriteVoluntaryLifeADDBenefitToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteFSASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                wt.WriteHRASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName);
                wt.WriteHSASectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList);
                wt.WriteEAPSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, RateDS, ContributionDS, PlanTable);
                wt.WriteContactinformationToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary1" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Create Summary Template2
        /// </summary>
        protected string CreateSummaryTemplate2(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report2"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example2_v2.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report2/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();

                WriteTemplate2 wt = new WriteTemplate2();
                wt.WriteFieldToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList);
                wt.WriteMedicalSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, ddlMedicalNoOfPlan.SelectedItem.Text, CarrierSpecific);
                wt.WritePrescriptionDrugsSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific);
                wt.WriteVisionSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, VisionBenefitColumnIdOutNetworkList);
                wt.WriteVoluntaryLifeToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteGroupLifeADDBenifitToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteSTDSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteLTDSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan);
                wt.WriteEAPSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ContributionDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteNoticeSectionToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlAnnualLegalNotice, chkAnualNotice, ddlChipNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);
                wt.WriteContactInformationToTemplate2(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.DeleteDisabilityRow(wobj.office.oWordDoc, wobj.office.oWordApp);
                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary2" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Storing the activity logs

                string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlMedicalPlanName1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlMedicalBenefitSummary1.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Create Summary Template5
        /// </summary>
        protected string CreateSummaryTemplate5(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {

                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report5")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report5"));
                }

                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary-Example5_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report5/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();

                WriteTemplate5 wt = new WriteTemplate5();
                wt.WriteFieldToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient.SelectedItem.Text, AccountDS);
                wt.WriteMedicalSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan);
                wt.WriteDentalSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList);
                wt.WriteVisionSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific);
                wt.WriteLifeADDToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific);
                wt.WriteVoluntaryLifeToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, CarrierSpecific);
                wt.WriteLTDSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, CarrierSpecific, ddlSTDNoOfPlan, ddlSTDPlanName);
                wt.WriteFSASectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific);
                wt.WriteEAPSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, CarrierSpecific);
                wt.WritePrescriptionDrugsSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WriteMonthlyPremiumSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WritePlanNameToTemplate5(ddlMedicalNoOfPlan.SelectedIndex, ddlDentalNoOfPlan.SelectedIndex, ddlEAPNoOfPlan.SelectedIndex, ddlFSANoOfPlan.SelectedIndex, ddlSTDNoOfPlan.SelectedIndex, ddlLTDNoOfPlan.SelectedIndex, ddlLifeADDNoOfPlan.SelectedIndex, ddlVoluntaryLifeADDNoOfPlan.SelectedIndex, ddlVisionNoOfPlan.SelectedIndex, wobj.office.oWordDoc, wobj.office.oWordApp);
                wt.WriteNoticeSectionToTemplate5(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);
                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary5" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Storing the activity logs
                string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlMedicalPlanName1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlMedicalBenefitSummary1.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion

                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

            }

            return (wobj.Save_File);
        }
        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        /// <summary>
        /// Get all the plan for selected client.
        /// </summary>
        private void FindPlans()
        {
            BPBusiness bp = new BPBusiness();
            List<Plan> PlanList = new List<Plan>();
            Session["PlanList"] = null;
            SessionId = Session["SessionId"].ToString();
            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            Session["PlanList"] = PlanList;
        }



        ///Function for Templeate 3
        ///
        protected string CreateSummaryTemplate3()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report3")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report3"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example3_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report3/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate3 wt = new WriteTemplate3();
                wt.WriteFieldToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList);
                wt.WriteMedicalSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan);
                wt.WritePrescriptionDrugsSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WriteDentalSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, DentalBenefitColumnIdList, CarrierSpecific, PlanTypeSpecific);
                wt.WriteVisionSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, CarrierSpecific, ddlDentalNoOfPlan);
                wt.WriteLifeADDToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific);
                wt.WriteSTDSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlSTDPlanName);
                wt.WriteLTDSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlSTDNoOfPlan, ddlLTDPlanName);
                wt.WriteVoluntaryLifeToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteContactinformationToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlMarketplaceCoverage, ddlCreditableCoverage);
                wt.WritePlanCarrierTemplate3(wobj.office.oWordDoc, wobj.office.oWordApp);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary3" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        ///Function for Templeate 4
        ///
        protected string CreateSummaryTemplate4(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report4")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report4"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example4_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report4/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate4 wt = new WriteTemplate4();
                wt.WriteFieldToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, ddlAnnualLegalNotice, ddlChipNotice, ddlImageOption);
                wt.WriteMedicalSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan);
                wt.WritePrescriptionDrugsSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList);
                wt.WriteVisionSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific);
                wt.WriteLifeADDToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific);
                wt.WriteSTDSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlSTDPlanName);
                wt.WriteLTDSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlClient, ddlLTDPlanName);
                wt.WriteVoluntaryLifeToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ProductDS);
                wt.WriteFSASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific);
                wt.WriteHRASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS);
                wt.WriteHSASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList);
                wt.WriteEAPSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, CarrierSpecific);
                wt.WriteContactinformationToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlBRC, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary4" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Storing the activity logs
                string AdditionalCrtieriaOption_1 = ddlHRContact.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlBRC.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlMedicalPlanName1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlMedicalBenefitSummary1.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion

                ////  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        ///Function for Templeate 6
        ///
        protected string CreateSummaryTemplate6()
        {
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            string color = ddlColor.SelectedValue.ToString();

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report6"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/BenefitSummary-Example6_v1.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report6/NewDocument";

                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate6 wt = new WriteTemplate6();
                wt.WriteFieldToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, color);
                wt.WriteMedicalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, color);
                wt.WritePrescriptionDrugsSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, color);
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, color);
                    //wt.WriteDentalSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, color);
                }
                //if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                //{
                wt.WriteLifeADDBenifitToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, ddlLTDNoOfPlan, color);
                //}
                //if (ddlSTDNoOfPlan.SelectedIndex > 0)
                //{
                wt.WriteSTDSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, ddlLTDNoOfPlan, ddlClient, ddlSTDPlanName, ddlLifeADDNoOfPlan, ddlSTDNoOfPlan, color);
                //}
                //wt.WriteLTDSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, ddlClient, ddlLTDPlanName);
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, color);
                }
                wt.WriteMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS, color);
                //wt.WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS);
                wt.WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, color);
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, CarrierSpecific, color);
                }
                //wt.WriteHRASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS);
                //wt.WriteHSASectionToTemplate4(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList);
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, color);
                }
                wt.WriteContactinformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, color);
                //if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                //{
                wt.WriteNoticeSectionToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, color, ddlMarketplaceCoverage, ddlCreditableCoverage);
                //}
                wt.WriteTableOfContentInformationToTemplate6(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, ddlAnnualLegalNotice, ddlChipNotice, ddlBRC, color);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary6" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Create Summary Template7 Highlights
        /// </summary>
        protected string CreateSummaryTemplate7_Highlights()
        {

            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report7"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_Example7_Highlights.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report7/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                LoadColumnIdArrayList();
                WriteTemplate7_Highlights wt = new WriteTemplate7_Highlights();

                wt.WriteFieldToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice);
                wt.WriteMedicalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, ddlMedicalNoOfPlan, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList);
                wt.WritePrescriptionDrugsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ProductDS, PlanTable, CarrierSpecific, BenefitDS, MedicalBenefitColumnIdList);
                wt.WriteDentalSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific, PlanTypeSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList);
                wt.WriteVisionBenefitsSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList);
                wt.WriteLifeADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList);
                wt.WriteGroupTermLifeBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, GroupTermLifeBenefitColumnIdList);
                wt.WriteADDBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, ADDBenefitColumnIdList);
                wt.WriteWellnessBenifitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, WellnessBenefitColumnIdList);
                wt.WriteSTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList);
                wt.WriteLTDSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList);
                wt.WriteVoluntaryLifeADDBenefitToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList);
                wt.WriteFSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, PlanTypeSpecific, BenefitDS, FSABenefitColumnIdList);
                wt.WriteHRASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ddlHRAPlanName, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList);
                wt.WriteHSASectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, CarrierSpecific, HSABenefitColumnIdList, ddlClient.SelectedItem.Text, ddlHSAPlanName);
                wt.WriteEAPSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList);
                wt.WriteMonthlyPremiumSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, RateDS, ContributionDS);
                //wt.WriteContactinformationToTemplate1(wobj.office.oWordDoc, wobj.office.oWordApp, PlanTable, CarrierSpecific);
                wt.WriteNoticeSectionToTemplate7(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, ddlAnnualLegalNotice, chkAnualNotice, ddlMarketplaceCoverage, ddlCreditableCoverage);

                RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary7" });
                temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
                bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        private void LineShadingFormatting()
        {
            // For loop for Life_ADnD and its subs line shading changes
            for (int i = 0; i <= 1; i++)
            {
                // If Life_ADnD is not selected
                if (i == 0)
                {
                    if (ddlLifeADDNoOfPlan.SelectedIndex == i)
                    {
                        trLifeADDHeading.Attributes.Add("class", "treven");
                        trLifeADDNoOfPlans.Attributes.Add("class", "trodd");

                        if (trLifeADDSection2.Visible == false)
                        {
                            trVolLifeHeading.Attributes.Add("class", "treven");
                            trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                            LineShading_STD(1);
                        }
                        else if (trLifeADDSection2.Visible == true)
                        {
                            trVolLifeHeading.Attributes.Add("class", "trodd");
                            trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                            LineShading_STD(i);
                        }
                    }
                }
                // If Life_ADnD is selected
                else if (i == 1)
                {
                    if (ddlLifeADDNoOfPlan.SelectedIndex == i || ddlLifeADDNoOfPlan.SelectedIndex == 2)
                    {
                        trLifeADDHeading.Attributes.Add("class", "treven");
                        trLifeADDNoOfPlans.Attributes.Add("class", "trodd");
                        trLifeADDSection1.Attributes.Add("class", "treven");

                        if (trSTDSection11.Visible == false)
                        {
                            trVolLifeHeading.Attributes.Add("class", "trodd");
                            trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                            if (ddlLifeADDNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_STD(0);
                            }
                            else
                            {
                                LineShading_STD(i);
                            }
                        }
                        else if (trLifeADDSection2.Visible == true)
                        {
                            trVolLifeHeading.Attributes.Add("class", "treven");
                            trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                            trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                            trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                            if (ddlLifeADDNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_STD(1);
                            }
                            else
                            {
                                LineShading_STD(i);
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_STD(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for STD and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If STD is not selected
                    if (i == 0)
                    {
                        if (ddlSTDNoOfPlan.SelectedIndex == i)
                        {
                            trSTDHeading.Attributes.Add("class", "trodd");
                            trSTDNoOfPlans.Attributes.Add("class", "treven");

                            if (trSTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");
                                trADNDSection.Attributes.Add("class", "trodd");
                                trWellnessHeading.Attributes.Add("class", "treven");
                                trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                trWellnessProgramSection.Attributes.Add("class", "treven");

                                if (ddlLifeADDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(0);
                                }
                                else
                                {
                                    LineShading_LTD(1);
                                }
                            }
                            else if (trSTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");
                                trADNDSection.Attributes.Add("class", "trodd");
                                trWellnessHeading.Attributes.Add("class", "treven");
                                trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                trWellnessProgramSection.Attributes.Add("class", "treven");

                                LineShading_LTD(i);
                            }
                        }
                    }
                    // If STD is selected
                    else if (i == 1)
                    {
                        if (ddlSTDNoOfPlan.SelectedIndex == i)
                        {
                            trSTDHeading.Attributes.Add("class", "trodd");
                            trSTDNoOfPlans.Attributes.Add("class", "treven");
                            trSTDSection.Attributes.Add("class", "trodd");

                            if (trSTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                if (ddlLifeADDNoOfPlan.SelectedIndex == 0 && ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(0);
                                }
                                else if (ddlLifeADDNoOfPlan.SelectedIndex == 1 && ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(1);
                                }
                                else
                                {
                                    LineShading_LTD(i);
                                }
                            }
                            else if (trSTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(1);
                                }
                                else
                                {
                                    LineShading_LTD(i);
                                }
                            }
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for STD and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If STD is not selected
                    if (i == 0)
                    {
                        if (ddlSTDNoOfPlan.SelectedIndex == i)
                        {
                            trSTDHeading.Attributes.Add("class", "treven");
                            trSTDNoOfPlans.Attributes.Add("class", "trodd");

                            if (trSTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");

                                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                                {
                                    trADNDSection.Attributes.Add("class", "treven");
                                    trWellnessHeading.Attributes.Add("class", "trodd");
                                    trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                    trWellnessProgramSection.Attributes.Add("class", "trodd");
                                }
                                else
                                {
                                    trWellnessHeading.Attributes.Add("class", "treven");
                                    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                    trWellnessProgramSection.Attributes.Add("class", "treven");
                                }

                                LineShading_LTD(1);
                            }
                            else if (trSTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");
                                trADNDSection.Attributes.Add("class", "trodd");
                                trWellnessHeading.Attributes.Add("class", "treven");
                                trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                trWellnessProgramSection.Attributes.Add("class", "treven");

                                LineShading_LTD(i);
                            }
                        }
                    }
                    // If STD is selected
                    else if (i == 1)
                    {
                        if (ddlSTDNoOfPlan.SelectedIndex == i)
                        {
                            trSTDHeading.Attributes.Add("class", "treven");
                            trSTDNoOfPlans.Attributes.Add("class", "trodd");
                            trSTDSection.Attributes.Add("class", "treven");

                            if (trSTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");

                                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                                {
                                    trADNDSection.Attributes.Add("class", "trodd");
                                    trWellnessHeading.Attributes.Add("class", "treven");
                                    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                    trWellnessProgramSection.Attributes.Add("class", "treven");
                                }
                                else
                                {
                                    if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                    {
                                        trWellnessHeading.Attributes.Add("class", "trodd");
                                        trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                        trWellnessProgramSection.Attributes.Add("class", "trodd");
                                    }
                                    else
                                    {
                                        trWellnessHeading.Attributes.Add("class", "treven");
                                        trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                        trWellnessProgramSection.Attributes.Add("class", "treven");
                                    }
                                }
                                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(0);
                                }
                                else
                                {
                                    LineShading_LTD(i);
                                }
                            }
                            else if (trSTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                if (ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_LTD(1);
                                }
                                else
                                {
                                    LineShading_LTD(i);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_LTD(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for LTD and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If LTD is not selected
                    if (i == 0)
                    {
                        if (ddlLTDNoOfPlan.SelectedIndex == i)
                        {
                            trLTDHeading.Attributes.Add("class", "trodd");
                            trLTDNoOfPlans.Attributes.Add("class", "treven");

                            if (trLTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                //trGroupTermHeading.Attributes.Add("class", "trodd");
                                //trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                //trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                //trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                //trADNDHeading.Attributes.Add("class", "trodd");
                                //trADNDNoOfPlans.Attributes.Add("class", "treven");
                                //trADNDSection.Attributes.Add("class", "trodd");
                                //trWellnessHeading.Attributes.Add("class", "treven");
                                //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                //trWellnessProgramSection.Attributes.Add("class", "treven");

                                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(1);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                            else if (trLTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                LineShading_EAP(i);
                            }
                        }
                    }
                    // If LTD is selected
                    else if (i == 1)
                    {
                        if (ddlLTDNoOfPlan.SelectedIndex == i)
                        {
                            trLTDHeading.Attributes.Add("class", "trodd");
                            trLTDNoOfPlans.Attributes.Add("class", "treven");
                            trLTDSection.Attributes.Add("class", "trodd");

                            if (trLTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");

                                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                                {
                                    trADNDSection.Attributes.Add("class", "treven");
                                    trWellnessHeading.Attributes.Add("class", "trodd");
                                    trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                    trWellnessProgramSection.Attributes.Add("class", "trodd");
                                }
                                else
                                {
                                    trWellnessHeading.Attributes.Add("class", "treven");
                                    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                    trWellnessProgramSection.Attributes.Add("class", "treven");
                                }
                                //trADNDSection.Attributes.Add("class", "treven");
                                //trWellnessHeading.Attributes.Add("class", "trodd");
                                //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                //trWellnessProgramSection.Attributes.Add("class", "trodd");

                                //if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                //{
                                //    trWellnessHeading.Attributes.Add("class", "trodd");
                                //    trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                //    trWellnessProgramSection.Attributes.Add("class", "trodd");
                                //}
                                //else
                                //{
                                //    trWellnessHeading.Attributes.Add("class", "treven");
                                //    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                //    trWellnessProgramSection.Attributes.Add("class", "treven");
                                //}

                                if (ddlLifeADDNoOfPlan.SelectedIndex == 0 && ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(1);
                                }
                                else if (ddlLifeADDNoOfPlan.SelectedIndex == 1 || (ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 1))
                                {
                                    LineShading_EAP(0);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                            else if (trLTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(0);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for LTD and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If LTD is not selected
                    if (i == 0)
                    {
                        if (ddlLTDNoOfPlan.SelectedIndex == i)
                        {
                            trLTDHeading.Attributes.Add("class", "treven");
                            trLTDNoOfPlans.Attributes.Add("class", "trodd");

                            if (trLTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");

                                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                                {
                                    trADNDSection.Attributes.Add("class", "treven");
                                    trWellnessHeading.Attributes.Add("class", "trodd");
                                    trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                    trWellnessProgramSection.Attributes.Add("class", "trodd");
                                }
                                else
                                {
                                    trWellnessHeading.Attributes.Add("class", "treven");
                                    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                    trWellnessProgramSection.Attributes.Add("class", "treven");
                                }

                                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(1);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                            else if (trLTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");
                                trADNDSection.Attributes.Add("class", "trodd");
                                trWellnessHeading.Attributes.Add("class", "treven");
                                trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                trWellnessProgramSection.Attributes.Add("class", "treven");

                                LineShading_EAP(i);
                            }
                        }
                    }
                    // If LTD is selected
                    else if (i == 1)
                    {
                        if (ddlLTDNoOfPlan.SelectedIndex == i)
                        {
                            trLTDHeading.Attributes.Add("class", "treven");
                            trLTDNoOfPlans.Attributes.Add("class", "trodd");
                            trLTDSection.Attributes.Add("class", "treven");

                            if (trLTDSection11.Visible == false)
                            {
                                trVolLifeHeading.Attributes.Add("class", "trodd");
                                trVolLifeNoOfPlans.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "treven");

                                trGroupTermHeading.Attributes.Add("class", "trodd");
                                trGroupTermNoOfPlans.Attributes.Add("class", "treven");
                                trGroupTermLifeSection1.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection2.Attributes.Add("class", "treven");
                                trADNDHeading.Attributes.Add("class", "trodd");
                                trADNDNoOfPlans.Attributes.Add("class", "treven");

                                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                                {
                                    trADNDSection.Attributes.Add("class", "trodd");
                                    trWellnessHeading.Attributes.Add("class", "treven");
                                    trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                                    trWellnessProgramSection.Attributes.Add("class", "treven");
                                }
                                else
                                {
                                    trWellnessHeading.Attributes.Add("class", "trodd");
                                    trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                    trWellnessProgramSection.Attributes.Add("class", "trodd");
                                }

                                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(1);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                            else if (trLTDSection11.Visible == true)
                            {
                                trVolLifeHeading.Attributes.Add("class", "treven");
                                trVolLifeNoOfPlans.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection11.Attributes.Add("class", "trodd");
                                trVoluntaryLifeADDSection2.Attributes.Add("class", "treven");
                                trVoluntaryLifeADDSection12.Attributes.Add("class", "trodd");

                                trGroupTermHeading.Attributes.Add("class", "treven");
                                trGroupTermNoOfPlans.Attributes.Add("class", "trodd");
                                trGroupTermLifeSection1.Attributes.Add("class", "treven");
                                trGroupTermLifeSection2.Attributes.Add("class", "trodd");
                                trADNDHeading.Attributes.Add("class", "treven");
                                trADNDNoOfPlans.Attributes.Add("class", "trodd");
                                trADNDSection.Attributes.Add("class", "treven");
                                trWellnessHeading.Attributes.Add("class", "trodd");
                                trWellnessNoOfPlans.Attributes.Add("class", "treven");
                                trWellnessProgramSection.Attributes.Add("class", "trodd");

                                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1)
                                {
                                    LineShading_EAP(0);
                                }
                                else
                                {
                                    LineShading_EAP(i);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_EAP(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for EAP and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If EAP is not selected
                    if (i == 0)
                    {
                        if (ddlEAPNoOfPlan.SelectedIndex == i)
                        {
                            trEAPHeading.Attributes.Add("class", "treven");
                            trEAPNoOfPlans.Attributes.Add("class", "trodd");

                            LineShading_FSA(i);
                        }
                    }
                    // If EAP is selected
                    else if (i == 1)
                    {
                        if (ddlEAPNoOfPlan.SelectedIndex == i)
                        {
                            trEAPHeading.Attributes.Add("class", "treven");
                            trEAPNoOfPlans.Attributes.Add("class", "trodd");
                            trEAPSection.Attributes.Add("class", "treven");
                            trFSAHeading.Attributes.Add("class", "trodd");
                            trFSANoOfPlans.Attributes.Add("class", "treven");

                            LineShading_FSA(i);
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for LTD and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If LTD is not selected
                    if (i == 0)
                    {
                        if (ddlEAPNoOfPlan.SelectedIndex == i)
                        {
                            trEAPHeading.Attributes.Add("class", "trodd");
                            trEAPNoOfPlans.Attributes.Add("class", "treven");

                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_FSA(1);
                            }
                            else
                            {
                                LineShading_FSA(i);
                            }
                        }
                    }
                    // If LTD is selected
                    else if (i == 1)
                    {
                        if (ddlEAPNoOfPlan.SelectedIndex == i)
                        {
                            trEAPHeading.Attributes.Add("class", "trodd");
                            trEAPNoOfPlans.Attributes.Add("class", "treven");
                            trEAPSection.Attributes.Add("class", "trodd");
                            trFSAHeading.Attributes.Add("class", "treven");
                            trFSANoOfPlans.Attributes.Add("class", "trodd");

                            if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_FSA(0);
                            }
                            else
                            {
                                LineShading_FSA(i);
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_FSA(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for FSA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If FSA is not selected
                    if (i == 0)
                    {
                        if (ddlFSANoOfPlan.SelectedIndex == i)
                        {
                            trFSAHeading.Attributes.Add("class", "treven");
                            trFSANoOfPlans.Attributes.Add("class", "trodd");

                            LineShading_HSA(i);
                        }
                    }
                    // If FSA is selected
                    else if (i == 1)
                    {
                        if (ddlFSANoOfPlan.SelectedIndex == i)
                        {
                            trFSAHeading.Attributes.Add("class", "treven");
                            trFSANoOfPlans.Attributes.Add("class", "trodd");
                            trFSASection.Attributes.Add("class", "treven");
                            trHSAHeading.Attributes.Add("class", "trodd");
                            trHSANoOfPlans.Attributes.Add("class", "treven");

                            LineShading_HSA(i);
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for FSA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If FSA is not selected
                    if (i == 0)
                    {
                        if (ddlFSANoOfPlan.SelectedIndex == i)
                        {
                            trFSAHeading.Attributes.Add("class", "trodd");
                            trFSANoOfPlans.Attributes.Add("class", "treven");

                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlEAPNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_HSA(1);
                            }
                            else
                            {
                                LineShading_HSA(i);
                            }
                        }
                    }
                    // If FSA is selected
                    else if (i == 1)
                    {
                        if (ddlFSANoOfPlan.SelectedIndex == i)
                        {
                            trFSAHeading.Attributes.Add("class", "trodd");
                            trFSANoOfPlans.Attributes.Add("class", "treven");
                            trFSASection.Attributes.Add("class", "trodd");
                            trHSAHeading.Attributes.Add("class", "treven");
                            trHSANoOfPlans.Attributes.Add("class", "trodd");

                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlEAPNoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_HSA(0);
                            }
                            else
                            {
                                LineShading_HSA(i);
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_HSA(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for HSA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If HSA is not selected
                    if (i == 0)
                    {
                        if (ddlHSANoOfPlan.SelectedIndex == i)
                        {
                            trHSAHeading.Attributes.Add("class", "treven");
                            trHSANoOfPlans.Attributes.Add("class", "trodd");
                            trHRAHeading.Attributes.Add("class", "treven");
                            trHRANoOfPlans.Attributes.Add("class", "trodd");

                            LineShading_HRA(i);
                        }
                    }
                    // If HSA is selected
                    else if (i == 1)
                    {
                        if (ddlHSANoOfPlan.SelectedIndex == i)
                        {
                            trHSAHeading.Attributes.Add("class", "treven");
                            trHSANoOfPlans.Attributes.Add("class", "trodd");
                            trHSASection.Attributes.Add("class", "treven");
                            trHRAHeading.Attributes.Add("class", "trodd");
                            trHRANoOfPlans.Attributes.Add("class", "treven");

                            LineShading_HRA(i);
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for HSA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If HSA is not selected
                    if (i == 0)
                    {
                        if (ddlHSANoOfPlan.SelectedIndex == i)
                        {
                            trHSAHeading.Attributes.Add("class", "trodd");
                            trHSANoOfPlans.Attributes.Add("class", "treven");
                            trHRAHeading.Attributes.Add("class", "trodd");
                            trHRANoOfPlans.Attributes.Add("class", "treven");

                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlEAPNoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_HRA(1);
                            }
                            else
                            {
                                LineShading_HRA(i);
                            }
                        }
                    }
                    // If HSA is selected
                    else if (i == 1)
                    {
                        if (ddlHSANoOfPlan.SelectedIndex == i)
                        {
                            trHSAHeading.Attributes.Add("class", "trodd");
                            trHSANoOfPlans.Attributes.Add("class", "treven");
                            trHSASection.Attributes.Add("class", "trodd");
                            trHRAHeading.Attributes.Add("class", "treven");
                            trHRANoOfPlans.Attributes.Add("class", "trodd");

                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 1 || (ddlEAPNoOfPlan.SelectedIndex == 1 && ddlFSANoOfPlan.SelectedIndex == 0))
                            {
                                LineShading_HRA(0);
                            }
                            else
                            {
                                LineShading_HRA(i);
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_HRA(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                // For loop for HRA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If HRA is not selected
                    if (i == 0)
                    {
                        if (ddlHRANoOfPlan.SelectedIndex == i)
                        {

                            trNotice_Heading.Attributes.Add("class", "treven");
                            trNotice_Options.Attributes.Add("class", "trodd");

                            // For loop for Annual Legal Notices and its subs line shading changes
                            //if (ddlHSANoOfPlan.SelectedIndex == 1 ||( ddlEAPNoOfPlan.SelectedIndex ==0 && ddlFSANoOfPlan.SelectedIndex == 1))
                            if ((ddlEAPNoOfPlan.SelectedIndex == 0 && ddlFSANoOfPlan.SelectedIndex == 1 && ddlHSANoOfPlan.SelectedIndex == 0))
                            {
                                LineShading_AnnualLegalNotices(1);
                            }
                            else
                            {
                                LineShading_AnnualLegalNotices(i);
                            }
                        }
                    }
                    // If HRA is selected
                    else if (i == 1)
                    {
                        if (ddlHRANoOfPlan.SelectedIndex == i)
                        {
                            trHRASection.Attributes.Add("class", "treven");
                            trNotice_Heading.Attributes.Add("class", "trodd");
                            trNotice_Options.Attributes.Add("class", "treven");

                            // For loop for Annual Legal Notices and its subs line shading changes
                            if (ddlHSANoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_AnnualLegalNotices(1);
                            }
                            else
                            {
                                LineShading_AnnualLegalNotices(i);
                            }
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                // For loop for HRA and its subs line shading changes
                for (int i = 0; i <= 1; i++)
                {
                    // If HRA is not selected
                    if (i == 0)
                    {
                        if (ddlHRANoOfPlan.SelectedIndex == i)
                        {
                            trNotice_Heading.Attributes.Add("class", "trodd");
                            trNotice_Options.Attributes.Add("class", "treven");

                            // For loop for Annual Legal Notices and its subs line shading changes
                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlEAPNoOfPlan.SelectedIndex == 1 || ddlHSANoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_AnnualLegalNotices(1);
                            }
                            else
                            {
                                LineShading_AnnualLegalNotices(i);
                            }
                        }
                    }
                    // If HRA is selected
                    else if (i == 1)
                    {
                        if (ddlHRANoOfPlan.SelectedIndex == i)
                        {
                            trHRAHeading.Attributes.Add("class", "trodd");
                            trHRANoOfPlans.Attributes.Add("class", "treven");
                            trHRASection.Attributes.Add("class", "trodd");
                            trNotice_Heading.Attributes.Add("class", "treven");
                            trNotice_Options.Attributes.Add("class", "trodd");

                            // For loop for Annual Legal Notices and its subs line shading changes
                            if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 1 || ddlADNDNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 1 || ddlHSANoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 1)
                            {
                                LineShading_AnnualLegalNotices(0);
                            }
                            else
                            {
                                LineShading_AnnualLegalNotices(i);
                            }
                        }
                    }
                }
            }
        }

        private void LineShading_AnnualLegalNotices(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                for (int j = 0; j <= 1; j++)
                {
                    // If Annual Legal Notices is not selected
                    if (j == 0)
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == j)
                        {
                            trCreditableCoverage.Attributes.Add("class", "treven");
                            trChip_Notice.Attributes.Add("class", "trodd");
                            trNoticeOfMarketplace.Attributes.Add("class", "treven");
                        }
                    }
                    // If Annual Legal Notices is selected
                    else if (j == 1)
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == j)
                        {
                            trAnual.Attributes.Add("class", "treven");
                            trCreditableCoverage.Attributes.Add("class", "trodd");
                            trChip_Notice.Attributes.Add("class", "treven");
                            trNoticeOfMarketplace.Attributes.Add("class", "trodd");
                        }
                    }
                }
            }
            else if (selectedIndex == 1)
            {
                for (int j = 0; j <= 1; j++)
                {
                    // If Annual Legal Notices is not selected
                    if (j == 0)
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == j)
                        {
                            trCreditableCoverage.Attributes.Add("class", "trodd");
                            trChip_Notice.Attributes.Add("class", "treven");
                            trNoticeOfMarketplace.Attributes.Add("class", "trodd");
                        }
                    }
                    // If Annual Legal Notices is selected
                    else if (j == 1)
                    {
                        if (ddlAnnualLegalNotice.SelectedIndex == j)
                        {
                            trAnual.Attributes.Add("class", "trodd");
                            trCreditableCoverage.Attributes.Add("class", "treven");
                            trChip_Notice.Attributes.Add("class", "trodd");
                            trNoticeOfMarketplace.Attributes.Add("class", "treven");
                        }
                    }
                }
            }
        }

        ///Function for PowerPoint 1
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint1()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example1_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));


            if (File.Exists(Convert.ToString(fileName)))
            {

                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);


                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;

                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report1"));
                    }
                    //objPres.SaveAs(ref savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsPresentation , MsoTriState.msoTriStateMixed);
                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTrue); // Working for SaveAs not for Open
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);


                    LoadColumnIdArrayList();
                    WritePowerPoint1 wt = new WritePowerPoint1();
                    wt.WriteFieldToPowerPointTemplate1(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHRANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHRASectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate1(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

                    //if (objApp != null)
                    //{
                    //    objPres.Close();
                    //    Marshal.FinalReleaseComObject(objPresSet);

                    //    objPresSet = null;
                    //    objApp.Quit();
                    //    Marshal.FinalReleaseComObject(objApp);
                    //    objApp = null;
                    //}
                }
                catch (Exception ex)
                {
                    //Response.Write(ex.Message);
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateSummaryPowerPoint1();
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    //if (objApp != null)
                    //{
                    //    objPres.Close();
                    //    Marshal.FinalReleaseComObject(objPresSet);

                    //    objPresSet = null;
                    //    objApp.Quit();
                    //    Marshal.FinalReleaseComObject(objApp);
                    //    objApp = null;
                    //}

                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }


                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();


                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }

            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        ///Function for PowerPoint 2
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint2()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example2_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;
            WritePowerPoint2 wt = new WritePowerPoint2();
            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));


            if (File.Exists(Convert.ToString(fileName)))
            {

                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);


                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;

                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report2"));
                    }
                    //objPres.SaveAs(ref savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsPresentation , MsoTriState.msoTriStateMixed);
                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTrue); // Working for SaveAs not for Open
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);


                    LoadColumnIdArrayList();
                    wt.WriteFieldToPowerPointTemplate2(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlSTDNoOfPlan);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlLTDNoOfPlan, ddlLTDPlanName);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate2(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate2(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate2(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    //Response.Write(ex.Message);
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }


                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }

            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        ///Function for PowerPoint 3
        ///
        [STAThread]
        protected string CreateSummaryPowerPoint3()
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            DataTable PlanTable = (DataTable)Session["PlanTable"];
            DataTable CarrierSpecific = (DataTable)Session["Carrierspecific"];
            DataTable PlanTypeSpecific = (DataTable)Session["PlanTypeSpecific"];
            List<BRC> BRCList = new List<BRC>();
            BRCList = (List<BRC>)Session["BRCList"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            DataTable Office = (DataTable)Session["OffieceTable"];
            string NumberofPlan = ddlMedicalNoOfPlan.SelectedItem.Text;
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/PowerPoint/Documents/Templates/PowerPoint-Example3_v1.pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;
            WritePowerPoint3 wt = new WritePowerPoint3();

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));


            if (File.Exists(Convert.ToString(fileName)))
            {

                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);


                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3/NewPowerPoint" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;

                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/PowerPoint/Documents/Templates/Report3"));
                    }
                    //objPres.SaveAs(ref savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsPresentation , MsoTriState.msoTriStateMixed);
                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTrue); // Working for SaveAs not for Open
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);


                    LoadColumnIdArrayList();
                    wt.WriteFieldToPowerPointTemplate3(objPres, objPresSet, PlanTable, Office, BRCList, ddlBRC, ProductDS, EligibilityDS, ddlClient, ddlOffice, ddlHRContact, ContactList, AccountDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.WriteMedicalSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, NumberofPlan, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    wt.WritePrescriptionDrugsSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, MedicalBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    if (ddlDentalNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteDentalSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, CarrierSpecific, ProductDS, BenefitDS, DentalBenefitColumnIdList, DentalBenefitColumnIdOutNetworkList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlVisionNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVisionSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VisionBenefitColumnIdList, VisionBenefitColumnIdOutNetworkList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLifeADDToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, CarrierSpecific, ddlClient, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteLTDSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, LTDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlSTDNoOfPlan);
                    }
                    if (ddlSTDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteSTDSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, STDBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange, ddlLTDNoOfPlan, ddlLTDPlanName);
                    }
                    if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteVoluntaryLifeToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, CarrierSpecific, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlEAPNoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteEAPSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, EAPBenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlFSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteFSASectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, FSABenefitColumnIdList, ddlFSABenefitSummary, objSlides, objShapes, txtFrame, txtRange);
                    }
                    if (ddlHSANoOfPlan.SelectedIndex > 0)
                    {
                        wt.WriteHSAToPowerPointTemplate3(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HSABenefitColumnIdList, CarrierSpecific, ddlClient, ddlFSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    }
                    //if (ddlHRANoOfPlan.SelectedIndex > 0)
                    //{
                    //    wt.WriteHRASectionToPowerPointTemplate1(objPres, objPresSet, PlanTable, ProductDS, BenefitDS, HRABenefitColumnIdList, objSlides, objShapes, txtFrame, txtRange);
                    //}
                    wt.WriteMonthlyPremiumSectionToPowerPointTemplate3(objPres, objPresSet, PlanTable, RateDS, ContributionDS, ProductDS, objSlides, objShapes, txtFrame, txtRange);
                    wt.UpdateOtherPlansToPowerPointTemplate3(objPres, objPresSet, ddlDentalNoOfPlan, ddlVisionNoOfPlan, ddlLifeADDNoOfPlan, ddlVoluntaryLifeADDNoOfPlan, ddlLTDNoOfPlan, ddlSTDNoOfPlan, ddlEAPNoOfPlan, ddlFSANoOfPlan, ddlHSANoOfPlan, objSlides, objShapes, txtFrame, txtRange);
                    wt.DeleteUnwantedSectionFromPowerPointTemplate3(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();
                    bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    //Response.Write(ex.Message);
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }


                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }

            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

    }
    public class OleMessageFilter : IOleMessageFilter
    {
        public static void Register()
        {

            IOleMessageFilter newFilter = new OleMessageFilter();
            IOleMessageFilter oldFilter = null;

            if (Thread.CurrentThread.GetApartmentState() == ApartmentState.STA)
            {
                CoRegisterMessageFilter(newFilter, out oldFilter);
            }
            else
            {
                throw new COMException("Unable to register message filter because the current thread apartment state is not STA.");
            }
        }

        public static void Revoke()
        {
            IOleMessageFilter oldFilter = null;
            CoRegisterMessageFilter(null, out oldFilter);
        }

        int IOleMessageFilter.HandleInComingCall(
            int dwCallType,
            System.IntPtr hTaskCaller,
            int dwTickCount,
            System.IntPtr lpInterfaceInfo)
        {
            return (int)SERVERCALL.SERVERCALL_ISHANDLED;
        }

        int IOleMessageFilter.RetryRejectedCall(
            System.IntPtr hTaskCallee,
            int dwTickCount,
            int dwRejectType)
        {
            if (dwRejectType == (int)SERVERCALL.SERVERCALL_RETRYLATER)
            {
                return 99;
            }

            return -1;
        }

        int IOleMessageFilter.MessagePending(
            System.IntPtr hTaskCallee,
            int dwTickCount,
            int dwPendingType)
        {
            return (int)PENDINGMSG.PENDINGMSG_WAITDEFPROCESS;
        }

        [DllImport("Ole32.dll")]
        private static extern int CoRegisterMessageFilter(
            IOleMessageFilter newFilter,
            out IOleMessageFilter oldFilter);
    }

    enum SERVERCALL
    {
        SERVERCALL_ISHANDLED = 0,
        SERVERCALL_REJECTED = 1,
        SERVERCALL_RETRYLATER = 2
    }

    enum PENDINGMSG
    {
        PENDINGMSG_CANCELCALL = 0,
        PENDINGMSG_WAITNOPROCESS = 1,
        PENDINGMSG_WAITDEFPROCESS = 2
    }

    [ComImport(), Guid("00000016-0000-0000-C000-000000000046"),
    InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
    interface IOleMessageFilter
    {
        [PreserveSig]
        int HandleInComingCall(
            int dwCallType,
            IntPtr hTaskCaller,
            int dwTickCount,
            IntPtr lpInterfaceInfo);

        [PreserveSig]
        int RetryRejectedCall(
            IntPtr hTaskCallee,
            int dwTickCount,
            int dwRejectType);

        [PreserveSig]
        int MessagePending(
            IntPtr hTaskCallee,
            int dwTickCount,
            int dwPendingType);
    }


}