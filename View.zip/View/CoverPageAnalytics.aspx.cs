﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;
using System.Globalization;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.Common.OpenCloseWord;

namespace BenefitPointSummaryPortal.View
{
    public partial class CoverPageAnalytics : System.Web.UI.Page
    {
        #region global variables
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        SummaryDetail sd = new SummaryDetail();
        string SessionId = "";

        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        private static string Activity = "";
        private static string Activity_Group = "";

        List<Contact> ContactList = new List<Contact>();
        DataSet AccountDS = new DataSet();
        DataSet AccountTeamMemberDS = new DataSet();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    objCommFun.GetUserDetails();


                    DictDepartment = sd.getDepartmentDetails();
                    Activity_Group = "Analytics";
                    Activity = "Analytics Cover Page";

                    mvExperienceReport.ActiveViewIndex = 0;
                    txtsearch.Focus();

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
            }

        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            string mynewfile = "";
            string SessionId = Convert.ToString(Session["SessionId"]);
            try
            {
                if (validate() && Convert.ToString(Session["Summary"]) == "CoverPageAnalytics")
                {
                    #region fetch data

                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    #endregion


                    mynewfile = CreateTemplateCoverPageAnalytics(AccountDS, AccountTeamMemberDS);
                    DownloadFileNew(mynewfile);

                    InsertLog(ddlLayoutOption.SelectedItem.Text, ddlReportType.SelectedItem.Text);

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        private string CreateTemplateCoverPageAnalytics(DataSet AccountDS, DataSet AccountTeamMemberDS)
        {


            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = "";

            if (ddlLayoutOption.SelectedValue == "Portrait")
            {
                fileName = Server.MapPath("~/Files/CoverPageAnalytics/Documents/Templates/CoverPage-Analytics_Portrait.docx");
            }
            else if (ddlLayoutOption.SelectedValue == "Landscape")
            {
                fileName = Server.MapPath("~/Files/CoverPageAnalytics/Documents/Templates/CoverPage-Analytics_Landscape.docx");
            }



            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/CoverPageAnalytics/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docx");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/CoverPageAnalytics/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/CoverPageAnalytics/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                WriteTemplateCoverPageAnalytics wr = new WriteTemplateCoverPageAnalytics();
                wr.WriteTemplate_CommonFields(oWordDoc, oWordApp, ddlClient.SelectedItem.Text, GetDate(txtMeetingDate.Text), ddlReportType.SelectedItem.Text);
                wr.WriteTemplate_AccountContacts(oWordDoc, oWordApp, AccountDS, AccountTeamMemberDS);

                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        private void ResetForm()
        {
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;
            ddlLayoutOption.SelectedIndex = 0;
            ddlReportType.SelectedIndex = 0;
            txtMeetingDate.Text = "";

        }
        private bool validate()
        {
            bool isValid = true;
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                ddlClient.Focus();
                return false;
            }
          
            if (!IsValidDate(txtMeetingDate.Text.Trim()))
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Invalid Meeting Date. Date format should be MM/DD/YYYY')</script>");
                txtMeetingDate.Focus();
                return false;
            }
            if (ddlReportType.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Report Type.')</script>");
                ddlReportType.Focus();
                return false;
            }
            if (ddlLayoutOption.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Layout Option.')</script>");
                ddlLayoutOption.Focus();
                return false;
            }

            return isValid;
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            string deliverableCategory = "Analytics";
            Activity = "Analytics Cover Page";
            Activity_Group = "Analytics";
            

            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedValue), Account_Region, Account_Office, deliverableCategory, Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }
    }
}