﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class BRCData
    {
        #region Variable
        private int _BRCId;
        private string _BRCName;
        private string _BRCLocation;
        private string _BRCDayHours;
        private string _BRCPhone;
        private string _BRCEmail;
        private string _BRCFax;
        private string _BRCTimezone;
        #endregion

        #region Properties

        /// <summary>
        /// Get and SetBRCId
        /// </summary>
        public int BRCId
        {
            get
            {
                return _BRCId;
            }
            set
            {
                _BRCId = value;
            }
        }
        /// <summary>
        /// Get and SetBRCName
        /// </summary>
        public string BRCName
        {
            get
            {
                return _BRCName;
            }
            set
            {
                _BRCName = value;
            }
        }
        /// <summary>
        /// Get and SetBRCLocation
        /// </summary>
        public string BRCLocation
        {
            get
            {
                return _BRCLocation;
            }
            set
            {
                _BRCLocation = value;
            }
        }
        /// <summary>
        /// Get and SetBRCEmail
        /// </summary>
        public string BRCEmail
        {
            get
            {
                return _BRCEmail;
            }
            set
            {
                _BRCEmail = value;
            }
        }
        /// <summary>
        /// Get and SetBRCPhone
        /// </summary>
        public string BRCPhone
        {
            get
            {
                return _BRCPhone;
            }
            set
            {
                _BRCPhone = value;
            }
        }
        /// <summary>
        /// Get and SetBRCFax
        /// </summary>
        public string BRCFax
        {
            get
            {
                return _BRCFax;
            }
            set
            {
                _BRCFax = value;
            }
        }
        /// <summary>
        /// Get and Set BRCTimezone
        /// </summary>
        public string BRCTimezone
        {
            get
            {
                return _BRCTimezone;
            }
            set
            {
                _BRCTimezone = value;
            }
        }
        /// <summary>
        /// Get and SetBRCDayHours
        /// </summary>
        public string BRCDayHours
        {
            get
            {
                return _BRCDayHours;
            }
            set
            {
                _BRCDayHours = value;
            }
        }
        #endregion
    }
}