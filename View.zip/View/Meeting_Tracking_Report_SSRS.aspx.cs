﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Reflection;
using System.Web.Configuration;


namespace BenefitPointSummaryPortal.View
{
    public partial class Meeting_Tracking_Report_SSRS : System.Web.UI.Page
    {

        CommonFunctionsBS commnObj = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        protected void Page_Load(object sender, EventArgs e)
        {
            //DisableUnwantedExportFormat(rptViewer, "PDF");
            div_footer.Controls.Add(commnObj.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                TitleSpan.InnerText = "Meeting Tracking Report";
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                ServerReport serverReport = rptViewer.ServerReport;
                rptViewer.ProcessingMode = ProcessingMode.Remote;
                string ReportServer = WebConfigurationManager.AppSettings["SSRSReportServer"].ToString();
                ///SSRSReportServer
                //  serverReport.ReportServerUrl = new Uri("http://usi-sq-10/ReportServer_ADPConcur");
                serverReport.ReportServerUrl = new Uri(ReportServer);// new Uri("http://reports.usii.com/reportserver");
                serverReport.ReportPath = "/BP/BP Meeting Tracking Report";

                //string[] values_Regions = new string[] { "Midwest" };
                //string[] values_Offices = new string[] { "Cleveland", "Chicago" };


                //ReportParameter[] Param = new ReportParameter[6];
                //Param[0] = new ReportParameter("REGIONS", values_Regions);
                //Param[1] = new ReportParameter("OFFICES", values_Offices);
                //Param[2] = new ReportParameter("DATETYPE", "CD");
                //Param[3] = new ReportParameter("PRODUCERTEAMS", "%");
                //Param[4] = new ReportParameter("DATEFROM", "04/01/2017");
                //Param[5] = new ReportParameter("DATETO", "04/12/2017");

                //ReportParameter[] Param = new ReportParameter[6];
                //Param[0] = new ReportParameter("REGIONS", "8071");
                //Param[1] = new ReportParameter("OFFICES", "Cleveland");
                //Param[2] = new ReportParameter("DATETYPE", "CD");
                //Param[3] = new ReportParameter("PRODUCERTEAMS", "%");
                //Param[4] = new ReportParameter("DATEFROM", "04/01/2017");
                //Param[5] = new ReportParameter("DATETO", "04/12/2017");

                rptViewer.ServerReport.GetParameters();
                rptViewer.ShowParameterPrompts = true;
                //rptViewer.ServerReport.SetParameters(Param);
                string Activity = string.Empty;
                string Activity_Group = string.Empty;
                Activity = "Meeting Tracking Report";
                Activity_Group = "Reports";
                string AdditionalCrtieriaOption_1 = string.Empty;// string.Empty;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;

                rptViewer.ServerReport.Refresh();
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, "", Convert.ToString(Session["UserLoginName"]), 0, "", "", Convert.ToString(Session["DeliverableCategory"]), "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
            }
        }

        //public void DisableUnwantedExportFormat(ReportViewer rptViewer, string strFormatName)
        //{
        //    FieldInfo info;

        //    foreach (RenderingExtension extension in rptViewer.LocalReport.ListRenderingExtensions())
        //    {
        //        if (extension.Name == strFormatName)
        //        {
        //            info = extension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic);
        //            info.SetValue(extension, false);
        //        }
        //    }
        //}

    }
}