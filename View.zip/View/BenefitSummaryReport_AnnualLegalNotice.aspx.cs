﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;

namespace BenefitPointSummaryPortal.View
{
    public partial class BenefitSummaryReport_AnnualLegalNotice : System.Web.UI.Page
    {
        #region Global Variable
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string temperror = "cs";

        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        #region Added by vinod : Department information
        SummaryDetail sdd = new SummaryDetail();

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        #endregion

        #endregion

        # region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                   // Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    #region Added by vinod : setting Department Value
                    DictDepartment = sdd.getDepartmentDetails();
                    #endregion

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    GetData();

                    if (Convert.ToString(Session["Summary"]) == "Template8")
                    {
                        Activity = "Important Legal Notices";
                        Activity_Group = "Communications";
                    }

                    //Activity = lblHeading.Text;

                    txtsearch.Focus();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                Clear();
                SessionId = Session["SessionId"].ToString();
                List<Contact> ContactList = new List<Contact>();
                if (ddlClient.SelectedValue != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                }
                Session["Contact"] = ContactList;
                ddlHRContact.DataSource = ContactList;
                ddlHRContact.DataBind();
                ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlHRContact.Items.Insert(1, new ListItem("None", "-1"));
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                Clear();

                if (ddlOffice.Items.Count > 1)
                {
                    ddlOffice.SelectedIndex = 2;
                }

                ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                SummaryDetail sd = new SummaryDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                if (flag == true)
                {
                    BPBusiness bp = new BPBusiness();

                    string mynewfile = "";

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    if (Convert.ToString(Session["Summary"]) == "Template8")
                    {
                        mynewfile = CreateSummaryTemplate8_AnnualLegalNotices();
                    }
                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        #region Function

        /// <summary>
        /// Create Summary Template8 Annual Legal Notices
        /// </summary>
        protected string CreateSummaryTemplate8_AnnualLegalNotices()
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            List<Contact> ContactList = (List<Contact>)Session["Contact"];
            Object missing = System.Reflection.Missing.Value;

            try
            {
                if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report8")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Report8"));
                }
                string filename = "~/Files/BenefitSummary/Documents/Templates/Benefit Summary_Example8_AnnualLegalNotices.docm";
                string _savefilename = "~/Files/BenefitSummary/Documents/Templates/Report8/NewDocument";
                wobj.Word_Open(wobj.office.oWordApp, wobj.office.oWordDoc, filename, _savefilename, missing);

                WriteTemplate8_AnnualLegalNotices wt = new WriteTemplate8_AnnualLegalNotices();

                wt.WriteNoticeSectionToTemplate8(wobj.office.oWordDoc, wobj.office.oWordApp, ContactList, ddlHRContact, ddlChipNotice, chkAnualNotice, ddlClient, ddlOffice, Office, ddlMarketplaceCoverage, ddlCreditableCoverage);

                //RunMacro(wobj.office.oWordApp, new Object[] { "CleanDocumentSummary7" });
                //temperror = temperror + " postmacro";
                wobj.office.oWordDoc.Save();

                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);

                #region Added By vinod : for saving the activity log information

                /// List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

                // Loading Account DS and Account ReamMember DS
                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();
                sdd.BuildAccountTable();
                AccountDS = sdd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sdd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }


                string AdditionalCrtieriaOption_1 = ddlOffice.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlHRContact.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlCreditableCoverage.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlChipNotice.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

              //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                wobj.Word_Close(wobj.office.oWordApp, wobj.office.oWordDoc, missing);
            }

            return (wobj.Save_File);
        }

        /// <summary>
        /// Bind data to office dropdown and BRC dropdown.
        /// </summary>
        protected void GetData()
        {
            try
            {
                //Office.
                Session["OffieceTable"] = null;
                Session["BRCList"] = null;
                BPBusiness bp = new BPBusiness();
                DataTable dt = new DataTable();
                SessionId = Session["SessionId"].ToString();
                dt = bp.GetOfficeList();
                Session["OffieceTable"] = dt;
                ddlOffice.DataSource = dt;
                ddlOffice.DataBind();
                ddlOffice.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlOffice.SelectedIndex = 2;

                ///** Office Dropdown Enabled=False by Amogh*/
                ddlOffice.Enabled = false;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            ddlHRContact.Items.Clear();
            ddlHRContact.Items.Insert(0, new ListItem("Select", string.Empty));
            chkAnualNotice.SelectedIndex = -1;
            ddlChipNotice.SelectedIndex = 0;

        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion
    }
}