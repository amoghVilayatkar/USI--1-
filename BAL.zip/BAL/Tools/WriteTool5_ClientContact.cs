﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;

using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.Tools;


namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTool5_ClientContact : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctions objCommFun = new CommonFunctions();
        int deleterow = 2;

        /// <summary>
        /// WriteFieldToClientContact_Landscape
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        public void WriteFieldToClientContact_Landscape(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, GridView grdAccountTeam, List<BRC> BRCList, DropDownList ddlBRC, DataTable dtPlanContactInfo, DataTable PlanInfoTable, DataTable dtOfficeAddress)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;

                #region MergeField
                int BRCindex = -1;
                string hasBRC = String.Empty;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                    hasBRC = " ";
                }
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Legal Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }


                        if (fieldName.Contains("Office Street Address"))
                        {
                            myMergeField.Select();
                            string OfficeStreetAdd = Convert.ToString(dtOfficeAddress.Rows[0]["Office Street Address"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeStreetAdd))
                            {
                                oWordApp.Selection.TypeText(OfficeStreetAdd);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("City"))
                        {
                            myMergeField.Select();

                            string OfficeCity = Convert.ToString(dtOfficeAddress.Rows[0]["City"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeCity))
                            {
                                oWordApp.Selection.TypeText(OfficeCity);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("State"))
                        {
                            myMergeField.Select();
                            string OfficeState = Convert.ToString(dtOfficeAddress.Rows[0]["State"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeState))
                            {
                                oWordApp.Selection.TypeText(OfficeState);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("ZIP"))
                        {
                            myMergeField.Select();
                            string OfficeZip = Convert.ToString(dtOfficeAddress.Rows[0]["Zip"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeZip))
                            {
                                oWordApp.Selection.TypeText(OfficeZip);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("Office Phone Number"))
                        {
                            myMergeField.Select();
                            string OfficePhNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Phone Number"]).Trim();
                            if (!string.IsNullOrEmpty(OfficePhNumber))
                            {
                                oWordApp.Selection.TypeText(OfficePhNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("Office Fax Number"))
                        {
                            myMergeField.Select();
                            string OfficeFaxNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Fax Number"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeFaxNumber))
                            {
                                oWordApp.Selection.TypeText(OfficeFaxNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                            oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                            continue;
                        }
                        if (fieldName.Contains("HAVE_BRC"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(hasBRC))
                            {
                                oWordApp.Selection.TypeText(hasBRC);
                            }
                            continue;
                        }
                        if (BRCindex > -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                }
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim() +".");
                                }
                                continue;
                            }

                        }
                        else if (BRCindex == -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }

                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 1;
                int count = 1;
                string SerialNo = string.Empty;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    //DataTable dtAccountTeam = new DataTable();
                    //dtAccountTeam.Columns.Add("SrNo", typeof(string));
                    //dtAccountTeam.Columns.Add("Name", typeof(string));
                    //dtAccountTeam.Columns.Add("email", typeof(string));
                    //dtAccountTeam.Columns.Add("role", typeof(string));
                    //dtAccountTeam.Columns.Add("workPhone", typeof(string));
                    CheckBox chkItemSelect = new CheckBox();
                    //TextBox txtSerialNo = new TextBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        //txtSerialNo = ((TextBox)grRow.FindControl("txtSRNo"));
                        if (chkItemSelect.Checked == true)
                        {
                            SerialNo = "";
                            name = "";
                            role = "";
                            workPhone = "";
                            email = "";

                            //SerialNo = txtSerialNo.Text;
                            name = Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "").Replace("&#39;", "'") + " " + Convert.ToString(grRow.Cells[6].Text).Replace("&nbsp;", "").Replace("&#39;", "'");
                            email = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                            role = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");
                            workPhone = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "");


                            //DataRow drAccountTeamRow;
                            //drAccountTeamRow = dtAccountTeam.NewRow();
                            //drAccountTeamRow["SrNo"] = SerialNo;
                            //drAccountTeamRow["Name"] = name;
                            //drAccountTeamRow["email"] = email;
                            //drAccountTeamRow["role"] = role;
                            //drAccountTeamRow["workPhone"] = workPhone;
                            //dtAccountTeam.Rows.Add(drAccountTeamRow);

                            if (grRow.RowIndex > 0)
                            {
                                oWordDoc.Tables[1].Rows.Add();
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }
                            else if (grRow.RowIndex == 0)
                            {
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }


                        }

                    }
                }
                #endregion

                #region For Contact information writing

                if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                {
                    foreach (DataRow row in dtPlanContactInfo.Rows)
                    {
                        if (dtPlanContactInfo.Rows.IndexOf(row) > 0)
                        {
                            oWordDoc.Tables[2].Rows.Add();
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                        else if (dtPlanContactInfo.Rows.IndexOf(row) == 0)
                        {
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                    }
                }
                else if (dtPlanContactInfo.Rows.Count == 0)
                {
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Cell(1, 1).Select();
                    oWordDoc.Tables[2].Cell(deleterow, 1).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 2).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 3).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 4).Range.Text = "";
                }
                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient, PlanInfoTable);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// WriteFieldToClientContact_Portrait
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        public void WriteFieldToClientContact_Portrait(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, GridView grdAccountTeam, List<BRC> BRCList, DropDownList ddlBRC, DataTable dtPlanContactInfo, DataTable PlanInfoTable, DataTable dtOfficeAddress)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;
                string value = string.Empty;

                #region MergeField
                int BRCindex = -1;
                string hasBRC = String.Empty;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                    hasBRC = " ";
                }
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Legal Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }


                        if (fieldName.Contains("Office Street Address"))
                        {
                            myMergeField.Select();
                            string OfficeStreetAdd = Convert.ToString(dtOfficeAddress.Rows[0]["Office Street Address"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeStreetAdd))
                            {
                                oWordApp.Selection.TypeText(OfficeStreetAdd);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("City"))
                        {
                            myMergeField.Select();

                            string OfficeCity = Convert.ToString(dtOfficeAddress.Rows[0]["City"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeCity))
                            {
                                oWordApp.Selection.TypeText(OfficeCity);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("State"))
                        {
                            myMergeField.Select();
                            string OfficeState = Convert.ToString(dtOfficeAddress.Rows[0]["State"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeState))
                            {
                                oWordApp.Selection.TypeText(OfficeState);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("ZIP"))
                        {
                            myMergeField.Select();
                            string OfficeZip = Convert.ToString(dtOfficeAddress.Rows[0]["Zip"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeZip))
                            {
                                oWordApp.Selection.TypeText(OfficeZip);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("Office Phone Number"))
                        {
                            myMergeField.Select();
                            string OfficePhNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Phone Number"]).Trim();
                            if (!string.IsNullOrEmpty(OfficePhNumber))
                            {
                                oWordApp.Selection.TypeText(OfficePhNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("Office Fax Number"))
                        {
                            myMergeField.Select();
                            string OfficeFaxNumber = Convert.ToString(dtOfficeAddress.Rows[0]["Office Fax Number"]).Trim();
                            if (!string.IsNullOrEmpty(OfficeFaxNumber))
                            {
                                oWordApp.Selection.TypeText(OfficeFaxNumber);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;

                        }
                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                            oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                            continue;
                        }
                        if (fieldName.Contains("HAVE_BRC"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(hasBRC))
                            {
                                oWordApp.Selection.TypeText(hasBRC);
                            }
                            continue;
                        }
                        if (BRCindex > -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                }
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                {
                                    myMergeField.Delete();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim() +".");
                                }
                                continue;
                            }
                            //if (fieldName.Contains("First Med Plan Effective Date"))
                            //{
                            //    myMergeField.Select();
                            //    string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                            //    oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                            //    continue;
                            //}
                        }
                        else if (BRCindex == -1)
                        {
                            if (fieldName.Contains("BRC Phone Number"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }
                            if (fieldName.Contains("BRC e-mail"))
                            {
                                myMergeField.Select();
                                myMergeField.Delete();
                                continue;
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 1;
                int count = 1;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    CheckBox chkItemSelect = new CheckBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));


                        if (chkItemSelect.Checked == true)
                        {
                            name = "";
                            role = "";
                            workPhone = "";
                            email = "";
                            name = Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "").Replace("&#39;", "'") + " " + Convert.ToString(grRow.Cells[6].Text).Replace("&nbsp;", "").Replace("&#39;", "'");
                            email = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                            role = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");
                            workPhone = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "");

                            if (grRow.RowIndex > 0)
                            {
                                oWordDoc.Tables[1].Rows.Add();
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }
                            else if (grRow.RowIndex == 0)
                            {
                                cntAT++;
                                oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name;
                                oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                                oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                                oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;
                            }
                            //oWordDoc.Tables[1].Rows.Add();
                            //cntAT++;
                            //oWordDoc.Tables[1].Cell(cntAT, 1).Select();
                            //oWordDoc.Tables[1].Cell(cntAT, 1).Range.Text = name;
                            //oWordDoc.Tables[1].Cell(cntAT, 2).Range.Text = role;
                            //oWordDoc.Tables[1].Cell(cntAT, 3).Range.Text = workPhone;
                            //oWordDoc.Tables[1].Cell(cntAT, 4).Range.Text = email;


                        }

                    }
                }
                #endregion

                #region For Contact information writing

                if (dtPlanContactInfo != null && dtPlanContactInfo.Rows.Count > 0)
                {
                    foreach (DataRow row in dtPlanContactInfo.Rows)
                    {
                        if (dtPlanContactInfo.Rows.IndexOf(row) > 0)
                        {
                            oWordDoc.Tables[2].Rows.Add();
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                        else if (dtPlanContactInfo.Rows.IndexOf(row) == 0)
                        {
                            count++;
                            oWordDoc.Tables[2].Cell(count, 1).Select();
                            oWordDoc.Tables[2].Cell(count, 1).Range.Text = row["CarrierName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 2).Range.Text = row["ContactName"].ToString();
                            oWordDoc.Tables[2].Cell(count, 3).Range.Text = row["ContactWorkPhone"].ToString();
                            oWordDoc.Tables[2].Cell(count, 4).Range.Text = row["ContactEmail"].ToString();
                        }
                    }
                }
                else if (dtPlanContactInfo.Rows.Count == 0)
                {
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Rows.Add();
                    oWordDoc.Tables[2].Cell(1, 1).Select();
                    oWordDoc.Tables[2].Cell(deleterow, 1).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 2).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 3).Range.Text = "";
                    oWordDoc.Tables[2].Cell(deleterow, 4).Range.Text = "";
                }
                #endregion

                Write_Field_Header(oWordDoc, oWordApp, ddlClient, PlanInfoTable);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataTable PlanInfoTable)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("Client Name"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                continue;
                            }

                            if (fieldName.Contains("First Med Plan Effective Date"))
                            {
                                field.Select();
                                string effectivedate = PlanInfoTable.Rows[0]["Effective"].ToString();
                                oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                continue;
                            }
                        }
                    }
                }
            }

        }
    }
}