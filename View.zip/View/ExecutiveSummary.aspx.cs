﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office.Core;
using Word = Microsoft.Office.Interop.Word;
using BenefitPointSummaryPortal.Common.ClientUserControl;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.ExecutiveSummaryReport;


namespace BenefitPointSummaryPortal.View
{
    public partial class ExecutiveSummary : System.Web.UI.Page
    {

        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        private string Activity = "Executive Summary";
        private string Activity_Group = "Analytics";

        //For Activity Log
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        public string Account_Region = string.Empty;
        public string Account_Office = string.Empty;


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());


                if (!IsPostBack)
                {
                    objCommFun.GetUserDetails();
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;


                    DictDepartment = sd.getDepartmentDetails();
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataSet AccountDS = new DataSet();
                string Account_Office = string.Empty;
                string Account_Region = string.Empty;
                SessionId = Session["SessionId"].ToString();
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
            }
            catch (Exception ex)
            {

            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                rdlClient.SelectedIndex = 0;
                ddlLayoutOption.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToString(Session["Summary"]) == "ExecutiveSummary")
                {

                    if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        return;
                    }
                    else if (ddlLayoutOption.SelectedIndex == 0 || ddlLayoutOption.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Layout Option.')</script>");
                        ddlLayoutOption.Focus();
                        return;
                    }
                    else
                    {
                        string mynewfile = Create_ExecutiveSummary();
                        //Insert Log
                        DownloadFileNew(mynewfile);
                        InsertLog(Convert.ToString(ddlLayoutOption.SelectedItem.Text));
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected string Create_ExecutiveSummary()
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Microsoft.Office.Interop.Word.Application oWordApp = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlLayoutOption.SelectedItem.Value == "1") // Landscape Format
            {
                strFileName = "Summary-Executive_Landscape";
            }
            else if (ddlLayoutOption.SelectedItem.Value == "2") // Portrait Format
            {
                strFileName = "Summary-Executive_Portrait";
            }

            Object fileName = Server.MapPath("~/Files/ExecutiveSummaryReport/Documents/Templates/" + strFileName + ".docm");



            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/ExecutiveSummaryReport/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/ExecutiveSummaryReport/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/ExecutiveSummaryReport/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                ExecutiveSummaryReport objEx = new ExecutiveSummaryReport();

                objEx.WriteFileds_ExecutiveSummaryReportFooter(oWordDoc, oWordApp, ddlClient.SelectedItem.Text);

                oWordDoc.Save();


                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());

        }

        //Insert Log
        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {

            SessionId = Session["SessionId"].ToString();
            Session["DeliverableCategory"] = "Analytics";
            List<Contact> ContactList = new List<Contact>();
            ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
            DataSet AccountDS = new DataSet();
            DataSet AccountTeamMemberDS = new DataSet();
            sd.BuildAccountTable();
            AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            if (ddlClient.SelectedValue != "")
            {
                AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            }
            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
            string Office_Region = Account_Region + " / " + Account_Office;
            string AdditionalCrtieriaOption_1 = Criteria1;
            string AdditionalCrtieriaOption_2 = string.Empty;
            string AdditionalCrtieriaOption_3 = string.Empty;
            string AdditionalCrtieriaOption_4 = string.Empty;
            DicActivityLog.Clear();
            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

        }

    }
}