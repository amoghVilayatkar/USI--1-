﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.ServiceCalendar;

namespace BenefitPointSummaryPortal.BAL.ServiceCalendar
{
    public class WriteServiceCalendarDetail : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctions objCommFun = new CommonFunctions();

        /// <summary>
        /// WriteFieldToSC_Highlights_Landscape
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="SelectedMonthNo">Int16 SelectedMonthNo for to check which month is selected</param>
        /// <param name="Healthcare_Reform">int Healthcare_Reform is used as a flag just to check whether Healthcare Reform is included or not</param>
        /// <param name="USI_Holidays">int USI_Holidays is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Wellness">int Wellness is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Cust_Field_1">int Cust_Field_1 for to check which month is selected</param>
        /// <param name="Cust_Field_2">int Cust_Field_2 for to check which month is selected</param>
        /// <param name="Cust_Field_3">int Cust_Field_3 for to check which month is selected</param>
        /// <param name="strCustField1">string strCustField1 is used to write the text provided in the text box in the selected month for Cust_Field_1</param>
        /// <param name="strCustField2">string strCustField2 is used to write the text provided in the text box in the selected month for Cust_Field_2</param>
        /// <param name="strCustField3">string strCustField3 is used to write the text provided in the text box in the selected month for Cust_Field_3</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="ddlServiceCalYear">DropDownList ddlServiceCalYear is used to check which year to show on the report (Current Year / Next Year)</param>
        /// <param name="ActivityDS">DataSet ActivityDS is used for taking the Activity custom field values and to calculate month on the basis of Activity custom field value to put populate particular topin</param>
        /// <param name="Renewal_Year">int Renewal_Year is used to populate the year calculated from the renewal date in the Renewal_Year field</param>
        public void WriteFieldToSC_Detail_Landscape(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, Int16 SelectedMonthNo,
           int Healthcare_Reform, int USI_Holidays, int Wellness, int Cust_Field_1, int Cust_Field_2, int Cust_Field_3, string strCustField1, string strCustField2, string strCustField3, GridView grdAccountTeam, DropDownList ddlServiceCalYear, DataSet ActivityDS, int Renewal_Year, DropDownList ddlReportStyle)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;
                string value = string.Empty;
                int cnt = 0;
                int cnt1 = 0;
                int cntDiff = 0;

                string strUSI_Holidays = string.Empty;
                string strHealthcare = string.Empty;

                #region For writing table values

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    #region Code for first 6 months
                    if (cnt < 6)
                    {
                        cnt++;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // Condition for Healthcare
                        objCommFun.Get_Healthcare_Topic(i, cnt, 2, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cnt, 2, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cnt, 2, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cnt, 2, oWordDoc, ActivityDS);
                        #region Add "Population Health Management Strategy"
                        /* As per requirement here we add the "Population Health Management Strategy" */
                        if (cnt == 2)
                        {
                            if (oWordDoc.Tables[2].Cell(2, cnt).Range.Text.Length < 2) // In case no record found 
                            {
                                oWordDoc.Tables[2].Cell(2, cnt).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(2, cnt).Range.Text = oWordDoc.Tables[2].Cell(2, cnt).Range.Text + "Population Health Management Strategy";
                            }
                            else
                                oWordDoc.Tables[2].Cell(2, cnt).Range.Text = oWordDoc.Tables[2].Cell(2, cnt).Range.Text + "Population Health Management Strategy";
                        }
                        #endregion
                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cnt, 2, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // Code for next 6 columns (Months)
                    #region Code for next 6 months
                    else if (cnt >= 6)
                    {
                        cnt1++;
                        oWordDoc.Tables[2].Cell(3, cnt1).Select();
                        oWordDoc.Tables[2].Cell(3, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)

                        // Condition for Healthcare
                        objCommFun.Get_Healthcare_Topic(i, cnt1, 4, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cnt1, 4, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cnt1, 4, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cnt1, 4, oWordDoc, ActivityDS);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cnt1, 4, oWordDoc, Cust_Field_3, strCustField3);

                    }
                    #endregion

                    cntDiff++;
                }

                // Take a difference from above loop so that to iterate another loop for the 12 - cntDiff 
                // (i.e. Total 12 months minus the total months for which the loop is already executed
                if (cntDiff < 12)
                {
                    for (int j = 1; j <= 12 - cntDiff; j++)
                    {
                        #region Code for first 6 months
                        if (cnt < 6)
                        {
                            cnt++;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // Condition for Healthcare
                            objCommFun.Get_Healthcare_Topic(j, cnt, 2, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(j, cnt, 2, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(j, cnt, 2, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(j, cnt, 2, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(j, cnt, 2, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        #region Code for next 6 months
                        else if (cnt >= 6)
                        {
                            cnt1++;
                            oWordDoc.Tables[2].Cell(3, cnt1).Select();
                            oWordDoc.Tables[2].Cell(3, cnt1).Range.Text = dictionaryMonth[j].ToString(); // For showing month name in the Renewal Month heading(s)

                            // Condition for Healthcare
                            objCommFun.Get_Healthcare_Topic(j, cnt1, 4, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(j, cnt1, 4, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(j, cnt1, 4, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(j, cnt1, 4, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(j, cnt1, 4, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion
                    }
                }
                #endregion

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Short Office Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Renewal Month"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dictionaryMonth[SelectedMonthNo].ToString());
                            continue;
                        }

                        if (fieldName.Contains("Renewal Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Renewal_Year.ToString());
                            continue;
                        }

                        // To include the graphics image in the report
                        // if value = 0 ('Graphics') is selected then graphics image will be displayed
                        // if value = 1 ('No Graphics') is selected then graphics image will not be displayed
                        if (fieldName.Contains("Graphics_Image"))
                        {
                            myMergeField.Select();
                            if (ddlReportStyle.SelectedItem.Value == "1")
                            {
                                oWordApp.Selection.TypeText(" ");
                                object missing = System.Type.Missing;
                                Word.Range rng = rngFieldCode;
                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/Service_Calendar_Graphics.jpg"));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (ddlOffice.SelectedIndex > -1)
                        {
                            DataRow[] FoundRow = null;
                            FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                            if (FoundRow.Count() > 0)
                            {
                                if (fieldName.Contains("Office Full Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeName"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeName"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Address"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeAddress"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Phone Number"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["PhoneNumber"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["PhoneNumber"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("OFFICE LOGO"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                    object missing = System.Type.Missing;
                                    Word.Range rng = rngFieldCode;
                                    rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                    string imageName = FoundRow[0]["OfficeLogo"].ToString().Replace("jpg", "png");
                                    rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/CompanyLogo/" + imageName));
                                }
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 6;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    CheckBox chkItemSelect = new CheckBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (cntAT <= 9)
                        {
                            if (chkItemSelect.Checked == true)
                            {
                                name = "";
                                role = "";
                                workPhone = "";
                                email = "";

                                name = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "") + " " + Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "");
                                role = Convert.ToString(grRow.Cells[1].Text).Replace("&nbsp;", "");
                                workPhone = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                                email = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");

                                cntAT++;
                                oWordDoc.Tables[2].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[2].Cell(cntAT, 1).Range.Text = name + ", " + role + ": " + workPhone + " / " + email;

                                if (cntAT == 9)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// WriteFieldToSC_Highlights_Portrait
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlOffice">DropDownList ddlOffice to show office name and on the basis of Office Id to take information such as Office Logo, Office Address and Office Phone number</param>
        /// <param name="ddlClient">DropDownList ddlClient to show the client name on the report</param>
        /// <param name="dictionaryMonth">Dictionary<int, string> contains the Month No and Month Name for showing the month name as per the selected month</param>
        /// <param name="SelectedMonthNo">Int16 SelectedMonthNo for to check which month is selected</param>
        /// <param name="Healthcare_Reform">int Healthcare_Reform is used as a flag just to check whether Healthcare Reform is included or not</param>
        /// <param name="USI_Holidays">int USI_Holidays is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Wellness">int Wellness is used as a flag just to check whether 5500 report is included or not</param>
        /// <param name="Cust_Field_1">int Cust_Field_1 for to check which month is selected</param>
        /// <param name="Cust_Field_2">int Cust_Field_2 for to check which month is selected</param>
        /// <param name="Cust_Field_3">int Cust_Field_3 for to check which month is selected</param>
        /// <param name="strCustField1">string strCustField1 is used to write the text provided in the text box in the selected month for Cust_Field_1</param>
        /// <param name="strCustField2">string strCustField2 is used to write the text provided in the text box in the selected month for Cust_Field_2</param>
        /// <param name="strCustField3">string strCustField3 is used to write the text provided in the text box in the selected month for Cust_Field_3</param>
        /// <param name="grdAccountTeam">GridView grdAccountTeam is used to take the selected account team members information and to show it on the report</param>
        /// <param name="ddlServiceCalYear">DropDownList ddlServiceCalYear is used to check which year to show on the report (Current Year / Next Year)</param>
        /// <param name="ActivityDS">DataSet ActivityDS is used for taking the Activity custom field values and to calculate month on the basis of Activity custom field value to put populate particular topin</param>
        /// <param name="Renewal_Year">int Renewal_Year is used to populate the year calculated from the renewal date in the Renewal_Year field</param>
        public void WriteFieldToSC_Detail_Portrait(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlOffice, DropDownList ddlClient, Dictionary<int, string> dictionaryMonth, Int16 SelectedMonthNo,
           int Healthcare_Reform, int USI_Holidays, int Wellness, int Cust_Field_1, int Cust_Field_2, int Cust_Field_3, string strCustField1, string strCustField2, string strCustField3, GridView grdAccountTeam, DropDownList ddlServiceCalYear, DataSet ActivityDS, int Renewal_Year, DropDownList ddlReportStyle)
        {
            try
            {
                DataTable Office = (DataTable)Session["OffieceTable"];
                int iTotalFields = 0;
                string value = string.Empty;
                int cnt = -1;
                int cnt1 = -1;
                int cnt2 = -1;
                int cnt3 = -1;
                int cntDiff = 0;

                #region For writing table values

                int cntFirst3_Month = 0;
                int cntSecond3_Month = 0;
                int cntThird3_Month = 0;
                int cntFourth3_Month = 0;

                // Loop for 12 months to show as header and to write data in particular month
                for (int i = SelectedMonthNo; i <= 12; i++)
                {
                    // For first 3 months
                    #region For first 3 months
                    if (cnt < 5)
                    {
                        cnt = cnt + 2;
                        oWordDoc.Tables[2].Cell(1, cnt).Select();
                        oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntFirst3_Month = cnt + 1;

                        // Condition for Healthcare Reform
                        objCommFun.Get_Healthcare_Topic(i, cntFirst3_Month, 1, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntFirst3_Month, 1, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntFirst3_Month, 1, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cntFirst3_Month, 1, oWordDoc, ActivityDS);

                        #region Add "Population Health Management Strategy"
                        /* As per requirement here we add the "Population Health Management Strategy" */
                        if (cntFirst3_Month == 4)
                        {
                            if (oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.Text.Length < 2) // InCase no any record exist in cell then we add apply bullet
                            {
                                oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.Text = oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.Text + "Population Health Management Strategy";
                            }
                            else
                                oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.Text = oWordDoc.Tables[2].Cell(1, cntFirst3_Month).Range.Text + "Population Health Management Strategy";
                        }
                        #endregion

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For second 3 months
                    #region For second 3 months
                    if (cntDiff >= 3 && cnt1 < 5)
                    {
                        cnt1 = cnt1 + 2;
                        oWordDoc.Tables[2].Cell(2, cnt1).Select();
                        oWordDoc.Tables[2].Cell(2, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntSecond3_Month = cnt1 + 1;

                        // Condition for Healthcare Reform
                        objCommFun.Get_Healthcare_Topic(i, cntSecond3_Month, 2, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntSecond3_Month, 2, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntSecond3_Month, 2, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cntSecond3_Month, 2, oWordDoc, ActivityDS);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For third 3 months
                    #region For third 3 months
                    if (cntDiff >= 6 && cnt2 < 5)
                    {
                        cnt2 = cnt2 + 2;
                        oWordDoc.Tables[2].Cell(3, cnt2).Select();
                        oWordDoc.Tables[2].Cell(3, cnt2).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntThird3_Month = cnt2 + 1;

                        // Condition for Healthcare Reform
                        objCommFun.Get_Healthcare_Topic(i, cntThird3_Month, 3, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntThird3_Month, 3, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntThird3_Month, 3, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cntThird3_Month, 3, oWordDoc, ActivityDS);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    // For fourth 3 months
                    #region For fourth 3 months
                    if (cntDiff >= 9 && cnt3 < 5)
                    {
                        cnt3 = cnt3 + 2;
                        oWordDoc.Tables[2].Cell(4, cnt3).Select();
                        oWordDoc.Tables[2].Cell(4, cnt3).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                        cntFourth3_Month = cnt3 + 1;

                        // Condition for Healthcare Reform
                        objCommFun.Get_Healthcare_Topic(i, cntFourth3_Month, 4, oWordDoc, Healthcare_Reform);

                        // Condition for USI Holidays
                        objCommFun.Get_USI_Holidays_Topic(i, cntFourth3_Month, 4, oWordDoc, USI_Holidays);

                        // Condition for Wellness
                        objCommFun.Get_Wellness_Topic(i, cntFourth3_Month, 4, oWordDoc, Wellness);

                        //For writing Topics
                        objCommFun.Get_Topic_Basis_On_Month(i, cntFourth3_Month, 4, oWordDoc, ActivityDS);

                        // For note 2 - Custom field 1
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_1, strCustField1);

                        // For note 2 - Custom field 2
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_2, strCustField2);

                        // For note 2 - Custom field 3
                        objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_3, strCustField3);
                    }
                    #endregion

                    cntDiff++;
                }

                // If the month difference is less than 12 then execute the below
                int cntDiff1 = cntDiff;
                if (cntDiff < 12)
                {
                    for (int i = 1; i <= 12 - cntDiff; i++)
                    {
                        // For first 3 months
                        #region For first 3 months
                        if (cnt < 5)
                        {
                            cnt = cnt + 2;
                            oWordDoc.Tables[2].Cell(1, cnt).Select();
                            oWordDoc.Tables[2].Cell(1, cnt).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntFirst3_Month = cnt + 1;

                            // Condition for Healthcare Reform
                            objCommFun.Get_Healthcare_Topic(i, cntFirst3_Month, 1, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntFirst3_Month, 1, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntFirst3_Month, 1, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(i, cntFirst3_Month, 1, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntFirst3_Month, 1, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For second 3 months
                        #region For second 3 months
                        if (cntDiff1 >= 3 && cnt1 < 5)
                        {
                            cnt1 = cnt1 + 2;
                            oWordDoc.Tables[2].Cell(2, cnt1).Select();
                            oWordDoc.Tables[2].Cell(2, cnt1).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntSecond3_Month = cnt1 + 1;

                            // Condition for Healthcare Reform
                            objCommFun.Get_Healthcare_Topic(i, cntSecond3_Month, 2, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntSecond3_Month, 2, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntSecond3_Month, 2, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(i, cntSecond3_Month, 2, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntSecond3_Month, 2, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For third 3 months
                        #region For third 3 months
                        if (cntDiff1 >= 6 && cnt2 < 5)
                        {
                            cnt2 = cnt2 + 2;
                            oWordDoc.Tables[2].Cell(3, cnt2).Select();
                            oWordDoc.Tables[2].Cell(3, cnt2).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntThird3_Month = cnt2 + 1;

                            // Condition for Healthcare Reform
                            objCommFun.Get_Healthcare_Topic(i, cntThird3_Month, 3, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntThird3_Month, 3, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntThird3_Month, 3, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(i, cntThird3_Month, 3, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntThird3_Month, 3, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        // For fourth 3 months
                        #region For fourth 3 months
                        if (cntDiff1 >= 9 && cnt3 < 5)
                        {
                            cnt3 = cnt3 + 2;
                            oWordDoc.Tables[2].Cell(4, cnt3).Select();
                            oWordDoc.Tables[2].Cell(4, cnt3).Range.Text = dictionaryMonth[i].ToString(); // For showing month name in the Renewal Month heading(s)
                            cntFourth3_Month = cnt3 + 1;

                            // Condition for Healthcare Reform
                            objCommFun.Get_Healthcare_Topic(i, cntFourth3_Month, 4, oWordDoc, Healthcare_Reform);

                            // Condition for USI Holidays
                            objCommFun.Get_USI_Holidays_Topic(i, cntFourth3_Month, 4, oWordDoc, USI_Holidays);

                            // Condition for Wellness
                            objCommFun.Get_Wellness_Topic(i, cntFourth3_Month, 4, oWordDoc, Wellness);

                            //For writing Topics
                            objCommFun.Get_Topic_Basis_On_Month(i, cntFourth3_Month, 4, oWordDoc, ActivityDS);

                            // For note 2 - Custom field 1
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_1, strCustField1);

                            // For note 2 - Custom field 2
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_2, strCustField2);

                            // For note 2 - Custom field 3
                            objCommFun.Get_Custom_Field_Values(i, cntFourth3_Month, 4, oWordDoc, Cust_Field_3, strCustField3);
                        }
                        #endregion

                        cntDiff1++;
                    }
                }

                #endregion

                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Short Office Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Renewal Month"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dictionaryMonth[SelectedMonthNo].ToString());
                            continue;
                        }
                        if (fieldName.Contains("Renewal Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Renewal_Year.ToString());
                            continue;
                        }

                        // To include the graphics image in the report
                        // if value = 0 ('Graphics') is selected then graphics image will be displayed
                        // if value = 1 ('No Graphics') is selected then graphics image will not be displayed
                        if (fieldName.Contains("Graphics_Image"))
                        {
                            myMergeField.Select();
                            if (ddlReportStyle.SelectedItem.Value == "1")
                            {
                                oWordApp.Selection.TypeText(" ");
                                object missing = System.Type.Missing;
                                Word.Range rng = rngFieldCode;
                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/Service_Calendar_Graphics.jpg"));
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (ddlOffice.SelectedIndex > -1)
                        {
                            DataRow[] FoundRow = null;
                            FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                            if (FoundRow.Count() > 0)
                            {
                                if (fieldName.Contains("Office Full Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeName"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeName"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Address"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["OfficeAddress"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("Office Phone Number"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(FoundRow[0]["PhoneNumber"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText(FoundRow[0]["PhoneNumber"].ToString().Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("OFFICE LOGO"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                    object missing = System.Type.Missing;
                                    Word.Range rng = rngFieldCode;
                                    rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                    string imageName = FoundRow[0]["OfficeLogo"].ToString().Replace("jpg", "png");
                                    rng.InlineShapes.AddPicture(Server.MapPath("~/Files/ServiceCalendar/Images/CompanyLogo/" + imageName));
                                }
                            }
                        }
                    }
                }
                #endregion

                #region For Account Team information writing
                int cntAT = 6;
                string name = string.Empty;
                string role = string.Empty;
                string workPhone = string.Empty;
                string email = string.Empty;

                if (grdAccountTeam != null)
                {
                    CheckBox chkItemSelect = new CheckBox();
                    foreach (GridViewRow grRow in grdAccountTeam.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (cntAT <= 9)
                        {
                            if (chkItemSelect.Checked == true)
                            {
                                name = "";
                                role = "";
                                workPhone = "";
                                email = "";

                                name = Convert.ToString(grRow.Cells[4].Text).Replace("&nbsp;", "") + " " + Convert.ToString(grRow.Cells[5].Text).Replace("&nbsp;", "");
                                role = Convert.ToString(grRow.Cells[1].Text).Replace("&nbsp;", "");
                                workPhone = Convert.ToString(grRow.Cells[2].Text).Replace("&nbsp;", "");
                                email = Convert.ToString(grRow.Cells[3].Text).Replace("&nbsp;", "");

                                cntAT++;
                                oWordDoc.Tables[2].Cell(cntAT, 1).Select();
                                oWordDoc.Tables[2].Cell(cntAT, 1).Range.Text = name + ", " + role + ": " + workPhone + " / " + email;

                                if (cntAT == 9)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


    }
}