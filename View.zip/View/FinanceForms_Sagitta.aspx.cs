﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.Tools;
using System.Collections;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.Tools;
using BenefitPointSummaryPortal.BAL.Finance;

////using System.Data.SqlClient;
////using System.Configuration;

namespace BenefitPointSummaryPortal.View
{
    public partial class FinanceForms_Sagitta : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        DataSet ProductDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        ConstantValue cv = new ConstantValue();
        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList MedicalBenefitColumnId_Tier3 = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList();
        ArrayList WellnessBenefitColumnIdList = new ArrayList();
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        //Added For New Development Account Profile Details 
        ArrayList DisabilityBenefitColumnIdList = new ArrayList();
        ArrayList AccidentalBenefitColumnIdList = new ArrayList();
        ArrayList AdditionalProductsBenefitColumnIdList = new ArrayList();
        ArrayList StopLossBenefitColumnIdList = new ArrayList();
        ArrayList PrescriptionDrugBenefitColumnIdList = new ArrayList();
        Dictionary<string, string> dictFormDescriptions = new Dictionary<string, string>();
        static DataTable dtPlanContact;
        static DataTable PlanTableCriteriaPageSecond = new DataTable();
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                LoadDisplayFormDescription();
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                if (!IsPostBack)
                {
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();
                    SummaryDetail sd = new SummaryDetail();
                    DictDepartment = sd.getDepartmentDetails();
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    if (Convert.ToString(Session["Summary"]) == "Finance")
                    {
                        TitleSpan.InnerText = "Finance Forms for Sagitta";
                        hdnSummary.Value = "Finance";
                        //Activity_Group = "Finance";
                        Activity_Group = "Tools";
                        Session["DeliverableCategory"] = "Finance";
                    }
                    mvClientContact.ActiveViewIndex = 0;
                    hdnCriteriaPage.Value = "0";
                    txtsearch.Focus();
                    ////Activity = TitleSpan.InnerText;
                    Activity = "Finance Forms";
                    trBillingContact.Visible = false;
                    lblAccountContact.Visible = false;
                    pnlChkAccountContact.Visible = false;
                    divCommssionSP.Visible = false;
                    divInvoiceType.Visible = false;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "none");
                    divAvailbalePlan_Next.Visible = false;
                    divAvailbalePlan.Visible = false;
                }
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btnSummary);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                //ddlActivity.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                pnlPlans.Visible = false;
                // rdlActivity.SelectedIndex = 0;
                //BPBusiness bp = new BPBusiness();

                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Reset page.
        /// </summary>
        protected void Clear()
        {
            ddlInvoiceType.SelectedIndex = 0;
            ddlTypeOfForm.SelectedIndex = 0;
            txtCommisionSpliteDate.Text = string.Empty;
            txtFormDecription.Text = string.Empty;
            ddlIsCommissionSplit.SelectedIndex = 0;
            ddlTotalAssociate.SelectedIndex = 0;
        }

        private void ClearControl()
        {

            divAvailbalePlan.Visible = false;
            divAvailbalePlan_Next.Visible = false;
            divInvoiceType.Visible = false;
            divCommssionSP.Visible = false;
            trBillingContact.Visible = false;
            trBillingContact_1.Visible = false;

            grdPlans.DataSource = null;
            grdPlans.DataBind();
            grdPlans_Next.DataSource = null;
            grdPlans_Next.DataBind();

            ddlInvoiceType.SelectedIndex = 0;

            txtCommisionSpliteDate.Text = string.Empty;
            txtCommisionSpliteDate_Next.Text = string.Empty;
            ddlIsCommissionSplit.SelectedIndex = 0;
            ddlTotalAssociate.SelectedIndex = 0;
            ddlIsCommissionSplit_Next.SelectedIndex = 0;
            ddlTotalAssociate_Next.SelectedIndex = 0;
            spnSummeryText.InnerText = string.Empty;
            btnViewPlans.Text = "View Plans";
            //cblistAccountContact.Items.Clear();
        }

        private bool checkValidation(DataTable PlanInfoTable)
        {
            bool validationResult = true;
            try
            {
                //Check Validation for Commission Split 
                if (ddlTypeOfForm.SelectedValue == "ComissionSplit" && ddlIsCommissionSplit.SelectedValue == "No")
                {
                    if (PlanInfoTable.Rows.Count > 0)
                    {
                        validationResult = true;
                    }
                    else
                    {
                        validationResult = false;
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return validationResult;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                divBtnPrevious.Style.Add("Display", "none");
                divBtnNext.Style.Add("Display", "none");
                divBtnSummary.Style.Add("Display", "block");

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //ddlActivity.Items.Clear();
                // rdlActivity.SelectedIndex = 0;

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;

                cblistAccountContact.Items.Clear();
                ClearControl();
                txtFormDecription.Text = string.Empty;
                txtFormDecription.Visible = false;
                ddlTypeOfForm.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        private void LoadBillingContactList()
        {

            if (Convert.ToString(Session["Summary"]) == "Finance")
            {
                lblMessage.Visible = false;
                cblistAccountContact.Items.Clear();
                SessionId = Session["SessionId"].ToString();
                List<Contact> acctContact = new List<Contact>();
                List<Contact> ContactList = new List<Contact>();
                Contact cont = new Contact();
                if (ddlClient.SelectedValue != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                }

                ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();

                if (ContactList != null)
                {
                    for (int i = 0; i < ContactList.Count; i++)
                    {
                        cont = new Contact();
                        cont.ContactId = ContactList[i].ContactId;
                        if (!string.IsNullOrEmpty(ContactList[i].Title))
                        {
                            cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                        }
                        else
                        {
                            cont.Name = ContactList[i].Name;
                        }
                        acctContact.Add(cont);
                    }
                }
                if (acctContact.Count > 0)
                {
                    cblistAccountContact.DataSource = acctContact;
                    cblistAccountContact.DataBind();
                    pnlChkAccountContact.Height = 130;
                }
                else
                {
                    lblMessage.Visible = true;
                    pnlChkAccountContact.Height = 50;
                }
            }

        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                Session["PlanTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;

                DataTable PlanInfoTable = new DataTable();
                DataTable PlanInfoTable_Second = new DataTable();

                if (Convert.ToString(Session["Summary"]) == "Finance")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }
                    else
                    {
                        //flag = CheckAccountContactsSelected();
                    }
                }


                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    List<Carrier> carrierList = new List<Carrier>();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    string mynewfile = "";


                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();
                    sd.BuildContributionTable();
                    sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    //sd.BuildRateTable();

                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


                    //string Office_Region = Account_Region;
                    string Office_Region = Account_Region + " / " + Account_Office;

                    #region common for both

                    if (Convert.ToString(Session["Summary"]) == "Finance")
                    {
                        if (ddlTypeOfForm.SelectedValue == "ComissionSplit" && ddlIsCommissionSplit.SelectedValue == "No")
                        {
                            PlanInfoTable = GetPlanInfoTable_CriteriaPageFirst();
                        }
                        else if (ddlTypeOfForm.SelectedValue == "ComboInvoiceClient" && ddlInvoiceType.SelectedValue != "Select" && ddlIsCommissionSplit_Next.SelectedValue == "No")
                        {
                            PlanInfoTable_Second = GetPlanInfoTable_CriteriaPageSecond();
                            PlanInfoTable = (DataTable)Session["PlanInfoTable"];
                        }
                        else if (ddlTypeOfForm.SelectedValue == "ComboInvoiceClient" && ddlInvoiceType.SelectedValue != "Select" && ddlIsCommissionSplit_Next.SelectedValue == "Yes")
                        {
                            PlanInfoTable = (DataTable)Session["PlanInfoTable"];
                        }
                        else if (ddlTypeOfForm.SelectedValue == "InvoiceClient" && ddlInvoiceType.SelectedValue != "Select")
                        {
                            PlanInfoTable = GetPlanInfoTable_CriteriaPageFirst();
                        }
                    }

                    DataTable PlanTable = new DataTable();
                    PlanTable.Merge(PlanInfoTable);

                    //RateDS = sd.GetRateForTools(PlanTable, SessionId);
                    //ContributionDS = sd.GetContributionForTool(PlanTable, SessionId);
                    var table = from x in PlanInfoTable.AsEnumerable() where !string.IsNullOrEmpty(x.Field<string>("PlanType")) select x;

                    PlanTable.Clear();
                    foreach (dynamic i in table)
                    {
                        PlanTable.NewRow();
                        PlanTable.ImportRow(i);
                    }

                    ProductDS = sd.GetProductDetail(PlanInfoTable, SessionId);
                    carrierList = bp.GetAllCarriers(SessionId);
                    //BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);

                    #endregion


                    //code used for selected primary contact
                    #region selected primary contact
                    ////DataTable dtNewAcctContactList = new DataTable();
                    ////dtNewAcctContactList.Columns.Add("Name", typeof(string));
                    ////dtNewAcctContactList.Columns.Add("ID", typeof(string));
                    ////dtNewAcctContactList.Columns.Add("PrimaryContact", typeof(string));
                    ////string ID = string.Empty;
                    ////string Name = string.Empty;
                    ////string primary = string.Empty;

                    ////for (int i = 0; i < ddlSelectedAccountContact.Items.Count; i++)
                    ////{
                    ////    if (ddlSelectedAccountContact.Items[i].Selected == true)
                    ////    {
                    ////        primary = "1";
                    ////    }
                    ////    else
                    ////    {
                    ////        primary = "2";
                    ////    }
                    ////    Name = ddlSelectedAccountContact.Items[i].Text;
                    ////    ID = ddlSelectedAccountContact.Items[i].Value;
                    ////    dtNewAcctContactList.Rows.Add(Name, ID, primary);
                    ////}

                    #endregion

                    if (Convert.ToString(Session["Summary"]) == "Finance")
                    {
                        //Check Validation for Commission Split 
                        if (ddlTypeOfForm.SelectedValue == "ComissionSplit" && (ddlIsCommissionSplit.SelectedValue == "No" || ddlIsCommissionSplit.SelectedValue == "Yes"))
                        {
                            if (ddlIsCommissionSplit.SelectedValue == "No")
                            {
                                if (PlanInfoTable.Rows.Count > 0)
                                {
                                    mynewfile = CreateCommissionSplitRequest(txtCommisionSpliteDate.Text, Office_Region, PlanInfoTable, AccountDS, AccountTeamMemberDS, SessionId, ddlIsCommissionSplit.SelectedValue, ddlClient.SelectedItem.Text, ddlTotalAssociate.SelectedIndex);
                                }
                                else
                                {
                                    if (PlanInfoTable.Rows.Count > 0)
                                    {
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                    }
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                    return;
                                }
                            }
                            else if (ddlIsCommissionSplit.SelectedValue == "Yes")
                            {
                                mynewfile = CreateCommissionSplitRequest(txtCommisionSpliteDate.Text, Office_Region, PlanInfoTable, AccountDS, AccountTeamMemberDS, SessionId, ddlIsCommissionSplit.SelectedValue, ddlClient.SelectedItem.Text, ddlTotalAssociate.SelectedIndex);
                            }
                        }
                        else if (ddlTypeOfForm.SelectedValue == "InvoiceClient" && ddlInvoiceType.SelectedValue != "Select")
                        {
                            if (PlanInfoTable.Rows.Count > 0)
                            {
                                if (ddlTypeOfForm.SelectedValue == "InvoiceClient")
                                {
                                    mynewfile = CreateInvoiceClient(SessionId, PlanInfoTable, ProductDS, AccountTeamMemberDS, AccountDS, ContactList, Office_Region, carrierList);
                                }
                            }
                            else
                            {
                                if (PlanInfoTable.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                return;
                            }
                        }
                        else if (ddlTypeOfForm.SelectedValue == "ComboInvoiceClient" && ddlInvoiceType.SelectedValue != "Select")
                        {
                            if (ddlIsCommissionSplit_Next.SelectedValue == "No")
                            {
                                if (PlanInfoTable_Second.Rows.Count > 0)
                                {
                                    mynewfile = WriteComboInvoiceReport(SessionId, PlanInfoTable, PlanInfoTable_Second, ProductDS, AccountTeamMemberDS, AccountDS, ContactList, Office_Region, carrierList);
                                }
                                else
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                    return;
                                }

                            }
                            else if (ddlIsCommissionSplit_Next.SelectedValue == "Yes")
                            {
                                mynewfile = WriteComboInvoiceReport(SessionId, PlanInfoTable, PlanInfoTable_Second, ProductDS, AccountTeamMemberDS, AccountDS, ContactList, Office_Region, carrierList);
                            }
                        }//OuterElseIF
                    }

                    DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                int CriteriaPageIndex = 1;// THIS INDICATE THAT THIS CALLING FROM FIRST PAGE 
                if (ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient")
                {
                    if (ddlInvoiceType.SelectedIndex > 0)
                    {
                        grdPlans.DataSource = null;
                        grdPlans.DataBind();
                        LoadAvailablePlan(CriteriaPageIndex);
                        #region OLD CODE
                        ////    bool flag = true;
                        ////    Hashtable htSortedPlanList = new Hashtable();

                        ////    if (Convert.ToString(Session["Summary"]) == "Finance")
                        ////    {
                        ////        grdPlans.DataSource = null;
                        ////        grdPlans.DataBind();
                        ////        //flag = CheckAccountContactsSelected();
                        ////    }

                        ////    if (flag == true)
                        ////    {
                        ////        List<Plan> PlanList = new List<Plan>();
                        ////        List<Plan> commonPlanList = new List<Plan>();
                        ////        Session["PlanList"] = null;
                        ////        SessionId = Session["SessionId"].ToString();
                        ////        if (ddlClient.SelectedIndex > 0)
                        ////        {
                        ////            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        ////        }
                        ////        Session["PlanList"] = PlanList;

                        ////        if (PlanList != null)
                        ////        {
                        ////            if (PlanList.Count > 0)
                        ////            {
                        ////                if (rdlPlan.SelectedIndex == 0)
                        ////                {
                        ////                    // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                        ////                    if (Convert.ToString(Session["Summary"]) == "Finance")
                        ////                    {
                        ////                        foreach (Plan item in PlanList)
                        ////                        {
                        ////                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                        ////                            {
                        ////                                commonPlanList.Add(item);
                        ////                            }
                        ////                        }
                        ////                    }
                        ////                    // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                        ////                }
                        ////                if (rdlPlan.SelectedIndex == 1)
                        ////                {
                        ////                    foreach (Plan item in PlanList)
                        ////                    {
                        ////                        commonPlanList.Add(item);
                        ////                    }
                        ////                }

                        ////                //  commonPlanList.OrderBy(a => a.ProductTypeId);
                        ////                List<Plan> lstPlanList = new List<Plan>();

                        ////                lstPlanList = (from l in commonPlanList
                        ////                               orderby l.ProductTypeId, l.CarrierName ascending
                        ////                               select l).ToList();

                        ////                /**************************************************************************************/
                        ////                /* As per Requirment here We check Invoice type and form type and show Plan and Additional Product Accourdingly.*/
                        ////                /*********************************************************************************/
                        ////                if (ddlInvoiceType.SelectedValue == "ServiceFee" && (ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient"))
                        ////                {
                        ////                    grdPlans.DataSource = lstPlanList.Where(p => p.ProductTypeId.ToString().Length > 3);
                        ////                    grdPlans.DataBind();
                        ////                    if (grdPlans.Rows.Count <= 0)
                        ////                    {
                        ////                        string script = "alert(\"No active Additional Product.\");";
                        ////                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        ////                    }
                        ////                }
                        ////                else
                        ////                {
                        ////                    grdPlans.DataSource = lstPlanList;
                        ////                    grdPlans.DataBind();
                        ////                }

                        ////                if (commonPlanList.Count > 0)
                        ////                {
                        ////                    pnlPlans.Visible = true;
                        ////                    if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "ServiceFee")
                        ////                    {
                        ////                        spnSummeryText.InnerText = "Select the applicable Fee for Service additional product.";
                        ////                    }
                        ////                    else if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "BillClientandRemit_Comm")
                        ////                    {
                        ////                        spnSummeryText.InnerText = "Select the applicable plan or product that we are billing premium to the client and upon receipt, remitting to the carrier net of USI commission.";
                        ////                    }
                        ////                    else if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "ThirdPartyServicesPassThrough")
                        ////                    {
                        ////                        spnSummeryText.InnerText = "Select the applicable plan or product that we are billing the client for Third Party Services and in turn, paying the vendor. (Pass through Services with no USI commission or Producer Comp).";
                        ////                    }

                        ////                    ////CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                        ////                    ////ChkBoxHeader.Checked = true;
                        ////                    ////foreach (GridViewRow row in grdPlans.Rows)
                        ////                    ////{
                        ////                    ////    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                        ////                    ////    ChkBoxRows.Checked = true;
                        ////                    ////}
                        ////                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        ////                }
                        ////                else
                        ////                {
                        ////                    string script = "alert(\"No active plans.\");";
                        ////                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        ////                }
                        ////            }
                        ////        }
                        ////    }
                        #endregion
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Invoice Type.')</script>", false);
                        return;
                    }
                }
                else if (ddlTypeOfForm.SelectedValue == "ComissionSplit")
                {
                    grdPlans.DataSource = null;
                    grdPlans.DataBind();
                    LoadAvailablePlan(CriteriaPageIndex);
                }

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        private void LoadAvailablePlan(int CriteriaPageIndex)
        {
            try
            {
                bool flag = true;
                Hashtable htSortedPlanList = new Hashtable();

                ////if (Convert.ToString(Session["Summary"]) == "Finance")
                ////{
                ////    grdPlans.DataSource = null;
                ////    grdPlans.DataBind();

                ////    grdPlans_Next.DataSource = null;
                ////    grdPlans_Next.DataBind();
                ////    //flag = CheckAccountContactsSelected();
                ////}

                if (flag == true)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (CriteriaPageIndex == 1)
                            {
                                #region check Active/All click

                                if (rdlPlan.SelectedIndex == 0)
                                {
                                    if (Convert.ToString(Session["Summary"]) == "Finance")
                                    {
                                        foreach (Plan item in PlanList)
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                if (rdlPlan.SelectedIndex == 1)
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                                #endregion
                            }
                            else if (CriteriaPageIndex == 2)
                            {
                                if (rdlPlan_Next.SelectedIndex == 0)
                                {
                                    if (Convert.ToString(Session["Summary"]) == "Finance")
                                    {
                                        foreach (Plan item in PlanList)
                                        {
                                            if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                if (rdlPlan_Next.SelectedIndex == 1)
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        commonPlanList.Add(item);
                                    }
                                }
                            }



                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            /**************************************************************************************/
                            /* As per Requirment here We check Invoice type and form type and show Plan and Additional Product Accourdingly.*/
                            /*********************************************************************************/
                            if (ddlInvoiceType.SelectedValue == "ServiceFee" && (ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient"))
                            {
                                if (CriteriaPageIndex == 1)
                                {
                                    grdPlans.DataSource = lstPlanList.Where(p => p.ProductTypeId.ToString().Length > 3);
                                    grdPlans.DataBind();
                                    if (grdPlans.Rows.Count <= 0)
                                    {
                                        string script = "alert(\"No active Additional Product.\");";
                                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                                    }
                                }
                                else if (CriteriaPageIndex == 2)
                                {
                                    grdPlans_Next.DataSource = lstPlanList;
                                    grdPlans_Next.DataBind();
                                    if (grdPlans_Next.Rows.Count <= 0)
                                    {
                                        string script = "alert(\"No active Additional Product.\");";
                                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                                    }
                                }
                            }
                            else
                            {
                                if (CriteriaPageIndex == 1)
                                {
                                    grdPlans.DataSource = lstPlanList;
                                    grdPlans.DataBind();
                                }
                                else if (CriteriaPageIndex == 2)
                                {
                                    grdPlans_Next.DataSource = lstPlanList;
                                    grdPlans_Next.DataBind();
                                    if (grdPlans_Next.Rows.Count <= 0)
                                    {
                                        string script = "alert(\"No active Additional Product.\");";
                                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                                    }
                                }
                            }

                            if (commonPlanList.Count > 0)
                            {
                                if (CriteriaPageIndex == 1)
                                {
                                    pnlPlans.Visible = true;
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                else if (CriteriaPageIndex == 2)
                                {
                                    pnlPlans_Next.Visible = true;
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans_Next');</script>", false);
                                }
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
        }

        private DataTable GetPlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();


            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        private DataTable GetPlanInfoTable_CriteriaPageFirst()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds();
            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {

                            //foreach (var data in BenefitSummaryList)
                            //{

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;


                        }
                        else
                        {

                        }

                    }


                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanInfoTable.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            if (ddlTypeOfForm.SelectedValue != "ComissionSplit" && ChkBoxHeader.Checked == true)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select only 1 plan from Grid.')</script>", false);
                ChkBoxHeader.Checked = false;
                return;
            }
            else
            {
                foreach (GridViewRow row in grdPlans.Rows)
                {
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                    if (ChkBoxHeader.Checked == true)
                    {
                        ChkBoxRows.Checked = true;
                    }
                    else
                    {
                        ChkBoxRows.Checked = false;
                    }
                }
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
            }//ElseIFClose

            /****************** OLD CODE*****************************/
            ////foreach (GridViewRow row in grdPlans.Rows)
            ////{
            ////    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
            ////    if (ChkBoxHeader.Checked == true)
            ////    {
            ////        ChkBoxRows.Checked = true;
            ////    }
            ////    else
            ////    {
            ////        ChkBoxRows.Checked = false;
            ////    }
            ////}
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        private bool CheckAccountContactsSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        cnt++;
                    }
                }

                if (cnt > 3)
                {
                    string script = "alert(\"Please select max 3 Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        protected void cblistAccountContact_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dtAcctContactList = new DataTable();
                dtAcctContactList.Columns.Add("Name", typeof(string));
                dtAcctContactList.Columns.Add("ID", typeof(string));
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        dtAcctContactList.Rows.Add(cblistAccountContact.Items[i].Text, cblistAccountContact.Items[i].Value);
                    }
                }
                grdSelectedAccountContact.DataSource = dtAcctContactList;
                grdSelectedAccountContact.DataBind();

                ddlSelectedAccountContact.DataSource = dtAcctContactList;
                ddlSelectedAccountContact.DataBind();
            }

            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /*********************************** Coded Added By Amogh Coding **********/

        protected void ddlClient_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ClearControl();
            ddlTypeOfForm.SelectedIndex = 0;
        }

        protected void ddlTypeOfForm_OnSelectedIndexChanged(object sender, EventArgs e)
        {

            ClearControl();
            /************************************************************************************************************/
            /*************** CONTACT DETAILS ONLY DISPLAY IF FORM TYPE IS ----> "INVOICE CLIENT/COMBO -" ***********************/
            /************************************************************************************************************/
            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                string script = "alert(\"Please select client.\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                ddlTypeOfForm.SelectedIndex = 0;
                return;
            }


            #region FORM Description
            if (dictFormDescriptions[ddlTypeOfForm.SelectedValue.Trim()] != string.Empty)
            {
                txtFormDecription.Text = dictFormDescriptions[ddlTypeOfForm.SelectedValue.Trim()];
                txtFormDecription.Visible = true;
            }
            else
            {
                txtFormDecription.Text = ""; ;
                txtFormDecription.Visible = false;
            }
            #endregion

            if (ddlTypeOfForm.SelectedValue == "InvoiceClient")
            {
                LoadBillingContactList();
                ShowHidePanel("1");
                //code added by shravan "FEEDBACK 3: New Deliverables Module Request - Finance Forms for Sagitta"
                ddlInvoiceType.Items[3].Enabled = true;
            }
            else if (ddlTypeOfForm.SelectedValue == "ComissionSplit")
            {
                ShowHidePanel("2");
            }
            else if (ddlTypeOfForm.SelectedValue == "ComboInvoiceClient")
            {
                LoadBillingContactList();
                ShowHidePanel("3");
                //code added by shravan "FEEDBACK 3: New Deliverables Module Request - Finance Forms for Sagitta"
                ddlInvoiceType.Items[3].Enabled = false;
            }
            else if (ddlTypeOfForm.SelectedValue == "Select")
            {
                trBillingContact.Visible = false;
                trBillingContact_1.Visible = false;
                lblAccountContact.Visible = false;
                pnlChkAccountContact.Visible = false;
                divInvoiceType.Visible = false;
                divCommssionSP.Visible = false;
            }
            hdnTypeOfForm.Value = ddlTypeOfForm.SelectedValue.Trim();
        }


        private void LoadDisplayFormDescription()
        {
            #region Form Description
            dictFormDescriptions["Select"] = "";
            dictFormDescriptions["InvoiceClient"] = "This form is utilized if we have a relationship with a Client that requires USI to bill for brokerage or consulting services, the carrier invoices USI and we need to bill the client, or we need to pay Third Party Services Pass Through fees out of Sagitta.";
            dictFormDescriptions["ComissionSplit"] = "This form outlines those scenarios when there is a commission split between the EB Producer and one or more of the following:  another EB Producer, a P&C Producer, a Referral from an Associate or an Outside Broker.";
            dictFormDescriptions["ComboInvoiceClient"] = "This form is created when you have a Client that needs to be invoiced for services and there is a commission split between Producers.";
            #endregion
        }

        private void ShowHidePanel(string flag)
        {
            switch (flag)
            {
                case "1":
                    trBillingContact.Visible = true;
                    trBillingContact_1.Visible = true;
                    lblAccountContact.Visible = true;
                    pnlChkAccountContact.Visible = true;
                    divInvoiceType.Visible = true;
                    divCommssionSP.Visible = false;
                    divAvailbalePlan.Visible = true;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "none");
                    divBtnSummary.Style.Add("Display", "block");
                    break;
                case "2":
                    trBillingContact.Visible = false;
                    trBillingContact_1.Visible = false;
                    lblAccountContact.Visible = false;
                    pnlChkAccountContact.Visible = false;
                    divInvoiceType.Visible = false;
                    divCommssionSP.Visible = true;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "none");
                    divBtnSummary.Style.Add("Display", "block");
                    spnSummeryText.InnerText = "Select the applicable plans and products you would like to include in your Commission Split Request Form based on what is available in BenefitPoint.";
                    break;
                case "3":  /*--------- Combo - Invoice Client and Commission Split --------*/
                    trBillingContact.Visible = true;
                    trBillingContact_1.Visible = true;
                    lblAccountContact.Visible = true;
                    pnlChkAccountContact.Visible = true;
                    divInvoiceType.Visible = true;
                    divCommssionSP.Visible = false;
                    divAvailbalePlan.Visible = true;
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "block");
                    divBtnSummary.Style.Add("Display", "none");
                    break;
            }
        }

        protected void ddlIsCommissionSplit_Next_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlIsCommissionSplit_Next.SelectedValue == "Yes")
                {
                    grdPlans_Next.DataSource = null;
                    grdPlans_Next.DataBind();
                    divAvailbalePlan_Next.Visible = false;
                }
                else
                {
                    divAvailbalePlan_Next.Visible = true;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void chkHeaderSelect_Next_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckBox ChkBoxHeader = (CheckBox)grdPlans_Next.HeaderRow.FindControl("chkHeaderSelect_Next");
                foreach (GridViewRow row in grdPlans_Next.Rows)
                {
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                    if (ChkBoxHeader.Checked == true)
                    {
                        ChkBoxRows.Checked = true;
                    }
                    else
                    {
                        ChkBoxRows.Checked = false;
                    }
                }
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnViewPlans_Next_Click(object sender, EventArgs e)
        {
            try
            {
                int CriteriaPageIndex = 2;// THIS INDICATE THAT THIS CALLING FROM SECOND PAGE 
                grdPlans_Next.DataSource = null;
                grdPlans_Next.DataBind();
                LoadAvailablePlan(CriteriaPageIndex);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (mvClientContact.ActiveViewIndex == 1)
                {
                    mvClientContact.ActiveViewIndex = 0;
                    hdnCriteriaPage.Value = "0";
                    divBtnPrevious.Style.Add("Display", "none");
                    divBtnNext.Style.Add("Display", "block");
                    divBtnSummary.Style.Add("Display", "none");
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            Eligibility eligibilityItem = new Eligibility();
            string _PlanName = string.Empty;
            string selected_Value = string.Empty;
            bool flag = true;

            try
            {
                if (mvClientContact.ActiveViewIndex == 0) //**** When on First Criteria Page
                {
                    if (Convert.ToString(Session["Summary"]) == "Finance")
                    {
                        if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                            ddlClient.Focus();
                            flag = false;
                        }

                        DataTable PlanInfoTable = new DataTable();
                        PlanInfoTable = GetPlanInfoTable_CriteriaPageFirst();

                        Session["PlanInfoTable"] = PlanInfoTable;

                        if (PlanInfoTable != null)
                        {
                            if (PlanInfoTable.Rows.Count > 0)
                            {
                                mvClientContact.ActiveViewIndex = 1;
                                hdnCriteriaPage.Value = "1";
                                divBtnPrevious.Style.Add("Display", "block");
                                divBtnNext.Style.Add("Display", "none");
                                divBtnSummary.Style.Add("Display", "block");
                            }
                            else
                            {
                                if (grdPlans.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlPlan_Next_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans_Next.DataSource = null;
            grdPlans_Next.DataBind();
        }

        protected void ddlInvoiceType_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            spnSummeryText.InnerText = string.Empty;
            ChangeSummeryText();
        }


        private void ChangeSummeryText()
        {
            spnSummeryText.InnerText = string.Empty;
            if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "ServiceFee")
            {
                spnSummeryText.InnerText = "Select the applicable Fee for Service additional product.";
                btnViewPlans.Text = "View Products";
            }
            else if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "BillClientandRemit_Comm")
            {
                spnSummeryText.InnerText = "Select the applicable plan or product that we are billing premium to the client and upon receipt, remitting to the carrier net of USI commission.";
                btnViewPlans.Text = "View Plans";
            }
            else if ((ddlTypeOfForm.SelectedValue == "InvoiceClient" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlInvoiceType.SelectedValue == "ThirdPartyServicesPassThrough")
            {
                spnSummeryText.InnerText = "Select the applicable plan or product that we are billing the client for Third Party Services and in turn, paying the vendor. (Pass through Services with no USI commission or Producer Comp).";
                btnViewPlans.Text = "View Plans";
            }
            else if ((ddlTypeOfForm.SelectedValue == "ComissionSplit" || ddlTypeOfForm.SelectedValue == "ComboInvoiceClient") && ddlIsCommissionSplit.SelectedValue == "No")
            {
                spnSummeryText.InnerText = " Select the applicable plans and products you would like to include in your Commission Split Request Form based on what is available in BenefitPoint.";
                btnViewPlans.Text = "View Plans";
            }
            else if (ddlInvoiceType.SelectedValue == "Select")
            {
                btnViewPlans.Text = "View Plans";
                spnSummeryText.InnerText = string.Empty;
            }

        }


        private DataTable GetPlanInfoTable_CriteriaPageSecond()
        {
            //DataTable PlanInfoTable = new DataTable();
            PlanTableCriteriaPageSecond = CreatePlanInfoTable();
            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
            objCommFun.LoadPlanTypeIds();

            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans_Next != null)
                {
                    foreach (GridViewRow grRow in grdPlans_Next.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            PlanTableCriteriaPageSecond.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanTableCriteriaPageSecond.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanTableCriteriaPageSecond.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.ADD;
                            }
                            ////if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            ////}
                            ////if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            ////}
                            ////if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            ////}
                            ////if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            ////}
                            ////if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            ////}

                            ////if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            ////}

                            ////if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            ////}

                            ////if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            ////}

                            ////if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            ////}
                            ////if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            ////}

                            ////if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            ////}

                            ////if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            ////}

                            ////if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            ////}

                            ////if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            ////{
                            ////    PlanTableCriteriaPageSecond.Rows[rowCount]["PlanType"] = cv.ADD;
                            ////}
                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {

                            //foreach (var data in BenefitSummaryList)
                            //{

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;
                        }
                        else
                        {

                        }
                    }

                    var Rows = (from row in PlanTableCriteriaPageSecond.AsEnumerable()
                                select row);
                    PlanTableCriteriaPageSecond = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanTableCriteriaPageSecond.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanTableCriteriaPageSecond;
        }

        //********************  HERE WE WRITE THE LOGIC TO SHOW HIDE NEXT AND CREATE BUTTON 
        protected void ddlIsCommissionSplit_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //ScriptManager.RegisterStartupScript(Page, this.GetType(), "LoadDate", "<script>LoadDate();</script>", false);
                if (ddlIsCommissionSplit.SelectedValue == "Yes")
                {
                    grdPlans.DataSource = null;
                    grdPlans.DataBind();
                    divAvailbalePlan.Visible = false;
                }
                else
                {
                    divAvailbalePlan.Visible = true;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");

            }
        }

        protected string CreateInvoiceClient(string SessionId, DataTable PlanTable, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList, string Office_Region, List<Carrier> carrierList)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - EB Invoice Request Form.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - EB Invoice Request Form/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - EB Invoice Request Form")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - EB Invoice Request Form"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                EB_Invoice_Request wt = new EB_Invoice_Request();

                ArrayList arrAcctContact = new ArrayList();
                //arrAcctContact.Add(ddlAccountContacts.SelectedValue);
                // Commented By Vaibhav

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }
                //if (ddlUSI_City.SelectedIndex > 0)
                //{
                //    string[] office = ddlUSI_City.SelectedValue.Split('~');
                //    string City = Convert.ToString(office[0]).Trim();
                //    string BPOffice = Convert.ToString(office[1]).Trim();
                //    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
                //    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
                //}

                if (ddlInvoiceType.SelectedValue == "ServiceFee")
                    wt.WriteInvoiceFinance_ServiceFee(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, ProductDS, Office_Region, carrierList);
                if (ddlInvoiceType.SelectedValue == "BillClientandRemit_Comm")
                    wt.WriteInvoiceFinance_BillClient(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, ProductDS, Office_Region, carrierList);
                if (ddlInvoiceType.SelectedValue == "ThirdPartyServicesPassThrough")
                    wt.WriteInvoiceFinance_ThirdPartyService(oWordDoc, oWordApp, ddlClient, AccountDS, PlanTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact, ProductDS, Office_Region, carrierList);

                RunMacro(oWordApp, new Object[] { "CleanFinanceInvoiceForm" });
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                string AdditionalCrtieriaOption_1 = ddlTypeOfForm.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlInvoiceType.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                //// bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        private string CreateCommissionSplitRequest(string CommisionSpliteDate, string Account_Office, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, string SessionId, string IsCommissionSplit, string ClientName, int TotalAssociates)
        {

            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Commission Split Request Form.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Commission Split Request Form/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Commission Split Request Form")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Commission Split Request Form"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                EB_CommissionSplit objCommissionSplit = new EB_CommissionSplit();
                objCommissionSplit.WriteFinanceForm_CommissionSplitRequest(oWordDoc, oWordApp, CommisionSpliteDate, Account_Office, PlanInfoTable, AccountDS, AccountTeamMemberDS, SessionId, IsCommissionSplit, ClientName, TotalAssociates);
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

                //Created by Amogh 
                string AdditionalCrtieriaOption_1 = ddlTypeOfForm.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                MedicalBenefitColumnIdList.Add("410");       // International Bundled Plan (3-Tier)	410
                //MedicalBenefitColumnIdList.Add("233");       // Limited Benefit 2-Tier	
                MedicalBenefitColumnIdList.Add("148");          //149

                //MedicalBenefitColumnIdList.Add("141");

                //Stop Loss
                StopLossBenefitColumnIdList.Add("141");       // Stop Loss
                PrescriptionDrugBenefitColumnIdList.Add("173");       // Prescription Drug (Carve-Out) -- Amogh

                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("104");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");

                //Tier 3 medical 
                MedicalBenefitColumnId_Tier3.Add("105");
                MedicalBenefitColumnId_Tier3.Add("110");

                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");

                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // Group Term Life
                GroupTermLifeBenefitColumnIdList.Add("127");

                // ADD
                ADDBenefitColumnIdList.Add("129");
                // Accidental Plan provided by Nicole in New Development request Account Profile Details - Added by Amogh
                AccidentalBenefitColumnIdList.Add("134");        // Business Travel Accident (BTA)

                // Wellness
                WellnessBenefitColumnIdList.Add("162");
                WellnessBenefitColumnIdList.Add("317");
                //WellnessBenefitColumnIdList.Add("1740");



                //Disability Plan provided by Nicole in New Development request Account Profile Details - Added by Amogh
                DisabilityBenefitColumnIdList.Add("151"); //New York DBL
                DisabilityBenefitColumnIdList.Add("152"); //New Jersey TDB
                DisabilityBenefitColumnIdList.Add("153"); //Hawaii TDI

                //Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
                AdditionalProductsBenefitColumnIdList.Add("1790");
                AdditionalProductsBenefitColumnIdList.Add("5460");
                AdditionalProductsBenefitColumnIdList.Add("5500");
                AdditionalProductsBenefitColumnIdList.Add("1400");
                AdditionalProductsBenefitColumnIdList.Add("1160");
                AdditionalProductsBenefitColumnIdList.Add("1740"); // As Per Nicole we added in Additional Product List 
                ////AdditionalProductsBenefitColumnIdList.Add("1109");       // COBRA Administration
                ////AdditionalProductsBenefitColumnIdList.Add("5060");       // Hospitalization

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #region Combo commission split
        //Added by Vaibhav for combo invoice split commission
        protected string WriteComboInvoiceReport(string SessionId, DataTable PlanTable_FirstCriteriaPage, DataTable PlanTable_SecondCriteriaPage, DataSet ProductDS, DataSet AccountTeamMemberDS, DataSet AccountDS, List<Contact> ContactList, string Office_Region, List<Carrier> carrierList)
        {
            SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Combo Invoice Client and SetUp Commission Split.docm");
            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Combo Invoice Client and SetUp Commission Split/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docm");

            try
            {

                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Combo Invoice Client and SetUp Commission Split")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Finance/Documents/Template/Finance Form - Combo Invoice Client and SetUp Commission Split"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();

                #region common reporting functionality
                ComboInvoiceCommissionSplit wt = new ComboInvoiceCommissionSplit();
                ArrayList arrAcctContact = new ArrayList();
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }
                wt.WriteCommissionSplitInformationToComboReport(oWordDoc, oWordApp, AccountDS, AccountTeamMemberDS, txtCommisionSpliteDate_Next.Text, int.Parse(ddlTotalAssociate_Next.SelectedValue));
                wt.WriteContactInformationToComboTemplate(oWordDoc, oWordApp, ddlClient, AccountDS, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);
                wt.WriteOfficeAndServiceTeamInformationToComboReport(oWordDoc, oWordApp, AccountDS, AccountTeamMemberDS, Office_Region);
                wt.Write_Invoiceinfo_PolicyInfoToComboReport(oWordDoc, oWordApp, carrierList, PlanTable_FirstCriteriaPage, ProductDS);
                #endregion

                if (ddlIsCommissionSplit_Next.SelectedValue.ToLower().Equals("no"))
                {
                    wt.WriteCommissionSplitPlanInformationToComboReport(oWordDoc, oWordApp, PlanTable_SecondCriteriaPage);
                    wt.DeleteBookmarks(oWordDoc, oWordApp, "SplitCommission_YES");
                }
                else if (ddlIsCommissionSplit_Next.SelectedValue.ToLower().Equals("yes"))
                {
                    wt.DeleteBookmarks(oWordDoc, oWordApp, "SplitPlanList");
                }

                switch (ddlInvoiceType.SelectedValue)
                {
                    case "ServiceFee":
                        wt.Write_InvoiceDetails_ServiceFeeToComboReport(oWordDoc, oWordApp, ProductDS);
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_BillPremium");
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_ThirdParty");
                        break;
                    case "BillClientandRemit_Comm":
                        wt.Write_InvoiceDetails_BillClientandRemit_CommToComboReport(oWordDoc, oWordApp, ProductDS);
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_ServiceFee");
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_ThirdParty");
                        break;
                    case "ThirdPartyServicesPassThrough":
                        wt.Write_InvoiceDetails_ThirdPartyServiceToComboReport(oWordDoc, oWordApp, ProductDS);
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_ServiceFee");
                        wt.DeleteBookmarks(oWordDoc, oWordApp, "InvoiceType_BillPremium");
                        break;
                    default:
                        break;
                }
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlTypeOfForm.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlInvoiceType.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }



            return (savefilename.ToString());
        }
        #endregion
    }
}