﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;

namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTemplate_OnSiteClinicsDisclosure : System.Web.UI.Page
    {
        //BPBusiness bp = new BPBusiness();
        //SummaryDetail sd = new SummaryDetail();
        public void WriteFileds_OnSiteClinicsDisclosure(Word.Document oWordDoc, Word.Application oWordApp, string ClientName)
        {
            #region MergeField
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Client Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        //continue;    // -- Only One Field
                        break;
                    }
                }
            }
            #endregion
        }
    }
}