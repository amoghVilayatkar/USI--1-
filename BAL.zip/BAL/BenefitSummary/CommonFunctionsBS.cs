﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using BenefitPointSummaryPortal.BAL.BPTimeLine;

using System.Web.Configuration;
using System.Text.RegularExpressions;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class CommonFunctionsBS : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        public static List<int> MedicalPlanTypeList = new List<int>();
        public static List<int> DentalPlanTypeList = new List<int>();
        public static List<int> VisionPlanTypeList = new List<int>();
        public static List<int> LifeADDPlanTypeList = new List<int>();
        public static List<int> STDPlanTypeList = new List<int>();
        public static List<int> LTDPlanTypeList = new List<int>();
        public static List<int> VoluntaryLifeADDPlanTypeList = new List<int>();
        public static List<int> VoluntaryADDPlanTypeList = new List<int>();
        public static List<int> EAPPlanTypeList = new List<int>();
        public static List<int> FSAPlanTypeList = new List<int>();
        public static List<int> HRAPlanTypeList = new List<int>();
        public static List<int> HSAPlanTypeList = new List<int>();
        public static List<int> WellnessPlanTypeList = new List<int>();
        public static List<int> GroupTermLifePlanTypeList = new List<int>();
        public static List<int> ADNDPlanTypeList = new List<int>();
        public static List<int> AdditionalProductsPlanTypeList = new List<int>();
        public static List<int> StopLossPlanTypeList = new List<int>();
        public static List<int> FeesForServicePlanTypeList = new List<int>();

        // Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
        public static List<int> DisabilityPlanTypeList = new List<int>();
        public static List<int> AccidentalProductPlanTypeList = new List<int>();
        public static List<int> PrescriptionDrugPlanTypeList = new List<int>();
        public static Dictionary<string, List<int>> DictContactsPlanTypes = new Dictionary<string, List<int>>();

        public void NoticesFunction_EnrollmentSummaryOnly(CheckBoxList chkAnualNotice, Word.Range r, int marketplaceSelectedIndex = 0)
        {
            try
            {
                string path = "";
                if (Convert.ToString(Session["Summary"]) == "Template8")
                {
                    path = "~/Files/BenefitSummary/Documents/AnnualLegalNotice/";
                }
                else
                {
                    path = "~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/";
                }
                object missing = System.Type.Missing;

                //Ending of Page
                if (marketplaceSelectedIndex == 0)
                {
                    r.InsertFile(Server.MapPath(path + "9 - Legal Notices Contact Information.docx"), missing, true, missing, missing);
                }
                else
                {
                    r.InsertFile(Server.MapPath(path + "9 - Legal Notices Contact Information_WithMarketplace.docx"), missing, true, missing, missing);
                }

                for (int i = chkAnualNotice.Items.Count - 1; i >= 0; i--)
                {
                    if (chkAnualNotice.Items[i].Selected == true)
                    {
                        switch (i)
                        {
                            case 0:
                                if (Convert.ToString(Session["Summary"]) == "Template9_EnrollmentGuide")
                                {
                                    r.InsertFile(Server.MapPath(path + "1 - Womens Health Cancer Right_EnrolmentGuide.docx"), missing, true, missing, missing);
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath(path + "1 - Legal Notices Womens Health Cancer Rights.docx"), missing, true, missing, missing);
                                }
                                break;
                            case 1: r.InsertFile(Server.MapPath(path + "2 - Legal Notices Newborns Act Disclosure.docx"), missing, true, missing, missing); break;
                            case 2:
                                if (Convert.ToString(Session["Summary"]) == "Template9_EnrollmentGuide")
                                {
                                    r.InsertFile(Server.MapPath(path + "3 - Notice of Special Enrollment Rights_EnrolmentGuide.docx"), missing, true, missing, missing);
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath(path + "3 - Legal Notices Notice of Special Enrollment Rights.docx"), missing, true, missing, missing);
                                }
                                break;
                            case 3: r.InsertFile(Server.MapPath(path + "4 - Legal Notices Wellness Program.docx"), missing, true, missing, missing); break;
                            case 4: r.InsertFile(Server.MapPath(path + "5 - Legal Notices Grandfathered Status.docx"), missing, true, missing, missing); break;
                            case 5: r.InsertFile(Server.MapPath(path + "4a - Legal Notices Wellness Program-HIPAA.docx"), missing, true, missing, missing); break;
                            case 6: r.InsertFile(Server.MapPath(path + "6 - Legal Notics Patient Protection Model.docx"), missing, true, missing, missing); break;
                            case 7: r.InsertFile(Server.MapPath(path + "7 - Legal Notices Michelles Law.docx"), missing, true, missing, missing); break;
                            case 8:
                                if (Convert.ToString(Session["Summary"]) == "Template9_EnrollmentGuide")
                                {
                                    r.InsertFile(Server.MapPath(path + "8 - Legal Notices ERISA Statement_EnrolmentGuide.docx"), missing, true, missing, missing);
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath(path + "8 - Legal Notices ERISA Statement.docx"), missing, true, missing, missing);
                                }
                                break;
                        }
                    }
                }

                ////Initial  of Page
                //r.InsertFile(Server.MapPath(path + "InitialAnnualEnrollmentNoticeGuide.docx"), missing, true, missing, missing);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void NoticesFunction_AnnualLegalNoticesOnly(CheckBoxList chkAnualNotice, Word.Range r, int marketplaceSelectedIndex = 0)
        {
            BPBusiness bp = new BPBusiness();
            try
            {
                string path = "~/Files/BenefitSummary/Documents/AnnualLegalNotice/";
                object missing = System.Type.Missing;

                //Ending of Page
                if (marketplaceSelectedIndex == 0)
                {
                    r.InsertFile(Server.MapPath(path + "9 - Legal Notices Contact Information.docx"), missing, true, missing, missing);
                }
                else
                {
                    r.InsertFile(Server.MapPath(path + "9 - Legal Notices Contact Information_WithMarketplace.docx"), missing, true, missing, missing);
                }

                for (int i = chkAnualNotice.Items.Count - 1; i >= 0; i--)
                {
                    if (chkAnualNotice.Items[i].Selected == true)
                    {
                        switch (i)
                        {
                            case 0: r.InsertFile(Server.MapPath(path + "1 - Legal Notices Womens Health Cancer Rights.docx"), missing, true, missing, missing); break;
                            case 1: r.InsertFile(Server.MapPath(path + "2 - Legal Notices Newborns Act Disclosure.docx"), missing, true, missing, missing); break;
                            case 2: r.InsertFile(Server.MapPath(path + "3 - Legal Notices Notice of Special Enrollment Rights.docx"), missing, true, missing, missing); break;
                            case 3: r.InsertFile(Server.MapPath(path + "4 - Legal Notices Wellness Program.docx"), missing, true, missing, missing); break;
                            case 4: r.InsertFile(Server.MapPath(path + "5 - Legal Notices Grandfathered Status.docx"), missing, true, missing, missing); break;
                            case 5: r.InsertFile(Server.MapPath(path + "4a - Legal Notices Wellness Program-HIPAA.docx"), missing, true, missing, missing); break;
                            case 6: r.InsertFile(Server.MapPath(path + "6 - Legal Notics Patient Protection Model.docx"), missing, true, missing, missing); break;
                            case 7: r.InsertFile(Server.MapPath(path + "7 - Legal Notices Michelles Law.docx"), missing, true, missing, missing); break;
                            case 8: r.InsertFile(Server.MapPath(path + "8 - Legal Notices ERISA Statement.docx"), missing, true, missing, missing); break;
                        }
                    }
                }

                ////Initial  of Page
                //r.InsertFile(Server.MapPath(path + "InitialAnnualEnrollmentNoticeGuide.docx"), missing, true, missing, missing);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Below function is called for writing the fields present inside the contact information notice page
        // and the same function is used in all the templates
        public void WriteFieldsForContactInformationNotice(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, int index, int marketplaceSelectedIndex = 0, int creditableCoverageIndex = 0, CheckBoxList chkAnualNotice = null, bool isSelected = false, string selectedColor = "", string summaryName = "")
        {
            int iTotalFields = 0;
            BPBusiness bp = new BPBusiness();

            Word.WdColor wdColor_font = font_color(selectedColor);
            try
            {
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (shape.Name == "Annual_Notice_1" || shape.Name == "Annual_Notice_2" || shape.Name == "Annual_Notice_3" || shape.Name == "Annual_Notice_4" || shape.Name == "Annual_Notice_4_a" || shape.Name == "Annual_Notice_5" || shape.Name == "Annual_Notice_6" || shape.Name == "Annual_Notice_7" || shape.Name == "Annual_Notice_8" || shape.Name == "Annual_Notice_9")
                        {
                            shape.TextFrame.TextRange.Shading.BackgroundPatternColor = textbox_color(selectedColor);
                            shape.TextFrame.TextRange.Font.Color = Word.WdColor.wdColorWhite;
                        }
                    }
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("(MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("(MODIFICATION REQUIRED"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED");
                            continue;
                        }
                        if (fieldName.Contains("MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)");
                            continue;
                        }
                        if (fieldName.Contains("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)");
                            continue;
                        }

                        if (fieldName.Contains("(IF APPLICABLE -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(IF APPLICABLE - ");
                            continue;
                        }

                        if (fieldName.Contains("(ONLY USE IF GRANDFATHERED -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(ONLY USE IF GRANDFATHERED - ");
                            continue;
                        }

                        if (fieldName.Contains("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION");
                            continue;
                        }

                        if (fieldName.Contains("REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("REQUIRED)");
                            continue;
                        }

                        if (fieldName.Contains("MICHELLE’S LAW DISCLOSURE"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MICHELLE’S LAW DISCLOSURE");
                            continue;
                        }
                        if (fieldName.Contains("(USE ONLY IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(USE ONLY IF APPLICABLE)");
                            continue;
                        }
                        if (fieldName.Contains("Receive Information about Your Plan and Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Receive Information about Your Plan and Benefits");
                            continue;
                        }
                        if (fieldName.Contains("Continue Group Health Plan Coverage"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Continue Group Health Plan Coverage");
                            continue;
                        }
                        if (fieldName.Contains("Prudent Actions by Plan Fiduciaries"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Prudent Actions by Plan Fiduciaries");
                            continue;
                        }
                        if (fieldName.Contains("Enforce your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Enforce your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Assistance with your Questions"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Assistance with your Questions");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("Your Information. Your Rights. Our Responsibilities."))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.Range.Font.Bold = 1;
                            oWordApp.Selection.TypeText("Your Information. Your Rights. Our Responsibilities.");
                            continue;
                        }
                        if (fieldName.Contains("Your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Your Choices"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Choices");
                            continue;
                        }
                        if (fieldName.Contains("Our Uses and Disclosures"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Our Uses and Disclosures");
                            continue;
                        }
                        if (fieldName.Contains("Changes to the Terms of this Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Changes to the Terms of this Notice");
                            continue;
                        }
                        if (fieldName.Contains("Other Instructions for Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Other Instructions for Notice");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("PART A: General Information"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART A: General Information");
                            continue;
                        }
                        if (fieldName.Contains("What is the Health Insurance Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("What is the Health Insurance Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Can I Save Money on my Health Insurance Premiums in the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Can I Save Money on my Health Insurance Premiums in the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("How Can I Get More Information?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("How Can I Get More Information?");
                            continue;
                        }
                        if (fieldName.Contains("PART B: Information About Health Coverage Offered by Your Employer"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART B: Information About Health Coverage Offered by Your Employer");
                            continue;
                        }
                        if (fieldName.Contains("HealthCare.gov"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("HealthCare.gov");
                            continue;
                        }

                        if (fieldName.Contains("CREDITABLE COVERAGE"))
                        {
                            if (creditableCoverageIndex > 0)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);

                                if (creditableCoverageIndex == 1)
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11.docx"), missing, true, missing, missing);
                                    }
                                }
                                else if (creditableCoverageIndex == 2)
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11.docx"), missing, true, missing, missing);
                                    }
                                }
                                else if (creditableCoverageIndex == 3)
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11c - Creditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11c - Notice of Creditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                    }
                                }
                                else if (creditableCoverageIndex == 4)
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11d - Noncreditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11d - Notice of Noncreditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                    }
                                }
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Notice of Privacy Practices"))
                        {
                            if (chkAnualNotice.Items[9].Selected == true)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);

                                if (summaryName == "Enrollment Summary" || summaryName == "Summary Highlight" || summaryName == "Value Summary" || summaryName == "Enrollment Guide")
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices_EnrolmentGuide.doc"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                    }
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                }
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (index > -1)
                        {
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("\f");
                                if (isSelected == true)
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText("CONTACT INFORMATION");
                                }
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Name);
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Address);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Email);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Phone.Count == 0)
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    StringBuilder Phone = new StringBuilder(); ;
                                    for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                    {
                                        Phone.Append(ContactList[index].Phone[i]);
                                        if (ContactList[index].Phone[i] != string.Empty)
                                        {
                                            if (Phone.ToString().Contains("_"))
                                            {
                                                Phone.Replace("_", "-");
                                            }
                                            Phone.Append("\n");
                                        }
                                    }
                                    oWordApp.Selection.TypeText(Phone.ToString());
                                }
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Postion == " ")
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(ContactList[index].Postion);
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("MARKETPLACE COVERAGE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Delete();
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Below function is called for writing the fields present inside the Cover page
        public void WriteFieldsForCoverPage(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DropDownList ddlOffice, DataTable OfficeTable)
        {
            int iTotalFields = 0;
            BPBusiness bp = new BPBusiness();
            DataTable Office = OfficeTable;

            try
            {
                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();


                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Company Logo"))
                        {
                            DataRow[] FoundRow = null;
                            if (ddlOffice.SelectedIndex > 0)
                            {
                                FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                if (FoundRow.Count() > 0)
                                {

                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                    object missing = System.Type.Missing;
                                    Word.Range rng = rngFieldCode;
                                    rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                    string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                    rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                    continue;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_Field_Header(Word.Document oWordDoc, Word.Application oWordApp, string year, string selectedColor = "Grey")
        {
            Word.WdColor wdColor_font = font_color(selectedColor);

            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Fields fields = header.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("MedicalPlanEffDateYear"))
                            {
                                field.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(year);
                                continue;
                            }

                            if (fieldName.Contains("BENEFITS AT A GLANCE"))
                            {
                                field.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("BENEFITS AT A GLANCE");
                                continue;
                            }
                        }
                    }
                }
            }

        }

        // This function is used to get the User Details from the windows ActiveDirectory for the logged in User      
        public void GetUserDetails()
        {
            BPBusiness bp = new BPBusiness();
            try
            {
                string DisplayName = string.Empty;
                string Department = string.Empty;
                string physicalDeliveryOfficeName = string.Empty;
                string company = string.Empty;

                string windowsLogin = Page.User.Identity.Name;

                //Normally if the domain is present you get a string like DOMAINNAME\username, remove the domain
                int hasDomain = windowsLogin.IndexOf(@"\");
                if (hasDomain > 0)
                {
                    windowsLogin = windowsLogin.Remove(0, hasDomain + 1);
                } //end if 

                DirectoryEntry de = new DirectoryEntry("LDAP://USII");
                de.AuthenticationType = AuthenticationTypes.Secure;

                DirectorySearcher deSearch = new DirectorySearcher();
                deSearch.SearchRoot = de;
                //SearchResultCollection results;
                SearchResult results;
                deSearch.PropertiesToLoad.Add("displayname");//first name
                deSearch.PropertiesToLoad.Add("userWorkstations");//first name
                deSearch.PropertiesToLoad.Add("department");//first name
                deSearch.PropertiesToLoad.Add("physicalDeliveryOfficeName");//first name
                deSearch.PropertiesToLoad.Add("company");//first name
                //Search the USER object in the hierachy                   
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + loginUserName + "))";
                // deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "mayur.darshale" + "))";
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "rickey.brown" + "))";
                //deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + "laurie.lim" + "))";
                deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + windowsLogin + "))";
                deSearch.SearchScope = System.DirectoryServices.SearchScope.Subtree;

                // Session for User Login Name
                Session["UserLoginName"] = windowsLogin;
                //Add the attributes which we want to return to the search result          

                results = deSearch.FindOne();

                if ((results != null))
                {
                    DisplayName = "";
                    Department = "";
                    physicalDeliveryOfficeName = "";
                    company = "";

                    if (results.Properties.Contains("displayname"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["displayname"][0]))
                        {
                            DisplayName = (String)results.Properties["displayname"][0];
                            Session["UserName"] = DisplayName;
                        }
                    }
                    if (results.Properties.Contains("department"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["department"][0]))
                        {
                            Department = (String)results.Properties["department"][0];
                            Session["Department"] = Department;
                        }
                    }
                    if (results.Properties.Contains("physicalDeliveryOfficeName"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["physicalDeliveryOfficeName"][0]))
                        {
                            physicalDeliveryOfficeName = (String)results.Properties["physicalDeliveryOfficeName"][0];
                            Session["Office"] = physicalDeliveryOfficeName;
                        }
                    }
                    if (results.Properties.Contains("company"))
                    {
                        if (!string.IsNullOrEmpty((String)results.Properties["company"][0]))
                        {
                            company = (String)results.Properties["company"][0];
                            Session["Region"] = company;
                        }
                    }
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        // Function to get the Office and Region name for the selected client
        public string GetOfficeAndRegionNames(int AccountNumber, string sessionId, out string RegionName)
        {
            DataTable OfficeDt = new DataTable();
            SummaryDetail sd = new SummaryDetail();
            string officeName = string.Empty;
            RegionName = string.Empty;

            try
            {
                OfficeDt = sd.GetOfficeDetail(AccountNumber, sessionId);
                if (OfficeDt.Rows.Count > 0)
                {
                    officeName = Convert.ToString(OfficeDt.Rows[0]["OfficeName"]);
                    RegionName = Convert.ToString(OfficeDt.Rows[0]["RegionName"]);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return officeName;
        }

        public string GetAccountMainPhoneNumber(DataSet AccountDS)
        {
            string MainPhone = string.Empty;
            try
            {
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    break;
                                }
                            }
                        }
                    }
                }
                return MainPhone;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        #region Colors
        public Word.WdColor textbox_color(string color)
        {
            Color table_textbox = Color.FromArgb(79, 128, 189);
            switch (color)
            {
                case "Blue": table_textbox = Color.FromArgb(79, 128, 189); break;
                case "Green": table_textbox = Color.FromArgb(21, 95, 33); break;
                case "Black": table_textbox = Color.FromArgb(0, 0, 0); break;
                case "Maroon": table_textbox = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": table_textbox = Color.FromArgb(9, 84, 155); break;
                case "True Blue": table_textbox = Color.FromArgb(0, 0, 255); break;
                case "Dark Green": table_textbox = Color.FromArgb(0, 102, 0); break;
                case "Bright Green": table_textbox = Color.FromArgb(0, 153, 0); break;
                case "Olive Green": table_textbox = Color.FromArgb(131, 141, 9); break;
                case "Dark Red": table_textbox = Color.FromArgb(128, 0, 0); break;
                case "Red": table_textbox = Color.FromArgb(204, 0, 0); break;
                case "Mustard": table_textbox = Color.FromArgb(212, 160, 15); break;
                case "Orange": table_textbox = Color.FromArgb(255, 165, 0); break;
                case "Purple": table_textbox = Color.FromArgb(102, 0, 102); break;
                case "Light Brown": table_textbox = Color.FromArgb(153, 102, 51); break;
                case "Dark Brown": table_textbox = Color.FromArgb(102, 51, 0); break;
                case "Gray": table_textbox = Color.FromArgb(119, 119, 119); break;
                default: table_textbox = Color.FromArgb(105, 29, 29); break;
            }
            int rgb_textbox = ColorTranslator.ToOle(table_textbox);
            Word.WdColor wdColor_textbox = (Word.WdColor)rgb_textbox;
            return wdColor_textbox;
        }

        public Word.WdColor border_color(string color)
        {
            Color border = Color.FromArgb(79, 128, 189);

            switch (color)
            {
                case "Blue": border = Color.FromArgb(79, 128, 189); break;
                case "Green": border = Color.FromArgb(21, 95, 33); break;
                case "Black": border = Color.FromArgb(0, 0, 0); break;
                case "Maroon": border = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": border = Color.FromArgb(9, 84, 155); break;
                case "True Blue": border = Color.FromArgb(0, 0, 255); break;
                case "Dark Green": border = Color.FromArgb(0, 102, 0); break;
                case "Bright Green": border = Color.FromArgb(0, 153, 0); break;
                case "Olive Green": border = Color.FromArgb(131, 141, 9); break;
                case "Dark Red": border = Color.FromArgb(128, 0, 0); break;
                case "Red": border = Color.FromArgb(204, 0, 0); break;
                case "Mustard": border = Color.FromArgb(212, 160, 15); break;
                case "Orange": border = Color.FromArgb(255, 165, 0); break;
                case "Purple": border = Color.FromArgb(102, 0, 102); break;
                case "Light Brown": border = Color.FromArgb(153, 102, 51); break;
                case "Dark Brown": border = Color.FromArgb(102, 51, 0); break;
                case "Gray": border = Color.FromArgb(119, 119, 119); break;
                default: border = Color.FromArgb(105, 29, 29); break;
            }
            int rgb_border = ColorTranslator.ToOle(border);
            Word.WdColor wdColor_border = (Word.WdColor)rgb_border;
            return wdColor_border;
        }

        public Word.WdColor font_color(string color)
        {
            Color font = Color.FromArgb(0, 68, 123);
            switch (color)
            {
                case "Blue": font = Color.FromArgb(0, 68, 123); break;
                case "Green": font = Color.FromArgb(14, 62, 22); break;
                case "Black": font = Color.FromArgb(38, 38, 38); break;
                case "Maroon": font = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": font = Color.FromArgb(6, 58, 106); break;
                case "True Blue": font = Color.FromArgb(0, 0, 192); break;
                case "Dark Green": font = Color.FromArgb(0, 66, 0); break;
                case "Bright Green": font = Color.FromArgb(0, 96, 0); break;
                case "Olive Green": font = Color.FromArgb(63, 68, 4); break;
                case "Dark Red": font = Color.FromArgb(84, 0, 0); break;
                case "Red": font = Color.FromArgb(150, 0, 0); break;
                case "Mustard": font = Color.FromArgb(118, 89, 8); break;
                case "Orange": font = Color.FromArgb(172, 94, 0); break;
                case "Purple": font = Color.FromArgb(100, 9, 125); break;
                case "Light Brown": font = Color.FromArgb(81, 54, 27); break;
                case "Dark Brown": font = Color.FromArgb(84, 42, 0); break;
                case "Gray": font = Color.FromArgb(84, 84, 84); break;
                default: font = Color.FromArgb(0, 68, 123); break;
            }

            int rgb_font = ColorTranslator.ToOle(font);
            Word.WdColor wdColor_font = (Word.WdColor)rgb_font;
            return wdColor_font;
        }

        public Word.WdColor cell_color(string color)
        {
            Color table_cell = Color.FromArgb(211, 223, 238);

            switch (color)
            {
                case "Blue": table_cell = Color.FromArgb(211, 223, 238); break;
                case "Green": table_cell = Color.FromArgb(192, 239, 175); break;
                case "Black": table_cell = Color.FromArgb(217, 217, 217); break;
                case "Maroon": table_cell = Color.FromArgb(237, 177, 177); break;

                case "USI Blue": table_cell = Color.FromArgb(140, 197, 248); break;
                case "True Blue": table_cell = Color.FromArgb(163, 197, 251); break;
                case "Dark Green": table_cell = Color.FromArgb(0, 188, 0); break;
                case "Bright Green": table_cell = Color.FromArgb(121, 255, 121); break;
                case "Olive Green": table_cell = Color.FromArgb(223, 247, 147); break;
                case "Dark Red": table_cell = Color.FromArgb(255, 125, 125); break;
                case "Red": table_cell = Color.FromArgb(255, 143, 143); break;
                case "Mustard": table_cell = Color.FromArgb(245, 210, 11); break;
                case "Orange": table_cell = Color.FromArgb(255, 199, 97); break;
                case "Purple": table_cell = Color.FromArgb(224, 183, 255); break;
                case "Light Brown": table_cell = Color.FromArgb(217, 178, 139); break;
                case "Dark Brown": table_cell = Color.FromArgb(200, 144, 88); break;
                case "Gray": table_cell = Color.FromArgb(196, 196, 196); break;
                default: table_cell = Color.FromArgb(211, 223, 238); break;
            }

            int rgb_cell = ColorTranslator.ToOle(table_cell);
            Word.WdColor wdColor_cell = (Word.WdColor)rgb_cell;

            return wdColor_cell;
        }
        # endregion
        #region Adding Image
        public Word.InlineShape PictureMethod(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlImageOption, Word.Range rngFieldCode, string imgName, float Width, float Height)
        {
            Word.InlineShape shape = null;
            try
            {
                string path = Server.MapPath("~/Files/BenefitSummary/Images/Pictures/New Benefit Summaries/" + Convert.ToString(ddlImageOption.SelectedItem.Text) + "/" + imgName + ".jpg");
                if (File.Exists(path))
                {
                    object missing = System.Type.Missing;
                    Word.Range r = oWordDoc.Range();
                    r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                    shape = r.InlineShapes.AddPicture(path, false, true);
                    shape.Width = oWordApp.InchesToPoints(Width);
                    shape.Height = oWordApp.InchesToPoints(Height);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return shape;
        }
        #endregion

        public void GetPlanContribution(DataTable PremiumTable, int planNumber, ref DataTable PremiumTableWritePlan)
        {
            try
            {
                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                {
                    int flag = 0;
                    if (PremiumTable.Rows[i][1].ToString() == "8")
                    {
                        for (int c = 0; c < PremiumTableWritePlan.Rows.Count; c++)
                        {
                            if ((PremiumTableWritePlan.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString()) && (PremiumTableWritePlan.Rows[c][7].ToString() == PremiumTable.Rows[i][7].ToString()))
                            {
                                PremiumTableWritePlan.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                flag = 1;
                                break;
                            }
                        }
                        if (flag == 0)
                        {
                            DataRow dr = PremiumTableWritePlan.NewRow();
                            dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                            dr["Plan1_Rate"] = "";
                            dr["Plan2_Rate"] = "";
                            dr["Plan3_Rate"] = "";
                            dr["Plan4_Rate"] = "";
                            dr["Plan5_Rate"] = "";
                            dr["Plan6_Rate"] = "";
                            dr["Plan" + planNumber + "_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                            dr["Contribution_Id"] = PremiumTable.Rows[i][7].ToString();
                            dr["RateId"] = PremiumTable.Rows[i][1].ToString();
                            dr["contributionValueID"] = PremiumTable.Rows[i][4].ToString();
                            dr["PlanNumber"] = PremiumTable.Rows[i][11].ToString();
                            PremiumTableWritePlan.Rows.Add(dr);
                        }
                    }
                    else
                    {
                        for (int c = 0; c < PremiumTableWritePlan.Rows.Count; c++)
                        {
                            if (PremiumTableWritePlan.Rows[c][7].ToString() == PremiumTable.Rows[i][7].ToString())
                            {
                                if (PremiumTableWritePlan.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWritePlan.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                {
                                    PremiumTableWritePlan.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                    flag = 1;
                                    break;
                                }
                            }
                        }
                        if (flag == 0)
                        {
                            DataRow dr = PremiumTableWritePlan.NewRow();
                            dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                            dr["Plan1_Rate"] = "";
                            dr["Plan2_Rate"] = "";
                            dr["Plan3_Rate"] = "";
                            dr["Plan4_Rate"] = "";
                            dr["Plan5_Rate"] = "";
                            dr["Plan6_Rate"] = "";
                            dr["Plan" + planNumber + "_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                            dr["Contribution_Id"] = PremiumTable.Rows[i][7].ToString();
                            dr["RateId"] = PremiumTable.Rows[i][1].ToString();
                            dr["contributionValueID"] = PremiumTable.Rows[i][4].ToString();
                            dr["PlanNumber"] = PremiumTable.Rows[i][11].ToString();
                            PremiumTableWritePlan.Rows.Add(dr);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #region Write Contributionvalues functions- Approch1
        #region WriteMedicalContributionValues function
        // Function to write Medical plan values
        // This function is used to show the contribution values in a format of 
        // Row - Contribution name as (Employee, Employee & Spouse, Employee & Child etc.)
        // Column - Plan Name and contribution name selected from dropdown list
        public void WriteMedicalContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int medicalTableNo, ref int columnNum, DataTable PremiumTableWriteMedical, int colNumber, ref ArrayList arrContributionID, string strDentalPlan_Contri1, string strMedicalPlan_Contri2, ref int MedicalTableRowCounter)
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWriteMedical.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteMedical.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[medicalTableNo].Rows.Add();
                        oWordDoc.Tables[medicalTableNo].Cell(MedicalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString(); // Row Desc
                        MedicalTableRowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWriteMedical.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;

                        if (isFirstContributionTaken == false)
                        {
                            oWordDoc.Tables[medicalTableNo].Cell(1, columnNum).Range.Text = strDentalPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        else
                        {
                            oWordDoc.Tables[medicalTableNo].Cell(1, columnNum).Range.Text = strMedicalPlan_Contri2;
                        }
                    }

                    for (int rowNum = 1; rowNum <= oWordDoc.Tables[medicalTableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[medicalTableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[medicalTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteMedical.Rows[i]["RateHeader"].ToString())
                            {
                                oWordDoc.Tables[medicalTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteMedical.Rows[i][colNumber].ToString(); //Contri Cost
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        #region WriteDentalContributionValues function
        // Function to write Dental plan values
        public void WriteDentalContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int dentalTableNo, ref int columnNum, DataTable PremiumTableWriteDental, int colNumber, ref ArrayList arrContributionID, string strDentalPlan_Contri1, string strDentalPlan_Contri2, ref int DentalTableRowCounter)
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWriteDental.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteDental.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[dentalTableNo].Rows.Add();
                        oWordDoc.Tables[dentalTableNo].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString(); // Row Desc
                        DentalTableRowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWriteDental.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;

                        if (isFirstContributionTaken == false)
                        {
                            oWordDoc.Tables[dentalTableNo].Cell(1, columnNum).Range.Text = strDentalPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        else
                        {
                            oWordDoc.Tables[dentalTableNo].Cell(1, columnNum).Range.Text = strDentalPlan_Contri2;
                        }
                    }

                    for (int rowNum = 1; rowNum <= oWordDoc.Tables[dentalTableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[dentalTableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[dentalTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteDental.Rows[i]["RateHeader"].ToString())
                            {
                                oWordDoc.Tables[dentalTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteDental.Rows[i][colNumber].ToString(); //Contri Cost
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        #region WriteVisionContributionValues function
        // Function to write Vision plan values
        public void WriteVisionContributionValues(Word.Document oWordDoc, Word.Application oWordApp, int visionTableNo, ref int columnNum, DataTable PremiumTableWriteVision, int colNumber, ref ArrayList arrContributionID, string strVisionPlan_Contri1, string strVisionPlan_Contri2, ref int VisionTableRowCounter)
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWriteVision.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteVision.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[visionTableNo].Rows.Add();
                        oWordDoc.Tables[visionTableNo].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString(); // Row Desc
                        VisionTableRowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWriteVision.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;

                        if (isFirstContributionTaken == false)
                        {
                            oWordDoc.Tables[visionTableNo].Cell(1, columnNum).Range.Text = strVisionPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        else
                        {
                            oWordDoc.Tables[visionTableNo].Cell(1, columnNum).Range.Text = strVisionPlan_Contri2;
                        }
                    }

                    for (int rowNum = 1; rowNum <= oWordDoc.Tables[visionTableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[visionTableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[visionTableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteVision.Rows[i]["RateHeader"].ToString())
                            {
                                oWordDoc.Tables[visionTableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWriteVision.Rows[i][colNumber].ToString(); //Contri Cost
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
        #endregion Contribution values Approch1

        #region Write ContributionValues function - Approach 1
        // This function is used to show the contribution values in a format of 
        // Row - Contribution name as (Employee, Employee & Spouse, Employee & Child etc.)
        // Column - Contribution values
        public void WriteContributionValues_Approach_1(Word.Document oWordDoc, Word.Application oWordApp, int TableNo, ref int columnNum, DataTable PremiumTableWrite, int colNumber, ref ArrayList arrContributionID, string strPlan_Contri1, string strPlan_Contri2, ref int TableRowCounter, ref int RowCounter, int contributionId_1, int contributionId_2, string SummaryName = "", string planheader = "", string contribution_Frequency = "")
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWrite.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWrite.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWrite.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[TableNo].Rows.Add();
                        oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Font.Color = WdColor.wdColorWhite;
                        oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = PremiumTableWrite.Rows[i][0].ToString(); // Row Desc
                        RowCounter++;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWrite.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        columnNum++;


                        // Check whether the PreimumTable is having values for the contribution selected
                        var contri_1 = (from n in PremiumTableWrite.AsEnumerable()
                                        where n.Field<int>("Contribution_Id") == contributionId_1
                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                        var contri_2 = (from n in PremiumTableWrite.AsEnumerable()
                                        where n.Field<int>("Contribution_Id") == contributionId_2
                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                        // If any of the contribution selected is not having the value then do not write that contribution in the heading
                        // and column for that contribution will be deleted
                        if (contri_1 == 0)
                        {
                            strPlan_Contri1 = "";
                        }
                        if (contri_2 == 0)
                        {
                            strPlan_Contri2 = "";
                        }

                        // If the contribution value 1 is available then 
                        if (isFirstContributionTaken == false && !string.IsNullOrEmpty(strPlan_Contri1))
                        {
                            //oWordDoc.Tables[TableNo].Rows.Add();
                            oWordDoc.Tables[TableNo].Cell(TableRowCounter, columnNum).Range.Text = strPlan_Contri1;
                            isFirstContributionTaken = true;
                        }
                        // If the contribution value 2 is available then 
                        else if (!string.IsNullOrEmpty(strPlan_Contri2))
                        {
                            //if (isFirstContributionTaken == true)
                            //{
                            //    //oWordDoc.Tables[TableNo].Rows.Add();
                            //    //RowCounter++;
                            //}

                            oWordDoc.Tables[TableNo].Cell(TableRowCounter, columnNum).Range.Text = strPlan_Contri2;
                        }
                    }

                    for (int rowNum = TableRowCounter; rowNum <= oWordDoc.Tables[TableNo].Rows.Count; rowNum++)
                    {
                        for (int colNum = 1; colNum <= oWordDoc.Tables[TableNo].Columns.Count; colNum++)
                        {
                            if (oWordDoc.Tables[TableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWrite.Rows[i]["RateHeader"].ToString())
                            {
                                //if (!string.IsNullOrEmpty(oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "")))
                                //{
                                //    oWordDoc.Tables[TableNo].Cell(rowNum, columnNum).Range.Text = oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWrite.Rows[i][colNumber].ToString();
                                //}
                                //else
                                //{
                                oWordDoc.Tables[TableNo].Cell(rowNum, columnNum).Range.Text = PremiumTableWrite.Rows[i][colNumber].ToString(); //Contri Cost
                                oWordDoc.Tables[TableNo].Cell(rowNum, columnNum).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                                //}
                            }
                        }
                    }
                }

                //// For deleting the last empty rows
                //for (int rowNum = 2; rowNum <= oWordDoc.Tables[TableNo].Rows.Count; rowNum++)
                //{
                //    if (string.IsNullOrEmpty(oWordDoc.Tables[TableNo].Cell(rowNum, 1).Range.Text.ToString()) || oWordDoc.Tables[TableNo].Cell(rowNum, 1).Range.Text == "\r\a")
                //    {
                //        oWordDoc.Tables[TableNo].Rows[rowNum].Delete();
                //        rowNum = rowNum - 1;
                //    }
                //}

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        #region Write ContributionValues function - Approach 2
        // This function is used to show the contribution values in a format of 
        // Row - Contribution values
        // Column - Contribution name as (Employee, Employee & Spouse, Employee & Child etc.)
        public void WriteContributionValues_Approach_2(Word.Document oWordDoc, Word.Application oWordApp, int TableNo, ref int columnNum, DataTable PremiumTableWrite, int colNumber, ref ArrayList arrContributionID, string strPlan_Contri1, string strPlan_Contri2, ref int TableRowCounter, ref int RowCounter, int contributionId_1, int contributionId_2, string SummaryName = "", string planheader = "")
        {
            try
            {
                RowCounter++;
                int newRowCounter = RowCounter + 1;
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int i = 0; i < PremiumTableWrite.Rows.Count; i++)
                {
                    if (!arrContributionID.Contains(PremiumTableWrite.Rows[i]["RateId"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWrite.Rows[i]["RateId"].ToString());
                        oWordDoc.Tables[TableNo].Columns.Add();
                        oWordDoc.Tables[TableNo].Columns[oWordDoc.Tables[TableNo].Columns.Count].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;

                        oWordDoc.Tables[TableNo].Cell(1, oWordDoc.Tables[TableNo].Columns.Count).Range.Text = PremiumTableWrite.Rows[i][0].ToString(); // Row Desc
                        oWordDoc.Tables[TableNo].Cell(1, oWordDoc.Tables[TableNo].Columns.Count).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                    }

                    currentPlanNo = Convert.ToInt32(PremiumTableWrite.Rows[i]["Contribution_Id"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;

                        //columnNum++;

                        // Check whether the PreimumTable is having values for the contribution selected
                        var contri_1 = (from n in PremiumTableWrite.AsEnumerable()
                                        where n.Field<int>("Contribution_Id") == contributionId_1
                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                        var contri_2 = (from n in PremiumTableWrite.AsEnumerable()
                                        where n.Field<int>("Contribution_Id") == contributionId_2
                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                        // If any of the contribution selected is not having the value then do not write that contribution in the heading
                        // and column for that contribution will be deleted
                        if (contri_1 == 0)
                        {
                            strPlan_Contri1 = "";
                        }
                        if (contri_2 == 0)
                        {
                            strPlan_Contri2 = "";
                        }

                        // If the contribution value 1 is available then 
                        if (isFirstContributionTaken == false && !string.IsNullOrEmpty(strPlan_Contri1))
                        {
                            oWordDoc.Tables[TableNo].Rows.Add();
                            if (SummaryName == "Value Summary")
                            {
                                oWordDoc.Tables[TableNo].Rows.Add();
                            }

                            if (SummaryName == "Value Summary")
                            {
                                oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = planheader;
                                oWordDoc.Tables[TableNo].Cell(newRowCounter, 1).Range.Text = strPlan_Contri1;
                            }
                            else
                            {
                                oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = strPlan_Contri1;
                            }
                            isFirstContributionTaken = true;
                        }
                        // If the contribution value 2 is available then 
                        else if (!string.IsNullOrEmpty(strPlan_Contri2))
                        {
                            if (isFirstContributionTaken == true)
                            {
                                oWordDoc.Tables[TableNo].Rows.Add();
                                if (SummaryName == "Value Summary")
                                {
                                    oWordDoc.Tables[TableNo].Rows.Add();
                                    // RowCounter++;
                                    newRowCounter = newRowCounter + 1;
                                    oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = planheader;
                                }
                                RowCounter++;
                            }
                            else if (isFirstContributionTaken == false && SummaryName == "Value Summary")
                            {
                                oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = planheader;
                            }
                            if (SummaryName == "Value Summary")
                            {
                                //oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = planheader;
                                oWordDoc.Tables[TableNo].Cell(newRowCounter, 1).Range.Text = strPlan_Contri2;
                            }
                            else
                            {
                                oWordDoc.Tables[TableNo].Cell(RowCounter, 1).Range.Text = strPlan_Contri2;
                            }
                        }
                    }

                    if (SummaryName == "Value Summary")
                    {
                        for (int rowNum = 1; rowNum <= oWordDoc.Tables[TableNo].Rows.Count; rowNum++)
                        {
                            for (int colNum = 1; colNum <= oWordDoc.Tables[TableNo].Columns.Count; colNum++)
                            {
                                if (oWordDoc.Tables[TableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWrite.Rows[i]["RateHeader"].ToString())
                                {
                                    //if (!string.IsNullOrEmpty(oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "")))
                                    //{

                                    //    oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text = oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWrite.Rows[i][colNumber].ToString();
                                    //}
                                    //else
                                    //{
                                    //oWordDoc.Tables[TableNo].Cell(newRowCounter, 1).Range.Text = "Employee Cost";
                                    oWordDoc.Tables[TableNo].Cell(newRowCounter, colNum).Range.Text = PremiumTableWrite.Rows[i][colNumber].ToString(); //Contri Cost
                                    oWordDoc.Tables[TableNo].Cell(newRowCounter, colNum).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;

                                    //}
                                    // break;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int rowNum = 1; rowNum <= oWordDoc.Tables[TableNo].Rows.Count; rowNum++)
                        {
                            for (int colNum = 1; colNum <= oWordDoc.Tables[TableNo].Columns.Count; colNum++)
                            {
                                if (oWordDoc.Tables[TableNo].Cell(rowNum, colNum).Range.Text.Replace("\r\a", "") == PremiumTableWrite.Rows[i]["RateHeader"].ToString())
                                {
                                    if (!string.IsNullOrEmpty(oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "")))
                                    {
                                        oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text = oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWrite.Rows[i][colNumber].ToString();
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.Text = PremiumTableWrite.Rows[i][colNumber].ToString(); //Contri Cost
                                        oWordDoc.Tables[TableNo].Cell(RowCounter, colNum).Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;

                                    }
                                    // break;
                                }
                            }
                        }
                    }

                }
                if (SummaryName == "Value Summary" && PremiumTableWrite.Rows.Count > 0)
                {
                    RowCounter = newRowCounter;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        #endregion

        // Function to get PlanContact details from the Screen - 3 using original dtPlanContactInfo and PlanTable
        public DataTable GetDataTableFromGridView_ForContactDetails(GridView dtg, DataTable PlanTable, DataTable dtPlanContactInfo)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            string carriername = "";
            string plantype = "";
            string ProductTypeDesc = "";
            string ProductId = "";

            string carrier = string.Empty;
            string description_Policy = string.Empty;
            string website_phone = string.Empty;

            // add the columns to the datatable            
            dt.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("ContactEmail", typeof(String)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_FirstName", typeof(string)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_LastName", typeof(string)));
            dt.Columns.Add(new System.Data.DataColumn("Contact_Address", typeof(string)));

            //  add each of the data rows to the table
            foreach (GridViewRow row in dtg.Rows)
            {
                Label lblName = (Label)row.FindControl("lblName");
                DropDownList ddlItemPlanContact = (DropDownList)row.FindControl("ddlItemPlanContact");
                Label lblProductID = (Label)row.FindControl("lblProductID");

                if (ddlItemPlanContact.SelectedItem.Text != "Select" && ddlItemPlanContact.SelectedItem.Text != "None")
                {
                    dr = dt.NewRow();
                    dr[0] = Convert.ToString(lblName.Text).Replace(" ", "");
                    dr[1] = Convert.ToString(ddlItemPlanContact.SelectedItem.Value);
                    dr[2] = Convert.ToString(ddlItemPlanContact.SelectedItem.Text);
                    dr[4] = Convert.ToString(lblProductID.Text);

                    var planContactPhone = (from n in dtPlanContactInfo.AsEnumerable()
                                            where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                            select n.Field<string>("ContactWorkPhone")).FirstOrDefault();

                    dr[3] = Convert.ToString(planContactPhone);

                    var planEmail = (from n in dtPlanContactInfo.AsEnumerable()
                                     where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                     select n.Field<string>("ContactEmail")).FirstOrDefault();

                    var firstName = (from n in dtPlanContactInfo.AsEnumerable()
                                     where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                     select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                    var lastName = (from n in dtPlanContactInfo.AsEnumerable()
                                    where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                    select n.Field<string>("Contact_LastName")).FirstOrDefault();

                    var address = (from n in dtPlanContactInfo.AsEnumerable()
                                   where n.Field<int>("ContactId") == Convert.ToInt32(ddlItemPlanContact.SelectedItem.Value)
                                   select n.Field<string>("Contact_Address")).FirstOrDefault();

                    dr[5] = Convert.ToString(planEmail);
                    dr[6] = Convert.ToString(firstName);
                    dr[7] = Convert.ToString(lastName);
                    dr[8] = Convert.ToString(address);

                    dt.Rows.Add(dr);
                }
            }

            DataTable dtDetailContacts = new DataTable();
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("PlanName", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("PlanType", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ProductTypeDesc", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactName", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactPhoneNumber", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactEmail", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ContactId", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("ProductId", typeof(String)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_FirstName", typeof(string)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_LastName", typeof(string)));
            dtDetailContacts.Columns.Add(new System.Data.DataColumn("Contact_Address", typeof(string)));

            for (int i = 0; i < PlanTable.Rows.Count; i++)
            {
                dr = dtDetailContacts.NewRow();

                if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                {
                    ProductId = PlanTable.Rows[i]["ProductId"].ToString();
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    carriername = PlanTable.Rows[i]["Carrier"].ToString();
                    ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();

                    var planEmail = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("ContactEmail")).FirstOrDefault();
                    var planContactPhone = (from n in dt.AsEnumerable()
                                            where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                            select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();
                    var planContactName = (from n in dt.AsEnumerable()
                                           where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                           select n.Field<string>("ContactName")).FirstOrDefault();
                    var ContactId = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("ContactId")).FirstOrDefault();

                    var firstName = (from n in dt.AsEnumerable()
                                     where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                     select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                    var lastName = (from n in dt.AsEnumerable()
                                    where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                    select n.Field<string>("Contact_LastName")).FirstOrDefault();

                    var address = (from n in dt.AsEnumerable()
                                   where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                   select n.Field<string>("Contact_Address")).FirstOrDefault();

                    dr[0] = Convert.ToString(carriername);
                    dr[1] = Convert.ToString(plantype);
                    dr[2] = Convert.ToString(ProductTypeDesc);
                    dr[3] = Convert.ToString(planContactName);
                    dr[4] = Convert.ToString(planContactPhone);
                    dr[5] = Convert.ToString(planEmail);

                    dr[6] = Convert.ToString(ContactId);
                    dr[7] = Convert.ToString(ProductId);
                    dr[8] = Convert.ToString(firstName);
                    dr[9] = Convert.ToString(lastName);
                    dr[10] = Convert.ToString(address);
                    dtDetailContacts.Rows.Add(dr);
                }
            }

            return dtDetailContacts;
        }

        // Overloaded function to get the Unique carrier names from the list
        // This function accepts the two parameters (1. Seperator and 2. ParamList)
        // The resulting output is a string variable which is based on the carrier name and seperated by seperator parameter
        public string GetCarrierList(string seperator, params string[] carrierlist)
        {
            string carrierName = string.Empty;
            ArrayList arrCarrierlist = new ArrayList();

            foreach (string item in carrierlist)
            {
                if (!string.IsNullOrEmpty(item))
                {
                    if (!arrCarrierlist.Contains(item))
                    {
                        arrCarrierlist.Add(item);
                    }
                }
            }

            foreach (string carName in arrCarrierlist)
            {
                if (carrierName.Length == 0)
                {
                    carrierName = carName;
                }
                else
                {
                    carrierName = carrierName + seperator + carName;
                }
            }

            return carrierName;
        }

        // Function to return the list unique Carrier names
        public void GetCarrierList(string carriername, ref List<string> carrierlist)
        {
            if (!carrierlist.Contains(carriername.Trim()))
            {
                carrierlist.Add(carriername);
            }
        }

        #region WriteMedicalContributionValues for PowerPoint reports function

        // Function to write Medical plan values
        // This function is used to show the contribution values in a format of 
        // Row - Contribution name as (Employee, Employee & Spouse, Employee & Child etc.)
        // Column - Plan Name and contribution name selected from dropdown list
        public void WriteContributionValuesFor_PPT(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, string TableName, DataTable PremiumTableWrite, ref ArrayList arrContributionID, string strPlan_Contri1, string strPlan_Contri2, ref int TableRowCounter, int slideNumber, int colNumber, ref int uniqeColumnNum, int contributionId_1, int contributionId_2, string Frequency_Text_To_Find = "", string Frequency_Of_Contribution = "")
        {
            try
            {
                int currentPlanNo = 0;
                int oldPlanNo = 0;
                bool isFirstContributionTaken = false;

                for (int k = 0; k < PremiumTableWrite.Rows.Count; k++)
                {
                    objSlides = objPres.Slides;
                    // Iterate through each slide for putting the attribute values for respective fields
                    for (int i = 1; i <= objSlides.Count; i++)
                    {
                        objShapes = objSlides[i].Shapes;

                        //if (objSlides[i].SlideNumber == slideNumber)
                        //{
                        for (int j = 1; j <= objShapes.Count; j++)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                if (objShapes[j].Name.ToString().Equals(TableName))
                                {
                                    // create ArrayList for unique contribution heading (i.e. Employee / Employee & Spouse / Employee & Child etc.)
                                    if (!arrContributionID.Contains(PremiumTableWrite.Rows[k]["RateId"].ToString()))
                                    {
                                        arrContributionID.Add(PremiumTableWrite.Rows[k]["RateId"].ToString());

                                        objShapes[j].Table.Rows.Add();
                                        objShapes[j].Table.Cell(TableRowCounter, 1).Shape.TextFrame.TextRange.Text = PremiumTableWrite.Rows[k][0].ToString(); // Row Desc
                                        TableRowCounter++;
                                    }

                                    currentPlanNo = Convert.ToInt32(PremiumTableWrite.Rows[k]["Contribution_Id"]);
                                    if (currentPlanNo != oldPlanNo)
                                    {
                                        oldPlanNo = currentPlanNo;
                                        uniqeColumnNum++;

                                        // Check whether the PreimumTable is having values for the contribution selected
                                        var contri_1 = (from n in PremiumTableWrite.AsEnumerable()
                                                        where n.Field<int>("Contribution_Id") == contributionId_1
                                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                                        var contri_2 = (from n in PremiumTableWrite.AsEnumerable()
                                                        where n.Field<int>("Contribution_Id") == contributionId_2
                                                        select n.Field<int>("Contribution_Id")).FirstOrDefault();

                                        // If any of the contribution selected is not having the value then do not write that contribution in the heading
                                        // and column for that contribution will be deleted
                                        if (contri_1 == 0)
                                        {
                                            strPlan_Contri1 = "";
                                        }
                                        if (contri_2 == 0)
                                        {
                                            strPlan_Contri2 = "";
                                        }

                                        // If the contribution value 1 is available then 
                                        if (isFirstContributionTaken == false && !string.IsNullOrEmpty(strPlan_Contri1))
                                        {
                                            objShapes[j].Table.Cell(1, uniqeColumnNum).Shape.TextFrame.TextRange.Text = strPlan_Contri1;
                                            isFirstContributionTaken = true;
                                        }
                                        // If the contribution value 2 is available then 
                                        else if (!string.IsNullOrEmpty(strPlan_Contri2))
                                        {
                                            objShapes[j].Table.Cell(1, uniqeColumnNum).Shape.TextFrame.TextRange.Text = strPlan_Contri2;
                                        }
                                    }

                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Replace("\r\a", "") == PremiumTableWrite.Rows[k]["RateHeader"].ToString())
                                            {
                                                objShapes[j].Table.Cell(rowNum, uniqeColumnNum).Shape.TextFrame.TextRange.Text = PremiumTableWrite.Rows[k][colNumber].ToString(); //Contri Cost
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        //}
                    }
                }

                // For showing the Frequency information for Medical/Dental/Vision which is in table
                // This block is used to write the "Frequency" information on the table
                objSlides = objPres.Slides;
                if (!string.IsNullOrEmpty(Frequency_Text_To_Find))
                {
                    for (int i = 1; i <= objSlides.Count; i++)
                    {
                        objShapes = objSlides[i].Shapes;
                        //if (objSlides[i].SlideNumber == slideNumber)
                        //{
                        for (int j = 1; j <= objShapes.Count; j++)
                        {
                            if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoLine || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoAutoShape)
                            {
                            }
                            else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                            {
                                if (objShapes[j].Name.ToString().Equals(TableName))
                                {
                                    for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                                    {
                                        for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                        {
                                            if (objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Text.Contains(Frequency_Text_To_Find))
                                            {
                                                objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame.TextRange.Replace(Frequency_Text_To_Find, Frequency_Of_Contribution);
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        //break;
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        // Function to build the contribution premium table
        public void BuildContributionPremiumTable(ref DataTable PremiumTable)
        {
            PremiumTable.Columns.Add("RateHeader");
            PremiumTable.Columns.Add("Plan1_Rate");
            PremiumTable.Columns.Add("Plan2_Rate");
            PremiumTable.Columns.Add("Plan3_Rate");
            PremiumTable.Columns.Add("Plan4_Rate");
            PremiumTable.Columns.Add("Plan5_Rate");
            PremiumTable.Columns.Add("Plan6_Rate");
            PremiumTable.Columns.Add("Contribution_Id", typeof(Int32));
            PremiumTable.Columns.Add("RateID");
            PremiumTable.Columns.Add("contributionValueID");
            PremiumTable.Columns.Add("PlanNumber");
        }

        // Function to create PremiumTable
        public DataTable CreateContributionPremiumTable(DataTable PlanTable, DataSet ContributionDS, int index)
        {
            DataTable PremiumTable = new DataTable();

            try
            {
                int premium_row_counter = 0;

                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("contributioncost", typeof(string));
                PremiumTable.Columns.Add("summaryname", typeof(string));
                PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                PremiumTable.Columns.Add("contributionid", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("contributionValueID", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("PlanNumber", typeof(string));

                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                {
                    if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                    {
                        if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                        {
                            PremiumTable.Rows.Add();
                            PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                            PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                            PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                            PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                            PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                            PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                            PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                            premium_row_counter++;
                        }

                        if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId_2"].ToString()) && ContributionDS.Tables["ContributionValueTable"].Rows[j]["contribution_number"].ToString() == PlanTable.Rows[index]["PlanNumber"].ToString())
                        {
                            PremiumTable.Rows.Add();
                            PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];//Plan Name
                            PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();//Rate tier ID
                            PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();//Contribution Description(like EE ,Spouse)
                            PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();//Contribution values
                            PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionValueID"].ToString();//Contribution ValueId
                            PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();//Frequency
                            PremiumTable.Rows[premium_row_counter][7] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString();//Contribution Id
                            PremiumTable.Rows[premium_row_counter][11] = PlanTable.Rows[index]["PlanNumber"].ToString();
                            premium_row_counter++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PremiumTable;
        }

        // Function to delete unwanted columns from the table
        // This function is a common function and can be used in case of PPT report 
        // This function iterates on all the slides and look for the tables only. If the table is having a "Delete" keyword in the heading of the first row then that column will be deleted.
        // Also we have get the width of the table initially then using the same width to set to the table after deleting the columns
        public void DeleteUnwantedColumnsFromTable(Microsoft.Office.Interop.PowerPoint._Presentation objPres, Microsoft.Office.Interop.PowerPoint.Presentations objPresSet, Microsoft.Office.Interop.PowerPoint.Slides objSlides, Microsoft.Office.Interop.PowerPoint.Shapes objShapes, Microsoft.Office.Interop.PowerPoint.TextFrame txtFrame, Microsoft.Office.Interop.PowerPoint.TextRange txtRange)
        {
            try
            {
                float tblWidth = 0;

                #region merge fields
                // Iterate through each slide for putting the attribute values for respective fields
                objSlides = objPres.Slides;

                for (int i = 1; i <= objSlides.Count; i++)
                {
                    objShapes = objSlides[i].Shapes;

                    for (int j = 1; j <= objShapes.Count; j++)
                    {
                        if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoDiagram || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoSmartArt || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoGroup || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPicture || objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoPlaceholder)
                        {
                        }
                        else if (objShapes[j].Type == Microsoft.Office.Core.MsoShapeType.msoTable)
                        {
                            tblWidth = objShapes[j].Width;
                            for (int rowNum = 1; rowNum <= objShapes[j].Table.Rows.Count; rowNum++)
                            {
                                for (int columnNum = 1; columnNum <= objShapes[j].Table.Columns.Count; columnNum++)
                                {
                                    txtFrame = objShapes[j].Table.Cell(rowNum, columnNum).Shape.TextFrame;
                                    txtRange = txtFrame.TextRange;

                                    // Delete the columns from the table having the "Delete" keyword in the column heading (First row)
                                    if (txtRange.Text.Contains("Delete"))
                                    {
                                        objShapes[j].Table.Columns[columnNum].Delete();
                                        columnNum = columnNum - 1;
                                    }
                                }

                                if (rowNum == objShapes[j].Table.Rows.Count)
                                {
                                    // for deleting the last row if the last row is empty
                                    txtFrame = objShapes[j].Table.Cell(rowNum, 1).Shape.TextFrame;
                                    txtRange = txtFrame.TextRange;
                                    if (string.IsNullOrEmpty(txtRange.Text))
                                    {
                                        objShapes[j].Table.Rows[rowNum].Delete();
                                    }

                                    // Set the width of the table
                                    objShapes[j].Width = tblWidth;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Function to get the Activity Details
        public void GetActivity_List(string rdlValue, int SubjectID, DropDownList ddlClient, ref DropDownList ddlActivity)
        {
            bool isActivityPresent = false;
            try
            {
                BPBusiness bp = new BPBusiness();
                TimelineDetail timeD = new TimelineDetail();
                DataTable ActivityTable = new DataTable();
                string ActivityName = string.Empty;
                string ActivityID = string.Empty;
                string SessionId = Session["SessionId"].ToString();
                int rowIndex = 1;
                //Clear();

                if (ddlClient.SelectedIndex == 0)
                {
                    ddlActivity.Items.Clear();
                }
                else
                {
                    ActivityTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                    Session["ActivityTable"] = ActivityTable;

                    if (ActivityTable.Rows.Count > 0)
                    {
                        ddlActivity.Items.Insert(0, new ListItem("Select", string.Empty));
                        for (int i = 0; i < ActivityTable.Rows.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["recordID"])))
                            {
                                ActivityID = Convert.ToString(ActivityTable.Rows[i]["recordID"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["subject"])))
                            {
                                ActivityName = Convert.ToString(ActivityTable.Rows[i]["subject"]);
                            }
                            //-- Do not delete code starts here --------------------------------------------------
                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["name"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["name"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["createdon"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["createdon"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["dueon"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["dueon"]);
                            ////}

                            ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["status"])))
                            ////{
                            ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["status"]);
                            ////}
                            //-- Do not delete code ends here --------------------------------------------------

                            if (rdlValue == "Open" && Convert.ToString(ActivityTable.Rows[i]["status"]).Trim().ToLower() == "open")
                            {
                                ddlActivity.Items.Insert(rowIndex, new ListItem(ActivityName, ActivityID));
                                rowIndex++;
                            }
                            else if (rdlValue == "All")
                            {
                                ddlActivity.Items.Insert(i + 1, new ListItem(ActivityName, ActivityID));
                            }
                        }
                        isActivityPresent = true;
                    }
                }

                if (isActivityPresent == false)
                {
                    if (ddlClient.SelectedItem.Text != "Select")
                    {
                        //string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text + "'.\");";
                        //ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                        /**************Code Added by Amogh Vilayatkar 9 Jan 2018 PopUp not Rendering on Page* ***********/
                        var page = HttpContext.Current.CurrentHandler as System.Web.UI.Page;
                        string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text + "'.\");";
                        ScriptManager.RegisterStartupScript(page, GetType(), "ServerControlScript", script, true);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void DeleteRows_STD_LTD_Life(int table_no, Word.Document oWordDoc)
        {
            int trcnt = oWordDoc.Tables[table_no].Rows.Count;
            #region Delete Rows
            for (int tr = 1; tr <= trcnt; tr++)
            {
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_Life1"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_Life2"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("ADD_Plan"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("STD_Plan1"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("STD_Plan2"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_LTD1"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_LTD2"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_STD_LTD1"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
                if (oWordDoc.Tables[table_no].Cell(tr, 1).Range.Text.Contains("Delete_STD_LTD2"))
                {
                    oWordDoc.Tables[table_no].Rows[tr].Delete();
                    trcnt = trcnt - 1;
                }
            }

            #endregion Delete Rows
        }

        // Function to find the text in the shapes and to replace the text
        public void FindandReplace(Word.Document doc, string Findtext, string ReplaceText)
        {
            Word.Range myStoryRange = doc.Range();

            //First search the main document using the Selection
            Word.Find myFind = myStoryRange.Find;
            myFind.Text = Findtext;
            myFind.Replacement.Text = ReplaceText;
            myFind.Forward = true;
            myFind.Wrap = Word.WdFindWrap.wdFindContinue;
            myFind.Format = false;
            myFind.MatchCase = false;
            myFind.MatchWholeWord = false;
            myFind.MatchWildcards = false;
            myFind.MatchSoundsLike = false;
            myFind.MatchAllWordForms = false;
            myFind.Execute(Replace: Word.WdReplace.wdReplaceAll);

            //'Now search all other stories using Ranges
            foreach (Word.Range otherStoryRange in doc.StoryRanges)
            {
                if (otherStoryRange.StoryType != Word.WdStoryType.wdMainTextStory)
                {
                    Word.Find myOtherFind = otherStoryRange.Find;
                    myOtherFind.Text = Findtext;
                    myOtherFind.Replacement.Text = ReplaceText;
                    myOtherFind.Wrap = Word.WdFindWrap.wdFindContinue;
                    myOtherFind.Execute(Replace: Word.WdReplace.wdReplaceAll);
                }

                // 'Now search all next stories of other stories (doc.storyRanges dont seem to cascades in sub story)
                Word.Range nextStoryRange = otherStoryRange.NextStoryRange;
                while (nextStoryRange != null)
                {
                    Word.Find myNextStoryFind = nextStoryRange.Find;
                    myNextStoryFind.Text = Findtext;
                    myNextStoryFind.Replacement.Text = ReplaceText;
                    myNextStoryFind.Wrap = Word.WdFindWrap.wdFindContinue;
                    myNextStoryFind.Execute(Replace: Word.WdReplace.wdReplaceAll);

                    nextStoryRange = nextStoryRange.NextStoryRange;
                }
            }
        }

        /// <summary>
        /// Write_Field_Header
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Fill_Shape(Word.Document oWordDoc, Word.Application oWordApp, string selectedColor = "Grey")
        {
            Word.WdColor wdColor_font = font_color(selectedColor);

            //Code For writing fields in Footer or  Header section  in Word Docs
            #region Header Shape Color
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                {
                    Word.Shapes Shape = header.Shapes;

                    foreach (Word.Shape HeaderShape in Shape)
                    {
                        if (HeaderShape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                        {
                            if (HeaderShape.Name == "txtHeader" || HeaderShape.Name == "txtfooter")
                            {
                                HeaderShape.TextFrame.TextRange.Shading.BackgroundPatternColor = textbox_color(selectedColor);
                            }
                            if (HeaderShape.Name == "txtSideTextbox")
                            {
                                HeaderShape.TextFrame.TextRange.Shading.BackgroundPatternColor = cell_color(selectedColor);
                            }
                        }
                    }
                }


            }
            #endregion Header Shape Color
            #region Shape Color
            foreach (Word.Shape shape in oWordDoc.Shapes)
            {
                if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                {
                    if (shape.Name == "Page1_Textbox1" || shape.Name == "Page1_Textbox2")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = textbox_color(selectedColor);
                        // shape.TextFrame.TextRange.Font.Color = Word.WdColor.wdColorWhite;
                    }
                    if (shape.Name == "Page1_Textbox3")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = cell_color(selectedColor);
                        // shape.TextFrame.TextRange.Font.Color = Word.WdColor.wdColorWhite;
                    }

                }
            }
            #endregion Shape Color

        }

        public Literal Writer_FooterText_ForAllPages()
        {
            string FooterText = WebConfigurationManager.AppSettings["FooterText"];
            //FooterText = FooterText.Replace('@', '&');
            var FooterResult = Regex.Replace(FooterText,       // input
                               @"CONFIDENTIAL & PROPRIETARY", // word to match
                               @"<b>$0</b>",                 // "wrap match in bold tags"
                               RegexOptions.IgnoreCase);    // ignore case when matching
            Literal lt = new Literal();
            lt.Text = FooterResult;

            return lt;

        }
        // Function to Merge the rows in the table is the table is having contribution values attached with the 
        // summary values and having more than one plan (for two plans in one table only) in the same table
        public void MergeColumnsInContributionTable(Word.Document oWordDoc, int rowNum, int TableNo, bool isFirstPlanOnlyOneContribution, bool isSecondPlanHasOnlyOneContribution)
        {
            try
            {
                rowNum = oWordDoc.Tables[TableNo].Rows.Count;
                // For first plan
                for (int rw = 8; rw <= rowNum; rw++)
                {
                    for (int cl = 2; cl < oWordDoc.Tables[TableNo].Columns.Count; cl++)
                    {
                        if (isFirstPlanOnlyOneContribution == true)
                        {
                            oWordDoc.Tables[TableNo].Cell(rw, 2).Merge(oWordDoc.Tables[TableNo].Cell(rw, 3));
                            break;
                        }
                    }
                }

                // For second plan
                for (int rw = 8; rw <= rowNum; rw++)
                {
                    for (int cl = 2; cl < oWordDoc.Tables[TableNo].Columns.Count; cl++)
                    {
                        if (isFirstPlanOnlyOneContribution == true && isSecondPlanHasOnlyOneContribution == true)
                        {
                            oWordDoc.Tables[TableNo].Cell(rw, cl + 1).Merge(oWordDoc.Tables[TableNo].Cell(rw, cl + 2));
                            break;
                        }
                        else if (isFirstPlanOnlyOneContribution == false && isSecondPlanHasOnlyOneContribution == true)
                        {
                            oWordDoc.Tables[TableNo].Cell(rw, 4).Merge(oWordDoc.Tables[TableNo].Cell(rw, 5));
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /************************************************************************************
         * Created by Amogh For Account Profile - Detailed 
         * 
         */
        public void LoadPlanTypeIds_AccountDetails()
        {
            // Medical Plan Type Id's
            MedicalPlanTypeList.Clear();
            MedicalPlanTypeList.Add(100);       // Medical HMO
            MedicalPlanTypeList.Add(110);       // Medical PPO
            MedicalPlanTypeList.Add(120);       // Medical PPO (3-Tier)
            MedicalPlanTypeList.Add(130);       // Medical POS (2-Tier)
            MedicalPlanTypeList.Add(140);       // Medical POS (3-Tier)
            MedicalPlanTypeList.Add(150);       // Medical EPO (1-Tier)
            MedicalPlanTypeList.Add(160);       // Medical EPO (2-Tier)
            MedicalPlanTypeList.Add(170);       // Medical Indemnity
            // Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
            ////MedicalPlanTypeList.Add(173);       // Prescription Drug (Carve-Out) -- Amogh
            MedicalPlanTypeList.Add(410);       // International Bundled Plan (3-Tier)	410
            MedicalPlanTypeList.Add(233);       // Limited Benefit 2-Tier	
            ////MedicalPlanTypeList.Add(235);       // Stop Loss	

            /*---
             * Account profile-Detailed - Issue #2 & #3 - Changes to Plan Details section- By Nicole [Thu 4/12/2018 8:30 PM]
             * As Per Nicole saparate stop loss section need to create.
             * */
            StopLossPlanTypeList.Add(235);       // Stop Loss	
            PrescriptionDrugPlanTypeList.Add(173); // Prescription Drug (Carve-Out) -- Amogh

            // Dental Plan Type Id's
            DentalPlanTypeList.Clear();
            DentalPlanTypeList.Add(180);        // Managed Dental
            DentalPlanTypeList.Add(190);        // Dental PPO
            DentalPlanTypeList.Add(200);        // Dental Triple Option
            DentalPlanTypeList.Add(210);        // Dental Indemnity

            // Vision Plan Type Id's
            VisionPlanTypeList.Clear();
            VisionPlanTypeList.Add(230);        // Vision

            // Life AD&D Plan Type Id's
            LifeADDPlanTypeList.Clear();
            LifeADDPlanTypeList.Add(240);       // Life and AD&D
            LifeADDPlanTypeList.Add(250);       // Group Term Life
            LifeADDPlanTypeList.Add(270);       // AD&D

            // STD Plan Type Id's
            STDPlanTypeList.Clear();
            STDPlanTypeList.Add(290);       // Short Term Disability (STD)

            // STD Plan Type Id's
            LTDPlanTypeList.Clear();
            LTDPlanTypeList.Add(300);       // Long Term Disability (LTD)

            // Voluntary Life Plan Type Id's
            VoluntaryLifeADDPlanTypeList.Clear();
            VoluntaryLifeADDPlanTypeList.Add(260);      // For Voluntary Life
            VoluntaryLifeADDPlanTypeList.Add(280);      // For Voluntary AD&D

            VoluntaryADDPlanTypeList.Add(280);      // For Voluntary AD&D

            // EAP Plan Type Id's
            EAPPlanTypeList.Clear();
            EAPPlanTypeList.Add(310);       // Employee Assistance Program (EAP)

            // FSA Plan Type Id's
            FSAPlanTypeList.Clear();
            FSAPlanTypeList.Add(330);       // Section 125

            // HRA Plan Type Id's
            HRAPlanTypeList.Clear();
            HRAPlanTypeList.Add(178);       // Health Reimbursement Arrangement

            // HSA Plan Type Id's
            HSAPlanTypeList.Clear();
            HSAPlanTypeList.Add(179);       // Health Savings Account

            // Wellness Plan Type Id's
            WellnessPlanTypeList.Clear();
            WellnessPlanTypeList.Add(317);                  // Wellness Program
            //WellnessPlanTypeList.Add(1740);               

            // Additional Products Plan Type Id's
            AdditionalProductsPlanTypeList.Clear();
            AdditionalProductsPlanTypeList.Add(1790);       // Patient Advocacy
            AdditionalProductsPlanTypeList.Add(5460);       // Consumer Driven Telemedicine
            AdditionalProductsPlanTypeList.Add(5500);       // Accident
            AdditionalProductsPlanTypeList.Add(1400);       // Voluntary Cancer
            AdditionalProductsPlanTypeList.Add(1160);       // Voluntary Critical Illness

            /*--------------------As per Nicole We added this wellness plan in Additional Product List */
            AdditionalProductsPlanTypeList.Add(1740);       // Wellness/Disease Mgmt
            AdditionalProductsPlanTypeList.Add(1109);       // COBRA Administration
            AdditionalProductsPlanTypeList.Add(5060);       // Hospitalization

            /************************ADDED AS PER NICOLE-  Issue #26 - LTC not listed under Plan Details screen***/
            AdditionalProductsPlanTypeList.Add(1115);       // Long Term Care Plan

            //Cobra Administration 1109
            //Hospitalization Only 5060

            // Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
            //AdditionalProductsPlanTypeList.Add(320);        // Business Travel Accident (BTA)
            AccidentalProductPlanTypeList.Clear();
            AccidentalProductPlanTypeList.Add(320);

            // Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
            DisabilityPlanTypeList.Clear();
            DisabilityPlanTypeList.Add(293); //New Jersey TDB
            DisabilityPlanTypeList.Add(292); //New York DBL
            DisabilityPlanTypeList.Add(294); //Hawaii TDI

        }


        public void LoadPlanTypeIds()
        {
            // Medical Plan Type Id's
            MedicalPlanTypeList.Clear();
            MedicalPlanTypeList.Add(100);       // Medical HMO
            MedicalPlanTypeList.Add(110);       // Medical PPO
            MedicalPlanTypeList.Add(120);       // Medical PPO (3-Tier)
            MedicalPlanTypeList.Add(130);       // Medical POS (2-Tier)
            MedicalPlanTypeList.Add(140);       // Medical POS (3-Tier)
            MedicalPlanTypeList.Add(150);       // Medical EPO (1-Tier)
            MedicalPlanTypeList.Add(160);       // Medical EPO (2-Tier)
            MedicalPlanTypeList.Add(170);       // Medical Indemnity
            //////MedicalPlanTypeList.Add(173);       // Prescription Drug (Carve-Out) -- Amogh

            // Dental Plan Type Id's
            DentalPlanTypeList.Clear();
            DentalPlanTypeList.Add(180);        // Managed Dental
            DentalPlanTypeList.Add(190);        // Dental PPO
            DentalPlanTypeList.Add(200);        // Dental Triple Option
            DentalPlanTypeList.Add(210);        // Dental Indemnity

            // Vision Plan Type Id's
            VisionPlanTypeList.Clear();
            VisionPlanTypeList.Add(230);        // Vision

            // Life AD&D Plan Type Id's
            LifeADDPlanTypeList.Clear();
            LifeADDPlanTypeList.Add(240);       // Life and AD&D
            LifeADDPlanTypeList.Add(250);       // Group Term Life
            LifeADDPlanTypeList.Add(270);       // AD&D

            // STD Plan Type Id's
            STDPlanTypeList.Clear();
            STDPlanTypeList.Add(290);       // Short Term Disability (STD)

            // STD Plan Type Id's
            LTDPlanTypeList.Clear();
            LTDPlanTypeList.Add(300);       // Long Term Disability (LTD)

            // Voluntary Life Plan Type Id's
            VoluntaryLifeADDPlanTypeList.Clear();
            VoluntaryLifeADDPlanTypeList.Add(260);      // For Voluntary Life
            VoluntaryLifeADDPlanTypeList.Add(280);      // For Voluntary AD&D

            VoluntaryADDPlanTypeList.Add(280);      // For Voluntary AD&D

            // EAP Plan Type Id's
            EAPPlanTypeList.Clear();
            EAPPlanTypeList.Add(310);       // Employee Assistance Program (EAP)

            // FSA Plan Type Id's
            FSAPlanTypeList.Clear();
            FSAPlanTypeList.Add(330);       // Section 125

            // HRA Plan Type Id's
            HRAPlanTypeList.Clear();
            HRAPlanTypeList.Add(178);       // Health Reimbursement Arrangement

            // HSA Plan Type Id's
            HSAPlanTypeList.Clear();
            HSAPlanTypeList.Add(179);       // Health Savings Account

            // Wellness Plan Type Id's
            WellnessPlanTypeList.Clear();
            WellnessPlanTypeList.Add(317);                  // Wellness Program
            WellnessPlanTypeList.Add(1740);                 // Wellness/Disease Mgmt

            // Additional Products Plan Type Id's
            AdditionalProductsPlanTypeList.Clear();
            AdditionalProductsPlanTypeList.Add(1790);       // Patient Advocacy
            AdditionalProductsPlanTypeList.Add(5460);       // Consumer Driven Telemedicine
            AdditionalProductsPlanTypeList.Add(5500);       // Accident
            AdditionalProductsPlanTypeList.Add(1400);       // Voluntary Cancer
            AdditionalProductsPlanTypeList.Add(1160);       // Voluntary Critical Illness
        }

        public void LoadPlanTypeIds_Pilot()
        {
            // Medical Plan Type Id's
            MedicalPlanTypeList.Clear();
            MedicalPlanTypeList.Add(100);       // Medical HMO
            MedicalPlanTypeList.Add(110);       // Medical PPO
            MedicalPlanTypeList.Add(120);       // Medical PPO (3-Tier)
            MedicalPlanTypeList.Add(130);       // Medical POS (2-Tier)
            MedicalPlanTypeList.Add(140);       // Medical POS (3-Tier)
            MedicalPlanTypeList.Add(150);       // Medical EPO (1-Tier)
            MedicalPlanTypeList.Add(160);       // Medical EPO (2-Tier)
            MedicalPlanTypeList.Add(170);       // Medical Indemnity

            // Dental Plan Type Id's
            DentalPlanTypeList.Clear();
            DentalPlanTypeList.Add(180);        // Managed Dental
            DentalPlanTypeList.Add(190);        // Dental PPO
            DentalPlanTypeList.Add(200);        // Dental Triple Option
            DentalPlanTypeList.Add(210);        // Dental Indemnity

            // Vision Plan Type Id's
            VisionPlanTypeList.Clear();
            VisionPlanTypeList.Add(230);        // Vision

            // Life AD&D Plan Type Id's
            LifeADDPlanTypeList.Clear();
            LifeADDPlanTypeList.Add(240);       // Life and AD&D

            GroupTermLifePlanTypeList.Clear();
            GroupTermLifePlanTypeList.Add(250);       // Group Term Life

            ADNDPlanTypeList.Clear();
            ADNDPlanTypeList.Add(270);       // AD&D

            // STD Plan Type Id's
            STDPlanTypeList.Clear();
            STDPlanTypeList.Add(290);       // Short Term Disability (STD)

            // STD Plan Type Id's
            LTDPlanTypeList.Clear();
            LTDPlanTypeList.Add(300);       // Long Term Disability (LTD)

            // Voluntary Life Plan Type Id's
            VoluntaryLifeADDPlanTypeList.Clear();
            VoluntaryLifeADDPlanTypeList.Add(260);      // For Voluntary Life
            //VoluntaryLifeADDPlanTypeList.Add(280);      // For Voluntary AD&D

            VoluntaryADDPlanTypeList.Add(280);      // For Voluntary AD&D

            // EAP Plan Type Id's
            EAPPlanTypeList.Clear();
            EAPPlanTypeList.Add(310);       // Employee Assistance Program (EAP)

            // FSA Plan Type Id's
            FSAPlanTypeList.Clear();
            FSAPlanTypeList.Add(330);       // Section 125

            // HRA Plan Type Id's
            HRAPlanTypeList.Clear();
            HRAPlanTypeList.Add(178);       // Health Reimbursement Arrangement

            // HSA Plan Type Id's
            HSAPlanTypeList.Clear();
            HSAPlanTypeList.Add(179);       // Health Savings Account

            // Wellness Plan Type Id's
            WellnessPlanTypeList.Clear();
            WellnessPlanTypeList.Add(317);                  // Wellness Program
            WellnessPlanTypeList.Add(1740);                 // Wellness/Disease Mgmt

            // Additional Products Plan Type Id's
            AdditionalProductsPlanTypeList.Clear();
            AdditionalProductsPlanTypeList.Add(1790);       // Patient Advocacy
            AdditionalProductsPlanTypeList.Add(5460);       // Consumer Driven Telemedicine
            AdditionalProductsPlanTypeList.Add(5500);       // Accident
            AdditionalProductsPlanTypeList.Add(1400);       // Voluntary Cancer
            AdditionalProductsPlanTypeList.Add(1160);       // Voluntary Critical Illness

            //Stop Loss
            StopLossPlanTypeList.Clear();
            StopLossPlanTypeList.Add(235);                 //Stop Loss

            //Fees for Service
            FeesForServicePlanTypeList.Clear();
            FeesForServicePlanTypeList.Add(1108);               //Fees for Service
        }
        /*************************************************************************************/
        /***********THIS FUCNTION ADDED BY VAIBHAV FOR NEW REQUEST SPANISH ********************/
        /**************************************************************************************/
        public void WriteFieldsForContactInformationNotice_V2(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, int index, int marketplaceSelectedIndex = 0, string creditableCoverageValue = "", CheckBoxList chkAnualNotice = null, bool isSelected = false, string selectedColor = "", string summaryName = "")
        {
            int iTotalFields = 0;
            BPBusiness bp = new BPBusiness();

            Word.WdColor wdColor_font = font_color(selectedColor);
            try
            {
                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                    {
                        if (shape.Name == "Annual_Notice_1" || shape.Name == "Annual_Notice_2" || shape.Name == "Annual_Notice_3" || shape.Name == "Annual_Notice_4" || shape.Name == "Annual_Notice_4_a" || shape.Name == "Annual_Notice_5" || shape.Name == "Annual_Notice_6" || shape.Name == "Annual_Notice_7" || shape.Name == "Annual_Notice_8" || shape.Name == "Annual_Notice_9")
                        {
                            shape.TextFrame.TextRange.Shading.BackgroundPatternColor = textbox_color(selectedColor);
                            shape.TextFrame.TextRange.Font.Color = Word.WdColor.wdColorWhite;
                        }
                    }
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("(MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("(MODIFICATION REQUIRED"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MODIFICATION REQUIRED");
                            continue;
                        }
                        if (fieldName.Contains("MODIFICATION REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MODIFICATION REQUIRED)");
                            continue;
                        }
                        if (fieldName.Contains("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("THE NOTICE ISSUED BY THE EEOC IS BELOW, HIGHLIGHTED TO IDENTIFY AREAS FOR EMPLOYERS TO COMPLETE.)");
                            continue;
                        }
                        if (fieldName.Contains("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(MUST BE IN SPD, CONSIDER INCLUDING HERE. INCLUDE STATE INFORMATION IF APPLICABLE)");
                            continue;
                        }

                        if (fieldName.Contains("(IF APPLICABLE -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(IF APPLICABLE - ");
                            continue;
                        }

                        if (fieldName.Contains("(ONLY USE IF GRANDFATHERED -"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(ONLY USE IF GRANDFATHERED - ");
                            continue;
                        }

                        if (fieldName.Contains("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(APPLICABLE NON-GRANDFATHERED PLANS - MODIFICATION");
                            continue;
                        }

                        if (fieldName.Contains("REQUIRED)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("REQUIRED)");
                            continue;
                        }

                        if (fieldName.Contains("MICHELLE’S LAW DISCLOSURE"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("MICHELLE’S LAW DISCLOSURE");
                            continue;
                        }
                        if (fieldName.Contains("(USE ONLY IF APPLICABLE)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("(USE ONLY IF APPLICABLE)");
                            continue;
                        }
                        if (fieldName.Contains("Receive Information about Your Plan and Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Receive Information about Your Plan and Benefits");
                            continue;
                        }
                        if (fieldName.Contains("Continue Group Health Plan Coverage"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Continue Group Health Plan Coverage");
                            continue;
                        }
                        if (fieldName.Contains("Prudent Actions by Plan Fiduciaries"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Prudent Actions by Plan Fiduciaries");
                            continue;
                        }
                        if (fieldName.Contains("Enforce your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Enforce your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Assistance with your Questions"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Assistance with your Questions");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("Your Information. Your Rights. Our Responsibilities."))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.Range.Font.Bold = 1;
                            oWordApp.Selection.TypeText("Your Information. Your Rights. Our Responsibilities.");
                            continue;
                        }
                        if (fieldName.Contains("Your Rights"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Rights");
                            continue;
                        }
                        if (fieldName.Contains("Your Choices"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Your Choices");
                            continue;
                        }
                        if (fieldName.Contains("Our Uses and Disclosures"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Our Uses and Disclosures");
                            continue;
                        }
                        if (fieldName.Contains("Changes to the Terms of this Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Changes to the Terms of this Notice");
                            continue;
                        }
                        if (fieldName.Contains("Other Instructions for Notice"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.Range.Font.Name = "Arial";
                            oWordApp.Selection.Range.Font.Size = 14f;
                            oWordApp.Selection.TypeText("Other Instructions for Notice");
                            continue;
                        }
                        if (fieldName.Contains("CONTACT INFORMATION"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("CONTACT INFORMATION");
                            continue;
                        }
                        if (fieldName.Contains("PART A: General Information"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART A: General Information");
                            continue;
                        }
                        if (fieldName.Contains("What is the Health Insurance Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("What is the Health Insurance Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Can I Save Money on my Health Insurance Premiums in the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Can I Save Money on my Health Insurance Premiums in the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Does Employer Health Coverage Affect Eligibility for Premium Savings through the Marketplace?");
                            continue;
                        }
                        if (fieldName.Contains("How Can I Get More Information?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("How Can I Get More Information?");
                            continue;
                        }
                        if (fieldName.Contains("PART B: Information About Health Coverage Offered by Your Employer"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("PART B: Information About Health Coverage Offered by Your Employer");
                            continue;
                        }
                        if (fieldName.Contains("HealthCare.gov"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("HealthCare.gov");
                            continue;
                        }

                        if (fieldName.Contains("CREDITABLE COVERAGE"))
                        {
                            if (creditableCoverageValue.Trim() != string.Empty)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (creditableCoverageValue.Trim() != "Not Included")
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                switch (creditableCoverageValue)
                                {
                                    case "Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Non-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Cobra-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11c - Creditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11c - Notice of Creditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Cobra-Non-Creditable-English":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11d - Noncreditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11d - Notice of Noncreditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    case "Creditable-Spanish":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide_Spanish.docx"), missing, true, missing, missing);

                                        }
                                        else
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11_Spanish.docx"), missing, true, missing, missing);
                                        }

                                        break;
                                    case "NonCreditable-Spanish":
                                        if (summaryName == "Enrollment Guide")
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide_Spanish.docx"), missing, true, missing, missing);
                                        }
                                        else
                                        {
                                            r.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
                                            r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11_spanish.docx"), missing, true, missing, missing);
                                        }
                                        break;
                                    default:
                                        break;
                                }

                                #region to be remove
                                //if (creditableCoverageIndex == 1)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11a - Creditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11a - Notice of Creditable Coverage 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 2)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11b - Noncreditable Coverage_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11b - Notice of Noncreditable Coverage 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 3)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11c - Creditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11c - Notice of Creditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                //else if (creditableCoverageIndex == 4)
                                //{
                                //    if (summaryName == "Enrollment Guide")
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/11d - Noncreditable Coverage - COBRA_EnrolmentGuide.docx"), missing, true, missing, missing);
                                //    }
                                //    else
                                //    {
                                //        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/11d - Notice of Noncreditable Coverage - COBRA 4.11.docx"), missing, true, missing, missing);
                                //    }
                                //}
                                #endregion
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Contains("Notice of Privacy Practices"))
                        {
                            if (chkAnualNotice.Items[9].Selected == true)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);

                                if (summaryName == "Enrollment Summary" || summaryName == "Summary Highlight" || summaryName == "Value Summary" || summaryName == "Enrollment Guide")
                                {
                                    if (summaryName == "Enrollment Guide")
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices_EnrolmentGuide.doc"), missing, true, missing, missing);
                                    }
                                    else
                                    {
                                        r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                    }
                                }
                                else
                                {
                                    r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/10 - Notice of Privacy Practices.doc"), missing, true, missing, missing);
                                }
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (index > -1)
                        {
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("\f");
                                if (isSelected == true)
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText("CONTACT INFORMATION");
                                }
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Name);
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Address);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(ContactList[index].Email);
                                continue;
                            }

                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Phone.Count == 0)
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    StringBuilder Phone = new StringBuilder(); ;
                                    for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                    {
                                        Phone.Append(ContactList[index].Phone[i]);
                                        if (ContactList[index].Phone[i] != string.Empty)
                                        {
                                            if (Phone.ToString().Contains("_"))
                                            {
                                                Phone.Replace("_", "-");
                                            }
                                            Phone.Append("\n");
                                        }
                                    }
                                    oWordApp.Selection.TypeText(Phone.ToString());
                                }
                                continue;
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Select();
                                if (ContactList[index].Postion == " ")
                                {
                                    oWordApp.Selection.Delete();
                                    oWordApp.Selection.TypeBackspace();
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(ContactList[index].Postion);
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("MARKETPLACE COVERAGE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("CONTACTNAMENOTICE"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactName"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactAddress"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPhone"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactPosition"))
                            {
                                myMergeField.Delete();
                            }
                            if (fieldName.Contains("AnnualContactEmail"))
                            {
                                myMergeField.Delete();
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public string GetBenefitColumnName(int BenefitColumnID)
        {
            Dictionary<int, string> dictBPColumns = new Dictionary<int, string>();
            dictBPColumns[100] = "Schedule of Benefits";
            dictBPColumns[101] = "In-Network Benefits";
            dictBPColumns[102] = "Out-of-Network Benefits";
            dictBPColumns[103] = "Level 1";
            dictBPColumns[104] = "Level 2";
            dictBPColumns[105] = "Level 3";
            dictBPColumns[106] = "POS In-Network";
            dictBPColumns[107] = "POS Out-of-Network";
            dictBPColumns[108] = "HMO Level";
            dictBPColumns[109] = "POS In-Network";
            dictBPColumns[110] = "POS Out-of-Network";
            dictBPColumns[111] = "Schedule of Benefits";
            dictBPColumns[112] = "EPO In-Network";
            dictBPColumns[113] = "EPO Out-of-Network";
            dictBPColumns[114] = "Schedule of Benefits";
            dictBPColumns[115] = "Schedule of Benefits";
            dictBPColumns[116] = "In-Network Benefits";
            dictBPColumns[117] = "Out-of-Network Benefits";
            dictBPColumns[118] = "Level 1";
            dictBPColumns[119] = "Level 2";
            dictBPColumns[120] = "Level 3";
            dictBPColumns[121] = "Schedule of Benefits";
            dictBPColumns[123] = "In-Network Benefits";
            dictBPColumns[124] = "Out-of-Network Benefits";
            dictBPColumns[127] = "Schedule of Benefits";
            dictBPColumns[128] = "Schedule of Benefits";
            dictBPColumns[129] = "Schedule of Benefits";
            dictBPColumns[130] = "Schedule of Benefits";
            dictBPColumns[131] = "Schedule of Benefits";
            dictBPColumns[132] = "Schedule of Benefits";
            dictBPColumns[133] = "Schedule of Benefits";
            dictBPColumns[134] = "Schedule of Benefits";
            dictBPColumns[135] = "Schedule of Covered Services";
            dictBPColumns[136] = "Schedule of Benefits";
            dictBPColumns[137] = "Schedule of Benefits";
            dictBPColumns[138] = "In-Network";
            dictBPColumns[139] = "Out-of-Network";
            dictBPColumns[140] = "Schedule of Benefits";
            dictBPColumns[141] = "Schedule of Benefits";
            dictBPColumns[142] = "Schedule of Benefits";
            dictBPColumns[143] = "Schedule of Benefits";
            dictBPColumns[144] = "In-Network Benefits";
            dictBPColumns[145] = "Out-of-Network Benefits";
            dictBPColumns[146] = "Schedule of Benefits";
            dictBPColumns[147] = "Schedule of Benefits";
            dictBPColumns[148] = "In-Network Benefits";
            dictBPColumns[149] = "Out-of-Network Benefits";
            dictBPColumns[150] = "Schedule of Benefits";
            dictBPColumns[151] = "Schedule of Benefits";
            dictBPColumns[152] = "Schedule of Benefits";
            dictBPColumns[153] = "Schedule of Benefits";
            dictBPColumns[154] = "Schedule of Benefits";
            dictBPColumns[155] = "Schedule of Benefits";
            dictBPColumns[156] = "Schedule of Benefits";
            dictBPColumns[158] = "Out of US";
            dictBPColumns[159] = "US - In Network";
            dictBPColumns[160] = "US - Out of Network";
            dictBPColumns[161] = "Schedule of Benefits";
            dictBPColumns[162] = "Schedule of Benefits";

            if (dictBPColumns.ContainsKey(BenefitColumnID))
                return dictBPColumns[BenefitColumnID];

            return string.Empty;
        }

        /************************************************************************************************************************************/
        /***  WE ADDED THIS FUNCTION TO FORMATE THE VALUE IN BENEFIT SUMMERY REPORT - ADDED BY - AMOGH                                      */
        /************************************************************************************************************************************/
        public string GetBenefitFormattedValue(DataRow dr)
        {
            string value = string.Empty;
            if (!dr["value"].ToString().Contains(','))
            {
                value = Convert.ToString(dr["value"].ToString().Trim());
                if (!string.IsNullOrEmpty(dr["value"].ToString()))
                {
                    if (IsNumeric(Convert.ToString(dr["value"].ToString())))
                    {
                        if (value.Contains('.'))
                        {
                            value = string.Format("{0:#,0.00}", double.Parse(value));
                            var finalVal = value.EndsWith(".00") ? value.Substring(0, value.LastIndexOf(".00")) : value;
                            value = finalVal;
                        }
                        else
                        {
                            value = string.Format("{0:#,0.##}", int.Parse(value));
                        }
                    }
                }
                /////return (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

            }
            else
            {
                value = Convert.ToString(dr["value"].ToString().Trim());
            }

            // Added .replace() to replace double spaces with single space.  --- by shravan 
            return (dr["prefix"].ToString() + Convert.ToString(value) + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim().Replace("  "," ");
        }

        public string GetBenefitFormattedValue_Contribtion(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                if (IsNumeric(Convert.ToString(value)))
                {
                    //if (value.Contains('.'))
                    //{
                    //    value = string.Format("{0:#,0.00}", double.Parse(value));
                    //    var finalVal = value.EndsWith(".00") ? value.Substring(0, value.LastIndexOf(".00")) : value;
                    //    value = finalVal;
                    //}
                    //else
                    //{
                    //    value = string.Format("{0:#,0.##}", int.Parse(value));
                    //}
                    value = string.Format("{0:#,0.00}", double.Parse(value));
                }
            }
            return value;
        }
        public string GetBenefitFormattedValue(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                if (IsNumeric(Convert.ToString(value)))
                {
                    if (value.Contains('.'))
                    {
                        value = string.Format("{0:#,0.00}", double.Parse(value));
                        var finalVal = value.EndsWith(".00") ? value.Substring(0, value.LastIndexOf(".00")) : value;
                        value = finalVal;
                    }
                    else
                    {
                        value = string.Format("{0:#,0.##}", int.Parse(value));
                    }
                }
            }
            return value;
        }
        private static bool IsNumeric(string inputValue)
        {
            double Result;
            return double.TryParse(inputValue, out Result);  // TryParse routines were added in Framework version 2.0.
        }

        public static void BuiltDictContactsPlanTypes()
        {
            CommonFunctionsBS comFunObj = new CommonFunctionsBS();
            DictContactsPlanTypes.Clear();

            comFunObj.LoadPlanTypeIds();
            DictContactsPlanTypes.Add("Medical", CommonFunctionsBS.MedicalPlanTypeList);
            DictContactsPlanTypes.Add("Dental", CommonFunctionsBS.DentalPlanTypeList);
            DictContactsPlanTypes.Add("Vision", CommonFunctionsBS.VisionPlanTypeList);

            comFunObj.LoadPlanTypeIds_Pilot();
            DictContactsPlanTypes.Add("Life and AD&D", new List<int>() { 240 });
            DictContactsPlanTypes.Add("Group Term Life", new List<int> { 250 });
            DictContactsPlanTypes.Add("Accidental Death & Dismemberment", new List<int> { 270 });

            DictContactsPlanTypes.Add("Voluntary Life", new List<int> { 260 });
            DictContactsPlanTypes.Add("Voluntary AD&D", new List<int> { 280 });

            DictContactsPlanTypes.Add("Short Term Disability", new List<int> { 290 });
            DictContactsPlanTypes.Add("Long Term Disability", new List<int> { 300 });

            DictContactsPlanTypes.Add("Health Savings Account", new List<int> { 179 });
            DictContactsPlanTypes.Add("Health Reimbursement Account", new List<int> { 178 });

            DictContactsPlanTypes.Add("Flexible Spending Accounts", CommonFunctionsBS.FSAPlanTypeList);
            DictContactsPlanTypes.Add("Employee Assistance Program", CommonFunctionsBS.EAPPlanTypeList);

            DictContactsPlanTypes.Add("Stop Loss Insurance", new List<int> { 235 });

            DictContactsPlanTypes.Add("Patient Advocacy Program", new List<int> { ConstantValue.AdditionalProducts_Patient_Advocacy });
            DictContactsPlanTypes.Add("Telemedicine", new List<int> { ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine });
            DictContactsPlanTypes.Add("Wellness Plan", CommonFunctionsBS.WellnessPlanTypeList);
            DictContactsPlanTypes.Add("Accident Insurance", new List<int> { ConstantValue.AdditionalProducts_Accident });
            DictContactsPlanTypes.Add("Critical Illness", new List<int> { ConstantValue.AdditionalProducts_Voluntary_Critical_Illness });

            //Added by Shravan : for Voluntary Cancer Product for new Benifit Summaries
            DictContactsPlanTypes.Add("Voluntary Cancer", new List<int> { ConstantValue.AdditionalProducts_Voluntary_Cancer });

            DictContactsPlanTypes.Add("401(k) Insurance", new List<int> { 340 });
            DictContactsPlanTypes.Add("Disability Insurance", new List<int> { 294, 293, 292 });
            DictContactsPlanTypes.Add("Business Travel Accident (BTA)", new List<int> { 320 });

            DictContactsPlanTypes.Add("Prescription Drug (Carve-Out)", new List<int> { 173 });

        }
    }

}