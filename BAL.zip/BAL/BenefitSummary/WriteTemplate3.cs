﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate3 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string plan_carrier = "";
        string std_carrier = "";
        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        public void WriteFieldToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                int index = -1;

                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).Year.ToString() + " Plan Year").Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText((renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString()).Trim());
                                        continue;
                                    }

                                    if (fieldName.Contains("unmarriedchildtoage"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText((EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString()).Trim());
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("definitionofdomesticpartner"))
                                    {

                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                            oWordApp.Selection.TypeText(domesticPartner.Trim());
                                            continue;
                                        }
                                    }
                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("EmployeeStatus"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("working"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                            continue;
                                        }

                                        if (fieldName.Contains("frequency"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("unitofmeasure"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("medicalplanwaitingperiod"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                            continue;
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name.Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            if (Phone.ToString() == "")
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Phone.ToString());
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        public void WriteDentalSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, DataTable CarrierSpecific, DataTable PlanTypeSpecific)
        {
            try
            {
                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(9, "45");  //Calendar Year Deductible - Individual
                HashtableDentalInNetwork.Add(8, "44");  //Calendar Year Deductible - Family
                HashtableDentalInNetwork.Add(7, "164"); //Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(6, "64");  //Basic Services – Basic
                HashtableDentalInNetwork.Add(5, "336"); //Major Services – Major
                HashtableDentalInNetwork.Add(4, "392"); //Orthodontic Services
                HashtableDentalInNetwork.Add(3, "55");  //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(2, "314"); //Orthodontia[Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(1, "566"); //Annual Deductible[Deductible waived for Preventive]
                #endregion

                int count = 1;
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string AnnualDeductibleIndividual = string.Empty;
                int dentalCount = 1; //For 3 different dental plans
                int dentalTableNo = 0; //For giving proper table numbers for selected plans
                string value = "";
                int rowCnt = 1;
                bool isRowIncremented = false;
                string Dental_Summary_Plan_1 = string.Empty;
                string Dental_Summary_Plan_2 = string.Empty;
                string Dental_Summary_Plan_3 = string.Empty;
                string Waived_For_Preventive_1 = string.Empty;
                string Waived_For_Preventive_2 = string.Empty;
                string Waived_For_Preventive_3 = string.Empty;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    // Check for only Dental plans from the given PlanTable
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (count == 1)
                        {
                            plan_carrier = "Dental benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".";
                        }
                        // For first dental plan -- Table number is 13
                        if (dentalCount == 1)
                        {
                            Dental_Summary_Plan_1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            dentalTableNo = 13;
                            rowCnt = 1;
                            count = 1;
                        }
                        // For second plan -- Table number is 15
                        else if (dentalCount == 2)
                        {
                            Dental_Summary_Plan_2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            dentalTableNo = 15;
                            rowCnt = 1;
                            count = 1;
                        }
                        // For third plan -- Table number is 17
                        else if (dentalCount == 3)
                        {
                            Dental_Summary_Plan_3 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            dentalTableNo = 17;
                            rowCnt = 1;
                            count = 1;
                        }

                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + "'");

                            #region DentalTable
                            // Iterate the loop for above created HashTable to get the value for selected Key
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                isRowIncremented = false;
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        // Set value = Prefix + Value + Suffix + AncillaryTest + ExclusionsLimitations
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 9: AnnualDeductibleIndividual = value; break;
                                            case 8:
                                                if (!string.IsNullOrEmpty(value))
                                                {
                                                    oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = "\n" + "\n" + AnnualDeductibleIndividual.Trim() + "/" + value.Trim();
                                                }
                                                else
                                                {
                                                    oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = "\n" + "\n" + AnnualDeductibleIndividual.Trim();
                                                }
                                                rowCnt++;
                                                break;
                                            case 7: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = "\n" + value; rowCnt++; break;
                                            case 6: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 5: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 4: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 3: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 2: oWordDoc.Tables[dentalTableNo].Cell(rowCnt, count + 1).Range.Text = value; rowCnt++; break;
                                            case 1:
                                                if (dentalCount == 1)
                                                {
                                                    Waived_For_Preventive_1 = value.Trim();
                                                }
                                                else if (dentalCount == 2)
                                                {
                                                    Waived_For_Preventive_2 = value.Trim();
                                                }
                                                else if (dentalCount == 3)
                                                {
                                                    Waived_For_Preventive_3 = value.Trim();
                                                }
                                                break;
                                        }
                                        isRowIncremented = true;
                                    }
                                }
                                if (isRowIncremented == false)
                                {
                                    // Do not increment the row when Key = 8 because we are not writing any valye for key = 9, we are only taking valye for key = 9 in variable and
                                    // we have already incremented row in the above switch(key)
                                    if (key != 8)
                                    {
                                        rowCnt++;
                                    }
                                }
                            }
                            #endregion

                            #region MergeField
                            int iTotalFields = 0;
                            // Check for each field in the word document to write value for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;
                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Carrier" + dentalCount.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Summary Description 1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Dental_Summary_Plan_1.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Summary Description 2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Dental_Summary_Plan_2.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Summary Description 3"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Dental_Summary_Plan_3.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("General Plan Info – Waived for Preventive 1"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Waived_For_Preventive_1))
                                        {
                                            oWordApp.Selection.TypeText((Waived_For_Preventive_1 + ",").Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.Delete();
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("General Plan Info – Waived for Preventive 2"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Waived_For_Preventive_2))
                                        {
                                            oWordApp.Selection.TypeText((Waived_For_Preventive_2 + ",").Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.Delete();
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("General Plan Info – Waived for Preventive 3"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Waived_For_Preventive_3.Trim()))
                                        {
                                            oWordApp.Selection.TypeText((Waived_For_Preventive_3 + ",").Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.Delete();
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("First Dental Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Your dental benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Specific Text" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                            continue;
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    if (fieldName.Contains("Dental Plan Website"))
                                    {
                                        myMergeField.Select();
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                                            continue;
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                            dentalCount++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, DropDownList ddlDentalNoOfPlan)
        {
            try
            {
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefit = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefit.Add(2, "194");  //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefit.Add(3, "195");  //General Plan Information – Copay – Deductible
                HashtableVisionBenefit.Add(44, "309");   //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(4, "122");   //General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(55, "507");   //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefit.Add(54, "73");    //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefit.Add(53, "553");   //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefit.Add(52, "178");   //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(5, "356");   //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefit.Add(6, "207");   //General Plan Information – Benefit Frequency – Frames
                #endregion

                ArrayList arrVisionBenefit = new ArrayList();
                foreach (int key in HashtableVisionBenefit.Keys)
                {
                    arrVisionBenefit.Add(key);
                }

                arrVisionBenefit.Sort();
                arrVisionBenefit.Reverse();

                string CopayExamination = string.Empty;
                string BenefitFrequency_Examination = string.Empty;
                string BenefitFrequency_Lenses = string.Empty;
                string BenefitFrequency_Contacts = string.Empty;
                string lenses = string.Empty;
                string singleLense = string.Empty;
                string bifocal = string.Empty;
                string trifocal = string.Empty;
                string elective = string.Empty;
                string medical = string.Empty;
                string Vision_Summary_Description_Plan_1 = string.Empty;
                string Vision_Summary_Description_Plan_2 = string.Empty;

                int iTotalFields = 0;
                int count = 1;

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            if (count == 1)
                            {
                                plan_carrier = plan_carrier + "\n\n" + "Vision benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".";
                            }
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable

                            if (count == 1)
                            {
                                Vision_Summary_Description_Plan_1 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                            }
                            if (count == 2)
                            {
                                Vision_Summary_Description_Plan_2 = PlanTable.Rows[rowindex]["SummaryName"].ToString();
                                BenefitFrequency_Lenses = "";
                                singleLense = "";
                                bifocal = "";
                                trifocal = "";
                                elective = "";
                            }

                            foreach (int key in arrVisionBenefit)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 44: BenefitFrequency_Lenses = value; break;
                                                case 55: singleLense = value; break;
                                                case 54: bifocal = value; break;
                                                case 53: trifocal = value; break;
                                                case 52: elective = value; break;
                                                case 4: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + BenefitFrequency_Lenses + "\n" + value; break;
                                                case 5: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + singleLense + "\n" + bifocal + "\n" + trifocal + "\n" + "\n" + elective + "\n" + value; break;

                                                case 2: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + value; break;
                                                case 6: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + value; break;
                                            }
                                            if (key != 44 && key != 55 && key != 54 && key != 53 && key != 52 && key != 4 && key != 5 && key != 2 && key != 6)
                                            {
                                                oWordDoc.Tables[19].Cell(key, 2).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                            switch (key)
                                            {
                                                case 44: BenefitFrequency_Lenses = value; break;
                                                case 55: singleLense = value; break;
                                                case 54: bifocal = value; break;
                                                case 53: trifocal = value; break;
                                                case 52: elective = value; break;
                                                case 4: oWordDoc.Tables[21].Cell(key, 2).Range.Text = "\n" + BenefitFrequency_Lenses + "\n" + value; break;
                                                case 5: oWordDoc.Tables[21].Cell(key, 2).Range.Text = "\n" + singleLense + "\n" + bifocal + "\n" + trifocal + "\n" + "\n" + elective + "\n" + value; break;
                                                case 2: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + value; break;
                                                case 6: oWordDoc.Tables[19].Cell(key, 2).Range.Text = "\n" + value; break;
                                            }
                                            if (key != 44 && key != 55 && key != 54 && key != 53 && key != 52 && key != 4 && key != 5 && key != 2 && key != 6)
                                            {
                                                oWordDoc.Tables[21].Cell(key, 2).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            // Iterate through each field in word document to write values for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Vision Plan Carrier" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Plan Summary Description 1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Vision_Summary_Description_Plan_1.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Plan Summary Description 2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Vision_Summary_Description_Plan_2.Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("First Vision Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        if (ddlDentalNoOfPlan.SelectedIndex > 0)
                                        {
                                            oWordApp.Selection.TypeText(("and vision benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".").Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(("Your vision benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".").Trim());
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                        continue;
                                    }

                                    if (foundRows.Count() > 0)
                                    {
                                        if (fieldName.Contains("Vision Plan Website"))
                                        {
                                            myMergeField.Select();
                                            if (foundRows.Count() > 0)
                                            {
                                                oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                                                continue;
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlSTDPlanName)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(6, "71");  //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(5, "569"); //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(4, "8");   //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(3, "505"); //STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(2, "350"); //STD General Information – Maximum Period of Payment
                #endregion

                string Accident = string.Empty;
                string ProductName = "";
                int rowCnt = 2;
                bool isRowIncremented = false;

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                isRowIncremented = false;
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        // value = Prefix + Value + AncillaryText + ExclusionsLimitations
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 6: oWordDoc.Tables[28].Cell(rowCnt, count + 1).Range.Text = value.Trim(); rowCnt++; break;
                                            case 5: oWordDoc.Tables[28].Cell(rowCnt, count + 1).Range.Text = value.Trim(); rowCnt++; break;
                                            case 4: Accident = value.Trim(); break;
                                            case 3: oWordDoc.Tables[28].Cell(rowCnt, count + 1).Range.Text = Accident.Trim() + " / " + value.Trim(); rowCnt++; break;
                                            case 2: oWordDoc.Tables[28].Cell(rowCnt, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim(); rowCnt++; break;
                                        }

                                        isRowIncremented = true;
                                    }
                                }
                                if (isRowIncremented == false)
                                {
                                    // We are not incrementing row count for key = 3 because we have already incremented row count for that key in the above switch (key) code
                                    if (key != 3)
                                    {
                                        rowCnt++;
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            // Iterate through each field in the word document to write value for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VlSTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("STDTable"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }

                                    if (fieldName.Contains("MainTableSTDLTD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        std_carrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                        oWordApp.Selection.TypeText(std_carrier);
                                        continue;
                                    }
                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                        continue;
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        continue;
                                    }

                                    if (fieldName.Contains("VoluntarySTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Short Term Disability Premium Calculation");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        public void WriteLTDSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDPlanName)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableLTD
                HashtableLTD.Add(7, "71");  //General Plan Information – Benefit Percentage
                HashtableLTD.Add(6, "374"); //General Plan Information – Weekly Benefit Maximum
                HashtableLTD.Add(5, "8");   //STD General Information – Elimination Period – Accident
                HashtableLTD.Add(4, "505"); //STD General Information – Elimination Period –Sickness
                HashtableLTD.Add(3, "351"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(2, "449"); //General Plan Information – Pre-Existing Condition Limitations
                #endregion

                string Accident = string.Empty;
                int rowCnt = 2;
                string value = "";
                bool isRowIncremented = false;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                isRowIncremented = false;
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        // value = Prefix + Value + AncillaryText + ExclusionsLimitations
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 7: oWordDoc.Tables[29].Cell(rowCnt, count + 1).Range.Text = value.Trim(); rowCnt++; break;
                                            case 6: oWordDoc.Tables[29].Cell(rowCnt, count + 1).Range.Text = value.Trim(); rowCnt++; break;
                                            case 5: Accident = value.Trim(); break;
                                            case 4: oWordDoc.Tables[29].Cell(rowCnt, count + 1).Range.Text = Accident.Trim() + " / " + value.Trim(); rowCnt++; break;
                                            case 3: oWordDoc.Tables[29].Cell(rowCnt, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim(); rowCnt++; break;
                                            case 2: oWordDoc.Tables[29].Cell(rowCnt, count + 1).Range.Text = value.Trim(); rowCnt++; break;
                                        }
                                        isRowIncremented = true;
                                    }
                                }
                                if (isRowIncremented == false)
                                {
                                    // We are not incrementing row count for key = 4 because we have already incremented row count for key = 4 in the above switch (key) code
                                    if (key != 4)
                                    {
                                        rowCnt++;
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            // Interate through each field in the word document to write values for that field
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("VlLTD"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDPlanName.SelectedItem.Text.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("LTDTable"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("MainTableSTDLTD"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDNoOfPlan.SelectedIndex > 0)
                                        {
                                            if (std_carrier != PlanTable.Rows[rowindex]["Carrier"].ToString().Trim())
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                        continue;
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        continue;
                                    }
                                    if (fieldName.Contains("VoluntaryLTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Long Term Disability Premium Calculation");
                                            continue;
                                        }
                                    }

                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteContactinformationToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 3;
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                DataRow[] foundRows = null;
                int cnt = 2;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 2;
                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    carrier = oWordDoc.Tables[count].Cell(cnt, 1).Range.Text;
                    description_Policy = oWordDoc.Tables[count].Cell(cnt, 2).Range.Text;
                    website_phone = oWordDoc.Tables[count].Cell(cnt, 3).Range.Text.Replace("\r\r", "\r");
                }

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        if (plantype != "STD Plan" && plantype != "LTD Plan")
                        {
                            if (k > 1)
                            {
                                oWordDoc.Tables[count].Rows.Add();
                            }
                            carriername = PlanTable.Rows[i]["Carrier"].ToString();
                            plantype = PlanTable.Rows[i]["PlanType"].ToString();
                            ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                            oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                            oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString()) + " / " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (foundRows.Count() > 0)
                            {
                                if (PlanTable.Rows[i]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                                {
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "Member Services " + Convert.ToString(foundRows[0]["PhoneNumber"].ToString()) + "\n" + Convert.ToString(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                                    }
                                }
                                else if (PlanTable.Rows[i]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                                {
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "Employee Benefit Hotline " + Convert.ToString(foundRows[0]["PhoneNumber"].ToString()) + "\n" + Convert.ToString(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                                    }
                                }
                                else if (PlanTable.Rows[i]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                                {
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "Employee Benefit Hotline " + Convert.ToString(foundRows[0]["PhoneNumber"].ToString()) + "\n" + Convert.ToString(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                                    }
                                }
                                else if (PlanTable.Rows[i]["PlanType"].ToString().ToLower().Trim() == cv.LifeADDPlanType.ToLower().Trim())
                                {
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "Customer Service " + Convert.ToString(foundRows[0]["PhoneNumber"].ToString()) + "\n" + Convert.ToString(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                                    }
                                }
                                else
                                {
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(foundRows[0]["PhoneNumber"].ToString()) + "\n" + Convert.ToString(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                                    }
                                }
                            }
                            k++;
                            rowCnt++;
                        }
                    }
                }
                // Add client information at the end 
                rowCnt = 0;
                rowCnt = oWordDoc.Tables[count].Rows.Count;
                if (!string.IsNullOrEmpty(carrier))
                {
                    oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = carrier.Replace("\r", "").Trim();

                }
                if (!string.IsNullOrEmpty(description_Policy))
                {
                    oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = description_Policy.Replace("\r", "").Trim();

                }
                if (!string.IsNullOrEmpty(website_phone))
                {
                    oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = website_phone.Replace("\r", "").Trim();
                }

                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                }

                oWordDoc.Tables[count].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                oWordDoc.Tables[count].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write Voluntary STD  and LTD Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();

                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                int Start = 0;
                int End = 0;
                int Interval = 0;

                int rowCnt = 2;
                int ColumnCount = 0;
                int oldageBand = -1;
                int PlanCount = 0;
                DataTable dt = new DataTable();
                int tableNo = 0;

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower())
                        {
                            tableNo = 30;
                        }
                        else if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                        {
                            tableNo = 31;
                            PlanCount = 0;
                        }

                        PlanCount++;
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"] != null)
                        {
                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"] != null)
                        {
                            End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"] != null)
                        {
                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;
                        }
                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        int StartValue = Start;
                        int RowCount = 3;

                        if (Start > 0 && PlanCount == 1)
                        {
                            oWordDoc.Tables[tableNo].Cell(rowCnt, 1).Range.Text = "Under " + Start.ToString();

                            while (StartValue < End - 1)
                            {
                                oWordDoc.Tables[tableNo].Rows.Add();
                                if (StartValue == Start)
                                {
                                    oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                    StartValue = Start + Interval;
                                }
                                else
                                {
                                    oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                    StartValue = StartValue + Interval + 1;
                                }
                                RowCount++;
                            }
                            oWordDoc.Tables[tableNo].Rows.Add();
                            oWordDoc.Tables[tableNo].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                            oWordDoc.Tables[tableNo].Rows.Add();
                            oWordDoc.Tables[tableNo].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        }

                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 1;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.STDPlanType)
                            {
                                ColumnCount = 2;
                            }

                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.LTDPlanType)
                            {
                                ColumnCount = 2;
                            }
                            if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                            {
                                RowCount++;
                            }
                            oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());
                            oWordDoc.Tables[tableNo].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                        }
                    }


                    #region FormatTable
                    if (PremiumTable.Rows.Count > 0)
                    {
                        foreach (Word.Border border in oWordDoc.Tables[tableNo].Borders)
                        {
                            border.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                        }

                        oWordDoc.Tables[tableNo].Range.Borders[Word.WdBorderType.wdBorderDiagonalDown].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                        oWordDoc.Tables[tableNo].Range.Borders[Word.WdBorderType.wdBorderDiagonalUp].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                        oWordDoc.Tables[tableNo].Rows.Alignment = Microsoft.Office.Interop.Word.WdRowAlignment.wdAlignRowCenter;

                        object sortfield = 1;

                        for (int k = 2; k < oWordDoc.Tables[tableNo].Rows.Count + 1; k++)
                        {
                            oWordDoc.Tables[tableNo].Rows[k].Range.Paragraphs.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                            oWordDoc.Tables[tableNo].Rows[k].Range.Font.Color = Word.WdColor.wdColorBlack;
                        }
                    }

                    #endregion
                }

                if (tableNo != 0)
                {
                    ColumnCount = oWordDoc.Tables[tableNo].Columns.Count;
                    bool flag = false;
                    if (oWordDoc.Tables[tableNo].Rows.Count < 5)
                    {
                        oWordDoc.Tables[tableNo].Delete();
                    }
                    else
                    {
                        while (ColumnCount > 1)
                        {
                            for (int i = rowCnt; i < oWordDoc.Tables[tableNo].Rows.Count; i++)
                            {
                                if (oWordDoc.Tables[tableNo].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
                                {
                                    flag = false;
                                    break;
                                }
                                else
                                {
                                    flag = true;
                                }
                            }
                            if (flag == true)
                            {
                                oWordDoc.Tables[tableNo].Columns[ColumnCount].Delete();
                            }
                            ColumnCount--;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(3, "45");//Calendar Year Deductible indivisual
                HashtableMedicalInNetwork1.Add(4, "44");//Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(6, "112");//General Plan Information Coinsurence
                HashtableMedicalInNetwork1.Add(8, "53");//Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalInNetwork1.Add(9, "52");//Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalInNetwork1.Add(11, "386");//Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(12, "414");//Specialists Office Visit
                HashtableMedicalInNetwork1.Add(14, "16");//Preventive Care
                HashtableMedicalInNetwork1.Add(16, "295");//Inpatient Hospitalization
                HashtableMedicalInNetwork1.Add(18, "184");//Emergency Room

                Hashtable HashtableMedicalInNetwork2 = new Hashtable();

                HashtableMedicalInNetwork2.Add(3, "555");//Urgent Care
                HashtableMedicalInNetwork2.Add(5, "168");//Lab and Care (Diagnostic X-Ray and Lab Tests)



                #endregion
                #region HashtableMedicalOutNetwork
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedicalOutNetwork.Add(3, "45");//Calendar Year Deductible indivisual
                HashtableMedicalOutNetwork.Add(4, "44");//Calendar Year Deductible Family
                HashtableMedicalOutNetwork.Add(6, "112");//General Plan Information Coinsurence
                HashtableMedicalOutNetwork.Add(8, "53");//Calendar Year Out of Pocket Maximum(Indivisual)
                HashtableMedicalOutNetwork.Add(9, "52");//Calendar Year Out of Pocket Maximum(Family)
                HashtableMedicalOutNetwork.Add(11, "386");//Physician Office Visit (Primary)
                HashtableMedicalOutNetwork.Add(12, "414");//Specialists Office Visit
                HashtableMedicalOutNetwork.Add(14, "16");//Preventive Care
                HashtableMedicalOutNetwork.Add(16, "295");//Inpatient Hospitalization
                HashtableMedicalOutNetwork.Add(18, "184");//Emergency Room

                Hashtable HashtableMedicalOutNetwork2 = new Hashtable();
                HashtableMedicalOutNetwork2.Add(3, "555");//Urgent Care
                HashtableMedicalOutNetwork2.Add(5, "168");//Lab and Care (Diagnostic X-Ray and Lab Tests)

                #endregion

                int count = 1;
                string AnnualDeductible = "";
                string OfficeVisit = "";
                string medicalcarrier = "";

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            if (count == 1)
                            {
                                oWordDoc.Tables[4].Cell(1, count).Select();
                                oWordDoc.Tables[4].Cell(1, count).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[7].Cell(1, 1).Select();
                                oWordDoc.Tables[7].Cell(1, 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(1, 1).Select();
                                oWordDoc.Tables[10].Cell(1, 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString() + " " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[rowindex]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"];
                            }

                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[7].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[10].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            foreach (int key in HashtableMedicalInNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork2[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[8].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[11].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[7].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[10].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalOutNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork2[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[8].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[11].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (count == 1)
                                    {
                                        if (fieldName.Contains("Medical Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (count == 2)
                                    {
                                        if (fieldName.Contains("Medical Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (count == 3)
                                    {
                                        if (fieldName.Contains("Medical Benefit Summary Description3"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }

                            #endregion
                            medicalcarrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                int rowcount = 11;
                int colcount = 2;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");//Prescription Categories[Non Formulary]
                // HashtablePrescriptionDrugs.Add(4, "380");//Prescription Categories[Maximum Day Supply]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");//Prescription Categories[Non Formulary]
                // HashtablePrescriptionDrugs_OutNetwork.Add(4, "380");//Prescription Categories[Maximum Day Supply]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");//Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "378");//Mail Order[Maximum Day Supply]
                #endregion

                #region MailOrder_OutNetwork
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                HashtableMailOrder_OutNetwork.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder_OutNetwork.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder_OutNetwork.Add(3, "82");//Mail Order[Non Formulary]
                //  HashtableMailOrder_OutNetwork.Add(4, "378");//Mail Order[Maximum Day Supply]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    # region Priscription Drugs IN_Network

                    value = "";
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                        }
                                    }
                                }
                            }
                            //7,8,9 are the row numbers of Prescription Drugs  Teble 5 
                            if (count == 1)
                            {
                                oWordDoc.Tables[5].Cell(7, colcount).Range.Text = Generic; //row 7
                                oWordDoc.Tables[5].Cell(8, colcount).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[5].Cell(9, colcount).Range.Text = NonFormulary;////row 9
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(7, colcount).Range.Text = Generic; //row 7
                                oWordDoc.Tables[8].Cell(8, colcount).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[8].Cell(9, colcount).Range.Text = NonFormulary;////row 9
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[11].Cell(7, colcount).Range.Text = Generic; //row 7 column2
                                oWordDoc.Tables[11].Cell(8, colcount).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[11].Cell(9, colcount).Range.Text = NonFormulary;////row 9
                            }
                    #endregion

                            # region Priscription Drugs Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";

                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                        }
                                    }
                                }
                            }

                            if (count == 1)
                            {
                                oWordDoc.Tables[5].Cell(7, 3).Range.Text = Generic; //row 7
                                oWordDoc.Tables[5].Cell(8, 3).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[5].Cell(9, 3).Range.Text = NonFormulary;////row 9
                            }

                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(7, 3).Range.Text = Generic; //row 7
                                oWordDoc.Tables[8].Cell(8, 3).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[8].Cell(9, 3).Range.Text = NonFormulary;////row 9
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[11].Cell(7, 3).Range.Text = Generic; //row 7 column2
                                oWordDoc.Tables[11].Cell(8, 3).Range.Text = Formulary;//row 8
                                oWordDoc.Tables[11].Cell(9, 3).Range.Text = NonFormulary;////row 9
                            }
                            #endregion

                            #region Mail Order In_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                //oWordDoc.Tables[5].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;//
                                oWordDoc.Tables[5].Cell(11, 2).Range.Text = Generic; //row 11
                                oWordDoc.Tables[5].Cell(12, 2).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[5].Cell(13, 2).Range.Text = NonFormulary;////row 13
                            }

                            if (count == 2)
                            {
                                //oWordDoc.Tables[8].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;
                                oWordDoc.Tables[8].Cell(11, 2).Range.Text = Generic; //row 11
                                oWordDoc.Tables[8].Cell(12, 2).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[8].Cell(13, 2).Range.Text = NonFormulary;////row 13
                            }
                            if (count == 3)
                            {
                                // oWordDoc.Tables[11].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;
                                oWordDoc.Tables[11].Cell(11, 2).Range.Text = Generic; //row 11 column2
                                oWordDoc.Tables[11].Cell(12, 2).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[11].Cell(13, 2).Range.Text = NonFormulary;////row 13
                            }
                            #endregion

                            #region Mail Order Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";

                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value; break;
                                            case 2: Formulary = "Formulary: " + value; break;
                                            case 3: NonFormulary = "Non Formulary: " + value; break;
                                        }
                                    }
                                }
                            }
                            if (count == 1)
                            {
                                //oWordDoc.Tables[5].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;//
                                oWordDoc.Tables[5].Cell(11, 3).Range.Text = Generic; //row 11
                                oWordDoc.Tables[5].Cell(12, 3).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[5].Cell(13, 3).Range.Text = NonFormulary;////row 13
                            }

                            if (count == 2)
                            {
                                //oWordDoc.Tables[8].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;
                                oWordDoc.Tables[8].Cell(11, 3).Range.Text = Generic; //row 11
                                oWordDoc.Tables[8].Cell(12, 3).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[8].Cell(13, 3).Range.Text = NonFormulary;////row 13
                            }
                            if (count == 3)
                            {
                                // oWordDoc.Tables[11].Cell(rowcount, 2).Range.Text = Generic + Formulary + NonFormulary;
                                oWordDoc.Tables[11].Cell(11, 3).Range.Text = Generic; //row 11 column2
                                oWordDoc.Tables[11].Cell(12, 3).Range.Text = Formulary;//row 12
                                oWordDoc.Tables[11].Cell(13, 3).Range.Text = NonFormulary;////row 13
                            }

                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// 
        public void WriteMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int DentalCount = 0;
                int VisionCount = 0;

                //Effective dates of Medical plans
                string Medicaleffective1 = "";
                string Medicaleffective2 = "";
                string Medicaleffective3 = "";

                //Effective dates of Dental plans
                string Dentaleffective1 = "";
                string Dentaleffective2 = "";
                string Dentaleffective3 = "";

                //Effective dates of Vision Plans
                string Visioneffective1 = "";
                string Visioneffective2 = "";

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"];
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                premium_row_counter++;
                            }
                        }
                    }

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);

                    // Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                    //// The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    //for (int k = 0; k < dt.Rows.Count; k++)
                    //{
                    //    if (Convert.ToDecimal(dt.Rows[k]["monthlycost"]) == 0)
                    //    {
                    //        dt.Rows[k].Delete();
                    //        k = k - 1;
                    //    }
                    //}

                    PremiumTable = dt;

                    DataTable dt1 = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt1 = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt1;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Medicaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }

                        }
                        if (index == 1)
                        {
                            Medicaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (index == 2)
                        {
                            Medicaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Dentaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            Dentaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (DentalCount == 2)
                        {
                            Dentaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();//effective date
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Visioneffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            Visioneffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 0;
                for (int d = 1; d < PremiumTableWriteMedical.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        MediCalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[6].Rows.Add();
                                }
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[9].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective2;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[9].Rows.Add();
                                }
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[12].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective3;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[12].Rows.Add();
                                }

                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;

                            }
                        }
                    }
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[14].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[14].Rows.Add();
                                }
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[16].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[16].Rows.Add();
                                }
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[18].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[18].Rows.Add();
                                }
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion

                #region Vision Monthly Premium

                int VisionTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[20].Cell(1, 2).Range.Text = "Effective: " + Visioneffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[20].Rows.Add();
                                }
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[22].Cell(1, 2).Range.Text = "Effective: " + Visioneffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[22].Rows.Add();
                                }
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /* Plz do not delete this function, when will ask for rate values only then we need to delete comments for this function
        public void WriteMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 1;
                int Dentalindex = 2;
                int DentalCount = 0;
                int VisionCount = 0;

                //Effective dates of Medical plans
                string Medicaleffective1 = "";
                string Medicaleffective2 = "";
                string Medicaleffective3 = "";

                //Effective dates of Dental plans
                string Dentaleffective1 = "";
                string Dentaleffective2 = "";
                string Dentaleffective3 = "";

                //Effective dates of Vision Plans
                string Visioneffective1 = "";
                string Visioneffective2 = "";




                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");


                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {

                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));


                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {

                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }
                                }
                                premium_row_counter++;
                            }
                        }
                    }

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Medicaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }

                        }
                        if (index == 1)
                        {
                            Medicaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (index == 2)
                        {

                            Medicaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }


                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Dentaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            Dentaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (DentalCount == 2)
                        {
                            Dentaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();//effective date
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Visioneffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            Visioneffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 0;
                for (int d = 1; d < PremiumTableWriteMedical.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        MediCalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[6].Rows.Add();
                                }
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[9].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective2;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[9].Rows.Add();
                                }
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[12].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective3;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[12].Rows.Add();
                                }

                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;

                            }
                        }
                    }
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[14].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[14].Rows.Add();
                                }
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[16].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[16].Rows.Add();
                                }
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[18].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[18].Rows.Add();
                                }
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion

                #region Vision Monthly Premium

                int VisionTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[20].Cell(1, 2).Range.Text = "Effective: " + Visioneffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[20].Rows.Add();
                                }
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[22].Cell(1, 2).Range.Text = "Effective: " + Visioneffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[22].Rows.Add();
                                }
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        */

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();
                //List<string> RateDescList = new List<string>();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }

                        #region For EE Unismoker
                        oWordDoc.Tables[25].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                        int StartValue = Start;
                        int RowCount = 4;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[25].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[25].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[25].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[25].Rows.Add();
                        oWordDoc.Tables[25].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[25].Rows.Add();
                        oWordDoc.Tables[25].Cell(RowCount + 1, 1).Range.Text = "Composite";

                        int ColumnCount = 0;
                        int oldageBand = -1;
                        DataTable dt = new DataTable();

                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 2;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                oWordDoc.Tables[25].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount++;
                            }
                        }
                        #endregion

                        #region For SpouseUnismoker
                        oWordDoc.Tables[27].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                        StartValue = Start;
                        RowCount = 4;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[27].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[27].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[27].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[27].Rows.Add();
                        oWordDoc.Tables[27].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[27].Rows.Add();
                        oWordDoc.Tables[27].Cell(RowCount + 1, 1).Range.Text = "Composite";

                        RowCount = 2;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker")
                            {
                                ColumnCount = 2;
                                oWordDoc.Tables[27].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount++;
                            }

                        }
                        # endregion
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;
                int count = 1;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";
                string EmployeeIssueAmt = "";
                string age = "";
                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(1, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(2, "187");//Employee [Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(3, "519");//Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(4, "518");//Spouse[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(5, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(6, "103");//Child(ren)[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(7, "2");//age
                HashtableVoluntaryLifeADDBenifit.Add(8, "3");//age
                HashtableVoluntaryLifeADDBenifit.Add(9, "4");//age
                HashtableVoluntaryLifeADDBenifit.Add(10, "5");//age



                #endregion
                string GuarenteeIssueAmtEmp = "";
                string GuarenteeIssueAmtSpouse = "";
                string GuarenteeIssueAmtChild = "";

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region VoluntaryLifeADDBenifitTable
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: OverallMaximumEmployee = value; break;
                                            case 2: GuarenteeIssueAmtEmp = value; break;
                                            case 3: OverallMaximumSpouse = value; break;
                                            case 4: GuarenteeIssueAmtSpouse = value; break;
                                            case 5: OverallMaximumChild = value; break;
                                            case 6: GuarenteeIssueAmtChild = value; break;
                                            case 187: EmployeeIssueAmt = value; break;
                                        }

                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 187: EmployeeIssueAmt = value; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[24].Cell(1, 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            oWordDoc.Tables[24].Cell(4, 2).Range.Text = OverallMaximumEmployee;
                            oWordDoc.Tables[24].Cell(5, 2).Range.Text = GuarenteeIssueAmtEmp;

                            oWordDoc.Tables[24].Cell(7, 2).Range.Text = OverallMaximumSpouse;
                            oWordDoc.Tables[24].Cell(8, 2).Range.Text = GuarenteeIssueAmtSpouse;

                            oWordDoc.Tables[24].Cell(10, 2).Range.Text = OverallMaximumChild;
                            oWordDoc.Tables[24].Cell(11, 2).Range.Text = GuarenteeIssueAmtChild;

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Life_ADD_Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life and Accidental Death and Dismemberment Benefits");
                                    }
                                    if (fieldName.Contains("First Selected Voluntary Life Carrier1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    if (fieldName.Contains("First Selected Voluntary Life Carrier2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    //Change Done on 3 July 2014
                                    if (fieldName.Contains("Reduction of Benefit Schedule Return Age"))
                                    {
                                        myMergeField.Select();
                                        if (age != "")
                                        {
                                            oWordApp.Selection.TypeText("Benefits begin to reduce at " + age.Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    if (fieldName.Contains("Guarantee Issue Amount  Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(EmployeeIssueAmt.Trim());
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLifeADDToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DataTable CarrierSpecific)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 0;
                DataRow[] foundRows = null;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string value = "";
                string EmployeeIssueAmt = "";
                string age = "";
                //int benefitamount = 0;
                string benefitamount = "";
                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186");//Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(2, "187");//Employee Issue Amount
                HashtableGroupLifeADDBenifit.Add(3, "2");//age
                HashtableGroupLifeADDBenifit.Add(4, "3");//age
                HashtableGroupLifeADDBenifit.Add(5, "4");//age
                HashtableGroupLifeADDBenifit.Add(6, "5");//age

                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            if (count == 0)
                            {
                                plan_carrier = plan_carrier + "\n\n" + "Life and disability benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".";
                            }
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region GroupLifeADDBenifitTable
                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = "65"; } break; // 65-69
                                            case 3: if (value.Trim() != string.Empty) { age = "70"; } break; // 70-74
                                            case 4: if (value.Trim() != string.Empty) { age = "75"; } break; // 75-79
                                            case 5: if (value.Trim() != string.Empty) { age = "80"; } break; // 80-84
                                            case 186: benefitamount = value; break;
                                            case 187: EmployeeIssueAmt = value; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[23].Cell(1, 1).Range.Text = PlanTable.Rows[rowindex]["Carrier"].ToString();
                            oWordDoc.Tables[23].Cell(4, 1).Range.Text = benefitamount.ToString();
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Life_ADD_Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Life and Accidental Death and Dismemberment Benefits");
                                    }
                                    if (fieldName.Contains("Life ADD Carrier1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("LifeADD1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    if (fieldName.Contains("LifeADD2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    if (fieldName.Contains("First Life ADD Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Your life and disability benefits will be offered through " + PlanTable.Rows[rowindex]["Carrier"].ToString() + ".".Trim());
                                    }
                                }
                            }
                        }
                            #endregion
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlLifeADD, DropDownList ddlVoluntaryADD, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                bool flag = false;
                bool flag1 = false;

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex == 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("Annual_Notice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("OtherProducts"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                //  myMergeField.Select();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag1 == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag1 = false;
                                }

                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePlanCarrierTemplate3(Word.Document oWordDoc, Word.Application oWordApp)
        {
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Plan_Carrier_Field"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(plan_carrier);
                    }
                }
            }

            #endregion
        }
    }
}
