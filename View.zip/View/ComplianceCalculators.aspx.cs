﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BenefitPointSummaryPortal.Common.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.ServiceCalendar;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;
using BenefitPointSummaryPortal.BAL.RFPReports;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.BAL.Compliance;

namespace BenefitPointSummaryPortal.View
{
    public partial class ComplianceCalculators : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string SessionId = "";

        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        SummaryDetail sdd = new SummaryDetail();
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                DictDepartment = sdd.getDepartmentDetails();
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
                if (!IsPostBack)
                {
                    mvCmplianceCalculator.ActiveViewIndex = 0;
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    Activity = "Compliance Calculators";
                    Activity_Group = "Compliance";
                    ddlCalculatorOption_SelectedIndexChanged(null, null);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {            
            ResetForm();
        }
        private void ResetForm()
        {
            ddlCalculatorOption.SelectedIndex = 0;
            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
            rdlClient.SelectedIndex = 0;
            ddlCalculatorOption_SelectedIndexChanged(null, null);
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            if (Session["Summary"].ToString() == "ComplianceCalculators")
            {
                SessionId = Session["SessionId"].ToString();
                if (ValidateForm())
                {
                    if (ddlCalculatorOption.SelectedValue == "PCOR")
                    {
                        CreateComplianceCalculatorPCORTemplate();
                    }
                    else if (ddlCalculatorOption.SelectedValue == "Excise_Tax")
                    {
                        CreateComplianceCalculatorsExciseTaxTemplate();
                    }
                    else if (ddlCalculatorOption.SelectedValue == "ESR")
                    {
                        DownLoad_ComplianceCalculatorESRpopulatedTemplate();
                    }
                    else if (ddlCalculatorOption.SelectedValue == "ALE")
                    {
                        DownLoad_ComplianceCalculatorHCRpopulatedTemplate();
                    }
                    else if (ddlCalculatorOption.SelectedValue == "Wellness")
                    {
                        CreateComplianceCalculatorWellness();
                    }

                    #region Storing the Activity Logs

                    List<Contact> ContactList = new List<Contact>();
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    sdd.BuildAccountTable();
                    AccountDS = sdd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sdd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    string Office_Region = Account_Region + " / " + Account_Office;
                    string AdditionalCrtieriaOption_1 = ddlCalculatorOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = string.Empty;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion
                }
            }
        }
        private void DownLoad_ComplianceCalculatorESRpopulatedTemplate()
        {
            try
            {
                string myPath = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/ESRCalculator_Template.xlsx");

                string savefilename = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/"));
                }
                File.Copy(myPath, savefilename, true);
                DownloadFileNew_ExcelFormat(savefilename.ToString());
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
            }

        }
        private void DownLoad_ComplianceCalculatorHCRpopulatedTemplate()
        {
            try
            {
                string myPath = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/HCRCalculator_Template.xlsm");

                string savefilename = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsm");

                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/"));
                }
                File.Copy(myPath, savefilename, true);
                DownloadFileNew_ExcelFormat(savefilename);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
            }

        }
        protected void CreateComplianceCalculatorPCORTemplate()
        {
            SummaryDetail sd = new SummaryDetail();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/PCORCalculator_Template.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                WriteTemplate_ComplianceCalculators wr = new WriteTemplate_ComplianceCalculators();
                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Summary of Fee Costs";
                wr.WriteFields_CompliancePCORCalculatorsTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text);
                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();
                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        protected void CreateComplianceCalculatorsExciseTaxTemplate()
        {
            SummaryDetail sd = new SummaryDetail();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/ExciseTaxCalculator_Template.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                WriteTemplate_ComplianceCalculators wr = new WriteTemplate_ComplianceCalculators();
                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Excise Tax Calculator 2018";

                wr.WriteFields_ComplianceCalculatorsExciseTaxTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text);

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        protected void CreateComplianceCalculatorWellness()
        {
            SummaryDetail sd = new SummaryDetail();
            Excel.Application myExcelApp = null;
            Excel.Workbook myWorkbook = null;
            Excel.Worksheet myWorksheet = null;
            try
            {
                SessionId = Session["SessionId"].ToString();

                myExcelApp = new Excel.Application();
                myExcelApp.Visible = false;
                Object missing = System.Reflection.Missing.Value;

                string myPath = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Wellness_Calculator_Mar_20191.xlsx");

                myExcelApp.DisplayAlerts = false;
                myWorkbook = myExcelApp.Workbooks.Open(myPath);
                myWorksheet = myWorkbook.ActiveSheet;

                object savefilename = Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                    System.DateTime.Now.Month.ToString() +
                                     System.DateTime.Now.Day.ToString() +
                                      System.DateTime.Now.Hour.ToString() +
                                       System.DateTime.Now.Minute.ToString() +
                                      System.DateTime.Now.Second.ToString() +
                                      System.DateTime.Now.Millisecond.ToString() +
                                     ".xlsx");

                if (!Directory.Exists(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Compliance/Documents/Templates/ComplianceCalculator/Downloads/"));
                }

                myWorkbook.SaveAs(savefilename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing,
                  Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                WriteTemplate_ComplianceCalculators wr = new WriteTemplate_ComplianceCalculators();
                string SummaryName_SheetName = string.Empty;
                SummaryName_SheetName = "Wellness Calculator";
                DateTime dtRenewalDate = GetDate(txtRenewalDate.Text.Trim());
                wr.WriteFields_ComplianceCalculatorWellnessTemplate(myExcelApp, myWorkbook, SummaryName_SheetName, ddlClient.SelectedItem.Text, dtRenewalDate);

                myWorkbook.Save();
                myWorkbook.Close(true, Type.Missing, Type.Missing);
                myExcelApp.Quit();

                DownloadFileNew_ExcelFormat(savefilename.ToString());

                Marshal.FinalReleaseComObject(myWorksheet);
                myWorksheet = null;
                Marshal.FinalReleaseComObject(myWorkbook);
                myWorkbook = null;
                Marshal.FinalReleaseComObject(myExcelApp);
                myExcelApp = null;

                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }

                if (myExcelApp != null)
                {
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myWorksheet != null)
                {
                    Marshal.FinalReleaseComObject(myWorksheet);
                    myWorksheet = null;
                }
                if (myWorkbook != null)
                {
                    myWorkbook.Close();
                    Marshal.FinalReleaseComObject(myWorkbook);
                    myWorkbook = null;
                }
                if (myExcelApp != null)
                {
                    myExcelApp.Quit();
                    Marshal.FinalReleaseComObject(myExcelApp);
                    myExcelApp = null;
                    GC.Collect();
                }

                //// kill the right process after export completed
                //KillExcel();

                Process[] excelProcs = Process.GetProcessesByName("Excel");
                foreach (Process proc in excelProcs)
                {
                    // proc.Kill();
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

            }
        }
        public void DownloadFileNew_ExcelFormat(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlCalculatorOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            trRenewalDate.Style.Add("display", "none");
            tblWellnessInstruction.Style.Add("display", "none");
            txtRenewalDate.Text = string.Empty;
            switch (ddlCalculatorOption.SelectedValue)
            {
                case "Wellness":
                    trRenewalDate.Style.Add("display", "");
                    tblWellnessInstruction.Style.Add("display", "");
                    break;
                default:
                    break;
            }
        }
        private bool ValidateForm()
        {
            if (ddlCalculatorOption.SelectedIndex == 0 || ddlCalculatorOption.SelectedIndex == -1)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Calculator Option.')</script>");
                ddlCalculatorOption.Focus();
                return false;
            }
            if (ddlCalculatorOption.SelectedValue == "ALE" || ddlCalculatorOption.SelectedValue == "ESR" || ddlCalculatorOption.SelectedValue == "Wellness" || ddlCalculatorOption.SelectedValue == "Excise_Tax" || ddlCalculatorOption.SelectedValue == "PCOR")
            {
                if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client Name.')</script>");
                    ddlClient.Focus();
                    return false;
                }
                if (ddlCalculatorOption.SelectedValue == "Wellness")
                {
                    if (txtRenewalDate.Text.Trim() == string.Empty)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Renewal Date.')</script>");
                        txtRenewalDate.Focus();
                        return false;
                    }
                    if (!IsValidDate(txtRenewalDate.Text.Trim()))
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Invalid Renewal Date. Date format should be MM/DD/YYYY')</script>", false);
                        txtRenewalDate.Focus();
                        return false;
                    }
                }
            }
            return true;
        }
        private bool IsValidDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private DateTime GetDate(string strDate)
        {
            string[] formats = { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
            try
            {
                DateTime dtDates = DateTime.ParseExact(strDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                return dtDates;
            }
            catch (Exception ex)
            {
                return DateTime.MinValue;
            }
        }
    }
}