﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;



namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class SessionBPSummaryLogin
    {
        /// <summary>
        /// Get Session ID using Webservice BP_LoginV2  and web method login()
        /// </summary>
        /// <returns>SessionId</returns>
        public string GetSessionID_BPSummaryWebServiceLogin()
        {
            BP_LoginV2.LoginV2 mylogin = new BP_LoginV2.LoginV2();
            BP_LoginV2.LoginResult myloginresult = new BP_LoginV2.LoginResult();
            mylogin.Timeout = 14400000; //4hours
            myloginresult = mylogin.login(WebConfigurationManager.AppSettings["BPSummaryWebService_UserName"].ToString(), WebConfigurationManager.AppSettings["BPSummaryWebService_Password"].ToString());
            
            return myloginresult.sessionID.ToString(); 
        }
        /// <summary>
        /// Get Session ID using Webservice BP_LoginV2  and web method login()
        /// </summary>
        /// <returns>SessionId</returns>
        public string GetSessionID_wf_BPSummaryWebServiceLogin()
        {
            Wf_BenefitPoint_LoginV2.LoginV2 mylogin = new Wf_BenefitPoint_LoginV2.LoginV2();
            Wf_BenefitPoint_LoginV2.LoginResult myloginresult = new Wf_BenefitPoint_LoginV2.LoginResult();
            mylogin.Timeout = 14400000; //4hours
            myloginresult = mylogin.login(WebConfigurationManager.AppSettings["wf_BPSummaryWebService_UserName"].ToString(), WebConfigurationManager.AppSettings["Wf_BPSummaryWebService_Password"].ToString());

            return myloginresult.sessionID.ToString();
        }
        /// <summary>
        /// Get Session ID using Webservice BP_LoginV2  and web method login()
        /// </summary>
        /// <returns>SessionId</returns>
        public string GetSessionID_BPSummaryWebServiceLogin(string UserName, string Password)
        {
            BP_LoginV2.LoginV2 mylogin = new BP_LoginV2.LoginV2();
            BP_LoginV2.LoginResult myloginresult = new BP_LoginV2.LoginResult();
            mylogin.Timeout = 14400000; //4hours
            myloginresult = mylogin.login(UserName, Password);

            return myloginresult.sessionID.ToString();
        }
        /// <summary>
        /// Get Session ID using Webservice BP_LoginV2  and web method login()
        /// </summary>
        /// <returns>SessionId</returns>
        public string GetSessionID_wf_BPSummaryWebServiceLogin(string UserName, string Password)
        {
            Wf_BenefitPoint_LoginV2.LoginV2 mylogin = new Wf_BenefitPoint_LoginV2.LoginV2();
            Wf_BenefitPoint_LoginV2.LoginResult myloginresult = new Wf_BenefitPoint_LoginV2.LoginResult();
            mylogin.Timeout = 14400000; //4hours
            myloginresult = mylogin.login(UserName, Password);

            return myloginresult.sessionID.ToString();
        }
    }
}