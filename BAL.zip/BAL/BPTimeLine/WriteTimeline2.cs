﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.BPTimeLine
{
    public class WriteTimeline2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();

        public void WriteFieldToTimeLine2(Word.Document oWordDoc, Word.Application oWordApp, DataTable OfficeTable, DropDownList ddlOffice, DropDownList ddlClient, DataSet ActivityDS, DataTable ActivityInfoTable)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                string RenewalDate = string.Empty;
                string TimelineNotes = string.Empty;
                string value = string.Empty;
                int rowCnt = 2;
                DateTime dateValue = new DateTime();

                // Hashtable for PreRenewal
                #region HashTable_PreRenewal
                Hashtable HashtableTimeline_PreRenewal = new Hashtable();
                HashtableTimeline_PreRenewal.Add(1, "18030");  //Request Employee Census -- Sm Grp  Timeline  / Internal Milestones / Request Census
                HashtableTimeline_PreRenewal.Add(2, "18035");  //Request Employee Census -- Sm Grp  Timeline  / Internal Milestones / Request Census / Completed
                HashtableTimeline_PreRenewal.Add(3, "18031");  //Receive Employee Census -- Sm Grp  Timeline  / Internal Milestones / Receive Census
                HashtableTimeline_PreRenewal.Add(4, "18036");  //Receive Employee Census -- Sm Grp  Timeline  / Internal Milestones / Receive Census / Completed

                ArrayList arrPreRenewal = new ArrayList();
                foreach (int key in HashtableTimeline_PreRenewal.Keys)
                {
                    arrPreRenewal.Add(key);
                }

                arrPreRenewal.Sort();
                #endregion

                // Hashtable for Renewal
                #region HashTable_Renewal
                Hashtable HashtableTimeline_Renewal = new Hashtable();
                HashtableTimeline_Renewal.Add(1, "18032");  //Renewal Letter Sent -- Sm Grp Timeline / Internal Milestones / Send Renewal Letter
                HashtableTimeline_Renewal.Add(2, "18037");  //Renewal Letter Sent -- Sm Grp Timeline / Internal Milestones / Send Renewal Letter Completed

                ArrayList arrRenewal = new ArrayList();
                foreach (int key in HashtableTimeline_Renewal.Keys)
                {
                    arrRenewal.Add(key);
                }

                arrRenewal.Sort();
                #endregion

                // Hashtable for Implementation  -- first 4 attribute values need to be searched
                #region HashtableTimeline_Implementation
                Hashtable HashtableTimeline_Implementation = new Hashtable();
                HashtableTimeline_Implementation.Add(1, "45222");  //Carrier/Benefit Decisions Due -- Sm Grp  Timeline  / Internal Milestones / Make Benefit Decisions
                HashtableTimeline_Implementation.Add(2, "45226");  //Carrier/Benefit Decisions Due -- Sm Grp  Timeline  / Internal Milestones / Make Benefit Decisions / Completed
                HashtableTimeline_Implementation.Add(3, "18033");  //Enrollment Complete -- Sm Grp  Timeline  / Internal Milestones / Finalize Enrollment
                HashtableTimeline_Implementation.Add(4, "18038");  //Enrollment Complete -- Sm Grp  Timeline  / Internal Milestones / Finalize Enrollment Completed

                ArrayList arrImplementation = new ArrayList();
                foreach (int key in HashtableTimeline_Implementation.Keys)
                {
                    arrImplementation.Add(key);
                }

                arrImplementation.Sort();
                #endregion

                // Hashtable for PostRenewal
                #region HashtableTimeline_PostRenewal
                Hashtable HashtableTimeline_PostRenewal = new Hashtable();
                HashtableTimeline_PostRenewal.Add(1, "18034");  //Creditable Coverage Reminder -- Sm Grp Timeline  / Internal Milestones / CMS Reminder
                HashtableTimeline_PostRenewal.Add(2, "18039");  //Creditable Coverage Reminder -- Sm Grp Timeline  / Internal Milestones / CMS Reminder Completed

                ArrayList arrPostRenewal = new ArrayList();
                foreach (int key in HashtableTimeline_PostRenewal.Keys)
                {
                    arrPostRenewal.Add(key);
                }

                arrPostRenewal.Sort();
                #endregion

                for (int k = 0; k < ActivityInfoTable.Rows.Count; k++)
                {
                    if (ActivityInfoTable.Rows[k]["recordID"].ToString() == ActivityDS.Tables["activityrecord_table"].Rows[0]["recordID"].ToString())
                    {
                        if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count > 0)
                        {
                            for (int i = 0; i < ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count; i++)
                            {
                                if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_CustomFieldId"].ToString() == "18029")
                                {
                                    RenewalDate = Convert.ToDateTime(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_valueText"].ToString()).ToString("MMMM dd, yyyy");
                                }
                                if (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_CustomFieldId"].ToString() == "23046")
                                {
                                    TimelineNotes = Convert.ToString(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[i]["customFieldValues_valueText"].ToString().Trim());
                                    break;
                                }
                            }
                        }

                        #region PreRenewal Section
                        foreach (int key in arrPreRenewal)
                        {
                            foreach (DataRow dr in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (dr["customFieldValues_CustomFieldId"].ToString() == HashtableTimeline_PreRenewal[key].ToString())
                                {
                                    value = dr["customFieldValues_valueText"].ToString().Trim();

                                    if (!string.IsNullOrEmpty(value))
                                    {
                                        if (DateTime.TryParse(value, out dateValue) == true)
                                        {
                                            value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else
                                    {
                                        value = " ";
                                    }

                                    if (key == 1 || key == 3)
                                    {
                                        oWordDoc.Tables[1].Cell(rowCnt, 3).Range.Text = value;
                                    }
                                    else if (key == 2 || key == 4)
                                    {
                                        oWordDoc.Tables[1].Cell(rowCnt, 4).Range.Text = value;
                                        rowCnt++;
                                    }
                                    break;
                                }
                            }
                        }
                        #endregion

                        #region Renewal Section
                        rowCnt = 2;
                        foreach (int key in arrRenewal)
                        {
                            foreach (DataRow dr in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (dr["customFieldValues_CustomFieldId"].ToString() == HashtableTimeline_Renewal[key].ToString())
                                {
                                    value = dr["customFieldValues_valueText"].ToString().Trim();

                                    if (!string.IsNullOrEmpty(value))
                                    {
                                        if (DateTime.TryParse(value, out dateValue) == true)
                                        {
                                            value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else
                                    {
                                        value = " ";
                                    }

                                    if (key == 1)
                                    {
                                        oWordDoc.Tables[2].Cell(rowCnt, 3).Range.Text = value;
                                    }
                                    else if (key == 2)
                                    {
                                        oWordDoc.Tables[2].Cell(rowCnt, 4).Range.Text = value;
                                        rowCnt++;
                                    }
                                    break;
                                }
                            }
                        }
                        #endregion

                        #region Implementation Section
                        rowCnt = 2;
                        foreach (int key in arrImplementation)
                        {
                            foreach (DataRow dr in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (dr["customFieldValues_CustomFieldId"].ToString() == HashtableTimeline_Implementation[key].ToString())
                                {
                                    value = dr["customFieldValues_valueText"].ToString().Trim();

                                    if (!string.IsNullOrEmpty(value))
                                    {
                                        if (DateTime.TryParse(value, out dateValue) == true)
                                        {
                                            value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else
                                    {
                                        value = " ";
                                    }

                                    if (key == 1 || key == 3 || key == 5 || key == 7 || key == 9)
                                    {
                                        oWordDoc.Tables[3].Cell(rowCnt, 3).Range.Text = value;
                                    }
                                    else if (key == 2 || key == 4 || key == 6 || key == 8 || key == 10)
                                    {
                                        oWordDoc.Tables[3].Cell(rowCnt, 4).Range.Text = value;
                                        rowCnt++;
                                    }
                                    break;
                                }
                            }
                        }
                        #endregion

                        #region PostRenewal Section
                        rowCnt = 2;
                        foreach (int key in arrPostRenewal)
                        {
                            foreach (DataRow dr in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (dr["customFieldValues_CustomFieldId"].ToString() == HashtableTimeline_PostRenewal[key].ToString())
                                {
                                    value = dr["customFieldValues_valueText"].ToString().Trim();

                                    if (!string.IsNullOrEmpty(value))
                                    {
                                        if (DateTime.TryParse(value, out dateValue) == true)
                                        {
                                            value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else
                                    {
                                        value = " ";
                                    }

                                    if (key == 1)
                                    {
                                        oWordDoc.Tables[4].Cell(rowCnt, 3).Range.Text = value;
                                    }
                                    else if (key == 2)
                                    {
                                        oWordDoc.Tables[4].Cell(rowCnt, 4).Range.Text = value;
                                        rowCnt++;
                                    }
                                    break;
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(RenewalDate))
                        {
                            oWordDoc.Tables[4].Cell(rowCnt, 3).Range.Text = Convert.ToDateTime(RenewalDate).AddDays(59).ToString("MM/dd/yyyy");
                        }
                        #endregion

                        #region MergeField

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Client Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                    continue;
                                }

                                if (fieldName.Contains("LegalName"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString().Trim());
                                    continue;
                                }

                                if (fieldName.Contains("EBD Timeline / Renewal Date"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(RenewalDate))
                                    {
                                        oWordApp.Selection.TypeText(RenewalDate);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Timeline_Notes"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(TimelineNotes))
                                    {
                                        oWordApp.Selection.TypeText(TimelineNotes);
                                    }
                                    else
                                    {
                                        myMergeField.Delete();
                                    }
                                    continue;
                                }

                                if (ddlOffice.SelectedIndex > 0)
                                {
                                    DataRow[] FoundRow = null;
                                    FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                    if (FoundRow.Count() > 0)
                                    {
                                        if (fieldName.Contains("Company Logo"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            oWordApp.Selection.TypeBackspace();
                                            oWordApp.Selection.TypeBackspace();
                                            object missing = System.Type.Missing;
                                            Word.Range rng = rngFieldCode;
                                            rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                            string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                            rng.InlineShapes.AddPicture(Server.MapPath("~/Files/TimeLine/Images/CompanyLogo/" + imageName));
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
                #region Header fields
                foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                {
                    foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Headers)
                    {
                        Word.Fields fields = header.Range.Fields;

                        foreach (Word.Field field in fields)
                        {
                            Word.Range rngFieldCode = field.Code;
                            string fieldText = rngFieldCode.Text;
                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("EBD Timeline / Renewal Date"))
                                {
                                    field.Select();
                                    if (!string.IsNullOrEmpty(RenewalDate))
                                    {
                                        oWordApp.Selection.TypeText(RenewalDate);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                                if (fieldName.Contains("Client Name"))
                                {
                                    field.Select();
                                    if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Text.Trim()))
                                    {
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.Trim());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                            }
                        }
                    }
                }
                #endregion
                #region Footer Fields
                foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
                {
                    foreach (Microsoft.Office.Interop.Word.HeaderFooter header in section.Footers)
                    {
                        Word.Fields fields = header.Range.Fields;

                        foreach (Word.Field field in fields)
                        {
                            Word.Range rngFieldCode = field.Code;
                            string fieldText = rngFieldCode.Text;
                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("Current Year"))
                                {
                                    field.Select();
                                    oWordApp.Selection.TypeText(DateTime.Now.Year.ToString());
                                    continue;
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}