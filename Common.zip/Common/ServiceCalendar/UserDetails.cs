﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.ServiceCalendar
{
    public class UserDetails
    { 
        #region Variable
        private int _userId;
        private string _name;
        private string _role;
        private string _workPhone;
        private string _email;
        private string _lastName;
        private string _firstName;

         #endregion
        #region Properties
        /// <summary>
        /// Get and Set UserId
        /// </summary>
        public int UserId
        {
            get
            {
                return _userId;
            }
            set
            {
                _userId = value;
            }
        }
        /// <summary>
        /// Get and Set ContactName
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name= value;
            }
        }
        
        /// <summary>
        /// Get and Set Role
        /// </summary>
        public string Role
        {
            get
            {
                return _role;
            }
            set
            {
                _role = value;
            }
        }
        /// <summary>
        /// Get and Set WorkPhone
        /// </summary>
        public string WorkPhone
        {
            get
            {
                return _workPhone;
            }
            set
            {
                _workPhone = value;
            }
        }
        /// <summary>
        /// Get and Set ContactEmail
        /// </summary>
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }
       
        /// <summary>
        /// Get and Set First Name
        /// </summary>
        public string First_Name
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        /// <summary>
        /// Get and Set Last tName
        /// </summary>
        public string Last_Name
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
         #endregion
    }
}