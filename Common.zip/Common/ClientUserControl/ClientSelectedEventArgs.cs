﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.ClientUserControl
{
    public class ClientSelectedEventArgs
    {
        int _ClientID;
        string _ClientName;

        public int ClientID
        {
            get { return _ClientID; }
            set { _ClientID = value; }
        }
        public string ClientName
        {
            get { return _ClientName; }
            set { _ClientName = value; }
        }
    }
}