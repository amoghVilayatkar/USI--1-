﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;

namespace BenefitPointSummaryPortal.View
{
    public partial class BenefitSummaryExamples : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString[0] == "Ex1")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS1 - Simple Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex5")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS5 - Summary Brochure - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex4")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS4 - Detail Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex3")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS3 - Enrollment Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex2")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS2 - FAQ Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex6")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS6 - Value Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "Ex7")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/BS7 - Highlights Summary - Example.pdf");
            }
            else if (Request.QueryString[0] == "TL_EX_1")
            {
                Response.Redirect("~/Files/TimeLine/Examples/AllRenewalTimelineSamples_Portfolio.pdf");
            }
            else if (Request.QueryString[0] == "TL_EX_2")
            {
                Response.Redirect("~/Files/TimeLine/Examples/TL2 - Renewal - Small Group - Example.pdf");
            }
            else if (Request.QueryString[0] == "Tools1_Ex")
            {
                Response.Redirect("~/Files/Tools/Examples/Tools1 - 5500 Worksheet Example.pdf");
            }
            else if (Request.QueryString[0] == "Tools2_Ex")
            {
                Response.Redirect("~/Files/Tools/Examples/Tools2 - Account Profile Example.pdf");
            }
            else if (Request.QueryString[0] == "Tools3_Ex")
            {
                Response.Redirect("~/Files/Tools/Examples/Tools3 - Contract Review Checklist - Example.pdf");
            }
            else if (Request.QueryString[0] == "SC_EX_1")
            {
                Response.Redirect("~/Files/ServiceCalendar/Examples/Service Calendar Highlights Example.pdf");
            }
            else if (Request.QueryString[0] == "SC_EX_2")
            {
                Response.Redirect("~/Files/ServiceCalendar/Examples/Service Calendar Detail Example.pdf");
            }
            else if (Request.QueryString[0] == "SC_EX_3")
            {
                Response.Redirect("~/Files/ServiceCalendar/Examples/Service Calendar Compliance Example.pdf");
            }
            else if (Request.QueryString[0] == "FAQ")
            {
                Response.Redirect("~/Files/BenefitSummary/Documents/AnnualLegalNotice/0 - Instructions for Legal Notices.pdf");
            }
            else if (Request.QueryString[0] == "ColorEx")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/Color Options - Examples.pdf");
            }
            else if (Request.QueryString[0] == "RevenueSummaryEx") /*---- Added by Amogh For Revenue Summary Report*/
            {
                Response.Redirect("~/Files/Tools/Examples/RevenueSummaryExample.pdf");
            }
            else if (Request.QueryString[0] == "BRCCostSavings")  ///*---- Added by Amogh For BRC Reports*/
            {
                Response.Redirect("~/Files/BRC Report/Examples/BRC_Cost_Saving_Example.pdf");
            }
            else if (Request.QueryString[0] == "BRCDetailedMonthly")
            {
                Response.Redirect("~/Files/BRC Report/Examples/BRC_Detailed_Utilization_Monthly_Example.pdf");
            }
            else if (Request.QueryString[0] == "BRCDetailedSummary")
            {
                Response.Redirect("~/Files/BRC Report/Examples/BRC_Detailed_Utilization_Summary_Example.pdf");
            }
            else if (Request.QueryString[0] == "BRCMultiYear")
            {
                Response.Redirect("~/Files/BRC Report/Examples/BRC_Multi-Year_Utilization_Example.pdf");
            }
            else if (Request.QueryString[0] == "Analytics")
            {
                Response.Redirect("~/Files/AnalyticsCoverPages/Examples/Image Options v1.pdf");
            }
            // Added By Shravan
            else if (Request.QueryString[0] == "BenefitSummariesOnePage")
            {
                Response.Redirect("~/Files/BenefitSummary/Examples/Benefit Summaries One Page.pdf");
            }

            Response.Headers.Set("h1", "Example1");

        }
    }
}