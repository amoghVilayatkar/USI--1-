﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;


namespace BenefitPointSummaryPortal.BAL.BPTimeLine
{
    public class WriteTools1 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        public void WriteFieldToTools1(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet ActivityDS, DataTable ActivityInfoTable, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, string SessionId, DataTable dtPlanContactDetails = null)
        {
            try
            {
                int iTotalFields = 0;
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                // Hashtable for PreRenewal
                #region HashTable_PreRenewal
                Hashtable HashtableTimeline_PreRenewal = new Hashtable();
                HashtableTimeline_PreRenewal.Add(1, "21087");  //Plan Name
                HashtableTimeline_PreRenewal.Add(2, "17662");  //ERISA Plan Number
                HashtableTimeline_PreRenewal.Add(3, "17670");  //Plan Year Start Date
                HashtableTimeline_PreRenewal.Add(4, "17671");  //Plan Year End Date
                HashtableTimeline_PreRenewal.Add(5, "17672");  //Short Plan Year
                HashtableTimeline_PreRenewal.Add(6, "17679");  //# of EEs on Start Date
                HashtableTimeline_PreRenewal.Add(7, "17680");  //# of EEs on End Date
                HashtableTimeline_PreRenewal.Add(8, "17666");  //Plan Sponsor
                HashtableTimeline_PreRenewal.Add(9, "17667");  //Plan Sponsor Email
                HashtableTimeline_PreRenewal.Add(10, "48239"); //Broker PLan YEs/No

                //HashtableTimeline_PreRenewal.Add(10, "18111"); //Funding Method

                ArrayList arrPreRenewal = new ArrayList();
                foreach (int key in HashtableTimeline_PreRenewal.Keys)
                {
                    arrPreRenewal.Add(key);
                }

                arrPreRenewal.Sort();
                #endregion

                string ServiceInfo_FirstName = string.Empty;
                string ServiceInfo_LastName = string.Empty;
                string ServiceInfo_EMail = string.Empty;

                string Plan_Name = string.Empty;
                string ERISA_Plan_Number = string.Empty;
                string Plan_Year_Start_Date = string.Empty;
                string Plan_Year_End_Date = string.Empty;
                string Short_Plan_Year = string.Empty;
                string No_of_EEs_on_Start_Date = string.Empty;
                string No_of_EEs_on_End_Date = string.Empty;
                string Plan_Sponsor = string.Empty;
                string Plan_Sponsor_Email = string.Empty;
                string Funding_Method = string.Empty;
                string Broker_Plan = string.Empty;



                string MainPhone = string.Empty;
                string TaxID = string.Empty;
                string MainAddress = string.Empty;
                //string Street1 = string.Empty;
                //string Street2 = string.Empty;
                //string City = string.Empty;
                //string State = string.Empty;
                //string Zip = string.Empty;
                //string Country = string.Empty;

                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                }
                            }
                        }
                    }

                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int m = 0; m < AccountDS.Tables[1].Rows.Count; m++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"])))
                            {
                                TaxID = Convert.ToString(AccountDS.Tables[1].Rows[m]["groupAccountInfo_commonGroupAccountInfo_taxpayerID"]);
                            }

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street1"])))
                            //{
                            //    Street1 = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street1"]);
                            //}

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street2"])))
                            //{
                            //    Street2 = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street2"]);
                            //}

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_city"])))
                            //{
                            //    City = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_city"]);
                            //}

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_state"])))
                            //{
                            //    State = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_state"]);
                            //}

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_zip"])))
                            //{
                            //    Zip = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_zip"]);
                            //}

                            //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_country"])))
                            //{
                            //    Country = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_country"]);
                            //}
                        }

                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceInfo_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceInfo_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceInfo_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                    }
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools1");
                }

                #endregion

                for (int k = 0; k < ActivityInfoTable.Rows.Count; k++)
                {
                    if (ActivityInfoTable.Rows[k]["recordID"].ToString() == ActivityDS.Tables["activityrecord_table"].Rows[0]["recordID"].ToString())
                    {
                        #region Tools 1 Section
                        foreach (int key in arrPreRenewal)
                        {
                            foreach (DataRow dr in ActivityDS.Tables["activityCustomFieldValues_table"].Rows)
                            {
                                if (dr["customFieldValues_CustomFieldId"].ToString() == HashtableTimeline_PreRenewal[key].ToString())
                                {
                                    value = dr["customFieldValues_valueText"].ToString().Trim();

                                    if (key == 1)
                                    {
                                        Plan_Name = value;
                                    }

                                    else if (key == 2)
                                    {
                                        ERISA_Plan_Number = value;
                                    }

                                    else if (key == 3)
                                    {
                                        if (!string.IsNullOrEmpty(value))
                                        {
                                            if (DateTime.TryParse(value, out dateValue) == true)
                                            {
                                                value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else
                                        {
                                            value = " ";
                                        }
                                        Plan_Year_Start_Date = value;
                                    }

                                    else if (key == 4)
                                    {
                                        if (!string.IsNullOrEmpty(value))
                                        {
                                            if (DateTime.TryParse(value, out dateValue) == true)
                                            {
                                                value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else
                                        {
                                            value = " ";
                                        }
                                        Plan_Year_End_Date = value;
                                    }

                                    else if (key == 5)
                                    {
                                        Short_Plan_Year = value;
                                    }

                                    else if (key == 6)
                                    {
                                        No_of_EEs_on_Start_Date = value;
                                    }

                                    else if (key == 7)
                                    {
                                        No_of_EEs_on_End_Date = value;
                                    }

                                    else if (key == 8)
                                    {
                                        Plan_Sponsor = value;
                                    }

                                    else if (key == 9)
                                    {
                                        Plan_Sponsor_Email = value;
                                    }

                                    else if (key == 10)
                                    {
                                        Broker_Plan = value;
                                    }
                                    //else if (key == 10)
                                    //{
                                    //    Funding_Method = value;
                                    //}
                                }
                            }
                        }
                        #endregion

                        #region MergeField
                        string Fi_Or_Si = string.Empty;

                        if (string.IsNullOrEmpty(Short_Plan_Year))
                        {
                            Short_Plan_Year = "no";
                        }
                        if (string.IsNullOrEmpty(Broker_Plan))
                        {
                            Broker_Plan = "select";
                        }
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            string fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");

                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;
                                string fieldName = fieldText.Substring(11, endMerge - 11);
                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Client Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                    continue;
                                }

                                if (fieldName.Contains("Info_table"))
                                {
                                    myMergeField.Select();
                                    if (dtPlanContactDetails != null)
                                    {
                                        if (dtPlanContactDetails.Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    continue;
                                }


                                if (fieldName.Contains("Account Summary – Main Phone"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(MainPhone))
                                    {
                                        oWordApp.Selection.TypeText(MainPhone);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Account Summary – Main Address"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(MainAddress))
                                    {
                                        oWordApp.Selection.TypeText(MainAddress);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Yes"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Short_Plan_Year) && Short_Plan_Year.ToLower() == "yes")
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("No"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Short_Plan_Year) && Short_Plan_Year.ToLower() == "no")
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Equals("BR_YES"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Broker_Plan) && Broker_Plan.ToLower() == "yes")
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }


                                if (fieldName.Contains("BR_NO"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Broker_Plan) && Broker_Plan.ToLower() == "select")
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Account Summary – Tax ID"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(TaxID))
                                    {
                                        oWordApp.Selection.TypeText(TaxID);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Plan Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Plan_Name))
                                    {
                                        oWordApp.Selection.TypeText(Plan_Name);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("ERISA Plan Number"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(ERISA_Plan_Number))
                                    {
                                        oWordApp.Selection.TypeText(ERISA_Plan_Number);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Plan Year Start Date"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Plan_Year_Start_Date))
                                    {
                                        oWordApp.Selection.TypeText(Plan_Year_Start_Date);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Plan Year End Date"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Plan_Year_End_Date))
                                    {
                                        oWordApp.Selection.TypeText(Plan_Year_End_Date);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("# of EEs on Start Date"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(No_of_EEs_on_Start_Date))
                                    {
                                        decimal no_On_Start_Date = Convert.ToDecimal(No_of_EEs_on_Start_Date);
                                        oWordApp.Selection.TypeText(Convert.ToString(no_On_Start_Date.ToString("#,##0")));
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("# of EEs on End Date"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(No_of_EEs_on_End_Date))
                                    {
                                        decimal no_On_End_Date = Convert.ToDecimal(No_of_EEs_on_End_Date);
                                        oWordApp.Selection.TypeText(Convert.ToString(no_On_End_Date.ToString("#,##0")));
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Plan Sponsor Name"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Plan_Sponsor))
                                    {
                                        oWordApp.Selection.TypeText(Plan_Sponsor);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Plan Sponsor Email"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(Plan_Sponsor_Email))
                                    {
                                        oWordApp.Selection.TypeText(Plan_Sponsor_Email);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }

                                if (fieldName.Contains("Primary Service Lead name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ServiceInfo_FirstName + " " + ServiceInfo_LastName);
                                    continue;
                                }

                                if (fieldName.Contains("Service Info – Primary Service Lead Email"))
                                {
                                    myMergeField.Select();
                                    if (!string.IsNullOrEmpty(ServiceInfo_EMail))
                                    {
                                        oWordApp.Selection.TypeText(ServiceInfo_EMail);
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                    continue;
                                }
                            }
                        }
                        #endregion

                        #region Write Table of PLans
                        #region Plan Infor Code
                        int rowCnt = 2;
                        foreach (DataRow dr in PlanInfoTable.Rows)
                        {
                            if (rowCnt > 2)
                            {
                                oWordDoc.Tables[4].Rows.Add();
                            }

                            int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(dr["ProductId"].ToString()), SessionId);

                            if (OptionFieldValueiD == 52403)
                            {
                                Fi_Or_Si = "SI";
                            }
                            else if (OptionFieldValueiD == 52401)
                            {
                                Fi_Or_Si = "FI";
                            }
                            else if (OptionFieldValueiD == 52400)
                            {
                                Fi_Or_Si = " ";
                            }
                            else
                            {
                                Fi_Or_Si = " ";
                            }

                            var planContactName = (from n in dtPlanContactDetails.AsEnumerable()
                                                   where n.Field<String>("ProductId") == Convert.ToString(dr["ProductId"])
                                                   select n.Field<string>("ContactName")).FirstOrDefault();
                            var planContactEmail = (from n in dtPlanContactDetails.AsEnumerable()
                                                    where n.Field<String>("ProductId") == Convert.ToString(dr["ProductId"])
                                                    select n.Field<string>("ContactEmail")).FirstOrDefault();
                            var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                    where n.Field<String>("ProductId") == Convert.ToString(dr["ProductId"])
                                                    select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();
                            var firstName = (from n in dtPlanContactDetails.AsEnumerable()
                                             where n.Field<string>("ProductId") == Convert.ToString(dr["ProductId"])
                                             select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                            var lastName = (from n in dtPlanContactDetails.AsEnumerable()
                                            where n.Field<string>("ProductId") == Convert.ToString(dr["ProductId"])
                                            select n.Field<string>("Contact_LastName")).FirstOrDefault();

                            oWordDoc.Tables[4].Cell(rowCnt, 1).Range.Text = dr["Carrier"].ToString();
                            oWordDoc.Tables[4].Cell(rowCnt, 2).Range.Text = dr["PolicyNumber"].ToString();
                            oWordDoc.Tables[4].Cell(rowCnt, 3).Range.Text = dr["Name"].ToString();
                            oWordDoc.Tables[4].Cell(rowCnt, 5).Range.Text = Fi_Or_Si;

                            if (!string.IsNullOrEmpty(planContactName) || !string.IsNullOrEmpty(planContactEmail) || !string.IsNullOrEmpty(planContactPhone))
                            {
                                oWordDoc.Tables[4].Cell(rowCnt, 4).Range.Text = firstName + " " + lastName + "\n" + planContactEmail + "\n" + planContactPhone;
                            }
                            else
                            {
                                oWordDoc.Tables[4].Cell(rowCnt, 4).Range.Text = "Add Name\nAdd Email Address";
                            }
                            rowCnt++;

                        }
                        #endregion
                        #endregion
                    }
                }

                if (oWordDoc.Tables[4].Rows.Last.Cells[1].Range.Text == "\r\a")
                {
                    oWordDoc.Tables[4].Rows.Last.Delete();
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}