﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string std_carrier = "";
        string ltd_carrier = "";
        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="NumberOfPlan">Number of selected plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteMedicalSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, string NumberOfPlan, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;

                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;
                string AnnualDeductible = "";
                string AnnualOutofPocket = "";
                string ProfessionalVisit = "";
                DataRow[] foundRows = null;
                string Carrier = "";
                string Website = "";
                string OldCarrier = "";
                string OldWebsite = "";
                string effectivedate = "";
                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(3, "45");          //Annual Deductible[Per Person]
                HashtableMedical.Add(33, "44");         //Annual Deductible[Maximum Per Family]
                HashtableMedical.Add(4, "112");         //Benefits[Coinsurance]
                HashtableMedical.Add(5, "53");          //Annual Out-of-Pocket Maximum[Maximum Per Person]
                HashtableMedical.Add(55, "52");         //Annual Out-of-Pocket Maximum[Maximum Per Family]
                HashtableMedical.Add(6, "386");         //Professional[Office Visit]
                HashtableMedical.Add(66, "414");        //Professional [Outpatient Visit]
                HashtableMedical.Add(7, "16");          //Preventive Care[Office Visit]
                HashtableMedical.Add(8, "184");         //Other Services[Emergency Room]
                HashtableMedical.Add(9, "295");         //Hospital/Facility[Inpatient Care]
                HashtableMedical.Add(10, "168");        //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedical.Add(11, "971");        //Other Services[Complex Radiology]

                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                        if (foundRows.Count() > 0)
                        {
                            Website = foundRows[0]["Website"].ToString();
                        }
                        if (rowindex == 0)
                        {
                            effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                        }
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                Carrier = Carrier + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }
                            if (OldWebsite != Website)
                            {
                                OldWebsite = Website;
                            }
                            //if (OldWebsite != foundRows[0]["Website"].ToString())
                            //{
                            //    Website = foundRows[0]["Website"].ToString();
                            //    OldWebsite = foundRows[0]["Website"].ToString();
                            //}

                            #region MedicalTable

                            oWordDoc.Tables[1].Cell(1, count + 1).Select();
                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString()).Trim() + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString()).Trim();

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        switch (key)
                                        {
                                            case 33: AnnualDeductible = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " max per family"; break;
                                            case 55: AnnualOutofPocket = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " max per family" + "\n\nThe deductible is included in the out of pocket max.\nCopays do not count towards out of pocket max."; break;
                                            case 66: ProfessionalVisit = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " specialist visit"; break;
                                        }
                                        switch (key)
                                        {
                                            case 3: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per person \n" + AnnualDeductible; break;
                                            case 4: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " of medical charges after you meet deductible"; break;
                                            case 5: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " per person\n" + AnnualOutofPocket; break;
                                            case 6: oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " primary care visit\n" + ProfessionalVisit; break;
                                        }
                                        if (key > 6 && key < 33)
                                        {
                                            oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Number of Medical Plan"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(NumberOfPlan);
                        }
                        if (fieldName.Equals("MedicalPlanEffectiveDate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                        }
                        if (fieldName.Contains("Medical Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Medical Benefits");
                        }
                        if (fieldName.Contains("Medical Plan Carrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                        if (fieldName.Contains("Medical Plan Website"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Website.Trim()))
                            {
                                oWordApp.Selection.TypeText(Website);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }

                        /*New Changes-25 June 2014*/
                        if (fieldName.Contains("Medical_Plans"))
                        {
                            myMergeField.Select();
                            if (NumberOfPlan == "1")
                            {
                                oWordApp.Selection.TypeText("medical plan");
                            }
                            else
                            {
                                oWordApp.Selection.TypeText("medical plans");
                            }
                        }
                        //end change
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string Preferred_Specialty = "";
                int rowcount = 12;
                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");//Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");//Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");//Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "881");   //Prescription Categories[Preferred Specialty]

                #endregion
                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");//Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");//Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");//Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "884");    //Mail Order[Preferred Specialty]

                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value + " Tier 1\n"; break;
                                            case 2: Formulary = value + " Tier 2\n"; break;
                                            case 3: NonFormulary = value + " Tier 3\n"; break;
                                            case 4: Preferred_Specialty = value + " Tier 4"; break;
                                        }
                                    }
                                }
                            }
                            oWordDoc.Tables[1].Cell(rowcount, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;

                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value + " Tier 1\n"; break;
                                            case 2: Formulary = value + " Tier 2\n"; break;
                                            case 3: NonFormulary = value + " Tier 3\n"; break;
                                            case 4: Preferred_Specialty = value + " Tier 4"; break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[1].Cell(rowcount + 1, count + 1).Range.Text = Generic + Formulary + NonFormulary + Preferred_Specialty;

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        public void WriteDentalSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, DataTable CarrierSpecific, DataTable PlanTypeSpecific)
        {
            try
            {

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(22, "44");//Calendar Year Deductible
                HashtableDentalInNetwork.Add(2, "45");//Calendar Year Deductible
                HashtableDentalInNetwork.Add(3, "55");//Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(4, "164");//Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(5, "64");//Basic Services – Basic
                HashtableDentalInNetwork.Add(6, "336");//Major Services – Major


                #endregion

                int count = 1;
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;
                string AnnualDeductible = "";
                string OldCarrier = "";
                string Carrier = "";
                string OldCarrier_Website = "";
                string Carrier_Website = "";
                string Website = "";
                string value = "";
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            /*New Changes-25 June 2014*/
                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                if (count > 1)
                                {
                                    Carrier = Carrier.Trim() + " and " + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                                }
                                else
                                {
                                    Carrier = Carrier.Trim() + (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " ";
                                    // Carrier_Website = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString() + "'");
                                }
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }
                            // end change

                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            if (foundRows.Count() > 0)
                            {
                                Website = foundRows[0]["Website"].ToString().Trim();
                            }
                            if (OldCarrier_Website != Website)
                            {
                                if (count > 1)
                                {
                                    Carrier_Website = Carrier_Website.Trim() + " or " + Website;
                                }
                                else
                                {
                                    Carrier_Website = Carrier_Website.Trim() + Website + " ";
                                    // Carrier_Website = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString() + "'");
                                }
                                OldCarrier_Website = Website;
                            }

                            //Carrier_Website = foundRows[0]["Website"].ToString().Trim();

                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + "'");

                            #region DentalTable

                            oWordDoc.Tables[2].Cell(1, count + 1).Select();
                            oWordDoc.Tables[2].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString()).Trim() + " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString()).Trim() + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString().Trim());

                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 22: AnnualDeductible = value.ToString().Trim() + " family maximum"; break;

                                            case 2: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value.ToString().Trim() + " per person\n" + AnnualDeductible; break;
                                            //case 3: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value + " (annually)"; break;  
                                            case 3: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value.ToString().Trim() + " maximum per person"; break;
                                            case 4: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = value + "\nInsurance pays 100% for oral exams, x-rays and cleanings Annual Limits Apply"; break;
                                            case 5: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = "After deductible is met, insurance pays " + value + "\nServices include fillings, extractions, periodontics, root canals and general anesthesia"; break;
                                            case 6: oWordDoc.Tables[2].Cell(key, count + 1).Range.Text = "After deductible is met, insurance pays " + value + "\nServices include crowns, dentures, fixed and removable prosthetics"; break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Benefits");
                                    }

                                    //if (fieldName.Contains("Dental Plan Carrier"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.TypeText(Carrier);
                                    //}

                                    if (fieldName.Contains("Dental Plan Specific Text" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (foundPlanTypeRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundPlanTypeRows[0]["PlanSpecific"].ToString().Trim());
                                        }
                                        else
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    //if (fieldName.Contains("Dental Plan Website"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (foundRows.Count() > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                                    //    }
                                    //    else
                                    //    {
                                    //        myMergeField.Delete();
                                    //    }
                                    //}
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }

                /*New Changes-25 June 2014*/
                int iTotalField = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalField++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dental Plan Carrier"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                        if (fieldName.Contains("Dental Plan Website"))
                        {
                            myMergeField.Select();

                            //oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString().Trim());
                            if (!string.IsNullOrEmpty(Carrier_Website.Trim()))
                            {
                                oWordApp.Selection.TypeText(Carrier_Website.Trim());
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }
                //End change
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, ArrayList VisionBenefitColumnIdOutNetworkList)
        {
            try
            {
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefit = new Hashtable();
                #region HastableVisionBenefit

                //HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                //HashtableVisionBenefit.Add(3, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                ////HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                ////HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                ////HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                //HashtableVisionBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                ////HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                ////HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                //HashtableVisionBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                //HashtableVisionBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefit.Add(15, "207");//General Plan Information – Benefit Frequency – Frames

                /*For Old Template--Just Uncomment single if needed*/
                //HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                ///*Chnge 26 Jun 2014 issue #26*/
                //// HashtableVisionBenefit.Add(3, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(3, "344");//General Plan Information – Material
                ////End change
                //HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                ////HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                ////HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                ////HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                //HashtableVisionBenefit.Add(5, "178");//Covered Services – Contact Lenses - Elective
                ////HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                ////HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                //HashtableVisionBenefit.Add(7, "194");//General Plan Information – Benefit Frequency – Examination
                ///*Chnge 26 Jun 2014 issue #26*/
                ////HashtableVisionBenefit.Add(8, "309");//General Plan Information – Benefit Frequency –Lenses
                //HashtableVisionBenefit.Add(8, "344");//General Plan Information – Benefit Frequency –Lenses
                ////end change
                //HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts
                //HashtableVisionBenefit.Add(9, "207");//General Plan Information – Benefit Frequency – Frames


                /*After New Template Hash Table*/

                HashtableVisionBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                HashtableVisionBenefit.Add(3, "344");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(4, "208");//Covered Services – Frames
                HashtableVisionBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                HashtableVisionBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                HashtableVisionBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefit.Add(15, "122");//General Plan Information – Benefit Frequency – Contacts
                HashtableVisionBenefit.Add(16, "207");//General Plan Information – Benefit Frequency – Frame
                HashtableVisionBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts

                Hashtable HashtableVisionOutNetworkBenefit = new Hashtable();
                HashtableVisionOutNetworkBenefit.Add(2, "195");//General Plan Information – Copay – Deductible
                HashtableVisionOutNetworkBenefit.Add(3, "344");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionOutNetworkBenefit.Add(4, "208");//Covered Services – Frames
                HashtableVisionOutNetworkBenefit.Add(6, "507");//Covered Services – Lenses – Single Vision Lens
                HashtableVisionOutNetworkBenefit.Add(7, "73");//Covered Services – Lenses – Bifocal Lens
                HashtableVisionOutNetworkBenefit.Add(8, "553");//Covered Services – Lenses – Trifocal Lens
                HashtableVisionOutNetworkBenefit.Add(9, "178");//Covered Services – Contact Lenses - Elective
                HashtableVisionOutNetworkBenefit.Add(10, "356");//Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionOutNetworkBenefit.Add(11, "133");//Covered Services – Other Services – Corrective Vision Services (e.g. Laser Surgery)
                HashtableVisionOutNetworkBenefit.Add(13, "194");//General Plan Information – Benefit Frequency – Examination
                HashtableVisionOutNetworkBenefit.Add(14, "309");//General Plan Information – Benefit Frequency –Lenses
                HashtableVisionOutNetworkBenefit.Add(15, "122");//General Plan Information – Benefit Frequency – Contacts
                HashtableVisionOutNetworkBenefit.Add(16, "207");//General Plan Information – Benefit Frequency – Frame
                HashtableVisionOutNetworkBenefit.Add(66, "122");//General Plan Information – Benefit Frequency – Contacts

                #endregion
                int iTotalFields = 0;
                int count = 1;
                string Contacts = "";
                string OldCarrier = "";
                string Carrier = "";

                string value = "";
                string value1 = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            /*New Changes-25 June 2014*/
                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                Carrier = Carrier + (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + " ";
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                            }
                            //end change
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable
                            oWordDoc.Tables[3].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim())+ " " + (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() .Trim())+ " " + (PlanTable.Rows[rowindex]["PolicyNumber"].ToString().Trim()) + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"].ToString().Trim());
                            #region VisionInNetwork
                            foreach (int key in HashtableVisionBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();


                                        //if (key > 1 && key < 5)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}
                                        ////if (key > 5 && key < 9 || key == 11 || key == 13 || key == 15)
                                        //if (key == 7 || key == 9)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}

                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 3: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 4: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 6: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 7: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\nIn lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;

                                            case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\nDetermined at provider’s discretion for certain conditions"; break;
                                            case 11: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 13: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 16: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            case 15: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 66: Contacts = value; break;
                                            //case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n In lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;
                                            // case 5: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n Determined at provider’s discretion for certain conditions"; break;
                                            case 66: Contacts = value; break;

                                            //case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;
                                        }
                                    }
                                }
                            }
                            #endregion
                            #region Vision OutNetwork
                            foreach (int key in HashtableVisionOutNetworkBenefit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionOutNetworkBenefit[key].ToString())
                                    {
                                        value1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();


                                        //if (key > 1 && key < 5)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}
                                        ////if (key > 5 && key < 9 || key == 11 || key == 13 || key == 15)
                                        //if (key == 7 || key == 9)
                                        //{
                                        //    oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value;
                                        //}

                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 3: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 4: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 6: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 7: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 8: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 9: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1 + "\nIn lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;

                                            case 10: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1 + "\nDetermined at provider’s discretion for certain conditions"; break;
                                            case 11: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 13: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 14: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 16: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;
                                            case 15: oWordDoc.Tables[3].Cell(key, count + 2).Range.Text = value1; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 66: Contacts = value; break;
                                            //case 14: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;

                                            //case 9: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n In lieu of frames/lenses Fitting/evaluation fees are available at 15% off UCR"; break;
                                            // case 5: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value; break;
                                            //case 10: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n Determined at provider’s discretion for certain conditions"; break;
                                            case 66: Contacts = value1; break;

                                            //case 8: oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = value + "\n" + Contacts; break;
                                        }
                                    }
                                }
                            }


                            #endregion
                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    //if (fieldName.Contains("Vision Plan Carrier"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                    //}
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                    }


                                    if (fieldName.Contains("Vision Plan Website"))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }

                /*New Changes-25 June 2014*/

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Vision Plan Carrier"))
                        {
                            myMergeField.Select();
                            //oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                            oWordApp.Selection.TypeText(Carrier.Trim());
                        }
                    }
                }
                //end change
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(2, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(22, "188");//Employee[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(3, "516");//Spouse[Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(33, "519"); //Spouse[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(4, "106");//Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(44, "104");//Child(ren)[Overall Maximum]

                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee [Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(55, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(65, "103");//Child(ren)[Guarantee Issue Amount] 
                #endregion

                string OverallMaximumEmployee = "";
                string OverallMaximumSpouse = "";
                string OverallMaximumChild = "";

                string GuaranteeIssueSpouse = "";
                string GuaranteeIssueChild = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region VoluntaryLifeADDBenifitTable
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumEmployee; break;
                                            case 3: oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumSpouse + "\nElection cannot exceed 50% of employee’s coverage amount"; break;
                                            case 4: oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = "Units of " + value + " to a maximum of " + OverallMaximumChild + "\nThe maximum benefit for children under 6 months of age is $500"; break;
                                            case 5: oWordDoc.Tables[4].Cell(key, count + 1).Range.Text = "Employee -" + value + GuaranteeIssueSpouse + GuaranteeIssueChild; break;
                                            case 22: OverallMaximumEmployee = value; break;
                                            case 33: OverallMaximumSpouse = value; break;
                                            case 44: OverallMaximumChild = value; break;
                                            case 55: GuaranteeIssueSpouse = "\nSpouse - " + value; break;
                                            case 65: GuaranteeIssueChild = "\nChild - " + value + "\n\nVoluntary Life guarantee issue amounts only apply to new hire employees electing coverage within their original eligibility period. All others will be subject to Evidence of Insurability and can be declined for coverage."; break;
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VoluntaryLife"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Voluntary Life insurance for you and your family");
                                    }
                                    if (fieldName.Contains("Voluntary Life Plan Carrierr"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                    }

                                    if (fieldName.Contains("Income Protection Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Income Protection Benefits");
                                    }
                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteGroupLifeADDBenifitToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DropDownList ddlVoluntaryLifeADDNoOfPlan)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                string Carrier = "";

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                double benefitamount = 0;
                string age = "";
                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(2, "186");//Employee [Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                //HashtableGroupLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]
                //HashtableGroupLifeADDBenifit.Add(7, "517");//Spouse[Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(8, "519");//Spouse[Overall Maximum]
                //HashtableGroupLifeADDBenifit.Add(9, "518");//Spouse[Guarantee Issue Amount]
                //HashtableGroupLifeADDBenifit.Add(11, "102");//Child(ren)[Benefit Amount] 
                //HashtableGroupLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum] 
                //HashtableGroupLifeADDBenifit.Add(13, "103");//Child(ren)[Guarantee Issue Amount]
                //HashtableGroupLifeADDBenifit.Add(14, "2");//age
                //HashtableGroupLifeADDBenifit.Add(15, "3");//age
                //HashtableGroupLifeADDBenifit.Add(16, "4");//age
                //HashtableGroupLifeADDBenifit.Add(17, "5");//age
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupLifeADDBenifitTable
                            //oWordDoc.Tables[1].Cell(count + 7, 2).Select();
                            //oWordDoc.Tables[1].Cell(count + 7, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                            //OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();

                            if (OldCarrier != (PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                            {
                                Carrier = Carrier + (PlanTable.Rows[k]["Carrier"].ToString().Trim()) + " ";
                                OldCarrier = (PlanTable.Rows[k]["Carrier"].ToString().Trim());
                            }

                            //  OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            //oWordDoc.Tables[6].Cell(1, count + 1).Select();
                            //oWordDoc.Tables[6].Cell(1, count + 1).Range.Text = PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"];

                            /* The following line changed beacause we merging the first cell of table to Display the carrier name in correct format*/
                            oWordDoc.Tables[5].Cell(1, 1).Select();
                            oWordDoc.Tables[5].Cell(1, 2).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString().Trim()) + " " + (PlanTable.Rows[k]["ProductTypeDescription"].ToString().Trim()) + " " + (PlanTable.Rows[k]["PolicyNumber"].ToString().Trim()) + " " + (BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"].ToString().Trim());

                            foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                    {
                                        if (key < 14)
                                        {
                                            oWordDoc.Tables[5].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }

                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            //case 2: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                            // case 3: if (value.Trim() != string.Empty) { age = "70"; } break;//70-74
                                            // case 4: if (value.Trim() != string.Empty) { age = "75"; } break;//75-79
                                            //case 5: if (value.Trim() != string.Empty) { age = "80"; } break;//80-84
                                            case 186:
                                                ////benefitamount = int.Parse(dr["value"].ToString().Substring(dr["value"].ToString().IndexOf('$') + 1).Replace(",", "")); break;
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    //benefitamount = double.Parse(dr["value"].ToString().Substring(dr["value"].ToString().IndexOf('$') + 1).Replace(",", ""));
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();


                                    //if (fieldName.Contains("Group Life and AD&D Benefits"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.TypeText("Group Life and AD&D Benefits");
                                    //}
                                    if (fieldName.Contains("Life and AD&D Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(Carrier.Trim());
                                    }
                                    if (fieldName.Contains("Life_AD&D"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Basic Life and AD&D Insurance");

                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        }
                                    }

                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, DropDownList ddlVoluntaryLifeADDNoOfPlan)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableSTD
                HashtableSTD.Add(2, "8");//STD General Information – Elimination Period – Accident
                HashtableSTD.Add(22, "505");//STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");//STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "373");//STD General Plan Information – Minimum Weekly Benefit 
                HashtableSTD.Add(5, "569");//STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(6, "350");//STD General Information – Maximum Period of Payment
                HashtableSTD.Add(7, "449");//STD General Plan Information –Pre-Existing Condition Limitations


                #endregion
                string EliminationPeriod = "";
                string ProductName = "";

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Description";
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 22: EliminationPeriod = value + " Illness"; break;
                                            case 2: oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value + " Accident / " + EliminationPeriod; break;
                                            case 3: oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value + " of your weekly earnings\n\nEarnings includes your basic weekly earnings and commissions in effect prior to your period of disability.\nIt does not include overtime pay."; break;
                                        }

                                        if (key > 3 && key < 8)
                                        {
                                            oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value;
                                        }
                                        if (key == 6)
                                        {
                                            if (dr["UOM"].ToString() == "text")
                                            {
                                                dr["UOM"] = "";
                                            }
                                            oWordDoc.Tables[6].Cell(key, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim();
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("STD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        std_carrier = PlanTable.Rows[rowindex]["Carrier"].ToString().Trim();
                                        if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Plan administered by " + std_carrier);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Plans administered by " + std_carrier + " and");
                                        }
                                    }


                                    if (fieldName.Contains("STD_LTDField"))
                                    {
                                        myMergeField.Select();
                                        if (ddlLTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("The Short Term Disability Plan is");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Both the Short Term and Long Term Disability plans are");
                                        }

                                    }

                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        }
                                    }

                                    if (fieldName.Contains("VoluntarySTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Short Term Disability Premium Calculation");
                                        }
                                    }
                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        }
                                    }
                                    if (fieldName.Contains("STD_Table"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText("");

                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        public void WriteLTDSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, DropDownList ddlVoluntaryLifeADDNoOfPlan)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                string ProductName = "";
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();
                #region HashtableLTD
                HashtableLTD.Add(2, "181");//General Plan Information – Elimination Period
                HashtableLTD.Add(3, "71");//General Plan Information – Benefit Percentage
                HashtableLTD.Add(4, "374");//General Plan Information – Monthly Benefit Maximum
                HashtableLTD.Add(5, "351");//General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(6, "449");//General Plan Information – Pre-Existing Condition Limitations


                #endregion

                string value = "";

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            //oWordDoc.Tables[7].Cell(8, 2).Range.Text = "Description";
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 2: oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = value + " from the day the disability begins"; break;
                                            case 3: oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = value + " of your monthly earnings\n\nEarnings includes your basic monthly earnings and commissions in effect prior to your period of disability.\nIt does not include bonuses or overtime pay."; break;
                                        }

                                        if (key > 3)
                                        {
                                            if (key == 5)
                                            {
                                                if (dr["UOM"].ToString() == "text")
                                                {
                                                    dr["UOM"] = "";
                                                }
                                                oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = value.Trim() + " " + dr["UOM"].ToString().Trim();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[7].Cell(key, count + 1).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {

                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LTD Plan Carrier"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Plan administered by " + (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()));
                                        }
                                    }

                                    if (fieldName.Contains("STD_LTDField"))
                                    {
                                        myMergeField.Select();
                                        if (ddlSTDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("The Long Term Disability Plan is");
                                        }
                                        //else
                                        //{
                                        //    oWordApp.Selection.TypeText("Both the Short Term and Long Term Disability plans");
                                        //}

                                    }

                                    if (fieldName.Contains("Short Term"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Short Term and Long Term Disability coverage");
                                    }
                                    if (fieldName.Contains("Income continued"))
                                    {
                                        myMergeField.Select();
                                        if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("Income Protection Benefits continued");
                                        }
                                    }
                                    if (fieldName.Contains("VoluntaryLTD Disability"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Voluntary Long Term Disability Premium Calculation");
                                        }
                                    }

                                    if (fieldName.Contains("Employee continued"))
                                    {
                                        myMergeField.Select();
                                        if (ProductName.Contains("Voluntary"))
                                        {
                                            oWordApp.Selection.TypeText("Employee Payroll Contributions continued");
                                        }
                                    }
                                    if (fieldName.Contains("LTD_Table"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText("");

                                    }

                                }

                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int MedicalCount = 0;
                int DentalCount = 0;
                int VisionCount = 0;
                List<string> ContributionDescList = new List<string>();

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");

                DataTable PremiumTable = new DataTable();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("rateTierID", typeof(int));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("contributionDescription", typeof(string));
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("ProductTypeDescription", typeof(string));
                PremiumTable.Columns.Add("SummaryName", typeof(string));

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        #region Build Contribution Table

                        // Medical Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                        {
                            MedicalCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + MedicalCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    premium_row_counter++;
                                }
                            }
                        }

                        // Dental Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                        {
                            DentalCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + DentalCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    premium_row_counter++;
                                }
                            }
                        }

                        // Vision Plan
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                        {
                            VisionCount++;

                            for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                            {
                                if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["ContributionId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                    PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                    PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                    PremiumTable.Rows[premium_row_counter][3] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"] + VisionCount.ToString();
                                    PremiumTable.Rows[premium_row_counter][4] = PlanTable.Rows[rowindex]["ProductTypeDescription"];
                                    PremiumTable.Rows[premium_row_counter][5] = PlanTable.Rows[rowindex]["SummaryName"];
                                    premium_row_counter++;
                                }
                            }
                        }

                        #endregion
                    }
                }
                DataTable dt1 = new DataTable();

                PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                dt1 = PremiumTable.DefaultView.ToTable(true);

                // The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                for (int k = 0; k < dt1.Rows.Count; k++)
                {
                    if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                    {
                        dt1.Rows[k].Delete();
                        k = k - 1;
                    }
                }

                PremiumTable = dt1;

                dt1 = PremiumTable.DefaultView.ToTable(true, "contributionDescription");
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    ContributionDescList.Add(dt1.Rows[i][0].ToString());
                }
                int m = 2;
                for (int i = 0; i < ContributionDescList.Count; i++)
                {
                    oWordDoc.Tables[9].Rows.Add();
                    if (ContributionDescList[i].ToString().Contains("Employee"))
                    {
                        oWordDoc.Tables[9].Cell(m, 1).Range.Text = ContributionDescList[i].ToString() + " Only";
                    }
                    else if (ContributionDescList[i].ToString().Contains("Spouse & Child(ren) (Family)"))
                    {
                        oWordDoc.Tables[9].Cell(m, 1).Range.Text = "Employee & " + ContributionDescList[i].ToString().Replace("Spouse & Child(ren) (Family)", "Spouse & Child(ren)");
                    }
                    else
                    {
                        oWordDoc.Tables[9].Cell(m, 1).Range.Text = "Employee & " + ContributionDescList[i].ToString();
                    }
                    m++;
                }
                string OldRateDesc = "";
                int rowcount = 1;

                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                {
                    if (OldRateDesc != PremiumTable.Rows[i]["contributionDescription"].ToString())
                    {
                        rowcount++;
                        OldRateDesc = PremiumTable.Rows[i]["contributionDescription"].ToString();
                    }

                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalPlanType + "1")
                    {
                        oWordDoc.Tables[9].Cell(1, 2).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();

                        oWordDoc.Tables[9].Cell(rowcount, 2).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalPlanType + "2")
                    {
                        oWordDoc.Tables[9].Cell(1, 3).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 3).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.MedicalPlanType + "3")
                    {
                        oWordDoc.Tables[9].Cell(1, 4).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 4).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.DentalPlanType + "1")
                    {
                        oWordDoc.Tables[9].Cell(1, 5).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 5).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.DentalPlanType + "2")
                    {
                        oWordDoc.Tables[9].Cell(1, 6).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 6).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.VisionPlanType + "1")
                    {
                        oWordDoc.Tables[9].Cell(1, 7).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 7).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                    if (PremiumTable.Rows[i]["Plan"].ToString() == cv.VisionPlanType + "2")
                    {
                        oWordDoc.Tables[9].Cell(1, 8).Range.Text = PremiumTable.Rows[i]["ProductTypeDescription"].ToString() + "\n" + PremiumTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[9].Cell(rowcount, 8).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                    }
                }
                oWordDoc.Tables[9].Rows.Last.Delete();
                oWordDoc.Tables[9].PreferredWidth = oWordApp.InchesToPoints(7.99f);
                int ColumnCount = oWordDoc.Tables[9].Columns.Count;
                bool flag1 = false;

                while (ColumnCount > 1)
                {
                    for (int i = 2; i < oWordDoc.Tables[9].Rows.Count; i++)
                    {
                        if (oWordDoc.Tables[9].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
                        {
                            flag1 = false;
                            break;
                        }
                        else
                        {
                            flag1 = true;
                        }
                    }
                    if (flag1 == true)
                    {
                        oWordDoc.Tables[9].Columns[ColumnCount].Delete();

                    }
                    ColumnCount--;
                }

                oWordDoc.Tables[9].PreferredWidth = oWordApp.InchesToPoints(7.99f);

                #region merge fields
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();


                        if (fieldName.Contains("Employee Payroll Contributions"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Employee Payroll Contributions");
                        }

                        if (PremiumTable.Rows.Count > 0)
                        {
                            if (fieldName.Contains("RateTable"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        public void WriteEAPSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                string OldCarrier = "";
                ConstantValue cv = new ConstantValue();
                int count = 1;
                Hashtable HashtableEAP = new Hashtable();
                HashtableEAP.Add(1, "384");

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            /*Added by client requirement --- starts here --- 03 June 2014*/
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                oWordDoc.Tables[1].Cell(8, 2).Select();
                                if (count == 1)
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = PlanTable.Rows[k]["Carrier"].ToString();
                                }
                                else
                                {
                                    oWordDoc.Tables[1].Cell(8, 2).Range.Text = oWordDoc.Tables[1].Cell(7, 2).Range.Text + "\n" + PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();

                            }
                            /*Added by client requirement --- ends here --- 03 June 2014*/

                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {

                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {

                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();


                                                if (fieldName.Contains("Number of Visit Item"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                }

                                                if (fieldName.Contains("EAP Plan Carrier"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                }
                                                if (fieldName.Contains("EAP_Heading"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Employee Assistance Program");
                                                }
                                                if (fieldName.Contains("Employee Assistance Program"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("Employee Assistance Program");
                                                }
                                            }

                                        }
                                        #endregion

                                    }
                                }

                            }


                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        ///  Write Annual Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlChipNotice, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;


                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {

                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {

                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        /// As suggested by client this code is commented -- 03 June 2014 start here
                        //if (fieldName.Equals("CHIPNotices"))
                        //{
                        //    if (ddlChipNotice.SelectedIndex == 1)
                        //    {
                        //        myMergeField.Select();
                        //        oWordApp.Selection.TypeText("CHIP NOTICE");
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //}
                        /// As suggested by client this code is commented -- 03 June 2014 end here

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                            }
                            // code added by vaibhav and shravan for spanish chip notice 
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                if (ddlChipNotice.SelectedIndex >= 1)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }

                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                //Commented by Vaibhav
                //comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
                //Added by Vaibhav
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="Office">Office Table conatain data for selected office</param>
        /// <param name="BRCList">Office Table conatain data for selected BRC</param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC conatain data for selected BRC</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        public void WriteFieldToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable Office, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                int index = -1;

                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {

                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                    }

                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                    }

                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[rowindex]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                    }

                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                        }

                                        if (fieldName.Contains("Frequency"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                        }
                                        if (fieldName.Contains("Unit to Measure"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Waiting Period"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[rowindex]["item"].ToString().Trim());
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                            }

                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteContactInformationToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                DataRow[] foundRows = null;
                int MedicalCount = 0;
                string OldMedicalCarrier = "";
                int DentalCount = 0;
                string OldDentalCarrier = "";
                int VisionCount = 0;
                string OldVisionCarrier = "";
                string OldSTDCarrier = "";
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                    #region Medical
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        MedicalCount++;
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Equals("MedicalContactCarrier" + MedicalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldMedicalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Medical");
                                    }
                                }
                                if (fieldName.Contains("MedicalContactWebsite" + MedicalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldMedicalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                                if (fieldName.Contains("MedicalContactPhone" + MedicalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldMedicalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                        }
                        OldMedicalCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                    }
                    #endregion
                    #region Dental
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        DentalCount++;
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Equals("DentalContactCarrier" + DentalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldDentalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Dental");
                                    }
                                }
                                if (fieldName.Contains("DentalContactWebsite" + DentalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldDentalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                                if (fieldName.Contains("DentalContactPhone" + DentalCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldDentalCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                        }
                        OldDentalCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                    }
                    #endregion
                    #region Vision
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        VisionCount++;
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Equals("VisonContactCarrier" + VisionCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldVisionCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Vision");
                                    }
                                }
                                if (fieldName.Contains("VisionContactWebsite" + VisionCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldVisionCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                                if (fieldName.Contains("VisonContactPhone" + VisionCount.ToString()))
                                {
                                    myMergeField.Select();
                                    if (OldVisionCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                        }
                        OldVisionCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                    }
                    #endregion
                    #region Life
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LifeADDPlanType.ToLower().Trim())
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {

                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("LifeContactCarrier"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Life");
                                }
                                if (fieldName.Contains("LifeContactWebsite"))
                                {
                                    myMergeField.Select();
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("LifeContactPhone"))
                                {
                                    myMergeField.Select();
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }

                                }
                            }
                        }
                    }
                    #endregion
                    #region STD
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {

                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("STDContactCarrier"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Disability");
                                }
                                if (fieldName.Contains("STDContactWebsite"))
                                {
                                    myMergeField.Select();
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                                if (fieldName.Contains("STDContactPhone"))
                                {
                                    myMergeField.Select();
                                    if (foundRows.Count() > 0)
                                    {
                                        oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                    }
                                    else
                                    {
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                            }
                        }
                        OldSTDCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim());
                    }
                    #endregion
                    #region LTD
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {

                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {

                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();
                                if (fieldName.Contains("LTDContactCarrier"))
                                {
                                    myMergeField.Select();
                                    if (OldSTDCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        oWordApp.Selection.TypeText((PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()) + "- Disability");
                                    }
                                }
                                if (fieldName.Contains("LTDContactWebsite"))
                                {
                                    myMergeField.Select();
                                    if (OldSTDCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                                if (fieldName.Contains("LTDContactPhone"))
                                {
                                    myMergeField.Select();
                                    if (OldSTDCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                                    {
                                        if (foundRows.Count() > 0)
                                        {
                                            oWordApp.Selection.TypeText(foundRows[0]["PhoneNumber"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();
                //List<string> RateDescList = new List<string>();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        //Generate Voluntary Life Column Dynamically.
                        //DataTable VoluntaryColumnHeding = new DataTable();

                        //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                        //VoluntaryColumnHeding = PremiumTable.DefaultView.ToTable(true);
                        //PremiumTable = VoluntaryColumnHeding;
                        //VoluntaryColumnHeding = PremiumTable.DefaultView.ToTable(true, "rateTier_description");
                        //for (int i = 0; i < VoluntaryColumnHeding.Rows.Count; i++)
                        //{
                        //    RateDescList.Add(VoluntaryColumnHeding.Rows[i][0].ToString());
                        //    oWordDoc.Tables[8].Columns.Add();
                        //    if (VoluntaryColumnHeding.Rows[i][0].ToString().Contains("EE"))
                        //    {
                        //        oWordDoc.Tables[8].Cell(2, i + 2).Range.Text = VoluntaryColumnHeding.Rows[i][0].ToString().Replace("EE", "Employee");
                        //    }
                        //    else
                        //    {
                        //        oWordDoc.Tables[8].Cell(2, i + 2).Range.Text = "Employee &" + VoluntaryColumnHeding.Rows[i][0].ToString();
                        //    }
                        //}

                        oWordDoc.Tables[10].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                        int StartValue = Start;
                        int RowCount = 4;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[10].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[10].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[10].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[10].Rows.Add();
                        oWordDoc.Tables[10].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[10].Rows.Add();
                        oWordDoc.Tables[10].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        //oWordDoc.Tables[10].Rows.Add();
                        //oWordDoc.Tables[10].Cell(RowCount + 2, 1).Range.Text = "Per $1,000 Child Life";
                        //oWordDoc.Tables[10].Cell(RowCount + 2, 2).Merge(oWordDoc.Tables[10].Cell(RowCount + 2, 3));
                        string dependent_child_life = string.Empty;

                        int ColumnCount = 0;
                        int oldageBand = -1;
                        DataTable dt = new DataTable();

                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 3;
                        int RowCount1 = 3;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            // for (int j = 0; j < RateDescList.Count; j++)
                            //{
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                oWordDoc.Tables[10].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount++;
                            }
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker")
                            {
                                ColumnCount = 3;
                                oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                oWordDoc.Tables[10].Cell(RowCount1, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount1++;
                            }
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                            {
                                ColumnCount = 2;
                                dependent_child_life = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                //RowCount1++;
                            }
                            //if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                            //{
                            //    RowCount++;
                            //}
                            ////oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());
                            //oWordDoc.Tables[8].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                            // }
                        }

                        if (!string.IsNullOrEmpty(dependent_child_life))
                        {
                            oWordDoc.Tables[10].Rows.Add();
                            oWordDoc.Tables[10].Cell(RowCount + 2, 1).Range.Text = "Per $1,000 Child Life";
                            oWordDoc.Tables[10].Cell(RowCount + 2, 2).Merge(oWordDoc.Tables[10].Cell(RowCount + 2, 3));
                            oWordDoc.Tables[10].Cell(RowCount + 2, 2).Range.Text = dependent_child_life;

                        }

                        oWordDoc.Tables[10].PreferredWidth = oWordApp.InchesToPoints(7.99f);
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary STD  and LTD Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntarySTDandLTDMonthlyPremiumSectionToTemplate2(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();

                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));
                int Start = 0;
                int End = 0;
                int Interval = 0;

                int ColumnCount = 0;
                int oldageBand = -1;
                int PlanCount = 0;
                DataTable dt = new DataTable();
                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType.ToLower() || PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType.ToLower())
                    {
                        PlanCount++;
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"] != null)
                        {
                            Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"] != null)
                        {
                            End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        }
                        if (RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"] != null)
                        {
                            Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;
                        }
                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {

                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        int StartValue = Start;
                        int RowCount = 5;

                        if (Start > 0 && PlanCount == 1)
                        {
                            oWordDoc.Tables[11].Cell(4, 1).Range.Text = "Under " + Start.ToString();

                            while (StartValue < End - 1)
                            {
                                oWordDoc.Tables[11].Rows.Add();
                                if (StartValue == Start)
                                {
                                    oWordDoc.Tables[11].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                    StartValue = Start + Interval;
                                }
                                else
                                {
                                    oWordDoc.Tables[11].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                    StartValue = StartValue + Interval + 1;
                                }
                                RowCount++;
                            }
                            oWordDoc.Tables[11].Rows.Add();
                            oWordDoc.Tables[11].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                            oWordDoc.Tables[11].Rows.Add();
                            oWordDoc.Tables[11].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        }


                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 3;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.STDPlanType)
                            {
                                ColumnCount = 2;
                            }

                            if (PremiumTable.Rows[i]["Plan"].ToString() == cv.LTDPlanType)
                            {
                                ColumnCount = 3;
                            }
                            if (int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString()) != oldageBand)
                            {
                                RowCount++;
                            }
                            oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                            oWordDoc.Tables[11].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                        }
                    }
                }

                ColumnCount = oWordDoc.Tables[11].Columns.Count;
                bool flag = false;
                if (oWordDoc.Tables[11].Rows.Count < 5)
                {
                    oWordDoc.Tables[11].Delete();
                }
                else
                {
                    while (ColumnCount > 1)
                    {
                        for (int i = 4; i < oWordDoc.Tables[11].Rows.Count; i++)
                        {
                            if (oWordDoc.Tables[11].Cell(i, ColumnCount).Range.Text.Trim() != "\a")
                            {
                                flag = false;
                                break;
                            }
                            else
                            {
                                flag = true;
                            }
                        }
                        if (flag == true)
                        {
                            oWordDoc.Tables[11].Columns[ColumnCount].Delete();

                        }
                        ColumnCount--;
                    }
                }
                oWordDoc.Tables[11].PreferredWidth = oWordApp.InchesToPoints(7.99f);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Delete Row if only STD or LTD plan seleted.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        public void DeleteDisabilityRow(Word.Document oWordDoc, Word.Application oWordApp)
        {
            try
            {
                int RowCount = oWordDoc.Tables[6].Rows.Count;

                while (RowCount > 0)
                {
                    if (oWordDoc.Tables[6].Cell(RowCount, 2).Range.Text.Trim() == "\a")
                    {
                        oWordDoc.Tables[6].Rows[RowCount].Delete();
                    }
                    RowCount--;
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}