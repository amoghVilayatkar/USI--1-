﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_SpringField : System.Web.UI.Page
    {


        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        static Dictionary<string, Dictionary<string, string>> AllBookmarks = new Dictionary<string, Dictionary<string, string>>();

        List<int> Medical_BenefitColumn_Level1 = new List<int>() { 100, 101, 103, 106, 108, 111, 112, 114 };
        List<int> Medical_BenefitColumn_Level2 = new List<int>() { 113, 109, 107, 104, 102 };
        List<int> Medical_BenefitColumn_Level3 = new List<int>() { 105, 110 };

        List<int> Dental_BenefitColumn_Level3 = new List<int>() { 120 };
        List<int> Dental_BenefitColumn_Level2 = new List<int>() { 119, 117 };
        List<int> Dental_BenefitColumn_Level1 = new List<int>() { 115, 116, 118, 121 };
        List<int> lstPlanTier = new List<int>();

        public void Write_CommonFieldToSpringField(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, DataSet ProductDS, DataSet EligibilityDS, DataTable EmpTable, string ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, ArrayList arrAcctContact, List<BRCData> BRCList)
        {
            try
            {
                ////Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();

                int index = -1;
                string CompanyAddress = string.Empty;
                string CompanyStatePincode = string.Empty;
                string CompanyPhone = string.Empty;
                string City = string.Empty;
                string State = string.Empty;
                string Zip = string.Empty;
                string Street1 = string.Empty;
                string Street2 = string.Empty;


                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (EmpTable.Rows.Count > 0)
                {
                    Emp = EmpTable;
                }




                #region Write Table of Account Contacts
                string AccountContactname = string.Empty;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        AccountContactname = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        AccountContactname = " ";
                                    }

                                }
                            }
                        }
                    }
                }
                #endregion



                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                                State = State.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["individualAccountInfo_phone_number"])))
                            {
                                CompanyPhone = Convert.ToString(AccountDS.Tables[1].Rows[j]["individualAccountInfo_phone_number"]);
                            }
                        }
                    }
                }//AccountDS Close

                CompanyStatePincode = City + ", " + State + " " + Zip;
                CompanyAddress = Street1 + " " + Street2;
                CompanyPhone = "";

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;
                                Word.Range rngFieldCode = myMergeField.Code;
                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("ClientName"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(ddlClient))
                                        {
                                            oWordApp.Selection.TypeText(ddlClient);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }

                                        continue;
                                    }

                                    if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                                        continue;
                                    }
                                    ////if (fieldName.Contains("Plan Effective Date Year"))
                                    ////{
                                    ////    myMergeField.Select();
                                    ////    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    ////    string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                    ////    oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                    ////    continue;
                                    ////}
                                    if (fieldName.Contains("Date Of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        //oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }



                                    if (fieldName.Contains("definitionofdomesticpartner"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                            if (domesticPartner.Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(domesticPartner);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(domesticPartner.Trim());
                                            }
                                        }
                                    }

                                    ///Account Conact Name 
                                    if (fieldName.Contains("AccountContact_Name"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(AccountContactname))
                                        {
                                            oWordApp.Selection.TypeText(AccountContactname);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }




                                    if (fieldName.Contains("medicalplanwaitingperiod"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().ToLower().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    /*******COMPANY DETAILS */
                                    //Company_Address
                                    if (fieldName.Contains("Company_Address"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(CompanyAddress))
                                        {
                                            oWordApp.Selection.TypeText(CompanyAddress);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    //CompanyCity_StateZipCode
                                    if (fieldName.Contains("CompanyCity_StateZipCode"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(CompanyStatePincode))
                                        {
                                            oWordApp.Selection.TypeText(CompanyStatePincode);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    //CompanyPhoneNum
                                    if (fieldName.Contains("CompanyPhoneNum"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(CompanyPhone))
                                        {
                                            oWordApp.Selection.TypeText(CompanyPhone);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("BRCTimeZone"))
                                    {
                                        myMergeField.Select();

                                        if (BRCList[0].BRCTimezone.Trim().Length == 0)
                                        {
                                            myMergeField.Delete();
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(BRCList[0].BRCDayHours);
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("BRC_Phone_Number"))
                                    {
                                        myMergeField.Select();

                                        if (BRCList[0].BRCDayHours.Trim().Length == 0)
                                        {
                                            myMergeField.Delete();
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(BRCList[0].BRCPhone.Trim());
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("BRC_EMAIL"))
                                    {
                                        myMergeField.Select();

                                        if (BRCList[0].BRCEmail.Trim().Length == 0)
                                        {
                                            myMergeField.Delete();
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(BRCList[0].BRCEmail.Trim());
                                        }
                                        continue;
                                    }

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteMedicalSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DropDownList ddlClient, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataSet EligibilityDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {

            try
            {
                lstPlanTier.Clear();
                List<int> SkippedRowIndexes = new List<int>() { 3, 7, 10, 13, 16, 23, 26, 29, 31, 36 };
                string Renewaldate = string.Empty;
                string Effectivedate = string.Empty;
                DataTable Emp = new DataTable();
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);
                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();


                foreach (object item in MedicalBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in MedicalBenefitColumnIdOutNetworkList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }
                int TablesUsed = 1;
                int CurrentColumnIndex = 2;
                int CurrentTableIndex = 1;
                int WriteCount = 0;
                int ColumnIncreament = 0;
                int RemainingBenefitCount = 3;
                int HeaderColumnIndex = 2;
                List<int> Contributions = new List<int>();
                string strAllCarriers = "";
                string FirstRenewalDate = string.Empty;
                string FirstEffectiveDate = string.Empty;
                float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;
                int ContributionStartCount = 0;
                int TotalContributionCount = 0;

                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            WriteCount++;
                            RemainingBenefitCount--;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            if (WriteCount % 3 == 0)
                            {
                                oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Copy();
                                for (int i = 1; i < TotalContributionCount; i++)
                                {
                                    oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                                    oWordApp.Selection.Paste();
                                }

                                oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                                TablesUsed++;
                                TotalContributionCount = 0;
                                RemainingBenefitCount = 3;
                            }
                        }
                    }
                }
                if (RemainingBenefitCount != 3)
                {
                    oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Copy();
                    for (int i = 1; i < TotalContributionCount; i++)
                    {
                        oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                        oWordApp.Selection.Paste();
                    }
                    oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["MedicalContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                }

                TablesUsed = 1;
                TotalContributionCount = 0;
                RemainingBenefitCount = 3;
                WriteCount = 0;
                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        Renewaldate = drPlanRow["Renewal"].ToString();
                        Effectivedate = drPlanRow["Effective"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();
                        if (string.IsNullOrEmpty(FirstRenewalDate))
                        {
                            FirstRenewalDate = Convert.ToDateTime(Renewaldate).Year.ToString();
                            FirstEffectiveDate = Effectivedate;
                        }

                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            lstPlanTier.Add(PlanTier);
                            WriteCount++;
                            RemainingBenefitCount--;

                            switch (PlanTier)
                            {
                                case 1:
                                    // Benefits Table 
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);

                                    ColumnIncreament = 1;
                                    break;
                                case 2:
                                    // Benefits Table 
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippedRowIndexes);

                                    ColumnIncreament = 2;
                                    break;
                                case 3:
                                    ColumnIncreament = 3;
                                    break;
                            }
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                            string AttributeValue = "";


                            oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                            //oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Font.Color = WdColor.wdColorWhite;
                            // oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.

                            string strFieldText = "a " + ProduTypeDescription + " through " + Carrier;

                            if (string.IsNullOrEmpty(strAllCarriers))
                                strAllCarriers = strFieldText;
                            else
                            {
                                if (!strAllCarriers.Contains(strFieldText))
                                    strAllCarriers = strAllCarriers + ", " + strFieldText;
                            }


                            #region Benefits Coverage

                            #region Annual Deductible Individual - 4
                            //In Network
                            DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                                int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                            }

                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkIndividual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                                    int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkIndividual["benefitColumnID"].ToString());
                                    string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3Individual != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                        int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3Individual["benefitColumnID"].ToString());
                                        string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                        oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }

                            }
                            // Out Network

                            AttributeValue = "";
                            #endregion

                            #region Annual Deductible Family - 5
                            //In Network
                            DataRow drBenefitValues_InNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3Family = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3Family != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Family);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Annual Deductible Coinsurance - 6
                            //In Network
                            DataRow drBenefitValues_InNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkCoinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkCoinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3Coinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 112 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3Coinsurance != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Coinsurance);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Maximum Pocket Individual - 8
                            //In Network
                            DataRow drBenefitValues_InNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPockIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockIndividual);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPockIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPockIndividual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockIndividual);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3Individual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 53 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3Individual != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3Individual);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }

                            AttributeValue = "";
                            #endregion

                            #region Maximum Pocket Family - 9
                            //In Network
                            DataRow drBenefitValues_InNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPockFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPockFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPockFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPockFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3PockFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 52 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3PockFamily != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PockFamily);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Physical Office Visit -Primary Care -11
                            DataRow drBenefitValues_InNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPhysicalOfficePrimaryCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficePrimaryCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPhysicalOfficePrimaryCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficePrimaryCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3PhysicalOfficePrimaryCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 386 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3PhysicalOfficePrimaryCare != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PhysicalOfficePrimaryCare);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Physical Office Visit -Specialty Care - 12
                            //In Network
                            DataRow drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPhysicalOfficeSpecialtyCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPhysicalOfficeSpecialtyCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Leve3PhysicalOfficeSpecialtyCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 414 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Leve3PhysicalOfficeSpecialtyCare != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PhysicalOfficeSpecialtyCare);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(12, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Physical Office Visit - Preventive Adult Periodic Exams - 14
                            //In Network
                            DataRow drBenefitValues_InNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPreventiveAdultPeriodicExams != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveAdultPeriodicExams);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPreventiveAdultPeriodicExams != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveAdultPeriodicExams);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3PreventiveAdultPeriodicExams = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 16 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3PreventiveAdultPeriodicExams != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3PreventiveAdultPeriodicExams);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Physical Office Visit - Preventive Well-Child Care - 15
                            //InNetwork
                            DataRow drBenefitValues_InNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkPreventiveWellChildCare != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkPreventiveWellChildCare);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkPreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkPreventiveWellChildCare != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkPreventiveWellChildCare);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Leve3PreventiveWellChildCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 571 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Leve3PreventiveWellChildCare != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3PreventiveWellChildCare);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - X-ray and Lab Tests = 17
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDisgnisticXrayLabTest != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticXrayLabTest);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDisgnisticXrayLabTest != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticXrayLabTest);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_level3DisgnisticXrayLabTest = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 168 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_level3DisgnisticXrayLabTest != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticXrayLabTest);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - Complex Radiology = 18
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDisgnisticComplexRadiology != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticComplexRadiology);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDisgnisticComplexRadiology != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticComplexRadiology);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_level3DisgnisticComplexRadiology = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 971 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_level3DisgnisticComplexRadiology != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_level3DisgnisticComplexRadiology);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(18, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - Urgent Care Facility - 19
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 555 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(19, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - EmergencyRoom - 20
                            //InNetwork
                            DataRow drBenefitValues_InNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkEmrgRoomFacilityCharge != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkEmrgRoomFacilityCharge);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkEmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkEmrgRoomFacilityCharge != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkEmrgRoomFacilityCharge);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Leve3EmrgRoomFacilityCharge = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 184 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Leve3EmrgRoomFacilityCharge != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Leve3EmrgRoomFacilityCharge);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(20, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - Inpatient Facility Charges - 21
                            //InNetwork
                            DataRow drBenefitValues_InNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkInpatientFacilityCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkInpatientFacilityCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkInpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkInpatientFacilityCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkInpatientFacilityCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3InpatientFacilityCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 295 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3InpatientFacilityCharges != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3InpatientFacilityCharges);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(21, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Dignistic Services - Outpatient Facility and Surgical Charges- 22
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientFacilityandSurgicalCharges);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientFacilityandSurgicalCharges);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutpatientFacilityandSurgicalCharges = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 409 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutpatientFacilityandSurgicalCharges != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientFacilityandSurgicalCharges);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(22, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }

                            AttributeValue = "";
                            #endregion

                            #region Mental Health - Inpatient - 24
                            //InNetwork
                            DataRow drBenefitValues_InNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkMentalHealthInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkMentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkMentalHealthInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3MentalHealthInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 287 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3MentalHealthInpatient != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalHealthInpatient);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(24, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Mental Health - Inpatient - 25
                            //InNetwork
                            DataRow drBenefitValues_InNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkMentalHealthOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalHealthOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkMentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkMentalHealthOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalHealthOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValuesLevel3MentalHealthOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 407 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValuesLevel3MentalHealthOutpatient != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValuesLevel3MentalHealthOutpatient);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(25, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }

                            AttributeValue = "";
                            #endregion

                            #region Substance Abuse - Inpatient - 27
                            //InNetwork
                            DataRow drBenefitValues_InNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkMentalSubAbuseInpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseInpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkMentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkMentalSubAbuseInpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseInpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3MentalSubAbuseInpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 670 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3MentalSubAbuseInpatient != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseInpatient);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(27, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Substance Abuse - Outpatient - 28
                            //InNetwork
                            DataRow drBenefitValues_InNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkMentalSubAbuseOutpatient != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkMentalSubAbuseOutpatient);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkMentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkMentalSubAbuseOutpatient != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkMentalSubAbuseOutpatient);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3MentalSubAbuseOutpatient = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 673 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3MentalSubAbuseOutpatient != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3MentalSubAbuseOutpatient);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(28, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Other Services - Chiropractic - 30
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOtherServiceChiropractic != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOtherServiceChiropractic);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOtherServiceChiropractic != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOtherServiceChiropractic);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OtherServiceChiropractic = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 107 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OtherServiceChiropractic != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OtherServiceChiropractic);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(30, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion
                            #endregion

                            #region PharmacySesion

                            #region Retail Pharmacy (30 Day Supply)- Generic (Tier 1)- 3
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutpatientGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutpatientGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutpatientGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutpatientGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 213 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutpatientGenericFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientGenericFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(32, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion


                            #region Retail Pharmacy (30 Day Supply)- Preferred (Tier 2)- 4
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 78 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutPreferredFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutPreferredFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(33, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Retail Pharmacy (30 Day Supply)- Non-Preferred (Tier 3)- 5
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutpatientNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutpatientNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutpatientNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 84 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutpatientNonPreferredFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutpatientNonPreferredFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(34, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Retail Pharmacy (30 Day Supply)- Preferred Specialty (Tier 4)- 6
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_LEVEL3OutPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 881 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_LEVEL3OutPreferredSpecialtyFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_LEVEL3OutPreferredSpecialtyFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(35, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }

                            }
                            AttributeValue = "";
                            #endregion

                            #region Mail Order Pharmacy (90 Day Supply)- Generic (Tier 1)- 8
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutMailOrderGenericFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderGenericFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutMailOrderGenericFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderGenericFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutMailOrderGenericFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 211 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutMailOrderGenericFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderGenericFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(37, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Mail Order Pharmacy (90 Day Supply)- Preferred (Tier 2)- 9
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutMailOrderPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutMailOrderPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutMailOrderPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 76 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutMailOrderPreferredFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(38, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Mail Order Pharmacy (90 Day Supply)- Non-Preferred (Tier 3)- 10
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutMailOrderNonPreferredFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderNonPreferredFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderNonPreferredFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutMailOrderNonPreferredFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 82 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutMailOrderNonPreferredFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderNonPreferredFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(39, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Mail Order Pharmacy (90 Day Supply)- Preferred Specialty (Tier 4)- 11
                            //InNetwork
                            DataRow drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkOutMailOrderPreferredSpecialtyFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkOutMailOrderPreferredSpecialtyFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";

                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 884 AND benefitColumnID IN (" + string.Join(",", Medical_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3OutMailOrderPreferredSpecialtyFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(40, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                }
                            }
                            AttributeValue = "";
                            #endregion



                            #endregion

                            CurrentColumnIndex += ColumnIncreament;
                            HeaderColumnIndex += 1;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                            ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                            if (AllBookmarks["Medical"].ContainsKey("MedicalPlanTables" + TablesUsed))      //MedicalHMODescription1  MedicalPPODescription1
                            {
                                AllBookmarks["Medical"].Remove("MedicalPlanTables" + TablesUsed);
                            }

                            if (WriteCount % 3 == 0)
                            {
                                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                                CurrentColumnIndex = 2;
                                HeaderColumnIndex = 2;
                                CurrentTableIndex = CurrentTableIndex + TotalContributionCount + 1;
                                RemainingBenefitCount = 3;
                                TablesUsed += 1;
                                ContributionStartCount = 0;
                                TotalContributionCount = 0;
                                lstPlanTier.Clear();
                            }
                        }

                    }

                }

                if (RemainingBenefitCount != 3)
                {
                    int BodyMergeStartIndex = CurrentColumnIndex - 1;
                    int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                    int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                    // Benefits
                    MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                    MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                    AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                    //Pharmacy
                }

                #region MergeField

                int iTotalFields = 0;
                strAllCarriers = strAllCarriers.TrimEnd(',');
                if (WriteCount > 1 && strAllCarriers.Contains(","))
                {
                    int lastIndex = strAllCarriers.LastIndexOf(',');
                    strAllCarriers = (strAllCarriers.Substring(0, lastIndex) + " and " + strAllCarriers.Substring(lastIndex + 1));
                }
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("FirstMedRenewalYear"))
                        {
                            myMergeField.Select();
                            string effectivedate = Effectivedate;
                            // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                            DateTime effective_date = Convert.ToDateTime(effectivedate);
                            oWordApp.Selection.TypeText(effective_date.Year.ToString());
                            continue;
                        }
                        if (fieldName.Contains("FirstMedRenewalDate"))
                        {
                            myMergeField.Select();
                            string effectivedate = FirstEffectiveDate;
                            // oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                            DateTime effective_date = Convert.ToDateTime(effectivedate);
                            oWordApp.Selection.TypeText(Convert.ToDateTime(effective_date.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effective_date.ToString()).Year.ToString());
                            continue;
                        }
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void WriteDentalSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            try
            {

                lstPlanTier.Clear();
                List<int> SkippeRowSpan = new List<int>() { 3, 7, 12 };
                string Renewaldate = string.Empty;
                string Effectivedate = string.Empty;

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();
                string strAllCarriers = "";

                foreach (object item in DentalBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in DentalBenefitColumnIdOutNetworkList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }

                int TablesUsed = 1;
                int CurrentColumnIndex = 2;
                int CurrentTableIndex = 5;
                int WriteCount = 0;
                int ColumnIncreament = 0;
                int RemainingBenefitCount = 3;
                int HeaderColumnIndex = 2;
                List<int> Contributions = new List<int>();
                float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(4, 1).Width;
                int ContributionStartCount = 0;
                int TotalContributionCount = 0;

                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            WriteCount++;
                            RemainingBenefitCount--;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            if (WriteCount % 3 == 0)
                            {
                                oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Copy();
                                for (int i = 1; i < TotalContributionCount; i++)
                                {
                                    oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                                    oWordApp.Selection.Paste();
                                }

                                oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                                TablesUsed++;
                                TotalContributionCount = 0;
                                RemainingBenefitCount = 3;
                            }
                        }
                    }
                }
                if (RemainingBenefitCount != 3)
                {
                    oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Copy();
                    for (int i = 1; i < TotalContributionCount; i++)
                    {
                        oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                        oWordApp.Selection.Paste();
                    }
                    oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["DentallContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                }

                TablesUsed = 1;
                TotalContributionCount = 0;
                RemainingBenefitCount = 3;
                WriteCount = 0;

                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        Renewaldate = drPlanRow["Renewal"].ToString();
                        Effectivedate = drPlanRow["Effective"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();
                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                        if (string.IsNullOrEmpty(strAllCarriers))
                            strAllCarriers = Carrier;
                        else
                            strAllCarriers = strAllCarriers + "," + Carrier;

                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            lstPlanTier.Add(PlanTier);
                            WriteCount++;
                            RemainingBenefitCount--;

                            switch (PlanTier)
                            {
                                case 1:
                                    // Benefits Table 
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 2, 2, null);
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                    ColumnIncreament = 1;
                                    break;
                                case 2:
                                    // Benefits Table 
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 2, 2, null);
                                    MergeTableColumns(oWordDoc, CurrentTableIndex, CurrentColumnIndex + 1, CurrentColumnIndex + 2, 3, int.MaxValue, SkippeRowSpan);
                                    ColumnIncreament = 2;
                                    break;
                                case 3:
                                    ColumnIncreament = 3;
                                    break;
                            }
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                            string AttributeValue = "";
                            oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                            #region Benefits Coverage

                            #region Annual Deductible Individual - 4
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalIndividual != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalIndividual);
                                int BenefitColumnID_Level1 = int.Parse(drBenefitValues_InNetworkDentalIndividual["benefitColumnID"].ToString());
                                string ColumnNameLevel1 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level1);
                                oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex).Range.Text = ColumnNameLevel1;
                            }

                            oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            // Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalIndividual != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalIndividual);
                                    int BenefitColumnID_Level2 = int.Parse(drBenefitValues_OutNetworkDentalIndividual["benefitColumnID"].ToString());
                                    string ColumnNameLevel2 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level2);
                                    oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 1).Range.Text = ColumnNameLevel2;
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 45 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalIndividual != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalIndividual);
                                        int BenefitColumnID_Level3 = int.Parse(drBenefitValues_Level3DentalIndividual["benefitColumnID"].ToString());
                                        string ColumnNameLevel3 = comFunObj.GetBenefitColumnName(BenefitColumnID_Level3);
                                        oWordDoc.Tables[CurrentTableIndex].Cell(2, CurrentColumnIndex + 2).Range.Text = ColumnNameLevel3;
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(4, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Annual Deductible Family - 5
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalFamily != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalFamily);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDenatlFamily != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDenatlFamily);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DenatlFamily = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 44 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DenatlFamily != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DenatlFamily);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }

                            AttributeValue = "";
                            #endregion

                            #region Annual Deductible Waived for Preventive Care - 6
                            //In Network
                            DataRow drBenefitValues_InNetworkDenatlCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDenatlCoinsurance != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDenatlCoinsurance);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalCoinsurance != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalCoinsurance);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalCoinsurance = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 566 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalCoinsurance != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalCoinsurance);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Per Person/Family (indicate calendar/benefit year) - 8
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalAnnualPlanMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalAnnualPlanMaximum);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalAnnualPlanMaximum != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalAnnualPlanMaximum);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalAnnualPlanMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 55 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalAnnualPlanMaximum != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalAnnualPlanMaximum);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(8, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Preventive - 9
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalPreventive != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalPreventive);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalPreventive != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalPreventive);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalPreventive = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 164 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalPreventive != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalPreventive);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(9, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Basic Services – Basic -10
                            DataRow drBenefitValues_InNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalBasicServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalBasicServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalBasicServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalBasicServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalBasicServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 64 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalBasicServices != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalBasicServices);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(10, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Major Services – Major - 11
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalMajorServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalMajorServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalMajorServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalMajorServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalMajorServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 336 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalMajorServices != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalMajorServices);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Orthodontia-Orthodontia Services / Orthodontia - 13
                            //In Network
                            DataRow drBenefitValues_InNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalOrthodontiaServices != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontiaServices);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";
                            //Out Network
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalOrthodontiaServices != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontiaServices);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalOrthodontiaServices = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 392 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalOrthodontiaServices != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontiaServices);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(13, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Orthodontia Services / Adults (and covered full-time students - 14
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 17 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalOrthodontia != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalOrthodontia);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(14, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region Orthodontia Services / Dependent Children 15
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalDependentChildren != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalDependentChildren);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalDependentChildren != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalDependentChildren);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalDependentChildren = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 152 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalDependentChildren != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalDependentChildren);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(15, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region General Plan Information – Lifetime Orthodontial Plan Maximum -16
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDentalLifetimeOrthodontia != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDentalLifetimeOrthodontia);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDentalLifetimeOrthodontia != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDentalLifetimeOrthodontia);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DentalLifetimeOrthodontia = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 314 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DentalLifetimeOrthodontia != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DentalLifetimeOrthodontia);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(16, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #region General Plan Information – Waiting Period - 17
                            //InNetwork
                            DataRow drBenefitValues_InNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level1) + ") ").FirstOrDefault();
                            if (drBenefitValues_InNetworkDisgnisticUrgentCareFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkDisgnisticUrgentCareFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            //OutNetwork
                            if (PlanTier >= 2)
                            {
                                DataRow drBenefitValues_OutNetworkDisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level2) + ") ").FirstOrDefault();
                                if (drBenefitValues_OutNetworkDisgnisticUrgentCareFacility != null)
                                {
                                    AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkDisgnisticUrgentCareFacility);
                                }
                                oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 1).Range.Text = AttributeValue;
                                AttributeValue = "";
                                if (PlanTier == 3)
                                {
                                    DataRow drBenefitValues_Level3DisgnisticUrgentCareFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 565 AND benefitColumnID IN (" + string.Join(",", Dental_BenefitColumn_Level3) + ") ").FirstOrDefault();
                                    if (drBenefitValues_Level3DisgnisticUrgentCareFacility != null)
                                    {
                                        AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Level3DisgnisticUrgentCareFacility);
                                    }
                                    oWordDoc.Tables[CurrentTableIndex].Cell(17, CurrentColumnIndex + 2).Range.Text = AttributeValue;
                                    AttributeValue = "";
                                }
                            }
                            AttributeValue = "";
                            #endregion

                            #endregion

                            CurrentColumnIndex += ColumnIncreament;
                            HeaderColumnIndex += 1;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            // WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1, Carrier, SummaryName, ContributionCollection, ContributionDS);
                            WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                            ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                            if (AllBookmarks["Dental"].ContainsKey("DentalPlanTables" + TablesUsed))
                            {
                                AllBookmarks["Dental"].Remove("DentalPlanTables" + TablesUsed);
                            }
                            if (WriteCount % 3 == 0)
                            {
                                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
                                CurrentColumnIndex = 2;
                                HeaderColumnIndex = 2;
                                CurrentTableIndex = CurrentTableIndex + TotalContributionCount + 1;
                                RemainingBenefitCount = 3;
                                TablesUsed += 1;
                                lstPlanTier.Clear();
                                TotalContributionCount = 0;
                                ContributionStartCount = 0;
                            }
                        }
                    }
                }
                if (RemainingBenefitCount != 3)
                {
                    int BodyMergeStartIndex = CurrentColumnIndex - 1;
                    int BodyMergeEndIndex = BodyMergeStartIndex + (RemainingBenefitCount * 3);
                    int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                    // Benefits
                    MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                    MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippeRowSpan);
                    AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippeRowSpan, TableAttributeColumnsWidth);
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteVisionSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<string, Dictionary<int, List<int>>> dictMap, Dictionary<int, List<int>> ContributionList, DataSet ContributionDS)
        {
            try
            {
                lstPlanTier.Clear();
                string Renewaldate = string.Empty;
                string Effectivedate = string.Empty;

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();
                List<int> SkippedRowIndexes = new List<int>() { 2, 4 };

                foreach (object item in MedicalBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in MedicalBenefitColumnIdOutNetworkList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }

                int TablesUsed = 1;
                int CurrentColumnIndex = 2;
                int CurrentTableIndex = 7;
                int WriteCount = 0;
                int ColumnIncreament = 1;
                int RemainingBenefitCount = 3;
                int HeaderColumnIndex = 2;
                int ContributionStartCount = 0;
                int TotalContributionCount = 0;

                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            WriteCount++;
                            RemainingBenefitCount--;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            if (WriteCount % 3 == 0)
                            {
                                oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Copy();
                                for (int i = 1; i < TotalContributionCount; i++)
                                {
                                    oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                                    oWordApp.Selection.Paste();
                                }

                                oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                                TablesUsed++;
                                TotalContributionCount = 0;
                                RemainingBenefitCount = 3;
                            }
                        }
                    }
                }
                if (RemainingBenefitCount != 3)
                {
                    oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Copy();
                    for (int i = 1; i < TotalContributionCount; i++)
                    {
                        oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields.Count].Select();
                        oWordApp.Selection.Paste();
                    }
                    oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields[oWordDoc.Bookmarks["VisionContributionContainer" + TablesUsed].Range.Fields.Count].Delete();
                }

                TablesUsed = 1;
                TotalContributionCount = 0;
                RemainingBenefitCount = 3;
                WriteCount = 0;

                List<int> Contributions = new List<int>();
                float FullTableWidth = oWordDoc.Tables[CurrentTableIndex].Cell(2, 1).Width;
                float TableAttributeColumnsWidth = FullTableWidth - oWordDoc.Tables[CurrentTableIndex].Cell(3, 1).Width;
                foreach (string PlanTypeDescription in dictMap.Keys)
                {
                    foreach (int key in dictMap[PlanTypeDescription].Keys)
                    {
                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        Renewaldate = drPlanRow["Renewal"].ToString();
                        Effectivedate = drPlanRow["Effective"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();
                        List<int> BenefitSummarries = dictMap[PlanTypeDescription][key];
                        int PlanTier = CheckPlanTier(45, BenefitSummarries.First(), dtblBenefitAttribute);

                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            lstPlanTier.Add(1);
                            WriteCount++;
                            RemainingBenefitCount--;

                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            string ProduTypeDescription = drPlanBenefitRow["ProductTypeDescription"].ToString();
                            string AttributeValue = "";
                            string AttributeValue1 = "";
                            oWordDoc.Tables[CurrentTableIndex].Cell(1, HeaderColumnIndex).Range.Text = Carrier + "\n" + SummaryName + "\n" + PolicyNumber;

                            #region Benefit Coverage-Copay-Routine Exam-3
                            //InNetwork
                            DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 195 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CopayRoutineExamFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(3, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Benefit Coverage-Copay-Routine Materials-5
                            //InNetwork
                            DataRow drBenefitValues_CopayRoutineMaterialsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 344 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CopayRoutineMaterialsFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineMaterialsFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(5, CurrentColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Benefit Coverage-Frequency-Routine Lenses - 6
                            //InNetwork
                            DataRow drBenefitValues_GeneralPlanInformationLensesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 309 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_GeneralPlanInformationLensesFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationLensesFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(6, CurrentColumnIndex).Range.Text = "Benefit varies by type of lens. Covered every " + AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Benefit Coverage-Contact Lenses-Necessary / Prescribed-Frames-Elective-7
                            //InNetwork
                            DataRow drBenefitValues_CoveredServicesElectiveFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 178 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CoveredServicesElectiveFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesElectiveFacility);
                            }
                            DataRow drBenefitValues_GeneralPlanInformationContactsFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 122 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_GeneralPlanInformationContactsFacility != null)
                            {
                                AttributeValue1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationContactsFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(7, CurrentColumnIndex).Range.Text = "Elective contacts covered " + AttributeValue + " every " + AttributeValue1;
                            AttributeValue = "";
                            AttributeValue1 = "";

                            #endregion

                            #region Benefit Coverage-Frames-Retail Equivalent-Frames-8
                            //InNetwork
                            DataRow drBenefitValues_CoveredServicesFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 208 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CoveredServicesFramesFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CoveredServicesFramesFacility);
                            }
                            DataRow drBenefitValues_GeneralPlanInformationFramesFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 207 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_GeneralPlanInformationFramesFacility != null)
                            {
                                AttributeValue1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_GeneralPlanInformationFramesFacility);
                            }
                            oWordDoc.Tables[CurrentTableIndex].Cell(11, CurrentColumnIndex).Range.Text = "Covered at " + AttributeValue + " every " + AttributeValue1;
                            AttributeValue = "";
                            AttributeValue1 = "";
                            #endregion

                            CurrentColumnIndex += ColumnIncreament;
                            HeaderColumnIndex += 1;
                            List<int> ContributionCollection = ContributionList[BenefitSummaryID];
                            TotalContributionCount = TotalContributionCount + ContributionCollection.Count;
                            WriteContribution(oWordDoc, oWordApp, CurrentTableIndex + 1 + ContributionStartCount, Carrier, SummaryName, ContributionCollection, ContributionDS);
                            ContributionStartCount = ContributionStartCount + ContributionCollection.Count;

                            if (AllBookmarks["Vision"].ContainsKey("VisionPlanTables" + TablesUsed))
                            {
                                AllBookmarks["Vision"].Remove("VisionPlanTables" + TablesUsed);
                            }

                            if (WriteCount % 3 == 0)
                            {
                                AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                                CurrentColumnIndex = 2;
                                HeaderColumnIndex = 2;
                                ////CurrentTableIndex += 2;
                                RemainingBenefitCount = 3;
                                CurrentTableIndex = CurrentTableIndex + TotalContributionCount + 1;
                                lstPlanTier.Clear();
                                TotalContributionCount = 0;
                                ContributionStartCount = 0;
                            }
                        }
                    }
                }
                if (RemainingBenefitCount != 3)
                {
                    int BodyMergeStartIndex = CurrentColumnIndex - 1;
                    int BodyMergeEndIndex = BodyMergeStartIndex + RemainingBenefitCount;
                    int HeaderMergeStart = (3 - RemainingBenefitCount) + 1;
                    // Benefits
                    MergeTableColumns(oWordDoc, CurrentTableIndex, HeaderMergeStart, 4, 1, 1, null);
                    MergeTableColumns(oWordDoc, CurrentTableIndex, BodyMergeStartIndex, BodyMergeEndIndex, 2, int.MaxValue, SkippedRowIndexes);
                    AdjustCellWidth(oWordDoc, CurrentTableIndex, lstPlanTier, SkippedRowIndexes, TableAttributeColumnsWidth);
                }
                #region MergeField

                int iTotalFields = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Vision_ClientName_1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;
                        }
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritHSASectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {
            try
            {
                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string value = "";

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        //  oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                        #region Annual Deductible Individual - 4
                        //In Network
                        DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 635").FirstOrDefault();
                        if (drBenefitValues_InNetworkIndividual != null)
                        {
                            Max_Annual_Contribution_Individual1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                        }

                        DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 636").FirstOrDefault();
                        if (drBenefitValues_OutNetworkIndividual != null)
                        {
                            Max_Annual_Contribution_Family1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                        }
                        #endregion

                        AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                    }

                    #region merge fields
                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Delete HSA"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                            if (fieldName.Contains("HSA Carrier"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Carrier))
                                {
                                    oWordApp.Selection.TypeText(Carrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("IRS Employee Only coverage"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual1))
                                {
                                    oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                            if (fieldName.Contains("IRS Family Coverage"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Max_Annual_Contribution_Family1))
                                {
                                    oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                        }
                    }

                    #endregion

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //  Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WritHRASectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, Dictionary<int, List<int>> dictMap)
        {

            try
            {
                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;
                string value = "";

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();
                foreach (object item in MedicalBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in MedicalBenefitColumnIdOutNetworkList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        //  oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount + 1).Range.Text = SummaryName;

                        #region Annual Deductible Individual - 4
                        //In Network

                        DataRow drBenefitValues_InNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 238").FirstOrDefault();
                        if (drBenefitValues_InNetworkIndividual != null)
                        {
                            HRA_Tier_1 = comFunObj.GetBenefitFormattedValue(drBenefitValues_InNetworkIndividual);
                        }

                        DataRow drBenefitValues_OutNetworkIndividual = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 239").FirstOrDefault();
                        if (drBenefitValues_OutNetworkIndividual != null)
                        {
                            HRA_Tier_2 = comFunObj.GetBenefitFormattedValue(drBenefitValues_OutNetworkIndividual);
                        }
                        #endregion

                        AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                    }

                    #region merge fields
                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Delete HSA"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                            if (fieldName.Contains("HRA Carrier Name"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Carrier))
                                {
                                    oWordApp.Selection.TypeText(Carrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA Tier One"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                            if (fieldName.Contains("HRA Tier Two"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                        }
                    }

                    #endregion

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteFSASectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, Dictionary<int, List<int>> dictMap)
        {

            try
            {

                int BenefitCoverageTableIndex = 9;

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();

                foreach (object item in FSABenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string Carrier = drPlanRow["Carrier"].ToString();

                    PlanCount = PlanCount + 1;
                    List<int> BenefitSummarries = dictMap[key];
                    int AttributeValueColumnIndex = 2;
                    int AttributeRowIndex = 2;
                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        ////oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, BenefitSummaryCount).Range.Text = SummaryName;

                        #region Health Care FSA - Spending Account Maximum

                        DataRow drBenefitValues_SpendingAccountMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 354 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_SpendingAccountMaximum != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpendingAccountMaximum);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(AttributeRowIndex, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Dependent Care FSA - Administration Services – Dependent Care

                        DataRow drBenefitValues_DependentCare = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 150 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_DependentCare != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_DependentCare);
                        }
                        oWordDoc.Tables[BenefitCoverageTableIndex].Cell(AttributeRowIndex + 1, AttributeValueColumnIndex).Range.Text = AttributeValue;
                        AttributeValue = "";

                        #endregion


                        AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                    }

                    BenefitCoverageTableIndex = BenefitCoverageTableIndex + 1;

                    #region merge fields
                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("FSACarrierName"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Carrier);
                            }
                        }
                    }
                    #endregion
                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteLifeADDToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> LifeAndADnDPlans, List<int> VoluntaryLifeAndADnDPlans)
        {
            try
            {
                int LifeADDTableIndex = 10;

                #region Mark written tables by removing from "AllBookmarks"

                string bookmark = string.Empty;
                if (LifeAndADnDPlans.Count > 0)
                {
                    if (AllBookmarks["Life and AD&D"].ContainsKey("LifeADnD"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("LifeADnD");
                    }
                }
                for (int i = 1; i <= LifeAndADnDPlans.Count; i++)
                {
                    bookmark = "LifeADnDTable" + i.ToString();
                    if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                    {
                        AllBookmarks["Life and AD&D"].Remove(bookmark);
                    }
                }
                #endregion


                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

                int PlanCount = 0;
                int GroupPlanCount = dictMap.Keys.Count;
                string VoluntaryLifeAndADnDCarrier = " ";
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    if (LifeAndADnDPlans.Contains(key))
                    {
                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();


                        if (VoluntaryLifeAndADnDPlans.Count > 0 && VoluntaryLifeAndADnDPlans.Contains(key))
                        {
                            VoluntaryLifeAndADnDCarrier = drPlanRow["Carrier"].ToString();
                        }

                        PlanCount = PlanCount + 1;
                        List<int> BenefitSummarries = dictMap[key];
                        int AttributeValueColumnIndex = 2;
                        // Write for each Benefit Summary selected
                        int BenefitSummaryCount = 0;
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {

                            string AttributeValue = "";
                            BenefitSummaryCount = BenefitSummaryCount + 1;
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();
                            oWordDoc.Tables[LifeADDTableIndex].Cell(1, 1).Range.Text = Carrier + "\n" + SummaryName;


                            #region Benefit Maximum-3
                            //InNetwork
                            DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                            if (drBenefitValues_BenefitMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(3, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Guaranteed Issue-4
                            //InNetwork
                            oWordDoc.Save();
                            DataRow drBenefitValues_Guaranteed_Issue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 187").FirstOrDefault();
                            if (drBenefitValues_Guaranteed_Issue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Guaranteed_Issue);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(4, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Spouse Benifit Maximum-6
                            //InNetwork
                            DataRow drBenefitValues_SpouseBenifitMaximumFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 519").FirstOrDefault();
                            if (drBenefitValues_SpouseBenifitMaximumFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseBenifitMaximumFacility);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(6, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Spouse Guaranteed Issue-7
                            //InNetwork
                            DataRow drBenefitValues_SpouseGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 518").FirstOrDefault();
                            if (drBenefitValues_SpouseGuaranteedIssue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteedIssue);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(7, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Child Benefit Maximum-9
                            //InNetwork
                            DataRow drBenefitValues_ChildBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 104").FirstOrDefault();
                            if (drBenefitValues_ChildBenefitMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildBenefitMaximum);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(9, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Child Guaranteed Issue-10
                            //InNetwork
                            DataRow drBenefitValues_ChildGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 103").FirstOrDefault();
                            if (drBenefitValues_ChildGuaranteedIssue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildGuaranteedIssue);
                            }
                            oWordDoc.Tables[LifeADDTableIndex].Cell(10, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            // AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                            LifeADDTableIndex = LifeADDTableIndex + 1;
                        }


                        // ContrbutionTableIndex = ContrbutionTableIndex + 2;
                    }
                }


                int iTotalFields = 0;

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("VolLifeADnDCarrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(VoluntaryLifeAndADnDCarrier);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //  Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteGroupLifeADDTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> GroupTermLife)
        {
            try
            {
                int GroupTermTableIndex = 12;

                #region Mark written tables by removing from "AllBookmarks"

                string bookmark = string.Empty;
                if (GroupTermLife.Count > 0)
                {
                    if (AllBookmarks["Life and AD&D"].ContainsKey("GroupLife"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("GroupLife");
                    }
                }
                for (int i = 1; i <= GroupTermLife.Count; i++)
                {
                    bookmark = "GroupLifeTable" + i.ToString();
                    if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                    {
                        AllBookmarks["Life and AD&D"].Remove(bookmark);
                    }
                }
                #endregion

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];

                int PlanCount = 0;
                int GroupPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    if (GroupTermLife.Contains(key))
                    {
                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();

                        PlanCount = PlanCount + 1;
                        List<int> BenefitSummarries = dictMap[key];
                        int AttributeValueColumnIndex = 2;
                        // Write for each Benefit Summary selected
                        int BenefitSummaryCount = 0;
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            string AttributeValue = "";
                            BenefitSummaryCount = BenefitSummaryCount + 1;
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                            oWordDoc.Tables[GroupTermTableIndex].Cell(1, 1).Range.Text = Carrier + "\n" + SummaryName;

                            #region Benefit Maximum-3
                            //InNetwork
                            DataRow drBenefitValues_BenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 188").FirstOrDefault();
                            if (drBenefitValues_BenefitMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitMaximum);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(3, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Guaranteed Issue-4
                            //InNetwork
                            DataRow drBenefitValues_Guaranteed_Issue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 187").FirstOrDefault();
                            if (drBenefitValues_Guaranteed_Issue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_Guaranteed_Issue);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(4, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Spouse Benifit Maximum-6
                            //InNetwork
                            DataRow drBenefitValues_SpouseBenifitMaximumFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 519").FirstOrDefault();
                            if (drBenefitValues_SpouseBenifitMaximumFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseBenifitMaximumFacility);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(6, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Spouse Guaranteed Issue-7
                            //InNetwork
                            DataRow drBenefitValues_SpouseGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 518").FirstOrDefault();
                            if (drBenefitValues_SpouseGuaranteedIssue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_SpouseGuaranteedIssue);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(7, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Child Benefit Maximum-9
                            //InNetwork
                            DataRow drBenefitValues_ChildBenefitMaximum = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 104").FirstOrDefault();
                            if (drBenefitValues_ChildBenefitMaximum != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildBenefitMaximum);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(9, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            #region Your Child Guaranteed Issue-10
                            //InNetwork
                            DataRow drBenefitValues_ChildGuaranteedIssue = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 103").FirstOrDefault();
                            if (drBenefitValues_ChildGuaranteedIssue != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_ChildGuaranteedIssue);
                            }
                            oWordDoc.Tables[GroupTermTableIndex].Cell(10, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            //  AttributeValueColumnIndex = AttributeValueColumnIndex + 1;
                            GroupTermTableIndex = GroupTermTableIndex + 1;
                        }

                        #region MergeField

                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Vision_ClientName_" + PlanCount))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ClientName);
                                    continue;
                                }
                            }
                        }

                        #endregion

                        // ContrbutionTableIndex = ContrbutionTableIndex + 2;
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                // Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteADandDSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, ArrayList ADDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> ADnDPlans)
        {
            try
            {
                int BenefitCoverageTableIndex = 14;

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();
                List<string> lstOutNetworkColumnID = new List<string>();

                #region Mark written tables by removing from "AllBookmarks"

                string bookmark = string.Empty;
                if (ADnDPlans.Count > 0)
                {
                    if (AllBookmarks["Life and AD&D"].ContainsKey("ADDADnD"))
                    {
                        AllBookmarks["Life and AD&D"].Remove("ADDADnD");
                    }
                }
                for (int i = 1; i <= ADnDPlans.Count; i++)
                {
                    bookmark = "ADDADnDTables" + i.ToString();
                    if (AllBookmarks["Life and AD&D"].ContainsKey(bookmark))
                    {
                        AllBookmarks["Life and AD&D"].Remove(bookmark);
                    }
                }
                #endregion


                foreach (object item in ADDBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }
                foreach (object item in LifeADDBenefitColumnIdList)
                {
                    lstOutNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    if (ADnDPlans.Contains(key))
                    {

                        DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                        string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                        string Carrier = drPlanRow["Carrier"].ToString();

                        PlanCount = PlanCount + 1;
                        List<int> BenefitSummarries = dictMap[key];
                        int AttributeValueColumnIndex = 2;
                        // Write for each Benefit Summary selected
                        int BenefitSummaryCount = 0;
                        foreach (int BenefitSummaryID in BenefitSummarries)
                        {
                            string AttributeValue = "";
                            BenefitSummaryCount = BenefitSummaryCount + 1;
                            DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                            string CarrierName = drPlanBenefitRow["Carrier"].ToString();
                            string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                            string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(1, 1).Range.Text = CarrierName + "\n" + SummaryName;

                            #region General Plan Info –Benefit Amount – Employee
                            //InNetwork
                            DataRow drBenefitValues_CopayRoutineExamFacility = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 186 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                            if (drBenefitValues_CopayRoutineExamFacility != null)
                            {
                                AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_CopayRoutineExamFacility);
                            }
                            oWordDoc.Tables[BenefitCoverageTableIndex].Cell(3, AttributeValueColumnIndex).Range.Text = AttributeValue;
                            AttributeValue = "";

                            #endregion

                            BenefitCoverageTableIndex = BenefitCoverageTableIndex + 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //   Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteVoluntaryLifeTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet RateDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> VoluntaryLife, List<int> VoluntaryADnD)
        {
            try
            {
                string BothLifeADnDCarrier = string.Empty;
                string VolLifeCarrier = string.Empty;
                string VolADnDCarrier = string.Empty;
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();

                    if (VoluntaryLife.Contains(key))
                    {
                        VolLifeCarrier = drPlanRow["Carrier"].ToString();
                    }
                    else if (VoluntaryADnD.Contains(key))
                    {
                        VolADnDCarrier = drPlanRow["Carrier"].ToString();
                    }

                }

                int iTotalFields = 0;

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        //if (fieldName.Contains("VolLifeADnDCarrier"))
                        //{
                        //    myMergeField.Select();
                        //    oWordApp.Selection.TypeText(BothLifeADnDCarrier);
                        //}
                        if (fieldName.Contains("VoluntaryLifeCarrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(VolLifeCarrier);
                        }
                        if (fieldName.Contains("VoluntaryADnDCarrier"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(VolADnDCarrier);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //   Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteSTDSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> STD, List<int> VoluantrySTD)
        {
            try
            {

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();

                foreach (object item in STDBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int STDCount = 0;
                int VolSTDCount = 0;
                int MedicalPlanCount = dictMap.Keys.Count;



                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {

                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string STDPlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string STDCarrierName = string.Empty;
                    //string CarrierName = drPlanRow["Carrier"].ToString();

                    string CarrierName = string.Empty;
                    string BenefitPercentage = string.Empty;
                    string WeeklyBenefitMaximum = string.Empty;
                    string EliminationPeriod = string.Empty;
                    string MaximumPeriodofPayment = string.Empty;

                    string STDBenefitPercentage = string.Empty;
                    string STDWeeklyBenefitMaximum = string.Empty;
                    string STDEliminationPeriod = string.Empty;
                    string STDMaximumPeriodofPayment = string.Empty;

                    List<int> BenefitSummarries = dictMap[key];

                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        PlanCount++;

                        CarrierName = "CarrierName";
                        BenefitPercentage = "BenefitPercentage";
                        WeeklyBenefitMaximum = "WeeklyBenefitMaximum";
                        EliminationPeriod = "EliminationPeriod";
                        MaximumPeriodofPayment = "MaximumPeriodofPayment";

                        STDBenefitPercentage = string.Empty;
                        STDWeeklyBenefitMaximum = string.Empty;
                        STDEliminationPeriod = string.Empty;
                        STDMaximumPeriodofPayment = string.Empty;

                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        STDCarrierName = drPlanBenefitRow["Carrier"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        #region Elimination Period

                        DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 8 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_EliminationPeriod != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                        }
                        STDEliminationPeriod = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Percentage

                        DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPercentage != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                        }
                        STDBenefitPercentage = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Maximum Weekly Benefit

                        DataRow drBenefitValues_MaximumWeeklyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 569 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_MaximumWeeklyBenefit != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumWeeklyBenefit);
                        }
                        STDWeeklyBenefitMaximum = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Maximum Period of Payment

                        DataRow drBenefitValues_MaximumPeriodPayment = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 350 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_MaximumPeriodPayment != null)
                        {
                            ////AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumPeriodPayment);
                            if (drBenefitValues_MaximumPeriodPayment["UOM"].ToString() == "text")
                            {
                                drBenefitValues_MaximumPeriodPayment["UOM"] = "";
                            }
                            AttributeValue = (comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumPeriodPayment) + " " + drBenefitValues_MaximumPeriodPayment["UOM"].ToString().Trim().Replace("_", " ")).Trim();
                        }
                        STDMaximumPeriodofPayment = AttributeValue;
                        AttributeValue = "";

                        #endregion

                    }

                    if (VoluantrySTD.Contains(key))
                    {
                        VolSTDCount++;
                        MaximumPeriodofPayment = "STDVol" + MaximumPeriodofPayment + VolSTDCount.ToString();
                        WeeklyBenefitMaximum = "STDVol" + WeeklyBenefitMaximum + VolSTDCount.ToString();
                        EliminationPeriod = "STDVol" + EliminationPeriod + VolSTDCount.ToString();
                        BenefitPercentage = "STDVol" + BenefitPercentage + VolSTDCount.ToString();
                        CarrierName = "STDVol" + CarrierName + VolSTDCount.ToString();
                    }
                    else if (STD.Contains(key))
                    {
                        STDCount++;
                        MaximumPeriodofPayment = "STD" + MaximumPeriodofPayment + STDCount.ToString();
                        WeeklyBenefitMaximum = "STD" + WeeklyBenefitMaximum + STDCount.ToString();
                        EliminationPeriod = "STD" + EliminationPeriod + STDCount.ToString();
                        BenefitPercentage = "STD" + BenefitPercentage + STDCount.ToString();
                        CarrierName = "STD" + CarrierName + STDCount.ToString();
                    }

                    #region merge fields
                    int iTotalFields = 0;

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains(MaximumPeriodofPayment))
                            {
                                myMergeField.Select();
                                if (STDMaximumPeriodofPayment == "")
                                {
                                    STDMaximumPeriodofPayment = " ";
                                }
                                oWordApp.Selection.TypeText(STDMaximumPeriodofPayment);
                            }
                            if (fieldName.Contains(WeeklyBenefitMaximum))
                            {
                                myMergeField.Select();
                                if (STDWeeklyBenefitMaximum == "")
                                {
                                    STDWeeklyBenefitMaximum = " ";
                                }
                                oWordApp.Selection.TypeText(STDWeeklyBenefitMaximum);
                            }
                            if (fieldName.Contains(EliminationPeriod))
                            {
                                myMergeField.Select();
                                if (STDEliminationPeriod == "")
                                {
                                    STDEliminationPeriod = " ";
                                }
                                oWordApp.Selection.TypeText(STDEliminationPeriod);
                            }
                            if (fieldName.Contains(BenefitPercentage))
                            {
                                myMergeField.Select();
                                if (STDBenefitPercentage == "")
                                {
                                    STDBenefitPercentage = " ";
                                }
                                oWordApp.Selection.TypeText(STDBenefitPercentage);
                            }
                            if (fieldName.Contains(CarrierName))
                            {
                                myMergeField.Select();
                                if (STDCarrierName == "")
                                {
                                    STDCarrierName = " ";
                                }
                                oWordApp.Selection.TypeText(STDCarrierName);
                            }
                        }
                    }
                    #endregion

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //    Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteLTDSectionToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, Dictionary<int, List<int>> dictMap, List<int> LTD, List<int> VoluntaryLTD)
        {

            try
            {

                DataTable dtblBenefitAttribute = BenefitDS.Tables["AttributeValueDetailTable"];
                List<string> lstInNetworkColumnID = new List<string>();

                foreach (object item in LTDBenefitColumnIdList)
                {
                    lstInNetworkColumnID.Add(item.ToString());
                }

                int PlanCount = 0;
                int LTDCount = 0;
                int VolLTDCount = 0;

                int MedicalPlanCount = dictMap.Keys.Count;
                // Write for each disctinct plan selected
                foreach (int key in dictMap.Keys)
                {
                    DataRow drPlanRow = PlanTable.Select("ProductId = " + key.ToString()).FirstOrDefault();
                    string PlanTypeDescription = drPlanRow["ProductTypeDescription"].ToString();
                    string LTDCarrierName = drPlanRow["Carrier"].ToString();



                    string LTDBenefitPercentage = string.Empty;
                    string LTDMonthlyBenefitMaximum = string.Empty;
                    string LTDEliminationPeriod = string.Empty;

                    List<int> BenefitSummarries = dictMap[key];

                    // Write for each Benefit Summary selected
                    int BenefitSummaryCount = 0;
                    foreach (int BenefitSummaryID in BenefitSummarries)
                    {
                        PlanCount++;

                        string CarrierName = "CarrierName";
                        string BenefitPercentage = "BenefitPercentage";
                        string MonthlyBenefitMaximum = "MonthlyBenefitMaximum";
                        string EliminationPeriod = "EliminationPeriod";

                        LTDBenefitPercentage = string.Empty;
                        LTDMonthlyBenefitMaximum = string.Empty;
                        LTDEliminationPeriod = string.Empty;

                        string AttributeValue = "";
                        BenefitSummaryCount = BenefitSummaryCount + 1;
                        DataRow drPlanBenefitRow = PlanTable.Select("ProductId = " + key.ToString() + "AND SummaryId = " + BenefitSummaryID.ToString()).FirstOrDefault();
                        string SummaryName = drPlanBenefitRow["SummaryName"].ToString();
                        string PolicyNumber = drPlanBenefitRow["PolicyNumber"].ToString();

                        #region Elimination Period

                        DataRow drBenefitValues_EliminationPeriod = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 181 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_EliminationPeriod != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_EliminationPeriod);
                        }
                        LTDEliminationPeriod = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Benefit Percentage

                        DataRow drBenefitValues_BenefitPercentage = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 71 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_BenefitPercentage != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_BenefitPercentage);
                        }
                        LTDBenefitPercentage = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        #region Maximum Weekly Benefit

                        DataRow drBenefitValues_MaximumWeeklyBenefit = dtblBenefitAttribute.Select("benefitSummaryID = " + BenefitSummaryID + " AND attributeID = 374 AND benefitColumnID IN (" + string.Join(",", lstInNetworkColumnID) + ") ").FirstOrDefault();
                        if (drBenefitValues_MaximumWeeklyBenefit != null)
                        {
                            AttributeValue = comFunObj.GetBenefitFormattedValue(drBenefitValues_MaximumWeeklyBenefit);
                        }
                        LTDMonthlyBenefitMaximum = AttributeValue;
                        AttributeValue = "";

                        #endregion

                        if (VoluntaryLTD.Contains(key))
                        {
                            VolLTDCount++;
                            EliminationPeriod = "LTDVol" + EliminationPeriod + VolLTDCount.ToString();
                            BenefitPercentage = "LTDVol" + BenefitPercentage + VolLTDCount.ToString();
                            CarrierName = "LTDVol" + CarrierName + VolLTDCount.ToString();
                            MonthlyBenefitMaximum = "LTDVol" + MonthlyBenefitMaximum + VolLTDCount.ToString();
                        }
                        else if (LTD.Contains(key))
                        {
                            LTDCount++;
                            EliminationPeriod = "LTD" + EliminationPeriod + LTDCount.ToString();
                            BenefitPercentage = "LTD" + BenefitPercentage + LTDCount.ToString();
                            CarrierName = "LTD" + CarrierName + LTDCount.ToString();
                            MonthlyBenefitMaximum = "LTD" + MonthlyBenefitMaximum + LTDCount.ToString();
                        }
                        #region merge fields
                        int iTotalFields = 0;

                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains(MonthlyBenefitMaximum))
                                {
                                    myMergeField.Select();
                                    if (LTDMonthlyBenefitMaximum == "")
                                    {
                                        LTDMonthlyBenefitMaximum = " ";
                                    }
                                    oWordApp.Selection.TypeText(LTDMonthlyBenefitMaximum);
                                }
                                if (fieldName.Contains(EliminationPeriod))
                                {
                                    myMergeField.Select();
                                    if (LTDEliminationPeriod == "")
                                    {
                                        LTDEliminationPeriod = " ";
                                    }
                                    oWordApp.Selection.TypeText(LTDEliminationPeriod);
                                }
                                if (fieldName.Contains(BenefitPercentage))
                                {
                                    myMergeField.Select();
                                    if (LTDBenefitPercentage == "")
                                    {
                                        LTDBenefitPercentage = " ";
                                    }
                                    oWordApp.Selection.TypeText(LTDBenefitPercentage);
                                }
                                if (fieldName.Contains(CarrierName))
                                {
                                    myMergeField.Select();
                                    if (LTDCarrierName == "")
                                    {
                                        LTDCarrierName = " ";
                                    }
                                    oWordApp.Selection.TypeText(LTDCarrierName);
                                }
                            }
                        }
                        #endregion

                    }

                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //  Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteEAPSectionToSpringField(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                //HashtableEAP.Add(1, "384"); // Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("EAP Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteAdditionalProductToTemplateSpringField(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, DataTable PlanInfoTable)
        {
            try
            {
                string CriticalIllnessCarrier = string.Empty;
                string Voluntary_Cancer = "";
                int iTotalFields = 0;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            CriticalIllnessCarrier = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            Voluntary_Cancer = PlanInfoTable.Rows[k]["Carrier"].ToString();
                        }
                    }
                }
                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Critical Illness Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(CriticalIllnessCarrier);
                            continue;
                        }
                        /********Printing Voluntary Cancer Section *********************/
                        if (fieldName.Contains("WorksitePrdCancerCarrierName"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Voluntary_Cancer);
                            continue;
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        public void WriteNoticeSectionToSpringField(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                //Added By Vaibhav -- Calling by Mr.Amogh 
                selectedcolor = "Gray";
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        public void WriteContactinformationToSpringField(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, Dictionary<string, Dictionary<int, List<int>>> dictProductMap)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int count = 17;
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                DataRow[] foundRows = null;
                int rowcount = 2;
                int PlanCount = 0;

                List<string> lstUniquePlanTypeCarrier = new List<string>();
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    carriername = PlanTable.Rows[i]["Carrier"].ToString();
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();

                    string lstUniquePlanTypeCarrierItem = carriername + "|" + ProductTypeDesc;
                    if (!lstUniquePlanTypeCarrier.Contains(lstUniquePlanTypeCarrierItem))
                    {
                        lstUniquePlanTypeCarrier.Add(lstUniquePlanTypeCarrierItem);
                        if (rowcount > 2)
                        {
                            oWordDoc.Tables[count].Rows.Add(Type.Missing);
                        }
                        oWordDoc.Tables[count].Cell(rowcount, 2).Range.Text = PlanTable.Rows[i]["Carrier"].ToString();
                        oWordDoc.Tables[count].Cell(rowcount, 1).Range.Text = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        oWordDoc.Tables[count].Cell(rowcount, 3).Range.Text = "(###) ###-####";
                        oWordDoc.Tables[count].Cell(rowcount, 4).Range.Text = "www.website.com";
                        rowcount++;
                    }

                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private void AdjustCellWidth(Word.Document oWordDoc, int TableIndex, List<int> planTierCount, List<int> SkippedRowIndexes, float TableWidth)
        {
            int colCount = oWordDoc.Tables[TableIndex].Columns.Count;
            double CellWidth = TableWidth / planTierCount.Count;
            int CurrentCellStartIndex = 2;
            int CurrentCellEndIndex = 2;
            for (int i = 1; i <= planTierCount.Count; i++)
            {
                CurrentCellStartIndex = CurrentCellEndIndex;
                CurrentCellEndIndex = CurrentCellEndIndex + planTierCount[i - 1];
                if (SkippedRowIndexes != null)
                {
                    if (!SkippedRowIndexes.Contains(1))
                        oWordDoc.Tables[TableIndex].Rows[1].Cells[i + 1].Width = (float)CellWidth;
                }
                else
                {
                    oWordDoc.Tables[TableIndex].Rows[1].Cells[i + 1].Width = (float)CellWidth;
                }
                float InnerCellWisth = (float)(CellWidth / planTierCount[i - 1]);
                for (int Row = 2; Row <= oWordDoc.Tables[TableIndex].Rows.Count; Row++)
                {
                    int TempCellIndex = CurrentCellStartIndex;
                    while (TempCellIndex < CurrentCellEndIndex)
                    {
                        if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                        {
                            if (!SkippedRowIndexes.Contains(Row))
                            {
                                oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                            }
                        }
                        else
                        {
                            oWordDoc.Tables[TableIndex].Rows[Row].Cells[TempCellIndex].Width = InnerCellWisth;
                        }
                        TempCellIndex++;
                    }
                }
            }
        }
        private string GetBenefitFormattedValue(DataRow dr)
        {
            if (dr != null)
                return (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
            return "";
        }
        public void getBookmarks()
        {
            AllBookmarks.Clear();
            /* =======================================================================================
             *Section         -> BookMark :-                             'VoluntaryADD'
             *Section         -> Header desc in 1st page (if exists):-   'VoluntaryADDMain'
             *Sub-Section     -> general Description:-                   'VoluntaryADDDescription'
             *Sub-Section     -> Single Plan Description: -              'VoluntaryADDSingleDescription'
             *Sub-Section     -> Multiple Plan Description :-            'VoluntaryADDMultipleDescription'
             *Sub-Section     -> Plan Tables :-                          'VoluntaryADDPlanTables'
             ============================================================================================*/
            #region Medical Bookmarks


            Dictionary<string, string> medicalBookmarks = new Dictionary<string, string>();
            //medicalBookmarks.Add("MedicalSinglePlanDescription", "MedicalSinglePlanDescription");
            //medicalBookmarks.Add("MedicalMultiplePlanDescription", "MedicalMultiplePlanDescription");

            ////medicalBookmarks.Add("MedicalHMODescription1", "MedicalHMODescription1");
            ////medicalBookmarks.Add("MedicalPPODescription1", "MedicalPPODescription1");

            medicalBookmarks.Add("MedicalPlanTables1", "MedicalPlanTables1");
            medicalBookmarks.Add("MedicalPlanTables2", "MedicalPlanTables2");
            medicalBookmarks.Add("MedicalPlanTables3", "MedicalPlanTables3");
            medicalBookmarks.Add("MedicalPlanTables4", "MedicalPlanTables4");
            medicalBookmarks.Add("MedicalPlanTables5", "MedicalPlanTables5");
            medicalBookmarks.Add("MedicalPlanTables6", "MedicalPlanTables6");

            medicalBookmarks.Add("MedicalSampleTest", "MedicalSampleTest");
            #endregion

            #region Dental Bookmarks
            Dictionary<string, string> dentalBookmarks = new Dictionary<string, string>();
            //dentalBookmarks.Add("DentalSingleCarrier", "DentalSingleCarrier");
            dentalBookmarks.Add("DentalMultipleCarrier", "DentalMultipleCarrier");
            dentalBookmarks.Add("DentalPlanTables1", "DentalPlanTables1");
            dentalBookmarks.Add("DentalPlanTables2", "DentalPlanTables2");
            dentalBookmarks.Add("DentalPlanTables3", "DentalPlanTables3");

            #endregion

            #region Vision Bookmarks
            Dictionary<string, string> visionBookmarks = new Dictionary<string, string>();
            visionBookmarks.Add("VisionDescription1", "VisionDescription1");
            visionBookmarks.Add("VisionPlanTables1", "VisionPlanTables1");
            visionBookmarks.Add("VisionPlanTables2", "VisionPlanTables2");
            visionBookmarks.Add("VisionPlanTables3", "VisionPlanTables3");

            #endregion

            #region HSA Bookmarks
            Dictionary<string, string> HSABookmarks = new Dictionary<string, string>();
            // HSABookmarks.Add("HSADescription1", "HSADescription1");
            // visionBookmarks.Add("Vision_Description2", "Vision_Description2");
            #endregion

            #region HRA Bookmarks
            Dictionary<string, string> HRABookmarks = new Dictionary<string, string>();
            //HRABookmarks.Add("HRADescription1", "HRADescription1");
            #endregion

            #region FSA Bookmarks
            Dictionary<string, string> FSABookmarks = new Dictionary<string, string>();
            //FSABookmarks.Add("FSADescription1", "FSADescription1");
            #endregion

            #region Life and AD&D Bookmarks
            Dictionary<string, string> ADDBookmarks = new Dictionary<string, string>();
            ADDBookmarks.Add("ADDADnD", "ADDADnD");
            ADDBookmarks.Add("ADDADnDTables1", "ADDADnDTables1");
            ADDBookmarks.Add("ADDADnDTables2", "ADDADnDTables2");

            ADDBookmarks.Add("LifeADnD", "LifeADnD");
            ADDBookmarks.Add("LifeADnDTable1", "LifeADnDTable1");
            ADDBookmarks.Add("LifeADnDTable2", "LifeADnDTable2");

            ADDBookmarks.Add("GroupLife", "GroupLife");
            ADDBookmarks.Add("GroupLifeTable1", "GroupLifeTable1");
            ADDBookmarks.Add("GroupLifeTable2", "GroupLifeTable2");
            #endregion

            #region Voluntary Life and AD&D Bookmarks
            Dictionary<string, string> VolLifeADDBookmarks = new Dictionary<string, string>();
            VolLifeADDBookmarks.Add("VoluntaryLifeADDPlan", "VoluntaryLifeADDPlan");
            VolLifeADDBookmarks.Add("VoluntaryLifePlan", "VoluntaryLifePlan");
            VolLifeADDBookmarks.Add("VoluntaryADDPlan", "VoluntaryADDPlan");

            #endregion

            #region STD Bookmarks
            Dictionary<string, string> STDBookmarks = new Dictionary<string, string>();
            //STDBookmarks.Add("STDDescription", "STDDescription");
            #endregion

            #region LTD Bookmarks
            Dictionary<string, string> LTDBookmarks = new Dictionary<string, string>();
            //LTDBookmarks.Add("LTDPlan1", "LTDPlan1");
            #endregion

            #region EAP Bookmarks
            Dictionary<string, string> EAPBookmarks = new Dictionary<string, string>();
            //EAPBookmarks.Add("EAPDescription", "EAPDescription");
            #endregion

            AllBookmarks.Add("Medical", medicalBookmarks);
            AllBookmarks.Add("Dental", dentalBookmarks);
            AllBookmarks.Add("Vision", visionBookmarks);
            AllBookmarks.Add("HSA", HRABookmarks);
            AllBookmarks.Add("HRA", HRABookmarks);
            AllBookmarks.Add("FSA", FSABookmarks);
            //AllBookmarks.Add("STD", STDBookmarks);
            //AllBookmarks.Add("Voluntary Life", VolLifeADDBookmarks);
            AllBookmarks.Add("Life and AD&D", ADDBookmarks);
            //AllBookmarks.Add("LTD", LTDBookmarks);
            AllBookmarks.Add("EAP", EAPBookmarks);


        }
        public void DeleteBookmarks(Word.Document oWordDoc, Word.Application oWordApp, Dictionary<string, Dictionary<int, List<int>>> dictProductMap, DataTable PlanInfoTable, bool isBRCSelected, List<int> STD, List<int> LTD, List<int> VoluntarySTD, List<int> VoluntaryLTD, List<int> VoluntaryLifeAndADnDPlans, List<int> VoluntaryLife, List<int> VoluntaryADnD)
        {
            string formattedPlanType = string.Empty;   //to format special characters and spaces -- which are not detected in bookmarks
            string mainDesc = string.Empty;            //Main descrption on 1st page

            #region Delete non-selected plans and sub-sections including Header on 1st Page
            foreach (string plantype in AllBookmarks.Keys)
            {

                if (!dictProductMap.ContainsKey(plantype))
                {
                    formattedPlanType = plantype.Replace("&", "").Replace(" ", "");

                    mainDesc = formattedPlanType + "Main";        //If Plan not selected

                    if (oWordDoc.Bookmarks.Exists(mainDesc))    // Delete Main Description on 1st page
                    {
                        oWordDoc.Bookmarks[mainDesc].Range.Delete();
                    }

                    if (oWordDoc.Bookmarks.Exists(formattedPlanType))     // Delete Enitre Section
                    {
                        oWordDoc.Bookmarks[formattedPlanType].Range.Delete();
                    }
                    //DeleteIndivialBookmark(oWordDoc, mainDesc);              UnComment if bookmark not deleted
                    // DeleteIndivialBookmark(oWordDoc, formattedPlanType);

                }
                else
                {                                                                     //If PlanType is selected
                    if (AllBookmarks[plantype] != null)
                    {
                        foreach (string bookmark in AllBookmarks[plantype].Keys)     // Loop through inner bookmarks and delete unwanted sub-sections
                        {
                            formattedPlanType = bookmark.Replace("&", "").Replace(" ", "");

                            if (oWordDoc.Bookmarks.Exists(formattedPlanType))
                            {
                                oWordDoc.Bookmarks[bookmark].Range.Delete();
                            }
                            DeleteIndivialBookmark(oWordDoc, formattedPlanType);
                        }
                    }
                }
            }
            #endregion

            #region Delete Product sections

            bool is_Patient_Advocacy_Selected = false;
            bool is_Consumer_Driven_Telemedicine_Selected = false;
            bool is_Accident_Selected = false;
            bool is_CriticalIllness_Selected = false;
            bool is_Voluntary_Cancer_Selected = false;
            bool is_Wellness_Selected = false;


            if (PlanInfoTable != null)
            {
                for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                {
                    if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                    {
                        is_Patient_Advocacy_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                    {
                        is_Consumer_Driven_Telemedicine_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                    {
                        is_Accident_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                    {
                        is_CriticalIllness_Selected = true;
                    }
                    /*******************ADDED NEW SECTION FOR Additional Products Voluntary Cancer ******************************/
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                    {
                        is_Voluntary_Cancer_Selected = true;
                    }
                    else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Wellness)
                    {
                        is_Wellness_Selected = true;
                    }
                }
            }


            if (is_Patient_Advocacy_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("PatientAdvocacyProgram"))
                {
                    oWordDoc.Bookmarks["PatientAdvocacyProgram"].Range.Delete();
                }
            }
            if (is_Consumer_Driven_Telemedicine_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Telemedicine"))
                {
                    oWordDoc.Bookmarks["Telemedicine"].Range.Delete();
                }
            }
            if (is_Wellness_Selected == false)
            {
                if (oWordDoc.Bookmarks.Exists("Welness"))
                {
                    oWordDoc.Bookmarks["Welness"].Range.Delete();
                }
            }

            #region Worksite
            if (is_Accident_Selected == false && is_CriticalIllness_Selected == false && is_Voluntary_Cancer_Selected == false)  // when both selected Delete "Worksite" section
            {
                if (oWordDoc.Bookmarks.Exists("Worksite"))
                {
                    oWordDoc.Bookmarks["Worksite"].Range.Delete();
                }
            }
            else
            {
                if (is_Accident_Selected == false)
                {
                    DeleteIndivialBookmark(oWordDoc, "Accident");
                }
                if (is_CriticalIllness_Selected == false)
                {
                    DeleteIndivialBookmark(oWordDoc, "CriticalIllness");
                }
                if (is_Voluntary_Cancer_Selected == false) /**********************ADDED NEW SECTION FOR VOLUNTORY CANCER *****/
                {
                    DeleteIndivialBookmark(oWordDoc, "VoluntaryCancer");
                }
            }
            ////else if (is_Accident_Selected == false)
            ////{
            ////    if (oWordDoc.Bookmarks.Exists("Accident"))
            ////    {
            ////        oWordDoc.Bookmarks["Accident"].Range.Delete();
            ////    }
            ////}
            ////else if (is_CriticalIllness_Selected == false)
            ////{
            ////    if (oWordDoc.Bookmarks.Exists("CriticalIllness"))
            ////    {
            ////        oWordDoc.Bookmarks["CriticalIllness"].Range.Delete();
            ////    }
            ////}
            #endregion

            #endregion

            #region Delete BRC Section
            if (isBRCSelected == false)
            {
                if (oWordDoc.Bookmarks.Exists("BRC"))
                {
                    oWordDoc.Bookmarks["BRC"].Range.Delete();
                }
            }
            #endregion

            #region Voluntary Disability  --- Remove this if not needed

            if (STD.Count == 0 && LTD.Count == 0 && VoluntarySTD.Count == 0 && VoluntaryLTD.Count == 0)
            {
                DeleteIndivialBookmark(oWordDoc, "Disability");
            }
            else
            {
                //STD ---------
                if (STD.Count > 0)
                {
                    if (STD.Count == 1)
                    {
                        DeleteIndivialBookmark(oWordDoc, "STDPlan2");
                    }
                }
                else
                {
                    DeleteIndivialBookmark(oWordDoc, "STD");
                }

                //LTD
                if (LTD.Count > 0)
                {
                    if (LTD.Count == 1)
                    {
                        DeleteIndivialBookmark(oWordDoc, "LTDPlan2");
                    }
                }
                else
                {
                    DeleteIndivialBookmark(oWordDoc, "LTD");
                }


                // Voluantry Diability 
                if (VoluntaryLTD.Count > 0 || VoluntarySTD.Count > 0)
                {
                    //Voluantry LTD
                    if (VoluntaryLTD.Count > 0)
                    {
                        if (VoluntaryLTD.Count == 1)
                        {
                            DeleteIndivialBookmark(oWordDoc, "VoluntaryLTDPlan2");
                        }
                    }
                    else
                    {
                        DeleteIndivialBookmark(oWordDoc, "VoluntaryLTD");
                    }

                    ////Voluantry LTD
                    if (VoluntarySTD.Count > 0)
                    {
                        if (VoluntarySTD.Count == 1)
                        {
                            DeleteIndivialBookmark(oWordDoc, "VoluntarySTDPlan2");
                        }
                    }
                    else
                    {
                        DeleteIndivialBookmark(oWordDoc, "VoluntarySTD");
                    }
                }
                else
                {
                    DeleteIndivialBookmark(oWordDoc, "VoluntaryDisability");
                }
            }



            #endregion

            #region
            if (VoluntaryLifeAndADnDPlans.Count > 0 || VoluntaryLife.Count > 0 || VoluntaryADnD.Count > 0)
            {
                if (VoluntaryLifeAndADnDPlans.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "VoluntaryLifeADDPlan");
                }
                if (VoluntaryLife.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "VoluntaryLifePlan");
                }
                if (VoluntaryADnD.Count == 0)
                {
                    DeleteIndivialBookmark(oWordDoc, "VoluntaryADDPlan");
                }
            }
            else
            {
                DeleteIndivialBookmark(oWordDoc, "VoluntaryLife");  // Voluntary Life Offering Section
            }
            #endregion


            if (oWordDoc.TablesOfContents.Count > 0)
            {
                oWordDoc.TablesOfContents[1].Update();
                oWordDoc.TablesOfContents[1].TabLeader = WdTabLeader.wdTabLeaderDots;
            }

        }
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        public bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        public void MergeTableColumns(Word.Document oWordDoc, int TableIndex, int MergeStart, int MergeEnd, int RowStartIndex, int RowEndIndex, List<int> SkippedRowIndexes)
        {
            Microsoft.Office.Interop.Word.Table objTable;
            objTable = oWordDoc.Tables[TableIndex];

            for (int i = RowStartIndex; i <= RowEndIndex; i++)
            {
                if (i > objTable.Rows.Count) break;
                if (SkippedRowIndexes != null && SkippedRowIndexes.Count > 0)
                {
                    if (!SkippedRowIndexes.Contains(i))
                    {
                        objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                    }
                }
                else
                {
                    objTable.Rows[i].Cells[MergeStart].Merge(objTable.Rows[i].Cells[MergeEnd]);
                }
            }
        }
        public int CheckPlanTier(int AttributeId, int BenefitSummaryId, DataTable BenefitTable)
        {
            List<int> lstBenefitColumnID = new List<int>();
            foreach (DataRow dr in BenefitTable.Rows)
            {
                if (dr["attributeID"].ToString() == AttributeId.ToString() && dr["benefitSummaryID"].ToString() == BenefitSummaryId.ToString())
                {
                    int benefitColumnID = int.Parse(dr["benefitColumnID"].ToString());
                    if (!lstBenefitColumnID.Contains(benefitColumnID))
                        lstBenefitColumnID.Add(benefitColumnID);
                }
            }
            return lstBenefitColumnID.Count;
        }
        public void WriteContribution(Word.Document oWordDoc, Word.Application oWordApp, int ContributionStartTableIndex, string CarrierName, string SummaryName, List<int> ContributionCollection, DataSet ContributionDS)
        {
            DataTable dtblContributionValues = ContributionDS.Tables["ContributionValueTable"].Copy();
            for (int i = 0; i < dtblContributionValues.Rows.Count; i++)
            {
                double PremiumPercentageValue = 0;
                double SalaryPercentageValue = 0;
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfPremium"].ToString(), out PremiumPercentageValue);
                double.TryParse(dtblContributionValues.Rows[i]["contributionValues_percentOfSalary"].ToString(), out SalaryPercentageValue);
                if (PremiumPercentageValue > 0 || SalaryPercentageValue > 0)
                {
                    dtblContributionValues.Rows[i].Delete();
                }
            }

            foreach (int ContId in ContributionCollection)
            {
                int RowIndex = 3;
                DataRow[] Contributions = dtblContributionValues.Select("ContributionValues_Contribution = " + ContId);
                List<int> UniqueRateTierIds = new List<int>();
                if (Contributions.Count() > 0)
                {
                    foreach (DataRow ContributionItem in Contributions)
                    {
                        if (!UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                        {
                            UniqueRateTierIds.Add(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                        }
                    }
                    if (UniqueRateTierIds.Count() > 0)
                    {
                        oWordDoc.Tables[ContributionStartTableIndex].Cell(1, 1).Range.Text = "Employee Contributions (" + Contributions[0]["contributionFrequency"].ToString().Replace("_", " ").Replace(" or ", "per") + ")";
                        oWordDoc.Tables[ContributionStartTableIndex].Cell(2, 1).Range.Text = Contributions[0]["description"].ToString();
                        oWordDoc.Tables[ContributionStartTableIndex].Rows[RowIndex].Range.Copy();
                        for (int a = 1; a < UniqueRateTierIds.Count(); a++)
                        {
                            oWordDoc.Tables[ContributionStartTableIndex].Rows[oWordDoc.Tables[ContributionStartTableIndex].Rows.Count].Range.Paste();
                        }
                        foreach (DataRow ContributionItem in Contributions)
                        {
                            if (UniqueRateTierIds.Contains(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString())))
                            {
                                UniqueRateTierIds.Remove(int.Parse(ContributionItem["contributionValues_rateTierID"].ToString()));
                                oWordDoc.Tables[ContributionStartTableIndex].Cell(RowIndex, 1).Range.Text = ContributionItem["contributionDescriptionWithEEIncluded"].ToString().Replace("EE", "Employee");
                                oWordDoc.Tables[ContributionStartTableIndex].Cell(RowIndex, 2).Range.Text = "$" + comFunObj.GetBenefitFormattedValue_Contribtion(ContributionItem["contributionValues_amount"].ToString());
                                RowIndex++;
                            }

                        }
                        ContributionStartTableIndex++;
                    }
                }
            }
        }

        public void WriteEligibilityToSpringField(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();
                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("EmployeeStatus"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Working"))
                    {
                        myMergeField.Select();
                        if (Working != string.Empty)
                            oWordApp.Selection.TypeText(Working);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unitofmeasure"))
                    {
                        myMergeField.Select();
                        if (UOM != string.Empty)
                            oWordApp.Selection.TypeText(UOM);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Frequency_Eligibility"))
                    {
                        myMergeField.Select();
                        if (Frequency != string.Empty)
                            oWordApp.Selection.TypeText(Frequency);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("unmarriedchildtoage"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period);
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }

    }
}