﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.AnalysisTemplate;
using BenefitPointSummaryPortal.Common.ViewModels;
using System.Globalization;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.Data;

namespace BenefitPointSummaryPortal.View
{
    public partial class AnalystAssignRequest : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        public ConstantValue cv = new ConstantValue();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        enum AccessKeys { SessionID, DeliverableCategory, IsDescriptionHide, AvailablePlanList, AvailableProductList, SelectedSummaries, SelectedProducts }
        enum PlanStatus { Pending, Current, ArchivedPriorYear };
        DataSet AccountDS = new DataSet();
        DataSet AccountTeamMemberDS = new DataSet();
        List<Contact> ContactList = new List<Contact>();

        #region Page Properties
        string SessionId
        {
            get
            {
                return Session[AccessKeys.SessionID.ToString()].ToString();
            }
            set
            {
                Session[AccessKeys.SessionID.ToString()] = value;
            }
        }
        List<int> ApplicablePlanTypes
        {
            get
            {
                List<int> AllPlans = new List<int>();
                AllPlans = WriteAnalystAssignmentRequest.LoadAllAnalystAssignmentProduct();
                return AllPlans;
            }
        }
        List<int> ApplicableProductTypes
        {
            get
            {
                List<int> AllProducts = new List<int>();
                AllProducts = WriteAnalystAssignmentRequest.LoadAllAnalystAssignmentProduct();
                return AllProducts;
            }
        }

        List<Plan> AvailablePlans
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailablePlanList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailablePlanList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailablePlanList.ToString()] = value;
            }
        }
        List<Plan> AvailableProducts
        {
            get
            {
                List<Plan> tempPlans = new List<Plan>();
                if (Session[AccessKeys.AvailableProductList.ToString()] != null)
                    tempPlans = Session[AccessKeys.AvailableProductList.ToString()] as List<Plan>;
                return tempPlans;
            }
            set
            {
                Session[AccessKeys.AvailableProductList.ToString()] = value;
            }
        }
        List<SummarySelectionViewModel> SelectedProducts
        {
            get
            {
                List<SummarySelectionViewModel> lstSelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
                lstSelectedPlansBenefitSummary = Session[AccessKeys.SelectedProducts.ToString()] == null ? lstSelectedPlansBenefitSummary : Session[AccessKeys.SelectedProducts.ToString()] as List<SummarySelectionViewModel>;
                return lstSelectedPlansBenefitSummary;
            }
            set
            {
                Session[AccessKeys.SelectedProducts.ToString()] = value;
            }
        }

        #region Plans TypeIds
        List<int> MedicalPlanTypes
        {
            get
            {
                List<int> MedicalPlanTypes = new List<int>();
                MedicalPlanTypes = WriteAnalystAssignmentRequest.MedicalPlan;
                return MedicalPlanTypes;
            }
        }
        List<int> DentalPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.Dental;
                return Plans;
            }
        }
        List<int> VisionPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.Vision;
                return Plans;
            }
        }
        List<int> HSAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.HealthSavingAccounts;
                return Plans;
            }
        }
        List<int> HRAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.HealthReimbursementArrangement;
                return Plans;
            }
        }
        List<int> LifeADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.LifeADD;
                return Plans;
            }
        }
        List<int> GroupTermPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.GroupTermLife;
                return Plans;
            }
        }
        List<int> ADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.ADD;
                return Plans;
            }
        }
        List<int> VoluntaryLifePlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.VoluntaryLife;
                return Plans;
            }
        }
        List<int> VoluntaryADDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.VoluntaryADD;
                return Plans;
            }
        }
        List<int> STDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.ShortTermDisability;
                return Plans;
            }
        }
        List<int> LTDPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.LongTermDisablity;
                return Plans;
            }
        }
        List<int> EAPPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.EmployeeAssistanceProgram;
                return Plans;
            }
        }
        List<int> FSAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.FlexibleSpendingAccount;
                return Plans;
            }
        }
        List<int> WellnessPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.Wellness;
                return Plans;
            }
        }
        List<int> plnatypes401k
        {
            get
            {
                List<int> plans = new List<int>();
                plans = WriteAnalystAssignmentRequest.Plan_401K;
                return plans;
            }
        }
        List<int> StopLossPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.StopLoss;
                return Plans;
            }
        }
        List<int> InternationalBundledPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.InternationalBundledsPlan_3_Tier;
                return Plans;
            }
        }
        List<int> BTAPlanTypes
        {
            get
            {
                List<int> Plans = new List<int>();
                Plans = WriteAnalystAssignmentRequest.BussinessTravelAccident;
                return Plans;
            }
        }



        List<SummarySelectionViewModel> SelectedPlansBenefitSummary
        {
            get
            {
                List<SummarySelectionViewModel> lstSelectedPlansBenefitSummary = new List<SummarySelectionViewModel>();
                lstSelectedPlansBenefitSummary = Session[AccessKeys.SelectedSummaries.ToString()] == null ? lstSelectedPlansBenefitSummary : Session[AccessKeys.SelectedSummaries.ToString()] as List<SummarySelectionViewModel>;
                return lstSelectedPlansBenefitSummary;
            }
            set
            {
                Session[AccessKeys.SelectedSummaries.ToString()] = value;
            }
        }
        #endregion
        #endregion
        #region UI Events

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            if (!IsPostBack)
            {
                ClearPlanGrid();
                ClearProductGrid();

                mvMainContainer.ActiveViewIndex = 0;
                SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                objCommFun.GetUserDetails();

                DictDepartment = sd.getDepartmentDetails();
                Activity_Group = "Analytics";
                Activity = "Analyst Assignment Request";

                Activity = TitleSpan.InnerText;
                Session[AccessKeys.DeliverableCategory.ToString()] = "Analytics";
                grdProducts.Style.Add("display", "none");

            }
        }
        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                List<Account> AccountList = new List<Account>();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlClient_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
            ClearProductGrid();
            rdlPlanStatus.SelectedValue = PlanStatus.Current.ToString();



        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        protected void btnViewPlans_Click(object sender, EventArgs e)
        {

            bool isPlanStatusSelected = false;

            for (int i = 0; i <= 2; i++)
            {
                if (rdlPlanStatus.Items[i].Selected == true)
                {
                    isPlanStatusSelected = true;
                }
            }

            if (ValidateCriteriaPage())
            {
                if (isPlanStatusSelected == false)
                {
                    ShowAlertMessage("Please select plan status.");
                    rdlPlanStatus.Focus();
                    return;
                }

                else
                {

                    LoadPlansAndProducts();
                }
            }

        }
        protected void rdlPlanStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearPlanGrid();
            ClearProductGrid();
        }
        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                string filename = "";
                if (Convert.ToString(Session["Summary"]) == "AnalystAssignmentReq" && ValidateCriteriaPage())
                {
                    AddSelctedPlanBenefitSummaryToSessions();
                    AddSelectedProductsToSession();
                    if (SelectedPlansBenefitSummary == null || SelectedPlansBenefitSummary.Count == 0)
                    {
                        ShowAlertMessage("Please select at least one plan.");
                        return;
                    }

                    // bool success = ValidateBenefitSummarySelection();

                    #region fetch data

                    sd.BuildAccountTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    #endregion

                    filename = CreateAnalystAssignRequest(AccountDS, AccountTeamMemberDS, Account_Office);
                    DownloadFileNew(filename);

                    InsertLog();

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        protected void chkPlanHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        protected void chkProductHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkPlanHeaderSelect = sender as CheckBox;
            foreach (GridViewRow row in grdProducts.Rows)
            {
                CheckBox chkItemSelect = row.FindControl("chkItemSelect") as CheckBox;
                if (chkItemSelect != null)
                    chkItemSelect.Checked = chkPlanHeaderSelect.Checked;
            }
            //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdProducts');</script>", false);
        }


        #endregion

        #region Functions
        private void ClearPlanGrid()
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            trPlanContainer.Style.Add("display", "none");
            tblEmptyPlanTemplate.Style.Add("display", "none");
            grdPlans.Style.Add("display", "none");
        }
        private void ClearProductGrid()
        {
            grdProducts.DataSource = null;
            grdProducts.DataBind();
            trProductContainer.Style.Add("display", "none");
            tblEmptyProductTemplate.Style.Add("display", "none");
            grdProducts.Style.Add("display", "none");
        }
        private void ResetForm()
        {

            txtsearch.Text = "";
            ddlClient.Items.Clear();
            ddlClient.Items.Add(new ListItem("Select", ""));
            rdlClient.SelectedIndex = 0;


            ddlClient_SelectedIndexChanged(null, null);

        }
        private void LoadPlansAndProducts()
        {
            List<Plan> PlanList = new List<Plan>();
            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
            LoadPlans(PlanList);
            LoadProducts(PlanList);
        }
        private void LoadPlans(List<Plan> PlanList)
        {
            ClearPlanGrid();
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;
                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                CanAdd = true;
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                CanAdd = true;
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                CanAdd = true;
                            }
                        }
                        if (MedicalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.MedicalLOC;
                        }
                        if (DentalPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.DentalLOC;
                        }
                        if (VisionPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VisionLOC;
                        }
                        if (HSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HSALOC;
                        }
                        if (HRAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.HRALOC;
                        }
                        if (LifeADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LifeADDLOC;
                        }
                        if (GroupTermPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                        }
                        if (ADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.ADNDPlanType_CommonCriteria;
                        }
                        if (VoluntaryLifePlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.VoluntaryLife;
                        }
                        if (VoluntaryADDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                        }
                        if (STDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.STDLOC;
                        }
                        if (LTDPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.LTDLOC;
                        }
                        if (EAPPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.EAPLOC;
                        }
                        if (FSAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.FSAPlanType;
                        }
                        if (WellnessPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.Wellness;
                        }
                        if (StopLossPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = cv.StopLoss;
                        }

                        if (plnatypes401k.Contains(item.ProductTypeId))
                        {
                            item.LOC = "401K";
                        }
                        if (BTAPlanTypes.Contains(item.ProductTypeId))
                        {
                            item.LOC = "BTA";
                        }

                        if (CanAdd)
                            FilteredPlanList.Add(item);

                    }
                }
            }


            FilteredPlanList = SortPlans(FilteredPlanList);
            grdPlans.DataSource = FilteredPlanList;
            grdPlans.DataBind();


            if (FilteredPlanList.Count > 0)
            {
                CheckBox chkPlanHeaderSelect = grdPlans.HeaderRow.FindControl("chkPlanHeaderSelect") as CheckBox;
                chkPlanHeaderSelect.Checked = true;
                chkPlanHeaderSelect_CheckedChanged(chkPlanHeaderSelect, null);
            }
            trPlanContainer.Style.Add("display", "");

            if (FilteredPlanList.Count > 0)
            {
                //ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                grdPlans.Style.Add("display", "");
            }
            else
            {
                tblEmptyPlanTemplate.Style.Add("display", "");
            }

            AvailablePlans = FilteredPlanList;
        }
        private void LoadProducts(List<Plan> PlanList)
        {
            ClearProductGrid();
            List<Plan> FilteredPlanList = new List<Plan>();
            List<string> lstStatuses = new List<string>();
            if (PlanList != null)
            {
                if (PlanList.Count > 0)
                {
                    foreach (ListItem item in rdlPlanStatus.Items)
                    {
                        if (item.Selected)
                            lstStatuses.Add(item.Value);
                    }
                    bool CanAdd = false;
                    foreach (Plan item in PlanList)
                    {
                        CanAdd = false;
                        item.SummaryID = 0;
                        item.SummaryName = string.Empty;
                        if (lstStatuses.Contains(PlanStatus.Pending.ToString()))
                        {
                            if (item.EffectiveDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.Current.ToString()))
                        {
                            if (item.EffectiveDate.Date < System.DateTime.Now.Date && item.RenewalDate.Date > System.DateTime.Now.Date)
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (lstStatuses.Contains(PlanStatus.ArchivedPriorYear.ToString()))
                        {
                            if (item.RenewalDate.Date == System.DateTime.Now.Date || (item.RenewalDate.Date > System.DateTime.Now.AddYears(-1).Date && item.RenewalDate.Date <= DateTime.Now.Date))
                            {
                                if (ApplicableProductTypes.Contains(item.ProductTypeId))
                                {
                                    CanAdd = true;
                                }
                            }
                        }
                        if (CanAdd)
                            FilteredPlanList.Add(item);
                    }
                }
            }
            FilteredPlanList = (from l in FilteredPlanList
                                orderby l.ProductTypeId ascending
                                select l).ToList();

            grdProducts.DataSource = FilteredPlanList;
            grdProducts.DataBind();

            if (FilteredPlanList.Count > 0)
            {

                CheckBox chkProductHeaderSelect = grdProducts.HeaderRow.FindControl("chkProductHeaderSelect") as CheckBox;
                chkProductHeaderSelect.Checked = true;
                chkProductHeaderSelect_CheckedChanged(chkProductHeaderSelect, null);
            }

            trProductContainer.Style.Add("display", "");
            if (FilteredPlanList.Count > 0)
            {
                // ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdProducts');</script>", false);
                grdProducts.Style.Add("display", "");
            }
            else
            {
                tblEmptyProductTemplate.Style.Add("display", "");
            }

            AvailableProducts = FilteredPlanList;
        }
        private List<Plan> SortPlans(List<Plan> lstPlans)
        {
            List<Plan> lstSortedPlan = new List<Plan>();
            foreach (BenefitSummaryStructure item in WriteAnalystAssignmentRequest.BenefitSummarySelectionMap)
            {
                List<Plan> lstLOCPlans = new List<Plan>();
                List<BenefitSummaryDropDownViewModel> lstSummaryDataSource = new List<BenefitSummaryDropDownViewModel>();
                if (item.LOC == cv.LifeADDLOC)
                {

                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.LifeADDLOC || r.LOC == cv.GroupTermLifePlanType_CommonCriteria || r.LOC == cv.ADNDPlanType_CommonCriteria).ToList();
                }
                else if (item.LOC == cv.VoluntaryLifeADDLOC)
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == cv.VoluntaryLife || r.LOC == cv.Voluntary_ADNDPlanType_CommonCriteria).ToList();
                }
                else
                {
                    lstLOCPlans = lstPlans.Where(r => r.LOC == item.LOC).ToList();
                }
                lstLOCPlans = (from l in lstLOCPlans
                               orderby l.ProductTypeDescription, l.SummaryName, l.CarrierName, l.RenewalDate ascending
                               select l).ToList();

                lstSortedPlan.AddRange(lstLOCPlans);

            }
            return lstSortedPlan;

        }

        private void AddSelctedPlanBenefitSummaryToSessions()
        {
            ConstantValue cv = new ConstantValue();
            List<SummarySelectionViewModel> lstSelectedSummaries = new List<SummarySelectionViewModel>();
            SelectedPlansBenefitSummary = lstSelectedSummaries;
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true)
                        {
                            SummarySelectionViewModel BenefitSummaryItem = new SummarySelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                BenefitSummaryItem.SummaryName = Convert.ToString(grRow.Cells[1].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryName = string.Empty;
                            }
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            // For ProductTypeId
                            // If ProductTypeId is > 3 the 'You are not authorized to access the requesn it gives an errorted information.'
                            // So we are taking ProductTypeId < 4
                            if (Convert.ToString(grRow.Cells[8].Text).Length < 5)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                                }
                                else
                                {
                                    BenefitSummaryItem.ProductTypeId = 0;
                                }
                            }

                            // For SummaryID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[9].Text)))
                            {
                                BenefitSummaryItem.SummaryId = int.Parse((grRow.Cells[9].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.SummaryId = 0;
                            }

                            if (MedicalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.MedicalLOC;
                            }
                            if (DentalPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.DentalLOC;
                            }
                            if (VisionPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VisionLOC;
                            }
                            if (LifeADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LifeADDLOC;
                            }
                            if (GroupTermPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.GroupTermLifePlanType_CommonCriteria;
                            }
                            if (ADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.ADNDPlanType_CommonCriteria;
                            }
                            if (VoluntaryLifePlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.VoluntaryLife;
                            }
                            if (VoluntaryADDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Voluntary_ADNDPlanType_CommonCriteria;
                            }
                            if (LTDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.LTDLOC;
                            }

                            if (STDPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.STDLOC;
                            }

                            if (EAPPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.EAPLOC;
                            }

                            if (FSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.FSAPlanType;
                            }
                            if (HSAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HSALOC;
                            }
                            if (HRAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.HRALOC;
                            }
                            if (StopLossPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.StopLoss;
                            }
                            if (WellnessPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = cv.Wellness;
                            }
                            if (plnatypes401k.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "401K";
                            }
                            if (BTAPlanTypes.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.LOC = "BTA";
                            }
                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }

                    }//Foreach Close
                    SelectedPlansBenefitSummary = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void AddSelectedProductsToSession()
        {
            ConstantValue cv = new ConstantValue();
            List<SummarySelectionViewModel> lstSelectedSummaries = new List<SummarySelectionViewModel>();
            SelectedProducts = lstSelectedSummaries;
            try
            {
                int rowCount = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdProducts != null)
                {
                    foreach (GridViewRow grRow in grdProducts.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));
                        if (chkItemSelect.Checked == true)
                        {
                            SummarySelectionViewModel BenefitSummaryItem = new SummarySelectionViewModel();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                BenefitSummaryItem.ProductTypeDescription = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeDescription = string.Empty;
                            }
                            // For SummaryName
                            BenefitSummaryItem.SummaryName = string.Empty;
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                BenefitSummaryItem.CarrierName = Convert.ToString(grRow.Cells[2].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.CarrierName = string.Empty;
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                BenefitSummaryItem.EffectiveDate = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.EffectiveDate = string.Empty;
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                BenefitSummaryItem.RenewalDate = Convert.ToString(grRow.Cells[4].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.RenewalDate = string.Empty;
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                BenefitSummaryItem.PolicyNumber = Convert.ToString(grRow.Cells[5].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                BenefitSummaryItem.PolicyNumber = string.Empty;
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                BenefitSummaryItem.ProductId = int.Parse(grRow.Cells[6].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductId = 0;
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                BenefitSummaryItem.ProductName = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                BenefitSummaryItem.ProductName = string.Empty;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                            {
                                BenefitSummaryItem.ProductTypeId = int.Parse((grRow.Cells[8].Text));
                            }
                            else
                            {
                                BenefitSummaryItem.ProductTypeId = 0;
                            }

                            BenefitSummaryItem.SummaryId = 0;


                            lstSelectedSummaries.Add(BenefitSummaryItem);
                            rowCount++;
                        }
                    }//Foreach Close
                    SelectedProducts = lstSelectedSummaries;
                }//If Outer Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        private bool ValidateCriteriaPage()
        {

            if (ddlClient.SelectedIndex == 0 || ddlClient.SelectedIndex == -1)
            {
                ShowAlertMessage("Please select Client Name.");

                ddlClient.Focus();
                return false;
            }

            return true;
        }
        public static void ShowAlertMessage(string error)
        {
            Page page = HttpContext.Current.Handler as Page;

            if (page != null)
            {
                error = error.Replace("'", "\'");

                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
            }
        }

        #endregion

        //Method Added by shravan - for template writing
        private string CreateAnalystAssignRequest(DataSet AccountDS, DataSet AccountTeamMemberDS, string Account_Office)
        {
            // SessionId = Session["SessionId"].ToString();
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;
            DataTable dtOfficeAddress = new DataTable();

            Object fileName = "";

            fileName = Server.MapPath("~/Files/AnalystAssignmentRequest/Documents/Templates/AnalystAssignReq_Template.docx");


            Object readOnly = true;
            Object isVisible = false;
            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                ref missing, ref readOnly,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref missing,
                                ref missing, ref missing, ref isVisible,
                                ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/AnalystAssignmentRequest/Documents/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                    System.DateTime.Now.Month.ToString() +
                                    System.DateTime.Now.Day.ToString() +
                                    System.DateTime.Now.Hour.ToString() +
                                    System.DateTime.Now.Minute.ToString() +
                                    System.DateTime.Now.Second.ToString() +
                                    System.DateTime.Now.Millisecond.ToString() +
                                    ".docx");
            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/AnalystAssignmentRequest/Documents/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/AnalystAssignmentRequest/Documents/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                WriteAnalystAssignmentRequest wr = new WriteAnalystAssignmentRequest();
                wr.WriteAnalystTable(oWordDoc, ddlClient.SelectedValue, SessionId);
                wr.WriteAccountAndContactDetails(oWordDoc, oWordApp, AccountDS, AccountTeamMemberDS, ddlClient.SelectedItem.Text, Account_Office);
                wr.WritePlanOrProductTable(oWordDoc, oWordApp, SelectedPlansBenefitSummary, SelectedProducts);
                wr.WritePlanTable(oWordDoc, oWordApp, SelectedPlansBenefitSummary, ddlClient, SessionId);
                
                if (SelectedProducts!=null && SelectedProducts.Count > 0)
                {
                    wr.WriteProductTable(oWordDoc, oWordApp, SelectedProducts, SessionId);
                }
                else
                {
                    wr.DeleteIndivialBookmark(oWordDoc, "ProductsTable");
                }
               
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void InsertLog(string Criteria1 = "", string Criteria2 = "", string Criteria3 = "", string Criteria4 = "")
        {
            DicActivityLog.Clear();
            string deliverableCategory = "Analytics";
            Activity = "Analyst Assignment Request";
            Activity_Group = "Analytics";

            DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
            bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedValue), Account_Region, Account_Office, deliverableCategory, Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Criteria1, Criteria2, Criteria3, Criteria4);

        }

    }
}