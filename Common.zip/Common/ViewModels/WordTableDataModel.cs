﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.ViewModels
{
    public class WordTableDataModel
    {
        public int TableIndex { get;set;}
        public int RowIndex { get; set; }
        public int ColumnIndex { get; set; }
        /// <summary>
        /// at this time 0 to write at the begining, -1 to write at the end 
        /// </summary>
        public int CharacterIndex { get; set; }
        public string Data;  
    }
}