﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Configuration;
using System.IO;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.View
{
    public partial class AdminPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void lnkOfficeAddress_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_OfficeAddress.aspx");
        }

        protected void lnkBRCInformation_Click(object sender, EventArgs e)
        {
            Response.Redirect("BRC_Information.aspx");
        }

        protected void lnkPotalUsage_Click(object sender, EventArgs e)
        {
           Response.Redirect("Activity.aspx");
        }
        protected void lnkBRCLocation_Click(object sender, EventArgs e)
        {
            Response.Redirect("BRC_Location.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("ServiceSetting.aspx");
        }
    }
}