﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.Tools;
using System.Drawing;

namespace BenefitPointSummaryPortal.BAL.Tools
{
    public class WriteTools2 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        public void WriteFieldToTools2(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DataSet AccountDS, DataTable PlanInfoTable, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, ArrayList arrAcctContact)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();
                string value = string.Empty;
                DateTime dateValue = new DateTime();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();

                string SalesLead_FirstName = string.Empty;
                string SalesLead_LastName = string.Empty;
                string SalesLead_EMail = string.Empty;
                string SalesLead_WorkPhone = string.Empty;

                string ServiceLead_FirstName = string.Empty;
                string ServiceLead_LastName = string.Empty;
                string ServiceLead_EMail = string.Empty;
                string ServiceLead_WorkPhone = string.Empty;

                string AnalyticalSupport_FirstName = string.Empty;
                string AnalyticalSupport_LastName = string.Empty;
                string AnalyticalSupport_EMail = string.Empty;
                string AnalyticalSupport_WorkPhone = string.Empty;

                string MainPhone = string.Empty;
                string MainAddress = string.Empty;
                string Required_5500 = string.Empty;
                string Broker_Of_Record = string.Empty;
                string Primary_Industry = string.Empty;
                string Num_Of_FTE = string.Empty;
                string Num_Of_FTE_AS_Of = string.Empty;
                string Num_Of_FTEquivalents = string.Empty;
                string Num_Of_FTEquivalents_AS_Of = string.Empty;
                string Num_Of_Retiree = string.Empty;
                string Num_Of_Retiree_As_Of = string.Empty;
                string BRC_Status = string.Empty;
                string BRC_Date_Implemented = string.Empty;

                List<string> MedicalPlanTypeList = new List<string>();

                MedicalPlanTypeList.Add("100");
                MedicalPlanTypeList.Add("110");
                MedicalPlanTypeList.Add("120");
                MedicalPlanTypeList.Add("130");
                MedicalPlanTypeList.Add("140");
                MedicalPlanTypeList.Add("150");
                MedicalPlanTypeList.Add("160");
                MedicalPlanTypeList.Add("170");
                MedicalPlanTypeList.Add("1116");


                #region For Address and Phone Number - Team Members
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[0].Rows.Count > 0)
                    {
                        for (int n = 0; n < AccountDS.Tables[0].Rows.Count; n++)
                        {
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "16799")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    MainPhone = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }

                            // BRC Status
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "35479")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    BRC_Status = Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]);
                                    continue;
                                }
                            }

                            // BRC Date Implemented
                            if (Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_customFieldID"]) == "35480")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])))
                                {
                                    if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"]), out dateValue) == true)
                                    {
                                        BRC_Date_Implemented = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[0].Rows[n]["customFieldValues_valueText"])).ToString("MM/dd/yyyy");
                                    }
                                    continue;
                                }
                            }
                        }
                    }

                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                            {
                                for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                {
                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        SalesLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        SalesLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        ServiceLead_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        ServiceLead_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]), SessionId);
                                    }

                                    if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                    {
                                        AnalyticalSupport_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                        AnalyticalSupport_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        AnalyticalSupport_EMail = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["email"]);
                                        AnalyticalSupport_WorkPhone = sd.GetUserWorkPhoneNumber(Convert.ToInt32(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]), SessionId);
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"])))
                            {
                                Required_5500 = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_requires5500"]);

                                if (Required_5500.ToLower() == "false")
                                {
                                    Required_5500 = "No";
                                }
                                else if (Required_5500.ToLower() == "true")
                                {
                                    Required_5500 = "Yes";
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                                {
                                    Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"])))
                            {
                                Primary_Industry = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_primaryIndustry"]);
                                Primary_Industry = Primary_Industry.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                            {
                                Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"])))
                            {
                                Num_Of_FTEquivalents = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalents"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"]), out dateValue) == true)
                                {
                                    Num_Of_FTEquivalents_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate"])).ToString("MM/dd/yyyy");
                                }
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"])))
                            {
                                Num_Of_Retiree = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetirees"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])))
                            {
                                if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"]), out dateValue) == true)
                                {
                                    Num_Of_Retiree_As_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf"])).ToString("MM/dd/yyyy");
                                }
                            }
                        }
                    }

                    MainAddress = sd.GetFormattedAddress(AccountDS, "Tools2").Trim();
                }

                #endregion

                //for (int k = 0; k < ActivityInfoTable.Rows.Count; k++)
                //{
                //if (ActivityInfoTable.Rows[k]["recordID"].ToString() == ActivityDS.Tables["activityrecord_table"].Rows[0]["recordID"].ToString())
                //{
                #region MergeField
                string effectiveDate = string.Empty;

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    //if (dr["Name"].ToString().Substring(0, dr["Name"].ToString().IndexOf(" ")).ToLower() == "medical")
                    if (MedicalPlanTypeList.Contains(dr["ProductTypeId"].ToString()))
                    {
                        effectiveDate = Convert.ToString(dr["Effective"]);
                        effectiveDate = Convert.ToString(Convert.ToDateTime(effectiveDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectiveDate.ToString()).Year.ToString());
                        break;
                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Sysdate"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                            continue;
                        }

                        if (fieldName.Contains("First Med Plan Effective Date"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(effectiveDate))
                            {
                                oWordApp.Selection.TypeText(effectiveDate);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainAddress))
                            {
                                oWordApp.Selection.TypeText(MainAddress);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Main Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(MainPhone))
                            {
                                oWordApp.Selection.TypeText(MainPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("5500 Required"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Required_5500))
                            {
                                oWordApp.Selection.TypeText(Required_5500);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Broker of Record"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(Broker_Of_Record);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Industry"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Primary_Industry))
                            {
                                oWordApp.Selection.TypeText(Primary_Industry);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("BRC Status"))
                        {
                            myMergeField.Select();
                            if (BRC_Status.ToLower() == "select")
                            {
                                BRC_Status = "";
                            }
                            if (!string.IsNullOrEmpty(BRC_Status) && !(string.IsNullOrEmpty(BRC_Date_Implemented)) && BRC_Date_Implemented != "01/01/0001")
                            {
                                oWordApp.Selection.TypeText(BRC_Status + " as of " + BRC_Date_Implemented);
                            }
                            else if (!string.IsNullOrEmpty(BRC_Status) && (string.IsNullOrEmpty(BRC_Date_Implemented)))
                            {
                                if (BRC_Status == "0" && string.IsNullOrEmpty(BRC_Date_Implemented))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(BRC_Status);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Employees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                                oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                            {
                                if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTE);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Full Time Equivalents"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && !(string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)) && Num_Of_FTEquivalents_AS_Of != "01/01/0001")
                            {
                                decimal Number_Of_FTEquivalents = Convert.ToDecimal(Num_Of_FTEquivalents);
                                oWordApp.Selection.TypeText(Number_Of_FTEquivalents.ToString("#,##0") + " as of " + Num_Of_FTEquivalents_AS_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_FTEquivalents) && (string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of)))
                            {
                                if (Num_Of_FTEquivalents == "0" && string.IsNullOrEmpty(Num_Of_FTEquivalents_AS_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_FTEquivalents);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Number of Retirees"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Num_Of_Retiree) && !(string.IsNullOrEmpty(Num_Of_Retiree_As_Of)) && Num_Of_Retiree_As_Of != "01/01/0001")
                            {
                                decimal Number_Retiree = Convert.ToDecimal(Num_Of_Retiree);
                                oWordApp.Selection.TypeText(Number_Retiree.ToString("#,##0") + " as of " + Num_Of_Retiree_As_Of);
                            }
                            else if (!string.IsNullOrEmpty(Num_Of_Retiree) && (string.IsNullOrEmpty(Num_Of_Retiree_As_Of)))
                            {
                                if (Num_Of_Retiree == "0" && string.IsNullOrEmpty(Num_Of_Retiree_As_Of))
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(Num_Of_Retiree);
                                }
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_FirstName) || !string.IsNullOrEmpty(SalesLead_LastName))
                            {
                                oWordApp.Selection.TypeText(SalesLead_FirstName + " " + SalesLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_EMail))
                            {
                                oWordApp.Selection.TypeText(SalesLead_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Sales Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(SalesLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(SalesLead_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_FirstName) || !string.IsNullOrEmpty(ServiceLead_LastName))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_FirstName + " " + ServiceLead_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_EMail))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Service Lead Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ServiceLead_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(ServiceLead_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_FirstName) || !string.IsNullOrEmpty(AnalyticalSupport_LastName))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_FirstName + " " + AnalyticalSupport_LastName);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Email"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_EMail))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_EMail);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }

                        if (fieldName.Contains("Primary Contact Phone"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AnalyticalSupport_WorkPhone))
                            {
                                oWordApp.Selection.TypeText(AnalyticalSupport_WorkPhone);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }
                #endregion

                #region Write Table of Account Contacts
                Tools_Constant tc = new Tools_Constant();
                string accountInfo = string.Empty;
                int clmCnt = 1;
                string name = string.Empty;
                string title = string.Empty;
                string email = string.Empty;
                string phoneNumber = string.Empty;

                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    //if (ContactList[i].Responsibility != null && ContactList[i].Title != null)
                                    //{
                                    ////if (ContactList[i].Title == tc.Tools2_CEO || ContactList[i].Title == tc.Tools2_CFO || ContactList[i].Title == tc.Tools2__HumanResources || ContactList[i].Title == tc.Tools2_VPFinance || ContactList[i].Title == tc.Tools2_VPHumanResources)
                                    //if (ContactList[i].Responsibility.ToLower() == tc.Tools2_CEO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_CFO.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2__HumanResources.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPFinance.ToLower() || ContactList[i].Responsibility.ToLower() == tc.Tools2_VPHumanResources.ToLower())
                                    //{
                                    if (clmCnt > 1)
                                    {
                                        //oWordDoc.Tables[2].Columns.Add();
                                        oWordDoc.Tables[2].Rows.Add();
                                    }

                                    if (ContactList[i].Name != null)
                                    {
                                        name = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        name = " ";
                                    }

                                    if (ContactList[i].Title != null)
                                    {
                                        title = ContactList[i].Title;
                                    }
                                    else
                                    {
                                        title = " ";
                                    }

                                    if (ContactList[i].Email != null)
                                    {
                                        email = ContactList[i].Email;
                                    }
                                    else
                                    {
                                        email = " ";
                                    }

                                    if (ContactList[i].Phone.Count > 0)
                                    {
                                        phoneNumber = ContactList[i].Phone[0];
                                    }
                                    else
                                    {
                                        phoneNumber = " ";
                                    }
                                    //accountInfo = name + "\n" + title + "\n" + email + "\n" + phoneNumber;
                                    //oWordDoc.Tables[2].Cell(1, clmCnt).Range.Text = "Client Contact:";
                                    //oWordDoc.Tables[2].Cell(2, clmCnt).Range.Text = accountInfo;
                                    //oWordDoc.Tables[2].Columns.Width = (float)(554.4 / clmCnt);
                                    oWordDoc.Tables[2].Cell(j + 2, 1).Range.Text = name;
                                    oWordDoc.Tables[2].Cell(j + 2, 2).Range.Text = title;
                                    oWordDoc.Tables[2].Cell(j + 2, 3).Range.Text = phoneNumber;
                                    oWordDoc.Tables[2].Cell(j + 2, 4).Range.Text = email;

                                    clmCnt++;

                                    //if (clmCnt > 3)
                                    //{
                                    //    break;
                                    //}
                                    //}
                                    //}
                                    break;
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Write Table of PLans
                ArrayList PlanTypeList = new ArrayList();
                ArrayList CarrerNameList = new ArrayList();
                ArrayList PolicyNumberlist = new ArrayList();
                ArrayList effectiveList = new ArrayList();
                ArrayList RenewalList = new ArrayList();
                ArrayList Benefit_DescList = new ArrayList();
                ArrayList ContributionMethodList = new ArrayList();
                ArrayList FundingTypeList = new ArrayList();
                ArrayList NumberOfEmpList = new ArrayList();
                #endregion

                #region Plan Infor Code
                int rowCnt = 4;
                int m = 1;
                string PlanType = "";
                string FundingType = "";
                string Benefit_Desc = "";

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    PlanType = dr["Name"].ToString().Replace("\r", "").Replace("\a", "").Trim();
                    BenefitSummaryList.Clear();
                    if (dr["ProductTypeId"].ToString().Length == 3)
                    //if (dr["ProductTypeId"].ToString().Length <=4)
                    {
                        if (BenefitSummaryList != null)
                        {
                            BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(dr["ProductId"].ToString()), SessionId);
                        }
                        //if (BenefitSummaryList != null)
                        //{
                        //    Benefit_Desc = BenefitSummaryList[0].BenefitDescription.Trim();
                        //}
                        //else
                        //{
                        //    Benefit_Desc = "";
                        //}
                    }
                    else
                    {
                        Benefit_Desc = dr["ProductName"].ToString().Trim().Substring(0, dr["ProductName"].ToString().Trim().IndexOf("|")).Trim();
                    }
                    int NoofELGEmployee = sd.GetProductDetail_numberofeligibleemployee(int.Parse(dr["ProductId"].ToString()), SessionId);

                    int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(int.Parse(dr["ProductId"].ToString()), SessionId);

                    switch (OptionFieldValueiD)
                    {
                        //case 52403: FundingType = "Self-Insured"; break;
                        case 52403: FundingType = "Self Funded"; break;
                        case 52401: FundingType = "Fully Insured"; break;
                        case 52400: FundingType = ""; break;
                        default: FundingType = ""; break;
                    }

                    string contributionMethod = string.Empty;
                    bool isFirstBSTaken = false;
                    if (dr["ProductName"].ToString() != null)
                    {
                        if (dr["ProductName"].ToString().Trim().ToLower().Contains("shared"))
                        {
                            contributionMethod = "Shared";
                        }
                        else if (dr["ProductName"].ToString().Trim().ToLower().Contains("er paid"))
                        {
                            contributionMethod = "Employer Paid";
                        }
                        else if (dr["ProductName"].ToString().Trim().ToLower().Contains("ee paid"))
                        {
                            contributionMethod = "Employee Paid";
                        }
                        else
                        {
                            contributionMethod = "Not Listed";
                        }
                    }
                    else
                    {
                        contributionMethod = "Not Listed";
                    }

                    //if (!PlanTypeList.Contains(PlanType))
                    //{
                    PlanTypeList.Add(PlanType);
                    CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                    PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim());
                    effectiveList.Add(dr["Effective"].ToString().Trim());
                    RenewalList.Add(dr["Renewal"].ToString().Trim());
                    ContributionMethodList.Add(contributionMethod);
                    FundingTypeList.Add(FundingType);
                    //Benefit_DescList.Add(Benefit_Desc);
                    Benefit_DescList.Clear();
                    NumberOfEmpList.Add(NoofELGEmployee);
                    if (rowCnt > 4)
                    {
                        oWordDoc.Tables[4].Rows.Add();
                        oWordDoc.Tables[4].Rows.Add();
                        oWordDoc.Tables[4].Rows.Add();
                        oWordDoc.Tables[4].Rows.Add();

                        oWordDoc.Tables[4].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineStyle = Word.WdLineStyle.wdLineStyleSingle;
                        oWordDoc.Tables[4].Rows[m].Borders[Word.WdBorderType.wdBorderTop].LineWidth = Word.WdLineWidth.wdLineWidth225pt;
                    }
                    oWordDoc.Tables[4].Cell(m, 1).Range.Text = dr["Name"].ToString().Trim();

                    oWordDoc.Tables[4].Cell(m, 2).Range.Text = "Carrier:";
                    oWordDoc.Tables[4].Cell(m, 2).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m, 2).Range.Font.Size = 9;
                    oWordDoc.Tables[4].Cell(m, 3).Range.Text = "Group Number:";
                    oWordDoc.Tables[4].Cell(m, 3).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m, 3).Range.Font.Size = 9;
                    oWordDoc.Tables[4].Cell(m, 4).Range.Text = "Effective Date:";
                    oWordDoc.Tables[4].Cell(m, 4).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m, 4).Range.Font.Size = 9;
                    oWordDoc.Tables[4].Cell(m, 5).Range.Text = "Renewal Date:";
                    oWordDoc.Tables[4].Cell(m, 5).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m, 5).Range.Font.Size = 9;

                    oWordDoc.Tables[4].Cell(m + 1, 2).Range.Text = dr["Carrier"].ToString().Trim();
                    oWordDoc.Tables[4].Cell(m + 1, 2).Range.Font.Size = 10;
                    oWordDoc.Tables[4].Cell(m + 1, 3).Range.Text = dr["PolicyNumber"].ToString().Trim();
                    oWordDoc.Tables[4].Cell(m + 1, 3).Range.Font.Size = 10;
                    oWordDoc.Tables[4].Cell(m + 1, 4).Range.Text = Convert.ToDateTime(dr["Effective"].ToString().Trim()).ToString("MM/dd/yyyy");
                    oWordDoc.Tables[4].Cell(m + 1, 4).Range.Font.Size = 10;
                    oWordDoc.Tables[4].Cell(m + 1, 5).Range.Text = Convert.ToDateTime(dr["Renewal"].ToString().Trim()).ToString("MM/dd/yyyy");
                    oWordDoc.Tables[4].Cell(m + 1, 5).Range.Font.Size = 10;
                    //oWordDoc.Tables[4].Cell(m + 1, 2).Range.Text = "PLAN NAME(S)" + "\n" + Benefit_Desc.Trim();
                    //--------------------- Added new code by Mandar Apate on 18 Nov 2014 starts here ----------------------
                    if (dr["ProductTypeId"].ToString().Length == 3)
                    {
                        oWordDoc.Tables[4].Cell(m + 2, 2).Range.Text = "Plan Name(s):";
                        oWordDoc.Tables[4].Cell(m + 2, 2).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m + 2, 2).Range.Font.Size = 9;
                    }
                    for (int i = 0; i < BenefitSummaryList.Count; i++)
                    {
                        if (BenefitSummaryList.Count > 1)
                        {
                            if (isFirstBSTaken == false)
                            {
                                oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text = oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text.Replace("\r", "") + BenefitSummaryList[i].BenefitDescription.Trim();
                                isFirstBSTaken = true;
                                oWordDoc.Tables[4].Cell(m + 3, 2).Range.Font.Size = 10;
                            }
                            else
                            {
                                oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text = oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text.Replace("\r", "") + ", " + BenefitSummaryList[i].BenefitDescription.Trim();
                                oWordDoc.Tables[4].Cell(m + 3, 2).Range.Font.Size = 10;
                            }
                        }
                        else
                        {
                            oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text = oWordDoc.Tables[4].Cell(m + 3, 2).Range.Text.Replace("\r", "") + BenefitSummaryList[i].BenefitDescription.Trim();
                            oWordDoc.Tables[4].Cell(m + 3, 2).Range.Font.Size = 10;
                        }

                        Benefit_DescList.Add(BenefitSummaryList[i].BenefitDescription);
                    }
                    //--------------------- Added new code by Mandar Apate on 18 Nov 2014 ends here ----------------------


                    if (!string.IsNullOrEmpty(contributionMethod))
                    {
                        oWordDoc.Tables[4].Cell(m + 2, 3).Range.Text = "Contribution Method:";
                        oWordDoc.Tables[4].Cell(m + 2, 3).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(m + 2, 3).Range.Font.Size = 9;
                        oWordDoc.Tables[4].Cell(m + 3, 3).Range.Text = contributionMethod;
                        oWordDoc.Tables[4].Cell(m + 3, 3).Range.Font.Size = 10;
                    }

                    oWordDoc.Tables[4].Cell(m + 2, 4).Range.Text = "Funding Type:";
                    oWordDoc.Tables[4].Cell(m + 2, 4).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m + 2, 4).Range.Font.Size = 9;
                    oWordDoc.Tables[4].Cell(m + 3, 4).Range.Text = FundingType;
                    oWordDoc.Tables[4].Cell(m + 3, 4).Range.Font.Size = 10;

                    oWordDoc.Tables[4].Cell(m + 2, 5).Range.Text = "Eligible Employees:";
                    oWordDoc.Tables[4].Cell(m + 2, 5).Range.Bold = 1;
                    oWordDoc.Tables[4].Cell(m + 2, 5).Range.Font.Size = 9;
                    oWordDoc.Tables[4].Cell(m + 3, 5).Range.Text = NoofELGEmployee.ToString("#,##0");
                    oWordDoc.Tables[4].Cell(m + 3, 5).Range.Font.Size = 10;


                    m = m + 4;
                    //}
                    //else
                    //{
                    //    int k = 0;
                    //    string Plan_Type1 = null;
                    //    for (int j = 1; j < oWordDoc.Tables[4].Rows.Count; j++)
                    //    {
                    //        Plan_Type1 = oWordDoc.Tables[4].Cell(j, 1).Range.Text.Replace("\r", "").Replace("\a", "");
                    //        if (Plan_Type1.Trim() == PlanType.Trim())
                    //        {
                    //            k = j;
                    //            break;
                    //        }
                    //    }

                    //    if (!CarrerNameList.Contains(dr["Carrier"].ToString().Trim()))
                    //    {
                    //        CarrerNameList.Add(dr["Carrier"].ToString().Trim());
                    //        oWordDoc.Tables[4].Cell(k, 2).Range.Text = oWordDoc.Tables[4].Cell(k, 2).Range.Text + dr["Carrier"].ToString().Trim();
                    //    }
                    //    if (!PolicyNumberlist.Contains(dr["PolicyNumber"].ToString().Trim()))
                    //    {
                    //        PolicyNumberlist.Add(dr["PolicyNumber"].ToString().Trim().Trim());
                    //        oWordDoc.Tables[4].Cell(k, 3).Range.Text = oWordDoc.Tables[4].Cell(k, 3).Range.Text + dr["PolicyNumber"].ToString().Trim();
                    //    }
                    //    if (!effectiveList.Contains(dr["Effective"].ToString().Trim()))
                    //    {
                    //        effectiveList.Add(dr["Effective"].ToString());
                    //        oWordDoc.Tables[4].Cell(k, 4).Range.Text = oWordDoc.Tables[4].Cell(k, 4).Range.Text + dr["Effective"].ToString().Trim();
                    //    }
                    //    if (!RenewalList.Contains(dr["Renewal"].ToString().Trim()))
                    //    {
                    //        RenewalList.Add(dr["Renewal"].ToString().Trim());
                    //        oWordDoc.Tables[4].Cell(k, 5).Range.Text = oWordDoc.Tables[4].Cell(k, 5).Range.Text + dr["Renewal"].ToString().Trim();
                    //    }

                    //    //---------------------- Commented by Mandar Apate on 18 Nov 2014 ----------------------
                    //    //if (!Benefit_DescList.Contains(Benefit_Desc.Trim()))
                    //    //{
                    //    //    Benefit_DescList.Add(Benefit_Desc.Trim());
                    //    //    oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text + Benefit_Desc.Trim();
                    //    //}

                    //    //--------------------- Added new code by Mandar Apate on 18 Nov 2014 starts here ----------------------
                    //    if (!Benefit_DescList.Contains(Benefit_Desc.Trim()))
                    //    {
                    //        //  Benefit_DescList.Add(Benefit_Desc.Trim());
                    //        for (int i = 0; i < BenefitSummaryList.Count; i++)
                    //        {
                    //            if (!Benefit_DescList.Contains(BenefitSummaryList[i].BenefitDescription))
                    //            {
                    //                //oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text + Benefit_Desc.Trim();
                    //                oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 2).Range.Text + BenefitSummaryList[i].BenefitDescription;
                    //                Benefit_DescList.Add(BenefitSummaryList[i].BenefitDescription);
                    //            }
                    //        }
                    //    }
                    //    //--------------- Added new code by Mandar Apate on 18 Nov 2014 ends here ---------------------
                    //    if (!string.IsNullOrEmpty(contributionMethod))
                    //    {
                    //        if (!ContributionMethodList.Contains(contributionMethod))
                    //        {
                    //            ContributionMethodList.Add(contributionMethod);
                    //            oWordDoc.Tables[4].Cell(k + 1, 3).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 3).Range.Text + contributionMethod;
                    //        }
                    //    }
                    //    if (!FundingTypeList.Contains(FundingType))
                    //    {
                    //        FundingTypeList.Add(FundingType);
                    //        oWordDoc.Tables[4].Cell(k + 1, 4).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 4).Range.Text + FundingType;
                    //    }
                    //    if (!NumberOfEmpList.Contains(NoofELGEmployee))
                    //    {
                    //        NumberOfEmpList.Add(NoofELGEmployee);
                    //        oWordDoc.Tables[4].Cell(k + 1, 5).Range.Text = oWordDoc.Tables[4].Cell(k + 1, 5).Range.Text + NoofELGEmployee.ToString();
                    //    }
                    //}
                    rowCnt++;
                }
                #endregion

                #region Code for Merging the rows

                Color rowsColor_4 = Color.FromArgb(242, 242, 242);
                int rgb_Rows4 = ColorTranslator.ToOle(rowsColor_4);
                Word.WdColor wdColor_rows4 = (Word.WdColor)rgb_Rows4;

                // oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = textbox_color(color);

                int cnt = 5;
                for (int rowNum = 5; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    //oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = wdColor_rows4;
                    if (cnt <= rowNum)
                    {
                        oWordDoc.Tables[4].Rows[cnt].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        oWordDoc.Tables[4].Rows[cnt + 1].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        oWordDoc.Tables[4].Rows[cnt + 2].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        oWordDoc.Tables[4].Rows[cnt + 3].Range.Shading.BackgroundPatternColor = wdColor_rows4;
                        rowNum = rowNum + 7;
                        cnt = rowNum + 1;
                    }
                }

                int rowCntVar = oWordDoc.Tables[4].Rows.Count;
                /*For First Coloumn*/
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    // Check the remainder for the rownumber to merge
                    if (rowNum % 4 == 0)
                    {
                        oWordDoc.Tables[4].Cell(rowNum, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 1, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 2, 1));
                        oWordDoc.Tables[4].Cell(rowNum - 2, 1).Merge(oWordDoc.Tables[4].Cell(rowNum - 3, 1));
                    }
                }
                //int rowCntVar = oWordDoc.Tables[4].Rows.Count;



                for (int rowNum = 2; rowNum <= rowCntVar; rowNum++)
                {
                    // Check the remainder for the rownumber to merge


                    oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                    oWordDoc.Tables[4].Cell(rowNum, 3).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 3));
                    oWordDoc.Tables[4].Cell(rowNum, 4).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 4));
                    oWordDoc.Tables[4].Cell(rowNum, 5).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 5));

                    rowCntVar = oWordDoc.Tables[4].Rows.Count;
                }



                /*For Second Coloumn*/
                for (int rowNum = 1; rowNum <= rowCntVar; rowNum++)
                {
                    string strBenefitSummaryDescription = oWordDoc.Tables[4].Cell(rowNum, 2).Range.Text;
                    if (strBenefitSummaryDescription == "\r\a")
                    {
                        oWordDoc.Tables[4].Cell(rowNum, 2).Merge(oWordDoc.Tables[4].Cell(rowNum - 1, 2));

                    }

                }
                #endregion

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}