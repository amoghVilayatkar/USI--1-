﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class BPSummary
    {
        #region Variable
        private DataTable _office;
        private DataTable _officeState;
        private DataTable _officeCity;
        private DataTable _OfficeAddress;
        private DataTable _employee;
        private DataTable _plantype;
        private DataTable _carrierSpecific;
        private DataTable _plantypeSpecific;
        private DataTable _irc;
        private DataTable _benchmarkingGrp;
        #endregion
        #region Properties
        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public DataTable Office
        {
            get
            {
                return _office;
            }
            set
            {
                _office = value;
            }
        }

        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public DataTable OfficeState
        {
            get
            {
                return _officeState;
            }
            set
            {
                _officeState = value;
            }
        }

        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public DataTable OfficeCity
        {
            get
            {
                return _officeCity;
            }
            set
            {
                _officeCity = value;
            }
        }
        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public DataTable OfficeAddress
        {
            get
            {
                return _OfficeAddress;
            }
            set
            {
                _OfficeAddress = value;
            }
        }
        /// <summary>
        /// Get and Set IRC
        /// </summary>
        public DataTable IRC
        {
            get
            {
                return _irc;
            }
            set
            {
                _irc = value;
            }
        }
        /// <summary>
        /// Get and Set PlanType
        /// </summary>
        public DataTable PlanType
        {
            get
            {
                return _plantype;
            }
            set
            {
                _plantype = value;
            }
        }
        /// <summary>
        /// Get and Set CarrierSpecific
        /// </summary>
        public DataTable CarrierSpecific
        {
            get
            {
                return _carrierSpecific;
            }
            set
            {
                _carrierSpecific = value;

            }
        }
        /// <summary>
        /// Get and Set PlanTypeSpecific
        /// </summary>
        public DataTable PlanTypeSpecific
        {
            get
            {
                return _plantypeSpecific;
            }
            set
            {
                _plantypeSpecific = value;
            }
        }
        /// <summary>
        /// Get and Set Employee
        /// </summary>
        public DataTable Employee
        {
            get
            {
                return _employee;
            }
            set
            {
                _employee = value;
            }
        }
        /// <summary>
        /// Get and Set BenchmarkingGrp
        /// </summary>
        public DataTable BenchmarkingGrp
        {
            get
            {
                return _benchmarkingGrp;
            }
            set
            {
                _benchmarkingGrp = value;
            }
        }
        #endregion


    }
}