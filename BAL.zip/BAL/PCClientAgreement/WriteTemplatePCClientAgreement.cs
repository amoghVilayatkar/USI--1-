﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Diagnostics;
using System.Threading;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Core;

namespace BenefitPointSummaryPortal.BAL.PCClientAgreement
{
    public class WriteTemplatePCClientAgreement : System.Web.UI.Page
    {
        static Dictionary<string, Dictionary<string, string>> AllBookmarks = new Dictionary<string, Dictionary<string, string>>();
        BPBusiness bp = new BPBusiness();

        public void WriteFileds_ClientService_FeeOnly(Word.Document oWordDoc, Word.Application oWordApp, Word.Document oWordDocSource, Word.Application oWordAppSorce, string ClientName, string selectedState, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedEffectiveDate, string selectedLegalEntity, Dictionary<string, string> dictAgreementDetails, string selectedTermAgreement)
        {
            try
            {
                getBookMark();

                string FeeOnly_StateSpecificText = Convert.ToString(dictAgreementDetails["FeeOnly_StateSpecificText"]);
                string FeeOnly_StateSpecificTextMiscellaneous = Convert.ToString(dictAgreementDetails["FeeOnly_StateSpecificTextMiscellaneous"]);
                string FeeOnly = Convert.ToString(dictAgreementDetails["inputFeeOnly"]);
                //*******************Checking Fee Only No-Exception**************************//
                if (!string.IsNullOrEmpty(FeeOnly) && FeeOnly.ToLower() != "no - with exception")
                {
                    DeleteExceptionScentance(oWordDoc, "ExceptionScentance");

                }

                //*******************Fee Only State Specific Text **************************//
                if (!string.IsNullOrEmpty(FeeOnly_StateSpecificText) && FeeOnly_StateSpecificText.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "StateSpecoficText");
                }

                //**************************** HERE WE CHECK AND DISPLAY MESSAGE FORM State Specific Text for Section - 3 *****************
                string bookmarkSection3 = "Section3_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeOnly_StateSpecificText) && FeeOnly_StateSpecificText.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeOnlyBookmarkSection3"].ContainsKey(bookmarkSection3))
                    {
                        string bookMarkKey = AllBookmarks["FeeOnlyBookmarkSection3"][bookmarkSection3];
                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "StateSpecoficText");
                    }
                }
                else if (!string.IsNullOrEmpty(FeeOnly_StateSpecificText) && FeeOnly_StateSpecificText.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "StateSpecoficText");
                }

                //*********************************************//
                string bookmark = "SP06_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeOnly_StateSpecificTextMiscellaneous) && FeeOnly_StateSpecificTextMiscellaneous.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeOnlyBookmarkMiscellaneous"].ContainsKey(bookmark))
                    {
                        string bookMarkKey = AllBookmarks["FeeOnlyBookmarkMiscellaneous"][bookmark];

                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "MiscellaneousField");

                    }
                }
                else if (!string.IsNullOrEmpty(FeeOnly_StateSpecificTextMiscellaneous) && FeeOnly_StateSpecificTextMiscellaneous.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "MiscellaneousField");
                    DeleteIndivialBookmark(oWordDoc, "BlankSpace");
                }

            }
            catch (Exception)
            {
                //bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
                throw;
            }
        }

        public void WriteCommonValueOnTemplate(Word.Document oWordDoc, Word.Application oWordApp, Word.Document oWordDocSource, Word.Application oWordAppSorce, string ClientName, string selectedState, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedEffectiveDate, string selectedLegalEntity, string selctedlType, string selectedTermAgreement, string selectedBasisOfCompensation,string selectedLegalValue)
        {
            try
            {
                #region MergeField for Primary
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;
                    string LegalShortName=string.Empty;
                    if (selectedLegalValue == "USIInsuranceServicesLLC" || selectedLegalValue == "KibblePrenticeHolding" || selectedLegalValue == "USISouthwest")
                    {
                        LegalShortName = "USI";
                    }
                    else if (selectedLegalValue == "Safehold" || selectedLegalValue == "SafeholdCalifornia")
                    {
                        LegalShortName = "Safehold";

                    }
                    else if (selectedLegalValue == "Omni")
                    {
                        LegalShortName = "Omni";
                    }

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        myMergeField.Select();


                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ClientName))
                                oWordApp.Selection.TypeText(ClientName);
                            else
                                myMergeField.Delete();
                            continue;
                        }

                        if (fieldName.Contains("InsertLegalName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(selectedLegalEntity))
                                oWordApp.Selection.TypeText(selectedLegalEntity);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("FeeAmount"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(selectedFeeAmount))
                                oWordApp.Selection.TypeText(selectedFeeAmount);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("InvoiceSchedule"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(selectedlnvoiceSchedule))
                                oWordApp.Selection.TypeText(selectedlnvoiceSchedule);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("EffectiveDate"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(selectedEffectiveDate))
                                oWordApp.Selection.TypeText(selectedEffectiveDate);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("TermAgreement"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(selectedTermAgreement))
                                oWordApp.Selection.TypeText(selectedTermAgreement);
                            else
                                myMergeField.Delete();
                            continue;
                        }
                        if (fieldName.Contains("ExhibitsDate"))
                        {
                            string ExihibitDate = string.Empty;
                            DateTime EffectiveEDate = Convert.ToDateTime(selectedEffectiveDate);
                            ExihibitDate = EffectiveEDate.ToString("MM/dd/yyyy");
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ExihibitDate))
                                oWordApp.Selection.TypeText(ExihibitDate);
                            else
                                myMergeField.Delete();
                            continue;
                        }

                        
                        if (fieldName.Contains("LegalShortName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(LegalShortName))
                                oWordApp.Selection.TypeText(LegalShortName);
                            else
                                myMergeField.Delete();
                            continue;

                        }

                        //if (fieldName.Contains("Fee_Exhibits"))
                        //{

                        //    if (selctedlType == "ClientService" && selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeCommission")
                        //    {
                        //        decimal amount = Convert.ToDecimal(selectedFeeAmount);
                        //        if (amount < 50000)
                        //        {
                        //            myMergeField.Delete();
                        //            object missing = System.Type.Missing;
                        //            Word.Range r = oWordDoc.Range();
                        //            r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                        //            r.InsertBreak(Word.WdBreakType.wdPageBreak);
                        //            r.InsertFile(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/02-PC_FeeAddendum.docm"), missing, true, missing, missing);
                        //            continue;
                        //        }
                        //        else
                        //        {
                        //            myMergeField.Delete();
                        //        }
                        //    }
                        //    else
                        //    {
                        //        myMergeField.Delete();
                        //    }
                        //}

                        string DayOnly = string.Empty;
                        string MonthYear = string.Empty;

                        DateTime Date = Convert.ToDateTime(selectedEffectiveDate);
                        DayOnly = Date.ToString("dd");
                        MonthYear = Date.ToString("MMMM") + ", " + Date.ToString("yyyy");
                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ClientName);
                            continue;

                        }

                        if (fieldName.Contains("EffectiveDayOnly"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(DayOnly);
                            continue;

                        }

                        if (fieldName.Contains("MonthYearOnly"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MonthYear);
                            continue;

                        }

                    }
                }


                Write_DateInto_Footer(oWordDoc, oWordApp);
                #endregion

                if (selectedState == "North Carolina")
                {
                    oWordDoc.Bookmarks["NC_State"].Range.Bold = 1;
                }
            }
            catch (Exception)
            {
                throw;
                // bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFileds_ClientService_FeeCommission(Word.Document oWordDoc, Word.Application oWordApp, Word.Document oWordDocSource, Word.Application oWordAppSorce, string ClientName, string selectedState, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedEffectiveDate, string selectedLegalEntity, Dictionary<string, string> dictAgreementDetails, string selectedTermAgreement)
        {
            try
            {
                getBookMark();

                string FeeCommission_StateSpecificText = Convert.ToString(dictAgreementDetails["FeeCommission_StateSpecificText"]);
                string FeeCommission_StateSpecificTextMiscellaneous = Convert.ToString(dictAgreementDetails["FeeCommission_StateSpecificTextMiscellaneous"]);
                string FeeCommission = Convert.ToString(dictAgreementDetails["inputFeeCommission"]);
                //*******************Checking Fee Only No-Exception**************************//
                if (!string.IsNullOrEmpty(FeeCommission) && FeeCommission.ToLower() != "no - with exception")
                {
                    DeleteExceptionScentance(oWordDoc, "ExceptionScentance");

                }
                //**************************** HERE WE CHECK AND DISPLAY MESSAGE FORM State Specific Text for Section 3 *****************
                string bookmarkSection3 = "Section3_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeCommission_StateSpecificText) && FeeCommission_StateSpecificText.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeCommissionSpecificSection3"].ContainsKey(bookmarkSection3))
                    {
                        string bookMarkKey = AllBookmarks["FeeCommissionSpecificSection3"][bookmarkSection3];
                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "StateSpecoficText");
                    }
                }
                else if (!string.IsNullOrEmpty(FeeCommission_StateSpecificText) && FeeCommission_StateSpecificText.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "StateSpecoficText");
                }


                //**************************** HERE WE CHECK AND DISPLAY MESSAGE FORM Miscellaneous FILE *****************
                string bookmark = "SP06_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeCommission_StateSpecificTextMiscellaneous) && FeeCommission_StateSpecificTextMiscellaneous.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeCommissionMiscellaneous"].ContainsKey(bookmark))
                    {
                        string bookMarkKey = AllBookmarks["FeeCommissionMiscellaneous"][bookmark];
                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "MiscellaneousField");
                    }
                }
                else if (!string.IsNullOrEmpty(FeeCommission_StateSpecificTextMiscellaneous) && FeeCommission_StateSpecificTextMiscellaneous.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "MiscellaneousField");
                    DeleteIndivialBookmark(oWordDoc, "BlankSpace");
                }

            }
            catch (Exception)
            {
                throw;
                //bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(Word.Document oWordDoc, Word.Application oWordApp, Word.Document oWordDocSource, Word.Application oWordAppSorce, string ClientName, string selectedState, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedEffectiveDate, string selectedLegalEntity, Dictionary<string, string> dictAgreementDetails, string selectedTermAgreement)
        {
            try
            {
                getBookMark();

                string FeeOffsetby_Commission_StateSpecificText = Convert.ToString(dictAgreementDetails["FeeOffsetby_Commission_StateSpecificText"]);
                string FeeOffsetby_Commission_StateSpecificTextMiscellaneous = Convert.ToString(dictAgreementDetails["FeeOffsetby_Commission_StateSpecificTextMiscellaneous"]);
                string FeeOffsetby_Commission = Convert.ToString(dictAgreementDetails["inputFeeOffsetby_Commission"]);
                //*******************Checking Fee Only No-Exception**************************//
                if (!string.IsNullOrEmpty(FeeOffsetby_Commission) && FeeOffsetby_Commission.ToLower() != "no - with exception")
                {
                    DeleteExceptionScentance(oWordDoc, "ExceptionScentance");

                }
                //**************************** HERE WE CHECK AND DISPLAY MESSAGE FORM State Specific Text for Section 3 *****************
                string bookmarkSection3 = "Section3_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeOffsetby_Commission_StateSpecificText) && FeeOffsetby_Commission_StateSpecificText.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeOffsetByCommissionSpecificSection3"].ContainsKey(bookmarkSection3))
                    {
                        string bookMarkKey = AllBookmarks["FeeOffsetByCommissionSpecificSection3"][bookmarkSection3];
                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "StateSpecoficText");
                    }
                }
                else if (!string.IsNullOrEmpty(FeeOffsetby_Commission_StateSpecificText) && FeeOffsetby_Commission_StateSpecificText.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "StateSpecoficText");
                }

                //**************************** HERE WE CHECK AND DISPLAY MESSAGE FORM Miscellaneous FILE *****************
                string bookmark = "SP06_" + selectedState.Trim();
                if (!string.IsNullOrEmpty(FeeOffsetby_Commission_StateSpecificTextMiscellaneous) && FeeOffsetby_Commission_StateSpecificTextMiscellaneous.ToLower() == "yes")
                {
                    if (AllBookmarks["FeeOffsetByCommissionMiscellaneous"].ContainsKey(bookmark))
                    {
                        string bookMarkKey = AllBookmarks["FeeOffsetByCommissionMiscellaneous"][bookmark];
                        AddStateSpecificTextFromMiscellaneousFile(bookMarkKey, oWordDocSource, oWordDoc, "MiscellaneousField");
                    }
                }
                else if (!string.IsNullOrEmpty(FeeOffsetby_Commission_StateSpecificTextMiscellaneous) && FeeOffsetby_Commission_StateSpecificTextMiscellaneous.ToLower() == "no")
                {
                    DeleteIndivialBookmark(oWordDoc, "MiscellaneousField");
                    DeleteIndivialBookmark(oWordDoc, "BlankSpace");
                }
            }
            catch (Exception)
            {
                throw;
                //bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void AddStateSpecificTextFromMiscellaneousFile(string BookMarkKey, Word.Document oWordDocSource, Word.Document oWordDoc, string DestinationBookMark)
        {
            bool flag = false;
            //MiscellaneousField
            if (oWordDocSource.Bookmarks.Exists(BookMarkKey))
            {
                oWordDocSource.Bookmarks[BookMarkKey].Range.Copy();
                flag = true;
            }
            if (flag && oWordDoc.Bookmarks.Exists(DestinationBookMark))
            {
                //oWordDoc.Bookmarks[DestinationBookMark].Range.PasteAndFormat(Word.WdRecoveryType.wdFormatOriginalFormatting);
                oWordDoc.Bookmarks[DestinationBookMark].Range.Select();
                oWordDoc.Application.Selection.Range.PasteAndFormat(Word.WdRecoveryType.wdFormatOriginalFormatting);
            }
        }

        private void getBookMark()
        {
            AllBookmarks.Clear();

            // Dictonary for State Specific Text for Section 3 FEE ONLY 
            Dictionary<string, string> FeeOnlyBookmarkSection3 = new Dictionary<string, string>();
            FeeOnlyBookmarkSection3.Add("Section3_Rhode Island", "Section3_RI_TX_State");
            FeeOnlyBookmarkSection3.Add("Section3_New Jersey", "Section3_NJ");
            FeeOnlyBookmarkSection3.Add("Section3_Maine", "Section3_ME");
            FeeOnlyBookmarkSection3.Add("Section3_Texas", "Section3_TX_State");

            Dictionary<string, string> FeeOnlyBookmarkMiscellaneous = new Dictionary<string, string>();
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Alabama", "AL_DCState");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_District of Columbia", "AL_DCState");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Idaho", "ID_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Illinois", "IL_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Louisiana", "LA_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Nevada", "NV_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_New York", "NY_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_North Carolina", "NC_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_North Dakota", "ND_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Ohio", "OH_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Washington", "WA_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Wisconsin", "WI_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Arkansas", "AR_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Colorado", "CO_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Michigan", "MI_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Montana", "MT_State");
            FeeOnlyBookmarkMiscellaneous.Add("SP06_Utah", "UT_State");

            Dictionary<string, string> FeeCommissionMiscellaneous = new Dictionary<string, string>();
            FeeCommissionMiscellaneous.Add("SP06_District of Columbia", "AL_DCState");
            FeeCommissionMiscellaneous.Add("SP06_Idaho", "ID_State");
            FeeCommissionMiscellaneous.Add("SP06_Illinois", "IL_State");
            FeeCommissionMiscellaneous.Add("SP06_Nevada", "NV_State");
            FeeCommissionMiscellaneous.Add("SP06_North Carolina", "NC_State");
            FeeCommissionMiscellaneous.Add("SP06_Ohio", "OH_State");
            FeeCommissionMiscellaneous.Add("SP06_Washington", "WA_State");
            FeeCommissionMiscellaneous.Add("SP06_Wisconsin", "WI_State");
            FeeCommissionMiscellaneous.Add("SP06_New York", "NY_State");
            FeeCommissionMiscellaneous.Add("SP06_Alabama", "AL_DCState");
            FeeCommissionMiscellaneous.Add("SP06_Arkansas", "AR_State");
            FeeCommissionMiscellaneous.Add("SP06_Colorado", "CO_State");
            FeeCommissionMiscellaneous.Add("SP06_Utah", "UT_State");
            FeeCommissionMiscellaneous.Add("SP06_Michigan", "MI_State");

            Dictionary<string, string> FeeOffsetByCommissionMiscellaneous = new Dictionary<string, string>();
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Alabama", "AL_DCState");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Arkansas", "AR_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Colorado", "CO_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_District of Columbia", "AL_DCState");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Idaho", "ID_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Illinois", "IL_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Louisiana", "LA_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Michigan", "MI_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Montana", "MT_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Nevada", "NV_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_New York", "NY_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_North Carolina", "NC_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_North Dakota", "ND_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Utah", "UT_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Washington", "WA_State");
            FeeOffsetByCommissionMiscellaneous.Add("SP06_Wisconsin", "WI_State");

            // Dictonary for State Specific Text for Section 3
            Dictionary<string, string> FeeCommissionSpecificSection3 = new Dictionary<string, string>();
            FeeCommissionSpecificSection3.Add("Section3_Illinois", "Section3_FeeCommission_FeeOffsetBy");
            FeeCommissionSpecificSection3.Add("Section3_Alaska", "Section3_FeeCommission_FeeOffsetBy");
            FeeCommissionSpecificSection3.Add("Section3_New Jersey", "Section3_NJ");
            FeeCommissionSpecificSection3.Add("Section3_New Mexico", "Section3_NMOR_State");
            FeeCommissionSpecificSection3.Add("Section3_New York", "Section3_NY_State");
            FeeCommissionSpecificSection3.Add("Section3_Oregon", "Section3_NMOR_State");
            FeeCommissionSpecificSection3.Add("Section3_Rhode Island", "Section3_RI_TX_State");
            FeeCommissionSpecificSection3.Add("Section3_Texas", "Section3_TX_State");
            FeeCommissionSpecificSection3.Add("Section3_Utah", "Section3_FeeCommission_FeeOffsetBy");
            FeeCommissionSpecificSection3.Add("Section3_Maine", "Section3_ME");
            FeeCommissionSpecificSection3.Add("Section3_Georgia", "Section3_FeeCommission_FeeOffsetBy");

            Dictionary<string, string> FeeOffsetByCommissionSpecificSection3 = new Dictionary<string, string>();
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Alaska", "Section3_FeeCommission_FeeOffsetBy");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Georgia", "Section3_FeeCommission_FeeOffsetBy");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Illinois", "Section3_FeeCommission_FeeOffsetBy");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Indiana", "Section3_FeeCommission_FeeOffsetBy");
            // FeeOffsetByCommissionSpecificSection3.Add("Section3_Maine", "Section3_FeeCommission_FeeOffsetBy");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_New Jersey", "Section3_NJ");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_New Mexico", "Section3_NMOR_State");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_New York", "Section3_NY_State");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Oregon", "Section3_NMOR_State");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Rhode Island", "Section3_RI_TX_State");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Texas", "Section3_TX_State");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Utah", "Section3_FeeCommission_FeeOffsetBy");
            FeeOffsetByCommissionSpecificSection3.Add("Section3_Maine", "Section3_ME");


            AllBookmarks.Add("FeeOnlyBookmarkSection3", FeeOnlyBookmarkSection3);
            AllBookmarks.Add("FeeOnlyBookmarkMiscellaneous", FeeOnlyBookmarkMiscellaneous);
            AllBookmarks.Add("FeeCommissionMiscellaneous", FeeCommissionMiscellaneous);
            AllBookmarks.Add("FeeOffsetByCommissionMiscellaneous", FeeOffsetByCommissionMiscellaneous);
            //******  Dictonary for State Specific Text for Section 3
            AllBookmarks.Add("FeeCommissionSpecificSection3", FeeCommissionSpecificSection3);
            AllBookmarks.Add("FeeOffsetByCommissionSpecificSection3", FeeOffsetByCommissionSpecificSection3);
        }

        public void WriteFileds_OnSiteClientBusinessAssociate(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, string LegalEntity, string EffectiveDate)
        {
            #region MergeField
            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {

                Microsoft.Office.Interop.Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    string DayOnly = string.Empty;
                    string MonthYear = string.Empty;

                    DateTime Date = Convert.ToDateTime(EffectiveDate);
                    DayOnly = Date.ToString("dd");
                    MonthYear = Date.ToString("MMMM") + ", " + Date.ToString("yyyy");
                    if (fieldName.Contains("ClientName"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;

                    }

                    if (fieldName.Contains("DayOnly"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DayOnly);
                        continue;

                    }

                    if (fieldName.Contains("MonthYearOnly"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(MonthYear);
                        continue;

                    }

                    if (fieldName.Contains("USILegalEntity"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(LegalEntity);
                        continue;

                    }
                }
            }
            #endregion

            #region MergeField With Footer
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentDate"))
                            {
                                field.Select();
                                string FooterCurrentDate = System.DateTime.Now.ToString("MM/dd/yyyy");
                                if (!string.IsNullOrEmpty(FooterCurrentDate))
                                {
                                    oWordApp.Selection.TypeText(FooterCurrentDate);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }


                        }
                    }
                }
            }
            #endregion
        }

        /// <summary>
        /// Write_DateInto_Footer
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        private void Write_DateInto_Footer(Word.Document oWordDoc, Word.Application oWordApp)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentDate"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                                continue;
                            }
                        }
                    }
                }
            }
        }

        // Call if bookmark which are not present in "AllBookmarks"
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }

        public void DeleteExceptionScentance(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }
        public void DeleteUnwantedBookMark(Word.Document oWordDoc, Word.Application oWordApp, string ClientName, string selectedState, string selectedAdditionalServices, string selctedlType, string selectedBasisOfCompensation)
        {

            if (selectedState != "north carolina")
            {
                if (oWordDoc.Bookmarks.Exists("CSNorthCarolina"))
                {
                    oWordDoc.Bookmarks["CSNorthCarolina"].Range.Delete();
                }
            }

            if (selectedBasisOfCompensation != "FeeOnly" && selectedBasisOfCompensation != "FeeOnly*")
            {
                if (oWordDoc.Bookmarks.Exists("FeeCOMPENSATION"))
                {
                    oWordDoc.Bookmarks["FeeCOMPENSATION"].Range.Delete();
                }
            }

            if (selectedBasisOfCompensation != "FeeCommission" && selectedBasisOfCompensation != "FeeCommission*")
            {
                if (oWordDoc.Bookmarks.Exists("FeeCommissionCOMPENSATION"))
                {
                    oWordDoc.Bookmarks["FeeCommissionCOMPENSATION"].Range.Delete();
                }
            }

            if (selectedBasisOfCompensation != "FeeOffsetByCommission" && selectedBasisOfCompensation != "FeeOffsetByCommission*")
            {
                if (oWordDoc.Bookmarks.Exists("FeeOffsetCommissionCOMPENSATION"))
                {
                    oWordDoc.Bookmarks["FeeOffsetCommissionCOMPENSATION"].Range.Delete();
                }
            }

            // ADDITIONAL THIRD-PARTY SERVICES 
            if (selectedAdditionalServices != "YES")
            {
                if (oWordDoc.Bookmarks.Exists("ADDITIONALTHIRD_PARTY"))
                {
                    oWordDoc.Bookmarks["ADDITIONALTHIRD_PARTY"].Range.Delete();
                }
            }

            if (selectedState != "ohio")
            {
                if (oWordDoc.Bookmarks.Exists("TermTerminationForOH"))
                {
                    oWordDoc.Bookmarks["TermTerminationForOH"].Range.Delete();
                }
            }

            if (selectedState == "ohio") // IF State is OH than remove this selection 
            {
                if (oWordDoc.Bookmarks.Exists("TermTerminationWithOutOH"))
                {
                    oWordDoc.Bookmarks["TermTerminationWithOutOH"].Range.Delete();
                }
            }

            if (selectedState != "massachusetts")
            {
                if (oWordDoc.Bookmarks.Exists("MISCELLANEOUS"))
                {
                    oWordDoc.Bookmarks["MISCELLANEOUS"].Range.Delete();
                }
            }


            if (selectedState != "south carolina")
            {
                if (oWordDoc.Bookmarks.Exists("MISCELLANEOUSForSC"))
                {
                    oWordDoc.Bookmarks["MISCELLANEOUSForSC"].Range.Delete();
                }
            }

            if (selectedState == "south carolina" || selectedState == "massachusetts")
            {
                if (oWordDoc.Bookmarks.Exists("MISCELLANEOUFORALL"))
                {
                    oWordDoc.Bookmarks["MISCELLANEOUFORALL"].Range.Delete();
                }
            }

            if (selectedState != "nevada")
            {
                if (oWordDoc.Bookmarks.Exists("SELECTIONOFISSUING"))
                {
                    oWordDoc.Bookmarks["SELECTIONOFISSUING"].Range.Delete();
                }
            }



        }//Method Clsoe here

    }
}