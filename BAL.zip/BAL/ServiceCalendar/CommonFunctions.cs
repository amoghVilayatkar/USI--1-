﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.ServiceCalendar;

namespace BenefitPointSummaryPortal.BAL.ServiceCalendar
{
    public class CommonFunctions : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        //Reading the data from ServiceCalendar Detail Healthcare XML file and get the values from that file
        DataSet dsHealthcare = new DataSet();

        //Reading the data from ServiceCalendar Detail USI Holidays XML file and get the values from that file
        DataSet dsUSI_Holidays = new DataSet();

        //Reading the data from ServiceCalendar Detail Wellness XML file and get the values from that file
        DataSet dsWellness = new DataSet();

        DataSet customfield = new DataSet();

        //Reading the data from ServiceCalendar Compliance XML file and get the values from that file
        DataSet dsCompliance = new DataSet();

        //Reading the data from ServiceCalendar Compliance Funding Method XML file and get the values from that file
        DataSet dsFunding_Method = new DataSet();

        public CommonFunctions()
        {
            dsHealthcare.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Detail_Healthcare.xml"));
            dsUSI_Holidays.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Highlights_USI_Holidays.xml"));
            dsWellness.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Detail_Wellness.xml"));
            customfield.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Detail_Customfield.xml"));
            //dsCompliance.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Compliance.xml"));
            dsFunding_Method.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Compliance_FundingMethod.xml"));
        }

        /// <summary>
        /// Get the USI Holidays Topics for Service Calender Details
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="col">Table column number </param>
        /// <param name="row">Table row number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="USI_Holidays">USI_Holidays value to compare for whether it is "Included" or not</param>
        public void Get_USI_Holidays_Topic(int monthno, int col, int row, Word.Document oWordDoc, int USI_Holidays)
        {
            try
            {
                if (USI_Holidays == 1) // USI Holidays Included
                {
                    for (int k = 0; k < dsUSI_Holidays.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsUSI_Holidays.Tables[0].Rows[k][0]))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            // If cell length is > 2 then only merge the current text into existing text else write the current text directly
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsUSI_Holidays.Tables[0].Rows[k][1]);
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsUSI_Holidays.Tables[0].Rows[k][1]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Get the Custom Field Values for Service Calender Details
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="col">Table column number </param>
        /// <param name="row">Table row number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="Cust_Field">Cust_Field month number to compare with one of the renewal month</param>
        /// <param name="strCustField">Custom field value to write in one of the matched renewal month</param>
        public void Get_Custom_Field_Values(int monthNo, int col, int row, Word.Document oWordDoc, int Cust_Field, string strCustField)
        {
            try
            {
                if (monthNo == Cust_Field)
                {
                    if (!string.IsNullOrEmpty(strCustField))
                    {
                        oWordDoc.Tables[2].Cell(row, col).Select();

                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + strCustField;
                        }
                        else
                        {
                            // For applying bullets in a cell
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = strCustField;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Get the Wellness Topics for Service Calender Details
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="col">Table column number </param>
        /// <param name="row">Table row number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="Wellness">Wellness value to compare for whether it is "Included" or not</param>
        public void Get_Wellness_Topic(int monthno, int col, int row, Word.Document oWordDoc, int Wellness)
        {
            try
            {
                if (Wellness == 1) // Wellness Included
                {
                    for (int k = 0; k < dsWellness.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsWellness.Tables[0].Rows[k][0]))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsWellness.Tables[0].Rows[k][1]);
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsWellness.Tables[0].Rows[k][1]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Get the Healthcare Reform Topics for Service Calender Details
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="col">Table column number </param>
        /// <param name="row">Table row number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="Healthcare_Reform">Healthcare reform value to compare for whether it is "Included" or not</param>
        public void Get_Healthcare_Topic(int monthno, int col, int row, Word.Document oWordDoc, int Healthcare_Reform)
        {
            try
            {
                if (Healthcare_Reform == 1) // Healthcare Included
                {
                    for (int k = 0; k < dsHealthcare.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsHealthcare.Tables[0].Rows[k][0]))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsHealthcare.Tables[0].Rows[k][1]);
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsHealthcare.Tables[0].Rows[k][1]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Topics for Service Calender Details
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="col">Table column number </param>
        /// <param name="row">Table row number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="ActivityDS">Detaset used to compare the activity ids whith hashtable </param>
        public void Get_Topic_Basis_On_Month(int monthno, int col, int row, Word.Document oWordDoc, DataSet ActivityDS)
        {

            //Hashtable service_canender_detail = new Hashtable();
            ////service_canender_detail.Add("49101","Renewal Date");
            //service_canender_detail.Add("49102", "Discrimination Testing - New Plan Year");
            //service_canender_detail.Add("49103", "Review/Distribute Contracts & Booklets");
            //service_canender_detail.Add("49104", "Medicare Part D Filing");
            //service_canender_detail.Add("49105", "Begin 5500 Process");
            //service_canender_detail.Add("49106", "Wellness Assessment");
            //service_canender_detail.Add("49107", "Finalize 5500 Process");
            //service_canender_detail.Add("49108", "Distribute Summary Annual Report");
            //service_canender_detail.Add("49109", "Request Census");
            //service_canender_detail.Add("49110", "Medicare Part D Notices");
            //service_canender_detail.Add("49111", "Finalize Rates");
            //service_canender_detail.Add("49112", "Section 79");
            //service_canender_detail.Add("49113", "Enrollment Materials");
            //service_canender_detail.Add("49114", "Request/Review SBC");
            //service_canender_detail.Add("49115", "Distribute Annual Legal Notices");
            //service_canender_detail.Add("49116", "Discrimination Test - Current Year");
            //service_canender_detail.Add("49132", "Post Renewal Meeting");
            //service_canender_detail.Add("49133", "First Quarterly Meeting");
            //service_canender_detail.Add("49134", "Second Quarterly Meeting");
            //service_canender_detail.Add("49135", "Stewardship Meeting");
            //service_canender_detail.Add("49136", "Internal Strategy Meeting");
            //service_canender_detail.Add("49137", "Pre Renewal Meeting");
            //service_canender_detail.Add("49138", "Renewal Meeting");


            // ArrayList hash_key = new ArrayList(service_canender_detail.Keys);
            //  hash_key.Sort();
            //for (int rowcnt = 0; rowcnt < ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count; rowcnt++)
            //{

            //    foreach (var key in hash_key)
            //    {
            //        if (Convert.ToInt32(key) == Convert.ToInt32(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_CustomFieldId"]))
            //        {
            //            if (!string.IsNullOrEmpty(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_valueText"].ToString()))
            //            {
            //                if (monthno == Convert.ToDateTime(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_valueText"].ToString()).Month)
            //                {
            //                    oWordDoc.Tables[2].Cell(row, col).Select();

            //                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
            //                    {
            //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + service_canender_detail[key].ToString();
            //                    }
            //                    else
            //                    {
            //                        // For applying bullets in a cell 
            //                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
            //                        oWordDoc.Tables[2].Cell(row, col).Range.Text = service_canender_detail[key].ToString();
            //                    }
            //                    break;
            //                }

            //            }
            //        }

            //    }
            //}
            int outValue;

            try
            {
                for (int rowcnt = 0; rowcnt < ActivityDS.Tables["activityCustomFieldValues_table"].Rows.Count; rowcnt++)
                {
                    //foreach (var key in hash_key)
                    //{
                    //if (Convert.ToInt32(key) == Convert.ToInt32(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_CustomFieldId"]))
                    //{
                    for (int i = 0; i < customfield.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(customfield.Tables[0].Rows[i][0]) == Convert.ToInt32(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_CustomFieldId"]))
                        {

                            if (!string.IsNullOrEmpty(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_valueText"].ToString()))
                            {
                                if (monthno == Convert.ToDateTime(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["customFieldValues_valueText"].ToString()).Month)
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Select();
                                    bool isnum = Int32.TryParse(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().ElementAt(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf(')') - 1).ToString(), out outValue);
                                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                    {

                                        // if ( Convert.ToInt32(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().ElementAt(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf (')')-1).ToString())>=0)
                                        if (isnum == true)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = (oWordDoc.Tables[2].Cell(row, col).Range.Text + (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().Remove(0, ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf(')') + 1)).Trim()).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = (oWordDoc.Tables[2].Cell(row, col).Range.Text + (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString()).Trim()).Trim();
                                        }
                                    }
                                    else
                                    {
                                        //Int32.TryParse(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().ElementAt(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf(')') - 1).ToString(), out outValue);
                                        // For applying bullets in a cell 
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        //if (Convert.ToInt32(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().ElementAt(ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf(')') - 1).ToString()) >= 0)
                                        if (isnum == true)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().Remove(0, ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString().IndexOf(')') + 1)).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = (ActivityDS.Tables["activityCustomFieldValues_table"].Rows[rowcnt]["custom_field_lable"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Get_Compliance_Constant_Text
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="row_First_6_Month">Table row number</param>
        /// <param name="row_Next_6_Month">Table row number</param>

        public void Get_Compliance_Constant_Text(Word.Document oWordDoc, int row_First_6_Month, int row_Next_6_Month)
        {
            try
            {
                // Below are the code for superscripting the numbers
                // materials 1 : "\u00B9" 
                // materials 2 : "\u00B2" 
                // materials 3 : "\u00B3" 
                // materials 4 : "\u2074" 
                // materials 5 : "\u2075" 
                // materials 6 : "\u2076" 
                // materials 7 : "\u2077" 
                // materials 8 : "\u2078" 
                // materials 9 : "\u2079";

                // For first column static text
                oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Select();

                if (oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text.Length > 2)
                {
                    //oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text + "New MOOP and HSA-Related limits apply" + "\u00B3";
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text + "OOPMs & HSA/QHDHP Limits" + "\u00B2";
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text + "Consider 105(h) and 125 plan early discrimination testing";
                }
                else
                {
                    // For applying bullets in a cell
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.ListFormat.ApplyBulletDefault();
                    //oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = "New MOOP and HSA-Related limits apply" + "\u00B3";
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = "OOPMs & HSA/QHDHP Limits" + "\u00B2";
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 1).Range.Text + "Consider 105(h) and 125 plan early discrimination testing";
                }

                // For second column static text
                oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Select();

                if (oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Range.Text + "Consider issuing Medicare Part D Creditable Coverage participant notices";
                }
                else
                {
                    // For applying bullets in a cell
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(row_First_6_Month, 2).Range.Text = "Consider issuing Medicare Part D Creditable Coverage participant notices";
                }

                //// For third column static text
                //oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Select();

                //if (oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Range.Text.Length > 2)
                //{
                //    oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Range.Text = oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Range.Text + "Medicare Part D Creditable Coverage Notice due to CMS";
                //}
                //else
                //{
                //    // For applying bullets in a cell
                //    oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Range.ListFormat.ApplyBulletDefault();
                //    oWordDoc.Tables[2].Cell(row_First_6_Month, 3).Range.Text = "Medicare Part D Creditable Coverage Notice due to CMS";
                //}

                // For next 6 months - sisth column static text
                oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Select();

                if (oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text.Length > 2)
                {
                    oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + "Perform required 125 discrimination testing";
                    //oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + "Distribute annual legal notices with next year’s enrollment materials" + "\u2077";
                    oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + "Distribute annual legal notices with next year’s enrollment materials" + "\u2075";
                }
                else
                {
                    // For applying bullets in a cell
                    //string str = "Distribute annual legal notices with next year’s enrollment 
                    oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.ListFormat.ApplyBulletDefault();
                    oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = "Perform required 125 discrimination testing";
                    //oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + "Distribute annual legal notices with next year’s enrollment materials" + "\u2077";
                    oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + "Distribute annual legal notices with next year’s enrollment materials" + "\u2075";
                    //oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text = oWordDoc.Tables[2].Cell(row_Next_6_Month, 6).Range.Text + str; 

                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Renewal Method
        /*
        /// <summary>
        /// Get the Funding Method Topics for Service Calender Compliance
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="OptionFieldValueiD">OptionFieldValueiD value is used to check wheather the funding method is "Self Insured (52403)", "Fully Insured" or anything else</param>
        public void Get_Funding_Method_Topic(int monthno, int row, int col, Word.Document oWordDoc, int OptionFieldValueiD)
        {
            try
            {
                // 52403 : is for self insured
                if (OptionFieldValueiD == 52403) // If Self Insured
                {
                    for (int k = 0; k < dsFunding_Method.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsFunding_Method.Tables[0].Rows[k][0]))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            // If cell length is > 2 then only merge the current text into existing text else write the current text directly
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        */

        // Funding Method
        /*
        /// <summary>
        /// Get the Funding Method Topics for Service Calender Compliance
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="OptionFieldValueiD">OptionFieldValueiD value is used to check wheather the funding method is "Self Insured (52403)", "Fully Insured" or anything else</param>
        public void Get_Funding_Method_Topic(int monthno, int row, int col, Word.Document oWordDoc, int OptionFieldValueiD)
        {
            try
            {
                // 52403 : is for self insured
                if (OptionFieldValueiD == 52403) // If Self Insured
                {
                    for (int k = 0; k < dsFunding_Method.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsFunding_Method.Tables[0].Rows[k][0]))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            // If cell length is > 2 then only merge the current text into existing text else write the current text directly
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year – 1 year'"))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text.Replace("'Effective Date Year – 1 year'", "2015");
                                }
                                else if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year'"))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text.Replace("'Effective Date Year'", "2016");
                                }
                                else
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                }
                            }
                            else
                            {
                                if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year – 1 year'"))
                                {
                                    // For applying bullets in a cell
                                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text.Replace("'Effective Date Year – 1 year'", "2015");
                                }
                                else if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year'"))
                                {
                                    // For applying bullets in a cell
                                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text.Replace("'Effective Date Year'", "2016");
                                }
                                else
                                {
                                    // For applying bullets in a cell
                                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        */

        public string GetNextBusinessDay(DateTime d_date, out DateTime cal_date)
        {
            string month_text = string.Empty;

            // For Checking months Mid/Last day 
            // If the mid/last day of month is saturday then add 2 days in the current date
            if (d_date.DayOfWeek == DayOfWeek.Saturday)
            {
                d_date = d_date.AddDays(2);
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();

            }
            // If the mid/last day of month is sunday then add 1 day in the current date
            else if (d_date.DayOfWeek == DayOfWeek.Sunday)
            {
                d_date = d_date.AddDays(1);
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();
            }
            else
            {
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();
            }

            cal_date = d_date;

            return month_text;
        }

        // Function to get the previous busieness days
        public string GetPreviousBusinessDay(DateTime d_date, out DateTime cal_date)
        {
            string month_text = string.Empty;

            // For Checking months Mid/Last day 
            // If the mid/last day of month is saturday then add 2 days in the current date
            if (d_date.DayOfWeek == DayOfWeek.Saturday)
            {
                d_date = d_date.AddDays(-1);
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();
            }
            // If the mid/last day of month is sunday then add 1 day in the current date
            else if (d_date.DayOfWeek == DayOfWeek.Sunday)
            {
                d_date = d_date.AddDays(-2);
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();
            }
            else
            {
                month_text = d_date.Month.ToString() + "/" + d_date.Day.ToString();
            }

            cal_date = d_date;

            return month_text;
        }


        // Get the next Business working day for the US holiday
        // Use the below function for the given list of holidays
        //     (January)   1      •	New Year’s Day – January 1
        //     (January)   1      •	Martin Luther King Day – 3rd Monday in January
        //     (February)  2      •	Presidents Day – 3rd Monday in February
        //     (May)       5      •	Memorial Day – Last Monday in May
        //     (July)      7      •	Independence Day – July 4
        //     (September) 9      •	Labor Day – 1st Monday in September
        //     (November)  11     •	Thanksgiving Day – 4th Thursday in November
        //     (December)  12     •	Christmas Day – December 25 
        //
        //  	            Note:   If 12/25 is a Saturday the holiday will be Friday 12/24
        //                          If 12/25 is a Sunday, the holiday will be Monday 12/26

        public string GetNextBusinessDay_For_Holiday(Int32 Month, Int32 Year, DateTime d_date)
        {
            // Get the first date of the parametered month
            DateTime StartDate = Convert.ToDateTime(Month.ToString() + "/01/" + Year.ToString());
            // Calculate the number of days in the selected month and year
            Int32 iDays = DateTime.DaysInMonth(Year, Month);
            // Calculate the end date in the selected month and year
            DateTime EndDate = StartDate.AddDays(iDays - 1);
            Int32 WeekdayCount = 0;
            string strDate = string.Empty;
            DateTime cal_date;

            // Switch between different month as 
            switch (Month)
            {
                case 1:
                    // **********************************************************************************************************************
                    // The comnments written here is the same process in all the months used in switch case
                    // **********************************************************************************************************************
                    // First condition for if January 1st = startDate
                    if (d_date == StartDate)
                    {
                        // Add 1 day in the current startDate 
                        StartDate = StartDate.AddDays(1);
                        strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                        // If the new created date is Weekend (Saturday or Sunday) then calculate the next business working day by using the function GetNerxtBusinessDay
                        strDate = GetNextBusinessDay(StartDate, out cal_date);
                        return strDate;
                    }
                    // Second condition for other that 1st January date
                    else
                    {
                        // Check for if the StartDate is Monday or not
                        while (StartDate.DayOfWeek != DayOfWeek.Monday)
                        {
                            // If the StartDate is not Monday then add 1 day in the StartDate untill we will get the Monday
                            StartDate = StartDate.AddDays(1);
                        }

                        // Set the Counter to 1 (Means the first Monday of the month)
                        WeekdayCount = 1;

                        // Set the StartDate as StartDate + 7 Days
                        StartDate = StartDate.AddDays(7);

                        // Check for the StartDate untill the LastDay of the month
                        while (StartDate <= EndDate)
                        {
                            // Increment the week counter by 1
                            WeekdayCount += 1;

                            // Check for the the current week is 3rd week of the January month or not
                            if (WeekdayCount == 3)
                            {
                                // If the current week is the 3rd week of the January month then check for the d_date (provided in parameter) 
                                // with the newly created StartDate, if these dates match then add 1 day in the StartDate and obtain the next working day
                                if (d_date == StartDate)
                                {
                                    StartDate = StartDate.AddDays(1);
                                    strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                                }
                                else
                                {
                                    strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                                }
                                return strDate;
                            }
                            StartDate = StartDate.AddDays(7);
                        }
                    }
                    break;

                case 2:
                    while (StartDate.DayOfWeek != DayOfWeek.Monday)
                    {
                        StartDate = StartDate.AddDays(1);
                    }

                    WeekdayCount = 1;

                    StartDate = StartDate.AddDays(7);

                    while (StartDate <= EndDate)
                    {
                        WeekdayCount += 1;
                        if (WeekdayCount == 3)
                        {
                            if (d_date == StartDate)
                            {
                                StartDate = StartDate.AddDays(1);
                                strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                            }
                            else
                            {
                                strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                            }
                            return strDate;
                        }
                        StartDate = StartDate.AddDays(7);
                    }
                    break;

                case 5:
                    while (StartDate.DayOfWeek != DayOfWeek.Monday)
                    {
                        StartDate = StartDate.AddDays(1);
                    }

                    WeekdayCount = 1;

                    StartDate = StartDate.AddDays(7);

                    while (StartDate <= EndDate)
                    {
                        WeekdayCount += 1;
                        StartDate = StartDate.AddDays(7);

                        if (d_date == StartDate)
                        {
                            StartDate = StartDate.AddDays(1);
                            strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                        }
                        else
                        {
                            strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                        }
                    }

                    return strDate;
                    break;

                case 7:

                    // Calculate the Independence Day – July 4
                    DateTime d_Jul = Convert.ToDateTime("07/04/" + d_date.Year);

                    // Check if the d_date provided in paranmeter = Independace day (July 4), if yes then add 1 day in d_date
                    if (d_date == d_Jul)
                    {
                        d_date = d_date.AddDays(1);
                        strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                        // If the new created date is Weekend (Saturday or Sunday) then calculate the next business working day by using the function GetNerxtBusinessDay
                        strDate = GetNextBusinessDay(d_date, out cal_date);
                        return strDate;
                    }
                    break;

                case 9:
                    while (StartDate.DayOfWeek != DayOfWeek.Monday)
                    {
                        StartDate = StartDate.AddDays(1);
                    }

                    WeekdayCount = 1;

                    while (StartDate <= EndDate)
                    {
                        if (WeekdayCount == 1)
                        {
                            if (d_date == StartDate)
                            {
                                StartDate = StartDate.AddDays(1);
                                strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                            }
                            else
                            {
                                strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                            }
                        }
                        WeekdayCount += 1;
                        StartDate = StartDate.AddDays(7);
                    }
                    return strDate;
                    break;

                case 11:

                    // Check for the Thursday
                    while (StartDate.DayOfWeek != DayOfWeek.Thursday)
                    {
                        StartDate = StartDate.AddDays(1);
                    }

                    WeekdayCount = 1;

                    StartDate = StartDate.AddDays(7);

                    while (StartDate <= EndDate)
                    {
                        WeekdayCount += 1;

                        // Check for the 4th Thursday
                        if (WeekdayCount == 4)
                        {
                            if (d_date == StartDate)
                            {
                                StartDate = StartDate.AddDays(1);
                                strDate = StartDate.Month.ToString() + "/" + StartDate.Day.ToString();
                            }
                            else
                            {
                                strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                            }
                            return strDate;
                        }
                        StartDate = StartDate.AddDays(7);
                    }
                    break;

                case 12:

                    // Calculate the Christmas Day – December 25
                    DateTime d_Dec = Convert.ToDateTime("12/25/" + d_date.Year);

                    if (d_date == d_Dec)
                    {
                        // If 12/25 is a Saturday the holiday will be Friday 12/24
                        if (d_Dec.DayOfWeek == DayOfWeek.Saturday)
                        {
                            d_date = d_date.AddDays(-1);
                        }
                        // If 12/25 is a Sunday, the holiday will be Monday 12/26
                        else if (d_Dec.DayOfWeek == DayOfWeek.Sunday)
                        {
                            d_date = d_date.AddDays(1);
                        }
                        else
                        {
                            d_date = d_date.AddDays(1);
                        }
                        strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                        // If the new created date is Weekend (Saturday or Sunday) then calculate the next business working day by using the function GetNerxtBusinessDay
                        strDate = GetNextBusinessDay(d_date, out cal_date);
                        return strDate;
                    }

                    break;

                default:

                    strDate = d_date.Month.ToString() + "/" + d_date.Day.ToString();
                    return strDate;
            }

            return strDate;
        }

        /// <summary>
        /// Get the Funding Method Topics for Service Calender Compliance
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="OptionFieldValueiD">OptionFieldValueiD value is used to check wheather the funding method is "Self Insured (52403)", "Fully Insured" or anything else</param>
        public void Get_Funding_Method_Topic(int monthno, int row, int col, Word.Document oWordDoc, int OptionFieldValueiD, DateTime EffectiveDate, int EffectiveDateYear, string _HRA, int EffectiveDate_Month)
        {
            string Jan_text = string.Empty;
            string Nov_text = string.Empty;
            string Jul_text = string.Empty;
            string month_Text = string.Empty;
            // Added on 13 June 2016
            // Check for the mid day of January for the selected year
            string strdt_Jan_15 = "01/15/" + EffectiveDateYear;
            DateTime d_Jan_15 = Convert.ToDateTime(strdt_Jan_15);

            // Check for the mid day of November for the selected year
            string strdt_Nov_15 = "11/15/" + EffectiveDateYear;
            DateTime d_Nov_15 = Convert.ToDateTime(strdt_Nov_15);

            // Check for the last day of July for the selected year
            string strdt_Jul_15 = "07/31/" + EffectiveDateYear;
            DateTime d_Jul_15 = Convert.ToDateTime(strdt_Jul_15);

            string effe_Dt_year = string.Empty;
            string effe_Dt_Year_1 = string.Empty;
            DateTime cal_date;
            try
            {
                // 52403 : is for self insured
                if (OptionFieldValueiD == 52403) // If Self Insured
                {
                    Jan_text = GetNextBusinessDay(d_Jan_15, out cal_date);
                    Jan_text = GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    Nov_text = GetNextBusinessDay(d_Nov_15, out cal_date);
                    Nov_text = GetNextBusinessDay_For_Holiday(cal_date.Month, cal_date.Year, cal_date);
                    Jul_text = GetNextBusinessDay(d_Jul_15, out cal_date);

                    for (int k = 0; k < dsFunding_Method.Tables[0].Rows.Count; k++)
                    {
                        if (monthno == Convert.ToInt32(dsFunding_Method.Tables[0].Rows[k][0]))
                        {
                            if (monthno == 1)
                            {
                                month_Text = Jan_text;
                            }
                            else if (monthno == 7)
                            {
                                month_Text = Jul_text;
                            }
                            else if (monthno == 11)
                            {
                                month_Text = Nov_text;
                            }
                            oWordDoc.Tables[2].Cell(row, col).Select();

                            if ((monthno == 7 && _HRA == "Yes"))
                            {
                            }
                            else
                            {
                                effe_Dt_Year_1 = month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                effe_Dt_Year_1 = effe_Dt_Year_1.Replace("'Effective Date Year – 1 year'", Convert.ToString(EffectiveDate.Year - 1));

                                effe_Dt_year = month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                effe_Dt_year = effe_Dt_year.Replace("'Effective Date Year'", Convert.ToString(EffectiveDate.Year));
                                // If cell length is > 2 then only merge the current text into existing text else write the current text directly
                                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                {
                                    if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year – 1 year'"))
                                    {
                                        /*---Code is Commented by Amogh ---*/
                                        ////oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + effe_Dt_Year_1;
                                        /****************Added by Amogh ********************/
                                        /*-- For any date after November 2017, there should be no “11/15 – if applicable, pay 2nd installment of [year] reinsurance fee” As per Lisa*/
                                        if (EffectiveDate_Month <= 11 && EffectiveDateYear <= 2017)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + effe_Dt_Year_1;
                                        }
                                    }
                                    else if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year'"))
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + effe_Dt_year;
                                    }
                                    else
                                    {
                                        if (monthno == 7)
                                        {
                                            if (Jul_text.Substring(0, 1) == "7")
                                            {
                                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                            }
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                        }
                                    }
                                }
                                else
                                {
                                    if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year – 1 year'"))
                                    {
                                        // For applying bullets in a cell
                                        /*------ Code commneted by Amogh */
                                        ////oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        ////oWordDoc.Tables[2].Cell(row, col).Range.Text = effe_Dt_Year_1;

                                        /****************Added by Amogh ********************/
                                        /*-- For any date after November 2017, there should be no “11/15 – if applicable, pay 2nd installment of [year] reinsurance fee” As per Lisa*/
                                        if (EffectiveDate_Month <= 11 && EffectiveDateYear <= 2017)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = effe_Dt_Year_1;
                                        }
                                    }
                                    else if (Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]).Contains("'Effective Date Year'"))
                                    {
                                        // For applying bullets in a cell
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = effe_Dt_year;
                                    }
                                    else
                                    {
                                        // For applying bullets in a cell
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        if (monthno == 7)
                                        {
                                            if (Jul_text.Substring(0, 1) == "7")
                                            {
                                                oWordDoc.Tables[2].Cell(row, col).Range.Text = month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                            }
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col).Range.Text = month_Text + Convert.ToString(dsFunding_Method.Tables[0].Rows[k][1]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        /// <summary>
        /// Get the Renewal_Month_Topic for Service Calender Compliance
        /// </summary>
        /// <param name="monthno">Month number where to put the topic</param>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="_MEWA">Is this group a MWEA Yes/No</param>
        /// <param name="San_Francisco">Are any employees in San Francisco, CA? Yes/No</param>
        /// <param name="d_Feb">DateTime Object</param>
        /// <param name="ddlReportFormatCompliance_selectedindex">int ddlReportFormatCompliance_selectedindex is optional parameter by default it takes 0 For First Two Report Format and For last report it takes 3</param>

        bool isJanMonthWritten = false;
        bool isMarchMonthWritten = false;
        bool isJulyMonthWritten = false;
        bool isAugMonthWritten = false;
        bool isMEWA_Yes = false;
        bool isMEWA_No = false;
        bool isMass = false;
        bool isMass_No = false;
        string Jan_Text_Sat_Sun = string.Empty;
        string Jan_Text_For_Mass = string.Empty;
        string Mar_Text_Sat_Sun = string.Empty;
        string Feb_test_sat_sun = string.Empty;
        string Mar_test_sat_sun = string.Empty;
        string Jul_test_sat_sun = string.Empty;
        public void Get_Renewal_Month_Topic(int monthno, int row, int col, Word.Document oWordDoc, string _MEWA, string San_Francisco, DateTime d_Feb, DateTime dtOriginal_RenewalDate, string _HRA, int EffectiveYear, int OptionFieldValueiD, DropDownList ddlMassachusetts, int ddlReportFormatCompliance_selectedindex = 0)
        {
            DateTime cal_date;
            try
            {
                //if (ddlReportFormatCompliance_selectedindex == 2 || ddlReportFormatCompliance_selectedindex == 3)// For last Report in Report format Dropdown(Index=3) need to load ServiceCalendar_Compliance_6mo.xml files 
                //{
                dsCompliance.Clear();
                dsCompliance.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Compliance_6mo.xml"));
                //}
                //else // For First and Second Report int Report  format Dropdown(Index=1,and Index=2) need to load ServiceCalendar_Compliance.xml files 
                //{
                //    dsCompliance.Clear();
                //    dsCompliance.ReadXml(Server.MapPath("~/Common/ServiceCalendar/ServiceCalendar_Compliance.xml"));
                //}
                string Feb_text = "";
                string complianceText = string.Empty;

                // Check for the last day of January for the selected year
                string strdt_Jan = "01/31/" + EffectiveYear;
                DateTime d_Jan = Convert.ToDateTime(strdt_Jan);
                string Jan_Text = string.Empty;

                // Check for the First day of March for the selected year
                string strdt_Mar = "03/01/" + EffectiveYear;
                DateTime d_Mar = Convert.ToDateTime(strdt_Mar);
                string Mar_Text = string.Empty;
                bool isDistributeToEmpDone = false;
                string Massachusetts_Text = string.Empty;

                for (int k = 0; k < dsCompliance.Tables[0].Rows.Count; k++)
                {
                    if (monthno == Convert.ToInt32(dsCompliance.Tables[0].Rows[k][0]))
                    {
                        oWordDoc.Tables[2].Cell(row, col).Select();

                        complianceText = Convert.ToString(dsCompliance.Tables[0].Rows[k][1]);

                        if (complianceText.Substring(complianceText.Length - 1, 1) == "1")
                        {
                            complianceText = complianceText.Substring(0, complianceText.Length - 1) + "\u00B9";
                        }
                        else if (complianceText.Substring(complianceText.Length - 1, 1) == "2")
                        {
                            complianceText = complianceText.Substring(0, complianceText.Length - 1) + "\u00B2";
                        }
                        else if (complianceText.Substring(complianceText.Length - 1, 1) == "3")
                        {
                            complianceText = complianceText.Substring(0, complianceText.Length - 1) + "\u00B3";
                        }


                        if (monthno == 1)
                        {
                            if (k == 0 || k == 1)
                            { }
                            else if (monthno == 1 && ddlMassachusetts.SelectedItem.Text == "Yes" && isMass == false) // Month == 1 (Jan)
                            {
                                // If the last day of February month is saturday then add 2 days in the current date
                                if (d_Jan.DayOfWeek == DayOfWeek.Saturday)
                                {
                                    d_Jan = d_Jan.AddDays(2);
                                    Massachusetts_Text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                                    Jan_Text_For_Mass = Massachusetts_Text + complianceText;
                                }
                                // If the last day of February month is sunday then add 1 day in the current date
                                else if (d_Jan.DayOfWeek == DayOfWeek.Sunday)
                                {
                                    d_Jan = d_Jan.AddDays(1);
                                    Massachusetts_Text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                                    Jan_Text_For_Mass = Massachusetts_Text + complianceText;
                                }
                                else
                                {
                                    Massachusetts_Text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                                }

                                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                {
                                    if (string.IsNullOrEmpty(Jan_Text_For_Mass))
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Massachusetts_Text + complianceText;
                                    }
                                }
                                else
                                {
                                    if (string.IsNullOrEmpty(Jan_Text_For_Mass))
                                    {
                                        // For applying bullets in a cell
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = Massachusetts_Text + complianceText;
                                    }
                                }
                                isMass = true;
                            }

                            if (monthno == 1 && Convert.ToString(dsCompliance.Tables[0].Rows[k][1]).Substring(complianceText.Length - 1, 1) == "3")
                            {
                                //Jan_Text = GetNextBusinessDay(d_Jan, out cal_date);
                                Jan_Text = GetPreviousBusinessDay(d_Jan, out cal_date);
                                Jan_Text_Sat_Sun = Jan_Text + complianceText;

                                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                {
                                    if (Jan_Text.Substring(0, 1) == "1")
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_Text + complianceText;
                                        isJanMonthWritten = true;
                                    }
                                }
                                else
                                {
                                    // For applying bullets in a cell
                                    if (Jan_Text.Substring(0, 1) == "1")
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_Text + complianceText;
                                        isJanMonthWritten = true;
                                    }
                                }
                            }
                            else
                            {
                                if (isMass_No == true || isMass == true)
                                { }
                                else
                                {
                                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + complianceText;
                                    }
                                    else
                                    {
                                        // For applying bullets in a cell
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = complianceText;
                                    }

                                    if (monthno == 1 && ddlMassachusetts.SelectedItem.Text == "No" && isMass_No == false) // Month == 1 (Jan)
                                    {
                                        isMass_No = true;
                                    }
                                }
                            }


                        }

                        // For Checking February Last day
                        if (monthno == 2) // Month == 2 (February)
                        {
                            // If the last day of February month is saturday then add 2 days in the current date
                            if (d_Feb.DayOfWeek == DayOfWeek.Saturday)
                            {
                                d_Feb = d_Feb.AddDays(2);
                                Feb_text = d_Feb.Month.ToString() + "/" + d_Feb.Day.ToString();
                                Feb_test_sat_sun = Feb_text + complianceText;
                            }
                            // If the last day of February month is sunday then add 1 day in the current date
                            else if (d_Feb.DayOfWeek == DayOfWeek.Sunday)
                            {
                                d_Feb = d_Feb.AddDays(1);
                                Feb_text = d_Feb.Month.ToString() + "/" + d_Feb.Day.ToString();
                                Feb_test_sat_sun = Feb_text + complianceText;
                            }
                            else
                            {
                                Feb_text = d_Feb.Month.ToString() + "/" + d_Feb.Day.ToString();
                            }

                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                if (string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Feb_text + complianceText;
                                }
                                if (!string.IsNullOrEmpty(Jan_Text_For_Mass))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_Text_For_Mass;
                                }
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                if (string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Feb_text + complianceText;
                                }

                                if (!string.IsNullOrEmpty(Jan_Text_For_Mass) && string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_Text_For_Mass;
                                }
                                else if (!string.IsNullOrEmpty(Jan_Text_For_Mass) && !string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_Text_For_Mass;
                                }
                            }
                        }

                        if (monthno == 3 && _MEWA == "Yes" && isMEWA_Yes == false) // Month == 3 (March)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + complianceText;
                                if (!string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Feb_test_sat_sun;
                                }
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = complianceText;

                                if (!string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Feb_test_sat_sun;
                                }
                            }
                            isMEWA_Yes = true;
                        }
                        else if (monthno == 3 && _MEWA == "No" && isMEWA_No == false) //If MEWA=No and date in Feb(2 month) is 28 or 29 
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                if (!string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Feb_test_sat_sun;
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(Feb_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Feb_test_sat_sun;
                                }
                            }
                            isMEWA_No = true;
                        }
                        else if (monthno == 3)
                        {
                            // Check for the last day of March for the selected year
                            string strdt_Mar_15 = "03/31/" + EffectiveYear;
                            DateTime d_Mar_15 = Convert.ToDateTime(strdt_Mar_15);
                            string Mar_text = string.Empty;
                            Mar_text = GetNextBusinessDay(d_Mar_15, out cal_date);
                            Mar_test_sat_sun = Mar_text + complianceText;
                            bool weekDayFlag = false;

                            //Check if 31 March is Weekend 
                            if (d_Mar_15.DayOfWeek == DayOfWeek.Saturday || d_Mar_15.DayOfWeek == DayOfWeek.Sunday)
                            {
                                weekDayFlag = true;
                            }

                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                if (Mar_text.Substring(0, 1) == "3")
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Mar_test_sat_sun;
                                    isMarchMonthWritten = true;
                                }
                                else if (Mar_text.Substring(0, 1) == "4" && weekDayFlag) // 31 March is Weekend so we need to display above message inside 4 month 
                                {
                                    if (col <= 5)
                                    {
                                        if (oWordDoc.Tables[2].Cell(row, col + 1).Range.Text.Length > 2)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.Text = oWordDoc.Tables[2].Cell(row, col + 1).Range.Text + Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.ListFormat.ApplyBulletDefault();
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.Text = Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                    }
                                    else if (col == 6)
                                    {
                                        if (oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text.Length > 2)
                                        {
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text = oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text + Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.ListFormat.ApplyBulletDefault();
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text = Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                // For applying bullets in a cell
                                if (Mar_text.Substring(0, 1) == "3")
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = Mar_test_sat_sun;
                                    isMarchMonthWritten = true;
                                }
                                else if (Mar_text.Substring(0, 1) == "4" && weekDayFlag) // 31 March is Weekend so we need to display above message inside 4 month 
                                {
                                    if (col <= 5)
                                    {
                                        if (oWordDoc.Tables[2].Cell(row, col + 1).Range.Text.Length > 2)
                                        {
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.Text = oWordDoc.Tables[2].Cell(row, col + 1).Range.Text + Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.ListFormat.ApplyBulletDefault();
                                            oWordDoc.Tables[2].Cell(row, col + 1).Range.Text = Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }

                                    }
                                    else if (col == 6)
                                    {
                                        if (oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text.Length > 2)
                                        {
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text = oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text + Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.ListFormat.ApplyBulletDefault();
                                            oWordDoc.Tables[2].Cell(row + 4, 1).Range.Text = Mar_test_sat_sun;
                                            isMarchMonthWritten = true;
                                        }

                                    }
                                }
                            }

                            #region Old Logic Commented by Amogh as per Nicole - Compliance Calendar - Duplicate tasks [Tue 3/5/2019 9:48 PM]
                            ////if (isDistributeToEmpDone == false)
                            ////{
                            ////    Mar_Text = GetNextBusinessDay(d_Mar, out cal_date);
                            ////    Mar_Text_Sat_Sun = Mar_Text + complianceText;

                            ////    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            ////    {
                            ////        if (Mar_Text.Substring(0, 1) == "3")
                            ////        {
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Mar_Text + complianceText;
                            ////            isJanMonthWritten = true;
                            ////        }
                            ////    }
                            ////    else
                            ////    {
                            ////        // For applying bullets in a cell
                            ////        if (Mar_Text.Substring(0, 1) == "3")
                            ////        {
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = Mar_Text + complianceText;
                            ////            isJanMonthWritten = true;
                            ////        }
                            ////    }
                            ////    isDistributeToEmpDone = true;
                            ////}
                            ////else
                            ////{
                            ////    // Check for the last day of March for the selected year
                            ////    string strdt_Mar_15 = "03/31/" + EffectiveYear;
                            ////    DateTime d_Mar_15 = Convert.ToDateTime(strdt_Mar_15);
                            ////    string Mar_text = string.Empty;
                            ////    Mar_text = GetNextBusinessDay(d_Mar_15, out cal_date);
                            ////    Mar_test_sat_sun = Mar_text + complianceText;

                            ////    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            ////    {
                            ////        if (Mar_text.Substring(0, 1) == "3")
                            ////        {
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Mar_test_sat_sun;
                            ////            isMarchMonthWritten = true;
                            ////        }
                            ////    }
                            ////    else
                            ////    {
                            ////        // For applying bullets in a cell
                            ////        if (Mar_text.Substring(0, 1) == "3")
                            ////        {
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            ////            oWordDoc.Tables[2].Cell(row, col).Range.Text = Mar_test_sat_sun;
                            ////            isMarchMonthWritten = true;
                            ////        }
                            ////    }
                            ////}
                            #endregion
                        }
                        if (monthno == 4 && San_Francisco == "Yes") // Month == 4 (April)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + complianceText;
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = complianceText;
                            }
                        }
                        else if (monthno == 4 && isMarchMonthWritten == false)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                if (!string.IsNullOrEmpty(Mar_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Mar_test_sat_sun;
                                }
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                if (!string.IsNullOrEmpty(Mar_test_sat_sun))
                                {
                                    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Mar_test_sat_sun;
                                }
                            }
                        }

                        if (monthno == 7) // Month == 7 (July)
                        {
                            // Check for the last day of July for the selected year
                            string strdt_Jul_15 = "07/31/" + EffectiveYear;
                            DateTime d_Jul_15 = Convert.ToDateTime(strdt_Jul_15);
                            string Jul_text = string.Empty;
                            Jul_text = GetNextBusinessDay(d_Jul_15, out cal_date);
                            Jul_test_sat_sun = Jul_text + complianceText;

                            if (_HRA == "Yes")
                            {
                                //Jul_text = GetNextBusinessDay(d_Jul_15, out cal_date);
                                //Jul_test_sat_sun = Jul_text + complianceText;

                                if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                                {
                                    if (Jul_text.Substring(0, 1) == "7")
                                    {
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jul_text + complianceText;
                                        isJulyMonthWritten = true;
                                    }
                                }
                                else
                                {
                                    if (Jul_text.Substring(0, 1) == "7")
                                    {
                                        // For applying bullets in a cell
                                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                        oWordDoc.Tables[2].Cell(row, col).Range.Text = Jul_text + complianceText;
                                        isJulyMonthWritten = true;
                                    }
                                }
                            }
                            else if (_HRA == "No" && OptionFieldValueiD != 52403) // If Self Insured
                            {
                                isJulyMonthWritten = true;
                            }
                        }

                        // If cell length is > 2 then only merge the current text into existing text else write the current text directly
                        if (monthno != 1 && monthno != 3 && monthno != 4 && monthno != 2 && monthno != 7)
                        {
                            if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + complianceText;
                            }
                            else
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = complianceText;
                            }
                        }
                    }
                }

                if (isJanMonthWritten == false)
                {
                    if (monthno == 2) // Month == 2 (February)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jan_Text_Sat_Sun) && (Jan_Text_Sat_Sun.Substring(0, 1) == "2"))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_Text_Sat_Sun;
                            }
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(Jan_Text_Sat_Sun) && (Jan_Text_Sat_Sun.Substring(0, 1) == "2"))
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_Text_Sat_Sun;
                            }
                        }
                        isJanMonthWritten = true;
                    }
                }

                if (isAugMonthWritten == false && isJulyMonthWritten == false)
                {
                    if (monthno == 8) // Month == 8 (August)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jul_test_sat_sun) && (Jul_test_sat_sun.Substring(0, 1) == "8"))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jul_test_sat_sun;
                            }
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(Jul_test_sat_sun) && (Jul_test_sat_sun.Substring(0, 1) == "8"))
                            {
                                // For applying bullets in a cell
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Jul_test_sat_sun;
                            }
                        }
                        isAugMonthWritten = true;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /*
        /// <summary>
        /// Get the Full_Time_Employees_Topic
        /// </summary>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="d_Jan">DateTime Object</param>
        /// <param name="Num_Of_FTE">Number of Full Time Employees</param>
        string Jan_text_31_gt50 = string.Empty;
        string Jan_text_31_lt50 = string.Empty;
        public void Get_Full_Time_Employees_Topic(int monthno, int row, int col, Word.Document oWordDoc, DateTime d_Jan, int Num_Of_FTE)
        {
            try
            {


                string Jan_text = "";

                oWordDoc.Tables[2].Cell(row, col).Select();

                // For Checking January Last day 
                // If the last day of January month is saturday then add 2 days in the current date
                if (d_Jan.DayOfWeek == DayOfWeek.Saturday)
                {
                    d_Jan = d_Jan.AddDays(2);
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                    Jan_text_31_gt50 = Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                    Jan_text_31_lt50 = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";

                }
                // If the last day of January month is sunday then add 1 day in the current date
                else if (d_Jan.DayOfWeek == DayOfWeek.Sunday)
                {
                    d_Jan = d_Jan.AddDays(1);
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                    Jan_text_31_gt50 = Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                    Jan_text_31_lt50 = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                }
                else
                {
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                }

                // If Num_Of_FTE >= 50 then the following condition
                if (Num_Of_FTE >= 50)
                {
                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "Employer penalty effective";

                        if (string.IsNullOrEmpty(Jan_text_31_gt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                        }
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "Employer penalty effective";
                        if (string.IsNullOrEmpty(Jan_text_31_gt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                        }
                    }
                }
                // else If Num_Of_FTE < 50 then the following condition
                else if (Num_Of_FTE < 50)
                {
                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    {
                        if (string.IsNullOrEmpty(Jan_text_31_lt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                        }
                    }
                    else
                    {
                        // For applying bullets in a cell
                        if (string.IsNullOrEmpty(Jan_text_31_lt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                        }
                    }
                }

                if (monthno == 2)
                {
                    // If Num_Of_FTE >= 50 then the following condition
                    if (Num_Of_FTE >= 50)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jan_text_31_gt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50;
                            }
                        }
                        else
                        {
                            // For applying bullets in a cell
                            if (!string.IsNullOrEmpty(Jan_text_31_gt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();

                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50;
                            }
                        }
                    }
                    // else If Num_Of_FTE < 50 then the following condition
                    else if (Num_Of_FTE < 50)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jan_text_31_lt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_lt50;
                            }
                        }
                        else
                        {
                            // For applying bullets in a cell
                            if (!string.IsNullOrEmpty(Jan_text_31_lt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text_31_lt50;
                            }
                        }
                    }



                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        */

        public bool If_Weekend_Or_Holiday(DateTime d_date)
        {
            bool isWeekend_Or_Holiday = false;

            // If the last day of month is saturday then add 2 days in the current date
            if (d_date.DayOfWeek == DayOfWeek.Saturday)
            {
                isWeekend_Or_Holiday = true;
            }
            // If the last day of month is sunday then add 1 day in the current date
            else if (d_date.DayOfWeek == DayOfWeek.Sunday)
            {
                isWeekend_Or_Holiday = true;
            }

            return isWeekend_Or_Holiday;
        }

        /// <summary>
        /// Get the Full_Time_Employees_Topic
        /// </summary>
        /// <param name="row">Table row number </param>
        /// <param name="col">Table column number </param>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="d_Jan">DateTime Object</param>
        /// <param name="Num_Of_FTE">Number of Full Time Employees</param>
        string Jan_text_31_gt50_SI = string.Empty;
        string Jan_text_31_gt50_FI = string.Empty;
        public void Get_Full_Time_Employees_Topic(int monthno, int row, int col, Word.Document oWordDoc, DateTime d_Jan, int Num_Of_FTE, int OptionFieldValueiD)
        {
            try
            {
                string Jan_text = "";
                string gt_50_SI = " - Distribute Form 1095-C to each ACA FTE and each covered primary insured";
                string gt_50_FI = " - Distribute Form 1095-C to each ACA FTE";

                oWordDoc.Tables[2].Cell(row, col).Select();

                // For Checking January Last day 
                // If the last day of January month is saturday then add 2 days in the current date
                if (d_Jan.DayOfWeek == DayOfWeek.Saturday)
                {
                    d_Jan = d_Jan.AddDays(2);
                    //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                }
                // If the last day of January month is sunday then add 1 day in the current date
                else if (d_Jan.DayOfWeek == DayOfWeek.Sunday)
                {
                    d_Jan = d_Jan.AddDays(1);
                    //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                }
                else
                {
                    //Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                }

                Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                Jan_text_31_gt50_SI = Jan_text + gt_50_SI;
                Jan_text_31_gt50_FI = Jan_text + gt_50_FI;

                // 52403 : is for self insured
                // If Num_Of_FTE >= 50 then the following condition
                if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52403)
                {
                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50_SI;
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text_31_gt50_SI;
                    }
                }
                // 52401 : is for Fully insured
                // If Num_Of_FTE >= 50 then the following condition
                else if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52401)
                {
                    ///************************************** -- Old Code Start Commented by Amogh *******************----*/
                    //if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    //{
                    //    oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50_FI;
                    //}
                    //else
                    //{
                    //    // For applying bullets in a cell
                    //    oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                    //    oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text_31_gt50_FI;
                    //}
                    ///************************************** -- Old Code End Commented by Amogh *******************----*/
                }

                //if (monthno == 2)
                //{
                //    // If Num_Of_FTE >= 50 then the following condition
                //    if (Num_Of_FTE >= 50 && OptionFieldValueiD == 52403)
                //    {
                //        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                //        {
                //            if (!string.IsNullOrEmpty(Jan_text_31_gt50_SI))
                //            {
                //                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50_SI;
                //            }
                //        }
                //        else
                //        {
                //            // For applying bullets in a cell
                //            if (!string.IsNullOrEmpty(Jan_text_31_gt50_SI))
                //            {
                //                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();

                //                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50_SI;
                //            }
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /*
        string Jan_text_31_gt50 = string.Empty;
        string Jan_text_31_lt50 = string.Empty;
        public void Get_Full_Time_Employees_Topic(int monthno, int row, int col, Word.Document oWordDoc, DateTime d_Jan, int Num_Of_FTE)
        {
            try
            {
                string Jan_text = "";

                oWordDoc.Tables[2].Cell(row, col).Select();

                // For Checking January Last day 
                // If the last day of January month is saturday then add 2 days in the current date
                if (d_Jan.DayOfWeek == DayOfWeek.Saturday)
                {
                    d_Jan = d_Jan.AddDays(2);
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                    Jan_text_31_gt50 = Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                    Jan_text_31_lt50 = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";

                }
                // If the last day of January month is sunday then add 1 day in the current date
                else if (d_Jan.DayOfWeek == DayOfWeek.Sunday)
                {
                    d_Jan = d_Jan.AddDays(1);
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                    Jan_text_31_gt50 = Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                    Jan_text_31_lt50 = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                }
                else
                {
                    Jan_text = d_Jan.Month.ToString() + "/" + d_Jan.Day.ToString();
                }

                // If Num_Of_FTE >= 50 then the following condition
                if (Num_Of_FTE >= 50)
                {
                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    {
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + "Employer penalty effective";

                        if (string.IsNullOrEmpty(Jan_text_31_gt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                        }
                    }
                    else
                    {
                        // For applying bullets in a cell
                        oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                        oWordDoc.Tables[2].Cell(row, col).Range.Text = "Employer penalty effective";
                        if (string.IsNullOrEmpty(Jan_text_31_gt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-C due to employees under 6055/6056 reporting";
                        }
                    }
                }
                // else If Num_Of_FTE < 50 then the following condition
                else if (Num_Of_FTE < 50)
                {
                    if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                    {
                        if (string.IsNullOrEmpty(Jan_text_31_lt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                        }
                    }
                    else
                    {
                        // For applying bullets in a cell
                        if (string.IsNullOrEmpty(Jan_text_31_lt50))
                        {
                            oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                            oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text + "-Forms 1095-B due to employees under 6055/6056 reporting";
                        }
                    }
                }

                if (monthno == 2)
                {
                    // If Num_Of_FTE >= 50 then the following condition
                    if (Num_Of_FTE >= 50)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jan_text_31_gt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50;
                            }
                        }
                        else
                        {
                            // For applying bullets in a cell
                            if (!string.IsNullOrEmpty(Jan_text_31_gt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();

                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_gt50;
                            }
                        }
                    }
                    // else If Num_Of_FTE < 50 then the following condition
                    else if (Num_Of_FTE < 50)
                    {
                        if (oWordDoc.Tables[2].Cell(row, col).Range.Text.Length > 2)
                        {
                            if (!string.IsNullOrEmpty(Jan_text_31_lt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = oWordDoc.Tables[2].Cell(row, col).Range.Text + Jan_text_31_lt50;
                            }
                        }
                        else
                        {
                            // For applying bullets in a cell
                            if (!string.IsNullOrEmpty(Jan_text_31_lt50))
                            {
                                oWordDoc.Tables[2].Cell(row, col).Range.ListFormat.ApplyBulletDefault();
                                oWordDoc.Tables[2].Cell(row, col).Range.Text = Jan_text_31_lt50;
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        */

        /// <summary>
        /// Write_DateInto_Footer
        /// </summary>
        /// <param name="oWordDoc">Object Of Word Document</param>
        /// <param name="oWordApp">Object Of Word Application </param>
        public void Write_DateInto_Footer(Word.Document oWordDoc, Word.Application oWordApp)
        {
            //Code For writing fields in Footer or  Header section  in Word Docs
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CURRENT DATE"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.ToShortDateString());
                                continue;
                            }

                            if (fieldName.Contains("CURRENT YEAR"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.Year.ToString());
                                continue;
                            }
                        }
                    }
                }
            }
        }

        public void Write_Field_Values_On_Template(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlClient, DateTime EffectiveDate)
        {
            int iTotalFields = 0;
            try
            {
                #region MergeField

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Client Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                            continue;
                        }

                        if (fieldName.Contains("Plan Effective Date Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText((EffectiveDate.ToString("M").Replace(" 0", " ").ToString() + ", " + EffectiveDate.Year.ToString()).Trim());
                            //oWordApp.Selection.TypeText(EffectiveDate.ToString());
                            continue;
                        }
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}