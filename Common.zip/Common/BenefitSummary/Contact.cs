﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class Contact
    { 
        #region Variable
        private int _contactId;
        private string _name;
        private string _address;
        private List<string> _phone;
        private string _postion;
        private string _title;
        private string _email;
        private string _responsibility;
        private string _lastName;
        private string _firstName;

        //Added for Account Plan / View  Page
        private bool _PrimaryFlag;
        

         #endregion
        #region Properties
        /// <summary>
        /// Get and Set ContactId
        /// </summary>
        public int ContactId
        {
            get
            {
                return _contactId;
            }
            set
            {
                _contactId = value;
            }
        }
        /// <summary>
        /// Get and Set ContactName
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name= value;
            }
        }
        /// <summary>
        /// Get and Set ContactAddress
        /// </summary>
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        /// <summary>
        /// Get and Set ContactPhone
        /// </summary>
        public List <string> Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }
        /// <summary>
        /// Get and Set ContactPosition
        /// </summary>
        public string Postion
        {
            get
            {
                return _postion;
            }
            set
            {
                _postion = value;
            }
        }
        /// <summary>
        /// Get and Set ContactTitle
        /// </summary>
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }
        /// <summary>
        /// Get and Set ContactEmail
        /// </summary>
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }
        /// <summary>
        /// Get and Set ContactResponsibility
        /// </summary>
        public string Responsibility
        {
            get
            {
                return _responsibility;
            }
            set
            {
                _responsibility = value;
            }
        }

        /// <summary>
        /// Get and Set First Name
        /// </summary>
        public string First_Name
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        /// <summary>
        /// Get and Set Last tName
        /// </summary>
        public string Last_Name
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

        /// <summary>
        /// Get and Set PrimaryFlag
        /// </summary>
        public bool PrimaryFlag
        {
            get
            {
                return _PrimaryFlag;
            }
            set
            {
                _PrimaryFlag = value;
            }
        } 
         #endregion
    }

    public class Wf_Contact
    {
        #region Variable
        private int _contactId;
        private string _name;
        private string _address;
        private List<string> _phone;
        private string _postion;
        private string _title;
        private string _email;
        private string _responsibility;
        private string _lastName;
        private string _firstName;

        private bool _PrimaryFlag;
        #endregion
        #region Properties
        /// <summary>
        /// Get and Set ContactId
        /// </summary>
        public int ContactId
        {
            get
            {
                return _contactId;
            }
            set
            {
                _contactId = value;
            }
        }
        /// <summary>
        /// Get and Set ContactName
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        /// <summary>
        /// Get and Set ContactAddress
        /// </summary>
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        /// <summary>
        /// Get and Set ContactPhone
        /// </summary>
        public List<string> Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }
        /// <summary>
        /// Get and Set ContactPosition
        /// </summary>
        public string Postion
        {
            get
            {
                return _postion;
            }
            set
            {
                _postion = value;
            }
        }
        /// <summary>
        /// Get and Set ContactTitle
        /// </summary>
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }
        /// <summary>
        /// Get and Set ContactEmail
        /// </summary>
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }
        /// <summary>
        /// Get and Set ContactResponsibility
        /// </summary>
        public string Responsibility
        {
            get
            {
                return _responsibility;
            }
            set
            {
                _responsibility = value;
            }
        }

        /// <summary>
        /// Get and Set First Name
        /// </summary>
        public string First_Name
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        /// <summary>
        /// Get and Set Last tName
        /// </summary>
        public string Last_Name
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
        /// <summary>
        /// Get and Set PrimaryFlag
        /// </summary>
        public bool PrimaryFlag
        {
            get
            {
                return _PrimaryFlag;
            }
            set
            {
                _PrimaryFlag = value;
            }
        } 
        #endregion
    }
}