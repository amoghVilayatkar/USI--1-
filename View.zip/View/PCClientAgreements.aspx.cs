﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office.Core;
using System.Threading;
using BenefitPointSummaryPortal.BAL.PCClientAgreement;


namespace BenefitPointSummaryPortal.View
{
    public partial class PCClientAgreements : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        //string temperror = "cs";

        private static string Activity = "P&C Client Agreement";
        private static string Activity_Group = "Compliance";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        private string userState = string.Empty;
        private string State = string.Empty;
        
        DataTable dbAgreeementMatrix = new DataTable();

        string FeeOnly_StateSpecificText = "";
        string FeeOnly_StateSpecificTextMiscellaneous = "";

        string FeeCommission_StateSpecificText = "";
        string FeeCommission_StateSpecificTextMiscellaneous = "";

        string FeeOffsetby_Commission_StateSpecificText = "";
        string FeeOffsetby_Commission_StateSpecificTextMiscellaneous = "";



        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        List<string> lstInvoiceSchedule = new List<string>() { "Monthly", "Quarterly", "Yearly" };
        Dictionary<string, string> dictBasisOfCompensation = new Dictionary<string, string>();
        Dictionary<string, string> dictAgreementDetails = new Dictionary<string, string>();
        protected void Page_Load(object sender, EventArgs e)
        {
            div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
            ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>LoadDate();</Script>", false);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "KeyClient", "<script>hideShowbutton();</Script>", false);
            Session["Summary"] = "P&C Client Agreement";
            if (!IsPostBack)
            {
                try
                {
                    txtClientLeagalName.Focus();
                    ResetControl(0);
                    objCommFun.GetUserDetails();
                    DictDepartment = sd.getDepartmentDetails();
                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    //if (Request.QueryString["ReportName"] != null)
                    //{
                    //    Session["Summary"] = Request.QueryString["ReportName"];
                    //}
                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;

                    //if (Convert.ToString(Session["Summary"]) == "ClientAgreement")
                    //{
                    //    TitleSpan.InnerText = "Client Agreements";
                    //    Activity_Group = "Compliance";
                    //    Activity = "Client Agreements";
                    //    ddlClientProspect.SelectedValue = "Select";
                    //    ddlClientProspect_OnSelectedIndexChanged(null, null);
                    //}
                    BindState();
                }
                catch (Exception ex)
                {
                    bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                    Response.Redirect("~/view/ErrorNotification.aspx");
                }
              
            }
        }

        #region  Events On Page

        #region Button Summery Click
        string _selectedClient = string.Empty;
        string _selectedType = string.Empty;
        string _selectedState = string.Empty;
        string _selectedBasisOfCompensation = string.Empty;
        string _selectedLegalEntity = string.Empty;
        string _selectedEffectiveDate = string.Empty;
        string _selectedTermAgreement = string.Empty;
        string _selectedFeeAmount = string.Empty;
        string _selectedlnvoiceSchedule = string.Empty;
        string _selectedAdditionalServices = string.Empty;
      
        string mynewfile = "";
        string _Value = string.Empty;



        protected void btnSummary_Click(object sender, EventArgs e)
        {
            _selectedState = ddlState.SelectedValue.Trim();
            _selectedBasisOfCompensation = ddlBasisOfCompensation.SelectedValue;
            _selectedState = ddlState.SelectedValue.Trim();
            try
            {

                if (ValidateForm())
                {
                    CreateClientAgreementsReport();
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ResetControl(1);
               // rdlClient.SelectedIndex = 0;
                //txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();
                SessionId = Session["SessionId"].ToString();
                //ddlClient.Items.Clear();
               // ddlClient.Items.Insert(0, new ListItem("Select", ""));
               // rdlClient.SelectedIndex = 0;
                ddlState.Items.Clear();
                ddlType.SelectedIndex = 0;
                hideShowAdditionalSection(ddlType.SelectedValue.Trim());
                ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlLegalEntity.SelectedIndex = 0;
            ddlType.SelectedIndex = 0;
            txtEffectiveDate.Text = string.Empty;
            ddlType_OnSelectedIndexChanged(null, null);
            ddlTermAgreement.SelectedIndex = 0;
            //ClearControl();
            //hideShowAdditionalSection(ddlType.SelectedValue.Trim());
            //FillBasicOfCommissionDropDown();
        }

        /******CODE ADDED BY AMOGH */
        protected void ddlType_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ClearControl();
            hideShowAdditionalSection(ddlType.SelectedValue.Trim());
            FillBasicOfCommissionDropDown();

        }


        protected void ddlBasisOfCompensation_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            hideShowAdditionalSectionControl(ddlType.SelectedValue.Trim(), ddlBasisOfCompensation.SelectedValue.Trim());
        }

        #endregion

        //Clear control 
        private void ClearControl()
        {
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;


            //ddlClientProspect.SelectedValue = "Select";
            //ddlClientProspect_OnSelectedIndexChanged(null, null);
            //trBasisOfCompensationException.Visible = false;

        }
        private void ClearAllControl()
        {
            txtClientLeagalName.Text = "";
           // txtsearch.Text = "";
            //ddlClient.Items.Clear();
            ddlState.SelectedIndex = 0;
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;
            txtEffectiveDate.Text = "";
            ddlType.SelectedIndex = 0;
            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;
        }

        private void ResetControl(int value)
        {
            txtEffectiveDate.Text = string.Empty;
            ddlBasisOfCompensation.Items.Clear();
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
            trBasisOfCompensation.Visible = false;
           // ddlClientProspect.SelectedValue = "Select";
            //ddlClientProspect_OnSelectedIndexChanged(null, null);
            //trBasisOfCompensationException.Visible = false;
        }

        private void LoadInvoiceSchedule()
        {
            ddlnvoiceSchedule.DataSource = lstInvoiceSchedule;
            ddlnvoiceSchedule.DataBind();
            ddlnvoiceSchedule.Items.Insert(0, new ListItem("Select", ""));
            ddlnvoiceSchedule.SelectedIndex = 0;
        }

        /// <summary>
        /// HIDE SHOW THE FEE AMOUNT / INVOICE SCHEDULE / ADDITTION SERVICES 
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="BasisOfCompensation"></param>
        private void hideShowAdditionalSectionControl(string Type, string BasisOfCompensation)
        {
            //trAdditionalOptions.Style.Add("display", "none");
            if (Type == "ClientService" || Type == "RiskAgreement" || Type == "ClientServiceRiskAgreement")
            {
                ClearControlForBasisOfCompensation();
                switch (BasisOfCompensation)
                {
                    case "FeeOnly":
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = true;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        LoadInvoiceSchedule();
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeCommission":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOffsetByCommission":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOnly*":
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = true;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        LoadInvoiceSchedule();
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeCommission*":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = true;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "FeeOffsetByCommission*":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    case "Select":
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = true;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Show')</script>", false);
                        break;
                    default:
                        ddlnvoiceSchedule.Items.Clear();
                        trFeeAmount.Visible = false;
                        trInvoiceSchedule.Visible = false;
                        trIncludeAdditionalServices.Visible = false;
                        //trBasisOfCompensationException.Visible = false;
                        ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>hideShowbutton('Hide')</script>", false);
                        break;
                }
            }
        }

        private void hideShowAdditionalSection(string Type)
        {
            trAdditionalOptions.Style.Add("display", "none");
            switch (Type)
            {
                
                case "ClientService":
                    trBasisOfCompensation.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "RiskAgreement":
                    trBasisOfCompensation.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "ClientServiceRiskAgreement":
                    trBasisOfCompensation.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                default:
                    trBasisOfCompensation.Visible = false;
                    trFeeAmount.Visible = false;
                    trInvoiceSchedule.Visible = false;
                    trIncludeAdditionalServices.Visible = false;
                    trAdditionalOptions.Style.Add("display", "none");
                    break;

            }
        }

        private void BindState()
        {
            //USI State
            DataTable dtOfficeState = new DataTable();
            dtOfficeState = bp.StateListforPCClientAgreement();
            ddlState.DataSource = dtOfficeState;
            ddlState.DataBind();

        }

        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void FillBasicOfCommissionDropDown()
        {
            try
            {
                string inputFeeOnly = "";
                string inputFeeCommission = "";
                string inputFeeOffsetby_Commission = "";
                DataSet DS_AgreementMatrix = new DataSet();
                string userState = Convert.ToString(ddlState.SelectedItem.Text);

                if (!string.IsNullOrEmpty(userState))
                {
                    dbAgreeementMatrix = bp.SP_loadClientAgreementMatrix(userState);
                    DS_AgreementMatrix.Tables.Add(dbAgreeementMatrix.Copy());
                }

                if (DS_AgreementMatrix.Tables.Count > 0)
                {
                    for (int i = 0; i < DS_AgreementMatrix.Tables[0].Rows.Count; i++)
                    {
                        ddlBasisOfCompensation.Items.Clear();
                        //dictAgreementDetails.Clear();

                        inputFeeOnly = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly"]).ToLower();
                        inputFeeCommission = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission"]).ToLower();
                        inputFeeOffsetby_Commission = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission"]).ToLower();

                        FeeOnly_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly_StateSpecificText"]).ToLower();
                        FeeOnly_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOnly_StateSpecificTextMiscellaneous"]).ToLower();

                        FeeCommission_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission_StateSpecificText"]).ToLower();
                        FeeCommission_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeCommission_StateSpecificTextMiscellaneous"]).ToLower();

                        FeeOffsetby_Commission_StateSpecificText = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission_StateSpecificText"]).ToLower();
                        FeeOffsetby_Commission_StateSpecificTextMiscellaneous = Convert.ToString(DS_AgreementMatrix.Tables[0].Rows[i]["FeeOffsetby_Commission_StateSpecificTextMiscellaneous"]).ToLower();

                        dictAgreementDetails.Add("inputFeeOnly", inputFeeOnly);
                        dictAgreementDetails.Add("FeeOnly_StateSpecificText", FeeOnly_StateSpecificText);
                        dictAgreementDetails.Add("FeeOnly_StateSpecificTextMiscellaneous", FeeOnly_StateSpecificTextMiscellaneous);

                        dictAgreementDetails.Add("inputFeeCommission", inputFeeCommission);
                        dictAgreementDetails.Add("FeeCommission_StateSpecificText", FeeCommission_StateSpecificText);
                        dictAgreementDetails.Add("FeeCommission_StateSpecificTextMiscellaneous", FeeCommission_StateSpecificTextMiscellaneous);

                        dictAgreementDetails.Add("inputFeeOffsetby_Commission", inputFeeOffsetby_Commission);
                        dictAgreementDetails.Add("FeeOffsetby_Commission_StateSpecificText", FeeOffsetby_Commission_StateSpecificText);
                        dictAgreementDetails.Add("FeeOffsetby_Commission_StateSpecificTextMiscellaneous", FeeOffsetby_Commission_StateSpecificTextMiscellaneous);

                        Session["dictAgreementDetails"] = dictAgreementDetails;
                        //// HERE WE CHECK FEE OPTION AVIALBEL FOR SPECIFIC STATE  -  Fee Only
                        if (!string.IsNullOrEmpty(inputFeeOnly) && inputFeeOnly != "no")
                        {
                            if (inputFeeOnly == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeOnly", "Fee Only");
                            }
                            else if (inputFeeOnly == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeOnly*", "Fee Only*");
                            }
                        }

                        //// HERE WE CHECK  "Fee and Commission" OPTION AVIALBEL FOR SPECIFIC STATE  -   "Fee and Commission"
                        if (!string.IsNullOrEmpty(inputFeeCommission) && inputFeeCommission != "no")
                        {
                            if (inputFeeCommission == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeCommission", "Fee and Commission");
                            }
                            else if (inputFeeCommission == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeCommission*", "Fee and Commission*");
                            }
                        }

                        //// HERE WE CHECK  "Fee and Commission" OPTION AVIALBEL FOR SPECIFIC STATE  -   "Fee and Commission"
                        if (!string.IsNullOrEmpty(inputFeeOffsetby_Commission) && inputFeeOffsetby_Commission != "no")
                        {
                            if (inputFeeOffsetby_Commission == "yes")
                            {
                                dictBasisOfCompensation.Add("FeeOffsetByCommission", "Fee Offset By Commission");
                            }
                            else if (inputFeeOffsetby_Commission == "no - with exception")
                            {
                                dictBasisOfCompensation.Add("FeeOffsetByCommission*", "Fee Offset By Commission*");
                            }
                        }
                    }

                    ddlBasisOfCompensation.DataTextField = "Value";
                    ddlBasisOfCompensation.DataValueField = "Key";
                    ddlBasisOfCompensation.DataSource = dictBasisOfCompensation;
                    ddlBasisOfCompensation.DataBind();

                    ddlBasisOfCompensation.Items.Insert(0, new ListItem("--Select--", "Select"));
                    ddlBasisOfCompensation.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {

            }
        }

        //Clear control 
        private void ClearControlForBasisOfCompensation()
        {
            ddlnvoiceSchedule.Items.Clear();
            ddlAdditionalServices.SelectedIndex = 0;
            txtFeeAmount.Text = string.Empty;

            trFeeAmount.Visible = false;
            trInvoiceSchedule.Visible = false;
            trIncludeAdditionalServices.Visible = false;
        }

        private string ClientService(string selectedClient, string selectedState, string selectedBasisOfCompensation, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedLegalEntity, string selectedEffectiveDate,string selectedTermAgreement)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/01-PC_ClientServiceAgreement.docm");
            Object fileNameSource = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/03-04-PC_StateSpecific_Miscellaneous_BrokerFeeText.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dictAgreementDetails = (Dictionary<string, string>)Session["dictAgreementDetails"];//= dictAgreementDetails;

                string selectedType = ddlType.SelectedValue;
                WriteTemplatePCClientAgreement wrt = new WriteTemplatePCClientAgreement();

                if (selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeOnly*")
                {
                    wrt.WriteFileds_ClientService_FeeOnly(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeCommission" || selectedBasisOfCompensation == "FeeCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeCommission(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeOffsetByCommission" || selectedBasisOfCompensation == "FeeOffsetByCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, selectedType, selectedTermAgreement, selectedBasisOfCompensation,ddlLegalEntity.SelectedValue);


                wrt.DeleteUnwantedBookMark(oWordDoc, oWordApp1, selectedClient, Convert.ToString(selectedState).ToLower(), selectedAdditionalServices, selectedType, selectedBasisOfCompensation);

                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }

            return (savefilename.ToString());

        }
        private string RiskAgreement(string selectedClient, string selectedState, string selectedBasisOfCompensation, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedLegalEntity, string selectedEffectiveDate, string selectedTermAgreement)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/02-PC_RiskManagement.docm");
            Object fileNameSource = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/03-04-PC_StateSpecific_Miscellaneous_BrokerFeeText.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dictAgreementDetails = (Dictionary<string, string>)Session["dictAgreementDetails"];//= dictAgreementDetails;

                string selectedType = ddlType.SelectedValue;
                WriteTemplatePCClientAgreement wrt = new WriteTemplatePCClientAgreement();


                if (selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeOnly*")
                {
                    wrt.WriteFileds_ClientService_FeeOnly(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeCommission" || selectedBasisOfCompensation == "FeeCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeCommission(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeOffsetByCommission" || selectedBasisOfCompensation == "FeeOffsetByCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, selectedType, selectedTermAgreement, selectedBasisOfCompensation, ddlLegalEntity.SelectedValue);
                wrt.DeleteUnwantedBookMark(oWordDoc, oWordApp1, selectedClient, Convert.ToString(selectedState).ToLower(), selectedAdditionalServices, selectedType, selectedBasisOfCompensation);

                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }

            return (savefilename.ToString());

        }
        private string ClientServiceRiskAgreement(string selectedClient, string selectedState, string selectedBasisOfCompensation, string selectedAdditionalServices, string selectedFeeAmount, string selectedlnvoiceSchedule, string selectedLegalEntity, string selectedEffectiveDate, string selectedTermAgreement)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp1 = new Word.Application();
            Word.Application oWordApp2 = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/05-PC_ClientServiceRiskAgreement.docm");
            Object fileNameSource = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/03-04-PC_StateSpecific_Miscellaneous_BrokerFeeText.docm");

            Object readOnly = true;
            Object isVisible = false;

            Word.Document oWordDoc = oWordApp1.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            Word.Document oWordDoc1 = oWordApp2.Documents.Open(ref fileNameSource,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp1.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/PCClientAgreement/Documents/Templates/Downloads"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dictAgreementDetails = (Dictionary<string, string>)Session["dictAgreementDetails"];//= dictAgreementDetails;

                string selectedType = ddlType.SelectedValue;
                WriteTemplatePCClientAgreement wrt = new WriteTemplatePCClientAgreement();


                if (selectedBasisOfCompensation == "FeeOnly" || selectedBasisOfCompensation == "FeeOnly*")
                {
                    wrt.WriteFileds_ClientService_FeeOnly(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeCommission" || selectedBasisOfCompensation == "FeeCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeCommission(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                else if (selectedBasisOfCompensation == "FeeOffsetByCommission" || selectedBasisOfCompensation == "FeeOffsetByCommission*")
                {
                    wrt.WriteFileds_ClientService_FeeOffsetByCommissionMiscellaneous(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, dictAgreementDetails, selectedTermAgreement);
                }
                wrt.WriteCommonValueOnTemplate(oWordDoc, oWordApp1, oWordDoc1, oWordApp2, selectedClient, selectedState, selectedAdditionalServices, selectedFeeAmount, selectedlnvoiceSchedule, selectedEffectiveDate, selectedLegalEntity, selectedType, selectedTermAgreement, selectedBasisOfCompensation, ddlLegalEntity.SelectedValue);
                wrt.DeleteUnwantedBookMark(oWordDoc, oWordApp1, selectedClient, Convert.ToString(selectedState).ToLower(), selectedAdditionalServices, selectedType, selectedBasisOfCompensation);

                oWordDoc.Save();

                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp1 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    // oWordApp1.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp1).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp1);
                    oWordApp1 = null;
                }

                if (oWordApp2 != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc1).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc1);

                    oWordDoc1 = null;
                    //oWordApp2.Quit(ref missing, ref missing, ref missing);
                    ((Microsoft.Office.Interop.Word._Application)oWordApp2).Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp2);
                    oWordApp2 = null;
                }
            }

            return (savefilename.ToString());

        }
        private bool ValidateForm()
        {
            var pattern = @"^[0-9]{1,3}(,[0-9]{3})*(\.[0-9]+)?$";
            var pattern2 = @"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$";
            var regexp = new System.Text.RegularExpressions.Regex(pattern);
            var regexp2 = new System.Text.RegularExpressions.Regex(pattern2);
            var userInput = txtFeeAmount.Text.Trim();

            if (txtClientLeagalName.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please fill Client Leagal Name.')</script>");
                    txtClientLeagalName.Focus();
                    return false;

                }

                if (ddlState.SelectedIndex == -1 || ddlState.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select State.')</script>");
                    ddlState.Focus();
                    return false;

                }

                if (txtEffectiveDate.Text.Trim() == string.Empty)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Effective Date.')</script>");
                    txtEffectiveDate.Focus();
                    return false;
                }

                if (ddlType.SelectedIndex == -1 || ddlType.SelectedIndex == 0)
                {
                    Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Type.')</script>");
                    ddlType.Focus();
                    return false;
                }
                if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeOnly*" || _selectedBasisOfCompensation == "FeeCommission*")
                {
                    if (!regexp2.IsMatch(userInput))
                    {
                        if (!regexp.IsMatch(userInput))
                        {
                            Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please enter valid Fee amount')</script>");
                            return false;
                        }
                    }
                }

           
            return true;
        }

        private void CreateClientAgreementsReport()
        {

            if (Convert.ToString(Session["Summary"]) == "P&C Client Agreement")
            {
                _selectedType = ddlType.SelectedValue.Trim();
                _selectedState = ddlState.SelectedValue.Trim();
                _selectedLegalEntity = ddlLegalEntity.SelectedItem.Text.Trim();
                _selectedEffectiveDate = txtEffectiveDate.Text.Trim();
                _selectedTermAgreement = ddlTermAgreement.SelectedItem.Text.Trim();

                _selectedClient = txtClientLeagalName.Text.Trim();

               
                if (_selectedType == "ClientService")
                {

                    _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                    if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                        _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                    }
                    else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                    }
                    mynewfile = ClientService(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate, _selectedTermAgreement);
                }
                else if (_selectedType == "RiskAgreement")
                {
                    _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                    if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                        _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                    }
                    else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                    }
                    mynewfile = RiskAgreement(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate, _selectedTermAgreement);
                }
                else if (_selectedType == "ClientServiceRiskAgreement")
                {
                    _selectedAdditionalServices = ddlAdditionalServices.SelectedValue.Trim();

                    if (_selectedBasisOfCompensation == "FeeOnly" || _selectedBasisOfCompensation == "FeeOnly*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                        _selectedlnvoiceSchedule = ddlnvoiceSchedule.SelectedItem.Text.Trim();
                    }
                    else if (_selectedBasisOfCompensation == "FeeCommission" || _selectedBasisOfCompensation == "FeeCommission*")
                    {
                        _Value = txtFeeAmount.Text.Trim();
                        _selectedFeeAmount = string.Format("{0:#,0.00}", double.Parse(_Value));
                    }
                    mynewfile = ClientServiceRiskAgreement(_selectedClient, _selectedState, _selectedBasisOfCompensation, _selectedAdditionalServices, _selectedFeeAmount, _selectedlnvoiceSchedule, _selectedLegalEntity, _selectedEffectiveDate, _selectedTermAgreement);
                }



                //    #endregion


                #region Storing the Activity Logs
                string AdditionalCrtieriaOption_1 = ddlState.SelectedItem.Text.Trim();
                string AdditionalCrtieriaOption_2 = ddlLegalEntity.SelectedItem.Text.Trim();
                string AdditionalCrtieriaOption_3 = ddlType.SelectedItem.Text.Trim();
                string AdditionalCrtieriaOption_4 = string.Empty;
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(txtClientLeagalName.Text), Convert.ToString(Session["UserLoginName"]), 0, Account_Region, Account_Office, "Compliance", "", "", "", "", "", Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                DownloadFileNew(mynewfile);
            }


        }
        

       
    }
}