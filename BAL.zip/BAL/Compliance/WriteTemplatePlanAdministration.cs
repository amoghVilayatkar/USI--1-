﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;
using System.Data;
using System.IO;

namespace BenefitPointSummaryPortal.BAL.Compliance
{
    public class WriteTemplatePlanAdministration
    {
        internal void WriteCommonFields(Word.Document oWordDoc, Word.Application oWordApp, string ClientName)
        {
            int iTotalFields = 0;

            #region MergeField

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Client Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }
                }
            }
             #endregion

            #region Merge field for footer
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.Year.ToString());
                                continue;
                            }
                        }
                    }
                }
            }

            #endregion
        }
    }
}