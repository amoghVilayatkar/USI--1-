﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using System.IO;

using System.Runtime.InteropServices;
using System.Web.UI.WebControls;



using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Microsoft.Office.Core;
using System.Threading;


namespace BenefitPointSummaryPortal.View
{
    public partial class Fyers : System.Web.UI.Page
    {
        string SessionId = "";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        string temperror = "cs";
        static DataTable dtFlyer_OpenEnroll;

        /******* As Per Nicole : Mobile App Flyers - Updates to names, default size, add Spanish
            List<string> listFlyerOptionMobileApp = new List<string>() { "Option 1", "Option 2" };
        ***/
        List<string> listFlyerOptionMobileApp = new List<string>() { "Basic Blue", "Images" };

        List<string> listFlyerLanguage = new List<string>() { "English" };
        List<string> listFlyerLanguageBoth = new List<string>() { "English", "Spanish" };
        List<string> listFlyerOptionBRC = new List<string>() { "Simple Poster", "General Poster/Flyer", "Expanded Services Poster/Flyer", "Reintroduction Poster/Flyer" };
        //List<string> listFlyerOptionOpenEnrollment = new List<string>() { "Mountain", "Spring Field", "Spot Light", "Tabs", "Basic Blue", "Bay View", "Mosaic", "Summer Health", "Fall Option 1", "Fall Option 2" };
        List<string> listFlyerOptionOpenEnrollment = new List<string>() { "Mountain", "Spring Field", "Spot Light", "Tabs", "Basic Blue", "Bay View", "Mosaic", "Summer Health", "Fall Option 1", "Fall Option 2", "Winter" };
        List<string> listFlyerOptionPHM = new List<string>() { "Appointment Reminder", "Steps-Savings", "Steps-Wellness", "Preventive Care", "Wellness-Business", "Wellness-City", "Wellness-Exercise", "Wellness-Fishing", "Wellness-Family1", "Wellness-Family2", "Wellness-Family3", "Wellness-Outdoors1", "Wellness-Outdoors2", "Wellness-Outdoors3", "Wellness-Physician1", "Wellness-Physician2", "Wellness-Veggies" };

        //List<string> listSizeAll = new List<string>() { "8.5 x 11", "8.5 x 14", "11 x 17" };
        //List<string> listSizeOption = new List<string>() { "8.5 x 11" };

        List<string> listSizeAll = new List<string>() { "Letter (8.5 x 11)", "Legal (8.5 x 14)", "Tabloid (11 x 17)" };
        List<string> listSizeOption = new List<string>() { "Letter (8.5 x 11)" };

        #region Added by vinod : global variables
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.MaintainScrollPositionOnPostBack = true;
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                TitleSpan.InnerText = "Employee Flyers";

                if (!IsPostBack)
                {
                    hideShowAdditionalSection("");
                    txtsearch.Focus();
                    objCommFun.GetUserDetails();
                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    #region Added by vinod : Get daprtment details
                    DictDepartment = sd.getDepartmentDetails();
                    #endregion
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.Items.Clear();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                ddlFlyerType.SelectedIndex = 0;
                ddlFlyerType_OnSelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();
                SessionId = Session["SessionId"].ToString();
                ddlClient.Items.Clear();
                ddlClient.Items.Insert(0, new ListItem("Select", ""));
                rdlClient.SelectedIndex = 0;
                //ddlClient_SelectedIndexChanged(null, null);

                ddlFlyerType.SelectedIndex = 0;
                ddlFlyerType_OnSelectedIndexChanged(null, null);

                //ResetFlyerForm();

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void ResetFlyerForm()
        {
            ddlFlyerType.SelectedValue = "-Select-";
            ddlAccessCodeCount.SelectedValue = "-Select-";
            txtClient1.Text = "";
            txtClient2.Text = "";
            txtClient1.Text = "";
            txtClient3.Text = "";
            txtClient4.Text = "";
            txtClient5.Text = "";
            txtClient6.Text = "";
            txtClient7.Text = "";
            txtClient8.Text = "";
            txtClient9.Text = "";
            txtClient10.Text = "";
            txtClient11.Text = "";
            txtClient12.Text = "";
            txtCode1.Text = "";
            txtCode1.Text = "";
            txtCode2.Text = "";
            txtCode3.Text = "";
            txtCode4.Text = "";
            txtCode5.Text = "";
            txtCode6.Text = "";
            txtCode7.Text = "";
            txtCode8.Text = "";
            txtCode9.Text = "";
            txtCode10.Text = "";
            txtCode11.Text = "";
            txtCode12.Text = "";
        }

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                string Client = string.Empty;
                string Access_Code = string.Empty;
                string mynewfile = "";

                /**** code added by Amogh **/
                string FlyerType = ddlFlyerType.SelectedValue;
                string FlyerOption = ddlFlyerOption.SelectedValue;
                string RenewalYear = txtRenewalYear.Text.Trim();
                string OpenEnrollDate = txtOpenEnrollmentMeetingDate.Text.Trim();
                string OpenEnrollLocation = txtOpenEnrollmentMeetingLocation.Text.Trim();
                string OpenEnrollTime = txtOpenEnrollmentMeetingTime.Text.Trim();       //DateTime.Now.ToString("hh:mm tt");
                string selectedLanguage = ddlLanguage.SelectedValue.Trim();
                string selectedSize = ddlSize.SelectedValue.Trim();

                string fromDueDate = txtPHMFromDueDate.Text.Trim();
                string ProgramStartDate = txtPHMProgramStartDate.Text.Trim();
                string ProgramEndDate = txtPHMProgramEndDate.Text.Trim();
                string PlanEffectiveDate = txtPHMPlanEffectiveDate.Text.Trim();

                #region Added by vinod : storing the activity logs
                SessionId = Session["SessionId"].ToString();
                // Get the Account Office and Account Region for the selected client
                Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                List<Contact> ContactList = new List<Contact>();
                ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);

                //Loading Account DS and Account ReamMember DS

                DataSet AccountDS = new DataSet();
                DataSet AccountTeamMemberDS = new DataSet();

                sd.BuildAccountTable();
                AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                if (ddlClient.SelectedValue != "")
                {
                    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                }
                #endregion

                ////if (ddlFlyerOption.SelectedValue == "Option 1")
                if (FlyerType == "MobileApp" && ddlFlyerOption.SelectedValue == "Basic Blue")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreatePilot_FlyerMobileAppRequestForm(AccountDS, AccountTeamMemberDS, ContactList, Account_Office);
                }
                ////if (ddlFlyerOption.SelectedValue == "Option 2")
                if (ddlFlyerOption.SelectedValue == "Images")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreatePilot_FlyerUSIMobileApp_Option2Form(AccountDS, AccountTeamMemberDS, ContactList);
                }
                //**** Edited by Mr. Amogh Vilayatkar
                //if (ddlFlyerType.SelectedValue == "BRC" && ddlFlyerOption.SelectedValue == "Simple Poster" && ddlLanguage.SelectedValue == "English")
                if (ddlFlyerType.SelectedValue == "BRC" && ddlFlyerOption.SelectedValue == "Simple Poster" && (ddlLanguage.SelectedValue == "English" || ddlLanguage.SelectedValue == "Spanish"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateSimplePoster(AccountDS, AccountTeamMemberDS, ContactList);
                }
                if (ddlFlyerType.SelectedValue == "BRC" && ddlFlyerOption.SelectedValue == "General Poster/Flyer" && (ddlLanguage.SelectedValue == "English" || ddlLanguage.SelectedValue == "Spanish"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateGeneralPoster(AccountDS, AccountTeamMemberDS, ContactList);
                }
                if (ddlFlyerType.SelectedValue == "BRC" && ddlFlyerOption.SelectedValue == "Expanded Services Poster/Flyer" && ddlLanguage.SelectedValue == "English")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateExpandedPoster(AccountDS, AccountTeamMemberDS, ContactList);
                }
                if (ddlFlyerType.SelectedValue == "BRC" && ddlFlyerOption.SelectedValue == "Reintroduction Poster/Flyer" && (ddlLanguage.SelectedValue == "English" || ddlLanguage.SelectedValue == "Spanish"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateReintroductionPoster(AccountDS, AccountTeamMemberDS, ContactList);
                }

                /**************** Code done by Shavan & Merge by Amogh ****************************/
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Spot Light")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_SpotLight(ddlClient.SelectedItem.Text.Trim(), RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Tabs")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_Tabs(ddlClient.SelectedItem.Text.Trim(), RenewalYear, OpenEnrollDate, OpenEnrollLocation, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Spring Field")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_SpringField(ddlClient.SelectedItem.Text.Trim(), RenewalYear, OpenEnrollDate, OpenEnrollLocation, OpenEnrollTime, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Mountain")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_Mountain(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Basic Blue")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_BlueBasic(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Bay View")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_BayView(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Mosaic")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion

                    mynewfile = CreateFlyer_OE_Mosaic(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }

                if (FlyerType == "OpenEnrollment" && FlyerOption == "Summer Health")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }

                    mynewfile = CreateFlyer_OE_SummerHealth(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }
                if (FlyerType == "OpenEnrollment" && FlyerOption == "Fall Option 1")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }

                    mynewfile = CreateFlyer_OE_FallOprion1(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }

                if (FlyerType == "OpenEnrollment" && FlyerOption == "Fall Option 2")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }

                    mynewfile = CreateFlyer_OE_FallOprion2(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }

                if (FlyerType == "OpenEnrollment" && FlyerOption == "Winter")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    mynewfile = CreateFlyer_OE_Winter(ddlClient.SelectedItem.Text.Trim(), selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ddlClient);
                }


                //Added by shravan for PHM
                if (FlyerType == "PopulationHealthMgmt" && FlyerOption == "Appointment Reminder")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    mynewfile = CreateFlyer_PopulationHealthMgmtAppReminder(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, fromDueDate, ddlClient);
                }
                if (FlyerType == "PopulationHealthMgmt" && FlyerOption == "Steps-Wellness")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    mynewfile = CreateFlyer_PopulationHealthMgmtStepsWellness(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ddlClient);
                }
                if (FlyerType == "PopulationHealthMgmt" && (FlyerOption == "Wellness-Family1" || FlyerOption == "Wellness-Family2" || FlyerOption == "Wellness-Family3"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    //mynewfile = CreateFlyer_PopulationHealthMgmtStepsWellness(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ddlClient);
                    mynewfile = CreateFlyer_PopulationHealthMgmtWellnessFamily(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, FlyerOption);
                }
                if (FlyerType == "PopulationHealthMgmt" && (FlyerOption == "Wellness-Outdoors1" || FlyerOption == "Wellness-Outdoors2" || FlyerOption == "Wellness-Outdoors3"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    //mynewfile = CreateFlyer_PopulationHealthMgmtStepsWellness(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ddlClient);
                    mynewfile = CreateFlyer_PopulationHealthMgmtWellnessOutdoors(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, FlyerOption);
                }
                if (FlyerType == "PopulationHealthMgmt" && (FlyerOption == "Wellness-Physician1" || FlyerOption == "Wellness-Physician2"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    //mynewfile = CreateFlyer_PopulationHealthMgmtStepsWellness(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ddlClient);
                    mynewfile = CreateFlyer_PopulationHealthMgmtWellnessPhysician(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, FlyerOption);
                }
                if (FlyerType == "PopulationHealthMgmt" && FlyerOption == "Preventive Care")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    mynewfile = CreateFlyer_PopulationHealthMgmtPreventiveCare(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, fromDueDate, ddlClient);
                }

                //Steps-Savings
                if (FlyerType == "PopulationHealthMgmt" && FlyerOption == "Steps-Savings")
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    mynewfile = CreateFlyer_PopulationHealthMgmtStepsSavings(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, FlyerOption);
                }
                if (FlyerType == "PopulationHealthMgmt" && (FlyerOption == "Wellness-Business" || FlyerOption == "Wellness-City" || FlyerOption == "Wellness-Exercise" || FlyerOption == "Wellness-Fishing" || FlyerOption == "Wellness-Veggies"))
                {
                    #region Added by vinod : As per new change
                    Activity = "Posters & Flyers";
                    Activity_Group = "Communications";
                    #endregion
                    int year = -1;
                    int.TryParse(txtRenewalYear.Text, out year);

                    if (year <= 0)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select valid year.')</script>");
                        return;
                    }
                    mynewfile = CreateFlyer_PopulationHealthMgmtWellnessOthers(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, FlyerOption);
                }

                DownloadFileNew(mynewfile);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /******* Code Made by SRAVAN *********************************/

        //Method for "Open-Enrollment 'SpotLight'"
        private string CreateFlyer_OE_SpotLight(string ddlClient, string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;


            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "21-OE_Spotlight_8 5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "22-OE_Spotlight_8 5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "23-OE_Spotlight_11x17_English";
                        break;
                }

                //Need to remove
                ////if (selectedSize == 1)
                ////{
                ////    filename = "21-OE_Spotlight_8 5x11_English";
                ////}
                ////else if (ddlAccessCodeCount.SelectedIndex == 2)
                ////{
                ////    filename = "22-OE_Spotlight_8 5x14_English";
                ////}
                ////else if (ddlAccessCodeCount.SelectedIndex == 3)
                ////{
                ////    filename = "23-OE_Spotlight_11x17_English";
                ////}
            }



            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_SpotLight(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient, RenewalYear);
                    objPres.Save();

                    #region Added by vinod
                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_SpotLight(ddlClient, RenewalYear, selectedLanguage, selectedSize);
                        CreateFlyer_OE_SpotLight(ddlClient, RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        //Method for "Open-Enrollment 'Tabs'"
        private string CreateFlyer_OE_Tabs(string ddlClient, string RenewalYear, string OEDate, string OELocation, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "24-OE_Tabs_8 5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "25-OE_Tabs_8 5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "26-OE_Tabs_11x17_English";
                        break;
                }
            }

            //need to Remove
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "24-OE_Tabs_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "25-OE_Tabs_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "26-OE_Tabs_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_Tabs(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient, RenewalYear, OEDate, OELocation);
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_OE_Tabs(ddlClient, RenewalYear, OEDate, OELocation, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        //Method for "Open-Enrollment 'Spring Field'"
        private string CreateFlyer_OE_SpringField(string ddlClient, string RenewalYear, string OEDate, string OELocation, string OETime, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "18-OE_SpringField_8 5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "19-OE_SpringField_8 5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "20-OE_SpringField_11x17_English";
                        break;
                }
            }

            //Need to remove
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "18-OE_SpringField_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "19-OE_SpringField_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "20-OE_SpringField_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_SpringField(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient, RenewalYear, OEDate, OELocation, OETime);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;

                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_SpringField(ddlClient, RenewalYear, OEDate, OELocation, OETime, selectedLanguage, selectedSize);
                        CreateFlyer_OE_SpringField(ddlClient, RenewalYear, OEDate, OELocation, OETime, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        //Method for "Open-Enrollment 'Mountain'"
        private string CreateFlyer_OE_Mountain(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "15-OE_Mountain_8 5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "16-OE_Mountain_8 5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "17-OE_Mountain_11x17_English";
                        break;
                }
            }

            //Need to remove 
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "15-OE_Mountain_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "16-OE_Mountain_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "17-OE_Mountain_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    //objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);


                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_Mountain(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient);
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_BlueBasic(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "27-OE_BasicBlue_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "28-OE_BasicBlue_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "29-OE_BasicBlue_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);


                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_BasicBlue(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingTime.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim());
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_BayView(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "30-OE_BayView_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "31-OE_BayView_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "32-OE_BayView_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_BayView(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, renewalYear, txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim(), ddlClient);
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_Mosaic(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "33-OE_Mosaic_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "34-OE_Mosaic_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "35-OE_Mosaic_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_Mosaic(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, renewalYear, txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim(), ddlClient);
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_SummerHealth(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "36-OE_SummerHealth_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "37-OE_SummerHealth_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "38-OE_SummerHealth_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_SummerHealth(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, txtOpenEnrollmentMeetingDate.Text.Trim(), renewalYear, ddlClient);
                    // wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_FallOprion1(string ClientName, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "51-OE_Fall_Option1_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "52-OE_Fall_Option1_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "53-OE_Fall_Option1_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_FallOption1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, txtRenewalYear.Text.Trim(), txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingTime.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim(), ClientName);

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_FallOprion1(ddlClient.SelectedItem.Text, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateFlyer_OE_FallOprion2(string ClientName, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "54-OE_Fall_Option2_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "55-OE_Fall_Option2_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "56-OE_Fall_Option2_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_FallOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, txtRenewalYear.Text.Trim(), txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingTime.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim(), ClientName);

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_FallOprion2(ddlClient.SelectedItem.Text, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }



        //Added by Vinod
        private string CreateFlyer_OE_Winter(string ddlClient, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            string filename = string.Empty;
            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "57_OE_Winter_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "58_OE_Winter_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "59_OE_Winter_11x17_English";
                        break;
                }
            }
            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + "/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    int renewalYear = int.Parse(txtRenewalYear.Text.Trim());
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_OE_Winter(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, renewalYear, txtOpenEnrollmentMeetingDate.Text.Trim(), txtOpenEnrollmentMeetingTime.Text.Trim(), txtOpenEnrollmentMeetingLocation.Text.Trim(), ddlClient);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize);
                        CreateFlyer_OE_Mountain(ddlClient, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ClientValue);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateSimplePoster(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            List<BRCData> BRC = new List<BRCData>();
            BRC = (List<BRCData>)Session["BRC"];

            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            string strFileName = string.Empty;
            string strReportName = string.Empty;


            //**** Code Edited by Mr. Amogh Vilayatkar
            if (ddlLanguage.SelectedValue == "English")  //English
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "03-BRC_SimplePoster_8.5x11_English";
                    strReportName = "03-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "04-BRC_SimplePoster_8.5x14_English";
                    strReportName = "03-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "05-BRC_SimplePoster_11x17_English";
                    strReportName = "03-BRC";
                }
            }
            else if (ddlLanguage.SelectedValue == "Spanish")  //Spanish
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "39-BRC_SimplePoster_8.5x11_Spanish";
                    strReportName = "39-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "40-BRC_SimplePoster_8.5x14_Spanish";
                    strReportName = "40-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "41-BRC_SimplePoster_11x17_Spanish";
                    strReportName = "41-BRC";
                }
            }

            //////if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
            //////{
            //////    strFileName = "03-BRC_SimplePoster_8.5x11_English";
            //////    strReportName = "03-BRC";
            //////}
            //////if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
            //////{
            //////    strFileName = "04-BRC_SimplePoster_8.5x14_English";
            //////    strReportName = "03-BRC";
            //////}
            //////if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
            //////{
            //////    strFileName = "05-BRC_SimplePoster_11x17_English";
            //////    strReportName = "03-BRC";
            //////}

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strFileName + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //dtFlyer_OpenEnroll = new DataTable();
                    //dtFlyer_OpenEnroll = CreateFlyerTable();
                    //BindFlyer();

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_BRC(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    //wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        #region  replace with createsimplaePoster method
                        CreateSimplePoster(AccountDS, AccountTeamMemberDS, ContactList);
                        #endregion
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateGeneralPoster(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            List<BRCData> BRC = new List<BRCData>();
            BRC = (List<BRCData>)Session["BRC"];

            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            string strFileName = string.Empty;
            string strReportName = string.Empty;

            //******** Code Updated by Mr. Amogh Vilayatkar 

            if (ddlLanguage.SelectedValue == "English")
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "06-BRC_GeneralPoster_8.5x11_English";
                    strReportName = "06-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "07-BRC_GeneralPoster_8.5x14_English";
                    strReportName = "07-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "08-BRC_GeneralPoster_11x17_English";
                    strReportName = "08-BRC";
                }
            }
            else if (ddlLanguage.SelectedValue == "Spanish")  //Spanish
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "42-BRC_GeneralPoster_8.5x11_Spanish";
                    strReportName = "42-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "43-BRC_GeneralPoster_8.5x14_Spanish";
                    strReportName = "43-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "44-BRC_GeneralPoster_11x17_Spanish";
                    strReportName = "44-BRC";
                }
            }




            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strFileName + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //dtFlyer_OpenEnroll = new DataTable();
                    //dtFlyer_OpenEnroll = CreateFlyerTable();
                    //BindFlyer();

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    if (ddlLanguage.SelectedValue == "English")
                        wt.WriteField_BRC_V1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    else
                        wt.WriteField_BRC(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    //wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        ////CreatePilot_FlyerUSIMobileApp_Option2Form();
                        CreateGeneralPoster(AccountDS, AccountTeamMemberDS, ContactList);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateExpandedPoster(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            List<BRCData> BRC = new List<BRCData>();
            BRC = (List<BRCData>)Session["BRC"];

            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            string strFileName = string.Empty;
            string strReportName = string.Empty;

            if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
            {
                strFileName = "09-BRC_Expanded_8.5x11_English";
                strReportName = "09-BRC";
            }
            if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
            {
                strFileName = "10-BRC_Expanded_8.5x14_English";
                strReportName = "10-BRC";
            }
            if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
            {
                strFileName = "11-BRC_Expanded_11x17_English";
                strReportName = "11-BRC";
            }

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strFileName + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //dtFlyer_OpenEnroll = new DataTable();
                    //dtFlyer_OpenEnroll = CreateFlyerTable();
                    //BindFlyer();

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_BRC_V1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    //wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateExpandedPoster(AccountDS, AccountTeamMemberDS, ContactList);
                        //CreatePilot_FlyerUSIMobileApp_Option2Form();
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreateReintroductionPoster(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;
            List<BRCData> BRC = new List<BRCData>();
            BRC = (List<BRCData>)Session["BRC"];

            bool bAssistantOn;

            Object missing = System.Reflection.Missing.Value;
            string strFileName = string.Empty;
            string strReportName = string.Empty;

            //***** Modified by Mr. Amogh Vilayatkar

            if (ddlLanguage.SelectedValue == "English")  //English
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "12-BRC_Reintroduction_8.5x11_English";
                    strReportName = "12-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "13-BRC_Reintroduction_8.5x14_English";
                    strReportName = "13-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "14-BRC_Reintroduction_11x17_English";
                    strReportName = "14-BRC";
                }
            }
            else if (ddlLanguage.SelectedValue == "Spanish")  //Spanish
            {
                if (ddlSize.SelectedValue == "Letter (8.5 x 11)")
                {
                    strFileName = "48-BRC_Reintroduction_8.5x11_Spanish";
                    strReportName = "48-BRC";
                }
                if (ddlSize.SelectedValue == "Legal (8.5 x 14)")
                {
                    strFileName = "49-BRC_Reintroduction_8.5x14_Spanish";
                    strReportName = "49-BRC";
                }
                if (ddlSize.SelectedValue == "Tabloid (11 x 17)")
                {
                    strFileName = "50-BRC_Reintroduction_11x17_Spanish";
                    strReportName = "50-BRC";
                }
            }

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strFileName + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName)))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + strReportName));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    //dtFlyer_OpenEnroll = new DataTable();
                    //dtFlyer_OpenEnroll = CreateFlyerTable();
                    //BindFlyer();

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    if (ddlLanguage.SelectedValue == "English")
                        wt.WriteField_BRC_V1(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    else
                        wt.WriteField_BRC(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, BRC);
                    //wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        //CreatePilot_FlyerUSIMobileApp_Option2Form();
                        CreateReintroductionPoster(AccountDS, AccountTeamMemberDS, ContactList);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        private string CreatePilot_FlyerUSIMobileApp_Option2Form(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            //PowerPoint.Slides objSlides;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;

            //***** Modified by Mr. Amogh Vilayatkar
            string strFileName = "";
            if (ddlLanguage.SelectedValue == "English")  //English
            {
                strFileName = "Flyer_MobileAppOpt2_Template";
            }
            else if (ddlLanguage.SelectedValue == "Spanish")  //Spanish
            {
                strFileName = "Flyers/60_MobileApp_Images_8.5x11_Spanish";
            }

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/" + strFileName + ".pptx");

            //Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyer_MobileAppOpt2_Template.pptx");

            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/ReportMobApp_Option2" + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //objSlides = objPres.Slides;
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/ReportMobApp_Option2")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/ReportMobApp_Option2"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);

                    dtFlyer_OpenEnroll = new DataTable();
                    dtFlyer_OpenEnroll = CreateFlyerTable();
                    BindFlyer();

                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, ddlClient, dtFlyer_OpenEnroll);
                    wt.DeleteUnwantedSectionFromFlyerOption2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    //wt.WriteField_FlyerMobileAppRequestForm_Option2(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange);
                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = string.Empty;
                    string AdditionalCrtieriaOption_4 = string.Empty;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreatePilot_FlyerUSIMobileApp_Option2Form(AccountDS, AccountTeamMemberDS, ContactList);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        protected string CreatePilot_FlyerMobileAppRequestForm(DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string Account_Office)
        {

            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.Application oWordApp = new Word.Application();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers_OpenEnrollmentMobileApp_Template.docm");

            Object readOnly = true;
            Object isVisible = false;
            //TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Pilot/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Pilot/Documents/Templates/Report1"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);

                dtFlyer_OpenEnroll = new DataTable();
                dtFlyer_OpenEnroll = CreateFlyerTable();
                BindFlyer();

                Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();

                wt.WriteField_FlyerMobileAppRequestForm(oWordDoc, oWordApp, dtFlyer_OpenEnroll);

                //wt.DeleteSpecialPage(oWordDoc, oWordApp);

                //for (int i = 3; i <=4; i++)
                //{
                //    wt.DeleteSpecialPage(oWordDoc);
                //}
                int id = Convert.ToInt32(ddlAccessCodeCount.SelectedValue);
                switch (id)
                {
                    case 1: RunMacro(oWordApp, new Object[] { "Clearpages1" }); break;
                    case 2: RunMacro(oWordApp, new Object[] { "Clearpages2" }); break;
                    case 3: RunMacro(oWordApp, new Object[] { "Clearpages3" }); break;
                    case 4: RunMacro(oWordApp, new Object[] { "Clearpages4" }); break;
                    case 5: RunMacro(oWordApp, new Object[] { "Clearpages5" }); break;
                    case 6: RunMacro(oWordApp, new Object[] { "Clearpages6" }); break;
                    case 7: RunMacro(oWordApp, new Object[] { "Clearpages7" }); break;
                    case 8: RunMacro(oWordApp, new Object[] { "Clearpages8" }); break;
                    case 9: RunMacro(oWordApp, new Object[] { "Clearpages9" }); break;
                    case 10: RunMacro(oWordApp, new Object[] { "Clearpages10" }); break;
                    case 11: RunMacro(oWordApp, new Object[] { "Clearpages11" }); break;
                }
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                #region Added by vinod for storing the activity logs

                string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                #endregion

                // bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }


        // Added by shravan for PHM
        #region PHM
        private string CreateFlyer_PopulationHealthMgmtAppReminder(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string fromDueDate, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "61_PHM_ApptReminder_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "62_PHM_ApptReminder_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "63_PHM_ApptReminder_11x17_English";
                        break;
                }
            }

            //Need to remove
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "18-OE_SpringField_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "19-OE_SpringField_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "20-OE_SpringField_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    // objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_AppointmentReminder(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, fromDueDate);

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtAppReminder(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, fromDueDate, ddlClient);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        private string CreateFlyer_PopulationHealthMgmtStepsWellness(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "83_PHM_Steps-Wellness_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "84_PHM_Steps-Wellness_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "85_PHM_Steps-Wellness_11x17_English";
                        break;
                }
            }

            //Need to remove
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "18-OE_SpringField_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "19-OE_SpringField_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "20-OE_SpringField_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //  objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_StepsWellness(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate);

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtStepsWellness(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ddlClient);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        private string CreateFlyer_PopulationHealthMgmtWellnessFamily(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, DropDownList ClientValue, string Flyersoptions)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (Flyersoptions)
                {
                    case "Wellness-Family1": filename = "70_PHM_Wellness_Family1_8.5x11_English";
                        break;
                    case "Wellness-Family2": filename = "71_PHM_Wellness_Family2_8.5x11_English";
                        break;
                    case "Wellness-Family3": filename = "72_PHM_Wellness_Family3_8.5x11_English";
                        break;


                }
            }

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //objApp.Visible = MsoTriState.msoFalse;                                        
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_WellnessFamily(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtWellnessFamily(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, Flyersoptions);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        private string CreateFlyer_PopulationHealthMgmtWellnessOutdoors(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, DropDownList ClientValue, string Flyersoptions)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (Flyersoptions)
                {
                    case "Wellness-Outdoors1": filename = "74_PHM_Wellness_Outdoors1_8.5x11_English";
                        break;
                    case "Wellness-Outdoors2": filename = "75_PHM_Wellness_Outdoors2_8.5x11_English";
                        break;
                    case "Wellness-Outdoors3": filename = "76_PHM_Wellness_Outdoors3_8.5x11_English";
                        break;


                }
            }

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //objApp.Visible = MsoTriState.msoFalse;                                        
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_Wellness_Outdoors(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtWellnessFamily(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, Flyersoptions);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        private string CreateFlyer_PopulationHealthMgmtWellnessPhysician(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, DropDownList ClientValue, string Flyersoptions)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (Flyersoptions)
                {
                    case "Wellness-Physician1": filename = "77_PHM_Wellness_Physician1_8.5x11_English";
                        break;
                    case "Wellness-Physician2": filename = "78_PHM_Wellness_Physician2_8.5x11_English";
                        break;
                }
            }

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //objApp.Visible = MsoTriState.msoFalse;                                        
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_WellnessPhysician(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtWellnessPhysician(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, Flyersoptions);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        private string CreateFlyer_PopulationHealthMgmtPreventiveCare(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string fromDueDate, DropDownList ClientValue)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "64_PHM_PreventiveCare_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "65_PHM_PreventiveCare_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "66_PHM_PreventiveCare_11x17_English";
                        break;
                }
            }

            //Need to remove
            ////if (ddlAccessCodeCount.SelectedIndex == 1)
            ////{
            ////    filename = "18-OE_SpringField_8 5x11_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 2)
            ////{
            ////    filename = "19-OE_SpringField_8 5x14_English";
            ////}
            ////else if (ddlAccessCodeCount.SelectedIndex == 3)
            ////{
            ////    filename = "20-OE_SpringField_11x17_English";
            ////}

            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //  objApp.Visible = MsoTriState.msoFalse;
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;
                //objPres = objPresSet.Open(Convert.ToString(fileName),
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoFalse,
                //                      MsoTriState.msoTrue);

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_PreventiveCare(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, fromDueDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                    //  bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtPreventiveCare(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, fromDueDate, ddlClient);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        //CreateFlyer_PopulationHealthMgmtStepsSavings
        private string CreateFlyer_PopulationHealthMgmtStepsSavings(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, DropDownList ClientValue, string Flyersoptions)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                switch (selectedSize)
                {
                    case "Letter (8.5 x 11)": filename = "80_PHM_Steps-Savings_8.5x11_English";
                        break;
                    case "Legal (8.5 x 14)": filename = "81_PHM_Steps-Savings_8.5x14_English";
                        break;
                    case "Tabloid (11 x 17)": filename = "82_PHM_Steps-Savings_11x17_English";
                        break;
                }
            }


            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //objApp.Visible = MsoTriState.msoFalse;                                        
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_StepsSavings(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtWellnessPhysician(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, Flyersoptions);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }

        //CreateFlyer_PopulationHealthMgmtWellnessOthers
        private string CreateFlyer_PopulationHealthMgmtWellnessOthers(string RenewalYear, string selectedLanguage, string selectedSize, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string ProgramStartDate, string ProgramEndDate, string PlanEffectiveDate, DropDownList ClientValue, string Flyersoptions)
        {
            Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
            OleMessageFilter.Register();
            PowerPoint.Presentations objPresSet;
            PowerPoint.Application objApp;
            PowerPoint._Presentation objPres;
            PowerPoint.Shapes objShapes = null;
            PowerPoint.Slides objSlides = null;
            PowerPoint.TextFrame txtFrame = null;
            PowerPoint.TextRange txtRange = null;

            bool bAssistantOn;
            string filename = string.Empty;

            if (selectedLanguage == "English")
            {
                if (selectedSize == "Letter (8.5 x 11)")
                {
                    switch (ddlFlyerOption.SelectedItem.Text)
                    {
                        case "Wellness-Business": filename = "67_PHM_Wellness-Business_8.5x11_English";
                            break;
                        case "Wellness-City": filename = "68_PHM_Wellness-City_8.5x11_English";
                            break;
                        case "Wellness-Exercise": filename = "69_PHM_Wellness-Exercise_8.5x11_English";
                            break;
                        case "Wellness-Fishing": filename = "73_PHM_Wellness-Fishing_8.5x11_English";
                            break;
                        case "Wellness-Veggies": filename = "79_PHM_Wellness-Veggies_8.5x11_English";
                            break;

                    }
                }
            }


            Object missing = System.Reflection.Missing.Value;
            Object fileName = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/" + filename + ".pptx");
            BPBusiness bp = new BPBusiness();
            Object readOnly = true;
            Object isVisible = false;
            string savefilename = string.Empty;

            FileInfo fInfo = new FileInfo(Convert.ToString(fileName));

            if (File.Exists(Convert.ToString(fileName)))
            {
                objApp = new PowerPoint.Application();
                try
                {
                    //objApp.Visible = MsoTriState.msoFalse;                                        
                }
                catch (Exception ex)
                { }

                objPresSet = objApp.Presentations;

                objPres = objPresSet.Open(Convert.ToString(fileName),
                                MsoTriState.msoTrue,
                                MsoTriState.msoTrue,
                                MsoTriState.msoFalse);

                savefilename = Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads/" + filename + System.DateTime.Now.Year.ToString() +
                                System.DateTime.Now.Month.ToString() +
                                System.DateTime.Now.Day.ToString() +
                                System.DateTime.Now.Hour.ToString() +
                                System.DateTime.Now.Minute.ToString() +
                                System.DateTime.Now.Second.ToString() +
                                System.DateTime.Now.Millisecond.ToString() +
                                ".pptx");

                try
                {
                    //Prevent Office Assistant from displaying alert messages:
                    if (objApp.Version != "14.0")
                    {
                        bAssistantOn = objApp.Assistant.On;
                        objApp.Assistant.On = false;
                        objApp.DisplayAlerts = PowerPoint.PpAlertLevel.ppAlertsNone;
                    }
                    if (!Directory.Exists(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads")))
                    {
                        Directory.CreateDirectory(Server.MapPath("~/Files/BenefitSummary/Documents/Templates/Flyers/Downloads"));
                    }
                    objPres.SaveAs(savefilename, PowerPoint.PpSaveAsFileType.ppSaveAsDefault, MsoTriState.msoTriStateMixed);
                    Flyers_OpenEnrollmentMobileApp wt = new Flyers_OpenEnrollmentMobileApp();
                    wt.WriteField_Flyer_PHM_WellnessOthers(objPres, objPresSet, objSlides, objShapes, txtFrame, txtRange, RenewalYear, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, Convert.ToString(ClientValue.SelectedItem));

                    objPres.Save();

                    #region Added by vinod : storing the activity logs

                    string AdditionalCrtieriaOption_1 = ddlFlyerType.SelectedItem.Text;
                    string AdditionalCrtieriaOption_2 = ddlFlyerOption.SelectedItem.Text;
                    string AdditionalCrtieriaOption_3 = ddlLanguage.SelectedItem.Text;
                    string AdditionalCrtieriaOption_4 = ddlSize.SelectedItem.Text;
                    DicActivityLog.Clear();
                    DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                    bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ClientValue.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ClientValue.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));

                    #endregion

                }
                catch (Exception ex)
                {
                    if (ex.Message.Equals("The message filter indicated that the application is busy. (Exception from HRESULT: 0x8001010A (RPC_E_SERVERCALL_RETRYLATER))"))
                    {
                        CreateFlyer_PopulationHealthMgmtWellnessPhysician(RenewalYear, selectedLanguage, selectedSize, AccountDS, AccountTeamMemberDS, ContactList, ProgramStartDate, ProgramEndDate, PlanEffectiveDate, ddlClient, Flyersoptions);
                    }
                    else
                    {
                        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                        Response.Redirect("~/view/ErrorNotification.aspx");
                    }
                }
                finally
                {
                    if (txtFrame != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtFrame) > 0) ;
                        txtFrame = null;
                    }
                    if (txtRange != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(txtRange) > 0) ;
                        txtRange = null;
                    }
                    if (objShapes != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objShapes) > 0) ;
                        objShapes = null;
                    }
                    if (objSlides != null)
                    {
                        while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objSlides) > 0) ;
                        objSlides = null;
                    }

                    objPres.Close();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPres) > 0)
                        objPres = null;
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objPresSet) > 0)
                        objPresSet = null;

                    objApp.Quit();
                    while (System.Runtime.InteropServices.Marshal.FinalReleaseComObject(objApp) > 0)
                        objApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
            else
            {
                Response.Write("File Name : " + fInfo.Name + " does not exists.");
            }
            OleMessageFilter.Revoke();
            return (savefilename.ToString());
        }
        #endregion

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected DataTable CreateFlyerTable()
        {
            try
            {
                dtFlyer_OpenEnroll.Columns.Add("ClientName", typeof(string));
                dtFlyer_OpenEnroll.Columns.Add("Code", typeof(Int32));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return dtFlyer_OpenEnroll;
        }

        private void BindFlyer()
        {
            try
            {
                int id = Convert.ToInt32(ddlAccessCodeCount.SelectedValue);
                DataRow dr = null;

                for (int i = 1; i <= id; i++)
                {
                    TextBox txtClient = this.FindControl("txtClient" + i) as TextBox;
                    TextBox txtMobileCode = this.FindControl("txtCode" + i) as TextBox;
                    if (txtClient != null)
                    {
                        dr = dtFlyer_OpenEnroll.NewRow();
                        dr["ClientName"] = txtClient.Text;
                        dr["Code"] = txtMobileCode.Text;
                        dtFlyer_OpenEnroll.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /******CODE ADDED BY AMOGH */
        protected void ddlFlyerType_OnSelectedIndexChanged(object sender, EventArgs e)
        {

            ClearControl();
            hideShowAdditionalSection("");
            if (ddlFlyerType.SelectedIndex > 0)
            {
                if (ddlClient.SelectedIndex > 0)
                {
                    loadFlyerOption(ddlFlyerType.SelectedValue.Trim());
                }
                else if (ddlClient.SelectedIndex == -1 || ddlClient.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select Client.')</script>", false);
                    ddlClient.Focus();
                    return;
                }
            }
        }

        private void loadFlyerOption(string selectedFlyerType)
        {
            ddlFlyerOption.Items.Clear();

            switch (selectedFlyerType)
            {
                case "MobileApp":
                    ddlFlyerOption.DataSource = listFlyerOptionMobileApp;
                    ddlFlyerOption.DataBind();
                    break;
                case "BRC":
                    ddlFlyerOption.DataSource = listFlyerOptionBRC;
                    ddlFlyerOption.DataBind();
                    break;
                case "OpenEnrollment":
                    ddlFlyerOption.DataSource = listFlyerOptionOpenEnrollment;
                    ddlFlyerOption.DataBind();
                    break;
                case "PopulationHealthMgmt":
                    ddlFlyerOption.DataSource = listFlyerOptionPHM;
                    ddlFlyerOption.DataBind();
                    break;
            }
            ddlFlyerOption.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlFlyerOption.SelectedIndex = 0;
        }



        protected void ddlFlyerOption_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ddlAccessCodeCount.SelectedIndex = 0;
            if (ddlFlyerOption.SelectedIndex > 0)
            {
                loadLang_Size(ddlFlyerType.SelectedValue.Trim(), ddlFlyerOption.SelectedValue.Trim());
            }
            else if (ddlFlyerOption.SelectedIndex == 0)
            {
                ddlSize.Items.Clear();
                ddlLanguage.Items.Clear();
                hideShowAdditionalSection("");
            }
        }

        private void loadLang_Size(string selectedFlyerType, string FlyerOption)
        {
            ddlSize.Items.Clear();
            ddlLanguage.Items.Clear();
            txtOpenEnrollmentMeetingDate.Text = string.Empty;
            txtOpenEnrollmentMeetingLocation.Text = string.Empty;
            txtOpenEnrollmentMeetingTime.Text = string.Empty;
            txtRenewalYear.Text = string.Empty;

            txtPHMFromDueDate.Text = string.Empty;
            txtPHMPlanEffectiveDate.Text = string.Empty;
            txtPHMProgramEndDate.Text = string.Empty;
            txtPHMProgramStartDate.Text = string.Empty;

            if (selectedFlyerType == "MobileApp" && listFlyerOptionMobileApp.Contains(FlyerOption))
            {
                if (FlyerOption == "Images")
                {
                    ddlLanguage.DataSource = listFlyerLanguageBoth;
                }
                else { ddlLanguage.DataSource = listFlyerLanguage; }

                ////ddlLanguage.DataSource = listFlyerLanguage;
                ddlLanguage.DataBind();
                ddlSize.DataSource = listSizeOption;
                ddlSize.DataBind();

                string classify = FlyerOption == "Basic Blue" ? "Basic Blue_Mob" : FlyerOption;
                hideShowAdditionalSection(classify);
            }
            else if (selectedFlyerType == "BRC" && listFlyerOptionBRC.Contains(FlyerOption))
            {
                //ddlLanguage.DataSource = listFlyerLanguage;
                if (FlyerOption == "Expanded Services Poster/Flyer")
                {
                    ddlLanguage.DataSource = listFlyerLanguage;
                }
                else { ddlLanguage.DataSource = listFlyerLanguageBoth; }
                ddlLanguage.DataBind();
                ddlSize.DataSource = listSizeAll;
                ddlSize.DataBind();
                hideShowAdditionalSection(FlyerOption);
            }
            else if (selectedFlyerType == "OpenEnrollment" && listFlyerOptionOpenEnrollment.Contains(FlyerOption))
            {
                ddlLanguage.DataSource = listFlyerLanguage;
                ddlLanguage.DataBind();
                ddlSize.DataSource = listSizeAll;
                ddlSize.DataBind();
                hideShowAdditionalSection(FlyerOption);
            }
            else if (selectedFlyerType == "PopulationHealthMgmt" && listFlyerOptionPHM.Contains(FlyerOption))
            {
                ddlLanguage.DataSource = listFlyerLanguage;
                ddlLanguage.DataBind();

                //if (FlyerOption == "Wellness-Family1" || FlyerOption == "Wellness-Family2" || FlyerOption == "Wellness-Family3"
                //    || FlyerOption == "Wellness-Outdoors1" || FlyerOption == "Wellness-Outdoors2" || FlyerOption == "Wellness-Outdoors3"
                //    || FlyerOption == "Wellness-Physician1" || FlyerOption == "Wellness-Physician2")
                if (FlyerOption == "Appointment Reminder" || FlyerOption == "Preventive Care" || FlyerOption == "Steps-Wellness" || FlyerOption == "Steps-Savings")
                {
                    ddlSize.DataSource = listSizeAll;
                }
                else { ddlSize.DataSource = listSizeOption; }

                ddlSize.DataBind();
                hideShowAdditionalSection(FlyerOption);
            }
            ddlLanguage.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlLanguage.SelectedIndex = 0;
            if (ddlLanguage.Items.Count == 2)
                ddlLanguage.SelectedIndex = 1;
            ddlSize.Items.Insert(0, new ListItem("Select", string.Empty));
            ddlSize.SelectedIndex = 0;
            if (ddlSize.Items.Count == 2)
                ddlSize.SelectedIndex = 1;
        }


        private void hideShowAdditionalSection(string FlyerOption)
        {
            trAccessCodeList.Style.Add("display", "none");
            trAdditionalOptions.Style.Add("display", "none");

            trMeetingDate.Visible = false;
            trMeetingTime.Visible = false;
            trMeetingLocation.Visible = false;
            trRenwalYr.Visible = false;

            trFromDueDate.Visible = false;
            trPlanEffectiveDate.Visible = false;
            trProgramStartDate.Visible = false;
            trProgramEndDate.Visible = false;
            switch (FlyerOption)
            {
                case "Spring Field":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = true;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Spot Light":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Tabs":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                //case "Option 1":
                case "Basic Blue_Mob":   //Changes done by Amogh 
                    trAccessCodeList.Style.Add("display", "");
                    trAdditionalOptions.Style.Add("display", "");
                    // tblAccessCodes.Style.Add("display", "");
                    ddlAccessCodeCount_SelectedIndexChanged(null, null);
                    int selectedRowCount = 0;
                    int.TryParse(ddlAccessCodeCount.SelectedValue, out selectedRowCount);
                    for (int i = 0; i < tblAccessCodes.Rows.Count; i++)
                    {
                        tblAccessCodes.Rows[i].Cells[1].Style.Add("display", "");
                        tblAccessCodes.Rows[i].Cells[2].Style.Add("display", "");
                        tblAccessCodes.Rows[i].Cells[3].Style.Add("display", "");
                    }

                    break;
                //case "Option 2":
                case "Images":
                    trAccessCodeList.Style.Add("display", "");
                    trAdditionalOptions.Style.Add("display", "");
                    ddlAccessCodeCount_SelectedIndexChanged(null, null);
                    //tblAccessCodes.Style.Add("display", "");

                    for (int i = 0; i < tblAccessCodes.Rows.Count; i++)
                    {
                        tblAccessCodes.Rows[i].Cells[1].Style.Add("display", "none");
                        tblAccessCodes.Rows[i].Cells[2].Style.Add("display", "none");
                        tblAccessCodes.Rows[i].Cells[3].Style.Add("display", "none");
                    }
                    break;
                case "Basic Blue":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = true;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = false;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Bay View":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Mosaic":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Summer Health":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Fall Option 1":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = true;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Fall Option 2":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = true;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Winter":
                    trMeetingDate.Visible = true;
                    trMeetingTime.Visible = true;
                    trMeetingLocation.Visible = true;
                    trRenwalYr.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Appointment Reminder":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trFromDueDate.Visible = true;
                    trProgramStartDate.Visible = false;
                    trProgramEndDate.Visible = false;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Steps-Wellness":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trFromDueDate.Visible = false;
                    trProgramStartDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Family1":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Family2":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Family3":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Outdoors1":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Outdoors2":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Outdoors3":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Physician1":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Physician2":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Steps-Savings":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Business":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-City":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Exercise":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Fishing":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Wellness-Veggies":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trPlanEffectiveDate.Visible = true;
                    trProgramStartDate.Visible = true;
                    trProgramEndDate.Visible = true;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                case "Preventive Care":
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = true;
                    trFromDueDate.Visible = true;
                    trProgramStartDate.Visible = false;
                    trProgramEndDate.Visible = false;
                    trAdditionalOptions.Style.Add("display", "");
                    break;
                default:
                    trMeetingDate.Visible = false;
                    trMeetingTime.Visible = false;
                    trMeetingLocation.Visible = false;
                    trRenwalYr.Visible = false;
                    trFromDueDate.Visible = false;
                    trPlanEffectiveDate.Visible = false;
                    trProgramStartDate.Visible = false;
                    trProgramEndDate.Visible = false;
                    //   tblAccessCodes.Style.Add("display", "none");
                    trAccessCodeList.Style.Add("display", "none");
                    trAdditionalOptions.Style.Add("display", "none");
                    break;
            }
        }

        //Clear control 
        private void ClearControl()
        {
            ddlFlyerOption.Items.Clear();
            ddlLanguage.Items.Clear();
            ddlSize.Items.Clear();

            txtOpenEnrollmentMeetingDate.Text = string.Empty;
            txtOpenEnrollmentMeetingLocation.Text = string.Empty;
            txtOpenEnrollmentMeetingTime.Text = string.Empty;
            txtRenewalYear.Text = string.Empty;

            txtPHMFromDueDate.Text = string.Empty;
            txtPHMPlanEffectiveDate.Text = string.Empty;
            txtPHMProgramEndDate.Text = string.Empty;
            txtPHMProgramStartDate.Text = string.Empty;


            ddlAccessCodeCount.SelectedIndex = 0;
            ddlAccessCodeCount_SelectedIndexChanged(null, null);

            for (int i = 0; i < tblAccessCodes.Rows.Count; i++)
            {
                TextBox tblClientCode = this.FindControl("txtClient" + (i + 1).ToString()) as TextBox;
                TextBox tblAccessCode = this.FindControl("txtCode" + (i + 1).ToString()) as TextBox;
                if (tblClientCode != null && tblAccessCode != null)
                {
                    tblClientCode.Text = "";
                    tblAccessCode.Text = "";
                }
            }

        }

        protected void ddlAccessCodeCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedRowCount1 = 0;
            int.TryParse(ddlAccessCodeCount.SelectedValue, out selectedRowCount1);
            for (int i = 0; i < tblAccessCodes.Rows.Count; i++)
            {
                if (i < selectedRowCount1)
                    tblAccessCodes.Rows[i].Style.Add("display", "");
                else
                {
                    TextBox tblClientCode = this.FindControl("txtClient" + (i + 1).ToString()) as TextBox;
                    TextBox tblAccessCode = this.FindControl("txtCode" + (i + 1).ToString()) as TextBox;
                    if (tblClientCode != null && tblAccessCode != null)
                    {
                        tblClientCode.Text = "";
                        tblAccessCode.Text = "";
                    }
                    tblAccessCodes.Rows[i].Style.Add("display", "none");
                }

            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlFlyerType.SelectedIndex = 0;
            ddlFlyerType_OnSelectedIndexChanged(null, null);

            DataSet AccountDS = new DataSet();
            string Account_Office = string.Empty;
            string Account_Region = string.Empty;
            SessionId = Session["SessionId"].ToString();

            sd.BuildAccountTable();
            AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
            // Get the Account Office and Account Region for the selected client
            Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);

            List<BRCData> BRCList = new List<BRCData>();
            BRCList = bp.GetBRCDetails(Account_Office);

            if (BRCList.Count <= 0)
            {
                BRCData brcData = new BRCData();
                brcData.BRCId = 0;
                brcData.BRCName = "";
                brcData.BRCLocation = "";
                brcData.BRCEmail = "";
                brcData.BRCPhone = "";
                brcData.BRCFax = "";
                brcData.BRCTimezone = "";
                brcData.BRCDayHours = "";
                BRCList.Add(brcData);
            }
            Session["BRC"] = BRCList;

        }
    }
}