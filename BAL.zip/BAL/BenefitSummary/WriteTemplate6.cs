﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using System.Drawing;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate6 : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;

        #region Colors
        public Word.WdColor textbox_color(string color)
        {
            Color table_textbox = Color.FromArgb(79, 128, 189);
            switch (color)
            {
                case "Blue": table_textbox = Color.FromArgb(79, 128, 189); break;
                case "Green": table_textbox = Color.FromArgb(21, 95, 33); break;
                case "Black": table_textbox = Color.FromArgb(0, 0, 0); break;
                case "Maroon": table_textbox = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": table_textbox = Color.FromArgb(9, 84, 155); break;
                case "True Blue": table_textbox = Color.FromArgb(0, 0, 255); break;
                case "Dark Green": table_textbox = Color.FromArgb(0, 102, 0); break;
                case "Bright Green": table_textbox = Color.FromArgb(0, 153, 0); break;
                case "Olive Green": table_textbox = Color.FromArgb(131, 141, 9); break;
                case "Dark Red": table_textbox = Color.FromArgb(128, 0, 0); break;
                case "Red": table_textbox = Color.FromArgb(204, 0, 0); break;
                case "Mustard": table_textbox = Color.FromArgb(212, 160, 15); break;
                case "Orange": table_textbox = Color.FromArgb(255, 165, 0); break;
                case "Purple": table_textbox = Color.FromArgb(102, 0, 102); break;
                case "Light Brown": table_textbox = Color.FromArgb(153, 102, 51); break;
                case "Dark Brown": table_textbox = Color.FromArgb(102, 51, 0); break;
                case "Grey": table_textbox = Color.FromArgb(119, 119, 119); break;
                default: table_textbox = Color.FromArgb(105, 29, 29); break;
            }
            int rgb_textbox = ColorTranslator.ToOle(table_textbox);
            Word.WdColor wdColor_textbox = (Word.WdColor)rgb_textbox;
            return wdColor_textbox;
        }

        public Word.WdColor border_color(string color)
        {
            Color border = Color.FromArgb(79, 128, 189);

            switch (color)
            {
                case "Blue": border = Color.FromArgb(79, 128, 189); break;
                case "Green": border = Color.FromArgb(21, 95, 33); break;
                case "Black": border = Color.FromArgb(0, 0, 0); break;
                case "Maroon": border = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": border = Color.FromArgb(9, 84, 155); break;
                case "True Blue": border = Color.FromArgb(0, 0, 255); break;
                case "Dark Green": border = Color.FromArgb(0, 102, 0); break;
                case "Bright Green": border = Color.FromArgb(0, 153, 0); break;
                case "Olive Green": border = Color.FromArgb(131, 141, 9); break;
                case "Dark Red": border = Color.FromArgb(128, 0, 0); break;
                case "Red": border = Color.FromArgb(204, 0, 0); break;
                case "Mustard": border = Color.FromArgb(212, 160, 15); break;
                case "Orange": border = Color.FromArgb(255, 165, 0); break;
                case "Purple": border = Color.FromArgb(102, 0, 102); break;
                case "Light Brown": border = Color.FromArgb(153, 102, 51); break;
                case "Dark Brown": border = Color.FromArgb(102, 51, 0); break;
                case "Grey": border = Color.FromArgb(119, 119, 119); break;
                default: border = Color.FromArgb(105, 29, 29); break;
            }
            int rgb_border = ColorTranslator.ToOle(border);
            Word.WdColor wdColor_border = (Word.WdColor)rgb_border;
            return wdColor_border;
        }

        public Word.WdColor font_color(string color)
        {
            Color font = Color.FromArgb(0, 68, 123);
            switch (color)
            {
                case "Blue": font = Color.FromArgb(0, 68, 123); break;
                case "Green": font = Color.FromArgb(14, 62, 22); break;
                case "Black": font = Color.FromArgb(38, 38, 38); break;
                case "Maroon": font = Color.FromArgb(63, 17, 17); break;

                case "USI Blue": font = Color.FromArgb(6, 58, 106); break;
                case "True Blue": font = Color.FromArgb(0, 0, 192); break;
                case "Dark Green": font = Color.FromArgb(0, 66, 0); break;
                case "Bright Green": font = Color.FromArgb(0, 96, 0); break;
                case "Olive Green": font = Color.FromArgb(63, 68, 4); break;
                case "Dark Red": font = Color.FromArgb(84, 0, 0); break;
                case "Red": font = Color.FromArgb(150, 0, 0); break;
                case "Mustard": font = Color.FromArgb(118, 89, 8); break;
                case "Orange": font = Color.FromArgb(172, 94, 0); break;
                case "Purple": font = Color.FromArgb(100, 9, 125); break;
                case "Light Brown": font = Color.FromArgb(81, 54, 27); break;
                case "Dark Brown": font = Color.FromArgb(84, 42, 0); break;
                case "Grey": font = Color.FromArgb(84, 84, 84); break;
                default: font = Color.FromArgb(0, 68, 123); break;
            }

            int rgb_font = ColorTranslator.ToOle(font);
            Word.WdColor wdColor_font = (Word.WdColor)rgb_font;
            return wdColor_font;
        }

        public Word.WdColor cell_color(string color)
        {
            Color table_cell = Color.FromArgb(211, 223, 238);

            switch (color)
            {
                case "Blue": table_cell = Color.FromArgb(211, 223, 238); break;
                case "Green": table_cell = Color.FromArgb(192, 239, 175); break;
                case "Black": table_cell = Color.FromArgb(217, 217, 217); break;
                case "Maroon": table_cell = Color.FromArgb(237, 177, 177); break;

                case "USI Blue": table_cell = Color.FromArgb(140, 197, 248); break;
                case "True Blue": table_cell = Color.FromArgb(163, 197, 251); break;
                case "Dark Green": table_cell = Color.FromArgb(0, 188, 0); break;
                case "Bright Green": table_cell = Color.FromArgb(121, 255, 121); break;
                case "Olive Green": table_cell = Color.FromArgb(223, 247, 147); break;
                case "Dark Red": table_cell = Color.FromArgb(255, 125, 125); break;
                case "Red": table_cell = Color.FromArgb(255, 143, 143); break;
                case "Mustard": table_cell = Color.FromArgb(245, 210, 11); break;
                case "Orange": table_cell = Color.FromArgb(255, 199, 97); break;
                case "Purple": table_cell = Color.FromArgb(224, 183, 255); break;
                case "Light Brown": table_cell = Color.FromArgb(217, 178, 139); break;
                case "Dark Brown": table_cell = Color.FromArgb(200, 144, 88); break;
                case "Grey": table_cell = Color.FromArgb(196, 196, 196); break;
                default: table_cell = Color.FromArgb(211, 223, 238); break;
            }

            int rgb_cell = ColorTranslator.ToOle(table_cell);
            Word.WdColor wdColor_cell = (Word.WdColor)rgb_cell;

            return wdColor_cell;
        }
        # endregion

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="AccountDS">Dataset AccountDS contain Account information for selected Client.</param>
        public void WriteFieldToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS, string color)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                int index = -1;

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Text Box 4")
                    {
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = textbox_color(color);
                    }
                }

                oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                oWordDoc.Tables[19].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                oWordDoc.Tables[19].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                oWordDoc.Tables[19].Range.Font.Color = font_color(color);

                oWordDoc.Tables[20].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                oWordDoc.Tables[20].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                oWordDoc.Tables[20].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                oWordDoc.Tables[20].Range.Font.Color = font_color(color);

                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client_Name1"))
                                    {
                                        myMergeField.Select();

                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());

                                        continue;
                                    }

                                    if (fieldName.Contains("Wellness Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("client website"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString()))
                                        {
                                            oWordApp.Selection.TypeText(" | " + AccountDS.Tables["AccountTable"].Rows[0]["groupAccountInfo_commonGroupAccountInfo_website"].ToString());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        oWordDoc.Tables[2].Cell(1, 1).Range.Shading.BackgroundPatternColor = textbox_color(color);
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date Of Medical Plan minus 1 day"))
                                    {
                                        myMergeField.Select();
                                        string renewDate = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime rDate = Convert.ToDateTime(renewDate).AddDays(-1);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(rDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(rDate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("First Medical Plan Renewal Year"))
                                    {
                                        myMergeField.Select();

                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordDoc.Tables[1].Cell(1, 1).Range.Shading.BackgroundPatternColor = textbox_color(color);
                                        DateTime effective_date = Convert.ToDateTime(effectivedate);
                                        oWordApp.Selection.TypeText(effective_date.Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("unmarriedchildtoage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("definitionofdomesticpartner"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                            oWordApp.Selection.TypeText(domesticPartner);
                                            continue;
                                        }
                                    }
                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                            continue;
                                        }

                                        if (fieldName.Contains("Frequency"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("unitofmeasure"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }

                                        if (fieldName.Contains("Frequency"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("unitofmeasure"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Medical Plan Waiting Period"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            continue;
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (ddlBRC.SelectedItem.Text != "None")
                                    {
                                        if (fieldName.Contains("BRC_Details"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText("\f");
                                            continue;
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString().Trim());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }

                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name);
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            oWordApp.Selection.TypeText(Phone.ToString());
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Renewal Date of First Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal);
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(renewdate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewdate.ToString()).Year.ToString());
                                        continue;
                                    }

                                    // For header and sub header field writing starts here
                                    if (fieldName.Contains("WHAT’S INSIDE THIS GUIDE?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("WHAT’S INSIDE THIS GUIDE?");
                                        continue;
                                    }

                                    if (fieldName.Contains("INTRODUCTION"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("INTRODUCTION");
                                        continue;
                                    }

                                    if (fieldName.Contains("Takes Your Wellness Seriously"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Takes Your Wellness Seriously");
                                        continue;
                                    }

                                    if (fieldName.Contains("EMPLOYEE CONTRIBUTION RATES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("EMPLOYEE CONTRIBUTION RATES");
                                        continue;
                                    }

                                    if (fieldName.Contains("GET MORE VALUE FROM YOUR PLANS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("GET MORE VALUE FROM YOUR PLANS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Minimize your out-of-pocket expenses"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Minimize your out-of-pocket expenses");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use the Emergency Room ONLY for emergencies"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Use the Emergency Room ONLY for emergencies");
                                        continue;
                                    }

                                    if (fieldName.Contains("Annual physical exams and cancer screening tests are 100% covered!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Annual physical exams and cancer screening tests are 100% covered!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Preventive dental care is covered 100%!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Preventive dental care is covered 100%!");
                                        continue;
                                    }

                                    if (fieldName.Contains("Save tax dollars and enroll in a Flexible Spending Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Save tax dollars and enroll in a Flexible Spending Account");
                                        continue;
                                    }

                                    if (fieldName.Contains("Rates Effective"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Effective");
                                        continue;
                                    }

                                    if (fieldName.Contains("MEDICAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("MEDICAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("DENTAL BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DENTAL BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF DENTAL BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("In-network vs. out-of-network"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("In-network vs. out-of-network");
                                        continue;
                                    }

                                    if (fieldName.Contains("Be prepared and plan ahead"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Be prepared and plan ahead");
                                        continue;
                                    }

                                    if (fieldName.Contains("VISION BENEFITS HEADING"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF VISION BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF VISION BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Using your vision benefit is easy!"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Using your vision benefit is easy!");
                                        continue;
                                    }

                                    if (fieldName.Contains("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("HEALTH AND DEPENDENT CARE SPENDING ACCOUNTS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("Use-it or lose-it benefit"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Use-it or lose-it benefit");
                                        continue;
                                    }

                                    if (fieldName.Contains("Example of tax savings"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Example of tax savings");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF DEPENDENT CARE FLEXIBLE SPENDING ACCOUNT");
                                        continue;
                                    }

                                    if (fieldName.Contains("INCOME PROTECTION BENEFIT"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("INCOME PROTECTION BENEFIT");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF BENEFITS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF BENEFITS");
                                        continue;
                                    }

                                    if (fieldName.Contains("SUMMARY OF COVERAGE FOR VOLUNTARY LIFE INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("SUMMARY OF COVERAGE FOR VOLUNTARY LIFE INSURANCE");
                                        continue;
                                    }

                                    if (fieldName.Contains("Voluntary Life Rates"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Voluntary Life Rates");
                                        continue;
                                    }

                                    if (fieldName.Contains("VALUE-ADDED PROGRAMS AND SERVICES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("VALUE-ADDED PROGRAMS AND SERVICES");
                                        continue;
                                    }

                                    if (fieldName.Contains("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("ADDITIONAL BENEFITS FOR ELIGIBLE EMPLOYEES");
                                        continue;
                                    }

                                    if (fieldName.Contains("CONTACT NUMBERS & WEBSITE LINKS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("CONTACT NUMBERS & WEBSITE LINKS");
                                        continue;
                                    }

                                    if (fieldName.Contains("THE BENEFIT RESOURCE CENTER"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("THE BENEFIT RESOURCE CENTER");
                                        continue;
                                    }

                                    if (fieldName.Contains("If you have any questions, please contact the following:"))
                                    {
                                        myMergeField.Select();
                                        // oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("If you have any questions, please contact the following:");
                                        continue;
                                    }

                                    if (fieldName.Contains("REQUIRED NOTIFICATIONS"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("REQUIRED NOTIFICATIONS");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call the BRC for assistance with:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call the BRC for assistance with:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Call Toll Free"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Call Toll Free");
                                        continue;
                                    }

                                    if (fieldName.Contains("or email"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("or email");
                                        continue;
                                    }

                                    if (fieldName.Contains("This guide is provided to you by"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("This guide is provided to you by");
                                        continue;
                                    }

                                    if (fieldName.Contains("and BRC"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("and");
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, string color)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(11, "45");   //Calendar Year Deductible individual
                HashtableMedicalInNetwork1.Add(1, "44");    //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(22, "53");   //Calendar Year Out of Pocket Maximum (Individual)
                HashtableMedicalInNetwork1.Add(2, "52");    //Calendar Year Out of Pocket Maximum (Family)


                Hashtable HashtableMedicalInNetwork2 = new Hashtable();
                HashtableMedicalInNetwork2.Add(2, "112");   //General Plan Information Coinsurence
                HashtableMedicalInNetwork2.Add(3, "386");   //Physician Office Visit (Primary)
                HashtableMedicalInNetwork2.Add(4, "414");   //Specialists Office Visit
                HashtableMedicalInNetwork2.Add(5, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork2.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalInNetwork2.Add(77, "295");  //Inpatient Hospitalization
                HashtableMedicalInNetwork2.Add(7, "409");   //Hospital/Facility [Outpatient Care]
                HashtableMedicalInNetwork2.Add(8, "184");   //Emergency Room
                HashtableMedicalInNetwork2.Add(9, "555");   //Urgent Care

                Hashtable HashtableMedicalOutNetwork2 = new Hashtable();
                HashtableMedicalOutNetwork2.Add(2, "112");   //General Plan Information Coinsurence
                HashtableMedicalOutNetwork2.Add(3, "386");   //Physician Office Visit (Primary)
                HashtableMedicalOutNetwork2.Add(4, "414");   //Specialists Office Visit
                HashtableMedicalOutNetwork2.Add(5, "16");    //Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalOutNetwork2.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalOutNetwork2.Add(77, "295");  //Inpatient Hospitalization
                HashtableMedicalOutNetwork2.Add(7, "409");   //Hospital/Facility [Outpatient Care]
                HashtableMedicalOutNetwork2.Add(8, "184");   //Emergency Room
                HashtableMedicalOutNetwork2.Add(9, "555");   //Urgent Care
                #endregion

                int count = 1;
                string InNetwork_Indivisual_Plan1 = string.Empty;
                string InNetwork_Family_Plan1 = string.Empty;
                string OutOfPocket_Individual_Plan1 = string.Empty;
                string Inpatient_Hospitalization_Plan1 = string.Empty;

                int TableNo = 6;
                int TableNo_FirstTable = 5;

                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            foreach (int key in HashtableMedicalInNetwork1.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            TableNo_FirstTable = 5;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = font_color(color);

                                            TableNo = 6;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = font_color(color);
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            TableNo_FirstTable = 7;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = font_color(color);

                                            TableNo = 8;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = font_color(color);
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            TableNo_FirstTable = 9;
                                            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = font_color(color);

                                            TableNo = 10;
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                            oWordDoc.Tables[TableNo].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                            oWordDoc.Tables[TableNo].Range.Font.Color = font_color(color);
                                            for (int i = 2; i < oWordDoc.Tables[TableNo].Rows.Count; i = i + 2)
                                            {
                                                oWordDoc.Tables[TableNo].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                            }
                                        }

                                        if (key == 22)
                                        {
                                            OutOfPocket_Individual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 2)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (OutOfPocket_Individual_Plan1 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n";
                                        }
                                        else if (key == 11)
                                        {
                                            InNetwork_Indivisual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 1)
                                        {
                                            InNetwork_Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (InNetwork_Indivisual_Plan1 + " / " + dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + "\n";
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableMedicalInNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork2[key].ToString())
                                    {
                                        if (key == 2)
                                        {
                                            if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " unless otherwise noted below";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = " ";
                                            }
                                        }
                                        else if (key == 77)
                                        {
                                            Inpatient_Hospitalization_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 7)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = Inpatient_Hospitalization_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            #region Out of Network
                            foreach (int key in HashtableMedicalOutNetwork2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork2[key].ToString())
                                    {
                                        if (key == 2)
                                        {
                                            if ((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() != "")
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " unless otherwise noted below";
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = " ";
                                            }
                                        }
                                        else if (key == 77)
                                        {
                                            Inpatient_Hospitalization_Plan1 = "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 7)
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = Inpatient_Hospitalization_Plan1 + "\n" + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[TableNo].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion
                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Medical Carrier Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(" " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("HMO_Med_Plan_" + count))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical HMO")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("PPO_Med_Plan_" + count))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical PPO")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (count == 1)
                                    {
                                        if (fieldName.Contains("First Medical Plan Year"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                            continue;
                                        }

                                        if (fieldName.Contains("First Medical Plan Expiry Date"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"]).ToShortDateString().ToString());
                                            continue;
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string color)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string NoOfDaysSupply = "";
                string Preferred_Specialty = "";
                int rowcount = 10;
                int colcount = 2;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "380");   //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs.Add(5, "881");   //Prescription Categories[Preferred Specialty]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");    //Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");     //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");     //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(4, "380");    //Prescription Categories[Maximum Day Supply]
                HashtablePrescriptionDrugs_OutNetwork.Add(5, "881");   //Prescription Categories[Preferred Specialty]

                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                HashtableMailOrder.Add(1, "211");   //Mail Order[Generic]
                HashtableMailOrder.Add(2, "76");    //Mail Order[Formulary]
                HashtableMailOrder.Add(3, "82");    //Mail Order[Non Formulary]
                HashtableMailOrder.Add(4, "378");   //Mail Order[Maximum Day Supply]
                HashtableMailOrder.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                #region MailOrder_OutNetwork
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                HashtableMailOrder_OutNetwork.Add(1, "211");    //Mail Order[Generic]
                HashtableMailOrder_OutNetwork.Add(2, "76");     //Mail Order[Formulary]
                HashtableMailOrder_OutNetwork.Add(3, "82");     //Mail Order[Non Formulary]
                HashtableMailOrder_OutNetwork.Add(4, "378");    //Mail Order[Maximum Day Supply]
                HashtableMailOrder_OutNetwork.Add(5, "884");    //Mail Order[Preferred Specialty]
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    # region Priscription Drugs IN_Network

                    value = "";
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";
                    NoOfDaysSupply = "";
                    Preferred_Specialty = "";

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;


                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }
                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }
                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(10, 2).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(10, 2).Range.Text = value;
                            }
                    #endregion

                            # region Priscription Drugs Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            NoOfDaysSupply = "";
                            Preferred_Specialty = "";

                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }
                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(10, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(10, 3).Range.Text = value;
                            }
                            #endregion

                            #region Mail Order In_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            NoOfDaysSupply = "";
                            Preferred_Specialty = "";
                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }
                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(11, 2).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(11, 2).Range.Text = value;
                            }
                            #endregion

                            #region Mail Order Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            NoOfDaysSupply = "";
                            Preferred_Specialty = "";
                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        switch (key)
                                        {
                                            case 1: Generic = "\n" + value + "\n"; break;
                                            case 2: Formulary = value + "\n"; break;
                                            case 3: NonFormulary = value + "\n"; break;
                                            case 5: Preferred_Specialty = value + "\n"; break;
                                            case 4: NoOfDaysSupply = value; break;
                                        }
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Generic))
                            {
                                Generic = "\n" + Generic + "\n";
                            }
                            if (string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + "\n";
                            }
                            if (string.IsNullOrEmpty(NonFormulary))
                            {
                                NonFormulary = NonFormulary + "\n";
                            }
                            if (string.IsNullOrEmpty(Preferred_Specialty))
                            {
                                Preferred_Specialty = Preferred_Specialty + "\n";
                            }

                            value = Generic + Formulary + NonFormulary + Preferred_Specialty + NoOfDaysSupply;

                            if (count == 1)
                            {
                                oWordDoc.Tables[6].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[8].Cell(11, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[10].Cell(11, 3).Range.Text = value;
                            }

                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            NoOfDaysSupply = "";
                            Preferred_Specialty = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="DentalBenefitColumnIdOutNetworkList">DentalBenefitColumnIdOutNetworkList contain out Network Benefit ColumnId for Dental Plan</param>
        public void WriteDentalSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, ArrayList DentalBenefitColumnIdOutNetworkList, string color)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(2, "164");     //Preventive & Diagnostic Care 
                HashtableDentalInNetwork.Add(4, "64");      //Basic Restorative Care - Basic  
                HashtableDentalInNetwork.Add(6, "336");     //Major Restorative Care - Major 
                HashtableDentalInNetwork.Add(8, "314");     //Orthodontia [Lifetime Orthodontia Maximum]
                HashtableDentalInNetwork.Add(88, "392");    //Orthodontic Services 
                HashtableDentalInNetwork.Add(9, "152");     //Orthodontia [Dependent Children]

                #endregion
                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(2, "164");     //Preventive & Diagnostic Care 
                HashtableDentalOutNetwork.Add(4, "64");      //Basic Restorative Care - Basic 
                HashtableDentalOutNetwork.Add(6, "336");     //Major Restorative Care - Major 
                HashtableDentalOutNetwork.Add(8, "314");     //Orthodontia [Lifetime Orthodontia Maximum]
                HashtableDentalOutNetwork.Add(88, "392");    //Orthodontic Services 
                //HashtableDentalOutNetwork.Add(9, "152");     //Orthodontia [Dependent Children]

                #endregion
                int count = 1;

                string Orthodontia_Lifetime_Maximum = "";
                string Orthodontia_Dependent_Children = "";
                string Website = string.Empty;
                string Phone_Number = string.Empty;
                string value = "";
                ConstantValue cv = new ConstantValue();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            Orthodontia_Dependent_Children = "";
                            Website = "";
                            Phone_Number = "";

                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (foundRows.Count() > 0)
                            {
                                Website = Convert.ToString(foundRows[0]["Website"].ToString());
                                Phone_Number = Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                            }

                            #region color
                            if (count == 1)
                            {
                                oWordDoc.Tables[11].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                oWordDoc.Tables[11].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                oWordDoc.Tables[11].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                oWordDoc.Tables[11].Range.Font.Color = font_color(color);
                                for (int i = 2; i < oWordDoc.Tables[11].Rows.Count; i = i + 2)
                                {
                                    oWordDoc.Tables[11].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                }
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[12].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                oWordDoc.Tables[12].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                oWordDoc.Tables[12].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                oWordDoc.Tables[12].Range.Font.Color = font_color(color);
                                for (int i = 2; i < oWordDoc.Tables[12].Rows.Count; i = i + 2)
                                {
                                    oWordDoc.Tables[12].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                }
                            }
                            #endregion
                            #region DentalTable

                            #region Dental InNetwork
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 8: Orthodontia_Lifetime_Maximum = value; break;
                                                case 9: Orthodontia_Dependent_Children = value; break;
                                                case 88:
                                                    oWordDoc.Tables[11].Cell(8, 2).Range.Text = value + " up to a lifetime maximum of " + Orthodontia_Lifetime_Maximum;
                                                    break;
                                            }

                                            if (key != 88 && key != 9 && key != 8)
                                            {
                                                oWordDoc.Tables[11].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 8: Orthodontia_Lifetime_Maximum = value; break;
                                                case 9: Orthodontia_Dependent_Children = value; break;
                                                case 88:
                                                    oWordDoc.Tables[12].Cell(8, 2).Range.Text = value + " up to a lifetime maximum of " + Orthodontia_Lifetime_Maximum;
                                                    break;
                                            }

                                            if (key != 88 && key != 9 && key != 8)
                                            {
                                                oWordDoc.Tables[12].Cell(key, 2).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region Dental OutOfNetwork
                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 88: Orthodontia_Lifetime_Maximum = value; break;
                                                case 8:
                                                    oWordDoc.Tables[11].Cell(key, 3).Range.Text = Orthodontia_Lifetime_Maximum + " up to a lifetime maximum of " + value;
                                                    break;
                                            }

                                            if (key != 88 && key != 8)
                                            {
                                                oWordDoc.Tables[11].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 88: Orthodontia_Lifetime_Maximum = value; break;
                                                case 8:
                                                    oWordDoc.Tables[12].Cell(key, 3).Range.Text = Orthodontia_Lifetime_Maximum + " up to a lifetime maximum of " + value;
                                                    break;
                                            }

                                            if (key != 88 && key != 8)
                                            {
                                                oWordDoc.Tables[12].Cell(key, 3).Range.Text = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Dental Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("Dental Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Plan Carrier_" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" " + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("In Network – Orthodontia Services – Dependent Children " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Orthodontia_Dependent_Children.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Orthodontia_Dependent_Children.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental Carrier Website " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Website.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Website);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Dental carrier phone number " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Phone_Number.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Phone_Number);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteVisionSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, ArrayList VisionBenefitColumnIdOutNetworkList, DataTable CarrierSpecific, string color)
        {
            try
            {
                DataRow[] foundRows = null;
                ConstantValue cv = new ConstantValue();
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitInNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(55, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(5, "194");      //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork.Add(71, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(72, "73");      //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitInNetwork.Add(73, "553");     //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitInNetwork.Add(74, "311");     //Covered Services – Lenses – Lenticular Lens
                HashtableVisionBenefitInNetwork.Add(7, "309");      //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitInNetwork.Add(99, "208");     //Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(9, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork.Add(16, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefitInNetwork.Add(15, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitInNetwork.Add(11, "122");     //General Plan Information – Benefit Frequency – Contacts


                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();
                #endregion

                Hashtable HashtableVisionBenefitOutNetwork = new Hashtable();

                #region HastableVisionBenefit
                HashtableVisionBenefitOutNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitOutNetwork.Add(55, "195");     //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitOutNetwork.Add(5, "194");      //General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitOutNetwork.Add(71, "507");     //Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitOutNetwork.Add(72, "73");      //Covered Services – Lenses – Bifocal Lens
                HashtableVisionBenefitOutNetwork.Add(73, "553");     //Covered Services – Lenses – Trifocal Lens
                HashtableVisionBenefitOutNetwork.Add(74, "311");     //Covered Services – Lenses – Lenticular Lens
                HashtableVisionBenefitOutNetwork.Add(7, "309");      //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitOutNetwork.Add(99, "208");     //Covered Services – Frames
                HashtableVisionBenefitOutNetwork.Add(9, "207");      //General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitOutNetwork.Add(16, "178");     //Covered Services – Contact Lenses - Elective
                HashtableVisionBenefitOutNetwork.Add(15, "356");     //Covered Services – Contact Lenses – Medically Necessary
                HashtableVisionBenefitOutNetwork.Add(11, "122");     //General Plan Information – Benefit Frequency – Contacts

                ArrayList arrVisionBenefitOutNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitOutNetwork.Keys)
                {
                    arrVisionBenefitOutNetwork.Add(key);
                }

                arrVisionBenefitOutNetwork.Sort();
                arrVisionBenefitOutNetwork.Reverse();
                #endregion

                string Copay_Examination_Deductible = string.Empty;
                string CoveredServices_Lenses_Single_Vision = string.Empty;
                string CoveredServices_Lenses_Bifocal = string.Empty;
                string CoveredServices_Lenses_Trifocal = string.Empty;
                string CoveredServices_Lenses_Lenticular = string.Empty;
                string CoveredServices_Frames = string.Empty;
                string CoveredServices_ContactLenses_Elective = string.Empty;
                string CoveredServices_ContactLenses_MedicallyNecessary = string.Empty;

                string Website = string.Empty;
                string Phone_Number = string.Empty;

                int iTotalFields = 0;
                int count = 1;

                string value = "";
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            if (foundRows.Count() > 0)
                            {
                                Website = Convert.ToString(foundRows[0]["Website"].ToString());
                                Phone_Number = Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                            }
                            # region VisionBenefitTable

                            #region color
                            if (count == 1)
                            {
                                oWordDoc.Tables[13].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                oWordDoc.Tables[13].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                oWordDoc.Tables[13].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                oWordDoc.Tables[13].Range.Font.Color = font_color(color);
                                for (int i = 2; i < oWordDoc.Tables[13].Rows.Count; i = i + 2)
                                {
                                    oWordDoc.Tables[13].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                }
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[14].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                oWordDoc.Tables[14].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                oWordDoc.Tables[14].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                oWordDoc.Tables[14].Range.Font.Color = font_color(color);
                                for (int i = 2; i < oWordDoc.Tables[14].Rows.Count; i = i + 2)
                                {
                                    oWordDoc.Tables[14].Rows[i].Range.Shading.BackgroundPatternColor = cell_color(color);
                                }
                            }
                            #endregion

                            if (count == 2)
                            {
                                Copay_Examination_Deductible = "";
                                CoveredServices_Lenses_Single_Vision = "";
                                CoveredServices_Lenses_Bifocal = "";
                                CoveredServices_Lenses_Trifocal = "";
                                CoveredServices_Lenses_Lenticular = "";
                                CoveredServices_Frames = "";
                                CoveredServices_ContactLenses_Elective = "";
                                CoveredServices_ContactLenses_MedicallyNecessary = "";
                            }

                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[13].Cell(key, 2).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[13].Cell(key, 2).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[13].Cell(key, 2).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[13].Cell(key, 2).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[13].Cell(key, 2).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[14].Cell(key, 2).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[14].Cell(key, 2).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[14].Cell(key, 2).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[14].Cell(key, 2).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[14].Cell(key, 2).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (int key in arrVisionBenefitOutNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitOutNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[13].Cell(key, 3).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[13].Cell(key, 3).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[13].Cell(key, 3).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[13].Cell(key, 3).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[13].Cell(key, 3).Range.Text = value;
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                            switch (key)
                                            {
                                                case 55: Copay_Examination_Deductible = value; break;
                                                case 71: CoveredServices_Lenses_Single_Vision = value; break;
                                                case 72: CoveredServices_Lenses_Bifocal = value; break;
                                                case 73: CoveredServices_Lenses_Trifocal = value; break;
                                                case 74: CoveredServices_Lenses_Lenticular = value; break;
                                                case 99: CoveredServices_Frames = value; break;
                                                case 16: CoveredServices_ContactLenses_Elective = value; break;
                                                case 15: CoveredServices_ContactLenses_MedicallyNecessary = value; break;

                                                case 5: oWordDoc.Tables[14].Cell(key, 3).Range.Text = Copay_Examination_Deductible + " \n" + value; break;
                                                case 7: oWordDoc.Tables[14].Cell(key, 3).Range.Text = CoveredServices_Lenses_Single_Vision + " \n" + CoveredServices_Lenses_Bifocal + "\n" + CoveredServices_Lenses_Trifocal + "\n" + CoveredServices_Lenses_Lenticular + "\n" + value; break;
                                                case 9: oWordDoc.Tables[14].Cell(key, 3).Range.Text = CoveredServices_Frames + "\n" + value; break;
                                                case 11: oWordDoc.Tables[14].Cell(key, 3).Range.Text = CoveredServices_ContactLenses_Elective + " \n" + CoveredServices_ContactLenses_MedicallyNecessary + "\n" + value; break;
                                            }
                                            if (key != 55 && key != 71 && key != 72 && key != 73 && key != 74 && key != 99 && key != 16 && key != 15 && key != 5 && key != 7 && key != 9 && key != 11)
                                            {
                                                oWordDoc.Tables[14].Cell(key, 3).Range.Text = value;
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Vision Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText("Vision Insurance");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Carrier Name_" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["Carrier"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Plan Type Name " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Benefit Summary Description " + count))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Carrier Website " + count))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Website.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Website);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision carrier phone number " + count))
                                    {
                                        myMergeField.Select();
                                        //oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (!string.IsNullOrEmpty(Phone_Number.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Phone_Number);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlLTDNoOfPlan, DropDownList ddlClient, DropDownList ddlSTDPlanName, DropDownList ddlLifeADDNoOfPlan, DropDownList ddlSTDNoOfPlan, string color)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(2, "505");     //STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");      //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment
                #endregion

                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string ProductName = "";

                string value = "";
                bool isSTDPlan_Selected = false;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        isSTDPlan_Selected = true;
                    }
                }

                oWordDoc.Tables[16].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                oWordDoc.Tables[16].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                oWordDoc.Tables[16].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                oWordDoc.Tables[16].Range.Font.Color = font_color(color);

                if (isSTDPlan_Selected == false)
                {
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0 || ddlSTDNoOfPlan.SelectedIndex > 0 || ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Life_STD_LTD_Plan"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);

                                    oWordApp.Selection.TypeText(" ");
                                }

                                if (fieldName.Contains("STD General Information – Elimination Period – Accident"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (fieldName.Contains("STD General Information – Elimination Period – Sickness"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }

                                if (fieldName.Contains("STD General Information – Maximum Period of Payment"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                        }
                    }
                }
                else
                {
                    for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                    {
                        if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                        {
                            if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                            {
                                #region STD
                                ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                                foreach (int key in HashtableSTD.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                        {
                                            value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            switch (key)
                                            {
                                                case 1:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Accident = value.Trim().Replace("days", "").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Accident = value.Trim();
                                                    }
                                                    break;
                                                case 2:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim().Replace("days", "").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim();
                                                    }
                                                    break;
                                                case 3: Benefit_Percentage = value.Trim(); break;
                                                case 4: Weekly_Benefit_Maximum = value.Trim(); break;
                                                case 5: Maximum_Period_of_Payment = (dr["value"].ToString() + " " + dr["UOM"].ToString()).Trim(); break;
                                            }
                                        }
                                    }
                                }
                                #endregion

                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();

                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("STD General Information – Elimination Period – Accident"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Accident))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Accident);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD General Information – Elimination Period – Sickness"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Sickness))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Sickness);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("STD General Information – Maximum Period of Payment"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                            {
                                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                    }
                                }
                                #endregion
                                count++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteLifeADDBenifitToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, DropDownList ddlLifeADDNoOfPlan, DropDownList ddlSTDNoOfPlan, DropDownList ddlLTDNoOfPlan, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                string Overall_Max_Employee = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();
                double benefitamount = 0;
                string age = "";
                string age_to = "";
                #region HashtableGroupLifeADDBenifit
                HashtableGroupLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(7, "517");//Spouse[Benefit Amount]
                HashtableGroupLifeADDBenifit.Add(8, "519");//Spouse[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(9, "518");//Spouse[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(10, "467"); // Reduction of Benefits
                HashtableGroupLifeADDBenifit.Add(11, "102");//Child(ren)[Benefit Amount] 
                HashtableGroupLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum] 
                HashtableGroupLifeADDBenifit.Add(13, "103");//Child(ren)[Guarantee Issue Amount]
                HashtableGroupLifeADDBenifit.Add(14, "2");//age
                HashtableGroupLifeADDBenifit.Add(15, "3");//age
                HashtableGroupLifeADDBenifit.Add(16, "4");//age
                HashtableGroupLifeADDBenifit.Add(17, "5");//age

                #endregion

                bool isLifeAdd_Is_Selected = false;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        isLifeAdd_Is_Selected = true;
                    }
                }

                oWordDoc.Tables[16].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                oWordDoc.Tables[16].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                oWordDoc.Tables[16].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                oWordDoc.Tables[16].Range.Font.Color = font_color(color);
                if (isLifeAdd_Is_Selected == false)
                {
                    if (ddlLifeADDNoOfPlan.SelectedIndex > 0 || ddlSTDNoOfPlan.SelectedIndex > 0 || ddlLTDNoOfPlan.SelectedIndex > 0)
                    {
                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                        {
                            iTotalFields++;

                            Word.Range rngFieldCode = myMergeField.Code;

                            String fieldText = rngFieldCode.Text;

                            if (fieldText.StartsWith(" MERGEFIELD"))
                            {
                                Int32 endMerge = fieldText.IndexOf("\\");
                                if (endMerge == -1)
                                {
                                    endMerge = fieldText.Length;
                                }

                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                fieldName = fieldName.Trim();

                                if (fieldName.Contains("Life_STD_LTD_Plan"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (fieldName.Contains("age_from"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (fieldName.Contains("age_to"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (fieldName.Contains("Life ADD General Plan Information – Overall Maximum – Employee"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                        }
                    }
                }
                else
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                #region GroupLifeADDBenifitTable
                                if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                                {
                                    OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                                }

                                /* The following line changed beacause we merging the first cell of table to Display the carrier name in correct format*/
                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 4)
                                            {
                                                Overall_Max_Employee = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            }

                                            value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                            int ch = int.Parse(dr["attributeID"].ToString());
                                            switch (ch)
                                            {
                                                case 2: if (value.Trim() != string.Empty) { age = value; } break;       // 65-69
                                                case 3: if (value.Trim() != string.Empty) { age = value; } break;       // 70-74
                                                case 4: if (value.Trim() != string.Empty) { age_to = value; } break;    // 75-79
                                                case 5: if (value.Trim() != string.Empty) { age = value; } break;       // 80-84
                                                case 186:
                                                    if (dr["value"].ToString().Trim() != "")
                                                    {
                                                        string str = dr["value"].ToString().Trim();
                                                        bool isNum = double.TryParse(str, out benefitamount);
                                                        if (isNum)
                                                        {
                                                        }
                                                        else
                                                        {
                                                            benefitamount = 0;
                                                        }
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0; break;
                                                    }
                                            }
                                        }
                                    }
                                }
                                #endregion

                                #region merge fields
                                foreach (Word.Field myMergeField in oWordDoc.Fields)
                                {
                                    iTotalFields++;

                                    Word.Range rngFieldCode = myMergeField.Code;

                                    String fieldText = rngFieldCode.Text;

                                    if (fieldText.StartsWith(" MERGEFIELD"))
                                    {
                                        Int32 endMerge = fieldText.IndexOf("\\");
                                        if (endMerge == -1)
                                        {
                                            endMerge = fieldText.Length;
                                        }

                                        Int32 fieldNameLength = fieldText.Length - endMerge;

                                        String fieldName = fieldText.Substring(11, endMerge - 11);

                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            oWordApp.Selection.TypeText(" ");
                                        }

                                        if (fieldName.Contains("age_from"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (!string.IsNullOrEmpty(age.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(age.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("age_to"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (!string.IsNullOrEmpty(age_to.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(age_to.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("Life ADD General Plan Information – Overall Maximum – Employee"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = font_color(color);
                                            if (!string.IsNullOrEmpty(Overall_Max_Employee.Trim()))
                                            {
                                                oWordApp.Selection.TypeText(Overall_Max_Employee.Trim());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                    }
                                }
                                #endregion
                                count++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Table of contents information (Header and page numbers) based upon the plans selected
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ddlAnnualLegalNotice">Dropdown list for AnnualLegalNotice</param>
        /// <param name="ddlChipNotice">Dropdown list for ChipNotice</param>
        /// <param name="ddlBRC">Dropdown list for BRC</param>

        #region TOC
        public void WriteTableOfContentInformationToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DropDownList ddlAnnualLegalNotice, DropDownList ddlChipNotice, DropDownList ddlBRC, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();

                int k = 1;
                string carriername = "";
                string plantype = "";
                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;
                int rowCnt = 3;

                // Update Table of Content
                int contentPageNo = 9;
                int contentRowCnt = 5;

                int medicalCnt = 0;
                int dentalCnt = 0;
                int visionCnt = 0;
                bool isDental = false;
                bool isVision = false;
                bool isFSA = false;
                bool isSummary = false;
                bool isValueAdded = false;
                bool isAddition_Benefit_Taken = false;
                bool isRequiredNotification = false;
                bool isContact_Info_Taken = false;
                bool isBRC = false;
                bool isLife_STD_LTD = false;

                // Create the arraylist for the headers other than default headers in the table
                ArrayList arrTOC = new ArrayList();
                arrTOC.Add("Dental Benefits");
                arrTOC.Add("Vision Benefits");
                arrTOC.Add("Health and Dependent Care Spending Accounts");
                arrTOC.Add("Income Protection Benefit");
                arrTOC.Add("Summary of Coverage For Voluntary Life Insurance");
                arrTOC.Add("Value-added Programs and Services");
                arrTOC.Add("Additional Benefits for Eligible Employees");
                arrTOC.Add("Contact Numbers & Website Links");
                arrTOC.Add("The Benefit Resource Center");
                arrTOC.Add("Required Notifications");

                // Check for the number of medical, dental and vision plans so that we can adjust the page numbers accordingly
                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    plantype = PlanTable.Rows[i]["PlanType"].ToString();
                    if (plantype == cv.MedicalPlanType)
                    {
                        medicalCnt++;
                    }
                    if (plantype == cv.DentalPlanType)
                    {
                        dentalCnt++;
                    }
                    if (plantype == cv.VisionPlanType)
                    {
                        visionCnt++;
                    }
                }

                // Based on the number of medical plans selected change the page number
                if (medicalCnt == 1)
                {
                    contentPageNo = 7;
                }
                else if (medicalCnt == 2)
                {
                    contentPageNo = 8;
                }
                else if (medicalCnt == 3)
                {
                    contentPageNo = 9;
                }

                int characterLength = 0;
                int lengthDifference = 0;
                string tmpVar = string.Empty;

                for (int j = 0; j < arrTOC.Count; j++)
                {
                    for (int i = 0; i < PlanTable.Rows.Count; i++)
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();

                        // For Dental
                        if (j == 0)
                        {
                            if (plantype == cv.DentalPlanType)
                            {
                                if (isDental == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();

                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[0].ToString().Length;
                                    lengthDifference = 80 - characterLength;
                                    tmpVar = arrTOC[0].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    contentRowCnt++;
                                    if (dentalCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    isDental = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For Vision
                        if (j == 1)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.VisionPlanType)
                            {
                                if (isVision == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[1].ToString().Length;
                                    lengthDifference = 81 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 81 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 81 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[1].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    if (visionCnt == 2)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }
                                    else
                                    {
                                        contentPageNo++;
                                    }
                                    isVision = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For FSA
                        if (j == 2)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.FSAPlanType)
                            {
                                if (isFSA == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[2].ToString().Length;
                                    lengthDifference = 57 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 57 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 57 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[2].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isFSA = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For if Life ADD / LTD / STD is selected
                        if (j == 3)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isLife_STD_LTD == false)
                            {
                                if (plantype == cv.LifeADDPlanType || plantype == cv.STDPlanType || plantype == cv.LTDPlanType)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[3].ToString().Length;
                                    lengthDifference = 72 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 72 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[3].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isLife_STD_LTD = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For Voluntary Life
                        if (j == 4)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.VoluntaryLifeADDPlanType)
                            {
                                if (isSummary == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[4].ToString().Length;
                                    lengthDifference = 56 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 56 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 56 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[4].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isSummary = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For EAP
                        if (j == 5)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (plantype == cv.EAPPlanType)
                            {
                                if (isValueAdded == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[5].ToString().Length;
                                    lengthDifference = 65 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 65 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 65 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }

                                    tmpVar = arrTOC[5].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isValueAdded = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For Additional Benefits for Eligible Employees
                        if (j == 6)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isAddition_Benefit_Taken == false)
                            {
                                oWordDoc.Tables[3].Rows.Add();
                                // Calculate the character length for selected heading
                                characterLength = arrTOC[6].ToString().Length;
                                lengthDifference = 65 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 65 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 65 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                }
                                tmpVar = arrTOC[6].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isAddition_Benefit_Taken = true;
                                break;
                            }
                            continue;
                        }

                        // For Contact Information
                        if (j == 7)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (isContact_Info_Taken == false)
                            {
                                oWordDoc.Tables[3].Rows.Add();
                                // Calculate the character length for selected heading
                                characterLength = arrTOC[7].ToString().Length;
                                lengthDifference = 66 - characterLength;

                                if (contentPageNo.ToString().Length > 1)
                                {
                                    //lengthDifference = 66 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                }
                                else
                                {
                                    //lengthDifference = 66 - characterLength;
                                    oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                }
                                tmpVar = arrTOC[7].ToString();

                                // Append "." at the end of the header and after that the page number
                                for (int len = 0; len < lengthDifference; len++)
                                {
                                    tmpVar = tmpVar + ".";
                                }

                                oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                contentRowCnt++;
                                contentPageNo++;
                                isContact_Info_Taken = true;
                                break;
                            }
                            continue;
                        }

                        // For BRC
                        if (j == 8)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (ddlBRC.SelectedIndex > 1)
                            {
                                if (isBRC == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[8].ToString().Length;
                                    lengthDifference = 71 - characterLength;

                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        //lengthDifference = 71 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        //lengthDifference = 71 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[8].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;
                                    contentPageNo++;
                                    isBRC = true;
                                    break;
                                }
                            }
                            continue;
                        }

                        // For Notification (Annual Legal Notices)
                        if (j == 9)
                        {
                            characterLength = 0;
                            lengthDifference = 0;
                            tmpVar = "";
                            if (ddlAnnualLegalNotice.SelectedIndex > 0 || ddlChipNotice.SelectedIndex > 0)
                            {
                                if (isRequiredNotification == false)
                                {
                                    oWordDoc.Tables[3].Rows.Add();
                                    // Calculate the character length for selected heading
                                    characterLength = arrTOC[9].ToString().Length;
                                    if (contentPageNo.ToString().Length > 1)
                                    {
                                        lengthDifference = 76 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = Convert.ToString(contentPageNo);
                                    }
                                    else
                                    {
                                        lengthDifference = 78 - characterLength;
                                        oWordDoc.Tables[3].Cell(contentRowCnt, 2).Range.Text = ".." + Convert.ToString(contentPageNo);
                                    }
                                    tmpVar = arrTOC[9].ToString();

                                    // Append "." at the end of the header and after that the page number
                                    for (int len = 0; len < lengthDifference; len++)
                                    {
                                        tmpVar = tmpVar + ".";
                                    }

                                    oWordDoc.Tables[3].Cell(contentRowCnt, 1).Range.Text = tmpVar;
                                    contentRowCnt++;

                                    if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex > 0)
                                    {
                                        contentPageNo++;
                                    }
                                    else if (ddlAnnualLegalNotice.SelectedIndex > 0 && ddlChipNotice.SelectedIndex == 0)
                                    {
                                        contentPageNo++;
                                    }

                                    if (ddlChipNotice.SelectedIndex > 0)
                                    {
                                        contentPageNo = contentPageNo + 2;
                                    }

                                    isRequiredNotification = true;
                                    break;
                                }
                            }
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int DentalCount = 0;
                int MedicalCount = 0;
                int VisionCount = 0;
                ArrayList _rateid = new ArrayList();
                ArrayList arrContributionID = new ArrayList();

                string Medical_Plan_Type_Plan_1 = string.Empty;
                string Medical_Plan_Type_Plan_2 = string.Empty;
                string Medical_Plan_Type_Plan_3 = string.Empty;

                string Medical_Plan_Summary_Description_Plan_1 = string.Empty;
                string Medical_Plan_Summary_Description_Plan_2 = string.Empty;
                string Medical_Plan_Summary_Description_Plan_3 = string.Empty;

                string Dental_Plan_Type_Plan_1 = string.Empty;
                string Dental_Plan_Type_Plan_2 = string.Empty;

                string Dental_Plan_Summary_Description_Plan_1 = string.Empty;
                string Dental_Plan_Summary_Description_Plan_2 = string.Empty;

                string Vision_Plan_Type_Plan_1 = string.Empty;
                string Vision_Plan_Type_Plan_2 = string.Empty;

                string Vision_Plan_Summary_Description_Plan_1 = string.Empty;
                string Vision_Plan_Summary_Description_Plan_2 = string.Empty;

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("PlanNo");
                PremiumTableWriteMedical.Columns.Add("RateID");
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("PlanNo");
                PremiumTableWriteDental.Columns.Add("RateID");
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("PlanNo");
                PremiumTableWriteVision.Columns.Add("RateID");
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");

                oWordDoc.Tables[4].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                oWordDoc.Tables[4].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                oWordDoc.Tables[4].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                oWordDoc.Tables[4].Range.Font.Color = font_color(color);

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("contributionDescription", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                // Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                                //if (Convert.ToDecimal(ContributionDS.Tables["ContributionValueTable"].Rows[j]["ContributionValues_amount"]) != 0)
                                //{
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                premium_row_counter++;
                                //}
                            }
                        }
                    }

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);

                    //// The below for loop is for deleting rows having contribution value as 0 -- 30 May 2014
                    //for (int k = 0; k < dt.Rows.Count; k++)
                    //{
                    //    if (Convert.ToDecimal(dt.Rows[k]["contributioncost"]) == 0)
                    //    {
                    //        dt.Rows[k].Delete();
                    //        k = k - 1;
                    //    }
                    //}

                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        MedicalCount = index;
                        if (index == 0)
                        {
                            Medical_Plan_Type_Plan_1 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Medical_Plan_Summary_Description_Plan_1 = PlanTable.Rows[index]["SummaryName"].ToString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";

                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";

                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }

                        }
                        if (index == 1)
                        {
                            Medical_Plan_Type_Plan_2 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Medical_Plan_Summary_Description_Plan_2 = PlanTable.Rows[index]["SummaryName"].ToString();

                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";

                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";

                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (index == 2)
                        {
                            Medical_Plan_Type_Plan_3 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Medical_Plan_Summary_Description_Plan_3 = PlanTable.Rows[index]["SummaryName"].ToString();

                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["PlanNo"] = 3;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";

                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["PlanNo"] = 3;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";

                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Dental_Plan_Type_Plan_1 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Dental_Plan_Summary_Description_Plan_1 = PlanTable.Rows[index]["SummaryName"].ToString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            Dental_Plan_Type_Plan_2 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Dental_Plan_Summary_Description_Plan_2 = PlanTable.Rows[index]["SummaryName"].ToString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        DentalCount++;
                    }
                    #endregion

                    # region FillTable Vision

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Vision_Plan_Type_Plan_1 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Vision_Plan_Summary_Description_Plan_1 = PlanTable.Rows[index]["SummaryName"].ToString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["PlanNo"] = 1;
                                    dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            Vision_Plan_Type_Plan_2 = PlanTable.Rows[index]["ProductTypeDescription"].ToString();
                            Vision_Plan_Summary_Description_Plan_2 = PlanTable.Rows[index]["SummaryName"].ToString();
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["PlanNo"] = 2;
                                        dr["RateID"] = PremiumTable.Rows[i][0].ToString();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        VisionCount++;
                    }
                    #endregion
                }

                int RowCounter = 3;

                #region Medical Monthly Premium

                int MediCalTableColCounter = 2;
                bool isRowInserted = false;
                bool isMedicalCounterChanged = false;
                int oldPlanNo = 0;
                int currentPlanNo = 0;
                string plan1_Rate = string.Empty;
                bool isFirstValuePopulated_Med2 = false;
                bool isFirstValuePopulated_Med3 = false;

                ArrayList arrValues = new ArrayList();

                for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
                {
                    currentPlanNo = Convert.ToInt16(PremiumTableWriteMedical.Rows[d]["PlanNo"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        isMedicalCounterChanged = false;
                        isRowInserted = false;
                    }

                    if (PremiumTableWriteMedical.Rows[d]["PlanNo"].ToString() == "2" || PremiumTableWriteMedical.Rows[d]["PlanNo"].ToString() == "3")
                    {
                        if (isMedicalCounterChanged == false)
                        {
                            MediCalTableColCounter = 2;
                            isMedicalCounterChanged = true;
                        }
                    }

                    if (!arrContributionID.Contains(PremiumTableWriteMedical.Rows[d]["RateID"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteMedical.Rows[d]["RateID"].ToString());
                        oWordDoc.Tables[4].Columns.Add();
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Text = PremiumTableWriteMedical.Rows[d]["RateHeader"].ToString(); //Col Desc
                    }


                    if (PremiumTableWriteMedical.Rows[d]["PlanNo"].ToString() == "1")
                    {
                        oWordDoc.Tables[4].Cell(2, 1).Range.Text = Medical_Plan_Type_Plan_1;
                        oWordDoc.Tables[4].Cell(2, 2).Range.Text = Medical_Plan_Summary_Description_Plan_1;

                        // Commented the "monthlycost != 0" condition on the request of Nicole on 07 April 2015 

                        //if (Convert.ToDecimal(PremiumTableWriteMedical.Rows[d]["Plan1_Rate"].ToString().Substring(1, PremiumTableWriteMedical.Rows[d]["Plan1_Rate"].ToString().Length - 1)) != 0)
                        //{
                        //oWordDoc.Tables[4].Cell(RowCounter, MediCalTableColCounter).Range.Bold = 0;
                        //oWordDoc.Tables[4].Cell(RowCounter, MediCalTableColCounter).Range.Text = PremiumTableWriteMedical.Rows[d]["Plan1_Rate"].ToString(); //Contri Cost

                        ////var result = (from n in PremiumTableWriteMedical.AsEnumerable()
                        ////              where n.Field<string>("RateID") == Convert.ToString(PremiumTableWriteMedical.Rows[d]["RateID"])
                        ////              select n.Field<string>("Plan1_Rate"));

                        ////foreach (dynamic rate in result)
                        ////{
                        ////    if (!string.IsNullOrEmpty(plan1_Rate))
                        ////    {
                        ////        plan1_Rate = plan1_Rate + "\n" + rate;
                        ////    }
                        ////    else
                        ////    {
                        ////        plan1_Rate = plan1_Rate + rate;
                        ////    }
                        ////}
                        ////oWordDoc.Tables[4].Cell(RowCounter, MediCalTableColCounter).Range.Text = plan1_Rate; //Contri Cost
                        //}

                        for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                        {
                            for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                            {
                                if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteMedical.Rows[d]["RateHeader"].ToString())
                                {
                                    oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;

                                    if (!(arrValues.Contains(PremiumTableWriteMedical.Rows[d]["RateID"].ToString())))
                                    {
                                        if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteMedical.Rows[d]["Plan1_Rate"].ToString();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteMedical.Rows[d]["Plan1_Rate"].ToString(); //Contri Cost
                                        }

                                        arrValues.Add(PremiumTableWriteMedical.Rows[d]["RateID"].ToString());
                                    }
                                }
                            }
                        }
                    }
                    if (PremiumTableWriteMedical.Rows[d]["PlanNo"].ToString() == "2")
                    {
                        if (isFirstValuePopulated_Med2 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Med2 = true;
                        }

                        if (MedicalCount > 0)
                        {
                            if (isRowInserted == false)
                            {
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Medical_Plan_Type_Plan_2;
                                oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Medical_Plan_Summary_Description_Plan_2;
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";

                                isRowInserted = true;
                            }

                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                            {
                                for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                                {
                                    if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteMedical.Rows[d]["RateHeader"].ToString())
                                    {
                                        oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;
                                        if (!(arrValues.Contains(PremiumTableWriteMedical.Rows[d]["RateID"].ToString())))
                                        {
                                            if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteMedical.Rows[d]["Plan2_Rate"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteMedical.Rows[d]["Plan2_Rate"].ToString(); //Contri Cost
                                            }
                                            arrValues.Add(PremiumTableWriteMedical.Rows[d]["RateID"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (PremiumTableWriteMedical.Rows[d]["PlanNo"].ToString() == "3")
                    {
                        if (isFirstValuePopulated_Med3 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Med3 = true;
                        }
                        if (MedicalCount > 0)
                        {
                            if (isRowInserted == false)
                            {
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Medical_Plan_Type_Plan_3;
                                oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Medical_Plan_Summary_Description_Plan_3;
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";
                                isRowInserted = true;
                            }

                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                            {
                                for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                                {
                                    if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteMedical.Rows[d]["RateHeader"].ToString())
                                    {
                                        oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;
                                        if (!(arrValues.Contains(PremiumTableWriteMedical.Rows[d]["RateID"].ToString())))
                                        {
                                            if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteMedical.Rows[d]["Plan3_Rate"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteMedical.Rows[d]["Plan3_Rate"].ToString(); //Contri Cost
                                            }
                                            arrValues.Add(PremiumTableWriteMedical.Rows[d]["RateID"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    MediCalTableColCounter++;
                }
                #endregion

                #region Dental Monthly Premium
                int DentalTableColCounter = 2;
                isRowInserted = false;
                bool isDentalCounterChanged = false;
                oldPlanNo = 0;
                currentPlanNo = 0;
                bool isFirstValuePopulated_Dental1 = false;
                bool isFirstValuePopulated_Dental2 = false;

                for (int d = 0; d < PremiumTableWriteDental.Rows.Count; d++)
                {
                    currentPlanNo = Convert.ToInt16(PremiumTableWriteDental.Rows[d]["PlanNo"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        isDentalCounterChanged = false;
                        isRowInserted = false;
                    }

                    if (PremiumTableWriteDental.Rows[d]["PlanNo"].ToString() == "2")
                    {
                        if (isDentalCounterChanged == false)
                        {
                            DentalTableColCounter = 2;
                            isDentalCounterChanged = true;
                        }
                    }

                    if (!arrContributionID.Contains(PremiumTableWriteDental.Rows[d]["RateID"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteDental.Rows[d]["RateID"].ToString());
                        oWordDoc.Tables[4].Columns.Add();
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Text = PremiumTableWriteDental.Rows[d]["RateHeader"].ToString(); //Col Desc
                    }

                    if (PremiumTableWriteDental.Rows[d]["PlanNo"].ToString() == "1")
                    {
                        if (isFirstValuePopulated_Dental1 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Dental1 = true;
                        }
                        if (isRowInserted == false)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                            RowCounter = RowCounter + 1;
                            oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Dental_Plan_Type_Plan_1;
                            oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Dental_Plan_Summary_Description_Plan_1;
                            oWordDoc.Tables[4].Rows.Add();
                            RowCounter = RowCounter + 1;
                            oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";

                            isRowInserted = true;
                        }

                        for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                        {
                            for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                            {
                                if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteDental.Rows[d]["RateHeader"].ToString())
                                {
                                    oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;

                                    if (!(arrValues.Contains(PremiumTableWriteDental.Rows[d]["RateID"].ToString())))
                                    {
                                        if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteDental.Rows[d]["Plan1_Rate"].ToString();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteDental.Rows[d]["Plan1_Rate"].ToString(); //Contri Cost
                                        }
                                        arrValues.Add(PremiumTableWriteDental.Rows[d]["RateID"].ToString());
                                    }
                                }
                            }
                        }
                    }
                    if (PremiumTableWriteDental.Rows[d]["PlanNo"].ToString() == "2")
                    {
                        if (isFirstValuePopulated_Dental2 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Dental2 = true;
                        }
                        if (DentalCount > 0)
                        {
                            if (isRowInserted == false)
                            {
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Dental_Plan_Type_Plan_2;
                                oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Dental_Plan_Summary_Description_Plan_2;
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";

                                isRowInserted = true;
                            }

                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                            {
                                for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                                {
                                    if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteDental.Rows[d]["RateHeader"].ToString())
                                    {
                                        oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;

                                        if (!(arrValues.Contains(PremiumTableWriteDental.Rows[d]["RateID"].ToString())))
                                        {
                                            if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteDental.Rows[d]["Plan2_Rate"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteDental.Rows[d]["Plan2_Rate"].ToString(); //Contri Cost
                                            }
                                            arrValues.Add(PremiumTableWriteDental.Rows[d]["RateID"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }

                    DentalTableColCounter++;
                }
                #endregion

                #region Vision Monthly Premium
                int VisionTableColCounter = 2;
                isRowInserted = false;
                bool isVisionCounterChanged = false;
                oldPlanNo = 0;
                currentPlanNo = 0;
                bool isFirstValuePopulated_Vision1 = false;
                bool isFirstValuePopulated_Vision2 = false;

                for (int d = 0; d < PremiumTableWriteVision.Rows.Count; d++)
                {
                    currentPlanNo = Convert.ToInt16(PremiumTableWriteVision.Rows[d]["PlanNo"]);
                    if (currentPlanNo != oldPlanNo)
                    {
                        oldPlanNo = currentPlanNo;
                        isVisionCounterChanged = false;
                        isRowInserted = false;
                    }

                    if (PremiumTableWriteVision.Rows[d]["PlanNo"].ToString() == "2")
                    {
                        if (isVisionCounterChanged == false)
                        {
                            VisionTableColCounter = 2;
                            isVisionCounterChanged = true;
                        }
                    }

                    if (!arrContributionID.Contains(PremiumTableWriteVision.Rows[d]["RateID"].ToString()))
                    {
                        arrContributionID.Add(PremiumTableWriteVision.Rows[d]["RateID"].ToString());
                        oWordDoc.Tables[4].Columns.Add();
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Bold = 1;
                        oWordDoc.Tables[4].Cell(1, oWordDoc.Tables[4].Columns.Count).Range.Text = PremiumTableWriteVision.Rows[d]["RateHeader"].ToString(); //Col Desc
                    }

                    if (PremiumTableWriteVision.Rows[d]["PlanNo"].ToString() == "1")
                    {
                        if (isFirstValuePopulated_Vision1 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Vision1 = true;
                        }
                        if (isRowInserted == false)
                        {
                            oWordDoc.Tables[4].Rows.Add();
                            RowCounter = RowCounter + 1;
                            oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Vision_Plan_Type_Plan_1;
                            oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Vision_Plan_Summary_Description_Plan_1;
                            oWordDoc.Tables[4].Rows.Add();
                            RowCounter = RowCounter + 1;
                            oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";

                            isRowInserted = true;
                        }

                        for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                        {
                            for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                            {
                                if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteVision.Rows[d]["RateHeader"].ToString())
                                {
                                    oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;

                                    if (!(arrValues.Contains(PremiumTableWriteVision.Rows[d]["RateID"].ToString())))
                                    {
                                        if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteVision.Rows[d]["Plan1_Rate"].ToString();
                                        }
                                        else
                                        {
                                            oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteVision.Rows[d]["Plan1_Rate"].ToString(); //Contri Cost
                                        }
                                        arrValues.Add(PremiumTableWriteVision.Rows[d]["RateID"].ToString());
                                    }
                                }
                            }
                        }
                    }
                    if (PremiumTableWriteVision.Rows[d]["PlanNo"].ToString() == "2")
                    {
                        if (isFirstValuePopulated_Vision2 == false)
                        {
                            arrValues.Clear();
                            isFirstValuePopulated_Vision2 = true;
                        }
                        if (VisionCount > 0)
                        {
                            if (isRowInserted == false)
                            {
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = Vision_Plan_Type_Plan_2;
                                oWordDoc.Tables[4].Cell(RowCounter, 2).Range.Text = Vision_Plan_Summary_Description_Plan_2;
                                oWordDoc.Tables[4].Rows.Add();
                                RowCounter = RowCounter + 1;
                                oWordDoc.Tables[4].Cell(RowCounter, 1).Range.Text = "Employee Cost";

                                isRowInserted = true;
                            }

                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                            {
                                for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                                {
                                    if (oWordDoc.Tables[4].Cell(rowNum, columnNum).Range.Text.Replace("\r\a", "") == PremiumTableWriteVision.Rows[d]["RateHeader"].ToString())
                                    {
                                        oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Bold = 0;

                                        if (!(arrValues.Contains(PremiumTableWriteVision.Rows[d]["RateID"].ToString())))
                                        {
                                            if (!string.IsNullOrEmpty(oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "")))
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text.Replace("\r\a", "") + "\n" + PremiumTableWriteVision.Rows[d]["Plan2_Rate"].ToString();
                                            }
                                            else
                                            {
                                                oWordDoc.Tables[4].Cell(RowCounter, columnNum).Range.Text = PremiumTableWriteVision.Rows[d]["Plan2_Rate"].ToString(); //Contri Cost
                                            }
                                            arrValues.Add(PremiumTableWriteVision.Rows[d]["RateID"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }

                    VisionTableColCounter++;
                }
                #endregion

                #region Code for Merging the rows
                for (int rowNum = 1; rowNum <= oWordDoc.Tables[4].Rows.Count; rowNum++)
                {
                    for (int columnNum = 1; columnNum <= oWordDoc.Tables[4].Columns.Count; columnNum++)
                    {
                        // Check the remainder for the rownumber to merge
                        if (rowNum % 2 == 0)
                        {
                            oWordDoc.Tables[4].Rows[rowNum].Cells.Merge();
                            oWordDoc.Tables[4].Rows[rowNum].Cells[1].Range.Text = oWordDoc.Tables[4].Rows[rowNum].Cells[1].Range.Text.Replace("\r", " ");
                            oWordDoc.Tables[4].Rows[rowNum].Cells[1].Shading.BackgroundPatternColor = cell_color(color);
                        }
                        break;
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteFSASectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList FSABenefitColumnIdList, DataTable CarrierSpecific, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableFSA = new Hashtable();
                DataRow[] foundRows = null;
                DateTime FSA_Effective_Date;
                DateTime Fsa_Renewal_Date;

                #region HashtableFSA
                HashtableFSA.Add(1, "150");     //Administration Services – Dependent Care Accounts-Maximum
                HashtableFSA.Add(2, "592");     //Administration Services – Grace Period
                HashtableFSA.Add(3, "354");     //Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            FSA_Effective_Date = Convert.ToDateTime(PlanTable.Rows[rowindex]["Effective"]);
                            Fsa_Renewal_Date = Convert.ToDateTime(PlanTable.Rows[rowindex]["Renewal"]);

                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("MAIN_FSA_HRA"))
                                                {
                                                    myMergeField.Select();

                                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                                    oWordApp.Selection.TypeText(" ");
                                                    continue;
                                                }

                                                if (key == 3)
                                                {
                                                    if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (key == 1)
                                                {
                                                    if (fieldName.Contains("Administration Services – Dependent Care Accounts-Maximum"))
                                                    {
                                                        myMergeField.Select();
                                                        oWordApp.Selection.TypeText((dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim());
                                                        continue;
                                                    }
                                                }
                                                if (fieldName.Contains("FSA_Plan"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                                    oWordApp.Selection.TypeText(" ");
                                                }
                                                if (fieldName.Contains("FSA Plan Effective date"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(FSA_Effective_Date.ToShortDateString());
                                                }

                                                if (fieldName.Contains("FSA Plan Renewal date minus 1 day"))
                                                {
                                                    myMergeField.Select();

                                                    oWordDoc.Tables[15].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                                                    oWordDoc.Tables[15].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                                                    oWordDoc.Tables[15].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                                                    oWordDoc.Tables[15].Range.Font.Color = font_color(color);

                                                    oWordDoc.Tables[15].Rows[9].Range.Shading.BackgroundPatternColor = cell_color(color);

                                                    DateTime FSA_Renewal_Date_Minus_Day = Convert.ToDateTime(Fsa_Renewal_Date).AddDays(-1);
                                                    oWordApp.Selection.TypeText(FSA_Renewal_Date_Minus_Day.ToShortDateString());
                                                    continue;
                                                }

                                                if (fieldName.Contains("FSA Carrier Website"))
                                                {
                                                    myMergeField.Select();
                                                    if (foundRows.Count() > 0)
                                                    {
                                                        if (!string.IsNullOrEmpty(foundRows[0]["Website"].ToString().Trim()))
                                                        {
                                                            oWordApp.Selection.TypeText(foundRows[0]["Website"].ToString());
                                                        }
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                }
                                            }
                                        }

                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        /// <summary>
        ///  Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        public void WriteEAPSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList, string color)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;
                string OldCarrier = "";

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                HashtableEAP.Add(1, "384"); //Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Number of Visit Item"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item);
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                }

                                                if (fieldName.Contains("EAP Plan Carrier"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                }
                                                if (fieldName.Contains("Employee Assistance Program"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.Range.Font.Color = font_color(color);
                                                    oWordApp.Selection.TypeText("Employee Assistance Program");
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                DataTable PremiumTable = new DataTable();
                //List<string> RateDescList = new List<string>();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                        int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                        int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                        oWordDoc.Tables[18].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                        oWordDoc.Tables[18].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                        oWordDoc.Tables[18].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                        oWordDoc.Tables[18].Range.Font.Color = font_color(color);

                        oWordDoc.Tables[18].Rows[1].Range.Shading.BackgroundPatternColor = cell_color(color);

                        for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                        {
                            if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                            {
                                if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                {
                                    PremiumTable.Rows.Add();
                                    PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                    PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                    PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                    PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                    PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                    PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                    PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                    premium_row_counter++;
                                }
                            }
                        }
                        //Generate Voluntary Life Column Dynamically.
                        //DataTable VoluntaryColumnHeding = new DataTable();

                        //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                        //VoluntaryColumnHeding = PremiumTable.DefaultView.ToTable(true);
                        //PremiumTable = VoluntaryColumnHeding;
                        //VoluntaryColumnHeding = PremiumTable.DefaultView.ToTable(true, "rateTier_description");
                        //for (int i = 0; i < VoluntaryColumnHeding.Rows.Count; i++)
                        //{
                        //    RateDescList.Add(VoluntaryColumnHeding.Rows[i][0].ToString());
                        //    oWordDoc.Tables[8].Columns.Add();
                        //    if (VoluntaryColumnHeding.Rows[i][0].ToString().Contains("EE"))
                        //    {
                        //        oWordDoc.Tables[8].Cell(2, i + 2).Range.Text = VoluntaryColumnHeding.Rows[i][0].ToString().Replace("EE", "Employee");
                        //    }
                        //    else
                        //    {
                        //        oWordDoc.Tables[8].Cell(2, i + 2).Range.Text = "Employee &" + VoluntaryColumnHeding.Rows[i][0].ToString();
                        //    }
                        //}

                        oWordDoc.Tables[18].Cell(2, 1).Range.Text = "Under " + Start.ToString();
                        int StartValue = Start;
                        int RowCount = 3;
                        while (StartValue < End - 1)
                        {
                            oWordDoc.Tables[18].Rows.Add();
                            if (StartValue == Start)
                            {
                                oWordDoc.Tables[18].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                StartValue = Start + Interval;
                            }
                            else
                            {
                                oWordDoc.Tables[18].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                StartValue = StartValue + Interval + 1;
                            }
                            RowCount++;
                        }
                        oWordDoc.Tables[18].Rows.Add();
                        oWordDoc.Tables[18].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                        oWordDoc.Tables[18].Rows.Add();
                        oWordDoc.Tables[18].Cell(RowCount + 1, 1).Range.Text = "Composite";
                        string dependent_child_life = string.Empty;

                        int ColumnCount = 0;
                        int oldageBand = -1;
                        DataTable dt = new DataTable();

                        PremiumTable.DefaultView.Sort = "[ageBandIndex] asc";
                        dt = PremiumTable.DefaultView.ToTable(true);
                        PremiumTable = dt;
                        RowCount = 2;
                        int RowCount1 = 2;
                        for (int i = 0; i < PremiumTable.Rows.Count; i++)
                        {
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                            {
                                ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                oWordDoc.Tables[18].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount++;
                            }
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Spouse UniSmoker")
                            {
                                ColumnCount = 3;
                                oldageBand = int.Parse(PremiumTable.Rows[i]["ageBandIndex"].ToString());

                                oWordDoc.Tables[18].Cell(RowCount1, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                RowCount1++;
                            }
                            if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                            {
                                ColumnCount = 2;
                                dependent_child_life = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                            }
                        }

                        if (!string.IsNullOrEmpty(dependent_child_life))
                        {
                            oWordDoc.Tables[18].Rows.Add();
                            oWordDoc.Tables[18].Cell(RowCount + 2, 1).Range.Text = "Per $1,000 Child Life";
                            oWordDoc.Tables[18].Cell(RowCount + 2, 2).Merge(oWordDoc.Tables[18].Cell(RowCount + 2, 3));
                            oWordDoc.Tables[18].Cell(RowCount + 2, 2).Range.Text = dependent_child_life;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;
                string Overall_Maximum_Employee = "";
                string Guarantee_Issue_Amt_Employee = "";

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string age = "";
                string age_to = "";
                double benefitamount = 0;

                #region HashtableVoluntaryLifeADDBenifit

                /*Delete Overall maximum row from all catagory--29/05/2014*/
                HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(4, "188");//Employee[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(5, "187");//Employee[Guarantee Issue Amount]4
                HashtableVoluntaryLifeADDBenifit.Add(6, "516");//Spouse[Benefit Amount]6
                //HashtableVoluntaryLifeADDBenifit.Add(8, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(8, "467"); //Reduction of Benefits
                HashtableVoluntaryLifeADDBenifit.Add(7, "518");//Spouse[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(9, "106");//Child(ren)[Benefit Amount] 
                //HashtableVoluntaryLifeADDBenifit.Add(12, "104");//Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(10, "103"); //Child(ren)[Guarantee Issue Amount]
                HashtableVoluntaryLifeADDBenifit.Add(11, "2");//age--
                HashtableVoluntaryLifeADDBenifit.Add(12, "3");//age
                HashtableVoluntaryLifeADDBenifit.Add(13, "4");//age
                HashtableVoluntaryLifeADDBenifit.Add(14, "5");//age

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            oWordDoc.Tables[17].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = border_color(color);
                            oWordDoc.Tables[17].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);
                            oWordDoc.Tables[17].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = border_color(color);

                            oWordDoc.Tables[17].Range.Font.Color = font_color(color);

                            #region VoluntaryLifeADDBenifitTable
                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                            {
                                OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                            }

                            string planname = PlanTable.Rows[k]["ProductTypeDescription"].ToString();
                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower().Trim().ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        if (key == 4)
                                        {
                                            Overall_Maximum_Employee = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }
                                        if (key == 5)
                                        {
                                            Guarantee_Issue_Amt_Employee = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        }

                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();
                                        int ch = int.Parse(dr["attributeID"].ToString());
                                        switch (ch)
                                        {
                                            case 2: if (value.Trim() != string.Empty) { age = value; } break;       // 65-69
                                            case 3: if (value.Trim() != string.Empty) { age = value; } break;       // 70-74
                                            case 4: if (value.Trim() != string.Empty) { age_to = value; } break;    // 75-79
                                            case 5: if (value.Trim() != string.Empty) { age = value; } break;       // 80-84
                                            case 186:
                                                if (dr["value"].ToString().Trim() != "")
                                                {
                                                    string str = dr["value"].ToString().Trim();
                                                    bool isNum = double.TryParse(str, out benefitamount);
                                                    if (isNum)
                                                    {
                                                    }
                                                    else
                                                    {
                                                        benefitamount = 0;
                                                    }
                                                    break;
                                                }
                                                else
                                                {
                                                    benefitamount = 0; break;
                                                }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Voluntary Life Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(" ");
                                    }

                                    if (fieldName.Contains("Voluntary Life and AD&D Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        oWordApp.Selection.TypeText(planname.Trim());
                                    }

                                    if (fieldName.Contains("voluntaryageto"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (!string.IsNullOrEmpty(age_to))
                                        {
                                            oWordApp.Selection.TypeText(age_to.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("voluntaryagefrom"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (!string.IsNullOrEmpty(age))
                                        {
                                            oWordApp.Selection.TypeText(age.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (fieldName.Contains("VoluntaryLifeADDTaxation"))
                                    {
                                        if (benefitamount > 50000)
                                        {
                                            myMergeField.Delete();
                                        }
                                    }

                                    if (fieldName.Contains("Voluntary General Plan information – Overall Maximum – Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (!string.IsNullOrEmpty(Overall_Maximum_Employee.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Overall_Maximum_Employee.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                    if (fieldName.Contains("Guarantee Issue Amount  Employee"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = font_color(color);
                                        if (!string.IsNullOrEmpty(Guarantee_Issue_Amt_Employee.Trim()))
                                        {
                                            oWordApp.Selection.TypeText(Guarantee_Issue_Amt_Employee.Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string color, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex == 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                continue;
                            }
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = font_color(color);
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = font_color(color);
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                // Call common function to write the contact information page fields
                comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>

        public void WriteContactinformationToTemplate6(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string color)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int k = 0;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                string summaryname = "";
                DataRow[] foundRows = null;
                int cnt = 2;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;

                int rowCnt = 1;
                int count = 20;//Table Numbaer for contact information

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        //if (plantype != "STD Plan" && plantype != "LTD Plan")
                        //{
                        if (k > 0)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString().Replace("''", "'");
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        summaryname = PlanTable.Rows[i]["SummaryName"].ToString();
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = ProductTypeDesc + " " + summaryname;
                        oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = carriername + "\nGroup Number: " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                        foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "") + "'");
                        if (foundRows.Count() > 0)
                        {
                            if (foundRows.Count() > 0)
                            {
                                oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "Website: " + Convert.ToString(foundRows[0]["Website"].ToString()) + "\nPhone Number: " + Convert.ToString(foundRows[0]["PhoneNumber"].ToString());
                            }
                            else
                            {
                                oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = "";
                            }
                        }
                        k++;
                        rowCnt++;
                    }
                }

            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
    }
}