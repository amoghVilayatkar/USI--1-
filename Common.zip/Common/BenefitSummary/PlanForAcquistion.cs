﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{
    public class PlanForAcquistion
    {
        #region Variable
        private int _productId;
        private string _productName;
        private string _LOC;
        private string _carrierName;
        private int _carrierId;
        private DateTime _effectiveDate;
        private DateTime _renewalDate;
        private string _productTypeDescription;
        private string _policyNo;
        private int _ProductTypeId;
        List<Rate> _rateList;
        string _productStatus;
        string _productStatusCurrent;
        string _productStatusPending;
        private string _summaryName;
        private int _summaryID;

        #endregion
        #region Properties
        /// <summary>
        /// Get and Set ProductId
        /// </summary>

        public int ProductId
        {
            get
            {
                return _productId;

            }
            set
            {
                _productId = value;
            }
        }
        /// <summary>
        /// Get and Set ProductName
        /// </summary>

        public string ProductName
        {
            get
            {
                return _productName;

            }
            set
            {
                _productName = value;
            }
        }

        /// <summary>
        /// Get and Set CarrierId
        /// </summary>
        public int CarrierId
        {
            get
            {
                return _carrierId;

            }
            set
            {
                _carrierId = value;
            }
        }

        /// <summary>
        /// Get and Set CarrierName
        /// </summary>
        public string CarrierName
        {
            get
            {
                return _carrierName;

            }
            set
            {
                _carrierName = value;
            }
        }

        /// <summary>
        /// Get and Set LOC
        /// </summary>
        public string LOC
        {
            get
            {
                return _LOC;

            }
            set
            {
                _LOC = value;
            }
        }

        /// <summary>
        /// Get and Set EffectiveDate
        /// </summary>
        public DateTime EffectiveDate
        {
            get
            {
                return _effectiveDate;
            }
            set
            {
                _effectiveDate = value;
            }
        }
        /// <summary>
        /// Get and Set RenewalDate
        /// </summary>

        public DateTime? RenewalDate
        {
            get
            {
                if (this.RenewalDate == default(DateTime))
                    return null;
                else
                    return this.RenewalDate;
            }
            set
            {
                _renewalDate =Convert.ToDateTime( RenewalDate);
            }
        }

        ////public DateTime? BirthdateDisplay
        ////{
        ////    get
        ////    {
        ////        if (this.RenewalDate == default(DateTime))
        ////            return null;
        ////        else
        ////            return this.RenewalDate;
        ////    }
        ////}

        /// <summary>
        /// Get and Set PolicyNumber
        /// </summary>

        public string PolicyNumber
        {
            get
            {
                return _policyNo;

            }
            set
            {
                _policyNo = value;
            }
        }
        /// <summary>
        /// Get and Set ProductTypeDescription
        /// </summary>

        public string ProductTypeDescription
        {
            get
            {
                return _productTypeDescription;

            }
            set
            {
                _productTypeDescription = value;
            }
        }
        /// <summary>
        /// Get and Set RateList
        /// </summary>
        public List<Rate> RateList
        {
            get
            {
                return _rateList;

            }
            set
            {
                _rateList = value;
            }
        }
        /// <summary>
        /// Get and Set ProductTypeId
        /// </summary>
        public int ProductTypeId
        {
            get
            {
                return _ProductTypeId;

            }
            set
            {
                _ProductTypeId = value;
            }
        }
        /// <summary>
        /// Get and Set ProductStatus
        /// </summary>
        public string ProductStatus
        {
            get
            {
                return _productStatus;

            }
            set
            {
                _productStatus = value;
            }
        }
        /// <summary>
        /// Get and Set ProductStatusCurrent
        /// </summary>
        public string ProductStatusCurrent
        {
            get
            {
                return _productStatusCurrent;

            }
            set
            {
                _productStatusCurrent = value;
            }
        }
        /// <summary>
        /// Get and Set ProductStatusPending
        /// </summary>
        public string ProductStatusPending
        {
            get
            {
                return _productStatusPending;

            }
            set
            {
                _productStatusPending = value;
            }
        }

        /// <summary>
        /// Get and Set SummaryName
        /// </summary>
        public string SummaryName
        {
            get
            {
                return _summaryName;

            }
            set
            {
                _summaryName = value;
            }
        }

        /// <summary>
        /// Get and Set SummaryID
        /// </summary>
        public int SummaryID
        {
            get
            {
                return _summaryID;

            }
            set
            {
                _summaryID = value;
            }
        }

        #endregion
    }
}