﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.PowerPoint;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Core = Microsoft.Office.Core;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;
using System.Data.SqlClient;
using System.Configuration;

using BenefitPointSummaryPortal.Common.OpenCloseWord;
using System.DirectoryServices.AccountManagement;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;

namespace BenefitPointSummaryPortal.View
{
    public partial class AccountPlan_View : System.Web.UI.Page
    {
        #region Global Variable
        DataSet AccountDS = new DataSet();
        Word_Office officeobj = new Common.BenefitSummary.Word_Office();
        WordOpenClose wobj = new WordOpenClose();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        DataSet ProductDS = new DataSet();
        ConstantValue cv = new ConstantValue();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;

        public static List<int> MedicalPlanTypeList = new List<int>();
        public static List<int> DentalPlanTypeList = new List<int>();
        public static List<int> VisionPlanTypeList = new List<int>();
        public static List<int> LifeADDPlanTypeList = new List<int>();
        public static List<int> WellnessPlanTypeList = new List<int>();
        public static List<int> AccidentTypeList = new List<int>();
        public static List<int> AncillaryPlanTypeList = new List<int>();
        public static List<int> DisabilityPlanTypeList = new List<int>();
        public static List<int> FeePlanTypeList = new List<int>();
        public static List<int> FinancialPlanTypeList = new List<int>();
        //code added by shravan
        public static Dictionary<string, Dictionary<int, int>> DictPlanType = new Dictionary<string, Dictionary<int, int>>();
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();
        //Dict for All carriers
        public static Dictionary<string, string> DictCarrier = new Dictionary<string, string>();
        //Dict for All carriers for specific client  -- this is only used to fetch carrier name of plan
        public static Dictionary<string, string> DictClientCarrier = new Dictionary<string, string>();

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                if (!IsPostBack)
                {
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    TitleSpan.InnerText = "Account/Plan View";
                    Activity_Group = "Account/Plan View";
                    Activity = TitleSpan.InnerText;
                    txtsearch.Focus();



                    List<Carrier> carrierList = new List<Carrier>();
                    carrierList = bp.GetAllCarriers(SessionId);
                    DictCarrier = carrierList.ToDictionary(x => x.CarrierId.ToString(), x => x.CarrierName.ToString());

                    //Fetching Department Table 
                    //Code for Department 
                    DictDepartment = sd.getDepartmentDetails();

                    //Loading Plain Id's
                    LoadPlanTypeIds();

                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                pnlPlans_Next.Visible = false;
                ddlPlanType.Items.Clear();
                ddlCommisionPaidBy.Items.Clear();
                txtAdministrator.Text = "";
                txtDepartment.Text = "";
                txtOffice.Text = "";
                txtPrimaryContact.Text = "";
                txtPrimaryService.Text = "";
                txtPrimarySales.Text = "";


                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BPBusiness bp = new BPBusiness();
                //List<Account> AccountList = new List<Account>();
                //SessionId = Session["SessionId"].ToString();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        // Old Method
        /*protected void btnAdditionalViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                List<Plan> PlanList = Session["PlanList"] as List<Plan>;
                List<Plan> newPlanList = new List<Plan>();
                DataTable NewPlanTable = BuildNewPlanTable();
                SessionId = Session["SessionId"].ToString();

                //LoadPlanTypeIds();

                // Plan Lisitng
                if (ddlPlanType.SelectedIndex > 0)
                {

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                    {
                                        newPlanList.Add(item);
                                    }
                                }
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    newPlanList.Add(item);
                                }
                            }
                        }
                    }



                    //Binding Repeator
                    DataTable plantable = CreatePlanInfoTable();
                    string Selectedplantype = ddlPlanType.SelectedValue.ToString();

                    //Dictionary fro ClientName and ClientID used to get only Carrier names of Plans
                    Dictionary<string, string> DictClient = new Dictionary<string, string>();


                    foreach (Plan plan in newPlanList)
                    {
                        // "-1" for All PLans Selected
                        if (ddlPlanType.SelectedValue.ToString() != "-1")
                        {
                            if (DictPlanType[Selectedplantype].ContainsKey(plan.ProductTypeId))
                            {
                                DataRow row = plantable.NewRow();
                                row["Carrier"] = plan.CarrierName;
                                row["Name"] = plan.ProductName;
                                row["Effective"] = plan.EffectiveDate.ToString();
                                row["Renewal"] = plan.RenewalDate.ToString();
                                row["PolicyNumber"] = plan.PolicyNumber.ToString();
                                row["ProductId"] = plan.ProductId.ToString();
                                row["ProductName"] = plan.ProductName;
                                row["ProductTypeId"] = plan.ProductTypeId.ToString();
                                row["PlanType"] = plan.ProductTypeDescription;
                                row["SummaryName"] = plan.SummaryName;
                                row["SummaryID"] = plan.SummaryID;
                                plantable.Rows.Add(row);


                                if (!DictClient.ContainsKey(plan.CarrierId.ToString()))
                                    DictClient.Add(plan.CarrierId.ToString(), plan.CarrierName);

                            }
                        }
                        else
                        {
                            DataRow row = plantable.NewRow();
                            row["Carrier"] = plan.CarrierName;
                            row["Name"] = plan.ProductName;
                            row["Effective"] = plan.EffectiveDate.ToString();
                            row["Renewal"] = plan.RenewalDate.ToString();
                            row["PolicyNumber"] = plan.PolicyNumber.ToString();
                            row["ProductId"] = plan.ProductId.ToString();
                            row["ProductName"] = plan.ProductName;
                            row["ProductTypeId"] = plan.ProductTypeId.ToString();
                            row["PlanType"] = plan.ProductTypeDescription;
                            row["SummaryName"] = plan.SummaryName;
                            row["SummaryID"] = plan.SummaryID;
                            plantable.Rows.Add(row);


                            if (!DictClient.ContainsKey(plan.CarrierId.ToString()))
                                DictClient.Add(plan.CarrierId.ToString(), plan.CarrierName);
                        }
                    }


                    sd.BuildProductTable();
                    ProductDS = sd.GetProductDetail(plantable, SessionId);

                    string Account_OfficePlan = string.Empty;
                    string Account_RegionPlan = string.Empty;
                    List<Carrier> carrierList = new List<Carrier>();

                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        DataRow newrow = NewPlanTable.NewRow();

                        //PlanType
                        if (ProductDS.Tables["ProductTable"].Rows[k]["section"].ToString() != null)
                        {
                            newrow["PlanType"] = ProductDS.Tables["ProductTable"].Rows[k]["section"].ToString();
                        }
                        else
                        {
                            newrow["PlanType"] = "";
                        }


                        //CarrierName
                        if (DictClient.ContainsKey(ProductDS.Tables["ProductTable"].Rows[k]["carrierID"].ToString()))
                        {
                            newrow["CarrierName"] = DictClient[ProductDS.Tables["ProductTable"].Rows[k]["carrierID"].ToString()];
                        }


                        //PlanID
                        if (ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString() != null)
                        {
                            newrow["PlanID"] = ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString();
                        }
                        else
                        {
                            newrow["PlanID"] = "";
                        }

                        //PlanName
                        if (ProductDS.Tables["ProductTable"].Rows[k]["name"].ToString() != null)
                        {
                            newrow["PlanName"] = ProductDS.Tables["ProductTable"].Rows[k]["name"].ToString();
                        }
                        else
                        {
                            newrow["PlanName"] = "";
                        }

                        //PolicyNumber
                        if (ProductDS.Tables["ProductTable"].Rows[k]["policyNumber"].ToString() != null)
                        {
                            newrow["PolicyNumber"] = ProductDS.Tables["ProductTable"].Rows[k]["policyNumber"].ToString();
                        }
                        else
                        {
                            newrow["PolicyNumber"] = "";
                        }

                        //AltPolicyNumber
                        if (ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString() != "")
                        {
                            newrow["AltPolicyNumber"] = ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString();
                        }
                        else
                        {
                            newrow["AltPolicyNumber"] = "";
                        }

                        //EffectiveDate
                        if (ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString().Trim() != "")
                        {
                            newrow["EffectiveDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString()).ToShortDateString(); ;
                        }
                        else
                        {
                            newrow["EffectiveDate"] = "";
                        }


                        //RenewalDate
                        if (ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"].ToString().Trim() != "")
                        {
                            newrow["RenewalDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"]).ToShortDateString();
                        }
                        else
                        {
                            newrow["RenewalDate"] = "";
                        }


                        //Code for binding Department 
                        string DepartmentID = string.Empty;
                        DepartmentID = ProductDS.Tables["ProductTable"].Rows[k]["departmentID"].ToString().Trim();
                        if (DictDepartment.ContainsKey(DepartmentID))
                        {
                            newrow["PlanDepartment"] = DictDepartment[DepartmentID];
                        }


                        //CancellationDate
                        if (ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString().Trim() != "")
                        {
                            if (ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString() != "")
                                newrow["CancellationDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"]).ToShortDateString();
                        }
                        else
                        {
                            newrow["CancellationDate"] = "";
                        }




                        //PlanOffice
                        if (ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString().Trim() != "")
                        {
                            DataTable dtTable = sd.GetOfficeDetail_AccountPlanView(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString()));
                            if (dtTable != null)
                            {
                                newrow["PlanOffice"] = dtTable.Rows[0][1].ToString();
                            }
                        }


                        // Get Commision paid by 
                        int billingCarrierID = Convert.ToInt32(Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]));
                        string BillingCarrierName = String.Empty;
                        carrierList = bp.GetAllCarriers(SessionId);
                        var Carrier = carrierList.FirstOrDefault(a => a.CarrierId == billingCarrierID);
                        if (Carrier != null)
                        {
                            BillingCarrierName = Carrier.CarrierName;// code here
                        }
                        else
                        {
                            BillingCarrierName = "";
                        }

                        newrow["CommissionPaidBy"] = BillingCarrierName;

                        NewPlanTable.Rows.Add(newrow);

                    }



                    rptPlanList.DataSource = NewPlanTable;
                    rptPlanList.DataBind();

                }

                pnlPlans_Next.Visible = true;

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }


        }*/


        protected void btnAdditionalViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ProductDS = Session["ProductDS"] as DataSet;
                DataTable FinalPlanTable = BuildNewPlanTable();
                SessionId = Session["SessionId"].ToString();
                // if Active is True -- Only Active Plans
                //if Active is Flase -- All Active and InActive Plans
                bool active = false;

                if (rdlPlan.SelectedIndex == 0)
                {
                    active = true;
                }

                if (ddlPlanType.SelectedIndex > 0)
                {

                    if (ProductDS.Tables["ProductTable"] != null)
                    {
                        if (ProductDS.Tables["ProductTable"].Rows.Count > 0)
                        {

                            FinalPlanTable = GetFinalProductTable(ProductDS, active);
                            #region Commented by shravan
                            //if (rdlPlan.SelectedIndex == 0)
                            //{
                            //    foreach (DataRow Product in ProductDS.Tables["ProductTable"].Rows)
                            //    {
                            //        if (Convert.ToDateTime(Product["renewalOn"]) > System.DateTime.Now && Product["productStatus"].ToString() == BP_BrokerConnectV4.ProductStatus.Current.ToString())
                            //        {
                            //            // newPlanList.Add(item);
                            //            //BindPlanGrid
                            //        }
                            //        else
                            //        {
                            //            Product.Delete();
                            //        }
                            //    }
                            //}
                            //if (rdlPlan.SelectedIndex == 1)
                            //{
                            //    foreach (DataRow Product in ProductDS.Tables["ProductTable"].Rows)
                            //    {
                            //        //newPlanList.Add(item);
                            //    }
                            //} 
                            #endregion
                        }
                    }

                    #region Commented by Shravan
                    ////Binding Repeator

                    //string Selectedplantype = ddlPlanType.SelectedValue.ToString();
                    //string SelectedCommissionPaidByID = ddlCommisionPaidBy.SelectedValue.ToString();

                    ////DataTable plantable = CreatePlanInfoTable();


                    ////Dictionary fro ClientName and ClientID used to get only Carrier names of Plans
                    //Dictionary<string, string> DictClient = new Dictionary<string, string>();


                    //foreach (DataRow Product in ProductDS.Tables["ProductTable"].Rows)
                    //{
                    //    // "-1" for All PLans Selected
                    //    if (ddlPlanType.SelectedValue.ToString() != "-1")
                    //    {
                    //        if (DictPlanType[Selectedplantype].ContainsKey(Convert.ToInt32(Product["productID"])))
                    //        {
                    //            //DataRow row = plantable.NewRow();
                    //            //row["Carrier"] = plan.CarrierName;
                    //            //row["Name"] = plan.ProductName;
                    //            //row["Effective"] = plan.EffectiveDate.ToString();
                    //            //row["Renewal"] = plan.RenewalDate.ToString();
                    //            //row["PolicyNumber"] = plan.PolicyNumber.ToString();
                    //            //row["ProductId"] = plan.ProductId.ToString();
                    //            //row["ProductName"] = plan.ProductName;
                    //            //row["ProductTypeId"] = plan.ProductTypeId.ToString();
                    //            //row["PlanType"] = plan.ProductTypeDescription;
                    //            //row["SummaryName"] = plan.SummaryName;
                    //            //row["SummaryID"] = plan.SummaryID;
                    //            //plantable.Rows.Add(row);


                    //            //if (!DictClient.ContainsKey(plan.CarrierId.ToString()))
                    //            //    DictClient.Add(plan.CarrierId.ToString(), plan.CarrierName);

                    //        }
                    //    }
                    //    else
                    //    {
                    //        //DataRow row = plantable.NewRow();
                    //        //row["Carrier"] = plan.CarrierName;
                    //        //row["Name"] = plan.ProductName;
                    //        //row["Effective"] = plan.EffectiveDate.ToString();
                    //        //row["Renewal"] = plan.RenewalDate.ToString();
                    //        //row["PolicyNumber"] = plan.PolicyNumber.ToString();
                    //        //row["ProductId"] = plan.ProductId.ToString();
                    //        //row["ProductName"] = plan.ProductName;
                    //        //row["ProductTypeId"] = plan.ProductTypeId.ToString();
                    //        //row["PlanType"] = plan.ProductTypeDescription;
                    //        //row["SummaryName"] = plan.SummaryName;
                    //        //row["SummaryID"] = plan.SummaryID;
                    //        //plantable.Rows.Add(row);


                    //        //if (!DictClient.ContainsKey(plan.CarrierId.ToString()))
                    //        //    DictClient.Add(plan.CarrierId.ToString(), plan.CarrierName);
                    //    }
                    //}


                    //// sd.BuildProductTable();
                    ////ProductDS = sd.GetProductDetail(plantable, SessionId);

                    //string Account_OfficePlan = string.Empty;
                    //string Account_RegionPlan = string.Empty;
                    //List<Carrier> carrierList = new List<Carrier>();

                    //for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    //{
                    //    DataRow newrow = NewPlanTable.NewRow();

                    //    //PlanType
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["section"].ToString() != null)
                    //    {
                    //        newrow["PlanType"] = ProductDS.Tables["ProductTable"].Rows[k]["section"].ToString();
                    //    }
                    //    else
                    //    {
                    //        newrow["PlanType"] = "";
                    //    }


                    //    //CarrierName
                    //    if (DictClient.ContainsKey(ProductDS.Tables["ProductTable"].Rows[k]["carrierID"].ToString()))
                    //    {
                    //        newrow["CarrierName"] = DictClient[ProductDS.Tables["ProductTable"].Rows[k]["carrierID"].ToString()];
                    //    }


                    //    //PlanID
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString() != null)
                    //    {
                    //        newrow["PlanID"] = ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString();
                    //    }
                    //    else
                    //    {
                    //        newrow["PlanID"] = "";
                    //    }

                    //    //PlanName
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["name"].ToString() != null)
                    //    {
                    //        newrow["PlanName"] = ProductDS.Tables["ProductTable"].Rows[k]["name"].ToString();
                    //    }
                    //    else
                    //    {
                    //        newrow["PlanName"] = "";
                    //    }

                    //    //PolicyNumber
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["policyNumber"].ToString() != null)
                    //    {
                    //        newrow["PolicyNumber"] = ProductDS.Tables["ProductTable"].Rows[k]["policyNumber"].ToString();
                    //    }
                    //    else
                    //    {
                    //        newrow["PolicyNumber"] = "";
                    //    }

                    //    //AltPolicyNumber
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString() != "")
                    //    {
                    //        newrow["AltPolicyNumber"] = ProductDS.Tables["ProductTable"].Rows[k]["commissionInfo_alternativePolicyNumber"].ToString();
                    //    }
                    //    else
                    //    {
                    //        newrow["AltPolicyNumber"] = "";
                    //    }

                    //    //EffectiveDate
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString().Trim() != "")
                    //    {
                    //        newrow["EffectiveDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["effectiveAsOf"].ToString()).ToShortDateString(); ;
                    //    }
                    //    else
                    //    {
                    //        newrow["EffectiveDate"] = "";
                    //    }


                    //    //RenewalDate
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"].ToString().Trim() != "")
                    //    {
                    //        newrow["RenewalDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["renewalOn"]).ToShortDateString();
                    //    }
                    //    else
                    //    {
                    //        newrow["RenewalDate"] = "";
                    //    }


                    //    //Code for binding Department 
                    //    string DepartmentID = string.Empty;
                    //    DepartmentID = ProductDS.Tables["ProductTable"].Rows[k]["departmentID"].ToString().Trim();
                    //    if (DictDepartment.ContainsKey(DepartmentID))
                    //    {
                    //        newrow["PlanDepartment"] = DictDepartment[DepartmentID];
                    //    }


                    //    //CancellationDate
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString().Trim() != "")
                    //    {
                    //        if (ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"].ToString() != "")
                    //            newrow["CancellationDate"] = Convert.ToDateTime(ProductDS.Tables["ProductTable"].Rows[k]["cancellationOn"]).ToShortDateString();
                    //    }
                    //    else
                    //    {
                    //        newrow["CancellationDate"] = "";
                    //    }




                    //    //PlanOffice
                    //    if (ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString() != null && ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString().Trim() != "")
                    //    {
                    //        DataTable dtTable = sd.GetOfficeDetail_AccountPlanView(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, Convert.ToInt32(ProductDS.Tables["ProductTable"].Rows[k]["OfficeID"].ToString()));
                    //        if (dtTable != null)
                    //        {
                    //            newrow["PlanOffice"] = dtTable.Rows[0][1].ToString();
                    //        }
                    //    }


                    //    // Get Commision paid by 
                    //    int billingCarrierID = Convert.ToInt32(Convert.ToInt32(ProductDS.Tables[1].Rows[k]["billingCarrierID"]));
                    //    string BillingCarrierName = String.Empty;
                    //    carrierList = bp.GetAllCarriers(SessionId);
                    //    var Carrier = carrierList.FirstOrDefault(a => a.CarrierId == billingCarrierID);
                    //    if (Carrier != null)
                    //    {
                    //        BillingCarrierName = Carrier.CarrierName;// code here
                    //    }
                    //    else
                    //    {
                    //        BillingCarrierName = "";
                    //    }

                    //    newrow["CommissionPaidBy"] = BillingCarrierName;

                    //    NewPlanTable.Rows.Add(newrow);

                    //} 
                    #endregion



                    rptPlanList.DataSource = FinalPlanTable;
                    rptPlanList.DataBind();

                }

                pnlPlans_Next.Visible = true;

                #region INSERT ACTIVITY LOG SECTION

                DataSet AccountDSActivity = new DataSet();
                DataSet AccountTeamMemberDSActivity = new DataSet();
                List<Contact> ContactListActivity = (List<Contact>)Session["Contact"];
                AccountTeamMemberDSActivity = (DataSet)Session["AccountTeamMemberDS"];
                AccountDSActivity = (DataSet)Session["AccountDS"];


                string AdditionalCrtieriaOption_1 = txtOffice.Text;
                string AdditionalCrtieriaOption_2 = txtAdministrator.Text;
                string AdditionalCrtieriaOption_3 = ddlPlanType.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlCommisionPaidBy.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDSActivity, AccountTeamMemberDSActivity, DictDepartment, ContactListActivity);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Convert.ToString(Session["Account_Region"]), Convert.ToString(Session["Account_Office"]), Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }


        }

        //Returns Final ProductTable for Binding Grid 
        protected DataTable GetFinalProductTable(DataSet ProductDS, bool Active)
        {
            try
            {
                DataTable FinalProductTable = BuildNewPlanTable();

                foreach (DataRow Product in ProductDS.Tables["ProductTable"].Rows)
                {
                    DataRow newrow = FinalProductTable.NewRow();
                    //Filter by Active and InActive Plans
                    if (Active)
                    {
                        if (Product["renewalOn"].ToString().Trim() != "" && Product["renewalOn"] != null)
                        {
                            if (Convert.ToDateTime(Product["renewalOn"]) > System.DateTime.Now && Product["productStatus"].ToString() == BP_BrokerConnectV4.ProductStatus.Current.ToString())
                            {
                                //Passing Product and  Filtering by PlanType and CommissionPaidBy 
                                newrow = GetFinalProductTableRow(Product, ddlPlanType, ddlCommisionPaidBy, newrow);
                                if (newrow != null)
                                    FinalProductTable.Rows.Add(newrow);
                            }

                        }
                    }
                    else
                    {
                        newrow = GetFinalProductTableRow(Product, ddlPlanType, ddlCommisionPaidBy, newrow);
                        if (newrow != null)
                            FinalProductTable.Rows.Add(newrow);
                    }
                }

                return FinalProductTable;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
                return null;
            }
        }

        //Returns Final ProductTable row for ProductTable
        protected DataRow GetFinalProductTableRow(DataRow Product, DropDownList ddlPlanType, DropDownList ddlCommisionPaidBy, DataRow newrow)
        {
            try
            {
                //DataRow newrow = BuildNewPlanTable().NewRow();

                // "-1" for All PLanTypes Selected   or    Select only that Plantype Product
                if (ddlPlanType.SelectedValue.ToString() == "-1" || DictPlanType[ddlPlanType.SelectedValue].ContainsKey(Convert.ToInt32(Product["productTypeID"])))
                {

                    // "-1" for All "Commission Paid By"  or select only that "Commission Paid By"
                    if (ddlCommisionPaidBy.SelectedValue.ToString() == "-1" || ddlCommisionPaidBy.SelectedValue.ToString().Trim() == Product["billingCarrierID"].ToString().Trim())
                    {
                        #region Added row to table

                        //PlanType
                        if (Product["section"].ToString() != null)
                        {
                            newrow["PlanType"] = Product["section"].ToString();
                        }
                        else
                        {
                            newrow["PlanType"] = "";
                        }


                        //CarrierName
                        if (DictClientCarrier.ContainsKey(Product["carrierID"].ToString()))
                        {
                            newrow["CarrierName"] = DictClientCarrier[Product["carrierID"].ToString()];
                        }


                        //PlanID
                        if (Product["productID"].ToString() != null)
                        {
                            newrow["PlanID"] = Product["productID"].ToString();
                        }
                        else
                        {
                            newrow["PlanID"] = "";
                        }

                        //PlanName
                        if (Product["name"].ToString() != null)
                        {
                            newrow["PlanName"] = Product["name"].ToString();
                        }
                        else
                        {
                            newrow["PlanName"] = "";
                        }

                        //PolicyNumber
                        if (Product["policyNumber"].ToString() != null)
                        {
                            newrow["PolicyNumber"] = Product["policyNumber"].ToString();
                        }
                        else
                        {
                            newrow["PolicyNumber"] = "";
                        }

                        //AltPolicyNumber
                        if (Product["commissionInfo_alternativePolicyNumber"].ToString() != null && Product["commissionInfo_alternativePolicyNumber"].ToString() != "")
                        {
                            newrow["AltPolicyNumber"] = Product["commissionInfo_alternativePolicyNumber"].ToString();
                        }
                        else
                        {
                            newrow["AltPolicyNumber"] = "";
                        }

                        //EffectiveDate
                        if (Product["effectiveAsOf"].ToString() != null && Product["effectiveAsOf"].ToString().Trim() != "")
                        {
                            newrow["EffectiveDate"] = Convert.ToDateTime(Product["effectiveAsOf"].ToString()).ToShortDateString(); ;
                        }
                        else
                        {
                            newrow["EffectiveDate"] = "";
                        }


                        //RenewalDate
                        if (Product["renewalOn"].ToString() != null && Product["renewalOn"].ToString().Trim() != "")
                        {
                            newrow["RenewalDate"] = Convert.ToDateTime(Product["renewalOn"]).ToShortDateString();
                        }
                        else
                        {
                            newrow["RenewalDate"] = "";
                        }


                        //Code for binding Department 
                        string DepartmentID = string.Empty;
                        DepartmentID = Product["departmentID"].ToString().Trim();
                        if (DictDepartment.ContainsKey(DepartmentID))
                        {
                            newrow["PlanDepartment"] = DictDepartment[DepartmentID];
                        }


                        //CancellationDate
                        if (Product["cancellationOn"].ToString() != null && Product["cancellationOn"].ToString().Trim() != "")
                        {
                            newrow["CancellationDate"] = Convert.ToDateTime(Product["cancellationOn"]).ToShortDateString();
                        }
                        else
                        {
                            newrow["CancellationDate"] = "";
                        }




                        //PlanOffice
                        if (Product["OfficeID"].ToString() != null && Product["OfficeID"].ToString().Trim() != "")
                        {
                            DataTable dtTable = sd.GetOfficeDetail_AccountPlanView(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, Convert.ToInt32(Product["OfficeID"].ToString()));
                            if (dtTable != null)
                            {
                                newrow["PlanOffice"] = dtTable.Rows[0][1].ToString();
                            }
                        }


                        // Get Commision paid by 
                        string billingCarrierID = Product["billingCarrierID"].ToString().Trim();
                        if (DictCarrier.ContainsKey(billingCarrierID))
                        {
                            newrow["CommissionPaidBy"] = DictCarrier[billingCarrierID];
                        }

                        #endregion

                        return newrow;
                    }

                    return null;

                }
                return null;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
                return null;
            }

        }

        //Return Structure for FinalProduct Table
        private DataTable BuildNewPlanTable()
        {
            DataTable table = new DataTable();
            table.Columns.Add("PlanID", typeof(int));
            table.Columns.Add("PlanType", typeof(string));
            table.Columns.Add("PlanName", typeof(string));
            table.Columns.Add("CarrierName", typeof(string));
            table.Columns.Add("CommissionPaidBy", typeof(string));
            table.Columns.Add("EffectiveDate", typeof(string));
            table.Columns.Add("RenewalDate", typeof(string));
            table.Columns.Add("CancellationDate", typeof(string));
            table.Columns.Add("PolicyNumber", typeof(string));
            table.Columns.Add("AltPolicyNumber", typeof(string));
            table.Columns.Add("PlanOffice", typeof(string));
            table.Columns.Add("PlanDepartment", typeof(string));
            return table;
        }


        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                ddlPlanType.Items.Clear();
                ddlCommisionPaidBy.Items.Clear();
                pnlPlans_Next.Visible = false;
                rdlPlan.SelectedIndex = 0;
                txtAdministrator.Text = "";
                txtDepartment.Text = "";
                txtOffice.Text = "";
                txtPrimaryContact.Text = "";
                txtPrimaryService.Text = "";
                txtPrimarySales.Text = "";
                //---------------------------------------------------------------------
                // Do not delete code start here -- 02 July 2014
                //---------------------------------------------------------------------
                //List<Account> AccountList = new List<Account>();
                //AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                //AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                //ddlClient.DataSource = AccountList;
                //ddlClient.DataBind();
                //ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                //---------------------------------------------------------------------
                // Do not delete code ends here -- 02 July 2014
                //---------------------------------------------------------------------
                //Clear();

                //if (ddlOffice.Items.Count > 1)
                //{
                //    ddlOffice.SelectedIndex = 2;
                //}

                //ddlHRContact.Items.Clear();
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                pnlPlans_Next.Visible = false;
                ddlPlanType.Items.Clear();
                ddlCommisionPaidBy.Items.Clear();
                rdlPlan.SelectedIndex = 0;
                txtAdministrator.Text = "";
                txtDepartment.Text = "";
                txtOffice.Text = "";
                txtPrimaryContact.Text = "";
                txtPrimaryService.Text = "";
                txtPrimarySales.Text = "";

                if (ddlClient.SelectedIndex != 0)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    List<Contact> ContactList = new List<Contact>();

                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountTeamMemberDS = new DataSet();
                    DataSet AccountDS = new DataSet();

                    sd.BuildAccountTable();
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();

                    string SalesLead_FirstName = string.Empty;
                    string SalesLead_LastName = string.Empty;

                    string ServiceLead_FirstName = string.Empty;
                    string ServiceLead_LastName = string.Empty;
                    string Admin_FirstName = string.Empty;
                    string Admin_LastName = string.Empty;
                    string ServicePrimary_FirstName = string.Empty;
                    string ServicePrimary_LastName = string.Empty;
                    string DepartmentID = string.Empty;

                    DataTable plantable = CreatePlanInfoTable();


                    sd.BuildProductTable();
                    AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    Session["Contact"] = ContactList;
                    Session["AccountDS"] = AccountDS;

                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                        Session["AccountTeamMemberDS"] = AccountTeamMemberDS;
                    }
                    ////if (ddlClient.SelectedValue != "")
                    ////{
                    ////    AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    ////}



                    /*  Commented by shravan - Issue #1
                     //Logic for Primary Contact from Contact List
                     var PrimaryName = ContactList.Where(c => c.PrimaryFlag == true).Select(x => x.Name).SingleOrDefault();
                     if (PrimaryName != null)
                     {
                         txtPrimaryContact.Text = PrimaryName.ToString();
                     }
                     else
                     {
                         txtPrimaryContact.Text = "";
                     } */


                    #region Binding txt boxes
                    //Logic for Primary SAles and Primary Service
                    if (AccountDS != null)
                    {
                        if (AccountDS.Tables[1].Rows.Count > 0)
                        {
                            for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                            {
                                if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                                {
                                    for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                                    {
                                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                        {
                                            SalesLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                            SalesLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                        }

                                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                        {
                                            ServiceLead_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                            ServiceLead_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);

                                        }
                                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["administratorUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                        {
                                            Admin_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                            Admin_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);

                                        }
                                        if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryContactUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                        {
                                            ServicePrimary_FirstName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]);
                                            ServicePrimary_LastName = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);

                                        }

                                    }
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim() != "")
                                {
                                    DepartmentID = Convert.ToString(AccountDS.Tables[1].Rows[j]["departmentID"]).Trim();
                                }
                            }
                        }
                    }


                    //binding values to txtboxes
                    txtPrimaryContact.Text = ServicePrimary_FirstName + " " + ServicePrimary_LastName;
                    txtPrimarySales.Text = SalesLead_FirstName + " " + SalesLead_LastName;
                    txtPrimaryService.Text = ServiceLead_FirstName + " " + ServiceLead_LastName;
                    txtAdministrator.Text = Admin_FirstName + " " + Admin_LastName;

                    string Account_Region = string.Empty;
                    string Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);
                    txtOffice.Text = Account_Office;
                    Session["Account_Office"] = Account_Office;
                    Session["Account_Region"] = Account_Region;



                    //Code for binding Department 
                    if (DictDepartment.ContainsKey(DepartmentID))
                    {
                        txtDepartment.Text = DictDepartment[DepartmentID];
                    }
                    #endregion

                    if (ddlClient.SelectedIndex > 0)
                    {
                        PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }


                    #region Code for PlanType Binding
                    string _PlanName = string.Empty;
                    DataTable itemTable = new DataTable();
                    itemTable.Columns.Add("PlanTypeDescription", typeof(string));
                    itemTable.Columns.Add("PlanTypeValue", typeof(string));
                    List<string> lstPlanNames = new List<string>();
                    //LoadPlanTypeIds();
                    foreach (Plan item in PlanList)
                    {
                        _PlanName = GetPlanName(Convert.ToInt16(item.ProductTypeId));
                        if (_PlanName.Trim() != "")
                            if (!lstPlanNames.Contains(_PlanName))
                            {
                                DataRow row = itemTable.NewRow();
                                row["PlanTypeDescription"] = _PlanName;
                                row["PlanTypeValue"] = _PlanName;
                                itemTable.Rows.Add(row);
                                lstPlanNames.Add(_PlanName);
                            }
                    }
                    #endregion

                    DictClientCarrier.Clear();

                    #region Getting Product DS from PlanList
                    foreach (Plan plan in PlanList)
                    {

                        DataRow row = plantable.NewRow();
                        row["Carrier"] = plan.CarrierName;
                        row["Name"] = plan.ProductName;
                        row["Effective"] = plan.EffectiveDate.ToString();
                        row["Renewal"] = plan.RenewalDate.ToString();
                        row["PolicyNumber"] = plan.PolicyNumber.ToString();
                        row["ProductId"] = plan.ProductId.ToString();
                        row["ProductName"] = plan.ProductName;
                        row["ProductTypeId"] = plan.ProductTypeId.ToString();
                        row["PlanType"] = plan.ProductTypeDescription;
                        row["SummaryName"] = plan.SummaryName;
                        row["SummaryID"] = plan.SummaryID;
                        plantable.Rows.Add(row);

                        if (!DictClientCarrier.ContainsKey(plan.CarrierId.ToString()))
                            DictClientCarrier.Add(plan.CarrierId.ToString(), plan.CarrierName);
                    }


                    ProductDS = sd.GetProductDetail(plantable, SessionId);


                    #endregion
                    Session["ProductDS"] = ProductDS;

                    #region Commented by shravan (Moved to ddlPlanType Selected index change)


                    //var billingCarrierList = (from row in ProductDS.Tables[1].AsEnumerable() group row by row.Field<int>("billingCarrierID") into r select r).ToList();
                    //DataTable BillingCarrierTable = new DataTable();
                    //BillingCarrierTable.Columns.Add("CarrierId", typeof(string));
                    //BillingCarrierTable.Columns.Add("CarrierName", typeof(string));

                    //foreach (var carrierid in billingCarrierList)
                    //{
                    //    string carrierID = carrierid.Key.ToString().Trim();
                    //    if (DictCarrier.ContainsKey(carrierID))
                    //    {
                    //        DataRow row = BillingCarrierTable.NewRow();
                    //        row["CarrierId"] = carrierID;
                    //        row["CarrierName"] = DictCarrier[carrierID];
                    //        BillingCarrierTable.Rows.Add(row);
                    //    }
                    //}
                    //DataView DVCarrier = BillingCarrierTable.DefaultView;
                    //DVCarrier.Sort = "CarrierName";
                    //ddlCommisionPaidBy.DataSource = DVCarrier;
                    //ddlCommisionPaidBy.DataBind();

                    //commonPlanList = PlanList.GroupBy(p => p.ProductTypeId).Select(g => g.First()).OrderBy(q => q.ProductTypeDescription).ToList<Plan>();
                    //Session["PlanList"] = PlanList; 
                    #endregion


                    ddlPlanType.DataSource = itemTable; //commonPlanList;
                    ddlPlanType.DataBind();
                    ddlPlanType.Items.Insert(0, new ListItem("Select", "0"));
                    ddlPlanType.Items.Insert(ddlPlanType.Items.Count, new ListItem("All", "-1"));

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }



        protected void ddlPlanType_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlPlans_Next.Visible = false;
            ddlCommisionPaidBy.Items.Clear();
            rdlPlan.SelectedIndex = 0;
            if (ddlPlanType.SelectedIndex != 0)
            {
                DataSet ProductDS = Session["ProductDS"] as DataSet;

                Dictionary<string, string> DictBillingCarrier = new Dictionary<string, string>();
                DictBillingCarrier.Clear();

                DataTable BillingCarrierTable = new DataTable();
                BillingCarrierTable.Columns.Add("CarrierId", typeof(string));
                BillingCarrierTable.Columns.Add("CarrierName", typeof(string));

                foreach (DataRow Product in ProductDS.Tables[1].Rows)
                {
                    if (Product["productTypeID"] != null && Product["productTypeID"].ToString().Trim() != "")
                        if (ddlPlanType.SelectedValue.ToString() == "-1" || DictPlanType[ddlPlanType.SelectedValue].ContainsKey(Convert.ToInt32(Product["productTypeID"])))
                        {
                            string billingCarrierID = Product["billingCarrierID"].ToString();
                            if (billingCarrierID != "" && !DictBillingCarrier.ContainsKey(billingCarrierID))
                            {
                                DictBillingCarrier.Add(billingCarrierID, billingCarrierID);
                                if (DictCarrier.ContainsKey(billingCarrierID))
                                {
                                    DataRow row = BillingCarrierTable.NewRow();
                                    row["CarrierId"] = billingCarrierID;
                                    row["CarrierName"] = DictCarrier[billingCarrierID];
                                    BillingCarrierTable.Rows.Add(row);
                                }

                            }

                        }
                }


                #region Commented by shravan
                //var billingCarrierList = (from row in ProductDS.Tables[1].AsEnumerable() group row by row.Field<int>("billingCarrierID") into r select r).ToList();
                //DataTable BillingCarrierTable = new DataTable();
                //BillingCarrierTable.Columns.Add("CarrierId", typeof(string));
                //BillingCarrierTable.Columns.Add("CarrierName", typeof(string));

                //foreach (var carrierid in billingCarrierList)
                //{
                //    string carrierID = carrierid.Key.ToString().Trim();
                //    if (DictCarrier.ContainsKey(carrierID))
                //    {
                //        DataRow row = BillingCarrierTable.NewRow();
                //        row["CarrierId"] = carrierID;
                //        row["CarrierName"] = DictCarrier[carrierID];
                //        BillingCarrierTable.Rows.Add(row);
                //    }
                //} 
                #endregion

                DataView DVBillingCarrier = BillingCarrierTable.DefaultView;
                DVBillingCarrier.Sort = "CarrierName";
                ddlCommisionPaidBy.DataSource = DVBillingCarrier;
                ddlCommisionPaidBy.DataBind();
                ddlCommisionPaidBy.Items.Insert(0, new ListItem("All", "-1"));
            }

        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("SummaryName", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }



        public void LoadPlanTypeIds()
        {

            // Medical Plan Type Id's
            MedicalPlanTypeList.Clear();
            MedicalPlanTypeList.Add(100);       // Medical HMO
            MedicalPlanTypeList.Add(110);       // Medical PPO
            MedicalPlanTypeList.Add(120);       // Medical PPO (3-Tier)
            MedicalPlanTypeList.Add(130);       // Medical POS (2-Tier)
            MedicalPlanTypeList.Add(140);       // Medical POS (3-Tier)
            MedicalPlanTypeList.Add(150);       // Medical EPO (1-Tier)
            MedicalPlanTypeList.Add(160);       // Medical EPO (2-Tier)
            MedicalPlanTypeList.Add(170);       // Medical Indemnity
            MedicalPlanTypeList.Add(173);
            MedicalPlanTypeList.Add(233);       // Limited Benefit 2-Tier
            MedicalPlanTypeList.Add(235);       // Stop Loss
            MedicalPlanTypeList.Add(420);       // International Bundled Plan (3-Tier)
            MedicalPlanTypeList.Add(1116);      //Medical Plan Riders
            MedicalPlanTypeList.Add(1240);      //Short Term Medical
            MedicalPlanTypeList.Add(1260);      //Medicare Supplement
            MedicalPlanTypeList.Add(5060);      //Hospitalization Only

            // Dental Plan Type Id's
            DentalPlanTypeList.Clear();
            DentalPlanTypeList.Add(180);        // Managed Dental
            DentalPlanTypeList.Add(190);        // Dental PPO
            DentalPlanTypeList.Add(200);        // Dental Triple Option
            DentalPlanTypeList.Add(210);        // Dental Indemnity

            // Vision Plan Type Id's
            VisionPlanTypeList.Clear();
            VisionPlanTypeList.Add(230);        // Vision

            // Life AD&D Plan Type Id's
            LifeADDPlanTypeList.Clear();
            LifeADDPlanTypeList.Add(240);       // Life and AD&D
            LifeADDPlanTypeList.Add(250);       // Group Term Life
            LifeADDPlanTypeList.Add(260);
            LifeADDPlanTypeList.Add(270);       // AD&D
            LifeADDPlanTypeList.Add(280);
            LifeADDPlanTypeList.Add(1150);
            LifeADDPlanTypeList.Add(1230);
            LifeADDPlanTypeList.Add(5070);


            // Wellness Plan Type Id's
            WellnessPlanTypeList.Clear();
            WellnessPlanTypeList.Add(317);     // Wellness Program
            WellnessPlanTypeList.Add(1740);


            // Addtional product 
            DisabilityPlanTypeList.Clear();
            DisabilityPlanTypeList.Add(290);
            DisabilityPlanTypeList.Add(292); //New York DBL
            DisabilityPlanTypeList.Add(293); //New Jersey TDB
            DisabilityPlanTypeList.Add(294); //Hawaii TDI
            DisabilityPlanTypeList.Add(300);
            DisabilityPlanTypeList.Add(1460);

            AccidentTypeList.Clear();
            AccidentTypeList.Add(320);
            AccidentTypeList.Add(5500);

            AncillaryPlanTypeList.Clear();
            AncillaryPlanTypeList.Add(310);
            AncillaryPlanTypeList.Add(1104);
            AncillaryPlanTypeList.Add(1109);
            AncillaryPlanTypeList.Add(1114);
            AncillaryPlanTypeList.Add(1115);
            AncillaryPlanTypeList.Add(1160);
            AncillaryPlanTypeList.Add(1400);
            AncillaryPlanTypeList.Add(1480);
            AncillaryPlanTypeList.Add(1720);
            AncillaryPlanTypeList.Add(1790);
            AncillaryPlanTypeList.Add(3090);
            AncillaryPlanTypeList.Add(5330);
            AncillaryPlanTypeList.Add(5340);
            AncillaryPlanTypeList.Add(5460);
            AncillaryPlanTypeList.Add(1890);
            // 5500 Filing 

            FeePlanTypeList.Clear();
            FeePlanTypeList.Add(1108);
            FeePlanTypeList.Add(1111);
            FeePlanTypeList.Add(5885);

            FinancialPlanTypeList.Clear();
            FinancialPlanTypeList.Add(1107);
            FinancialPlanTypeList.Add(340);
            FinancialPlanTypeList.Add(178);
            FinancialPlanTypeList.Add(179);
            FinancialPlanTypeList.Add(330);

            DictPlanType.Clear();
            DictPlanType.Add(cv.MedicalLOC, MedicalPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.DentalLOC, DentalPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.VisionLOC, VisionPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.LifeADDLOC, LifeADDPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.Wellness, WellnessPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.Disability, DisabilityPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add(cv.Accident, AccidentTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add("Ancillary", AncillaryPlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add("Fees", FeePlanTypeList.ToDictionary(x => x, x => x));
            DictPlanType.Add("Financial", FinancialPlanTypeList.ToDictionary(x => x, x => x));

        }

        //Returns PlanType by taking PlanTypeID
        public string GetPlanName(int PlanTypeId)
        {
            string _planName = string.Empty;

            try
            {
                // Medical
                foreach (var item in MedicalPlanTypeList)
                {
                    if (MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.MedicalLOC;
                    }
                }


                // Dental
                foreach (var item in DentalPlanTypeList)
                {
                    if (DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.DentalLOC;
                    }
                }

                // Vision
                foreach (var item in VisionPlanTypeList)
                {
                    if (VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VisionLOC;
                    }
                }

                // Life and AD&D
                foreach (var item in LifeADDPlanTypeList)
                {
                    if (LifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LifeADDLOC;
                    }
                }



                // Wellness
                foreach (var item in WellnessPlanTypeList)
                {
                    if (WellnessPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Wellness;
                    }
                }


                //Disability
                foreach (var item in DisabilityPlanTypeList)
                {
                    if (DisabilityPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Disability;
                    }
                }


                //Accident
                foreach (var item in AccidentTypeList)
                {
                    if (AccidentTypeList.Contains(PlanTypeId))
                    {
                        return cv.Accident;
                    }
                }

                //Ancillary
                foreach (var item in AncillaryPlanTypeList)
                {
                    if (AncillaryPlanTypeList.Contains(PlanTypeId))
                    {
                        return "Ancillary";
                    }
                }


                //Fees
                foreach (var item in FeePlanTypeList)
                {
                    if (FeePlanTypeList.Contains(PlanTypeId))
                    {
                        return "Fees";
                    }
                }

                //Financial
                foreach (var item in FinancialPlanTypeList)
                {
                    if (FinancialPlanTypeList.Contains(PlanTypeId))
                    {
                        return "Financial";
                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _planName;
        }

        protected void ddlCommisionPaidBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            rdlPlan.SelectedIndex = 0;
            pnlPlans_Next.Visible = false;
        }

    }
}