﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.DAL;
using BenefitPointSummaryPortal.BAL.OfficeAddress;
using BenefitPointSummaryPortal.BAL.BenefitSummary;

namespace BenefitPointSummaryPortal.View
{
    public partial class Admin_OfficeAddress : System.Web.UI.Page
    {
        BPSummary bp = new BPSummary();
        DBHelper DB_helper = new DBHelper();
        OfficeAddressOperations OfficeAddressOps;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindStateDropDown();
                ddlSearchState_SelectedIndexChanged(null, null);
                ddlState_SelectedIndexChanged(null, null);
                btnSearch_Click(null, null);
                txtSearchRegion.Focus();
                mvClientContact.ActiveViewIndex = 0;
                hdnSrNo.Value = "0";
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchOfficeAddress();
        }

        private void SearchOfficeAddress()
        {
            try
            {
                string strRegion = txtSearchRegion.Text.Trim();
                string strCity = ddlSearchCity.SelectedValue.Trim();
                string strState = ddlSearchState.SelectedValue;

                OfficeAddressOps = new OfficeAddressOperations();
                DataTable dtblOfficeAddress = OfficeAddressOps.SearchOfficeAddress(strRegion, strCity, strState);

                grdAddresses.DataSource = dtblOfficeAddress;
                grdAddresses.DataBind();

                ClearAddressDetailForm();
            }
            catch (Exception ex)
            {
            }
        }

        protected void bntSave_Click(object sender, EventArgs e)
        {
            try
            {
                OfficeAddressOps = new OfficeAddressOperations();


                if (string.IsNullOrEmpty(txtDivNo.Text))
                {
                    txtDivNo.Text = "0";
                }
                bool flag = OfficeAddressOps.InsertUpdateOfficeAddressDetails(int.Parse(hdnSrNo.Value), int.Parse(txtDivNo.Text), txtRegion.Text.Trim(), txtOfficeName.Text.Trim(), txtDivName.Text.Trim(), txtStreetAddress.Text.Trim(), ddlAddCity.SelectedValue.Trim(), ddlState.SelectedValue, txtZip.Text.Trim(), txtPhone.Text.Trim(), txtFax.Text.Trim());
                if (flag)
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Office address updated successfully.')</script>", false);
                    mvClientContact.ActiveViewIndex = 0;
                    ClearAddressDetailForm();
                    hdnSrNo.Value = "0";
                    btnClear_Click(null, null);
                    btnSearch_Click(null, null);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while insert/updating record, please try again')</script>", false);
                }
                BindStateDropDown();
            }
            catch (Exception ex)
            {
                BPBusiness bp = new BPBusiness();
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            mvClientContact.ActiveViewIndex = 0;
            txtSearchRegion.Focus();
            hdnSrNo.Value = "0";
        }

        protected void grdPlans_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string RowCommand = e.CommandName;
            if (RowCommand == "EditAddress")
            {
                mvClientContact.ActiveViewIndex = 1;
                txtOfficeName.Focus();
                ClearAddressDetailForm();
                FillAddressDetails(int.Parse(e.CommandArgument.ToString()));
                bntSave.Text = "Update";
            }
            else if (RowCommand == "DeleteAddress")
            {
                try
                {
                    OfficeAddressOps = new OfficeAddressOperations();
                    bool IsSuccess = OfficeAddressOps.DeleteOfficeAddressDetails(int.Parse(e.CommandArgument.ToString()));
                    if (IsSuccess)
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Office Address deleted successfully.')</script>", false);
                        btnSearch_Click(null, null);
                    }
                    else
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while deleting record, please try again')</script>", false);
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void ClearAddressDetailForm()
        {

            txtDivNo.Text = "";
            txtRegion.Text = "";
            txtOfficeName.Text = "";
            txtDivName.Text = "";
            txtStreetAddress.Text = "";
            ddlState.SelectedIndex = 0;
            ddlState_SelectedIndexChanged(null, null);
            ddlAddCity.SelectedIndex = 0;

            txtZip.Text = "";
            txtPhone.Text = "";
            txtFax.Text = "";
        }

        private void FillAddressDetails(int SrNo)
        {
            hdnSrNo.Value = SrNo.ToString();
            OfficeAddressOps = new OfficeAddressOperations();
            DataTable dtblOfficeeAddress = OfficeAddressOps.GetOfficeAddressById(SrNo);
            if (dtblOfficeeAddress != null && dtblOfficeeAddress.Rows.Count > 0)
            {
                txtDivNo.Text = dtblOfficeeAddress.Rows[0]["DIV#NOText"].ToString();
                txtRegion.Text = dtblOfficeeAddress.Rows[0]["BPRegion"].ToString();
                txtOfficeName.Text = dtblOfficeeAddress.Rows[0]["BPOfficeName"].ToString();
                txtDivName.Text = dtblOfficeeAddress.Rows[0]["DivName"].ToString();
                txtStreetAddress.Text = dtblOfficeeAddress.Rows[0]["OffStreetAdd"].ToString();
                if (ddlState.Items.Contains(new ListItem(dtblOfficeeAddress.Rows[0]["State"].ToString(), dtblOfficeeAddress.Rows[0]["State"].ToString())))
                    ddlState.SelectedValue = dtblOfficeeAddress.Rows[0]["State"].ToString();
                else
                    ddlState.SelectedIndex = 0;

                ddlState_SelectedIndexChanged(null, null);

                if (ddlAddCity.Items.Contains(new ListItem(dtblOfficeeAddress.Rows[0]["City"].ToString().Trim(), dtblOfficeeAddress.Rows[0]["City"].ToString().Trim())))
                    ddlAddCity.SelectedValue = dtblOfficeeAddress.Rows[0]["City"].ToString();
                else
                    ddlAddCity.SelectedIndex = 0;

                txtZip.Text = dtblOfficeeAddress.Rows[0]["Zip"].ToString();
                txtPhone.Text = dtblOfficeeAddress.Rows[0]["OffPhoneNumber"].ToString();
                txtFax.Text = dtblOfficeeAddress.Rows[0]["OfficeFaxNumber"].ToString();
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            hdnSrNo.Value = "0";
            mvClientContact.ActiveViewIndex = 1;
            txtOfficeName.Focus();
            ClearAddressDetailForm();
            bntSave.Text = "Save";
        }

        private void BindStateDropDown()
        {
            BPBusiness bp = new BPBusiness();
            DataTable dtOfficeState = new DataTable();
            dtOfficeState = bp.GetOfficeStateList();

            ddlSearchState.DataSource = dtOfficeState;
            ddlSearchState.DataBind();

            ddlState.DataSource = dtOfficeState;
            ddlState.DataBind();
        }

        protected void ddlSearchState_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCity(ddlSearchCity, ddlSearchState.SelectedValue);
        }

        private void BindCity(DropDownList objddlCity, string State)
        {
            OfficeAddressOps = new OfficeAddressOperations();
            DataTable dtOfficeCity = new DataTable();
            dtOfficeCity = OfficeAddressOps.GetOfficeStateCities(State);
            objddlCity.Items.Clear();
            if (dtOfficeCity.Rows.Count > 0)
            {
                objddlCity.DataSource = dtOfficeCity;
                objddlCity.DataBind();
            }
            objddlCity.Items.Insert(0, new ListItem("Select", ""));
            objddlCity.SelectedIndex = 0;
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCity(ddlAddCity, ddlState.SelectedValue);
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearchRegion.Text = "";
            ddlSearchState.SelectedIndex = 0;
            ddlSearchState_SelectedIndexChanged(null, null);
        }

        protected void btnStatePopUp_Click(object sender, EventArgs e)
        {
            txtNewState.Focus();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "MypopUp", "MypopUp();", true);
        }

        protected void btnAddState_Click(object sender, EventArgs e)
        {

            string strNewState = txtNewState.Text.Trim();
            ListItemCollection items = ddlState.Items;
            bool IsFound = false;
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Text.ToLower().Equals(strNewState.ToLower()))
                {
                    ddlState.SelectedIndex = i;
                    IsFound = true;
                    break;
                }
            }
            if (!IsFound)
            {
                ddlState.Items.Add(new ListItem(strNewState));
                ddlState.DataBind();
                ddlState.SelectedIndex = ddlState.Items.Count - 1;
            }

            txtNewState.Text = "";
        }

        protected void btnCityPopUp_Click(object sender, EventArgs e)
        {
            txtAddNewCity.Focus();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "MypopUpCity", "MypopUpCity();", true);
        }

        protected void btnAddCity_Click(object sender, EventArgs e)
        {

            string strNewCity = txtAddNewCity.Text.Trim();
            ListItemCollection items = ddlAddCity.Items;
            bool IsFound = false;
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Text.ToLower().Equals(strNewCity.ToLower()))
                {
                    ddlAddCity.SelectedIndex = i;
                    IsFound = true;
                    break;
                }
            }
            if (!IsFound)
            {
                ddlAddCity.Items.Add(new ListItem(strNewCity));
                ddlAddCity.DataBind();
                ddlAddCity.SelectedIndex = ddlAddCity.Items.Count - 1;
            }

            txtAddNewCity.Text = "";

        }

    }
}
