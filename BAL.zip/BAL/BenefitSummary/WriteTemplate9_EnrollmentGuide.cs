﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate9_EnrollmentGuide : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;

        private void GetPlanTableFirstColumnHeadingName_And_ColorFormatting(Word.Document oWordDoc, DataTable PlanTable, DataSet BenefitDS, int rowindex, int TableNo_FirstTable, string selectedColor, string PlanTypeName)
        {
            Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
            Word.WdColor wdColor_cell = comFunObj.cell_color(selectedColor);

            oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
            for (int i = 1; i <= oWordDoc.Tables[TableNo_FirstTable].Rows.Count; i++)
            {
                // For Medical table background shading color formatting
                if (PlanTypeName == cv.MedicalLOC)
                {
                    if (i == 1 || i == 2 || i == 14)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }

                    //oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                    if (i > 2 && i < 14)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 2).Range.Shading.BackgroundPatternColor = wdColor_cell;
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 4).Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                    if (i > 14)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Font.Color = WdColor.wdColorWhite;
                    }
                    oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[TableNo_FirstTable].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[TableNo_FirstTable].Rows[14].Range.Font.Color = WdColor.wdColorWhite;
                }

                // For Dental table background shading color formatting
                else if (PlanTypeName == cv.DentalLOC)
                {
                    if (i == 1 || i == 7)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                    if (i > 7)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Font.Color = WdColor.wdColorWhite;
                    }
                    oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[TableNo_FirstTable].Rows[7].Range.Font.Color = WdColor.wdColorWhite;
                }
                // For Vison table background shading color formatting
                else if (PlanTypeName == cv.VisionLOC)
                {
                    if (i == 1 || i == 2 || i == 8)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                    if (i > 2 && i < 8)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 2).Range.Shading.BackgroundPatternColor = wdColor_cell;
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 4).Range.Shading.BackgroundPatternColor = wdColor_cell;

                        if (i == 6)
                        {
                            oWordDoc.Tables[TableNo_FirstTable].Cell(i, 3).Range.Shading.BackgroundPatternColor = wdColor_cell;
                            oWordDoc.Tables[TableNo_FirstTable].Cell(i, 5).Range.Shading.BackgroundPatternColor = wdColor_cell;
                        }
                    }
                    if (i > 8)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 1).Range.Font.Color = WdColor.wdColorWhite;
                    }
                    oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[TableNo_FirstTable].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[TableNo_FirstTable].Rows[8].Range.Font.Color = WdColor.wdColorWhite;
                }
                // For LTD table background shading color formatting
                else if (PlanTypeName == cv.LTDPlanType_CommonCriteria || PlanTypeName == cv.STDPlanType_CommonCriteria)
                {
                    if (i == 1)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    }
                    if (i > 1 && i <= 5)
                    {
                        oWordDoc.Tables[TableNo_FirstTable].Cell(i, 2).Range.Shading.BackgroundPatternColor = wdColor_cell;
                    }
                    oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                }
                ////// For Life & ADnD table background shading color formatting
                ////else if (PlanTypeName == cv.LifeADDLOC || PlanTypeName == cv.VoluntaryLifeADDLOC)
                ////{
                ////    if (i == 2)
                ////    {
                ////        oWordDoc.Tables[TableNo_FirstTable].Range.Font.Color = wdColor_font;
                ////        oWordDoc.Tables[TableNo_FirstTable].Rows[i].Range.Shading.BackgroundPatternColor = wdColor_cell;
                ////    }
                ////}
            }


        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList"></param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        /// <param name="NumberofPlan">string NumberofPlan Object</param>
        /// <param name="selectedColor">string selectedColor Object (Optional Parameter)</param>
        /// <param name="MedicalBenefitColumnId_Tier3">ArrayList MedicalBenefitColumnId_Tier3 Object (Optional Parameter)</param>
        /// <param name="BenefitStructureDS">DataSet BenefitStructureDS Object (Optional Parameter)</param>
        public void WriteMedicalSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, string NumberofPlan, string selectedColor = "", ArrayList MedicalBenefitColumnId_Tier3 = null, DataSet BenefitStructureDS = null)
        {
            try
            {
                DataRow[] foundRows = null;

                #region HashtableMedicalInNetwork
                Hashtable HashtableMedicalInNetwork1 = new Hashtable();
                HashtableMedicalInNetwork1.Add(3, "16");       // Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalInNetwork1.Add(4, "386");      //Physician Office Visit (Primary)
                HashtableMedicalInNetwork1.Add(5, "414");      //Specialists Office Visit

                HashtableMedicalInNetwork1.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalInNetwork1.Add(7, "971");            //Other Services[Complex Radiology]

                HashtableMedicalInNetwork1.Add(8, "555");      //Urgent Care
                HashtableMedicalInNetwork1.Add(9, "184");      //Emergency Room
                HashtableMedicalInNetwork1.Add(110, "45");      //Calendar Year Deductible individual
                HashtableMedicalInNetwork1.Add(10, "44");       //Calendar Year Deductible Family
                HashtableMedicalInNetwork1.Add(111, "295");     //Hospital/Facility[Inpatient Care]
                HashtableMedicalInNetwork1.Add(11, "409");      //Hospital/Facility[Outpatient Care]
                HashtableMedicalInNetwork1.Add(113, "53");     //Calendar Year Out of Pocket Maximum(Individual)
                HashtableMedicalInNetwork1.Add(13, "52");      //Calendar Year Out of Pocket Maximum(Family)

                ArrayList arrMedicalInNetwork = new ArrayList();
                foreach (int key in HashtableMedicalInNetwork1.Keys)
                {
                    arrMedicalInNetwork.Add(key);
                }

                arrMedicalInNetwork.Sort();
                arrMedicalInNetwork.Reverse();
                #endregion

                #region HashtableMedicalOutNetwork
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedicalOutNetwork.Add(3, "16");       // Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedicalOutNetwork.Add(4, "386");      //Physician Office Visit (Primary)
                HashtableMedicalOutNetwork.Add(5, "414");      //Specialists Office Visit

                HashtableMedicalOutNetwork.Add(6, "168");   //Other Services[Diagnostic X-Ray and Lab Tests]
                HashtableMedicalOutNetwork.Add(7, "971");            //Other Services[Complex Radiology]

                HashtableMedicalOutNetwork.Add(8, "555");      //Urgent Care
                HashtableMedicalOutNetwork.Add(9, "184");      //Emergency Room
                HashtableMedicalOutNetwork.Add(110, "45");      //Calendar Year Deductible individual
                HashtableMedicalOutNetwork.Add(10, "44");       //Calendar Year Deductible Family
                HashtableMedicalOutNetwork.Add(111, "295");     //Hospital/Facility[Inpatient Care]
                HashtableMedicalOutNetwork.Add(11, "409");      //Hospital/Facility[Outpatient Care]
                HashtableMedicalOutNetwork.Add(113, "53");     //Calendar Year Out of Pocket Maximum(Individual)
                HashtableMedicalOutNetwork.Add(13, "52");      //Calendar Year Out of Pocket Maximum(Family)






                ArrayList arrMedicalOutNetwork = new ArrayList();
                foreach (int key in HashtableMedicalOutNetwork.Keys)
                {
                    arrMedicalOutNetwork.Add(key);
                }

                arrMedicalOutNetwork.Sort();
                arrMedicalOutNetwork.Reverse();
                #endregion

                int count = 1;

                int TableNo_FirstTable = 2;
                ArrayList arrPlanTypeIds = new ArrayList();

                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                ConstantValue cv = new ConstantValue();
                string Carrier = "";
                string OldCarrier = "";
                ArrayList arrCarrierName = new ArrayList();
                ArrayList arrPlanNumber = new ArrayList();
                string planNumber = string.Empty;
                string Annual_Deductible_InNetwork = string.Empty;
                string Annual_Deductible_OutNetwork = string.Empty;
                string Inpatient_Hospitalization_InNetwork = string.Empty;
                string Inpatient_Hospitalization_OutNetwork = string.Empty;
                string Out_Of_Pocket_Individual_InNetwork = string.Empty;
                string Out_Of_Pocket_Individual_OutNetwork = string.Empty;
                string MedicalCarrierName1 = string.Empty;
                string MedicalCarrierName2 = string.Empty;
                string MedicalCarrierName3 = string.Empty;
                string MedicalCarrierName4 = string.Empty;
                string MedicalCarrierName5 = string.Empty;
                string MedicalCarrierName6 = string.Empty;
                string value = string.Empty;
                int colCntInNetwork = 0;
                int colCntOutNetwork = 0;
                bool deletePlan2 = true;
                bool deletePlan3 = true;
                bool deletePlan4 = true;
                bool deletePlan5 = true;
                bool deletePlan6 = true;

                Dictionary<int, string> dicRepeatedPlans = new Dictionary<int, string>();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");

                            #region MedicalTable

                            if (OldCarrier != (PlanTable.Rows[rowindex]["Carrier"].ToString().Trim()))
                            {
                                if (OldCarrier == "")
                                {
                                    Carrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                                    arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                }
                                else
                                {
                                    if (!arrCarrierName.Contains(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim()))
                                    {
                                        Carrier = Carrier + " and " + (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim()) + " ";
                                        arrCarrierName.Add(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim());
                                    }
                                }
                                OldCarrier = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }

                            if (count == 1)
                            {
                                TableNo_FirstTable = 2;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName1 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            }
                            if (count == 2)
                            {
                                TableNo_FirstTable = 3;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName2 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();

                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    TableNo_FirstTable = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    deletePlan2 = false;
                                }
                            }
                            if (count == 3)
                            {
                                TableNo_FirstTable = 4;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName3 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();

                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    TableNo_FirstTable = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    deletePlan3 = false;
                                }
                            }
                            if (count == 4)
                            {
                                TableNo_FirstTable = 5;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName4 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();

                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    TableNo_FirstTable = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    deletePlan4 = false;
                                }
                            }
                            if (count == 5)
                            {
                                TableNo_FirstTable = 6;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName5 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();

                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    TableNo_FirstTable = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    deletePlan5 = false;
                                }
                            }
                            if (count == 6)
                            {
                                TableNo_FirstTable = 7;
                                colCntInNetwork = 2;
                                colCntOutNetwork = 3;
                                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, rowindex, TableNo_FirstTable, selectedColor, cv.MedicalLOC);
                                oWordDoc.Tables[TableNo_FirstTable].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                MedicalCarrierName6 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();

                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    TableNo_FirstTable = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                    oWordDoc.Tables[TableNo_FirstTable].Cell(1, 3).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["PolicyNumber"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(TableNo_FirstTable, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    deletePlan6 = false;
                                }
                            }

                            oWordDoc.Tables[TableNo_FirstTable].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                            foreach (int key in arrMedicalInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalInNetwork1[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();

                                        if (key == 110)
                                        {
                                            Annual_Deductible_InNetwork = value;
                                        }
                                        else if (key == 111)
                                        {
                                            Inpatient_Hospitalization_InNetwork = value;
                                        }
                                        else if (key == 113)
                                        {
                                            Out_Of_Pocket_Individual_InNetwork = value;
                                        }

                                        if (key == 10)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntInNetwork).Range.Text = Annual_Deductible_InNetwork + " / " + value;
                                        }
                                        else if (key == 11)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntInNetwork).Range.Text = Inpatient_Hospitalization_InNetwork + " / " + value;
                                        }
                                        else if (key == 13)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntInNetwork).Range.Text = Out_Of_Pocket_Individual_InNetwork + " / " + value + "\n" + "Once the out-of-pocket maximums is met, all covered expenses are paid at 100%";
                                        }
                                        else if (key != 110 && key != 111 && key != 113)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntInNetwork).Range.Text = value;
                                        }
                                    }
                                }
                            }

                            foreach (int key in arrMedicalOutNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedicalOutNetwork[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();

                                        if (key == 110)
                                        {
                                            Annual_Deductible_OutNetwork = value;
                                        }
                                        else if (key == 111)
                                        {
                                            Inpatient_Hospitalization_OutNetwork = value;
                                        }
                                        else if (key == 113)
                                        {
                                            Out_Of_Pocket_Individual_OutNetwork = value;
                                        }

                                        if (key == 10)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntOutNetwork).Range.Text = Annual_Deductible_OutNetwork + " / " + value;
                                        }
                                        else if (key == 11)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntOutNetwork).Range.Text = Inpatient_Hospitalization_OutNetwork + " / " + value;
                                        }
                                        else if (key == 13)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntOutNetwork).Range.Text = Out_Of_Pocket_Individual_OutNetwork + " / " + value + "\n" + "Once the out-of-pocket maximums is met, all covered expenses are paid at 100%";
                                        }
                                        else if (key != 110 && key != 111 && key != 113)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Cell(key, colCntOutNetwork).Range.Text = value;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region MergeField

                            int iTotalFields = 0;

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Medical_Plan_Effective_Date" + count))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[rowindex]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical_Plan_Renewal_Date" + count))
                                    {
                                        myMergeField.Select();
                                        string renewalDate = PlanTable.Rows[rowindex]["Renewal"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(renewalDate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewalDate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("HMO Plan Reminders"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical HMO")
                                        {
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText("HMO Plan Reminders");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("HMO_Plan_Selected"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() == "Medical HMO")
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }

                            #endregion

                            #region Code for Merging the rows
                            for (int rowNum = 1; rowNum <= oWordDoc.Tables[TableNo_FirstTable].Rows.Count; rowNum++)
                            {
                                if (rowNum == 1)
                                {
                                    for (int columnNum = 1; columnNum <= oWordDoc.Tables[TableNo_FirstTable].Columns.Count; columnNum++)
                                    {
                                        if (columnNum > 1)
                                        {
                                            oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells.Merge();
                                        }
                                        //oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells[2].Range.Text = oWordDoc.Tables[TableNo_FirstTable].Rows[rowNum].Cells[2].Range.Text.Replace("\r", " ");
                                        break;
                                    }
                                }
                            }
                            #endregion



                            count++;
                        }
                    }
                }

                #region merge Fields
                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("First Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName1);
                        }
                        if (fieldName.Contains("Second Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName2);
                        }
                        if (fieldName.Contains("Third Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName3);
                        }
                        if (fieldName.Contains("Fourth Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName4);
                        }
                        if (fieldName.Contains("Fifth Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName5);
                        }
                        if (fieldName.Contains("Sixth Medical Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(MedicalCarrierName6);
                        }
                        if (deletePlan2 == false)
                        {
                            if (fieldName.Contains("Delete Medical Plan 2"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (deletePlan3 == false)
                        {
                            if (fieldName.Contains("Delete Medical Plan 3"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (deletePlan4 == false)
                        {
                            if (fieldName.Contains("Delete Medical Plan 4"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (deletePlan5 == false)
                        {
                            if (fieldName.Contains("Delete Medical Plan 5"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (deletePlan6 == false)
                        {
                            if (fieldName.Contains("Delete Medical Plan 6"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }
                #endregion



            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WritePrescriptionDrugsSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList, ArrayList MedicalBenefitColumnId_Tier3 = null)
        {
            try
            {
                int count = 1;
                ConstantValue cv = new ConstantValue();
                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";
                string PreferredSpecialty = "";
                string Maximum_Day_Supply = string.Empty;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();

                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs.Add(4, "881");   //Prescription Categories[Preferred Specialty]
                HashtablePrescriptionDrugs.Add(5, "380");   //Prescription Categories[Maximum Day Supply]
                #endregion

                #region HashtablePrescriptionDrugs_OutNetwork
                Hashtable HashtablePrescriptionDrugs_OutNetwork = new Hashtable();
                HashtablePrescriptionDrugs_OutNetwork.Add(1, "213");    //Prescription Categories[Generic]
                HashtablePrescriptionDrugs_OutNetwork.Add(2, "78");     //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(3, "84");     //Prescription Categories[Non Formulary]
                HashtablePrescriptionDrugs_OutNetwork.Add(4, "881");    //Prescription Categories[Preferred Specialty]
                HashtablePrescriptionDrugs_OutNetwork.Add(5, "380"); //Prescription Categories[Maximum Day Supply]
                #endregion

                #region MailOrder
                Hashtable HashtableMailOrder = new Hashtable();

                //HashtableMailOrder.Add(1, "211");   //Mail Order[Generic]
                //HashtableMailOrder.Add(2, "76");    //Mail Order[Formulary]
                //HashtableMailOrder.Add(3, "82");    //Mail Order[Non Formulary]
                //HashtableMailOrder.Add(4, "884");   //Mail Order[Preferred Specialty]
                HashtableMailOrder.Add(1, "378");   //Mail Order[Maximum Day Supply]
                #endregion

                #region MailOrder_OutNetwork
                Hashtable HashtableMailOrder_OutNetwork = new Hashtable();
                //HashtableMailOrder_OutNetwork.Add(1, "211");    //Mail Order[Generic]
                //HashtableMailOrder_OutNetwork.Add(2, "76");     //Mail Order[Formulary]
                //HashtableMailOrder_OutNetwork.Add(3, "82");     //Mail Order[Non Formulary]
                //HashtableMailOrder_OutNetwork.Add(4, "884");    //Mail Order[Preferred Specialty]
                HashtableMailOrder_OutNetwork.Add(1, "378");    //Mail Order[Maximum Day Supply]
                #endregion

                int tableNumber = 2;
                int colCntInNetwork = 0;
                int colCntOutNetwork = 0;
                Dictionary<int, string> dicRepeatedPlans = new Dictionary<int, string>();

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {

                    value = "";
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";
                    PreferredSpecialty = "";
                    Maximum_Day_Supply = "";

                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            colCntInNetwork = 2;
                            colCntOutNetwork = 3;
                            if (count == 1)
                            {
                                tableNumber = 2;
                                dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                            }
                            else if (count == 2)
                            {
                                tableNumber = 3;
                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    tableNumber = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                }
                            }
                            else if (count == 3)
                            {
                                tableNumber = 4;
                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    tableNumber = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                }
                            }
                            else if (count == 4)
                            {
                                tableNumber = 5;
                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    tableNumber = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                }
                            }
                            else if (count == 5)
                            {
                                tableNumber = 6;
                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    tableNumber = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                }
                            }
                            else if (count == 6)
                            {
                                tableNumber = 7;
                                if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[rowindex]["ProductId"].ToString()))
                                {
                                    tableNumber = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[rowindex]["ProductId"].ToString());
                                    colCntInNetwork = 4;
                                    colCntOutNetwork = 5;
                                }
                                else
                                {
                                    dicRepeatedPlans.Add(tableNumber, PlanTable.Rows[rowindex]["ProductId"].ToString());
                                }
                            }

                            # region Priscription Drugs IN_Network
                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value + "\n"; break;
                                            case 2: Formulary = "Formulary: " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary: " + value + "\n"; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value + "\n"; break;
                                            //case 5: Maximum_Day_Supply = dr["value"].ToString(); break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[tableNumber].Cell(12, colCntInNetwork).Range.Text = Generic + Formulary + NonFormulary + PreferredSpecialty;

                            #endregion

                            # region Priscription Drugs Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";
                            Maximum_Day_Supply = "";

                            foreach (int key in HashtablePrescriptionDrugs_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs_OutNetwork[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 1: Generic = "Generic: " + value + "\n"; break;
                                            case 2: Formulary = "Formulary: " + value + "\n"; break;
                                            case 3: NonFormulary = "Non Formulary: " + value + "\n"; break;
                                            case 4: PreferredSpecialty = "Preferred Specialty: " + value + "\n"; break;
                                            //case 5: Maximum_Day_Supply = dr["value"].ToString(); break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[tableNumber].Cell(12, colCntOutNetwork).Range.Text = Generic + Formulary + NonFormulary + PreferredSpecialty;

                            #endregion

                            #region Mail Order In_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";
                            Maximum_Day_Supply = "";

                            foreach (int key in HashtableMailOrder.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 1: Maximum_Day_Supply = dr["value"].ToString(); break;
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Maximum_Day_Supply))
                            {
                                oWordDoc.Tables[tableNumber].Cell(12, colCntInNetwork).Range.Text = oWordDoc.Tables[tableNumber].Cell(12, colCntInNetwork).Range.Text + "Number of Days Supply for Mail Order: " + Maximum_Day_Supply;
                            }
                            #endregion

                            #region Mail Order Out_Network

                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";
                            Maximum_Day_Supply = "";

                            foreach (int key in HashtableMailOrder_OutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMailOrder_OutNetwork[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 1: Maximum_Day_Supply = dr["value"].ToString(); break;
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Maximum_Day_Supply))
                            {
                                oWordDoc.Tables[tableNumber].Cell(12, colCntOutNetwork).Range.Text = oWordDoc.Tables[tableNumber].Cell(12, colCntOutNetwork).Range.Text + "Number of Days Supply for Mail Order: " + Maximum_Day_Supply;
                            }
                            #endregion

                            count++;
                            value = "";
                            Generic = "";
                            Formulary = "";
                            NonFormulary = "";
                            PreferredSpecialty = "";
                            Maximum_Day_Supply = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        /// 
        public void WriteMonthlyPremiumSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS, string selectedColor = "", DataSet BenefitDS = null)
        {
            try
            {
                int DentalCount = 0;
                int VisionCount = 0;

                //Contribution frequency variables
                string FrequencyMEdical1 = "";
                string FrequencyMEdical2 = "";
                string FrequencyMEdical3 = "";
                string FrequencyMEdical4 = "";
                string FrequencyMEdical5 = "";
                string FrequencyMEdical6 = "";
                string FrequencyDental1 = "";
                string FrequencyDental2 = "";
                string FrequencyDental3 = "";
                string Frequencyvision = "";

                DataTable PremiumTableWriteMedical = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteMedical);

                DataTable PremiumTableWriteDental = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteDental);

                DataTable PremiumTableWriteVision = new DataTable();
                comFunObj.BuildContributionPremiumTable(ref PremiumTableWriteVision);

                int premTableMedical1 = 2;
                int dentalTableNo = 8;
                int visionTableNo = 11;
                ArrayList arrContributionID = new ArrayList();
                ArrayList arrContributionID_Dental = new ArrayList();
                ArrayList arrContributionID_Vision = new ArrayList();
                string strPlan_Contri1 = "";
                string strPlan_Contri2 = "";
                int MedicalTableRowCounter = 14;
                int DentalTableRowCounter = 2;
                int VisionTableRowCounter = 2;
                int medicalColumnNum = 1;
                int dentalColumnNum = 1;
                int visionColumnNum = 1;
                int contributionId_1 = 0;
                int contributionId_2 = 0;
                int RowCounter = 15;
                bool isFirstVisionHasOnlyOneContribution = false;
                bool isSecondVisionHasOnlyOneContribution = false;
                DataTable PremiumTable = new DataTable();
                Dictionary<int, string> dicRepeatedPlans = new Dictionary<int, string>();
                int rowNum = 14;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    strPlan_Contri1 = "";
                    strPlan_Contri2 = "";
                    PremiumTable.Clear();
                    PremiumTable = comFunObj.CreateContributionPremiumTable(PlanTable, ContributionDS, index);

                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId"].ToString()))
                    {
                        contributionId_1 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId"].ToString());
                    }
                    if (!string.IsNullOrEmpty(PlanTable.Rows[index]["ContributionId_2"].ToString()))
                    {
                        contributionId_2 = Convert.ToInt32(PlanTable.Rows[index]["ContributionId_2"].ToString());
                    }

                    DataTable dt1 = new DataTable();

                    PremiumTable.DefaultView.Sort = "[contributionValueID] asc";
                    //PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt1 = PremiumTable.DefaultView.ToTable(true);

                    // Code commented on 06 Dec 2016 - on request of Nicole
                    ////// The below for loop is for deleting rows having contribution value as 0
                    ////for (int k = 0; k < dt1.Rows.Count; k++)
                    ////{
                    ////    if (Convert.ToDecimal(dt1.Rows[k]["monthlycost"]) == 0)
                    ////    {
                    ////        dt1.Rows[k].Delete();
                    ////        k = k - 1;
                    ////    }
                    ////}

                    PremiumTable = dt1;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        rowNum = 14;
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["ContributionName"]).Trim());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["ContributionName_2"]).Trim());
                        }
                        if (index == 0)
                        {
                            premTableMedical1 = 2;
                            dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical1 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 1, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                        if (index == 1)
                        {
                            premTableMedical1 = 3;
                            if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[index]["ProductId"].ToString()))
                            {
                                premTableMedical1 = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 3;
                            }
                            else
                            {
                                dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 1;
                                arrContributionID.Clear();
                            }

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical2 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            MedicalTableRowCounter = 14;
                            RowCounter = 15;
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 2, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                        if (index == 2)
                        {
                            premTableMedical1 = 4;
                            if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[index]["ProductId"].ToString()))
                            {
                                premTableMedical1 = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 3;
                            }
                            else
                            {
                                dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 1;
                                arrContributionID.Clear();
                            }

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical3 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            MedicalTableRowCounter = 14;
                            RowCounter = 15;
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 3, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                        if (index == 3)
                        {
                            premTableMedical1 = 5;
                            if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[index]["ProductId"].ToString()))
                            {
                                premTableMedical1 = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 3;
                            }
                            else
                            {
                                dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 1;
                                arrContributionID.Clear();
                            }

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical4 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            MedicalTableRowCounter = 14;
                            RowCounter = 15;
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 4, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                        if (index == 4)
                        {
                            premTableMedical1 = 6;
                            if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[index]["ProductId"].ToString()))
                            {
                                premTableMedical1 = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 3;
                            }
                            else
                            {
                                dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 1;
                                arrContributionID.Clear();
                            }

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical5 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            MedicalTableRowCounter = 14;
                            RowCounter = 15;
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 5, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                        if (index == 5)
                        {
                            premTableMedical1 = 7;
                            if (dicRepeatedPlans.ContainsValue(PlanTable.Rows[index]["ProductId"].ToString()))
                            {
                                premTableMedical1 = dicRepeatedPlans.Keys.FirstOrDefault(s => dicRepeatedPlans[s] == PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 3;
                            }
                            else
                            {
                                dicRepeatedPlans.Add(premTableMedical1, PlanTable.Rows[index]["ProductId"].ToString());
                                medicalColumnNum = 1;
                                arrContributionID.Clear();
                            }

                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyMEdical6 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            PremiumTableWriteMedical.Clear();
                            comFunObj.GetPlanContribution(PremiumTable, index + 1, ref PremiumTableWriteMedical);
                            MedicalTableRowCounter = 14;
                            RowCounter = 15;
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, premTableMedical1, ref medicalColumnNum, PremiumTableWriteMedical, 6, ref arrContributionID, strPlan_Contri1, strPlan_Contri2, ref MedicalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                        }
                    }
                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";
                        DentalTableRowCounter = 7;
                        RowCounter = 8;
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["ContributionName"]).Trim());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["ContributionName_2"]).Trim());
                        }
                        if (DentalCount == 0)
                        {
                            dentalTableNo = 8;
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyDental1 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 1, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");

                            if (contributionId_2 == -1)
                            {
                                rowNum = oWordDoc.Tables[dentalTableNo].Rows.Count;
                            }

                            for (int rw = 1; rw <= rowNum; rw++)
                            {
                                for (int cl = 2; cl < oWordDoc.Tables[dentalTableNo].Columns.Count; cl++)
                                {
                                    oWordDoc.Tables[dentalTableNo].Cell(rw, cl).Merge(oWordDoc.Tables[dentalTableNo].Cell(rw, cl + 1));
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            dentalTableNo = 9;
                            PremiumTableWriteDental.Clear();
                            arrContributionID_Dental.Clear();
                            dentalColumnNum = 1;
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyDental2 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 2, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");

                            if (contributionId_2 == -1)
                            {
                                rowNum = oWordDoc.Tables[dentalTableNo].Rows.Count;
                            }

                            for (int rw = 1; rw <= rowNum; rw++)
                            {
                                for (int cl = 2; cl < oWordDoc.Tables[dentalTableNo].Columns.Count; cl++)
                                {
                                    oWordDoc.Tables[dentalTableNo].Cell(rw, cl).Merge(oWordDoc.Tables[dentalTableNo].Cell(rw, cl + 1));
                                }
                            }
                        }
                        if (DentalCount == 2)
                        {
                            dentalTableNo = 10;
                            PremiumTableWriteDental.Clear();
                            arrContributionID_Dental.Clear();
                            dentalColumnNum = 1;
                            if (PremiumTable.Rows.Count > 0)
                            {
                                FrequencyDental3 = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                            }
                            comFunObj.GetPlanContribution(PremiumTable, 3, ref PremiumTableWriteDental);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, dentalTableNo, ref dentalColumnNum, PremiumTableWriteDental, 3, ref arrContributionID_Dental, strPlan_Contri1, strPlan_Contri2, ref DentalTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");

                            if (contributionId_2 == -1)
                            {
                                rowNum = oWordDoc.Tables[dentalTableNo].Rows.Count;
                            }

                            for (int rw = 1; rw <= rowNum; rw++)
                            {
                                for (int cl = 2; cl < oWordDoc.Tables[dentalTableNo].Columns.Count; cl++)
                                {
                                    oWordDoc.Tables[dentalTableNo].Cell(rw, cl).Merge(oWordDoc.Tables[dentalTableNo].Cell(rw, cl + 1));
                                }
                            }
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    //columnNum = 1;
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        rowNum = 8;
                        strPlan_Contri1 = "";
                        strPlan_Contri2 = "";

                        VisionTableRowCounter = 8;
                        RowCounter = 9;
                        strPlan_Contri1 = (Convert.ToString(PlanTable.Rows[index]["ContributionName"]).Trim());
                        if (!string.IsNullOrEmpty(Convert.ToString(PlanTable.Rows[index]["ContributionName_2"].ToString())))
                        {
                            strPlan_Contri2 = (Convert.ToString(PlanTable.Rows[index]["ContributionName_2"]).Trim());
                        }

                        if (VisionCount == 0)
                        {
                            comFunObj.GetPlanContribution(PremiumTable, 1, ref PremiumTableWriteVision);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 1, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");

                            if (contributionId_2 == -1)
                            {
                                isFirstVisionHasOnlyOneContribution = true;
                            }
                        }
                        if (VisionCount == 1)
                        {
                            PremiumTableWriteVision.Clear();
                            visionColumnNum = 3;
                            comFunObj.GetPlanContribution(PremiumTable, 2, ref PremiumTableWriteVision);
                            comFunObj.WriteContributionValues_Approach_1(oWordDoc, oWordApp, visionTableNo, ref visionColumnNum, PremiumTableWriteVision, 2, ref arrContributionID_Vision, strPlan_Contri1, strPlan_Contri2, ref VisionTableRowCounter, ref RowCounter, contributionId_1, contributionId_2, "", "");
                            if (contributionId_2 == -1)
                            {
                                isSecondVisionHasOnlyOneContribution = true;
                            }
                        }
                        if (PremiumTable.Rows.Count > 0)
                        {
                            Frequencyvision = Convert.ToString(PremiumTable.Rows[0]["contributionFrequency"].ToString().Trim());
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium
                arrContributionID.Clear();
                bool isSecondColumnHasValue = true;
                bool isThirdColumnHasValue = true;
                bool isFourthColumnHasValue = true;
                bool isFifthColumnHasValue = true;

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        isSecondColumnHasValue = true;
                        isThirdColumnHasValue = true;
                        isFourthColumnHasValue = true;
                        isFifthColumnHasValue = true;

                        if (index == 0)
                        {
                            premTableMedical1 = 2;
                        }
                        if (index == 1)
                        {
                            premTableMedical1 = 3;
                        }
                        if (index == 2)
                        {
                            premTableMedical1 = 4;
                        }
                        if (index == 3)
                        {
                            premTableMedical1 = 5;
                        }
                        if (index == 4)
                        {
                            premTableMedical1 = 6;
                        }
                        if (index == 5)
                        {
                            premTableMedical1 = 7;
                        }

                        for (int rn = 14; rn < oWordDoc.Tables[premTableMedical1].Rows.Count; rn++)
                        {
                            if (rn == 14)
                            {
                                for (int cn = oWordDoc.Tables[premTableMedical1].Columns.Count; cn > 1; cn--)
                                {
                                    if (cn == 5 && (string.IsNullOrEmpty(oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text.ToString()) || oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text == "\r\a"))
                                    {
                                        isFifthColumnHasValue = false;
                                    }
                                    else if (cn == 4 && (string.IsNullOrEmpty(oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text.ToString()) || oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text == "\r\a"))
                                    {
                                        isFourthColumnHasValue = false;
                                    }
                                    else if (cn == 3 && (string.IsNullOrEmpty(oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text.ToString()) || oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text == "\r\a"))
                                    {
                                        isThirdColumnHasValue = false;
                                    }
                                    else if (cn == 2 && (string.IsNullOrEmpty(oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text.ToString()) || oWordDoc.Tables[premTableMedical1].Cell(rn, cn).Range.Text == "\r\a"))
                                    {
                                        isSecondColumnHasValue = false;
                                    }
                                }
                                break;
                            }
                        }

                        // Merge the columns

                        if (isSecondColumnHasValue == false && isThirdColumnHasValue == false && isThirdColumnHasValue == false && isSecondColumnHasValue == false)
                        { }
                        else
                        {
                            for (int rn = 14; rn <= oWordDoc.Tables[premTableMedical1].Rows.Count; rn++)
                            {
                                for (int cn = oWordDoc.Tables[premTableMedical1].Columns.Count; cn >= 1; cn--)
                                {
                                    // For merging in second plan
                                    if (isFifthColumnHasValue == false && isFourthColumnHasValue == true)
                                    {
                                        oWordDoc.Tables[premTableMedical1].Cell(rn, 4).Merge(oWordDoc.Tables[premTableMedical1].Cell(rn, 5));
                                    }

                                    // For merging in first plan
                                    if (isThirdColumnHasValue == false && isSecondColumnHasValue == true)
                                    {
                                        oWordDoc.Tables[premTableMedical1].Cell(rn, 2).Merge(oWordDoc.Tables[premTableMedical1].Cell(rn, 3));
                                    }
                                    break;
                                }
                            }
                        }

                        // For deleting the last empty rows
                        for (int rowNum1 = 2; rowNum1 <= oWordDoc.Tables[premTableMedical1].Rows.Count; rowNum1++)
                        {
                            if (string.IsNullOrEmpty(oWordDoc.Tables[premTableMedical1].Cell(rowNum1, 1).Range.Text.ToString()) || oWordDoc.Tables[premTableMedical1].Cell(rowNum1, 1).Range.Text == "\r\a")
                            {
                                oWordDoc.Tables[premTableMedical1].Rows[rowNum1].Delete();
                                rowNum1 = rowNum1 - 1;
                            }
                        }
                    }
                }
                #endregion

                #region Dental Monthly Premium
                if (PremiumTableWriteDental != null && PremiumTableWriteDental.Rows.Count > 0)
                {
                    oWordDoc.Tables[dentalTableNo].Rows.Last.Delete();
                    oWordDoc.Tables[dentalTableNo].Range.Font.Color = comFunObj.font_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                    oWordDoc.Tables[dentalTableNo].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                }

                #endregion

                #region Vision Monthly Premium
                arrContributionID_Vision.Clear();
                oWordDoc.Tables[visionTableNo].Rows.Last.Delete();

                if (PremiumTableWriteVision != null && PremiumTableWriteVision.Rows.Count > 0)
                {
                    comFunObj.MergeColumnsInContributionTable(oWordDoc, rowNum, visionTableNo, isFirstVisionHasOnlyOneContribution, isSecondVisionHasOnlyOneContribution);
                }

                #endregion

                #region Merge Fields
                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Frequency_Contribution_Med1"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical1.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med2"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical2.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med3"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical3.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical3);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med4"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical4.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical4);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Med5"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical5.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical5);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }

                        }
                        if (fieldName.Contains("Frequency_Contribution_Med6"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyMEdical6.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyMEdical6);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Dental1"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyDental1.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyDental1);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Dental2"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyDental2.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyDental2);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Dental3"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(FrequencyDental3.Trim()))
                            {
                                oWordApp.Selection.TypeText(FrequencyDental3);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        if (fieldName.Contains("Frequency_Contribution_Vision"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(Frequencyvision.Trim()))
                            {
                                oWordApp.Selection.TypeText(Frequencyvision);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /* Plz do not delete this function, when will ask for rate values only then we need to delete comments for this function
        public void WriteMonthlyPremiumSectionToTemplate3(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 1;
                int Dentalindex = 2;
                int DentalCount = 0;
                int VisionCount = 0;

                //Effective dates of Medical plans
                string Medicaleffective1 = "";
                string Medicaleffective2 = "";
                string Medicaleffective3 = "";

                //Effective dates of Dental plans
                string Dentaleffective1 = "";
                string Dentaleffective2 = "";
                string Dentaleffective3 = "";

                //Effective dates of Vision Plans
                string Visioneffective1 = "";
                string Visioneffective2 = "";




                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");


                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");


                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {

                    #region  BuildTable
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(Int16));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));


                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {

                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }
                                }
                                premium_row_counter++;
                            }
                        }
                    }

                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            Medicaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }

                        }
                        if (index == 1)
                        {
                            Medicaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (index == 2)
                        {

                            Medicaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }


                    #endregion

                    # region FillTable Dental

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            Dentaleffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            Dentaleffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        if (DentalCount == 2)
                        {
                            Dentaleffective3 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();//effective date
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            Visioneffective1 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                    dr["Plan2_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            Visioneffective2 = Convert.ToDateTime(PlanTable.Rows[index]["Effective"].ToString()).ToShortDateString();
                            for (int i = 0; i < PremiumTable.DefaultView.ToTable(true, "rateFieldValueID").Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][3].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][3].ToString();
                                        dr["Plan1_Rate"] = "";
                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium

                int MediCalTableRowCounter = 0;
                for (int d = 1; d < PremiumTableWriteMedical.Columns.Count; d++)
                {
                    if (d == 1)
                    {
                        MediCalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[6].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[6].Rows.Add();
                                }
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[6].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[9].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective2;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[9].Rows.Add();
                                }
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[9].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        MediCalTableRowCounter = 2;
                        oWordDoc.Tables[12].Cell(1, 2).Range.Text = "Effective: " + Medicaleffective3;
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteMedical.Rows.Count; i++)
                        {
                            if (PremiumTableWriteMedical.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[12].Rows.Add();
                                }

                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[i][0].ToString();
                                oWordDoc.Tables[12].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[i][d].ToString();
                                MediCalTableRowCounter++;
                                kk++;

                            }
                        }
                    }
                }
                #endregion

                #region Dental Monthly Premium

                int DentalTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteDental.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[14].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[14].Rows.Add();
                                }
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[14].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[16].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[16].Rows.Add();
                                }
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[16].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 3)
                    {
                        DentalTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[18].Cell(1, 2).Range.Text = "Effective: " + Dentaleffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteDental.Rows.Count; i++)
                        {
                            if (PremiumTableWriteDental.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[18].Rows.Add();
                                }
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[i][0].ToString();
                                oWordDoc.Tables[18].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[i][d].ToString();
                                DentalTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion

                #region Vision Monthly Premium

                int VisionTableRowCounter = 0;

                for (int d = 0; d < PremiumTableWriteVision.Columns.Count; d++)
                {

                    if (d == 1)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[20].Cell(1, 2).Range.Text = "Effective: " + Visioneffective1;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[20].Rows.Add();
                                }
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[20].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                    if (d == 2)
                    {
                        VisionTableRowCounter = 2; //Start row 
                        oWordDoc.Tables[22].Cell(1, 2).Range.Text = "Effective: " + Visioneffective2;//Header Part
                        int kk = 0;
                        for (int i = 0; i < PremiumTableWriteVision.Rows.Count; i++)
                        {
                            if (PremiumTableWriteVision.Rows[i][d].ToString() != "")
                            {
                                if (kk > 0)
                                {
                                    oWordDoc.Tables[22].Rows.Add();
                                }
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[i][0].ToString();
                                oWordDoc.Tables[22].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[i][d].ToString();
                                VisionTableRowCounter++;
                                kk++;
                            }
                        }
                    }
                }
                #endregion
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }
        */

        /// <summary>
        /// Write Voluntary Life Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteVoluntaryLifeMonthlyPremiumSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, string selectedColor = "")
        {
            try
            {
                int count = 1;
                DataTable PremiumTable = new DataTable();
                int premium_row_counter = 0;
                PremiumTable.Columns.Add("Plan", typeof(string));
                PremiumTable.Columns.Add("rateTierID", typeof(string));
                PremiumTable.Columns.Add("rateTier_description", typeof(string));
                PremiumTable.Columns.Add("monthlycost", typeof(string));
                PremiumTable.Columns.Add("rateid", typeof(string));
                PremiumTable.Columns.Add("rateFieldValueID", typeof(string));
                PremiumTable.Columns.Add("ageBandIndex", typeof(int));

                int tableNoVolLifeRates = 12;
                string dependent_child_rate_1 = " ";
                bool isVolRateDisplayed = false;

                for (int rowindex = 0; rowindex < PlanTable.Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                        {
                            if (isVolRateDisplayed == false)
                            {
                                PremiumTable.Clear();
                                premium_row_counter = 0;

                                int Start = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedStartOn"].ToString());
                                int End = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedEndOn"].ToString());
                                int Interval = int.Parse(RateDS.Tables["RateTable"].Rows[rowindex]["ageBandedInterval"].ToString()) - 1;

                                for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                                {
                                    if (PlanTable.Rows[rowindex]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                                    {
                                        if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[rowindex]["RateId"].ToString()))
                                        {
                                            PremiumTable.Rows.Add();
                                            PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                            PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                            PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                            PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                            PremiumTable.Rows[premium_row_counter][4] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                            PremiumTable.Rows[premium_row_counter][5] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                            PremiumTable.Rows[premium_row_counter][6] = int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_ageBandIndex"].ToString());
                                            premium_row_counter++;
                                        }
                                    }
                                }

                                #region For EE NonSmoker
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(3, 1).Range.Text = "Under " + Start.ToString();
                                int StartValue = Start;
                                int RowCount = 4;
                                while (StartValue < End - 1)
                                {
                                    oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                                    if (StartValue == Start)
                                    {
                                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = Start.ToString() + " - " + (Start + Interval).ToString();
                                        StartValue = Start + Interval;
                                    }
                                    else
                                    {
                                        oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = (StartValue + 1).ToString() + " - " + (StartValue + 1 + Interval).ToString();
                                        StartValue = StartValue + Interval + 1;
                                    }
                                    RowCount++;
                                }
                                oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, 1).Range.Text = "Over " + End.ToString();
                                oWordDoc.Tables[tableNoVolLifeRates].Rows.Add();
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount + 1, 1).Range.Text = "Composite";

                                int ColumnCount = 0;
                                DataTable dt = new DataTable();
                                bool isUniSmokerValueExists = false;
                                bool isSmokerValueExists = false;
                                bool isNonSmokerColumnInserted = false;

                                PremiumTable.DefaultView.Sort = "[ageBandIndex], [rateTierID] asc";
                                dt = PremiumTable.DefaultView.ToTable(true);
                                PremiumTable = dt;
                                RowCount = 3;

                                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                {
                                    if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                    {
                                        isUniSmokerValueExists = true;
                                        break;
                                    }
                                }

                                for (int i = 0; i < PremiumTable.Rows.Count; i++)
                                {
                                    if (isUniSmokerValueExists == true)
                                    {
                                        if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE UniSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                        {
                                            isUniSmokerValueExists = true;
                                            ColumnCount = 2;//j + 2;// int.Parse(RateDescList[j].IndexOf(PremiumTable.Rows[i]["rateTier_description"].ToString()).ToString()) + 1;
                                            oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 2).Range.Text = "Employee Uni-Smoker";
                                            oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                            RowCount++;
                                        }
                                    }
                                    else if (isUniSmokerValueExists == false)
                                    {
                                        if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE Smoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                        {
                                            ColumnCount = 2;
                                            isSmokerValueExists = true;
                                            oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 2).Range.Text = "Employee \nSmoker";
                                            oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                            RowCount++;

                                            if (isNonSmokerColumnInserted == false)
                                            {
                                                ColumnCount = 3;
                                                oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                                oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                                oWordDoc.Tables[tableNoVolLifeRates].Cell(1, ColumnCount).Range.Text = "Employee \nNon-Smoker";
                                                isNonSmokerColumnInserted = true;
                                            }
                                        }

                                        else if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "EE NonSmoker") //(PremiumTable.Rows[i]["rateTier_description"].ToString() == RateDescList[j].ToString())
                                        {
                                            // For inserting extra column
                                            if (isSmokerValueExists == true)
                                            {
                                                RowCount = RowCount - 1;
                                                ColumnCount = 3;
                                                //if (isNonSmokerColumnInserted == false)
                                                //{
                                                //    oWordDoc.Tables[tableNoVolLifeRates].Columns.Add();
                                                //    oWordDoc.Tables[tableNoVolLifeRates].Columns[ColumnCount].Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                                                //    isNonSmokerColumnInserted = true;
                                                //}
                                            }
                                            else
                                            {
                                                ColumnCount = 2;
                                            }

                                            //oWordDoc.Tables[tableNoVolLifeRates].Cell(1, ColumnCount).Range.Text = "Employee \nNon-Smoker";
                                            oWordDoc.Tables[tableNoVolLifeRates].Cell(RowCount, ColumnCount).Range.Text = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                            RowCount++;
                                        }
                                    }

                                    if (PremiumTable.Rows[i]["rateTier_description"].ToString() == "Dependent Child Life")
                                    {
                                        if (count == 1)
                                        {
                                            dependent_child_rate_1 = "$" + PremiumTable.Rows[i]["monthlycost"].ToString();
                                        }
                                    }
                                }
                                #endregion

                                oWordDoc.Tables[tableNoVolLifeRates].Range.Font.Color = comFunObj.font_color(selectedColor);
                                oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                                oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                                oWordDoc.Tables[tableNoVolLifeRates].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                                oWordDoc.Tables[tableNoVolLifeRates].Rows[2].Range.Font.Color = WdColor.wdColorWhite;
                                oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
                                //oWordDoc.Tables[tableNoVolLifeRates].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                                if (isSmokerValueExists == true)
                                {
                                    oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 2).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 3));
                                }
                                oWordDoc.Tables[tableNoVolLifeRates].Cell(1, 1).Merge(oWordDoc.Tables[tableNoVolLifeRates].Cell(2, 1));
                                oWordDoc.Tables[tableNoVolLifeRates].PreferredWidth = oWordApp.InchesToPoints(5.13f);
                                count++;
                                isVolRateDisplayed = true;
                            }
                        }
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dependent Child Rate 1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(dependent_child_rate_1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary ADnD Rates Selected"))
                        {
                            if (count == 3)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteVoluntaryLifeToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                string value = "";
                string EmployeeIssueAmt = "";
                string age = "";

                #region HashtableVoluntaryLifeADDBenifit
                HashtableVoluntaryLifeADDBenifit.Add(1, "186"); //Employee [Benefit Amount]
                HashtableVoluntaryLifeADDBenifit.Add(2, "188"); //Employee [Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(3, "187"); //Employee [Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(4, "516"); //Spouse[Benefit Amount]6
                HashtableVoluntaryLifeADDBenifit.Add(5, "519"); //Spouse[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(6, "518"); //Spouse[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(7, "106"); //Child(ren)[Benefit Amount] 
                HashtableVoluntaryLifeADDBenifit.Add(8, "104"); //Child(ren)[Overall Maximum]
                HashtableVoluntaryLifeADDBenifit.Add(9, "103"); //Child(ren)[Guarantee Issue Amount]

                HashtableVoluntaryLifeADDBenifit.Add(10, "2");   //age
                HashtableVoluntaryLifeADDBenifit.Add(11, "3");   //age
                HashtableVoluntaryLifeADDBenifit.Add(12, "4");   //age
                HashtableVoluntaryLifeADDBenifit.Add(13, "5");   //age

                #endregion

                string BenefitAmtEmployee1 = "";
                string BenefitAmtSpouse1 = "";
                string BenefitAmtChild1 = "";
                //string BenefitAmtEmployee2 = "";
                //string BenefitAmtSpouse2 = "";
                //string BenefitAmtChild2 = "";

                string OverallMaximumEmployee1 = "";
                string OverallMaximumSpouse1 = "";
                string OverallMaximumChild1 = "";
                //string OverallMaximumEmployee2 = "";
                //string OverallMaximumSpouse2 = "";
                //string OverallMaximumChild2 = "";

                string GuarenteeIssueAmtEmp1 = "";
                string GuarenteeIssueAmtSpouse1 = "";
                //string GuarenteeIssueAmtChild1 = "";
                //string GuarenteeIssueAmtEmp2 = "";
                //string GuarenteeIssueAmtSpouse2 = "";
                //string GuarenteeIssueAmtChild2 = "";

                string VoluntaryLifeSummaryName = string.Empty;
                bool isVolLife_Selected = false;
                bool isVolADnD_Selected = false;
                string planType = string.Empty;
                //int tableNoVolLife = 24;

                //GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoVolLife, selectedColor, cv.VoluntaryLifeADDLOC);
                //oWordDoc.Tables[tableNoVolLife].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region VoluntaryLifeADDBenifitTable

                            VoluntaryLifeSummaryName = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);

                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                            {
                                isVolLife_Selected = true;
                                planType = cv.VoluntaryLifeADDLOC.ToLower().Trim().ToLower();
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.Voluntary_ADNDPlanType_CommonCriteria.Trim().ToLower())
                            {
                                isVolADnD_Selected = true;
                                planType = cv.Voluntary_ADNDPlanType_CommonCriteria.ToLower().Trim().ToLower();
                            }

                            foreach (int key in HashtableVoluntaryLifeADDBenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == planType && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VoluntaryLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVoluntaryLifeADDBenifit[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();

                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.VoluntaryLifeADDLOC.Trim().ToLower())
                                        {
                                            switch (key)
                                            {
                                                case 1: BenefitAmtEmployee1 = value; break;
                                                case 2: OverallMaximumEmployee1 = value; break;
                                                case 3: GuarenteeIssueAmtEmp1 = value; break;
                                                case 4: BenefitAmtSpouse1 = value; break;
                                                case 5: OverallMaximumSpouse1 = value; break;
                                                case 6: GuarenteeIssueAmtSpouse1 = value; break;
                                                case 7: BenefitAmtChild1 = value; break;
                                                case 8: OverallMaximumChild1 = value; break;
                                            }

                                            int ch = int.Parse(dr["attributeID"].ToString());
                                            switch (ch)
                                            {
                                                case 10: if (value.Trim() != string.Empty) { age = "65"; } break; //65-69
                                                case 11: if (value.Trim() != string.Empty) { age = "70"; } break; //70-74
                                                case 12: if (value.Trim() != string.Empty) { age = "75"; } break; //75-79
                                                case 13: if (value.Trim() != string.Empty) { age = "80"; } break; //80-84
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            count++;
                        }
                    }
                }

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("LifeADnD_Or_GroupTermLife_Or_ADnD_Selected"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        if (fieldName.Contains("delete volantary pagebreak bookmark"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("VoluntaryPlan1_Selected"))
                        {
                            if (count > 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("Delete Voluntary Life"))
                        {

                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            continue;

                        }
                        if (fieldName.Contains("Delete_Life_And_Vol_Life"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (isVolLife_Selected == true && isVolADnD_Selected == true)
                        {
                            if (fieldName.Contains("Voluntary Life and Accidental Death & Dismemberment (AD&D) Insurance Coverage"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary Life and Accidental Death & Dismemberment (AD&D) Insurance Coverage");
                                continue;
                            }
                        }
                        if (isVolLife_Selected == true && isVolADnD_Selected == false)
                        {
                            if (fieldName.Contains("Voluntary Life Insurance Coverage"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary Life Insurance Coverage");
                                continue;
                            }
                        }
                        if (isVolLife_Selected == false && isVolADnD_Selected == true)
                        {
                            if (fieldName.Contains("Voluntary Accidental Death & Dismemberment (AD&D) Insurance Coverage"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Voluntary Accidental Death & Dismemberment (AD&D) Insurance Coverage");
                                continue;
                            }
                        }
                        if (fieldName.Contains("Important Things to Consider"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Important Things to Consider");
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Benefit Summary Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(VoluntaryLifeSummaryName);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Benefit Amount / Employee"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(BenefitAmtEmployee1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Overall Maximum Amount / Employee"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(OverallMaximumEmployee1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Guarantee Issue Amount / Employee"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(GuarenteeIssueAmtEmp1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Benefit Amount / Spouse"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(BenefitAmtSpouse1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Overall Maximum Amount / Spouse"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(OverallMaximumSpouse1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Guarantee Issue Amount / Spouse"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(GuarenteeIssueAmtSpouse1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Benefit Amount / Child(ren)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(BenefitAmtChild1);
                            continue;
                        }
                        if (fieldName.Contains("Voluntary Life Overall Maximum Amount / Child(ren)"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(OverallMaximumSpouse1);
                            continue;
                        }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        /// <param name="selectedColor">string selectedColor is used to pass the selected color from dropdownlist</param>
        /// <param name="GroupTermLifeBenefitColumnIdList">ArrayList GroupTermLifeBenefitColumnIdList contains InNetwork Benefit ColumnId for Group Term Life Plan</param>
        /// <param name="ADDBenefitColumnIdList">ArrayList ADDBenefitColumnIdList contains InNetwork Benefit ColumnId AD&D Plan</param>
        public void WriteLifeADDToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList, string selectedColor = "", ArrayList GroupTermLifeBenefitColumnIdList = null, ArrayList ADDBenefitColumnIdList = null)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);
                int iTotalFields = 0;

                int count = 0;

                Hashtable HashtableGroupLifeADDBenifit = new Hashtable();

                string LifeAndADnD_Amount1 = "";
                string LifeAndADnD_Amount2 = "";

                string GroupTermLife_Amount1 = "";
                string GroupTermLife_Amount2 = "";

                string ADnD_Amount1 = "";
                string ADnD_Amount2 = "";

                string LifeAndADnD_OverallMaximum_Employee1 = "";
                string LifeAndADnD_OverallMaximum_Employee2 = "";
                string GroupTermLife_OverallMaximum_Employee1 = "";
                string GroupTermLife_OverallMaximum_Employee2 = "";
                string ADD_OverallMaximum_Employee1 = "";
                string ADD_OverallMaximum_Employee2 = "";

                #region HashtableGroupLifeADDBenifit

                HashtableGroupLifeADDBenifit.Add(1, "186"); //Employee[Overall Maximum]
                HashtableGroupLifeADDBenifit.Add(2, "188"); //Employee[Overall Maximum]

                #endregion

                string Life_and_ADND_Carrier1 = string.Empty;
                string Life_and_ADND_Carrier2 = string.Empty;
                string GroupTermLife_Carrier1 = string.Empty;
                string GroupTermLife_Carrier2 = string.Empty;
                string ADnD_Carrier1 = string.Empty;
                string ADnD_Carrier2 = string.Empty;

                string LifeAndADnD_SummaryName1 = string.Empty;
                string LifeAndADnD_SummaryName2 = string.Empty;
                string GroupTermLife_SummaryName1 = string.Empty;
                string GroupTermLife_SummaryName2 = string.Empty;
                string ADnD_SummaryName1 = string.Empty;
                string ADnD_SummaryName2 = string.Empty;

                int LifeCount = 0;
                int GroupTermCount = 0;
                int AddCount = 0;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {

                            #region GroupLifeADDBenifitTable
                            if (count == 0)
                            {
                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                LifeAndADnD_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                LifeAndADnD_OverallMaximum_Employee1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                GroupTermLife_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                GroupTermLife_OverallMaximum_Employee1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                ADnD_Amount1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                ADD_OverallMaximum_Employee1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                    }
                                }

                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    LifeAndADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    GroupTermLife_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier1 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    ADnD_SummaryName1 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                            }
                            else if (count == 1)
                            {

                                foreach (int key in HashtableGroupLifeADDBenifit.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                LifeAndADnD_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                LifeAndADnD_OverallMaximum_Employee2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                GroupTermLife_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                GroupTermLife_OverallMaximum_Employee2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                        if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupLifeADDBenifit[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                ADnD_Amount2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                            if (key == 2)
                                            {
                                                ADD_OverallMaximum_Employee2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                            }
                                        }
                                    }
                                }

                                if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.LifeADDLOC.ToLower())
                                {
                                    Life_and_ADND_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    LifeAndADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                                {
                                    GroupTermLife_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    GroupTermLife_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                                else if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().Trim().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                                {
                                    ADnD_Carrier2 = Convert.ToString(PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''").Trim());
                                    ADnD_SummaryName2 = Convert.ToString(PlanTable.Rows[rowindex]["SummaryName"]);
                                }
                            }

                            #endregion


                            count++;
                        }
                    }
                    #region merge fields


                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                    {
                        LifeCount++;
                    }
                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                    {
                        GroupTermCount++;
                    }
                    if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                    {
                        AddCount++;
                    }

                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Delete Life"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Delete_Life_And_Vol_Life"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.LifeADDLOC.ToLower())
                            {


                                if (fieldName.Contains("Life and Accidental Death & Dismemberment (AD&D) Insurance Coverage"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("Life and Accidental Death & Dismemberment (AD&D) Insurance Coverage");
                                    continue;
                                }
                                if (LifeCount > 1)
                                {
                                    if (fieldName.Contains("Life_Add_2nd_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Life and AD&D Carrier Name2"))
                                    {
                                        myMergeField.Select();
                                        if (Life_and_ADND_Carrier2 == Life_and_ADND_Carrier1)
                                        {
                                            //oWordApp.Selection.TypeText(" ");
                                        }
                                        else
                                        {
                                            Life_and_ADND_Carrier2 = Life_and_ADND_Carrier1 + " and " + Life_and_ADND_Carrier2;
                                            oWordApp.Selection.TypeText(Life_and_ADND_Carrier2);
                                        }
                                        continue;
                                    }
                                }
                                if (fieldName.Contains("Life and AD&D Carrier Name1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(Life_and_ADND_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("Life and AD&D Benefit Summaries Description1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Summaries Description2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_SummaryName2);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Amount Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("Life and AD&D Benefit Amount Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_Amount2);
                                    continue;
                                }

                                if (fieldName.Contains("Overall Maximum – Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_OverallMaximum_Employee1);
                                    continue;
                                }
                                if (fieldName.Contains("Overall Maximum – Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(LifeAndADnD_OverallMaximum_Employee2);
                                    continue;
                                }

                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.GroupTermLifePlanType_CommonCriteria.ToLower())
                            {
                                if (fieldName.Contains("Group Term Life Insurance Coverage"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("Group Term Life Insurance Coverage");
                                    continue;
                                }
                                if (GroupTermCount > 1)
                                {
                                    if (fieldName.Contains("GroupTermLife_2nd_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Group Term Life Carrier Name2"))
                                    {
                                        myMergeField.Select();
                                        if (GroupTermLife_Carrier2 == GroupTermLife_Carrier1)
                                        {
                                            //oWordApp.Selection.TypeText(" ");
                                        }
                                        else
                                        {
                                            GroupTermLife_Carrier2 = GroupTermLife_Carrier1 + " and " + GroupTermLife_Carrier2;
                                            oWordApp.Selection.TypeText(GroupTermLife_Carrier2);
                                        }
                                        continue;
                                    }
                                }
                                if (fieldName.Contains("Group Term Life Carrier Name1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("Group Term Life Benefit Summaries Description1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Summaries Description2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_SummaryName2);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Amount Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("Group Term Life Benefit Amount Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_Amount2);
                                    continue;
                                }
                                if (fieldName.Contains("Group_Term_Overall_Maximum – Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_OverallMaximum_Employee1);
                                    continue;
                                }
                                if (fieldName.Contains("Group_Term_Overall_Maximum – Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(GroupTermLife_OverallMaximum_Employee2);
                                    continue;
                                }
                            }
                            if (PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString().ToLower() == cv.ADNDPlanType_CommonCriteria.ToLower())
                            {

                                if (fieldName.Contains("Group Accidental Death & Dismemberment (AD&D) Insurance Coverage"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    oWordApp.Selection.TypeText("Group Accidental Death & Dismemberment (AD&D) Insurance Coverage");
                                    continue;
                                }

                                if (fieldName.Contains("Second_ADD_Carrier Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" and " + ADnD_Carrier2);
                                    continue;
                                }
                                if (fieldName.Contains("ADD Carrier Name"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Carrier1);
                                    continue;
                                }

                                if (fieldName.Contains("ADDSummary1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_SummaryName1);
                                    continue;
                                }
                                if (fieldName.Contains("ADDSummary2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_SummaryName2);
                                    continue;
                                }

                                if (fieldName.Contains("ADD Benefit Amount Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Amount1);
                                    continue;
                                }
                                if (fieldName.Contains("ADD Benefit Amount Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADnD_Amount2);
                                    continue;
                                }
                                if (fieldName.Contains("ADD_Overall_Maximum_Amount / Employee1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADD_OverallMaximum_Employee1);
                                    continue;
                                }
                                if (fieldName.Contains("ADD_Overall_Maximum_Amount / Employee2"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(ADD_OverallMaximum_Employee2);
                                    continue;
                                }
                                if (fieldName.Contains("ADD1"))
                                {
                                    myMergeField.Select();
                                    oWordApp.Selection.TypeText(" ");
                                }
                                if (AddCount > 1)
                                {
                                    if (fieldName.Contains("GroupADD_2nd_Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("ADD2"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }
                                }
                            }

                        }
                    }
                    #endregion

                }


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">selectedColor contain selected color (Optional Paramter)</param>
        public void WriteVisionSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList, DataTable CarrierSpecific, ArrayList VisionBenefitColumnIdOutNetworkList, string selectedColor = "")
        {
            try
            {
                DataRow[] foundRows = null;
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();

                #region HastableVisionBenefitInNetwork
                //HashtableVisionBenefitInNetwork.Add(11, "195");     //General Plan Information – Copay – Examination Deductible
                // HashtableVisionBenefitInNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(3, "194");     //General Plan Information – Benefit Frequency – Examination 3
                // HashtableVisionBenefitInNetwork.Add(43, "309");     //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitInNetwork.Add(8, "122");     //General Plan Information – Benefit Frequency – Contacts     6
                HashtableVisionBenefitInNetwork.Add(2, "207");      //General Plan Information – Benefit Frequency – Frames      
                //HashtableVisionBenefitInNetwork.Add(5, "195");      //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(5, "507");      //Covered Services – Lenses – Single Vision Lens            5
                HashtableVisionBenefitInNetwork.Add(6, "73");       //Covered Services – Lenses – Bifocal Lens                    5
                HashtableVisionBenefitInNetwork.Add(7, "553");      //Covered Services – Lenses – Trifocal Lens                  5
                HashtableVisionBenefitInNetwork.Add(4, "208");      //Covered Services – Frames                                    4
                HashtableVisionBenefitInNetwork.Add(9, "356");     //Covered Services – Contact Lenses – Medically Necessary         7
                #endregion HastableVisionBenefitInNetwork

                Hashtable HashtableVisionBenefitOutNetwork = new Hashtable();
                #region HastableVisionBenefitOutNetwork
                //HashtableVisionBenefitOutNetwork.Add(11, "195");     //General Plan Information – Copay – Examination Deductible
                //HashtableVisionBenefitOutNetwork.Add(3, "344");      //General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitOutNetwork.Add(3, "194");     //General Plan Information – Benefit Frequency – Examination    2
                //HashtableVisionBenefitOutNetwork.Add(43, "309");     //General Plan Information – Benefit Frequency –Lenses
                HashtableVisionBenefitOutNetwork.Add(8, "122");     //General Plan Information – Benefit Frequency – Contacts         5
                //HashtableVisionBenefitOutNetwork.Add(4, "207");      //General Plan Information – Benefit Frequency – Frames         
                //HashtableVisionBenefitOutNetwork.Add(5, "195");      //General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitOutNetwork.Add(5, "507");      //Covered Services – Lenses – Single Vision Lens                4
                HashtableVisionBenefitOutNetwork.Add(6, "73");       //Covered Services – Lenses – Bifocal Lens                      4
                HashtableVisionBenefitOutNetwork.Add(7, "553");      //Covered Services – Lenses – Trifocal Lens                     4
                HashtableVisionBenefitOutNetwork.Add(4, "208");      //Covered Services – Frames                                      3
                HashtableVisionBenefitOutNetwork.Add(9, "356");     //Covered Services – Contact Lenses – Medically Necessary       6
                #endregion HastableVisionBenefitOutNetwork

                ArrayList arrVisionBenefitOutNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitOutNetwork.Keys)
                {
                    arrVisionBenefitOutNetwork.Add(key);
                }

                arrVisionBenefitOutNetwork.Sort();
                arrVisionBenefitOutNetwork.Reverse();

                ArrayList arrVisionBenefitInNetwork = new ArrayList();
                foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                {
                    arrVisionBenefitInNetwork.Add(key);
                }

                arrVisionBenefitInNetwork.Sort();
                arrVisionBenefitInNetwork.Reverse();

                ////ArrayList arrVisionBenefit = new ArrayList();
                ////foreach (int key in HashtableVisionBenefit.Keys)
                ////{
                ////    arrVisionBenefit.Add(key);
                ////}

                //arrVisionBenefit.Sort();
                //arrVisionBenefit.Reverse();

                string CoveredService_Frames_Innetwork = string.Empty;
                string BenefitFrequency_Contacts_Innetwork = string.Empty;

                string CoveredService_Lenses_Innetwork_Single = string.Empty;
                string CoveredService_Lenses_Innetwork_Bifocal = string.Empty;
                string CoveredService_Lenses_Innetwork_Trifocal = string.Empty;

                string CoveredService_Contact_Lenses_Innetwork = string.Empty;
                string BenefitFrequency_Examination_Innetwork = string.Empty;
                string BenefitFrequency_Frames_Innetwork = string.Empty;

                string CoveredService_Frames_OutNetwork = string.Empty;
                string BenefitFrequency_Contacts_OutNetwork = string.Empty;
                string CoveredService_Lenses_OutNetwork_Single = string.Empty;
                string CoveredService_Lenses_OutNetwork_Bifocal = string.Empty;
                string CoveredService_Lenses_OutNetwork_Trifocal = string.Empty;
                string CoveredService_Contact_Lenses_OutNetwork = string.Empty;
                string BenefitFrequency_Examination_OutNetwork = string.Empty;

                int iTotalFields = 0;
                int count = 1;
                int tableNoVision = 11;
                int colcount_innetwork = 2;
                int colcount_outnetwork = 3;
                int colCount = 0;
                string value = "";
                string ADD_Carrier = string.Empty;
                List<string> lstcarrier = new List<string>();

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, tableNoVision, selectedColor, cv.VisionLOC);
                oWordDoc.Tables[tableNoVision].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            # region VisionBenefitTable

                            if (count == 1)
                            {
                                oWordDoc.Tables[tableNoVision].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                comFunObj.GetCarrierList(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim(), ref lstcarrier);
                            }
                            if (count == 2)
                            {
                                colcount_innetwork = colcount_innetwork + 2;
                                colcount_outnetwork = colcount_outnetwork + 2;
                                oWordDoc.Tables[tableNoVision].Cell(1, 4).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();
                                oWordDoc.Tables[tableNoVision].Cell(2, 4).Range.Text = oWordDoc.Tables[tableNoVision].Cell(2, 4).Range.Text.Replace("Plan2_1", " "); ;
                                oWordDoc.Tables[tableNoVision].Cell(2, 5).Range.Text = oWordDoc.Tables[tableNoVision].Cell(2, 5).Range.Text.Replace("Plan2_2", " ");
                                comFunObj.GetCarrierList(Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim(), ref lstcarrier);
                            }

                            #region Vision InNetwork
                            foreach (int key in arrVisionBenefitInNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 2: BenefitFrequency_Frames_Innetwork = value; break;
                                            case 3: BenefitFrequency_Examination_Innetwork = value; break;
                                            case 4: CoveredService_Frames_Innetwork = value; break;
                                            case 5: CoveredService_Lenses_Innetwork_Single = "Single: " + value + "\n"; break;
                                            case 6: CoveredService_Lenses_Innetwork_Bifocal = "Bifocal: " + value + "\n"; break;
                                            case 7: CoveredService_Lenses_Innetwork_Trifocal = "Trifocal: " + value + "\n"; break;
                                            case 8: BenefitFrequency_Contacts_Innetwork = value; break;
                                            case 9: CoveredService_Contact_Lenses_Innetwork = value; break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[tableNoVision].Cell(3, colcount_innetwork).Range.Text = BenefitFrequency_Examination_Innetwork;
                            oWordDoc.Tables[tableNoVision].Cell(4, colcount_innetwork).Range.Text = CoveredService_Frames_Innetwork;
                            oWordDoc.Tables[tableNoVision].Cell(5, colcount_innetwork).Range.Text = CoveredService_Lenses_Innetwork_Single + CoveredService_Lenses_Innetwork_Bifocal + CoveredService_Lenses_Innetwork_Trifocal;
                            oWordDoc.Tables[tableNoVision].Cell(6, colcount_innetwork).Range.Text = "In Lieu of Eyeglass Lenses – " + BenefitFrequency_Contacts_Innetwork;
                            oWordDoc.Tables[tableNoVision].Cell(7, colcount_innetwork).Range.Text = CoveredService_Contact_Lenses_Innetwork;
                            #endregion Vision InNetwork

                            #region Vision OutNetwork
                            foreach (int key in arrVisionBenefitOutNetwork)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitOutNetwork[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 3: BenefitFrequency_Examination_OutNetwork = value; break;
                                            case 4: CoveredService_Frames_OutNetwork = value; break;
                                            case 5: CoveredService_Lenses_OutNetwork_Single = "Single: " + value + "\n"; break;
                                            case 6: CoveredService_Lenses_OutNetwork_Bifocal = "Bifocal: " + value + "\n"; break;
                                            case 7: CoveredService_Lenses_OutNetwork_Trifocal = "Trifocal: " + value + "\n"; break;
                                            case 8: BenefitFrequency_Contacts_OutNetwork = value; break;
                                            case 9: CoveredService_Contact_Lenses_OutNetwork = value; break;
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[tableNoVision].Cell(3, colcount_outnetwork).Range.Text = BenefitFrequency_Examination_OutNetwork;
                            oWordDoc.Tables[tableNoVision].Cell(4, colcount_outnetwork).Range.Text = CoveredService_Frames_OutNetwork;
                            oWordDoc.Tables[tableNoVision].Cell(5, colcount_outnetwork).Range.Text = CoveredService_Lenses_OutNetwork_Single + CoveredService_Lenses_OutNetwork_Bifocal + CoveredService_Lenses_OutNetwork_Trifocal;
                            //oWordDoc.Tables[tableNoVision].Cell(6, colcount_outnetwork).Range.Text = BenefitFrequency_Contacts_OutNetwork;
                            oWordDoc.Tables[tableNoVision].Cell(7, colcount_outnetwork).Range.Text = CoveredService_Contact_Lenses_OutNetwork;

                            #endregion Vision OutNetwork

                            #endregion

                            //// For deleting the last empty rows
                            //for (int rowNum = 2; rowNum <= oWordDoc.Tables[tableNoVision].Rows.Count; rowNum++)
                            //{
                            //    if (string.IsNullOrEmpty(oWordDoc.Tables[tableNoVision].Cell(rowNum, 1).Range.Text.ToString()) || oWordDoc.Tables[tableNoVision].Cell(rowNum, 1).Range.Text == "\r\a")
                            //    {
                            //        oWordDoc.Tables[tableNoVision].Rows[rowNum].Delete();
                            //        rowNum = rowNum - 1;
                            //    }
                            //}

                            count++;
                        }
                    }
                }

                if (lstcarrier.Count > 0)
                {
                    foreach (string item in lstcarrier)
                    {
                        if (ADD_Carrier.Length == 0)
                        {
                            ADD_Carrier = item;
                        }
                        else
                        {
                            ADD_Carrier = ADD_Carrier + " and " + item;
                        }
                    }
                }

                #region merge fields
                // Iterate through each field in word document to write values for that field
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();
                        if (fieldName.Contains("Vision Benefits"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("Vision Benefits");
                            continue;
                        }
                        if (fieldName.Contains("Delete Vision"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Contains("Vision Carrier Name"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(ADD_Carrier);
                            continue;
                        }
                        if (fieldName.Contains("General_Plan_InformationBenefits_Frequency_Eye_Exam"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(BenefitFrequency_Examination_Innetwork);
                            continue;
                        }
                        if (fieldName.Contains("General_Plan_InformationBenefits_Frequency_Frame_Exam"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(BenefitFrequency_Frames_Innetwork);
                            continue;
                        }
                    }
                }
                #endregion
                count = count - 1;
                if (count == 1)
                {
                    oWordDoc.Tables[tableNoVision].Cell(1, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(1, 3));
                    oWordDoc.Tables[tableNoVision].Cell(6, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(6, 3));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 3));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 1).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 2));
                }
                if (count == 2)
                {
                    oWordDoc.Tables[tableNoVision].Cell(1, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(1, 3));
                    oWordDoc.Tables[tableNoVision].Cell(1, 3).Merge(oWordDoc.Tables[tableNoVision].Cell(1, 4));
                    oWordDoc.Tables[tableNoVision].Cell(6, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(6, 3));
                    oWordDoc.Tables[tableNoVision].Cell(6, 3).Merge(oWordDoc.Tables[tableNoVision].Cell(6, 4));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 4).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 5));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 3).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 4));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 2).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 3));
                    //oWordDoc.Tables[tableNoVision].Cell(8, 1).Merge(oWordDoc.Tables[tableNoVision].Cell(8, 2));
                }
                oWordDoc.Tables[tableNoVision].Cell(6, 1).Merge(oWordDoc.Tables[tableNoVision].Cell(7, 1));
                //oWordDoc.Tables[tableNoVision].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="selectedColor">selectedColor contain selected color (Optional Paramter)</param>
        public void WriteDentalSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList, DataTable CarrierSpecific, DataTable PlanTypeSpecific, ArrayList DentalBenefitColumnIdOutNetworkList, string selectedColor = "")
        {
            try
            {
                #region HashtableDentalInNetwork
                Hashtable HashtableDentalInNetwork = new Hashtable();
                HashtableDentalInNetwork.Add(9, "465"); //Dental/Benefits/Reasonable & Customary Percentile 
                HashtableDentalInNetwork.Add(8, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalInNetwork.Add(7, "45");  //Calendar Year Deductible - Individual
                HashtableDentalInNetwork.Add(6, "44");  //Calendar Year Deductible - Family
                HashtableDentalInNetwork.Add(5, "55");  //Calendar Year Benefit Maximum
                HashtableDentalInNetwork.Add(4, "164"); //Preventive & Diagnostic Care
                HashtableDentalInNetwork.Add(3, "64");  //Basic Services – Basic
                HashtableDentalInNetwork.Add(2, "336"); //Major Services – Major
                HashtableDentalInNetwork.Add(1, "314"); //Orthodontia[Lifetime Orthodontia Maximum]
                #endregion

                #region HashtableDentalOutNetwork
                Hashtable HashtableDentalOutNetwork = new Hashtable();
                HashtableDentalOutNetwork.Add(8, "566"); //Annual Deductible[Deductible waived for Preventive]
                HashtableDentalOutNetwork.Add(7, "45");  //Calendar Year Deductible - Individual
                HashtableDentalOutNetwork.Add(6, "44");  //Calendar Year Deductible - Familyr Preventive]
                HashtableDentalOutNetwork.Add(5, "55");  //Calendar Year Benefit Maximum
                HashtableDentalOutNetwork.Add(4, "164"); //Preventive & Diagnostic Care
                HashtableDentalOutNetwork.Add(3, "64");  //Basic Services – Basic
                HashtableDentalOutNetwork.Add(2, "336"); //Major Services – Major
                HashtableDentalOutNetwork.Add(1, "314"); //Orthodontia[Lifetime Orthodontia Maximum]
                #endregion

                int count = 1;
                DataRow[] foundRows = null;
                DataRow[] foundPlanTypeRows = null;

                int dentalCount = 1; //For 3 different dental plans
                int dentalTableNo = 8; //For giving proper table numbers for selected plans
                string value = "";
                int rowCnt = 3;
                bool isRowIncremented = false;

                string Reasonable_And_Customary_Percentile1 = string.Empty;
                string Reasonable_And_Customary_Percentile2 = string.Empty;
                string Reasonable_And_Customary_Percentile3 = string.Empty;
                string AnnualDeductibleIndividual_Innetwork = string.Empty;
                string AnnualDeductibleFamily_Innetwork = string.Empty;
                string AnnualDeductibleIndividual_Outnetwork = string.Empty;
                string AnnualDeductibleFamily_Outnetwork = string.Empty;

                string AnnualPlanMaximum_Innetwork = string.Empty;
                string AnnualPlanMaximum_Outnetwork = string.Empty;

                string PreventiveService_Innetwork = string.Empty;
                string PreventiveService_Outnetwork = string.Empty;

                string BasicService_Innetwork = string.Empty;
                string BasicService_Outnetwork = string.Empty;

                string MajorService_Innetwork = string.Empty;
                string MajorService_Outnetwork = string.Empty;

                string Carrier1 = "";
                string Carrier2 = "";
                string Carrier3 = "";
                string OldCarrier = "";
                ArrayList arrCarrierName = new ArrayList();

                oWordDoc.Tables[dentalTableNo].Rows[1].Range.Font.Color = WdColor.wdColorWhite;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    // Check for only Dental plans from the given PlanTable
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim())
                    {
                        //  rowCnt = 3;
                        if (dentalCount == 1)
                        {
                            count = 1;
                            Carrier1 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, dentalTableNo, selectedColor, cv.DentalLOC);
                        }
                        else if (dentalCount == 2)
                        {
                            count = 2;
                            dentalTableNo = 9;
                            Carrier2 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, dentalTableNo, selectedColor, cv.DentalLOC);
                        }
                        else if (dentalCount == 3)
                        {
                            count = 3;
                            dentalTableNo = 10;
                            Carrier3 = (PlanTable.Rows[rowindex]["Carrier"].ToString()).Trim();
                            GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, dentalTableNo, selectedColor, cv.DentalLOC);
                        }

                        oWordDoc.Tables[dentalTableNo].Cell(1, 2).Range.Text = (Convert.ToString(PlanTable.Rows[rowindex]["Carrier"]).Trim() + " " + Convert.ToString(PlanTable.Rows[rowindex]["ProductTypeDescription"]).Trim() + " " + Convert.ToString(BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["description"]).Trim()).Trim();

                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[rowindex]["Carrier"].ToString().Replace("'", "''") + "'");
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[rowindex]["ProductTypeDescription"].ToString() + "'");

                            #region DentalTable

                            // Iterate the loop for above created HashTable to get the value for selected Key
                            foreach (int key in HashtableDentalInNetwork.Keys)
                            {
                                isRowIncremented = false;
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        // Set value = Prefix + Value + Suffix + AncillaryTest + ExclusionsLimitations
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 9:
                                                if (dentalCount == 1)
                                                { Reasonable_And_Customary_Percentile1 = value; }
                                                if (dentalCount == 2)
                                                { Reasonable_And_Customary_Percentile2 = value; }
                                                if (dentalCount == 3)
                                                { Reasonable_And_Customary_Percentile3 = value; }

                                                break;
                                            case 7: AnnualDeductibleIndividual_Innetwork = value; break;
                                            case 6: AnnualDeductibleFamily_Innetwork = value; break;
                                            case 5: AnnualPlanMaximum_Innetwork = value; break;
                                            case 4: PreventiveService_Innetwork = value; break;
                                            case 3: BasicService_Innetwork = value; break;
                                            case 2: MajorService_Innetwork = value; break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region OutNetwork
                            foreach (int key in HashtableDentalOutNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalLOC.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && DentalBenefitColumnIdOutNetworkList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDentalInNetwork[key].ToString())
                                    {
                                        // Set value = Prefix + Value + Suffix + AncillaryTest + ExclusionsLimitations
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim_String();
                                        switch (key)
                                        {
                                            case 7: AnnualDeductibleIndividual_Outnetwork = value; break;
                                            case 6: AnnualDeductibleFamily_Outnetwork = value; break;
                                            case 5: AnnualPlanMaximum_Outnetwork = value; break;
                                            case 4: PreventiveService_Outnetwork = value; break;
                                            case 3: BasicService_Outnetwork = value; break;
                                            case 2: MajorService_Outnetwork = value; break;
                                        }
                                        // isRowIncremented = true;
                                    }
                                }
                            }
                            #endregion

                            oWordDoc.Tables[dentalTableNo].Cell(2, 2).Range.Text = AnnualDeductibleIndividual_Innetwork + " / " + AnnualDeductibleFamily_Innetwork + " / " + AnnualDeductibleIndividual_Outnetwork + " / " + AnnualDeductibleFamily_Outnetwork;
                            oWordDoc.Tables[dentalTableNo].Cell(3, 2).Range.Text = AnnualPlanMaximum_Innetwork + " / " + AnnualPlanMaximum_Outnetwork;
                            oWordDoc.Tables[dentalTableNo].Cell(4, 2).Range.Text = PreventiveService_Innetwork + " / " + PreventiveService_Outnetwork;
                            oWordDoc.Tables[dentalTableNo].Cell(5, 2).Range.Text = BasicService_Innetwork + " / " + BasicService_Outnetwork;
                            oWordDoc.Tables[dentalTableNo].Cell(6, 2).Range.Text = MajorService_Innetwork + " / " + MajorService_Outnetwork + "\n" + "(12 month waiting period applies to new enrollees)";

                            AnnualDeductibleIndividual_Innetwork = string.Empty;
                            AnnualDeductibleFamily_Innetwork = string.Empty;
                            AnnualDeductibleIndividual_Outnetwork = string.Empty;
                            AnnualDeductibleFamily_Outnetwork = string.Empty;

                            AnnualPlanMaximum_Innetwork = string.Empty;
                            AnnualPlanMaximum_Outnetwork = string.Empty;

                            PreventiveService_Innetwork = string.Empty;
                            PreventiveService_Outnetwork = string.Empty;

                            BasicService_Innetwork = string.Empty;
                            BasicService_Outnetwork = string.Empty;

                            MajorService_Innetwork = string.Empty;
                            MajorService_Outnetwork = string.Empty;

                            // For deleting the last empty rows
                            for (int rowNum = 2; rowNum <= oWordDoc.Tables[dentalTableNo].Rows.Count; rowNum++)
                            {
                                if (string.IsNullOrEmpty(oWordDoc.Tables[dentalTableNo].Cell(rowNum, 1).Range.Text.ToString()) || oWordDoc.Tables[dentalTableNo].Cell(rowNum, 1).Range.Text == "\r\a")
                                {
                                    oWordDoc.Tables[dentalTableNo].Rows[rowNum].Delete();
                                    rowNum = rowNum - 1;
                                }
                            }

                            count++;
                            dentalCount++;
                        }
                    }
                }

                #region merge fields
                int iTotalFields1 = 0;

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields1++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("Dental Carrier Name1"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier1.Trim());
                        }
                        if (fieldName.Contains("Dental Carrier Name2"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier2.Trim());
                        }
                        if (fieldName.Contains("Dental Carrier Name3"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(Carrier3.Trim());
                        }
                    }
                }
                #endregion


                //---------------------------------------------------------------------------------------
                // Code to replace the text inside the text box
                //foreach (Word.Shape shape in oWordDoc.Shapes)
                //{
                //    if (shape.Type == Microsoft.Office.Core.MsoShapeType.msoTextBox)
                //    {
                //        if (shape.Name == "Text Box 29")
                //        {
                //            shape.TextFrame.TextRange.Text = shape.TextFrame.TextRange.Text.Replace("Dental Carrier Name1", Carrier1);
                //        }
                //    }
                //}
                //---------------------------------------------------------------------------------------

                comFunObj.FindandReplace(oWordDoc, "<<Dental Carrier Name1>>", Carrier1);
                comFunObj.FindandReplace(oWordDoc, "<<Dental Carrier Name2>>", Carrier2);
                comFunObj.FindandReplace(oWordDoc, "<<Dental Carrier Name3>>", Carrier3);

                comFunObj.FindandReplace(oWordDoc, "<<Dental/Benefits/Reasonable & Customary Percentile1>>", Reasonable_And_Customary_Percentile1);
                comFunObj.FindandReplace(oWordDoc, "<<Dental/Benefits/Reasonable & Customary Percentile2>>", Reasonable_And_Customary_Percentile2);
                comFunObj.FindandReplace(oWordDoc, "<<Dental/Benefits/Reasonable & Customary Percentile3>>", Reasonable_And_Customary_Percentile3);



            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable PlanTypeSpecific, DataSet BenefitDS, ArrayList FSABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                int count = 1;
                Hashtable HashtableFSA = new Hashtable();

                //DataRow[] foundPlanTypeRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "354"); // Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            //foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Delete FSA"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(" ");
                                                    continue;
                                                }
                                                if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    string administration_service_medicalspending = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                    if (administration_service_medicalspending.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                    }
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList, string clientName, DropDownList ddlHSAPlanName)
        {
            try
            {
                string carrier = string.Empty;
                string employeeOnlyCoverage = " ";
                string familyCoverage = " ";
                string employeesOver55 = " ";

                Hashtable HashtableHSABenifit = new Hashtable();

                string Max_Annual_Contribution_Individual1 = " ";
                string Max_Annual_Contribution_Family1 = " ";
                string value = "";

                #region HashtablHashtableHSA

                HashtableHSABenifit.Add(1, "635");     //General Plan Information – Maximum Annual Contribution/Individual
                HashtableHSABenifit.Add(2, "636");     //General Plan Information – Maximum Annual Contribution/Family

                //HashtableHSABenifit.Add(1, "640");     //Employer Contributions – Individual
                //HashtableHSABenifit.Add(2, "644");     //Employer Contributions – Family
                #endregion

                // IRS
                DataTable dt_IRS = new DataTable();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            // Get the renewal year for taking the IRS table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Effective"].ToString()).Year);

                            dt_IRS = bp.GetIRCList(renewalDate);
                            carrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                            for (int j = 0; j < dt_IRS.Rows.Count; j++)
                            {
                                employeeOnlyCoverage = Convert.ToString(dt_IRS.Rows[j]["EmployeeOnlyCoverage"].ToString());

                                familyCoverage = Convert.ToString(dt_IRS.Rows[j]["FamilyCoverage"].ToString());
                                //employeesOver55 = Convert.ToString(dt_IRC.Rows[j]["EmployeesOver55"].ToString());
                            }

                            #region HSABenifitTable

                            foreach (int key in HashtableHSABenifit.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.HSAPlanType_CommonCriteria.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSABenifit[key].ToString())
                                    {
                                        value = dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString();

                                        switch (key)
                                        {
                                            case 1: Max_Annual_Contribution_Individual1 = value; break;
                                            case 2: Max_Annual_Contribution_Family1 = value; break;
                                        }
                                    }
                                }
                            }

                            #endregion
                        }
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                if (ddlHSAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("Delete HSA"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");

                            }
                            if (fieldName.Contains("HSA Carrier"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(carrier))
                                {
                                    oWordApp.Selection.TypeText(carrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("IRS Employee Only coverage"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Max_Annual_Contribution_Individual1))
                                {
                                    //oWordApp.Selection.TypeText(employeeOnlyCoverage);
                                    oWordApp.Selection.TypeText(Max_Annual_Contribution_Individual1.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                            if (fieldName.Contains("IRS Family Coverage"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Max_Annual_Contribution_Family1))
                                {
                                    //oWordApp.Selection.TypeText(familyCoverage);
                                    oWordApp.Selection.TypeText(Max_Annual_Contribution_Family1.Trim());
                                    continue;
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Contact information Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        /// <param name="dtPlanContactDetails">DataTable dtPlanContactDetails contain the plan contact information (Optional Parameter)</param>
        public void WriteContactinformationToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, string selectedColor = "", DataTable dtPlanContactDetails = null)
        {
            try
            {
                int count = 1;
                int k = 1;
                string carriername = "";
                string plantype = "";
                string ProductTypeDesc = "";
                DataRow[] foundRows = null;
                int cnt = 2;

                string carrier = string.Empty;
                string description_Policy = string.Empty;
                string website_phone = string.Empty;
                int Contact_Tableno = 1;
                int rowCnt = 2;
                foreach (Word.Border border in oWordDoc.Tables[count].Borders)
                {
                    carrier = oWordDoc.Tables[count].Cell(cnt, 1).Range.Text;
                    description_Policy = oWordDoc.Tables[count].Cell(cnt, 2).Range.Text;
                    website_phone = oWordDoc.Tables[count].Cell(cnt, 3).Range.Text.Replace("\r\r", "\r");
                }

                oWordDoc.Tables[Contact_Tableno].Range.Font.Color = comFunObj.font_color(selectedColor);
                oWordDoc.Tables[Contact_Tableno].Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
                oWordDoc.Tables[Contact_Tableno].Rows[1].Range.Font.Color = WdColor.wdColorWhite;
                oWordDoc.Tables[Contact_Tableno].Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
                oWordDoc.Tables[Contact_Tableno].Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if ((carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype != PlanTable.Rows[i]["PlanType"].ToString()) || (carriername == PlanTable.Rows[i]["Carrier"].ToString() && ProductTypeDesc != PlanTable.Rows[i]["ProductTypeDescription"].ToString()) || (carriername != PlanTable.Rows[i]["Carrier"].ToString() && plantype == PlanTable.Rows[i]["PlanType"].ToString()))
                    {
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        if (k > 1)
                        {
                            oWordDoc.Tables[count].Rows.Add();
                        }
                        carriername = PlanTable.Rows[i]["Carrier"].ToString();
                        plantype = PlanTable.Rows[i]["PlanType"].ToString();
                        ProductTypeDesc = PlanTable.Rows[i]["ProductTypeDescription"].ToString();
                        oWordDoc.Tables[count].Cell(rowCnt, 1).Range.Text = Convert.ToString(PlanTable.Rows[i]["Carrier"].ToString());
                        oWordDoc.Tables[count].Cell(rowCnt, 2).Range.Text = Convert.ToString(PlanTable.Rows[i]["ProductTypeDescription"].ToString()) + " / " + Convert.ToString(PlanTable.Rows[i]["PolicyNumber"].ToString());
                        //foundRows = CarrierSpecific.Select("BenefitPointCarrierName='" + PlanTable.Rows[i]["Carrier"].ToString().Replace("'", "''") + "'");

                        var planContactName = (from n in dtPlanContactDetails.AsEnumerable()
                                               where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                               select n.Field<string>("ContactName")).FirstOrDefault();

                        var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                                where n.Field<string>("ProductId") == Convert.ToString(PlanTable.Rows[i]["ProductId"])
                                                select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                        oWordDoc.Tables[count].Cell(rowCnt, 3).Range.Text = Convert.ToString(planContactName) + "\n" + Convert.ToString(planContactPhone);

                        k++;
                        rowCnt++;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS">DataSet BenefitStructureDS Object as optional parameter</param>
        /// <param name="ddlImageOption">DropDownList ddlImageOption Object as optional parameter</param>
        public void WriteFieldToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRCData> BRCList, string ddlBRCSelectedValue, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null, DropDownList ddlImageOption = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                DataTable Emp = new DataTable();
                int BRCindex = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                //foreach (Word.Shape shape in oWordDoc.Shapes)
                //{
                //    if (shape.Name == "Text Box 15")
                //    {
                //        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                //    }

                //}

                ////if (ddlBRC.SelectedIndex > 1)
                ////{
                ////    BRCindex = BRCList.FindIndex(item => item.BRC_Region_Id == int.Parse(ddlBRC.SelectedValue.ToString()));
                ////}
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalLOC.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["ProductId"].ToString())
                        {
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                string fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");

                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;
                                    string fieldName = fieldText.Substring(11, endMerge - 11);
                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Picture 1"))
                                    {
                                        myMergeField.Delete();
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 1", 5.62f, 3.25f);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 2"))
                                    {
                                        myMergeField.Delete();
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 2", 3.62f, 2.57f);
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 6"))
                                    {
                                        myMergeField.Delete();
                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 6", 4.24f, 2.6f);
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();

                                            // Keep the image inline with the field (Text)
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapInline;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 7"))
                                    {
                                        myMergeField.Delete();

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 7", 5.62f, 3.32f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapInline;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeBottom;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 10"))
                                    {
                                        myMergeField.Delete();

                                        // Format the picture.
                                        Word.InlineShape inline_shape = comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 10", 5.04f, 3.07f);

                                        // Keep the image inline with the field (Text)
                                        if (inline_shape != null)
                                        {
                                            Word.Shape shape = inline_shape.ConvertToShape();
                                            shape.RelativeVerticalPosition = WdRelativeVerticalPosition.wdRelativeVerticalPositionLine;

                                            // Wrap text around the picture's square.
                                            shape.WrapFormat.Type = Word.WdWrapType.wdWrapSquare;

                                            //// Align the picture on the upper right.
                                            shape.Left = (float)Word.WdShapePosition.wdShapeLeft;
                                            shape.Top = (float)Word.WdShapePosition.wdShapeTop;
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Picture 13"))
                                    {
                                        myMergeField.Delete();
                                        comFunObj.PictureMethod(oWordDoc, oWordApp, ddlImageOption, rngFieldCode, "Picture 13", 4.39f, 2.85f);
                                        continue;
                                    }

                                    if (fieldName.Contains("Client Address / City"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_city"].ToString().Trim());
                                    }
                                    if (fieldName.Contains("Client / Address / State"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(AccountDS.Tables["AccountTable"].Rows[0]["mainAddress_state"].ToString().Trim());
                                    }

                                    if (fieldName.Contains("First Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Client_Name_Heading"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Client Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Benefits Enrollment Guide"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Benefits Enrollment Guide");
                                        continue;
                                    }



                                    if (fieldName.Contains("Plan Effective Date Year"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Renewal Plan Year"))
                                    {
                                        myMergeField.Select();
                                        string renewaldate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(renewaldate.ToString()).Year.ToString()).Trim());
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        continue;
                                    }

                                    if (fieldName.Contains("First Medical Plan Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewaldate = PlanTable.Rows[k]["Renewal"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(renewaldate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(renewaldate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("First Medical Plan Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(effectivedate.ToString()).ToString("M").Replace(" 0", " ").ToString() + ", " + Convert.ToDateTime(effectivedate.ToString()).Year.ToString()).Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Account Summary/Main Phone Number"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(comFunObj.GetAccountMainPhoneNumber(AccountDS));
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Plan/Renewal Date minus one day"))
                                    {
                                        myMergeField.Select();
                                        //Commented by:Mandar Apate
                                        //Date:8/24/2016
                                        //purpose:As per client said the date should be Medical Plan  effective Date

                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);

                                        //string renewal = PlanTable.Rows[k]["Effective"].ToString();
                                        //DateTime renewdate = Convert.ToDateTime(renewal);
                                        oWordApp.Selection.TypeText((renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString()).Trim());
                                        continue;
                                    }

                                    //if (fieldName.Contains("The Deadline to Enroll"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    oWordApp.Selection.TypeText("The Deadline to Enroll is");
                                    //    continue;
                                    //}
                                    if (fieldName.Contains("Brand Name Drugs:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Brand Name Drugs:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Mail Order Pharmacy:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Mail Order Pharmacy:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Coinsurance:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Coinsurance:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Copayment (Copay):"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Copayment (Copay):");
                                        continue;
                                    }
                                    if (fieldName.Contains("Inpatient:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Inpatient:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Outpatient:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Outpatient:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Deductible:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Deductible:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Generic Drugs:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Generic Drugs:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Out-of-Pocket Maximum:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Out-of-Pocket Maximum:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Primary Care Physician (PCP):"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Primary Care Physician (PCP):");
                                        continue;
                                    }
                                    if (fieldName.Contains("Specialist:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Specialist:");
                                        continue;
                                    }

                                    if (fieldName.Contains("In-Network:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("In-Network:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Out-of-Network:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Out-of-Network:");
                                        continue;
                                    }
                                    //if (fieldName.Contains("add applicable date"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    oWordApp.Selection.TypeText("add applicable date");
                                    //    continue;
                                    //}

                                    //if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                                    //{
                                    //    myMergeField.Select();

                                    //    if (Emp.Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                    //    }
                                    //    else
                                    //    {
                                    //        oWordApp.Selection.TypeText(" ");
                                    //    }
                                    //}
                                    //if (fieldName.Contains("Unmarried Child To Age"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText((EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString()).Trim());
                                    //        continue;
                                    //    }
                                    //    else
                                    //    {
                                    //        myMergeField.Delete();
                                    //    }
                                    //}
                                    //if (fieldName.Contains("Definition Of Domestic Partner"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                                    //        oWordApp.Selection.TypeText(domesticPartner);
                                    //        continue;
                                    //    }
                                    //    else
                                    //    {
                                    //        myMergeField.Delete();
                                    //    }
                                    //}
                                    //if (fieldName.Contains("definitionofdomesticpartner"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        domesticPartner = EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString();
                                    //        oWordApp.Selection.TypeText(domesticPartner.Trim());
                                    //        continue;
                                    //    }
                                    //}
                                    //if (fieldName.Contains("medicalplanwaitingperiod"))
                                    //{
                                    //    myMergeField.Select();
                                    //    if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                    //    {
                                    //        oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                    //        continue;
                                    //    }
                                    //}

                                    if (ddlBRCSelectedValue == "YES")
                                    {
                                        if (BRCList.Count > 0)
                                        {
                                            if (fieldName.Contains("BRC Selected"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                continue;
                                            }
                                            if (fieldName.Contains("Benefit Resource Center"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText("Benefit Resource Center");
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Hours"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Phone"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Email"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                                }
                                                continue;
                                            }
                                            if (fieldName.Contains("BRC Fax"))
                                            {
                                                myMergeField.Select();
                                                if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                                {
                                                    myMergeField.Delete();
                                                }
                                                else
                                                {
                                                    oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                                }
                                                continue;
                                            }
                                        }
                                    }//BRC IF YES CLOSE

                                    if (ddlOffice.SelectedIndex > 0)
                                    {
                                        DataRow[] FoundRow = null;
                                        FoundRow = Office.Select("OfficeID='" + ddlOffice.SelectedItem.Value.ToString() + "'");
                                        if (FoundRow.Count() > 0)
                                        {
                                            if (fieldName.Contains("Office Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(ddlOffice.SelectedItem.Text.ToString());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Legal Name"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(FoundRow[0]["OfficeLegalName"].ToString().Trim());
                                                continue;
                                            }
                                            if (fieldName.Contains("Office Address"))
                                            {
                                                myMergeField.Select();
                                                string var = Convert.ToString(FoundRow[0]["OfficeAddress"].ToString());
                                                if (string.IsNullOrEmpty(var))
                                                {
                                                    var = " ";
                                                }
                                                oWordApp.Selection.TypeText(var);
                                                continue;
                                            }
                                            if (fieldName.Contains("Company Logo"))
                                            {
                                                myMergeField.Select();
                                                oWordApp.Selection.TypeText(" ");
                                                object missing = System.Type.Missing;
                                                Word.Range rng = rngFieldCode;
                                                rng.SetRange(rngFieldCode.End + 1, rngFieldCode.End + 1);

                                                string imageName = FoundRow[0]["OfficeLogo"].ToString();
                                                rng.InlineShapes.AddPicture(Server.MapPath("~/Files/BenefitSummary/Images/CompanyLogo/" + imageName));
                                                continue;
                                            }
                                        }
                                    }
                                    if (index > -1)
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(ContactList[index].Name.Trim());
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            StringBuilder Phone = new StringBuilder(); ;

                                            for (int i = 0; i < ContactList[index].Phone.Count; i++)
                                            {
                                                Phone.Append(ContactList[index].Phone[i]);
                                                if (ContactList[index].Phone[i] != string.Empty)
                                                {
                                                    Phone.Append("\n");
                                                }
                                            }
                                            if (Phone.ToString() == "")
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Phone.ToString());
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (fieldName.Contains("Contact Name"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Contact Number"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Effective Date"))
                                    {
                                        myMergeField.Select();
                                        string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.TypeText(Convert.ToDateTime(effectivedate.ToString()).Year.ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("Renewal Date"))
                                    {
                                        myMergeField.Select();
                                        string renewal = PlanTable.Rows[k]["Renewal"].ToString();
                                        DateTime renewdate = Convert.ToDateTime(renewal).AddDays(-1);
                                        oWordApp.Selection.TypeText(renewdate.Year.ToString());
                                        continue;
                                    }

                                    // For giving color to header and text
                                    if (fieldName.Contains("EMPLOYEE BENEFITS ENROLLMENT GUIDE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("EMPLOYEE BENEFITS ENROLLMENT GUIDE");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Benefits Open Enrollment"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Benefits Open Enrollment");
                                        continue;
                                    }
                                    if (fieldName.Contains("What is Open Enrollment?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What is Open Enrollment?");
                                        continue;
                                    }
                                    if (fieldName.Contains("What’s new this year?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What’s new this year?");
                                        continue;
                                    }
                                    //if (fieldName.Contains("Eligibility"))
                                    //{
                                    //    myMergeField.Select();
                                    //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                                    //    oWordApp.Selection.TypeText("Eligibility");
                                    //    continue;
                                    //}
                                    if (fieldName.Contains("Family Status Change Events"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Family Status Change Events");
                                        continue;
                                    }
                                    if (fieldName.Contains("Disclaimer"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Disclaimer");
                                        continue;
                                    }
                                    if (fieldName.Contains("Contact Information"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Contact Information");
                                        continue;
                                    }
                                    if (fieldName.Contains("Have Questions? Need Help?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Have Questions? Need Help?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Medical Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dental Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Dental Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Vision Benefits"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Vision Benefits");
                                        continue;
                                    }
                                    if (fieldName.Contains("Wellness Initiative"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Wellness Initiative");
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical_Renewal_Plan_Year"))
                                    {
                                        myMergeField.Select();
                                        string renewaldate = PlanTable.Rows[k]["Effective"].ToString();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText((Convert.ToDateTime(renewaldate.ToString()).Year.ToString()).Trim());

                                        continue;
                                    }
                                    if (fieldName.Contains("Health Savings Account (HSA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Health Savings Account (HSA)");
                                        continue;
                                    }
                                    if (fieldName.Contains("What is a Health Saving Account?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What is a Health Savings Account (HSA)?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Plus, you get extra tax advantages with an HSA because:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Plus, you get extra tax advantages with an HSA because:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Are you eligible to open a Health Savings Account (HSA)?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Are you eligible to open a Health Savings Account (HSA)?");
                                        continue;
                                    }
                                    if (fieldName.Contains("HSA Contributions"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("HSA Contributions");
                                        continue;
                                    }
                                    if (fieldName.Contains("FOR THE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("FOR THE");
                                        continue;
                                    }
                                    if (fieldName.Contains("TAX YEAR:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("TAX YEAR:");
                                        continue;
                                    }
                                    if (fieldName.Contains("How do I get reimbursed for my eligible expenses?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("How do I get reimbursed for my eligible expenses?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Health Reimbursement Account (HRA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Health Reimbursement Account (HRA)");
                                        continue;
                                    }
                                    if (fieldName.Contains("Flexible Spending Account (FSA)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Flexible Spending Account (FSA)");
                                        continue;
                                    }

                                    if (fieldName.Contains("Healthcare FSA Debit Card:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Healthcare FSA Debit Card:");
                                        continue;
                                    }

                                    if (fieldName.Contains("Grace Period:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Grace Period:");
                                        continue;
                                    }

                                    if (fieldName.Contains("FSA Carryover:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("FSA Carryover:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Healthcare Expense Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Healthcare Expense Account");
                                        continue;
                                    }
                                    if (fieldName.Contains("Dependent Care Account"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Dependent Care Account");
                                        continue;
                                    }
                                    if (fieldName.Contains("What are the risks of FSAs?"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("What are the risks of FSAs?");
                                        continue;
                                    }
                                    if (fieldName.Contains("Life & Accidental Death and Dismemberment"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Life & Accidental Death and Dismemberment");
                                        continue;
                                    }
                                    if (fieldName.Contains("Disability Insurance Coverage"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Disability Insurance Coverage");
                                        continue;
                                    }
                                    if (fieldName.Contains("Long Term Disability"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Long Term Disability");
                                        continue;
                                    }
                                    if (fieldName.Contains("Pre-existing limitations may apply:"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Pre-existing limitations may apply:");
                                        continue;
                                    }
                                    if (fieldName.Contains("Short Term Disability"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Short Term Disability");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Assistance Plan (EAP)"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Assistance Plan (EAP)");
                                        continue;
                                    }
                                    if (fieldName.Contains("Employee Assistance Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("Employee Assistance Plan");
                                        continue;
                                    } if (fieldName.Contains("It’s free..."))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("It’s free...");
                                        continue;
                                    } if (fieldName.Contains("It’s confidential..."))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.Range.Font.Color = wdColor_font;
                                        oWordApp.Selection.TypeText("It’s confidential...");
                                        continue;
                                    }

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                string HRACarrier = string.Empty;

                #region HashtableHRA
                Hashtable HashtableHRA = new Hashtable();
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "239"); // Health Reimbursement Account Tier 2

                #endregion

                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;

                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                HRACarrier = Convert.ToString(PlanTable.Rows[k]["Carrier"]).Trim();

                                foreach (int key in HashtableHRA.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HRA Carrier Name"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRACarrier))
                                {
                                    oWordApp.Selection.TypeText(HRACarrier);
                                }
                                continue;
                            }
                            if (fieldName.Contains("Delete HRA"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");

                            }
                            if (fieldName.Contains("HRA Tier One"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("HRA Tier Two"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        /// <param name="ddlSTDPlanName">DropDownList ddlSTDPlanName object</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        public void WriteSTDSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList, DropDownList ddlSTDPlanName, string selectedcolor = "")
        {
            try
            {

                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       //STD General Information – Elimination Period – Accident
                HashtableSTD.Add(2, "505");     //STD General Information – Elimination Period –Sickness
                HashtableSTD.Add(3, "71");      //STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "569");     //STD General Information – Weekly Benefit Maximum
                HashtableSTD.Add(5, "350");     //STD General Information – Maximum Period of Payment
                HashtableSTD.Add(6, "449");     //Benefits[Pre-Existing Condition Limitation]
                #endregion

                string EliminationPeriod_Accident = string.Empty;
                string EliminationPeriod_Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Weekly_Benefit_Maximum = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;
                string PreExisting_Condition_Limitations = string.Empty;

                string EliminationPeriod_Accident2 = string.Empty;
                string EliminationPeriod_Sickness2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Weekly_Benefit_Maximum2 = string.Empty;
                string Maximum_Period_of_Payment2 = string.Empty;
                string PreExisting_Condition_Limitations2 = string.Empty;
                string ProductName = "";
                int STD_TBL_Number = 13;
                string value = "";
                bool isSTDPlan_Selected = false;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        isSTDPlan_Selected = true;
                    }
                }

                oWordDoc.Tables[STD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[STD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[STD_TBL_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[STD_TBL_Number].Range.Font.Color = wdColor_font;

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, STD_TBL_Number, selectedcolor, cv.STDPlanType_CommonCriteria);

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region STD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 1:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Accident = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Accident = value.Trim();
                                                    }
                                                    break;
                                                case 2:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Sickness = value.Trim();
                                                    }
                                                    break;
                                                case 3: Benefit_Percentage = value.Trim(); break;
                                                case 4: Weekly_Benefit_Maximum = value.Trim(); break;
                                                case 5: Maximum_Period_of_Payment = (dr["value"].ToString() + " " + dr["UOM"].ToString()).Trim(); break;
                                                case 6: PreExisting_Condition_Limitations = value.Trim(); break;
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 1:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Accident2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Accident2 = value.Trim();
                                                    }
                                                    break;
                                                case 2:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod_Sickness2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod_Sickness2 = value.Trim();
                                                    }
                                                    break;
                                                case 3: Benefit_Percentage2 = value.Trim(); break;
                                                case 4: Weekly_Benefit_Maximum2 = value.Trim(); break;
                                                case 5: Maximum_Period_of_Payment2 = (dr["value"].ToString() + " " + dr["UOM"].ToString()).Trim(); break;
                                                case 6: PreExisting_Condition_Limitations2 = value.Trim(); break;
                                            }
                                        }

                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    if (count == 1)
                                    {
                                        #region First_STD Plan
                                        fieldName = fieldName.Trim();
                                        if (fieldName.Contains("STD_Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[STD_TBL_Number].Cell(2, 1).Range.Text = oWordDoc.Tables[STD_TBL_Number].Cell(2, 1).Range.Text.Replace("STD_Plan1", " ");
                                            //oWordDoc.Tables[STD_TBL_Number].Cell(11, 1).Range.Text = oWordDoc.Tables[STD_TBL_Number].Cell(11, 1).Range.Text.Replace("Delete_STD_LTD1", " ");
                                            //oWordDoc.Tables[STD_TBL_Number].Cell(12, 1).Range.Text = oWordDoc.Tables[STD_TBL_Number].Cell(12, 1).Range.Text.Replace("Delete_STD_LTD2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("Delete Disability STD or LTD"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("If STD is selected, include this sentence"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Accident1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Accident))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Accident);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Sickness1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Sickness))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Sickness);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("STD_General Plan Information – Benefit Percentage1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Weekly Benefit Maximum1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Weekly_Benefit_Maximum))
                                            {
                                                oWordApp.Selection.TypeText(Weekly_Benefit_Maximum);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Maximum Period of Payment1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                            {
                                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General_Plan_Information – Pre-Existing Condition Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                    if (count == 2)
                                    {
                                        #region Second STD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();

                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("STD_Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[STD_TBL_Number].Cell(3, 1).Range.Text = oWordDoc.Tables[STD_TBL_Number].Cell(3, 1).Range.Text.Replace("STD_Plan2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Accident2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Accident2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Accident2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Elimination Period – Sickness2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod_Sickness2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod_Sickness2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("STD_General Plan Information – Benefit Percentage2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Weekly Benefit Maximum2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Weekly_Benefit_Maximum2))
                                            {
                                                oWordApp.Selection.TypeText(Weekly_Benefit_Maximum2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General Plan Information – Maximum Period of Payment2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Maximum_Period_of_Payment2))
                                            {
                                                oWordApp.Selection.TypeText(Maximum_Period_of_Payment2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("STD_General_Plan_Information – Pre-Existing Condition Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations2))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan </param>
        /// <param name="ddlLTDPlanName">DropDownList ddlLTDPlanName object</param>
        /// <param name="selectedColor">string selectedColor contain color selected on screen 1 (Optional Parameter)</param>
        public void WriteLTDSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList, DropDownList ddlLTDPlanName, string selectedcolor = "")
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableLTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableLTD
                HashtableLTD.Add(6, "71");  //General Plan Information – Benefit Percentage
                HashtableLTD.Add(5, "374"); //General Plan Information – Weekly Benefit Maximum
                HashtableLTD.Add(4, "181"); //LTD General Information – Elimination Period
                // HashtableLTD.Add(3, "351"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(7, "374");     // Benefits [Maximum Monthly Benefit]
                HashtableLTD.Add(3, "141"); //General Plan Information – Maximum Period of Payment
                HashtableLTD.Add(2, "449"); //General Plan Information – Pre-Existing Condition Limitations
                #endregion

                string EliminationPeriod = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Monthly_Benefit = string.Empty;
                string PreExisting_Condition_Limitations = string.Empty;

                string EliminationPeriod2 = string.Empty;
                string Benefit_Percentage2 = string.Empty;
                string Monthly_Benefit2 = string.Empty;
                string PreExisting_Condition_Limitations2 = string.Empty;

                string ProductName = "";
                int LTD_TBL_Number = 13;
                string value = "";
                bool isLTDPlan_Selected = false;

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        isLTDPlan_Selected = true;
                    }
                }

                oWordDoc.Tables[LTD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderTop].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[LTD_TBL_Number].Rows[1].Range.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);
                oWordDoc.Tables[LTD_TBL_Number].Rows.Borders[Word.WdBorderType.wdBorderBottom].Color = comFunObj.border_color(selectedcolor);

                oWordDoc.Tables[LTD_TBL_Number].Range.Font.Color = wdColor_font;

                GetPlanTableFirstColumnHeadingName_And_ColorFormatting(oWordDoc, PlanTable, BenefitDS, 0, LTD_TBL_Number, selectedcolor, cv.LTDPlanType_CommonCriteria);

                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[rowindex]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[rowindex]["productID"].ToString())
                        {
                            #region LTD
                            ProductName = ProductDS.Tables["ProductTable"].Rows[rowindex]["name"].ToString();
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType_CommonCriteria.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[rowindex]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        if (count == 1)
                                        {
                                            switch (key)
                                            {
                                                case 4:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod = value.Trim();
                                                    }
                                                    break;

                                                case 6: Benefit_Percentage = value.Trim(); break;
                                                case 7: Monthly_Benefit = value.Trim(); break;
                                                case 2: PreExisting_Condition_Limitations = value.Trim(); break;

                                            }
                                        }
                                        if (count == 2)
                                        {
                                            switch (key)
                                            {
                                                case 4:
                                                    if (value.Contains("days"))
                                                    {
                                                        EliminationPeriod2 = value.Trim().Replace("days", "day").Trim();
                                                    }
                                                    else
                                                    {
                                                        EliminationPeriod2 = value.Trim();
                                                    }
                                                    break;

                                                case 6: Benefit_Percentage2 = value.Trim(); break;
                                                case 7: Monthly_Benefit2 = value.Trim(); break;
                                                case 2: PreExisting_Condition_Limitations2 = value.Trim(); break;
                                            }
                                        }

                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);
                                    if (count == 1)
                                    {
                                        #region First LTD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Delete Disability STD or LTD"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("LTD_Benefit Summary Description1"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[LTD_TBL_Number].Cell(4, 1).Range.Text = oWordDoc.Tables[LTD_TBL_Number].Cell(4, 1).Range.Text.Replace("Delete_LTD1", " ");
                                            //oWordDoc.Tables[LTD_TBL_Number].Cell(11, 1).Range.Text = oWordDoc.Tables[LTD_TBL_Number].Cell(11, 1).Range.Text.Replace("Delete_STD_LTD1", " ");
                                            //oWordDoc.Tables[LTD_TBL_Number].Cell(12, 1).Range.Text = oWordDoc.Tables[LTD_TBL_Number].Cell(12, 1).Range.Text.Replace("Delete_STD_LTD2", " ");
                                            continue;
                                        }
                                        if (fieldName.Contains("If LTD is selected, include this sentence"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                        }
                                        //LTD_General Plan Information – Elimination Period1
                                        //LTD_General Plan Information – Benefit Percentage1
                                        //LTD_General Plan Information – Monthly Benefit Maximum1
                                        if (fieldName.Contains("LTD_General Plan Information – Elimination Period1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("LTD_General Plan Information – Benefit Percentage1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General Plan Information – Monthly Benefit Maximum1"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Monthly_Benefit))
                                            {
                                                oWordApp.Selection.TypeText(Monthly_Benefit);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General_Plan_Information – Pre-Existing Conditions Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                    if (count == 2)
                                    {
                                        #region Second LTD Plan
                                        fieldName = fieldName.Trim();

                                        if (fieldName.Contains("Life_STD_LTD_Plan"))
                                        {
                                            myMergeField.Select();

                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        if (fieldName.Contains("LTD_Benefit Summary Description2"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                                            oWordApp.Selection.TypeText(PlanTable.Rows[rowindex]["SummaryName"].ToString());
                                            oWordDoc.Tables[LTD_TBL_Number].Cell(5, 1).Range.Text = oWordDoc.Tables[LTD_TBL_Number].Cell(5, 1).Range.Text.Replace("Delete_LTD2", " ");
                                            continue;
                                        }
                                        //LTD_General Plan Information – Elimination Period1
                                        //LTD_General Plan Information – Benefit Percentage1
                                        //LTD_General Plan Information – Monthly Benefit Maximum1
                                        if (fieldName.Contains("LTD_General Plan Information – Elimination Period2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(EliminationPeriod2))
                                            {
                                                oWordApp.Selection.TypeText(EliminationPeriod2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }

                                        if (fieldName.Contains("LTD_General Plan Information – Benefit Percentage2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Benefit_Percentage2))
                                            {
                                                oWordApp.Selection.TypeText(Benefit_Percentage2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General Plan Information – Monthly Benefit Maximum2"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(Monthly_Benefit2))
                                            {
                                                oWordApp.Selection.TypeText(Monthly_Benefit2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        if (fieldName.Contains("LTD_General_Plan_Information – Pre-Existing Conditions Limitations"))
                                        {
                                            myMergeField.Select();
                                            if (!string.IsNullOrEmpty(PreExisting_Condition_Limitations2))
                                            {
                                                oWordApp.Selection.TypeText(PreExisting_Condition_Limitations2);
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(" ");
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void ShowUniqueCarrierNames_STD_LTD(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS, DataTable PlanTable)
        {
            try
            {
                string STD_CarrierName_1 = string.Empty;
                string STD_CarrierName_2 = string.Empty;
                string LTD_CarrierName1 = string.Empty;
                string LTD_CarrierName2 = string.Empty;
                string carrierName_STD_LTD = string.Empty;
                int STD_Count = 1;
                int LTD_Count = 1;
                for (int rowindex = 0; rowindex < ProductDS.Tables["ProductTable"].Rows.Count; rowindex++)
                {
                    //Carrier Names
                    #region  CarrierName - Spending Accounts
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.STDPlanType_CommonCriteria.ToLower())
                    {

                        if (STD_Count == 1)
                        {
                            STD_CarrierName_1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                        if (STD_Count == 2)
                        {
                            STD_CarrierName_2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                        STD_Count++;
                    }
                    if (PlanTable.Rows[rowindex]["PlanType"].ToString().ToLower() == cv.LTDPlanType_CommonCriteria.ToLower())
                    {
                        if (LTD_Count == 1)
                        {
                            LTD_CarrierName1 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                        if (LTD_Count == 2)
                        {
                            LTD_CarrierName2 = PlanTable.Rows[rowindex]["Carrier"].ToString();
                        }
                        LTD_Count++;
                    }

                    #endregion


                }

                carrierName_STD_LTD = comFunObj.GetCarrierList(",", STD_CarrierName_1, STD_CarrierName_2, LTD_CarrierName1, LTD_CarrierName2);

                #region merge fields
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {


                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);
                        if (fieldName.Contains("STD_And_LTD_Carrier Names"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(carrierName_STD_LTD);
                        }

                    }
                }
                #endregion


            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                //HashtableEAP.Add(1, "384"); // Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType_CommonCriteria.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("EAP Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                    if (fieldName.Contains("Delete EAP"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        /// <param name="ddlHRContact">Dropdownlist ddlHRContact Object</param>
        /// <param name="ContactList">List<Contact> ContactList Object</param>
        /// <param name="AccountDS">DataSet AccountDS Object as optional parameter</param>
        /// <param name="selectedcolor">string selectedcolor Object as optional parameter</param>
        /// <param name="BenefitStructureDS ">DataSet BenefitStructureDS  Object as optional parameter</param>
        public void WriteAdditionalProductsToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanInfoTable, DataTable OfficeTable, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice, DropDownList ddlHRContact, List<Contact> ContactList, DataSet AccountDS = null, string selectedcolor = "", DataSet BenefitStructureDS = null)
        {
            try
            {
                int iTotalFields = 0;
                DataTable Office = OfficeTable;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                bool is_Patient_Advocacy_Selected = false;
                bool is_Consumer_Driven_Telemedicine_Selected = false;
                bool is_Accident_Selected = false;
                bool is_Voluntary_Cancer_Selected = false;
                bool is_Voluntary_Critical_Illness_Selected = false;

                string Worksite_CarrierName = string.Empty;
                string Worksite_Accident_CarrierName = string.Empty;
                string Worksite_VoluntaryCancer_CarrierName = string.Empty;
                string Worksite_VoluntaryCritical_Illness_CarrierName = string.Empty;

                if (PlanInfoTable != null)
                {
                    for (int k = 0; k < PlanInfoTable.Rows.Count; k++)
                    {
                        if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Patient_Advocacy)
                        {
                            is_Patient_Advocacy_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine)
                        {
                            is_Consumer_Driven_Telemedicine_Selected = true;
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Accident)
                        {
                            is_Accident_Selected = true;
                            Worksite_Accident_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Cancer)
                        {
                            is_Voluntary_Cancer_Selected = true;
                            Worksite_VoluntaryCancer_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }
                        else if (Convert.ToInt32(PlanInfoTable.Rows[k]["ProductTypeId"].ToString()) == ConstantValue.AdditionalProducts_Voluntary_Critical_Illness)
                        {
                            is_Voluntary_Critical_Illness_Selected = true;
                            Worksite_VoluntaryCritical_Illness_CarrierName = Convert.ToString(PlanInfoTable.Rows[k]["Carrier"]);
                        }


                    }
                }

                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");

                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (is_Patient_Advocacy_Selected == true)
                        {
                            if (fieldName.Contains("Delete Patient Advocacy Program"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Patient Advocacy Program"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Patient Advocacy Program");
                                continue;
                            }
                            if (fieldName.Contains("Compass - Your Personal Healthcare Advisors"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Compass - Your Personal Healthcare Advisors");
                                continue;
                            } if (fieldName.Contains("WHY SHOULD YOU CONTACT COMPASS??"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHY SHOULD YOU CONTACT COMPASS??");
                                continue;
                            }

                            if (fieldName.Contains("WHY SHOULD YOU CONTACT COMPASS??"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("WHY SHOULD YOU CONTACT COMPASS??");
                                continue;
                            }
                        }

                        if (is_Consumer_Driven_Telemedicine_Selected == true)
                        {
                            if (fieldName.Contains("Delete Telemedicine"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Telemedicine"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Telemedicine");
                                continue;
                            }
                            if (fieldName.Contains("Here are some frequently asked questions regarding Teladoc:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Here are some frequently asked questions regarding Teladoc:");
                                continue;
                            }


                            if (fieldName.Contains("What kind of medical care does Teladoc provide?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("What kind of medical care does Teladoc provide?");
                                continue;
                            }

                            if (fieldName.Contains("Does Teladoc replace my doctor?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Does Teladoc replace my doctor?");
                                continue;
                            }
                            if (fieldName.Contains("How do I request a consult to talk to a doctor?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("How do I request a consult to talk to a doctor?");
                                continue;
                            }
                            if (fieldName.Contains("How do I set up my Teladoc account?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("How do I set up my Teladoc account?");
                                continue;
                            }
                            if (fieldName.Contains("How frequently can I call Teladoc?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("How frequently can I call Teladoc?");
                                continue;
                            }
                            if (fieldName.Contains("Can Teladoc doctors write a prescription?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Can Teladoc doctors write a prescription?");
                                continue;
                            }

                            if (fieldName.Contains("Who are Teladoc doctors?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Who are Teladoc doctors?");
                                continue;
                            }
                            if (fieldName.Contains("What is the cost to use Teladoc?"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("What is the cost to use Teladoc?");
                                continue;
                            }
                        }

                        if (is_Accident_Selected == true || is_Voluntary_Cancer_Selected == true || is_Voluntary_Critical_Illness_Selected == true)
                        {



                            // Worksite_CarrierName = Worksite_Accident_CarrierName + "," + Worksite_VoluntaryCancer_CarrierName + "," + Worksite_VoluntaryCritical_Illness_CarrierName;
                            if (fieldName.Contains("Delete Worksite Benefits"))
                            {
                                myMergeField.Select();

                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }

                            if (fieldName.Contains("Worksite Products"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Worksite Products");
                                continue;
                            }

                            //if (fieldName.Contains("Worksite Carrier Name"))
                            //{
                            //    myMergeField.Select();
                            //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                            //    oWordApp.Selection.TypeText("Worksite Carrier Name");
                            //    continue;
                            //}
                            if (fieldName.Contains("Accident Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Accident Insurance");
                                continue;
                            }
                            if (fieldName.Contains("Cancer Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Cancer Insurance");
                                continue;
                            }
                            if (fieldName.Contains("Hospital Indemnity Insurance"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Hospital Indemnity Insurance");
                                continue;
                            }
                            if (fieldName.Contains("To find out more information or to apply for coverage, leave a detailed message (name/contact information) or email at:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("To find out more information or to apply for coverage, leave a detailed message (name/contact information) or email at:");
                                continue;
                            }
                            if (fieldName.Contains("Phone Number and/or E-mail Address"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Phone Number and/or E-mail Address");
                                continue;
                            } if (fieldName.Contains("Some of the advantages of"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Some of the advantages of");
                                continue;
                            } if (fieldName.Contains("include:"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("include:");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        /// <param name="ddlLifeADD">DropDownList ddlLifeADD Object</param>
        /// <param name="ddlVoluntaryADD">DropDownList ddlVoluntaryADD Object</param>
        /// <param name="ddlMarketplaceCoverage">DropDownList ddlMarketplaceCoverage Object</param>
        /// <param name="ddlCreditableCoverage">DropDownList ddlCreditableCoverage Object</param>
        /// <param name="selectedColor">string selectedColor contains selected color from screen 1 (Optional Parameter).</param>
        public void WriteNoticeSectionToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlLifeADD, DropDownList ddlVoluntaryADD, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage, string selectedColor = "")
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedColor);

                bool flag = false;
                bool flag_MarketPlace = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }
                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }
                if (ddlChipNotice.SelectedIndex == 0 && ddlAnnualLegalNotice.SelectedIndex == 0 && ddlMarketplaceCoverage.SelectedIndex >= 1)
                {
                    flag_MarketPlace = true;
                }
                bool flag1 = false;

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                else if (flag == true)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                    r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                                }

                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            //adde by Vaibhav for spanish template
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                else if (flag == true)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                    r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                                }

                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            //else
                            //{
                            //    myMergeField.Delete();
                            //}
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag_MarketPlace == true)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                    r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                                }
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options_EnrolmentGuide.doc"), missing, true, missing, missing);
                            }
                            //Added by Vaibhav to add Spanish templte
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag_MarketPlace == true)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);
                                    r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)
                                }
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.PageSetup.RightMargin = 150f;
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("Annual_Notice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                r.InsertBreak(Word.WdBreakType.wdSectionBreakContinuous);

                                r.PageSetup.TopMargin = 108f; // Set Top Margin = 15" (Note : 1 " = 72f so 1.5" = 1.5*72 = 108f)

                                continue;
                            }
                        }
                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("OtherProducts"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.TypeText("\f"); // For Inserting the page break before Annual Legal Notice
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }

                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                if (flag1 == true)
                                {
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    oWordApp.ActiveDocument.Application.Selection.TypeBackspace();
                                    flag1 = false;
                                }

                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }

                            //////Word.Document document = oWordDoc.Application.ActiveDocument;
                            ////Word.Paragraph paragraph;
                            ////int totalPages;
                            //////Word.Range range;

                            ////// Get a range containing the whole document
                            //////r = oWordDoc.Content.Duplicate;
                            ////Word.Range range = oWordDoc.Range();
                            ////range = oWordDoc.Content.Duplicate;
                            ////// Get the total number of pages in range
                            ////totalPages = range.ComputeStatistics(Word.WdStatistic.wdStatisticPages);

                            //////object oMissing = System.Reflection.Missing.Value;
                            //////object what = Microsoft.Office.Interop.Word.WdGoToItem.wdGoToPage;
                            //////object which = Microsoft.Office.Interop.Word.WdGoToDirection.wdGoToFirst;
                            //////object count = 28;

                            ////for (int i = 28; i <= totalPages; i++)
                            ////{
                            ////    //count = i;

                            ////    // Set our range to contain only the last page
                            ////    //range = range.GoTo(ref what, ref which, ref count, ref oMissing);
                            ////    range = range.GoTo(Word.WdGoToItem.wdGoToPage, Type.Missing, i, Type.Missing);

                            ////    //oWordDoc.GoTo();

                            ////    range.Select();
                            ////    // Insert new paragraph
                            ////    paragraph = oWordDoc.Paragraphs.Add(range);
                            ////    paragraph.Range.PageSetup.TopMargin = 0.56f;
                            ////    paragraph.Range.PageSetup.BottomMargin = 0.69f;
                            ////    paragraph.Range.Font.Color = WdColor.wdColorWhite;
                            ////    paragraph.Range.Font.Size = 36f;
                            ////    paragraph.Range.Font.Name = "Trebuchet MS";
                            ////    // Test new paragraph
                            ////    paragraph.Range.Text = "This is paragraph!";

                            ////}
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                //COmmented by Vaibhav for spanish template
                //  comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true, selectedColor, "Enrollment Guide");
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedColor, "Enrollment Guide");
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        public void WriteEligibilityToTemplate9(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, int ClientID, int EleigibilityRuleId, string SessionId)
        {
            SummaryDetail sd = new SummaryDetail();
            DataTable Emp = new DataTable();
            string EmployeeStatus = string.Empty;
            string Working = string.Empty;
            string Frequency = string.Empty;
            string UOM = string.Empty;
            string Defination_UnmarriedChildAge = string.Empty;
            string Medical_Waiting_Period = string.Empty;
            string EmployeeType = string.Empty;
            int iTotalFields = 0;

            SummaryDetail sd1 = new SummaryDetail();
            DataSet AccountDS = sd1.GetAccountDetail_BenefitSummary(ClientID, SessionId);

            if (AccountDS.Tables.Count > 2)
            {
                Emp = AccountDS.Tables[2];
                if (Emp.Rows.Count > 0)
                {
                    EmployeeStatus = Emp.Rows[0]["EmployeeTypes_status"].ToString().Replace("_", "-");
                    EmployeeType = Emp.Rows[0]["EmployeeTypes_type"].ToString().Replace("_", "-");
                }
            }

            DataTable EligibilityDS = new DataTable();
            EligibilityDS = sd.GetEligibilityRule_BenefitSummary(PlanTable, SessionId, EleigibilityRuleId);

            if (EligibilityDS.Rows.Count > 0 && Emp.Rows.Count > 0 && (Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != null && Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"]) != ""))
            {
                Defination_UnmarriedChildAge = EligibilityDS.Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim();
                domesticPartner = EligibilityDS.Rows[0]["dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType"].ToString().Trim();
                //dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType

                Medical_Waiting_Period = EligibilityDS.Rows[0]["item"].ToString().Trim();

                IEnumerable<DataRow> query = from product in Emp.AsEnumerable()
                                             where product.Field<string>("EmployeeTypes_employeeTypeID") == Convert.ToString(EligibilityDS.Rows[0]["employeeTypeIDs"])
                                             select product;

                foreach (DataRow Def_Eligible_Emp in query)
                {
                    EmployeeStatus = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_status"]).Replace("_", "-");
                    //if (!Def_Eligible_Emp["EmployeeTypes_type"].ToString().ToLower().Equals("unspecified"))
                    //{
                    //    EmployeeStatus = EmployeeStatus + " " + Def_Eligible_Emp["EmployeeTypes_type"].ToString().Replace("_", "-");
                    //}
                    Working = Def_Eligible_Emp["EmployeeTypes_value"].ToString().Trim();
                    Frequency = Convert.ToString(Def_Eligible_Emp["EmployeeTypes_frequency"]).Replace("_", " ");
                    UOM = Def_Eligible_Emp["EmployeeTypes_unitOfMeasureSpecified"].ToString();
                }

            }

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                    {
                        myMergeField.Select();
                        if (EmployeeStatus != string.Empty)
                            oWordApp.Selection.TypeText(EmployeeStatus.Trim() + " " + EmployeeType.Trim() + " " + Working.Trim() + " " + UOM.Trim() + " " + Frequency.Trim());
                        else
                            myMergeField.Delete();
                        continue;
                    }

                    if (fieldName.Contains("Unmarried Child To Age"))
                    {
                        myMergeField.Select();
                        if (Defination_UnmarriedChildAge != string.Empty)
                            oWordApp.Selection.TypeText(Defination_UnmarriedChildAge);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Definition Of Domestic Partner"))
                    {
                        myMergeField.Select();
                        if (domesticPartner != string.Empty)
                            oWordApp.Selection.TypeText(domesticPartner);
                        else
                            myMergeField.Delete();
                        continue;
                    }
                    if (fieldName.Contains("Medical Plan Waiting Period"))
                    {
                        myMergeField.Select();
                        if (Medical_Waiting_Period != string.Empty)
                            oWordApp.Selection.TypeText(Medical_Waiting_Period);
                        else
                            myMergeField.Delete();
                        continue;

                    }
                }
            }


        }
    }
}
