﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;
using Microsoft.Office.Interop.Word;
using System.Drawing.Drawing2D;
using System.Drawing;
using StringTrimmer;
using System.Web.Resources;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate_WrapperEnrollmentSummary : System.Web.UI.Page
    {

        BPBusiness bp = new BPBusiness();
        ConstantValue cv = new ConstantValue();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();
        SummaryDetail sd = new SummaryDetail();
        string domesticPartner = string.Empty;
        string PlanSpecific = string.Empty;
        string Renewaldate = string.Empty;
        DataTable dtPlanContactInfo = new DataTable();
        Dictionary<string, List<int>> DictContactsPlanTypes = new Dictionary<string, List<int>>();
        private void BuiltDictContactsPlanTypes()
        {
            DictContactsPlanTypes.Clear();

            comFunObj.LoadPlanTypeIds();
            DictContactsPlanTypes.Add("Medical Insurance", new List<int> { 100, 110, 120, 130, 140, 150, 160, 170, 410, 233 });
            DictContactsPlanTypes.Add("Dental Insurance", new List<int> { 180, 190, 200, 210 });
            DictContactsPlanTypes.Add("Vision Benefits", new List<int> { 230 });

            comFunObj.LoadPlanTypeIds_Pilot();
            DictContactsPlanTypes.Add("Life and AD&D Insurance", new List<int> { 240 });
            DictContactsPlanTypes.Add("Group Term Life Insurance", new List<int> { 250 });
            DictContactsPlanTypes.Add("Accidental Death & Dismemberment Insurance", new List<int> { 270 });

            DictContactsPlanTypes.Add("Voluntary Life Insurance", new List<int> { 260 });
            DictContactsPlanTypes.Add("Voluntary AD&D Insurance", new List<int> { 280 });

            DictContactsPlanTypes.Add("Short Term Disability Insurance", new List<int> { 290 });
            DictContactsPlanTypes.Add("Long Term Disability Insurance", new List<int> { 300 });

            DictContactsPlanTypes.Add("Health Savings Account", new List<int> { 179 });
            DictContactsPlanTypes.Add("Health Reimbursement Account", new List<int> { 178 });

            DictContactsPlanTypes.Add("Flexible Spending Accounts", CommonFunctionsBS.FSAPlanTypeList);
            DictContactsPlanTypes.Add("Employee Assistance Program", CommonFunctionsBS.EAPPlanTypeList);

            DictContactsPlanTypes.Add("Stop Loss Insurance", new List<int> { 235 });

            DictContactsPlanTypes.Add("Patient Advocacy Program", new List<int> { ConstantValue.AdditionalProducts_Patient_Advocacy });
            DictContactsPlanTypes.Add("Telemedicine", new List<int> { ConstantValue.AdditionalProducts_Consumer_Driven_Telemedicine });
            DictContactsPlanTypes.Add("Wellness Plan", new List<int> { ConstantValue.AdditionalProducts_Wellness });
            DictContactsPlanTypes.Add("Accident Insurance", new List<int> { ConstantValue.AdditionalProducts_Accident });
            DictContactsPlanTypes.Add("Critical Illness Insurance", new List<int> { ConstantValue.AdditionalProducts_Voluntary_Critical_Illness });

            DictContactsPlanTypes.Add("401(k) Insurance", new List<int> { 340 });
            DictContactsPlanTypes.Add("Disability Insurance", new List<int> { 294, 293, 292 });
            DictContactsPlanTypes.Add("Business Travel Accident (BTA)", new List<int> { 320 });

            DictContactsPlanTypes.Add("Prescription Drug (Carve-Out)", new List<int> { 173 });

        }
        private DataTable AddColumnToPlanTable(DataTable PlanTable, string SessionId)
        {
            BuiltDictContactsPlanTypes();

            if (!PlanTable.Columns.Contains("contactPlanType"))
            {
                PlanTable.Columns.Add("contactPlanType", typeof(string));
            }

            foreach (DataRow row in PlanTable.Rows)
            {
                foreach (string plantype in DictContactsPlanTypes.Keys)
                {
                    if (DictContactsPlanTypes[plantype].Contains(Convert.ToInt32(row["ProductTypeId"])))
                    {
                        if (plantype == "Life and AD&D Insurance" && IsProductVoluntary(Convert.ToInt32(row["ProductId"]), SessionId))
                        {
                            row["contactPlanType"] = "Voluntary Life & AD&D Insurance";
                        }
                        else
                        {
                            row["contactPlanType"] = plantype;
                        }

                        break;
                    }
                }
            }
            if (!PlanTable.Columns.Contains("CarrierPlanType"))
            {
                PlanTable.Columns.Add("CarrierPlanType", typeof(string));
            } foreach (DataRow row in PlanTable.Rows)
            {
                row["CarrierPlanType"] = row["Carrier"] + " " + row["Name"];
            }
            return PlanTable;
        }
        private bool IsProductVoluntary(int ProductID, string SessionId)
        {
            bool IsVoluntary = false;
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            new_product = new BP_BrokerConnectV4.Product();
            new_product = new_connection.getProduct(ProductID);
            BP_BrokerConnectV4.CustomFieldValue[] CustomFieldValues = new_product.customFieldValues;
            if (CustomFieldValues != null && CustomFieldValues.Count() > 0)
            {
                foreach (BP_BrokerConnectV4.CustomFieldValue value in CustomFieldValues)
                {
                    if (value.customFieldID == 35484) //35484 fieldID for Voluntary
                    {
                        if (value.valueText != null && value.valueText.ToLower() == "yes")
                        {
                            IsVoluntary = true;
                        }
                    }
                }
            }
            return IsVoluntary;
        }
        #region Contact Information
        public void Write_ContactsToWapperEnrollmentSummary(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DropDownList ddlClient, DataTable dtPlanContactDetails, string SessionId, string selectedColor)
        {
            int rowCnt = 2;

            int k = 1;
            string carriername = "";
            string plantype = "";
            string ProductTypeDesc = "";

            string benefit_Summary_desp = string.Empty;
            string carrier = string.Empty;
            string Policy_no = string.Empty;
            string website_phone = string.Empty;
            string FirstMedRenewal = string.Empty;
            string FirstMedEffective = string.Empty;
            StringBuilder uniquePlans = new StringBuilder();

            Microsoft.Office.Interop.Word.Table table = oWordDoc.Tables[1];
            table.Range.Font.Color = comFunObj.font_color(selectedColor);
            table.Rows[1].Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedColor);
            table.Rows[1].Range.Font.Color = WdColor.wdColorWhite;
            table.Rows.Borders.InsideColor = comFunObj.border_color(selectedColor);
            table.Rows.Borders.OutsideColor = comFunObj.border_color(selectedColor);

            Dictionary<string, string> DistinctPlanTypes = new Dictionary<string, string>();
            DistinctPlanTypes.Clear();
            DataTable DistinctPlanTable = AddColumnToPlanTable(PlanTable, SessionId);
            #region Removing dulicate rows from table
            for (int rowindex = 0; rowindex < DistinctPlanTable.Rows.Count; rowindex++)
            {
                plantype = (DistinctPlanTable.Rows[rowindex]["CarrierPlanType"].ToString()).Replace(" ", string.Empty); ;
                if ((!DistinctPlanTypes.ContainsKey(plantype)) && plantype != "")
                {
                    DistinctPlanTypes.Add(plantype, plantype);
                }
                else
                {
                    DistinctPlanTable.Rows[rowindex].Delete();
                    rowindex--;
                }
            }
            #endregion

            for (int i = 0; i < DistinctPlanTable.Rows.Count; i++)
            {
                if (k > 1)
                {
                    table.Rows.Add(Type.Missing);
                }
                carriername = DistinctPlanTable.Rows[i]["Carrier"].ToString();
                // benefit_Summary_desp = DistinctPlanTable.Rows[i]["SummaryName"].ToString();
                Policy_no = Convert.ToString(DistinctPlanTable.Rows[i]["PolicyNumber"].ToString());
                //if (benefit_Summary_desp == "&nbsp;")
                //    benefit_Summary_desp = " ";
                if (Policy_no == "&nbsp;")
                    Policy_no = " ";
                //if (benefit_Summary_desp.Contains("amp;"))
                //    benefit_Summary_desp = benefit_Summary_desp.Replace("amp;", "");
                ///****************** WRTING IN TABLE ********************* 
                table.Cell(rowCnt, 1).Range.Text = Convert.ToString(carriername); //First Unique Carrier Name


                table.Cell(rowCnt, 2).Range.Text = Policy_no; //"\n" + benefit_Summary_desp;
                var planContactFirstName = (from n in dtPlanContactDetails.AsEnumerable()
                                            where n.Field<string>("ProductId") == Convert.ToString(DistinctPlanTable.Rows[i]["ProductId"])
                                            select n.Field<string>("Contact_FirstName")).FirstOrDefault();

                var planContactLastName = (from n in dtPlanContactDetails.AsEnumerable()
                                           where n.Field<string>("ProductId") == Convert.ToString(DistinctPlanTable.Rows[i]["ProductId"])
                                           select n.Field<string>("Contact_LastName")).FirstOrDefault();

                var planContactPhone = (from n in dtPlanContactDetails.AsEnumerable()
                                        where n.Field<string>("ProductId") == Convert.ToString(DistinctPlanTable.Rows[i]["ProductId"])
                                        select n.Field<string>("ContactPhoneNumber")).FirstOrDefault();

                table.Cell(rowCnt, 3).Range.Text = Convert.ToString(planContactFirstName) + "  " + Convert.ToString(planContactLastName) + "\n" + Convert.ToString(planContactPhone);

                k++;
                rowCnt++;

            }
        }
        #endregion
        #region Eligibility
        public void Write_CommonFieldToEnrollmentSummaryWrapper(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountTeamMemberDS, DataSet EligibilityDS, DropDownList ddlHRContact, List<Contact> ContactList, DataTable EmpTable, DataSet AccountDS, ArrayList arrAcctContact, DropDownList ddlClient, DataTable PlanTable, string selectedcolor)
        {
            try
            {

                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                string AccountAddress = string.Empty;
                string AccountPhoneNumber = string.Empty;
                string CompanyStatePincode = string.Empty;
                string CompanyPhone = string.Empty;
                string City = string.Empty;
                string State = string.Empty;
                string Zip = string.Empty;
                string Street1 = string.Empty;
                string Street2 = string.Empty;
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);

                if (oWordDoc.Bookmarks.Exists("Employee"))
                {
                    Bookmark bk = oWordDoc.Bookmarks["Employee"];
                    Range r = bk.Range;
                    r.Font.Color = wdColor_font;
                }

                foreach (Word.Shape shape in oWordDoc.Shapes)
                {
                    if (shape.Name == "Rectangle 7" || shape.Name == "Rectangle 7" || shape.Name == "Rectangle 9" || shape.Name == "Rectangle 1")
                    {
                        shape.Select();
                        shape.TextFrame.TextRange.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                        //ordApp.Selection.Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);

                    }
                }

                #region Header Footer Shape Color
                oWordDoc.Sections[1].Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Shapes[2].Select();
                oWordApp.Selection.Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);

                oWordDoc.Sections[1].Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Shapes[1].Select();
                oWordApp.Selection.Range.Shading.BackgroundPatternColor = comFunObj.textbox_color(selectedcolor);
                #endregion
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (EmpTable.Rows.Count > 0)
                {
                    Emp = EmpTable;
                }
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[0]["mainAddress_state"]);
                                State = State.Replace("_", " ");
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["individualAccountInfo_phone_number"])))
                            {
                                CompanyPhone = Convert.ToString(AccountDS.Tables[1].Rows[j]["individualAccountInfo_phone_number"]);
                            }

                        }
                    }
                }//AccountDS Close

                CompanyStatePincode = City + ", " + State + ", " + Zip;
                AccountAddress = Street1 + " " + Street2;

                #region AccountContactName
                string AccountContactname = string.Empty;
                if (ContactList != null)
                {
                    if (arrAcctContact.Count > 0)
                    {
                        for (int j = 0; j < arrAcctContact.Count; j++)
                        {
                            for (int i = 0; i < ContactList.Count; i++)
                            {
                                if (arrAcctContact[j].ToString() == Convert.ToString(ContactList[i].ContactId))
                                {
                                    if (ContactList[i].Name != null)
                                    {
                                        AccountContactname = ContactList[i].Name;
                                    }
                                    else
                                    {
                                        AccountContactname = " ";
                                    }
                                    if (ContactList[i].Phone.Count > 0)
                                    {
                                        AccountPhoneNumber = Convert.ToString(ContactList[i].Phone[0]);
                                    }
                                    else
                                    {
                                        AccountPhoneNumber = " ";
                                    }

                                }
                            }
                        }
                    }
                }
                #endregion

                for (int i = 0; i < PlanTable.Rows.Count; i++)
                {
                    if (PlanTable.Rows[i]["contactPlanType"].ToString() == "Medical Insurance")
                    {
                        Renewaldate = PlanTable.Rows[i]["Effective"].ToString();

                        break;

                    }
                }
                string year = Convert.ToString(DateTime.Parse(Renewaldate, new System.Globalization.CultureInfo("en-US")).Year);
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;
                    Word.Range rngFieldCode = myMergeField.Code;
                    string fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;
                        string fieldName = fieldText.Substring(11, endMerge - 11);
                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("First Medical Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(year);
                            continue;
                        }
                        if (fieldName.Contains("Plan Year"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Plan Year");
                            continue;
                        }
                        if (fieldName.Contains("First_Medical_Date"))
                        {
                            myMergeField.Select();
                            DateTime renewdate = Convert.ToDateTime(Renewaldate);
                            oWordApp.Selection.TypeText((renewdate.ToString("M").Replace(" 0", " ").ToString() + ", " + renewdate.Year.ToString()).Trim());
                            continue;

                        }

                        if (fieldName.Contains("ClientName"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Text))
                            {
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");

                            }
                            continue;
                        }
                        if (fieldName.Contains("First_Client_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(ddlClient.SelectedItem.Text))
                            {
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");

                            }
                            continue;
                        }
                        if (fieldName.Contains("AccountContact_Name"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountContactname))
                            {
                                oWordApp.Selection.TypeText(AccountContactname);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");

                            }
                            continue;
                        }
                        if (fieldName.Contains("Account Phone Number"))
                        {
                            myMergeField.Select();

                            oWordApp.Selection.TypeText(AccountPhoneNumber);


                            continue;
                        }
                        if (Emp.Rows.Count > 0)
                        {
                            if (fieldName.Contains("EmployeeStatus"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText((Emp.Rows[0]["VALUE"].ToString().Trim()).ToLower());
                                continue;
                            }

                            if (fieldName.Contains("Frequency_Eligibility"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText((Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim()).ToLower());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText((Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim()).ToLower());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("EmployeeStatus"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("Working"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }

                            if (fieldName.Contains("Frequency"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                            if (fieldName.Contains("unitofmeasure"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }

                        if (fieldName.Contains("medicalplanwaitingperiod"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (!string.IsNullOrEmpty(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().Trim()))
                                {
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["item"].ToString().ToLower().Trim());
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("unmarriedchildtoage"))
                        {
                            myMergeField.Select();
                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                            {
                                if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim() == "")
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                else
                                    oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[0]["employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit"].ToString().Trim());
                                continue;
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                        }
                        /*******COMPANY DETAILS */
                        //Company_Address

                        if (fieldName.Contains("Company_Address"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(AccountAddress))
                            {
                                oWordApp.Selection.TypeText(AccountAddress);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        //CompanyCity_StateZipCode
                        if (fieldName.Contains("CompanyCity_StateZipCode"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(CompanyStatePincode))
                            {
                                oWordApp.Selection.TypeText(CompanyStatePincode);
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        //CompanyPhoneNum

                        if (fieldName.Contains("companyPhNumber"))
                        {
                            myMergeField.Select();
                            if (!string.IsNullOrEmpty(CompanyPhone))
                                oWordApp.Selection.TypeText(CompanyPhone);
                            else
                                oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Contains("EMPLOYEE BENEFITS ENROLLMENT GUIDE"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("EMPLOYEE BENEFITS ENROLLMENT GUIDE");
                            continue;
                        }
                        if (fieldName.Contains("Employee Benefits Open Enrollment"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Employee Benefits Open Enrollment");
                            continue;
                        }

                        if (fieldName.Contains("What is Open Enrollment?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("What is Open Enrollment?");
                            continue;
                        }
                        //if (fieldName.Contains("What is Open Enrollment?1"))
                        //{
                        //    myMergeField.Select();
                        //    oWordApp.Selection.Range.Font.Color = wdColor_font;
                        //    oWordApp.Selection.TypeText("What is Open Enrollment?");
                        //}
                        if (fieldName.Contains("Eligibility"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Eligibility");
                            continue;
                        }
                        if (fieldName.Contains("The Deadline to Enroll is"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("The Deadline to Enroll is");
                            continue;
                        }
                        if (fieldName.Contains("add applicable date"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("add applicable date");
                            continue;
                        }
                        if (fieldName.Contains("Family Status Change Events"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Family Status Change Events");
                            continue;
                        }
                        if (fieldName.Contains("Disclaimer"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Disclaimer");
                            continue;
                        }
                        if (fieldName.Contains("Contact Information"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Contact Information");
                            continue;
                        }
                        if (fieldName.Contains("Have Questions?  Need Help?"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText("Have Questions?  Need Help?");
                            continue;
                        }



                    }
                }

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                //Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
        #region Brc Section
        public void Write_BRCToEnrollmentSummaryWrapper(Word.Document oWordDoc, Word.Application oWordApp, List<BRCData> BRCList, string selectedcolor)
        {
            int BRCindex = 0;

            Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
            #region MergeField

            int iTotalFields = 0;

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");
                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("BRCEmail"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCEmail != string.Empty)
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail);
                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                    if (fieldName.Contains("BRCDayHour"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCPhone != string.Empty)
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours);

                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                    if (fieldName.Contains("BRCPhone"))
                    {
                        myMergeField.Select();
                        if (BRCList[BRCindex].BRCPhone != string.Empty)
                            oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone);

                        else
                            oWordApp.Selection.TypeText(" ");
                        continue;
                    }
                }
            }
            #endregion
        }
        #endregion
        #region Delete Individual Bookmark
        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark1)
        {

            if (oWordDoc.Bookmarks.Exists(bookmark1))
            {
                oWordDoc.Bookmarks[bookmark1].Range.Delete();
            }

        }
        #endregion
        #region Notice Section
        public void WriteNoticeSectionToWapperEnrollmentSummary(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, string selectedcolor, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                Word.WdColor wdColor_font = comFunObj.font_color(selectedcolor);
                int iTotalFields = 0;
                int index = -1;
                bool flag = false;
                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                if (ddlChipNotice.SelectedIndex >= 1 && ddlAnnualLegalNotice.SelectedIndex == 0)
                {
                    flag = true;
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotices"))
                        {
                            if (ddlChipNotice.SelectedIndex >= 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("CHIP NOTICE");
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }
                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else if (ddlChipNotice.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                if (flag == false)
                                {
                                    r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                }
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice_Spanish.doc"), missing, true, missing, missing);
                                continue;
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            //Adde by Vaibhav forspanish template
                            else if (ddlMarketplaceCoverage.SelectedIndex == 2)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/EnrollmentSummary/13 - Notice of Coverage Options-Spanish.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("LegalChipCommon"))
                        {
                            myMergeField.Select();
                            oWordApp.Selection.Range.Font.Color = wdColor_font;
                            oWordApp.Selection.TypeText(" ");
                            continue;
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                oWordApp.Selection.Range.Font.Color = wdColor_font;
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 3, rngFieldCode.End);
                                comFunObj.NoticesFunction_EnrollmentSummaryOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion

                iTotalFields = 0;

                /******************* Call common function to write the contact information page fields ****************************/
                comFunObj.WriteFieldsForContactInformationNotice_V2(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), ddlCreditableCoverage.SelectedValue, chkAnualNotice, true, selectedcolor);

                /********************HERE WE DELETE THE LEGAL NOTICE SECTION IF NOT SELECTED ...**/
                if (ddlAnnualLegalNotice.SelectedValue == "Not Included")
                {
                    DeleteIndivialBookmark(oWordDoc, "LegalNoticeSectionBayView");
                }


            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        #endregion
    }
}