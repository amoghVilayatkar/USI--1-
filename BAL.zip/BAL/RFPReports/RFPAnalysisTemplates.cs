﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.RFPReports
{
    public class RFPAnalysisTemplates
    {
        List<string> DentalBenefitColumnIdOutNetworkList = new List<string>();
        List<string> DentalBenefitColumnIdList = new List<string>();
        List<string> VisionBenefitColumnIdOutNetworkList = new List<string>();
        List<string> VisionBenefitColumnIdList = new List<string>();
        List<string> STDBenefitColumnIdList = new List<string>();
        List<string> EAPBenefitColumnIdList = new List<string>();
        public RFPAnalysisTemplates()
        {
            //Outnetwok Dental 
            DentalBenefitColumnIdOutNetworkList.Add("117");
            //Dental      
            DentalBenefitColumnIdList.Add("115");
            DentalBenefitColumnIdList.Add("116");
            DentalBenefitColumnIdList.Add("118");
            DentalBenefitColumnIdList.Add("121");
            //Vision
            VisionBenefitColumnIdList.Add("123");
            //Outnetwok Vision
            VisionBenefitColumnIdOutNetworkList.Add("124");
            //STD
            STDBenefitColumnIdList.Add("131");
            //EAP
            EAPBenefitColumnIdList.Add("133");
        }
    }


}