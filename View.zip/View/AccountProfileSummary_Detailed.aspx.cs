﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BPTimeLine;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Data;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using BenefitPointSummaryPortal.Common.Tools;
using System.Collections;
using BenefitPointSummaryPortal.Common.BPTimeLine;
using BenefitPointSummaryPortal.BAL.Tools;

namespace BenefitPointSummaryPortal.View
{
    public partial class AccountProfileSummary_Detailed : System.Web.UI.Page
    {
        #region Global Variable
        BPBusiness bp = new BPBusiness();
        Timeline_Constant tc = new Timeline_Constant();
        string SessionId = "";
        private static string Activity = "";
        private static string Activity_Group = "";
        string temperror = "cs";
        CommonFunctionsBS objCommFun = new CommonFunctionsBS();
        string Account_Office = string.Empty;
        string Account_Region = string.Empty;
        DataSet ProductDS = new DataSet();
        DataSet BenefitStructureDS = new DataSet();
        DataSet RateDS = new DataSet();
        DataSet ContributionDS = new DataSet();
        DataSet BenefitDS = new DataSet();
        ConstantValue cv = new ConstantValue();

        ArrayList MedicalBenefitColumnIdList = new ArrayList();
        ArrayList DentalBenefitColumnIdList = new ArrayList();
        ArrayList MedicalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList MedicalBenefitColumnId_Tier3 = new ArrayList();
        ArrayList DentalBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList VisionBenefitColumnIdList = new ArrayList();
        ArrayList VisionBenefitColumnIdOutNetworkList = new ArrayList();
        ArrayList EAPBenefitColumnIdList = new ArrayList();
        ArrayList HSABenefitColumnIdList = new ArrayList();
        ArrayList HRABenefitColumnIdList = new ArrayList();
        ArrayList FSABenefitColumnIdList = new ArrayList();
        ArrayList STDBenefitColumnIdList = new ArrayList();
        ArrayList LTDBenefitColumnIdList = new ArrayList();
        ArrayList LifeADDBenefitColumnIdList = new ArrayList();
        ArrayList GroupTermLifeBenefitColumnIdList = new ArrayList();
        ArrayList ADDBenefitColumnIdList = new ArrayList();
        ArrayList WellnessBenefitColumnIdList = new ArrayList();
        ArrayList VoluntaryLifeBenefitColumnIdList = new ArrayList();
        //Added For New Development Account Profile Details 
        ArrayList DisabilityBenefitColumnIdList = new ArrayList();
        ArrayList AccidentalBenefitColumnIdList = new ArrayList();
        ArrayList AdditionalProductsBenefitColumnIdList = new ArrayList();
        ArrayList StopLossBenefitColumnIdList = new ArrayList();
        ArrayList PrescriptionDrugBenefitColumnIdList = new ArrayList();

        //********** THIS IS MEDICAL PRODUCT FOR WHICH WE HIDE /SHOW RATE, CONTRIBUTION,ELIGIBILITY DROPDOWN
        List<int> medicalProductTypeId = new List<int>() { 173, 235, 410 };
        public static Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
        public static Dictionary<string, string> DicActivityLog = new Dictionary<string, string>();

        SummaryDetail sdd = new SummaryDetail();

        #endregion

        static DataTable PlanInfoTable = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                div_footer.Controls.Add(objCommFun.Writer_FooterText_ForAllPages());
                DictDepartment = sdd.getDepartmentDetails();
                if (!IsPostBack)
                {
                    //Homelink.HRef = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HomePageLink"]);
                    objCommFun.GetUserDetails();

                    // Get the QueryString name from the "ReportName" parameter and compare it with the particular report name to run the code for specific report
                    if (Request.QueryString["ReportName"] != null)
                    {
                        Session["Summary"] = Request.QueryString["ReportName"];
                    }

                    if (Session["Summary"] == null)
                    {
                        Response.Redirect("Home.aspx");
                    }

                    SessionBPSummaryLogin sl = new SessionBPSummaryLogin();
                    SessionId = sl.GetSessionID_BPSummaryWebServiceLogin();
                    Session["SessionId"] = SessionId;
                    if (Convert.ToString(Session["Summary"]) == "Tools1")
                    {
                        //lblHeading.Text = "5500 Worksheet";
                    }

                    if (Convert.ToString(Session["Summary"]) == "Tools2")
                    {
                        TitleSpan.InnerText = "Account Profile";
                        SpanClientIntake.Visible = false;
                        SpanAccountProfile.Visible = true;
                        SpanClientIntakePHM.Visible = false;
                        mvAccountProfile.ActiveViewIndex = 0;
                        SpanClientIntakeComplaince.Visible = false;
                        trddlprimaryAccountContact.Visible = false;
                        hdnSummary.Value = "Tools2";
                        ////btnNext.Visible = false;
                        ////btnPrevious.Visible = false;
                        divBtnPrevious.Style.Add("Display", "none");
                        divBtnNext.Style.Add("Display", "none");
                        ////divBtnSummary.Style.Add("Display", "block");

                    }
                    #region Old Tools-2 Page Code which no longer needed

                    ////if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm")
                    ////{
                    ////    TitleSpan.InnerText = "Client Intake Form";
                    ////    //ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>ReplaceAuditReportToClientIntakes()</script>", false);
                    ////    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>ReplaceAuditReportToClientIntake()</script>", false);

                    ////    SpanClientIntake.Visible = true;
                    ////    SpanAccountProfile.Visible = false;
                    ////    SpanClientIntakePHM.Visible = false;

                    ////    SpanClientIntakeComplaince.Visible = false;
                    ////    trddlprimaryAccountContact.Visible = true;
                    ////    hdnSummary.Value = "ClientIntakeForm";
                    ////    Activity_Group = "Tools";
                    ////}
                    ////if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                    ////{
                    ////    TitleSpan.InnerText = "Client Intake Form – Compliance";
                    ////    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAccountProfileToClientIntakeComp", "<script>ReplaceAccountProfileToClientIntakeComp()</script>", false);

                    ////    SpanClientIntake.Visible = false;
                    ////    SpanAccountProfile.Visible = false;
                    ////    trddlprimaryAccountContact.Visible = true;
                    ////    SpanClientIntakeComplaince.Visible = true;
                    ////    SpanClientIntakePHM.Visible = false;

                    ////    hdnSummary.Value = "ClientIntakeFormCompliance";
                    ////    Activity_Group = "Complaince";
                    ////}
                    ////if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                    ////{
                    ////    TitleSpan.InnerText = "Client Intake Form – PHM";
                    ////    ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAccountProfileToClientIntakeComp", "<script>ReplaceAccountProfileToClientIntakeComp()</script>", false);

                    ////    SpanClientIntake.Visible = false;
                    ////    SpanAccountProfile.Visible = false;
                    ////    trddlprimaryAccountContact.Visible = true;
                    ////    SpanClientIntakeComplaince.Visible = false;
                    ////    SpanClientIntakePHM.Visible = true;

                    ////    hdnSummary.Value = "ClientIntakeFormPHM";
                    ////    Activity_Group = "Tools";
                    ////    grdPlans.Columns[9].Visible = true;
                    ////}
                    #endregion
                    txtsearch.Focus();
                    Activity_Group = "Tools";
                    Activity = TitleSpan.InnerText;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                //ddlActivity.Items.Clear();
                grdPlans.DataSource = null;
                grdPlans.DataBind();
                pnlPlans.Visible = false;
                // rdlActivity.SelectedIndex = 0;
                BPBusiness bp = new BPBusiness();
                List<Account> AccountList = new List<Account>();
                SessionId = Session["SessionId"].ToString();
                AccountList = bp.FindAccounts(rdlClient.SelectedIndex, SessionId, txtsearch.Text);
                AccountList = AccountList.OrderBy(o => o.AccountName).ToList();
                ddlClient.DataSource = AccountList;
                ddlClient.DataBind();
                ddlClient.Items.Insert(0, new ListItem("Select", string.Empty));
                ddlLayout.SelectedIndex = 0;
                cblistAccountContact.Items.Clear();
                Clear();
                ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>ddlLayout_changed(" + ddlLayout.SelectedIndex + ")</script>", false);
                //divBtnNext.Style.Add("display", "none");
                //divBtnSummary.Style.Add("display", "block");
                //divBtnPrevious.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                pnlPlans.Visible = false;
                rdlClient.SelectedIndex = 0;
                txtsearch.Text = "";
                BPBusiness bp = new BPBusiness();

                SessionId = Session["SessionId"].ToString();

                ddlClient.Items.Clear();
                //ddlActivity.Items.Clear();
                // rdlActivity.SelectedIndex = 0;

                grdPlans.DataSource = null;
                grdPlans.DataBind();

                Session["ProductSummaryTable"] = null;
                Session["PlanTable"] = null;
                Session["AdditionalProductTable"] = null;

                cblistAccountContact.Items.Clear();
                Clear();
                ScriptManager.RegisterStartupScript(Page, GetType(), "ReplaceAuditReportToClientIntake", "<script>ddlLayout_changed(" + ddlLayout.SelectedIndex + ")</script>", false);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlActivity.Items.Clear();
            pnlPlans.Visible = false;
            if (Convert.ToString(Session["Summary"]) == "Tools2" || Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
            {
                Clear(true);
                lblMessage.Visible = false;
                cblistAccountContact.Items.Clear();
                SessionId = Session["SessionId"].ToString();
                List<Contact> acctContact = new List<Contact>();
                List<Contact> ContactList = new List<Contact>();
                Contact cont = new Contact();
                if (ddlClient.SelectedValue != "")
                {
                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                }

                ContactList = ContactList.OrderBy(o => o.Last_Name).ToList();
                if (ContactList != null)
                {
                    for (int i = 0; i < ContactList.Count; i++)
                    {
                        cont = new Contact();
                        cont.ContactId = ContactList[i].ContactId;

                        if (!string.IsNullOrEmpty(ContactList[i].Title))
                        {
                            cont.Name = ContactList[i].Name + " & " + ContactList[i].Title;
                        }
                        else
                        {
                            cont.Name = ContactList[i].Name;
                        }

                        acctContact.Add(cont);
                    }
                }

                lblAccountContact.Visible = true;
                pnlChkAccountContact.Visible = true;
                ////if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                ////{
                ////    divgrdSelectedAccountContact.Visible = true;
                ////}
                ////else
                ////{
                ////    divgrdSelectedAccountContact.Visible = false;

                ////}
                if (acctContact.Count > 0)
                {
                    cblistAccountContact.DataSource = acctContact;
                    cblistAccountContact.DataBind();
                    pnlChkAccountContact.Height = 130;
                }
                else
                {
                    lblMessage.Visible = true;
                    pnlChkAccountContact.Height = 50;
                }
            }

        }

        //protected void rdlActivity_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    SummaryDetail.isClientChanged_ForMedical = true;
        //    if (ddlActivity.SelectedIndex >= 0)
        //    {
        //        ddlActivity.SelectedIndex = 0;
        //        ddlActivity.Items.Clear();
        //        if (Convert.ToString(Session["Summary"]) == "Tools1")
        //        {
        //            GetActivity_List(rdlActivity.SelectedItem.Text, tc.Tools1_SubjectID);
        //        }
        //    }
        //}

        //private void GetActivity_List(string rdlValue, int SubjectID)
        //{
        //    bool isActivityPresent = false;
        //    try
        //    {
        //        BPBusiness bp = new BPBusiness();
        //        TimelineDetail timeD = new TimelineDetail();
        //        DataTable ActivityTable = new DataTable();
        //        string ActivityName = string.Empty;
        //        string ActivityID = string.Empty;
        //        SessionId = Session["SessionId"].ToString();
        //        int rowIndex = 1;
        //        //Clear();

        //        if (ddlClient.SelectedIndex == 0)
        //        {
        //            ddlActivity.Items.Clear();
        //        }
        //        else
        //        {
        //            ActivityTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
        //            Session["ActivityTable"] = ActivityTable;

        //            if (ActivityTable.Rows.Count > 0)
        //            {
        //                ddlActivity.Items.Insert(0, new ListItem("Select", string.Empty));
        //                for (int i = 0; i < ActivityTable.Rows.Count; i++)
        //                {
        //                    if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["recordID"])))
        //                    {
        //                        ActivityID = Convert.ToString(ActivityTable.Rows[i]["recordID"]);
        //                    }

        //                    if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["subject"])))
        //                    {
        //                        ActivityName = Convert.ToString(ActivityTable.Rows[i]["subject"]);
        //                    }
        //                    //-- Do not delete code starts here --------------------------------------------------
        //                    ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["name"])))
        //                    ////{
        //                    ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["name"]);
        //                    ////}

        //                    ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["createdon"])))
        //                    ////{
        //                    ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["createdon"]);
        //                    ////}

        //                    ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["dueon"])))
        //                    ////{
        //                    ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["dueon"]);
        //                    ////}

        //                    ////if (!string.IsNullOrEmpty(Convert.ToString(ActivityTable.Rows[i]["status"])))
        //                    ////{
        //                    ////    ActivityName = ActivityName + "|" + Convert.ToString(ActivityTable.Rows[i]["status"]);
        //                    ////}
        //                    //-- Do not delete code ends here --------------------------------------------------

        //                    if (rdlValue == "Open" && Convert.ToString(ActivityTable.Rows[i]["status"]).Trim().ToLower() == "open")
        //                    {
        //                        ddlActivity.Items.Insert(rowIndex, new ListItem(ActivityName, ActivityID));
        //                        rowIndex++;
        //                    }
        //                    else if (rdlValue == "All")
        //                    {
        //                        ddlActivity.Items.Insert(i + 1, new ListItem(ActivityName, ActivityID));
        //                    }
        //                }
        //                isActivityPresent = true;
        //            }
        //        }

        //        if (isActivityPresent == false)
        //        {
        //            if (ddlClient.SelectedItem.Text != "Select")
        //            {
        //                string script = "alert(\"There is no Activity available for the Client '" + ddlClient.SelectedItem.Text + "'.\");";
        //                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //}

        protected void btnSummary_Click(object sender, EventArgs e)
        {
            try
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlDisability.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;

                Session["PlanTable"] = null;
                Session["AdditionalProductTable"] = null;
                TimelineDetail timeD = new TimelineDetail();
                SessionId = Session["SessionId"].ToString();
                bool flag = true;
                DataTable PlanInfoTable = new DataTable();


                if (Convert.ToString(Session["Summary"]) == "Tools2")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                        flag = false;
                    }
                    else
                    {
                        flag = CheckAccountContactsSelected();
                    }
                }


                if (flag == true)
                {
                    List<Contact> ContactList = new List<Contact>();
                    SummaryDetail sd = new SummaryDetail();
                    DataSet AccountDS = new DataSet();
                    DataSet AccountTeamMemberDS = new DataSet();
                    string mynewfile = "";
                    int engagement = 0;
                    bool flagCheckValidation = true;

                    sd.BuildAccountTable();
                    ////******************** Added by Amogh to load EmployeeType Table 
                    sd.BuildEmployeeTypesTable();
                    ///*********************************************
                    sd.BuildBenefitSummaryTable();
                    sd.BuildBenifitSummaryStructureTable();
                    sd.BuildContributionTable();
                    sd.BuildEligibilityRuleTable();
                    sd.BuildProductTable();
                    //sd.BuildRateTable();

                    //DataTable PlanTable1 = new DataTable();
                    //PlanTable1 = (DataTable)Session["PlanTable"];
                    //ContributionDS = sd.GetContribution(PlanTable1, SessionId);

                    /********************THIS METHOD CALL COMMNETED BY AMOGH *******************************/
                    /////AccountDS = sd.GetAccountDetail(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    /*************************************/

                    AccountDS = sd.GetAccountDetail_AccountProfileSummeryDetails(Convert.ToInt32(ddlClient.SelectedValue), SessionId);

                    ContactList = bp.FindContacts(ddlClient.SelectedValue, SessionId);
                    if (ddlClient.SelectedValue != "")
                    {
                        AccountTeamMemberDS = sd.GetTeamMembers(Convert.ToInt32(ddlClient.SelectedValue), SessionId);
                    }
                    // Get the Account Office and Account Region for the selected client
                    Account_Office = objCommFun.GetOfficeAndRegionNames(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, out Account_Region);


                    //string Office_Region = Account_Region;
                    string Office_Region = Account_Region + " / " + Account_Office;
                    //code used for contract review and benchmark audit report
                    #region common for both
                    if (Convert.ToString(Session["Summary"]) == "Tools2")
                    {
                        if (ddlLayout.SelectedIndex == 1)
                        {
                            PlanInfoTable = GetPlanInfoTable_Summary();
                        }

                    }


                    DataTable PlanTable = new DataTable();
                    PlanTable.Merge(PlanInfoTable);

                    //RateDS = sd.GetRateForTools(PlanTable, SessionId);
                    //ContributionDS = sd.GetContributionForTool(PlanTable, SessionId);
                    //var table = from x in PlanInfoTable.AsEnumerable() where !string.IsNullOrEmpty(x.Field<string>("PlanType")) select x;

                    //PlanTable.Clear();
                    //foreach (dynamic i in table)
                    //{
                    //    PlanTable.NewRow();
                    //    PlanTable.ImportRow(i);
                    //}

                    //ProductDS = sd.GetProductDetail(PlanTable, SessionId);


                    //DataTable ProductType = new DataTable();
                    //ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    //ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    //ProductType.Columns.Add("PlanNumber", typeof(string));
                    //ProductType.Columns.Add("ProductId", typeof(Int32));
                    //DataRow[] foundrow = null;

                    //for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                    //{
                    //    ProductType.Rows.Add();
                    //    ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);

                    //    foundrow = PlanTable.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                    //    ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                    //    ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                    //    ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);
                    //}

                    //BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);

                    #endregion


                    //code used for selected primary contact
                    #region selected primary contact

                    DataTable dtNewAcctContactList = new DataTable();
                    dtNewAcctContactList.Columns.Add("Name", typeof(string));
                    dtNewAcctContactList.Columns.Add("ID", typeof(string));
                    dtNewAcctContactList.Columns.Add("PrimaryContact", typeof(string));
                    string ID = string.Empty;
                    string Name = string.Empty;
                    string primary = string.Empty;

                    DataTable ProductType = new DataTable();
                    ProductType.Columns.Add("ProductTypeId", typeof(Int32));
                    ProductType.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductType.Columns.Add("PlanNumber", typeof(string));
                    ProductType.Columns.Add("ProductId", typeof(Int32));//need to confirm ,column added for tools
                    DataRow[] foundrow = null;



                    for (int i = 0; i < ddlSelectedAccountContact.Items.Count; i++)
                    {
                        if (ddlSelectedAccountContact.Items[i].Selected == true)
                        {
                            primary = "1";

                        }
                        else
                        {
                            primary = "2";
                        }
                        Name = ddlSelectedAccountContact.Items[i].Text;
                        ID = ddlSelectedAccountContact.Items[i].Value;
                        dtNewAcctContactList.Rows.Add(Name, ID, primary);
                    }

                    #endregion


                    if (Convert.ToString(Session["Summary"]) == "Tools2")
                    {
                        PlanInfoTable = GetPlanInfoTable_Summary();

                        if (ddlLayout.SelectedIndex == 1)    /**************THIS SECTION FOR OLD ACCOUNT PROFILE REPORT *************/
                        {
                            if (PlanInfoTable.Rows.Count > 0)
                            {
                                mynewfile = CreateTools2(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId);
                            }
                            else
                            {
                                if (grdPlans.Rows.Count > 0)
                                {
                                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                                divBtnNext.Style.Add("display", "none");
                                divBtnSummary.Style.Add("display", "block");
                                divBtnPrevious.Style.Add("display", "none");
                                return;
                            }
                        }
                        else if (ddlLayout.SelectedIndex == 2) /**************THIS SECTION FOR NEW ACCOUNT PROFILE - DETAILS REPORT *************/
                        {
                            CreatePlanTable();
                            DataTable PlanTableDetails = new DataTable();
                            PlanTableDetails = (DataTable)Session["PlanTable"];
                            DataTable AdditionalProductTableDetails = new DataTable();
                           // AdditionalProductTableDetails = (DataTable)Session["AdditionalProductTable"];
                            //Added by - Aatrey
                            AdditionalProductTableDetails = GetAddtionalProductDetail();


                            ProductDS = sd.GetProductDetail(PlanTableDetails, SessionId);
                            BenefitDS = sd.GetBenefitSummary(PlanTableDetails, SessionId);

                            for (int i = 0; i < ProductDS.Tables["ProductTable"].Rows.Count; i++)
                            {
                                ProductType.Rows.Add();
                                ProductType.Rows[i][0] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["productTypeID"]);

                                foundrow = PlanTableDetails.Select("ProductId='" + ProductDS.Tables["ProductTable"].Rows[i]["ProductID"] + "'");

                                ProductType.Rows[i][1] = foundrow[0]["PlanType"];
                                ProductType.Rows[i][2] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["PlanNumber"]);
                                ProductType.Rows[i][3] = Convert.ToString(ProductDS.Tables["ProductTable"].Rows[i]["ProductId"]);//need to confirm ,column added for tools
                            }

                            BenefitStructureDS = sd.GetBenefitSummaryStructure(ProductType, SessionId);
                            RateDS = sd.GetRateForTools(PlanTableDetails, SessionId);
                            ContributionDS = sd.GetContribution(PlanTableDetails, SessionId);


                            if (MedicalValidation() && PrescriptionDrugValidation() && StopLossValidation() && DentalValidation() && VisionValidation() && STDValidation() && LTDValidation() && LifeADnDValidation() && EAPValidation() && FSAValidation() && HRAValidation() && HSAValidation() && VoluntaryLifeADnDValidation() && DisabilityValidation() && AccidentValidation() && WellNessValidation() ) //&& AdditionalValidation()
                            {
                                // Check for if the dropdown list contains duplicate selection or not
                                for (int i = 0; i < PlanTableDetails.Rows.Count; i++)
                                {
                                    if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.MedicalLOC || Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.DentalLOC || Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.VisionLOC)
                                    {
                                        if (PlanTableDetails.Rows[i]["ContributionId"].ToString() != "-1" && PlanTableDetails.Rows[i]["ContributionId_2"].ToString() != "-1")
                                        {
                                            if (int.Parse(PlanTableDetails.Rows[i]["ContributionId"].ToString()) == int.Parse(PlanTableDetails.Rows[i]["ContributionId_2"].ToString()))
                                            {
                                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate Contribution for " + PlanTableDetails.Rows[i]["ProductName"].ToString() + " Plan. Please Select different Contribution.')</script>", false);
                                                Session["PlanTable"] = null;
                                                Session["AdditionalProductTable"] = null;
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.MedicalLOC)
                                                {
                                                    pnlMedical.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.DentalLOC)
                                                {
                                                    pnlDental.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.VisionLOC)
                                                {
                                                    pnlVision.Visible = true;
                                                }
                                                flagCheckValidation = false;
                                                break;
                                            }//Inner If Close
                                        }//OuterIf
                                    }
                                    for (int j = 0; j < PlanTableDetails.Rows.Count; j++)
                                    {
                                        if (i == j)
                                        {
                                            continue;
                                        }
                                        else
                                        {

                                            if (int.Parse(PlanTableDetails.Rows[i]["ProductId"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["ProductId"].ToString()) && int.Parse(PlanTableDetails.Rows[i]["SummaryId"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["SummaryId"].ToString()) && int.Parse(PlanTableDetails.Rows[i]["ContributionId"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["ContributionId"].ToString()) && int.Parse(PlanTableDetails.Rows[i]["ContributionId_2"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["ContributionId_2"].ToString()) && int.Parse(PlanTableDetails.Rows[i]["RateId"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["RateId"].ToString()) && int.Parse(PlanTableDetails.Rows[i]["EligibilityId"].ToString()) == int.Parse(PlanTableDetails.Rows[j]["EligibilityId"].ToString()))
                                            {
                                                if (int.Parse(PlanTableDetails.Rows[i]["ContributionId"].ToString()) == int.Parse(PlanTableDetails.Rows[i]["ContributionId_2"].ToString()))
                                                { }
                                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate " + PlanTableDetails.Rows[i]["PlanType"].ToString() + " Plan. Please Select different " + PlanTableDetails.Rows[i]["PlanType"].ToString() + " Plan.')</script>", false);
                                                Session["PlanTable"] = null;
                                                Session["AdditionalProductTable"] = null;
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.MedicalLOC)
                                                {
                                                    pnlMedical.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.DentalLOC)
                                                {
                                                    pnlDental.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.VisionLOC)
                                                {
                                                    pnlVision.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.LifeADDLOC)
                                                {
                                                    pnlLifeADND.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.LTDPlanType_CommonCriteria)
                                                {
                                                    pnlLTD.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.STDPlanType_CommonCriteria)
                                                {
                                                    pnlSTD.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.VoluntaryLifeADDLOC)
                                                {
                                                    pnlVoluntaryLife.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.HSAPlanType_CommonCriteria)
                                                {
                                                    pnlHSA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.HRAPlanType_CommonCriteria)
                                                {
                                                    pnlHRA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.FSAPlanType_CommonCriteria)
                                                {
                                                    pnlFSA.Visible = true;
                                                }
                                                else if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.EAPPlanType_CommonCriteria)
                                                {
                                                    pnlEAP.Visible = true;
                                                }
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.Disability)
                                                {
                                                    pnlDisability.Visible = true;
                                                }
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.Accident)
                                                {
                                                    pnlAccidental.Visible = true;
                                                }
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.Wellness)
                                                {
                                                    pnlWelness.Visible = true;
                                                }
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.StopLoss)
                                                {
                                                    pnlStopLoss.Visible = true;
                                                }
                                                if (Convert.ToString(PlanTableDetails.Rows[i]["PlanType"]) == cv.PrescriptionDrug)
                                                {
                                                    pnlPrescriptionLoss.Visible = true;
                                                }
                                                flagCheckValidation = false;
                                            }
                                        }
                                    }

                                }//forLoopclose


                                ////Validation Check duplicate Product for Additional Product 
                                //for (int i = 0; i < AdditionalProductTableDetails.Rows.Count; i++)
                                //{
                                //    for (int j = 0; j < AdditionalProductTableDetails.Rows.Count; j++)
                                //    {
                                //        if (i == j)
                                //        {
                                //            continue;
                                //        }
                                //        else
                                //        {
                                //            if (int.Parse(AdditionalProductTableDetails.Rows[i]["ProductId"].ToString()) == int.Parse(AdditionalProductTableDetails.Rows[j]["ProductId"].ToString()))
                                //            {
                                //                if (Convert.ToString(AdditionalProductTableDetails.Rows[i]["PlanType"]) == cv.AdditionalProducts)
                                //                {
                                //                    pnlAdditional.Visible = true;
                                //                    flagCheckValidation = false;
                                //                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('There is Duplicate " + AdditionalProductTableDetails.Rows[i]["PlanType"].ToString() + " Plan. Please Select different " + AdditionalProductTableDetails.Rows[i]["PlanType"].ToString() + " Plan.')</script>", false);
                                //                    Session["PlanTable"] = null;
                                //                    Session["AdditionalProductTable"] = null;
                                //                }
                                //            }
                                //        }
                                //    }
                                //}

                                if (flagCheckValidation)
                                {
                                    mynewfile = CreateTools2_AccountProfileDetails(tc.Tools1_SubjectID, PlanInfoTable, AccountDS, AccountTeamMemberDS, ContactList, SessionId, PlanTableDetails, BenefitDS, ProductDS, BenefitStructureDS, RateDS, ContributionDS, AdditionalProductTableDetails);
                                }
                            }
                            else
                            {
                                flagCheckValidation = false;
                            }
                        }
                    }

                    if (flagCheckValidation)
                        DownloadFileNew(mynewfile);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /*----Added by Amogh For New Development------*/
        List<string> lstPlanNames = new List<string>();
        List<Eligibility> lstEligibilityNames = new List<Eligibility>();

        protected void btnNext_Click(object sender, EventArgs e)
        {
            List<Eligibility> EligibilityList = new List<Eligibility>();
            Eligibility eligibilityItem = new Eligibility();
            string _PlanName = string.Empty;
            string selected_Value = string.Empty;
            try
            {

                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;

                PlanInfoTable = GetPlanInfoTable_Summary();
                Session["PlanInfoTable"] = PlanInfoTable;

                if (PlanInfoTable != null)
                {
                    if (PlanInfoTable.Rows.Count > 0)
                    {
                        if (mvAccountProfile.ActiveViewIndex == 0)
                        {
                            mvAccountProfile.ActiveViewIndex = 1;
                            ////btnPrevious.Visible = true;
                            ////btnNext.Visible = false;
                            ////btnSummary.Visible = true;

                            divBtnPrevious.Style.Add("Display", "block");
                            divBtnNext.Style.Add("Display", "none");
                            divBtnSummary.Style.Add("Display", "block");

                            MedicalPlansSelected();
                            StopLossPlanSelected();
                            PrescriptionPlanPlanSelected();
                            DentalPlanSelected();
                            VisionPlanSelected();
                            LifeADDPlanSelected();
                            STDPlanSelected();
                            LTDPlanSelected();
                            VoluntariLifeADDPlanSelected();
                            FSAPlanSelected();
                            HSAPlanSelected();
                            HRAPlanSelected();
                            EAPPlanSelected();
                            DisabilityPlanSelected();
                            AccidentalPlanSelected();


                            pnlWidthToDisplay.Visible = false;
                            bool isAdditionalProduct = false;

                            var dictionaryPlanList = new Dictionary<string, int>(20);
                            List<string> lstAvailablePlanNames = new List<string>();

                            foreach (DataRow dr in PlanInfoTable.Rows)
                            {
                                isAdditionalProduct = false;
                                /**********************************************************************************************************
                                     As Per Nicole We Need to Show Additional Product Section on Plan Page.
                                 *   So We commnet this code. 
                                 *******************************************************************************/
                                ////for (int j = 0; j < CommonFunctionsBS.AdditionalProductsPlanTypeList.Count; j++)
                                ////{
                                ////    if (Convert.ToInt32(dr["ProductTypeId"]) == Convert.ToInt32(CommonFunctionsBS.AdditionalProductsPlanTypeList[j]))
                                ////    {
                                ////        isAdditionalProduct = true;
                                ////    }
                                ////}

                                if (isAdditionalProduct == false)
                                {
                                    // Get the plan names for the seleted PlanTypeId
                                    _PlanName = GetPlanName(Convert.ToInt16(dr["ProductTypeId"]));

                                    /**********************************************************************************************************
                                     * Old logic which check wellness and can't allow to bind on left hand menu.
                                     *********************************************************************************************************/
                                    ////if (!lstPlanNames.Contains(_PlanName) && _PlanName != "" && _PlanName != cv.Wellness)
                                    ////if (!lstPlanNames.Contains(_PlanName) && _PlanName != "")  //Commented by Amogh For Issue#2
                                    if (!lstAvailablePlanNames.Contains(_PlanName) && _PlanName != "")
                                    {
                                        if (_PlanName == cv.MedicalLOC)
                                        {  // Medical
                                            dictionaryPlanList.Add(_PlanName, 1);
                                        }
                                        if (_PlanName == cv.PrescriptionDrug)
                                        {  // Prescription Drug
                                            dictionaryPlanList.Add(_PlanName, 2);
                                        }
                                        if (_PlanName == cv.StopLoss)
                                        {  // Stop Loss
                                            dictionaryPlanList.Add(_PlanName, 3);
                                        }
                                        if (_PlanName == cv.DentalLOC)
                                        {  // Dental Plan
                                            dictionaryPlanList.Add(_PlanName, 4);
                                        }
                                        if (_PlanName == cv.VisionLOC)
                                        {  // Vision Plan
                                            dictionaryPlanList.Add(_PlanName, 5);
                                        }
                                        if (_PlanName == cv.HSAPlanType_CommonCriteria)
                                        {  // HSA Plan
                                            dictionaryPlanList.Add(_PlanName, 6);
                                        }
                                        if (_PlanName == cv.HRAPlanType_CommonCriteria)
                                        {  // HRA Plan
                                            dictionaryPlanList.Add(_PlanName, 7);
                                        }
                                        if (_PlanName == cv.FSAPlanType_CommonCriteria)
                                        {  // FSA Plan
                                            dictionaryPlanList.Add(_PlanName, 8);
                                        }
                                        if (_PlanName == cv.LifeADDLOC)
                                        {  // Life and AD&D
                                            dictionaryPlanList.Add(_PlanName, 9);
                                        }
                                        if (_PlanName == (cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria))
                                        {  // Voluntary Life AD&D
                                            dictionaryPlanList.Add(_PlanName, 10);
                                        }
                                        if (_PlanName == cv.STDLOC)
                                        {  // STD Plan
                                            dictionaryPlanList.Add(_PlanName, 11);
                                        }
                                        if (_PlanName == cv.LTDLOC)
                                        {  // LTD Plan
                                            dictionaryPlanList.Add(_PlanName, 12);
                                        }
                                        if (_PlanName == cv.Disability)
                                        {  //Disability
                                            dictionaryPlanList.Add(_PlanName, 13);
                                        }
                                        if (_PlanName == cv.Accident)
                                        {  // Accident Plan
                                            dictionaryPlanList.Add(_PlanName, 14);
                                        }
                                        if (_PlanName == cv.EAPPlanType_CommonCriteria)
                                        {  //  EAP Plan
                                            dictionaryPlanList.Add(_PlanName, 15);
                                        }
                                        if (_PlanName == cv.Wellness)
                                        {  // Wellness Plan
                                            dictionaryPlanList.Add(_PlanName, 16);
                                        }
                                        if (_PlanName == cv.AdditionalProducts)
                                        {  // Additional Products
                                            dictionaryPlanList.Add(_PlanName, 17);
                                        }

                                        lstAvailablePlanNames.Add(_PlanName);
                                        ////lstPlanNames.Add(_PlanName);
                                    }

                                    /**********************************************************************************************************
                                     Old Logic to add check Eligibiliy for Medical Dental Vision Details. So We commnet this code. 
                                    *******************************************************************************/
                                    //// Check if the selected plan is Medical, Dental or Vision
                                    //// Because Eligibility is applicable only for Medical, Dental or Vision plans
                                    //if (Check_PlanIs_Medical_Dental_Vision(Convert.ToInt16(dr["ProductTypeId"])))
                                    //{
                                    //    EligibilityList = bp.FindEligibility(Convert.ToInt32(dr["ProductId"]), Session["SessionId"].ToString());

                                    //    foreach (var item in EligibilityList)
                                    //    {
                                    //        eligibilityItem = new Eligibility();
                                    //        eligibilityItem.EligibilityId = item.EligibilityId;
                                    //        eligibilityItem.EligibilityDescription = Convert.ToString(dr["Name"]) + " - " + Convert.ToString(dr["PolicyNumber"]) + " - " + item.EligibilityDescription;

                                    //        if (!lstEligibilityNames.Equals(eligibilityItem.EligibilityDescription))
                                    //        {
                                    //            lstEligibilityNames.Add(eligibilityItem);
                                    //        }
                                    //    }
                                    //}
                                }
                            }//Foreach Close

                            var items = from pair in dictionaryPlanList
                                        orderby pair.Value ascending
                                        select pair;

                            //HERE WE SORT LIST AS PER NICOLE REQUIRED 
                            foreach (KeyValuePair<string, int> pair in items)
                            {
                                lstPlanNames.Add(pair.Key);
                            }

                            dlPlan.DataSource = lstPlanNames;
                            dlPlan.DataBind();
                        }
                        else if (mvAccountProfile.ActiveViewIndex == 1)
                        {

                        }
                    }
                    else
                    {
                        if (grdPlans.Rows.Count > 0)
                        {
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                        }
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please select plans from Grid.')</script>", false);
                        divBtnNext.Style.Add("display", "block");
                        divBtnSummary.Style.Add("display", "none");
                        divBtnPrevious.Style.Add("display", "none");
                    }
                }//PlanInfoTable Close
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLayout_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            Clear(true, true);
            ////if (ddlLayout.SelectedIndex == 0)
            ////{
            ////    //btnPrevious.Visible = false;
            ////    //btnNext.Visible = false;
            ////    //btnSummary.Visible = true;
            ////    divBtnPrevious.Style.Add("Display", "none");
            ////    divBtnNext.Style.Add("Display", "none");
            ////    divBtnSummary.Style.Add("Display", "block");

            ////}
            ////else if (ddlLayout.SelectedIndex == 1)
            ////{
            ////    //btnPrevious.Visible = false;
            ////    //btnNext.Visible = false;
            ////    //btnSummary.Visible = true;

            ////    divBtnPrevious.Style.Add("Display", "none");
            ////    divBtnNext.Style.Add("Display", "none");
            ////    divBtnSummary.Style.Add("Display", "block");
            ////}
            ////else if (ddlLayout.SelectedIndex == 2)
            ////{
            ////    //btnPrevious.Visible = false;
            ////    //btnNext.Visible = true;
            ////    //btnSummary.Visible = false;
            ////    divBtnPrevious.Style.Add("Display", "none");
            ////    divBtnNext.Style.Add("Display", "block");
            ////    divBtnSummary.Style.Add("Display", "none");
            ////}
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            if (mvAccountProfile.ActiveViewIndex == 1)
            {
                mvAccountProfile.ActiveViewIndex = 0;
                ////btnPrevious.Visible = false;
                ////btnNext.Visible = true;
                ////btnSummary.Visible = false;

                divBtnPrevious.Style.Add("Display", "none");
                divBtnNext.Style.Add("Display", "block");
                divBtnSummary.Style.Add("Display", "none");
            }
        }

        private void MedicalPlansSelected()
        {
            try
            {
                if (ddlMedicalNoOfPlan.SelectedIndex == 0)
                {
                    ClearMedical();
                    if (ddlMedicalPlanName1 != null)
                    {
                        ddlMedicalPlanName1.Items.Clear();
                    }
                    if (ddlMedicalPlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                    if (ddlMedicalPlanName3 != null)
                    {
                        ddlMedicalPlanName3.Items.Clear();
                    }
                    if (ddlMedicalPlanName4 != null)
                    {
                        ddlMedicalPlanName4.Items.Clear();
                    }
                    if (ddlMedicalPlanName5 != null)
                    {
                        ddlMedicalPlanName5.Items.Clear();
                    }
                    if (ddlMedicalPlanName6 != null)
                    {
                        ddlMedicalPlanName6.Items.Clear();
                    }
                }
                string ch = ddlMedicalNoOfPlan.SelectedItem.Text;
                List<Plan> MedicalPlanList = new List<Plan>();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.MedicalPlanTypeList, cv.MedicalLOC, ref MedicalPlanList);
                string selected_Value = string.Empty;
                switch (ch)
                {
                    case "1":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = false;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);

                        //if (ddlMedicalPlanName1.SelectedIndex > 0)
                        //{
                        //selected_Value = Convert.ToString(ddlMedicalPlanName1.SelectedValue);

                        //ddlMedicalPlanName1.Items.Clear();
                        //ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //ddlMedicalPlanName1.DataBind();
                        //ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", "0"));

                        //ddlMedicalPlanName1.SelectedIndex = ddlMedicalPlanName1.Items.IndexOf(ddlMedicalPlanName1.Items.FindByValue(selected_Value));
                        //}
                        //else if (ddlMedicalPlanName1.SelectedIndex == -1)
                        //{
                        //    ddlMedicalPlanName1.Items.Clear();
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", "0"));
                        //    ddlMedicalPlanName1.SelectedValue = selected_Value;

                        //    //SummaryDetail.isClientChanged_ForMedical = false;
                        //}

                        ddlMedicalPlanName2.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        ClearDropDownList(ddlMedicalRate2, ddlMedicalEligibility2);
                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        ClearDropDownList(ddlMedicalRate3, ddlMedicalEligibility3);
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ClearDropDownList(ddlMedicalRate4, ddlMedicalEligibility4);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ClearDropDownList(ddlMedicalRate5, ddlMedicalEligibility5);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);
                        break;

                    case "2":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;


                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);

                        ddlMedicalPlanName3.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

                        //Added by Amogh 
                        ClearDropDownList(ddlMedicalRate3, ddlMedicalEligibility3);
                        ClearDropDownList(ddlMedicalRate4, ddlMedicalEligibility4);
                        ClearDropDownList(ddlMedicalRate5, ddlMedicalEligibility5);
                        ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);

                        break;

                    case "3":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);

                        ddlMedicalPlanName4.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        SummaryDetail.isClientChanged_ForMedical = false;

                        //Added by Amogh
                        ClearDropDownList(ddlMedicalRate4, ddlMedicalEligibility4);
                        ClearDropDownList(ddlMedicalRate5, ddlMedicalEligibility5);
                        ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);

                        break;

                    case "4":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);

                        ddlMedicalPlanName5.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        SummaryDetail.isClientChanged_ForMedical = false;
                        //Added by Amogh
                        ClearDropDownList(ddlMedicalRate5, ddlMedicalEligibility5);
                        ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);

                        break;

                    case "5":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = true;
                        tblMedicalPlan_6.Visible = false;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName5.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName5.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName5.DataBind();
                        //    ddlMedicalPlanName5.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        FillDropdownList(ddlMedicalPlanName5, MedicalPlanList, ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);

                        ddlMedicalPlanName6.Items.Clear();
                        ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                        //Added by Amogh
                        ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);
                        break;
                    case "6":

                        tblMedicalPlan_1.Visible = true;
                        tblMedicalPlan_2.Visible = true;
                        tblMedicalPlan_3.Visible = true;
                        tblMedicalPlan_4.Visible = true;
                        tblMedicalPlan_5.Visible = true;
                        tblMedicalPlan_6.Visible = true;

                        //if (ddlMedicalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName1.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName1.DataBind();
                        //    ddlMedicalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName2.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName2.DataBind();
                        //    ddlMedicalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName3.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName3.DataBind();
                        //    ddlMedicalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName4.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName4.DataBind();
                        //    ddlMedicalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName5.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName5.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName5.DataBind();
                        //    ddlMedicalPlanName5.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlMedicalPlanName6.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForMedical == true)
                        //{
                        //    ddlMedicalPlanName6.DataSource = MedicalPlanList;
                        //    ddlMedicalPlanName6.DataBind();
                        //    ddlMedicalPlanName6.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlMedicalPlanName1, MedicalPlanList, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                        FillDropdownList(ddlMedicalPlanName2, MedicalPlanList, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                        FillDropdownList(ddlMedicalPlanName3, MedicalPlanList, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                        FillDropdownList(ddlMedicalPlanName4, MedicalPlanList, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                        FillDropdownList(ddlMedicalPlanName5, MedicalPlanList, ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                        FillDropdownList(ddlMedicalPlanName6, MedicalPlanList, ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

                        break;
                    case "_":

                        tblMedicalPlan_1.Visible = false;
                        tblMedicalPlan_2.Visible = false;
                        tblMedicalPlan_3.Visible = false;
                        tblMedicalPlan_4.Visible = false;
                        tblMedicalPlan_5.Visible = false;
                        tblMedicalPlan_6.Visible = false;

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlMedicalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MedicalPlansSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }




        /// <summary>
        /// USING THIS FUNCTION WE FIND OUT PRODUCT TYPE ID AND HIDE/SHOW RATE,CONTRIBUTION,ELIGIBILITY DROPDOWN
        /// </summary>
        /// <param name="PlanName"Selected Plan from drop down </param>
        /// <returns>return the product type id</returns>
        public string productTypeValue(string selectedPlanValue)
        {
            string returnValue = string.Empty;
            DataTable dtTable = GetPlanInfoTable_Summary();
            ////DataRow[] dr = dtTable.Select("ProductId = " + selectedPlanValue);
            ////if (dr.Length > 0)
            ////{
            ////    returnValue = dr[0]["ProductTypeId"].ToString();
            ////}

            //var results = from myRow in dtTable.AsEnumerable()
            //              where myRow.Field<int>("ProductId") == selectedPlanValue
            //              select myRow.Field<int>("ProductTypeId");
            IEnumerable<DataRow> query = from product in dtTable.AsEnumerable()
                                         where product.Field<string>("ProductId") == selectedPlanValue
                                         select product;
            foreach (DataRow productTypeId in query)
            {
                returnValue = productTypeId.Field<string>("ProductTypeId");
            }
            return returnValue;
        }

        protected void ddlMedicalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName1.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName1.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution1.Enabled = false;
                                ddlMedicalEligibility1.Enabled = false;
                                ddlMedicalContribution1_2.Enabled = false;
                                ddlMedicalRate1.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                                ClearDropDownList(ddlMedicalEligibility1, ddlMedicalRate1);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName1.SelectedValue), ddlMedicalBenefitSummary1, null, null, null, null);
                                break;

                            case "410": //international Bundled Plan 3 - Tire
                                ddlMedicalContribution1.Enabled = false;
                                ddlMedicalContribution1_2.Enabled = false;
                                ddlMedicalRate1.Enabled = false;
                                ddlMedicalEligibility1.Enabled = true;
                                ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                                ClearDropDownList(ddlMedicalEligibility1, ddlMedicalRate1);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName1.SelectedValue), ddlMedicalBenefitSummary1, null, ddlMedicalEligibility1, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution1.Enabled = true;
                        ddlMedicalEligibility1.Enabled = true;
                        ddlMedicalContribution1_2.Enabled = true;
                        ddlMedicalRate1.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName1.SelectedValue), ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalEligibility1, ddlMedicalRate1, ddlMedicalContribution1_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
                ClearDropDownList(ddlMedicalEligibility1, ddlMedicalRate1);
            }
        }

        protected void ddlMedicalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName2.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName2.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution2.Enabled = false;
                                ddlMedicalEligibility2.Enabled = false;
                                ddlMedicalContribution2_2.Enabled = false;
                                ddlMedicalRate2.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                                ClearDropDownList(ddlMedicalEligibility2, ddlMedicalRate2);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName2.SelectedValue), ddlMedicalBenefitSummary2, null, null, null, null);
                                break;

                            case "410": //International Bundled Plan 3 - Tire
                                ddlMedicalContribution2.Enabled = false;
                                ddlMedicalContribution2_2.Enabled = false;
                                ddlMedicalRate2.Enabled = false;
                                ddlMedicalEligibility2.Enabled = true;
                                ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                                ClearDropDownList(ddlMedicalEligibility2, ddlMedicalRate2);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName2.SelectedValue), ddlMedicalBenefitSummary2, null, ddlMedicalEligibility2, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution2.Enabled = true;
                        ddlMedicalContribution2_2.Enabled = true;
                        ddlMedicalRate2.Enabled = true;
                        ddlMedicalEligibility2.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName2.SelectedValue), ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalEligibility2, ddlMedicalRate2, ddlMedicalContribution2_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
                ClearDropDownList(ddlMedicalEligibility2, ddlMedicalRate2);
            }
        }

        protected void ddlMedicalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName3.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName3.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution3.Enabled = false;
                                ddlMedicalEligibility3.Enabled = false;
                                ddlMedicalContribution3_2.Enabled = false;
                                ddlMedicalRate3.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                                ClearDropDownList(ddlMedicalEligibility3, ddlMedicalRate3);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName3.SelectedValue), ddlMedicalBenefitSummary3, null, null, null, null);
                                break;

                            case "410": //International Bundled Plan 3 - Tire
                                ddlMedicalContribution3.Enabled = false;
                                ddlMedicalEligibility3.Enabled = true;
                                ddlMedicalContribution3_2.Enabled = false;
                                ddlMedicalRate3.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                                ClearDropDownList(ddlMedicalEligibility3, ddlMedicalRate3);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName3.SelectedValue), ddlMedicalBenefitSummary3, null, ddlMedicalEligibility3, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution3.Enabled = true;
                        ddlMedicalEligibility3.Enabled = true;
                        ddlMedicalContribution3_2.Enabled = true;
                        ddlMedicalRate3.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName3.SelectedValue), ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalEligibility3, ddlMedicalRate3, ddlMedicalContribution3_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
                ClearDropDownList(ddlMedicalEligibility3, ddlMedicalRate3);
            }
        }

        protected void ddlMedicalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName4.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName4.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution4.Enabled = false;
                                ddlMedicalEligibility4.Enabled = false;
                                ddlMedicalContribution4_2.Enabled = false;
                                ddlMedicalRate4.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                                ClearDropDownList(ddlMedicalEligibility4, ddlMedicalRate4);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName4.SelectedValue), ddlMedicalBenefitSummary4, null, null, null, null);
                                break;

                            case "410": //International Bundled Plan 3 - Tire
                                ddlMedicalContribution4.Enabled = false;
                                ddlMedicalEligibility4.Enabled = true;
                                ddlMedicalContribution4_2.Enabled = false;
                                ddlMedicalRate4.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                                ClearDropDownList(ddlMedicalEligibility4, ddlMedicalRate4);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName4.SelectedValue), ddlMedicalBenefitSummary4, null, ddlMedicalEligibility4, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution4.Enabled = true;
                        ddlMedicalEligibility4.Enabled = true;
                        ddlMedicalContribution4_2.Enabled = true;
                        ddlMedicalRate4.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName4.SelectedValue), ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalEligibility4, ddlMedicalRate4, ddlMedicalContribution4_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
                ClearDropDownList(ddlMedicalEligibility4, ddlMedicalRate4);
            }
        }

        protected void ddlMedicalPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName5.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName5.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution5.Enabled = false;
                                ddlMedicalEligibility5.Enabled = false;
                                ddlMedicalContribution5_2.Enabled = false;
                                ddlMedicalRate5.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                                ClearDropDownList(ddlMedicalEligibility5, ddlMedicalRate5);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName5.SelectedValue), ddlMedicalBenefitSummary5, null, null, null, null);
                                break;

                            case "410": //International Bundled Plan 3 - Tire
                                ddlMedicalContribution5.Enabled = false;
                                ddlMedicalEligibility5.Enabled = true;
                                ddlMedicalContribution5_2.Enabled = false;
                                ddlMedicalRate5.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                                ClearDropDownList(ddlMedicalEligibility5, ddlMedicalRate5);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName5.SelectedValue), ddlMedicalBenefitSummary5, null, ddlMedicalEligibility5, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution5.Enabled = true;
                        ddlMedicalEligibility5.Enabled = true;
                        ddlMedicalContribution5_2.Enabled = true;
                        ddlMedicalRate5.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName5.SelectedValue), ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalEligibility5, ddlMedicalRate5, ddlMedicalContribution5_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
                ClearDropDownList(ddlMedicalEligibility5, ddlMedicalRate5);
            }
        }

        protected void ddlMedicalPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMedicalPlanName6.SelectedIndex > 0)
            {
                string productTypeID = productTypeValue(Convert.ToString(ddlMedicalPlanName6.SelectedValue));
                if (productTypeID != null && productTypeID != "")
                {
                    if (medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    {
                        switch (productTypeID)
                        {
                            case "173": //stopLossValue
                            case "235": //Prescription Drug (Carve-Out)
                                ddlMedicalContribution6.Enabled = false;
                                ddlMedicalEligibility6.Enabled = false;
                                ddlMedicalContribution6_2.Enabled = false;
                                ddlMedicalRate6.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                                ClearDropDownList(ddlMedicalEligibility6, ddlMedicalRate6);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName6.SelectedValue), ddlMedicalBenefitSummary6, null, null, null, null);
                                break;

                            case "410": //International Bundled Plan 3 - Tire
                                ddlMedicalContribution6.Enabled = false;
                                ddlMedicalEligibility6.Enabled = true;
                                ddlMedicalContribution6_2.Enabled = false;
                                ddlMedicalRate6.Enabled = false;
                                ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                                ClearDropDownList(ddlMedicalEligibility6, ddlMedicalRate6);
                                BindDataToPlan(int.Parse(ddlMedicalPlanName6.SelectedValue), ddlMedicalBenefitSummary6, null, ddlMedicalEligibility6, null, null);
                                break;
                        }
                    }
                    else
                    {
                        ddlMedicalContribution6.Enabled = true;
                        ddlMedicalEligibility6.Enabled = true;
                        ddlMedicalContribution6_2.Enabled = true;
                        ddlMedicalRate6.Enabled = true;
                        BindDataToPlan(int.Parse(ddlMedicalPlanName6.SelectedValue), ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalEligibility6, ddlMedicalRate6, ddlMedicalContribution6_2);
                    }
                }
            }
            else
            {
                ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);
                ClearDropDownList(ddlMedicalEligibility6, ddlMedicalRate6);
            }
        }

        private void DentalPlanSelected()
        {
            try
            {
                if (ddlDentalNoOfPlan.SelectedIndex == 0)
                {
                    ClearDental();
                    if (ddlDentalPlanName1 != null)
                    {
                        ddlDentalPlanName1.Items.Clear();
                    }
                    if (ddlDentalPlanName2 != null)
                    {
                        ddlDentalPlanName2.Items.Clear();
                    }
                    if (ddlDentalPlanName3 != null)
                    {
                        ddlDentalPlanName3.Items.Clear();
                    }
                    if (ddlDentalPlanName4 != null)
                    {
                        ddlDentalPlanName4.Items.Clear();
                    }
                    if (ddlDentalPlanName5 != null)
                    {
                        ddlDentalPlanName5.Items.Clear();
                    }
                    if (ddlDentalPlanName6 != null)
                    {
                        ddlDentalPlanName6.Items.Clear();
                    }
                }
                string ch = ddlDentalNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> DentalPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.DentalPlanTypeList, cv.DentalLOC, ref DentalPlanList);

                switch (ch)
                {
                    case "1":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = false;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;
                        tblDentalPlan_5.Visible = false;
                        tblDentalPlan_6.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    SummaryDetail.isClientChanged_ForDental = false;
                        //}

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);

                        ddlDentalPlanName2.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);

                        ddlDentalPlanName5.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                        ddlDentalPlanName6.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);


                        //Added by Amogh which clear Rate dropdown
                        ClearDropDownList(ddlDentalRate2, ddlDentalEligibility2);
                        ClearDropDownList(ddlDentalRate3, ddlDentalEligibility3);
                        ClearDropDownList(ddlDentalRate4, ddlDentalEligibility4);
                        ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
                        ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);

                        break;

                    case "2":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;

                        tblDentalPlan_5.Visible = false;
                        tblDentalPlan_6.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        //SummaryDetail.isClientChanged_ForDental = false;

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);

                        ddlDentalPlanName3.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);

                        ddlDentalPlanName5.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                        ddlDentalPlanName6.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);

                        //Added by Amogh which clear Rate dropdown
                        ClearDropDownList(ddlDentalRate3, ddlDentalEligibility3);
                        ClearDropDownList(ddlDentalRate4, ddlDentalEligibility4);
                        ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
                        ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);

                        break;

                    case "3":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = false;
                        tblDentalPlan_5.Visible = false;
                        tblDentalPlan_6.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName3.DataSource = DentalPlanList;
                        //    ddlDentalPlanName3.DataBind();
                        //    ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);

                        ddlDentalPlanName4.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        ddlDentalPlanName5.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                        ddlDentalPlanName6.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);

                        //Added by Amogh which clear Rate dropdown
                        ClearDropDownList(ddlDentalRate4, ddlDentalEligibility4);
                        ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
                        ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);
                        //SummaryDetail.isClientChanged_ForDental = false;
                        break;

                    case "4":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = true;
                        tblDentalPlan_5.Visible = false;
                        tblDentalPlan_6.Visible = false;

                        //if (ddlDentalPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName1.DataSource = DentalPlanList;
                        //    ddlDentalPlanName1.DataBind();
                        //    ddlDentalPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName2.DataSource = DentalPlanList;
                        //    ddlDentalPlanName2.DataBind();
                        //    ddlDentalPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName3.DataSource = DentalPlanList;
                        //    ddlDentalPlanName3.DataBind();
                        //    ddlDentalPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlDentalPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForDental == true)
                        //{
                        //    ddlDentalPlanName4.DataSource = DentalPlanList;
                        //    ddlDentalPlanName4.DataBind();
                        //    ddlDentalPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //SummaryDetail.isClientChanged_ForDental = false;

                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        FillDropdownList(ddlDentalPlanName4, DentalPlanList, ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);

                        ddlDentalPlanName5.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                        ddlDentalPlanName6.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);
                        ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
                        ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);

                        break;
                    case "5":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = true;
                        tblDentalPlan_5.Visible = true;
                        tblDentalPlan_6.Visible = false;


                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        FillDropdownList(ddlDentalPlanName4, DentalPlanList, ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        FillDropdownList(ddlDentalPlanName5, DentalPlanList, ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);


                        ddlDentalPlanName6.Items.Clear();
                        ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);
                        ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);

                        break;
                    case "6":

                        tblDentalPlan_1.Visible = true;
                        tblDentalPlan_2.Visible = true;
                        tblDentalPlan_3.Visible = true;
                        tblDentalPlan_4.Visible = true;
                        tblDentalPlan_5.Visible = true;
                        tblDentalPlan_6.Visible = true;


                        FillDropdownList(ddlDentalPlanName1, DentalPlanList, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                        FillDropdownList(ddlDentalPlanName2, DentalPlanList, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                        FillDropdownList(ddlDentalPlanName3, DentalPlanList, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                        FillDropdownList(ddlDentalPlanName4, DentalPlanList, ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                        FillDropdownList(ddlDentalPlanName5, DentalPlanList, ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                        FillDropdownList(ddlDentalPlanName6, DentalPlanList, ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);

                        break;
                    case "_":

                        tblDentalPlan_1.Visible = false;
                        tblDentalPlan_2.Visible = false;
                        tblDentalPlan_3.Visible = false;
                        tblDentalPlan_4.Visible = false;
                        tblDentalPlan_5.Visible = false;
                        tblDentalPlan_6.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlDentalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DentalPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlDentalPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName1.SelectedValue), ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalEligibility1, ddlDentalRate1, ddlDentalContribution1_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
                ClearDropDownList(ddlDentalRate1, ddlDentalEligibility1);
            }
        }

        protected void ddlDentalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName2.SelectedValue), ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalEligibility2, ddlDentalRate2, ddlDentalContribution2_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
                ClearDropDownList(ddlDentalRate2, ddlDentalEligibility2);
            }
        }

        protected void ddlDentalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName3.SelectedValue), ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalEligibility3, ddlDentalRate3, ddlDentalContribution3_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
                ClearDropDownList(ddlDentalRate3, ddlDentalEligibility3);
            }
        }

        protected void ddlDentalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName4.SelectedValue), ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalEligibility4, ddlDentalRate4, ddlDentalContribution4_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
                ClearDropDownList(ddlDentalRate4, ddlDentalEligibility4);
            }
        }

        protected void ddlDentalPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName5.SelectedValue), ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalEligibility5, ddlDentalRate5, ddlDentalContribution5_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
                ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
            }
        }
        protected void ddlDentalPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDentalPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDentalPlanName6.SelectedValue), ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalEligibility6, ddlDentalRate6, ddlDentalContribution6_2);
            }
            else
            {
                ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);
                ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);
            }
        }

        private void VisionPlanSelected()
        {
            try
            {
                if (ddlVisionNoOfPlan.SelectedIndex == 0)
                {
                    ClearVision();
                    if (ddlVisionPlanName1 != null)
                    {
                        ddlVisionPlanName1.Items.Clear();
                    }
                    if (ddlVisionPlanName2 != null)
                    {
                        ddlVisionPlanName2.Items.Clear();
                    }
                    if (ddlVisionPlanName3 != null)
                    {
                        ddlVisionPlanName3.Items.Clear();
                    }
                    if (ddlVisionPlanName4 != null)
                    {
                        ddlVisionPlanName4.Items.Clear();
                    }
                    if (ddlVisionPlanName5 != null)
                    {
                        ddlVisionPlanName5.Items.Clear();
                    }
                    if (ddlVisionPlanName6 != null)
                    {
                        ddlVisionPlanName6.Items.Clear();
                    }
                }
                string ch = ddlVisionNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> VisionPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.VisionPlanTypeList, cv.VisionLOC, ref VisionPlanList);

                switch (ch)
                {
                    case "1":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = false;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;
                        tblVisionPlan_5.Visible = false;
                        tblVisionPlan_6.Visible = false;
                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    SummaryDetail.isClientChanged_ForVision = false;
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);

                        ddlVisionPlanName2.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);

                        ddlVisionPlanName5.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                        ddlVisionPlanName6.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);

                        //Added by Amogh to clear Rate Dropdownbox 
                        ClearDropDownList(ddlVisionRate2, ddlVisionEligibility2);
                        ClearDropDownList(ddlVisionRate3, ddlVisionEligibility3);
                        ClearDropDownList(ddlVisionRate4, ddlVisionEligibility4);

                        ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
                        ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);
                        break;

                    case "2":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;
                        tblVisionPlan_5.Visible = false;
                        tblVisionPlan_6.Visible = false;
                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);

                        ddlVisionPlanName3.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        ddlVisionPlanName5.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                        ddlVisionPlanName6.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);

                        //SummaryDetail.isClientChanged_ForVision = false;
                        //Added by Amogh to clear Rate Dropdownbox 
                        ClearDropDownList(ddlVisionRate3, ddlVisionEligibility3);
                        ClearDropDownList(ddlVisionRate4, ddlVisionEligibility4);
                        ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
                        ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);
                        break;

                    case "3":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = false;
                        tblVisionPlan_5.Visible = false;
                        tblVisionPlan_6.Visible = false;
                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName3.DataSource = VisionPlanList;
                        //    ddlVisionPlanName3.DataBind();
                        //    ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);

                        ddlVisionPlanName4.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        ddlVisionPlanName5.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                        ddlVisionPlanName6.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);

                        //Added by Amogh to clear Rate Dropdownbox 
                        ClearDropDownList(ddlVisionRate4, ddlVisionEligibility4);
                        ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
                        ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);
                        //SummaryDetail.isClientChanged_ForVision = false;
                        break;

                    case "4":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = true;

                        //if (ddlVisionPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName1.DataSource = VisionPlanList;
                        //    ddlVisionPlanName1.DataBind();
                        //    ddlVisionPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName2.DataSource = VisionPlanList;
                        //    ddlVisionPlanName2.DataBind();
                        //    ddlVisionPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName3.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName3.DataSource = VisionPlanList;
                        //    ddlVisionPlanName3.DataBind();
                        //    ddlVisionPlanName3.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}
                        //if (ddlVisionPlanName4.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVision == true)
                        //{
                        //    ddlVisionPlanName4.DataSource = VisionPlanList;
                        //    ddlVisionPlanName4.DataBind();
                        //    ddlVisionPlanName4.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        //SummaryDetail.isClientChanged_ForVision = false;

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        FillDropdownList(ddlVisionPlanName4, VisionPlanList, ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);


                        tblVisionPlan_5.Visible = false;
                        tblVisionPlan_6.Visible = false;
                        ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                        ddlVisionPlanName6.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);
                        ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
                        ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);

                        break;

                    case "5":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = true;
                        tblVisionPlan_5.Visible = true;

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        FillDropdownList(ddlVisionPlanName4, VisionPlanList, ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        FillDropdownList(ddlVisionPlanName5, VisionPlanList, ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);



                        tblVisionPlan_6.Visible = false;
                        ddlVisionPlanName6.Items.Clear();
                        ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);

                        ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);

                        break;

                    case "6":

                        tblVisionPlan_1.Visible = true;
                        tblVisionPlan_2.Visible = true;
                        tblVisionPlan_3.Visible = true;
                        tblVisionPlan_4.Visible = true;
                        tblVisionPlan_5.Visible = true;
                        tblVisionPlan_6.Visible = true;

                        FillDropdownList(ddlVisionPlanName1, VisionPlanList, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
                        FillDropdownList(ddlVisionPlanName2, VisionPlanList, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                        FillDropdownList(ddlVisionPlanName3, VisionPlanList, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                        FillDropdownList(ddlVisionPlanName4, VisionPlanList, ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                        FillDropdownList(ddlVisionPlanName5, VisionPlanList, ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                        FillDropdownList(ddlVisionPlanName6, VisionPlanList, ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);


                        break;

                    case "_":

                        tblVisionPlan_1.Visible = false;
                        tblVisionPlan_2.Visible = false;
                        tblVisionPlan_3.Visible = false;
                        tblVisionPlan_4.Visible = false;
                        tblVisionPlan_5.Visible = false;
                        tblVisionPlan_6.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlVisionNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                VisionPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlVisionPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName1.SelectedValue), ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionEligibility1, ddlVisionRate1, ddlVisionContribution1_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution1, ddlVisionContribution1_2);
                ClearDropDownList(ddlVisionRate1, ddlVisionEligibility1);
            }
        }

        protected void ddlVisionPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName2.SelectedValue), ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionEligibility2, ddlVisionRate2, ddlVisionContribution2_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
                ClearDropDownList(ddlVisionRate2, ddlVisionEligibility2);
            }
        }

        protected void ddlVisionPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName3.SelectedValue), ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionEligibility3, ddlVisionRate3, ddlVisionContribution3_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
                ClearDropDownList(ddlVisionRate3, ddlVisionEligibility3);
            }
        }

        protected void ddlVisionPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName4.SelectedValue), ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionEligibility4, ddlVisionRate4, ddlVisionContribution4_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
                ClearDropDownList(ddlVisionRate4, ddlVisionEligibility4);
            }
        }

        protected void ddlVisionPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName5.SelectedValue), ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionEligibility5, ddlVisionRate5, ddlVisionContribution5_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
                ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
            }
        }

        protected void ddlVisionPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVisionPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVisionPlanName6.SelectedValue), ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionEligibility6, ddlVisionRate6, ddlVisionContribution6_2);
            }
            else
            {
                ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);
                ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);
            }
        }

        private void LifeADDPlanSelected()
        {
            try
            {
                List<Plan> LifeADDPlanList = new List<Plan>();
                string ch = ddlLifeADDNoOfPlan.SelectedItem.Text;

                if (ddlLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearLifeADD();
                    if (ddlLifeADDPlanName1 != null)
                    {
                        ddlLifeADDPlanName1.Items.Clear();
                    }
                    if (ddlLifeADDPlanName2 != null)
                    {
                        ddlLifeADDPlanName2.Items.Clear();
                    }
                    if (ddlLifeADDPlanName3 != null)
                    {
                        ddlLifeADDPlanName3.Items.Clear();
                    }
                    if (ddlLifeADDPlanName4 != null)
                    {
                        ddlLifeADDPlanName4.Items.Clear();
                    }
                    if (ddlLifeADDPlanName5 != null)
                    {
                        ddlLifeADDPlanName5.Items.Clear();
                    }
                    if (ddlLifeADDPlanName6 != null)
                    {
                        ddlLifeADDPlanName6.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.LifeADDPlanTypeList, cv.LifeADDLOC, ref LifeADDPlanList);

                switch (ch)
                {
                    case "1":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = false;
                        tblLifeADDPlan_3.Visible = false;
                        tblLifeADDPlan_4.Visible = false;
                        tblLifeADDPlan_5.Visible = false;
                        tblLifeADDPlan_6.Visible = false;

                        //if (ddlLifeADDPlanName1.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForLifeADD == true)
                        //{
                        //    ddlLifeADDPlanName1.DataSource = LifeADDPlanList;
                        //    ddlLifeADDPlanName1.DataBind();
                        //    ddlLifeADDPlanName1.Items.Insert(0, new ListItem("Select", string.Empty));
                        //}

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);

                        ddlLifeADDPlanName2.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary2, null);
                        //Added by Amogh to clear Rate Dropdown
                        ClearDropDownList(ddlLifeADDRate2, ddlLifeADDEligibility2);
                        ddlLifeADDPlanName3.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary3, null);
                        ClearDropDownList(ddlLifeADDRate3, ddlLifeADDEligibility3);
                        ddlLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary4, null);
                        ClearDropDownList(ddlLifeADDRate4, ddlLifeADDEligibility4);
                        ddlLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary5, null);
                        ClearDropDownList(ddlLifeADDRate5, ddlLifeADDEligibility5);
                        ddlLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary6, null);
                        ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);

                        break;
                    case "2":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = true;
                        tblLifeADDPlan_3.Visible = false;
                        tblLifeADDPlan_4.Visible = false;
                        tblLifeADDPlan_5.Visible = false;
                        tblLifeADDPlan_6.Visible = false;

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                        FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);

                        ddlLifeADDPlanName3.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary3, null);
                        ClearDropDownList(ddlLifeADDRate3, ddlLifeADDEligibility3);
                        ddlLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary4, null);
                        ClearDropDownList(ddlLifeADDRate4, ddlLifeADDEligibility4);
                        ddlLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary5, null);
                        ClearDropDownList(ddlLifeADDRate5, ddlLifeADDEligibility5);
                        ddlLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary6, null);
                        ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);
                        break;
                    case "3":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = true;
                        tblLifeADDPlan_3.Visible = true;
                        tblLifeADDPlan_4.Visible = false;
                        tblLifeADDPlan_5.Visible = false;
                        tblLifeADDPlan_6.Visible = false;

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                        FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);
                        FillDropdownList(ddlLifeADDPlanName3, LifeADDPlanList, ddlLifeADDBenefitSummary3, null, null);

                        ddlLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary4, null);
                        ClearDropDownList(ddlLifeADDRate4, ddlLifeADDEligibility4);
                        ddlLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary5, null);
                        ClearDropDownList(ddlLifeADDRate5, ddlLifeADDEligibility5);
                        ddlLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary6, null);
                        ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);
                        break;
                    case "4":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = true;
                        tblLifeADDPlan_3.Visible = true;
                        tblLifeADDPlan_4.Visible = true;
                        tblLifeADDPlan_5.Visible = false;
                        tblLifeADDPlan_6.Visible = false;

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                        FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);
                        FillDropdownList(ddlLifeADDPlanName3, LifeADDPlanList, ddlLifeADDBenefitSummary3, null, null);
                        FillDropdownList(ddlLifeADDPlanName4, LifeADDPlanList, ddlLifeADDBenefitSummary4, null, null);

                        ddlLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary5, null);
                        ClearDropDownList(ddlLifeADDRate5, ddlLifeADDEligibility5);
                        ddlLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary6, null);
                        ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);
                        break;
                    case "5":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = true;
                        tblLifeADDPlan_3.Visible = true;
                        tblLifeADDPlan_4.Visible = true;
                        tblLifeADDPlan_5.Visible = true;
                        tblLifeADDPlan_6.Visible = false;

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                        FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);
                        FillDropdownList(ddlLifeADDPlanName3, LifeADDPlanList, ddlLifeADDBenefitSummary3, null, null);
                        FillDropdownList(ddlLifeADDPlanName4, LifeADDPlanList, ddlLifeADDBenefitSummary4, null, null);
                        FillDropdownList(ddlLifeADDPlanName5, LifeADDPlanList, ddlLifeADDBenefitSummary5, null, null);


                        ddlLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLifeADDBenefitSummary6, null);
                        ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);
                        break;
                    case "6":
                        tblLifeADDPlan_1.Visible = true;
                        tblLifeADDPlan_2.Visible = true;
                        tblLifeADDPlan_3.Visible = true;
                        tblLifeADDPlan_4.Visible = true;
                        tblLifeADDPlan_5.Visible = true;
                        tblLifeADDPlan_6.Visible = true;

                        FillDropdownList(ddlLifeADDPlanName1, LifeADDPlanList, ddlLifeADDBenefitSummary1, null, null);
                        FillDropdownList(ddlLifeADDPlanName2, LifeADDPlanList, ddlLifeADDBenefitSummary2, null, null);
                        FillDropdownList(ddlLifeADDPlanName3, LifeADDPlanList, ddlLifeADDBenefitSummary3, null, null);
                        FillDropdownList(ddlLifeADDPlanName4, LifeADDPlanList, ddlLifeADDBenefitSummary4, null, null);
                        FillDropdownList(ddlLifeADDPlanName5, LifeADDPlanList, ddlLifeADDBenefitSummary5, null, null);
                        FillDropdownList(ddlLifeADDPlanName6, LifeADDPlanList, ddlLifeADDBenefitSummary6, null, null);
                        break;
                    case "_":

                        tblLifeADDPlan_1.Visible = false;
                        tblLifeADDPlan_2.Visible = false;
                        tblLifeADDPlan_3.Visible = false;
                        tblLifeADDPlan_4.Visible = false;
                        tblLifeADDPlan_5.Visible = false;
                        tblLifeADDPlan_6.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }
        protected void ddlLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LifeADDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLifeADDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName1.SelectedValue), ddlLifeADDBenefitSummary1, ddlLifeADDRate1, null, ddlLifeADDEligibility1);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary1, ddlLifeADDRate1, ddlLifeADDEligibility1);
            }
        }

        protected void ddlLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName2.SelectedValue), ddlLifeADDBenefitSummary2, ddlLifeADDRate2, null, ddlLifeADDEligibility2);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary2, ddlLifeADDRate2, ddlLifeADDEligibility2);
            }
        }

        protected void ddlLifeADDPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName3.SelectedValue), ddlLifeADDBenefitSummary3, ddlLifeADDRate3, null, ddlLifeADDEligibility3);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary3, ddlLifeADDRate3, ddlLifeADDEligibility3);
            }
        }
        protected void ddlLifeADDPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName4.SelectedValue), ddlLifeADDBenefitSummary4, ddlLifeADDRate4, null, ddlLifeADDEligibility4);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary4, ddlLifeADDRate4, ddlLifeADDEligibility4);
            }
        }
        protected void ddlLifeADDPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName5.SelectedValue), ddlLifeADDBenefitSummary5, ddlLifeADDRate5, null, ddlLifeADDEligibility5);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary5, ddlLifeADDRate5, ddlLifeADDEligibility5);
            }
        }
        protected void ddlLifeADDPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLifeADDPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlLifeADDPlanName6.SelectedValue), ddlLifeADDBenefitSummary6, ddlLifeADDRate6, null, ddlLifeADDEligibility6);
            }
            else
            {
                ClearDropDownList(ddlLifeADDBenefitSummary6, ddlLifeADDRate6, ddlLifeADDEligibility6);
            }
        }



        private void STDPlanSelected()
        {
            try
            {
                List<Plan> STDPlanList = new List<Plan>();

                string ch = ddlSTDNoOfPlan.SelectedItem.Text;

                if (ddlSTDNoOfPlan.SelectedIndex == 0)
                {
                    ClearSTD();
                    if (ddlSTDPlanName1 != null)
                    {
                        ddlSTDPlanName1.Items.Clear();
                    }
                    if (ddlSTDPlanName2 != null)
                    {
                        ddlSTDPlanName2.Items.Clear();
                    }
                    if (ddlSTDPlanName3 != null)
                    {
                        ddlSTDPlanName3.Items.Clear();
                    }
                    if (ddlSTDPlanName4 != null)
                    {
                        ddlSTDPlanName4.Items.Clear();
                    }
                    if (ddlSTDPlanName5 != null)
                    {
                        ddlSTDPlanName5.Items.Clear();
                    }
                    if (ddlSTDPlanName6 != null)
                    {
                        ddlSTDPlanName6.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.STDPlanTypeList, cv.STDPlanType_CommonCriteria, ref STDPlanList);

                switch (ch)
                {

                    case "1":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = false;
                        tblSTD_3.Visible = false;
                        tblSTD_4.Visible = false;
                        tblSTD_5.Visible = false;
                        tblSTD_6.Visible = false;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);

                        //Added by Amogh to clear Rate Dropdown
                        ddlSTDPlanName2.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary2, null);
                        ClearDropDownList(ddlSTDRate2, ddlSTDEligibility2);

                        ddlSTDPlanName3.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary3, ddlSTDRate3, ddlSTDEligibility3);

                        ddlSTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary4, ddlSTDRate4, ddlSTDEligibility4);

                        ddlSTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary5, null);
                        ClearDropDownList(ddlSTDRate5, ddlSTDEligibility5);

                        ddlSTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary6, null);
                        ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);
                        break;
                    case "2":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = true;
                        tblSTD_3.Visible = false;
                        tblSTD_4.Visible = false;
                        tblSTD_5.Visible = false;
                        tblSTD_6.Visible = false;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                        FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);


                        ddlSTDPlanName3.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary3, null);
                        ClearDropDownList(ddlSTDRate3, ddlSTDEligibility3);

                        ddlSTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary4, null);
                        ClearDropDownList(ddlSTDRate4, ddlSTDEligibility4);

                        ddlSTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary5, null);
                        ClearDropDownList(ddlSTDRate5, ddlSTDEligibility5);

                        ddlSTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary6, null);
                        ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);
                        break;
                    case "3":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = true;
                        tblSTD_3.Visible = true;
                        tblSTD_4.Visible = false;
                        tblSTD_5.Visible = false;
                        tblSTD_6.Visible = false;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                        FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                        FillDropdownList(ddlSTDPlanName3, STDPlanList, ddlSTDBenefitSummary3, null, null);

                        ddlSTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary4, null);
                        ClearDropDownList(ddlSTDRate4, ddlSTDEligibility4);

                        ddlSTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary5, null);
                        ClearDropDownList(ddlSTDRate5, ddlSTDEligibility5);

                        ddlSTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary6, null);
                        ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);
                        break;
                    case "4":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = true;
                        tblSTD_3.Visible = true;
                        tblSTD_4.Visible = true;
                        tblSTD_5.Visible = false;
                        tblSTD_6.Visible = false;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                        FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                        FillDropdownList(ddlSTDPlanName3, STDPlanList, ddlSTDBenefitSummary3, null, null);
                        FillDropdownList(ddlSTDPlanName4, STDPlanList, ddlSTDBenefitSummary4, null, null);

                        ddlSTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary5, null);
                        ClearDropDownList(ddlSTDRate5, ddlSTDEligibility5);

                        ddlSTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary6, null);
                        ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);
                        break;
                    case "5":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = true;
                        tblSTD_3.Visible = true;
                        tblSTD_4.Visible = true;
                        tblSTD_5.Visible = true;
                        tblSTD_6.Visible = false;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                        FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                        FillDropdownList(ddlSTDPlanName3, STDPlanList, ddlSTDBenefitSummary3, null, null);
                        FillDropdownList(ddlSTDPlanName4, STDPlanList, ddlSTDBenefitSummary4, null, null);
                        FillDropdownList(ddlSTDPlanName5, STDPlanList, ddlSTDBenefitSummary5, null, null);

                        ddlSTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlSTDBenefitSummary6, null);
                        ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);

                        break;
                    case "6":
                        tblSTD_1.Visible = true;
                        tblSTD_2.Visible = true;
                        tblSTD_3.Visible = true;
                        tblSTD_4.Visible = true;
                        tblSTD_5.Visible = true;
                        tblSTD_6.Visible = true;

                        FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                        FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                        FillDropdownList(ddlSTDPlanName3, STDPlanList, ddlSTDBenefitSummary3, null, null);
                        FillDropdownList(ddlSTDPlanName4, STDPlanList, ddlSTDBenefitSummary4, null, null);
                        FillDropdownList(ddlSTDPlanName5, STDPlanList, ddlSTDBenefitSummary5, null, null);
                        FillDropdownList(ddlSTDPlanName6, STDPlanList, ddlSTDBenefitSummary6, null, null);

                        break;
                    case "_":
                        tblSTD_1.Visible = false;
                        tblSTD_2.Visible = false;
                        tblSTD_3.Visible = false;
                        tblSTD_4.Visible = false;
                        tblSTD_5.Visible = false;
                        tblSTD_6.Visible = false;
                        break;

                }
                //////if (ddlSTDNoOfPlan.SelectedIndex == 1)
                //////{
                //////    tblSTD_1.Visible = true;
                //////    tblSTD_2.Visible = false;



                //////    FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);

                //////    ddlSTDPlanName2.Items.Clear();
                //////    ClearDropDownList(ddlSTDBenefitSummary2, null);
                //////    //Added by Amogh to clear Rate Dropdown
                //////    ClearDropDownList(ddlSTDRate2, null);
                //////    //SummaryDetail.isClientChanged_ForSTD = false;
                //////}
                //////else if (ddlSTDNoOfPlan.SelectedIndex == 2)
                //////{
                //////    tblSTD_1.Visible = true;
                //////    tblSTD_2.Visible = true;


                //////    FillDropdownList(ddlSTDPlanName1, STDPlanList, ddlSTDBenefitSummary1, null, null);
                //////    FillDropdownList(ddlSTDPlanName2, STDPlanList, ddlSTDBenefitSummary2, null, null);
                //////}
                //////else
                //////{
                //////    tblSTD_1.Visible = false;
                //////    tblSTD_2.Visible = false;
                //////}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                STDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlSTDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName1.SelectedIndex > 0)
            {
                if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName1.SelectedValue), ddlSTDBenefitSummary1, ddlSTDRate1, null, ddlSTDEligibility1);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName1.SelectedValue), ddlSTDBenefitSummary1, ddlSTDRate1, null, ddlSTDEligibility1);
                }
            }
            else
            {
                if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary1, ddlSTDEligibility1, ddlSTDRate1);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary1, ddlSTDEligibility1, ddlSTDRate1);
                }
            }
        }

        protected void ddlSTDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName2.SelectedIndex > 0)
            {
                if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName2.SelectedValue), ddlSTDBenefitSummary2, ddlSTDRate2, null, ddlSTDEligibility2);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName2.SelectedValue), ddlSTDBenefitSummary2, ddlSTDRate2, null, ddlSTDEligibility2);
                }
            }
            else
            {
                if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary2, ddlSTDEligibility2, ddlSTDRate2);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary2, ddlSTDEligibility2, ddlSTDRate2);
                }
            }
        }

        protected void ddlSTDPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName3.SelectedIndex > 0)
            {
                if (ddlSTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName3.SelectedValue), ddlSTDBenefitSummary3, ddlSTDRate3, null, ddlSTDEligibility3);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName3.SelectedValue), ddlSTDBenefitSummary3, ddlSTDRate3, null, ddlSTDEligibility3);
                }
            }
            else
            {
                if (ddlSTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary3, ddlSTDEligibility3, ddlSTDRate3);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary3, ddlSTDEligibility3, ddlSTDRate3);
                }
            }
        }

        protected void ddlSTDPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName4.SelectedIndex > 0)
            {
                if (ddlSTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName4.SelectedValue), ddlSTDBenefitSummary4, ddlSTDRate4, null, ddlSTDEligibility4);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName4.SelectedValue), ddlSTDBenefitSummary4, ddlSTDRate4, null, ddlSTDEligibility4);
                }
            }
            else
            {
                if (ddlSTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary4, ddlSTDEligibility4, ddlSTDRate4);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary4, ddlSTDEligibility4, ddlSTDRate4);
                }
            }
        }

        protected void ddlSTDPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName5.SelectedIndex > 0)
            {
                if (ddlSTDPlanName5.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName5.SelectedValue), ddlSTDBenefitSummary5, ddlSTDRate5, null, ddlSTDEligibility5);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName5.SelectedValue), ddlSTDBenefitSummary5, ddlSTDRate5, null, ddlSTDEligibility5);
                }
            }
            else
            {
                if (ddlSTDPlanName5.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary5, ddlSTDEligibility5, ddlSTDRate5);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary5, ddlSTDEligibility5, ddlSTDRate5);
                }
            }
        }

        protected void ddlSTDPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSTDPlanName6.SelectedIndex > 0)
            {
                if (ddlSTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName6.SelectedValue), ddlSTDBenefitSummary6, ddlSTDRate6, null, ddlSTDEligibility6);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlSTDPlanName6.SelectedValue), ddlSTDBenefitSummary6, ddlSTDRate6, null, ddlSTDEligibility6);
                }
            }
            else
            {
                if (ddlSTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlSTDBenefitSummary6, ddlSTDEligibility6, ddlSTDRate6);
                }
                else
                {
                    ClearDropDownList(ddlSTDBenefitSummary6, ddlSTDEligibility6, ddlSTDRate6);
                }
            }
        }

        private void LTDPlanSelected()
        {
            try
            {
                List<Plan> LTDPlanList = new List<Plan>();

                string ch = ddlLTDNoOfPlan.SelectedItem.Text;
                if (ddlLTDNoOfPlan.SelectedIndex == 0)
                {
                    ClearLTD();
                    if (ddlLTDPlanName1 != null)
                    {
                        ddlLTDPlanName1.Items.Clear();
                    }
                    if (ddlLTDPlanName2 != null)
                    {
                        ddlLTDPlanName2.Items.Clear();
                    }
                    if (ddlLTDPlanName3 != null)
                    {
                        ddlLTDPlanName3.Items.Clear();
                    }
                    if (ddlLTDPlanName4 != null)
                    {
                        ddlLTDPlanName4.Items.Clear();
                    }
                    if (ddlLTDPlanName5 != null)
                    {
                        ddlLTDPlanName5.Items.Clear();
                    }
                    if (ddlLTDPlanName6 != null)
                    {
                        ddlLTDPlanName6.Items.Clear();
                    }
                }

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.LTDPlanTypeList, cv.LTDPlanType_CommonCriteria, ref LTDPlanList);

                switch (ch)
                {

                    case "1":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = false;
                        tblLTD_3.Visible = false;
                        tblLTD_4.Visible = false;
                        tblLTD_5.Visible = false;
                        tblLTD_6.Visible = false;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);


                        ddlLTDPlanName2.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary2, null);
                        ClearDropDownList(ddlLTDRate2, ddlLTDEligibility2);

                        ddlLTDPlanName3.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary3, null);
                        ClearDropDownList(ddlLTDRate3, ddlLTDEligibility3);

                        ddlLTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary4, null);
                        ClearDropDownList(ddlLTDRate4, ddlLTDEligibility4);

                        ddlLTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary5, null);
                        ClearDropDownList(ddlLTDRate5, ddlLTDEligibility5);

                        ddlLTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary6, null);
                        ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
                        break;

                    case "2":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = true;
                        tblLTD_3.Visible = false;
                        tblLTD_4.Visible = false;
                        tblLTD_5.Visible = false;
                        tblLTD_6.Visible = false;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                        FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);

                        ddlLTDPlanName3.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary3, null);
                        ClearDropDownList(ddlLTDRate3, ddlLTDEligibility3);

                        ddlLTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary4, null);
                        ClearDropDownList(ddlLTDRate4, ddlLTDEligibility4);

                        ddlLTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary5, null);
                        ClearDropDownList(ddlLTDRate5, ddlLTDEligibility5);

                        ddlLTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary6, null);
                        ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
                        break;
                    case "3":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = true;
                        tblLTD_3.Visible = true;
                        tblLTD_4.Visible = false;
                        tblLTD_5.Visible = false;
                        tblLTD_6.Visible = false;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                        FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);
                        FillDropdownList(ddlLTDPlanName3, LTDPlanList, ddlLTDBenefitSummary3, null, null);

                        ddlLTDPlanName4.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary4, null);
                        ClearDropDownList(ddlLTDRate4, ddlLTDEligibility4);

                        ddlLTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary5, null);
                        ClearDropDownList(ddlLTDRate5, ddlLTDEligibility5);

                        ddlLTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary6, null);
                        ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
                        break;
                    case "4":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = true;
                        tblLTD_3.Visible = true;
                        tblLTD_4.Visible = true;
                        tblLTD_5.Visible = false;
                        tblLTD_6.Visible = false;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                        FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);
                        FillDropdownList(ddlLTDPlanName3, LTDPlanList, ddlLTDBenefitSummary3, null, null);
                        FillDropdownList(ddlLTDPlanName4, LTDPlanList, ddlLTDBenefitSummary4, null, null);

                        ddlLTDPlanName5.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary5, null);
                        ClearDropDownList(ddlLTDRate5, ddlLTDEligibility5);

                        ddlLTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary6, null);
                        ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
                        break;
                    case "5":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = true;
                        tblLTD_3.Visible = true;
                        tblLTD_4.Visible = true;
                        tblLTD_5.Visible = true;
                        tblLTD_6.Visible = false;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                        FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);
                        FillDropdownList(ddlLTDPlanName3, LTDPlanList, ddlLTDBenefitSummary3, null, null);
                        FillDropdownList(ddlLTDPlanName4, LTDPlanList, ddlLTDBenefitSummary4, null, null);
                        FillDropdownList(ddlLTDPlanName5, LTDPlanList, ddlLTDBenefitSummary5, null, null);

                        ddlLTDPlanName6.Items.Clear();
                        ClearDropDownList(ddlLTDBenefitSummary6, null);
                        ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
                        break;
                    case "6":
                        tblLTD_1.Visible = true;
                        tblLTD_2.Visible = true;
                        tblLTD_3.Visible = true;
                        tblLTD_4.Visible = true;
                        tblLTD_5.Visible = true;
                        tblLTD_6.Visible = true;

                        FillDropdownList(ddlLTDPlanName1, LTDPlanList, ddlLTDBenefitSummary1, null, null);
                        FillDropdownList(ddlLTDPlanName2, LTDPlanList, ddlLTDBenefitSummary2, null, null);
                        FillDropdownList(ddlLTDPlanName3, LTDPlanList, ddlLTDBenefitSummary3, null, null);
                        FillDropdownList(ddlLTDPlanName4, LTDPlanList, ddlLTDBenefitSummary4, null, null);
                        FillDropdownList(ddlLTDPlanName5, LTDPlanList, ddlLTDBenefitSummary5, null, null);
                        FillDropdownList(ddlLTDPlanName6, LTDPlanList, ddlLTDBenefitSummary6, null, null);

                        break;
                    case "_":
                        tblLTD_1.Visible = false;
                        tblLTD_2.Visible = false;
                        tblLTD_3.Visible = false;
                        tblLTD_4.Visible = false;
                        tblLTD_5.Visible = false;
                        tblLTD_6.Visible = false;
                        break;

                }//SwitchClose

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLTDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LTDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Clear DropdownList
        /// </summary>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void ClearDropDownList(DropDownList Benefit, DropDownList Contribution, DropDownList Contribution2 = null)
        {
            try
            {
                if (Benefit != null)
                {
                    Benefit.Items.Clear();
                }
                if (Contribution != null)
                {
                    Contribution.Items.Clear();
                }
                if (Contribution2 != null)
                {
                    Contribution2.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlLTDPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName1.SelectedIndex > 0)
            {
                if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName1.SelectedValue), ddlLTDBenefitSummary1, ddlLTDRate1, null, ddlLTDEligibility1);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName1.SelectedValue), ddlLTDBenefitSummary1, ddlLTDRate1, null, ddlLTDEligibility1);
                }
            }
            else
            {
                if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary1, ddlLTDRate1, ddlLTDEligibility1);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary1, ddlLTDRate1, ddlLTDEligibility1);
                }
            }
        }

        protected void ddlLTDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName2.SelectedIndex > 0)
            {
                if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName2.SelectedValue), ddlLTDBenefitSummary2, ddlLTDRate2, null, ddlLTDEligibility2);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName2.SelectedValue), ddlLTDBenefitSummary2, ddlLTDRate2, null, ddlLTDEligibility2);
                }
            }
            else
            {
                if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary2, ddlLTDRate2, ddlLTDEligibility2);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary2, ddlLTDRate2, ddlLTDEligibility2);
                }
            }
        }

        protected void ddlLTDPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName3.SelectedIndex > 0)
            {
                if (ddlLTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName3.SelectedValue), ddlLTDBenefitSummary3, ddlLTDRate3, null, ddlLTDEligibility3);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName3.SelectedValue), ddlLTDBenefitSummary3, ddlLTDRate3, null, ddlLTDEligibility3);
                }
            }
            else
            {
                if (ddlLTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary3, ddlLTDRate3, ddlLTDEligibility3);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary3, ddlLTDRate3, ddlLTDEligibility3);
                }
            }
        }

        protected void ddlLTDPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName4.SelectedIndex > 0)
            {
                if (ddlLTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName4.SelectedValue), ddlLTDBenefitSummary4, ddlLTDRate4, null, ddlLTDEligibility4);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName4.SelectedValue), ddlLTDBenefitSummary4, ddlLTDRate4, null, ddlLTDEligibility4);
                }
            }
            else
            {
                if (ddlLTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary4, ddlLTDRate4, ddlLTDEligibility4);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary4, ddlLTDRate4, ddlLTDEligibility4);
                }
            }
        }
        protected void ddlLTDPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName5.SelectedIndex > 0)
            {
                if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName5.SelectedValue), ddlLTDBenefitSummary5, ddlLTDRate5, null, ddlLTDEligibility5);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName5.SelectedValue), ddlLTDBenefitSummary5, ddlLTDRate5, null, ddlLTDEligibility5);
                }
            }
            else
            {
                if (ddlLTDPlanName5.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary5, ddlLTDRate5, ddlLTDEligibility5);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary5, ddlLTDRate5, ddlLTDEligibility5);
                }
            }
        }
        protected void ddlLTDPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLTDPlanName6.SelectedIndex > 0)
            {
                if (ddlLTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName6.SelectedValue), ddlLTDBenefitSummary6, ddlLTDRate6, null, ddlLTDEligibility6);
                }
                else
                {
                    BindDataToPlan(int.Parse(ddlLTDPlanName6.SelectedValue), ddlLTDBenefitSummary6, ddlLTDRate6, null, ddlLTDEligibility6);
                }
            }
            else
            {
                if (ddlLTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                {
                    ClearDropDownList(ddlLTDBenefitSummary6, ddlLTDRate6, ddlLTDEligibility6);
                }
                else
                {
                    ClearDropDownList(ddlLTDBenefitSummary6, ddlLTDRate6, ddlLTDEligibility6);
                }
            }
        }


        private void VoluntariLifeADDPlanSelected()
        {
            try
            {
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 0)
                {
                    ClearVoluntaryLifeADD();
                    if (ddlVoluntaryLifeADDPlanName != null)
                    {
                        ddlVoluntaryLifeADDPlanName.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName2 != null)
                    {
                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName3 != null)
                    {
                        ddlVoluntaryLifeADDPlanName3.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName4 != null)
                    {
                        ddlVoluntaryLifeADDPlanName4.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName5 != null)
                    {
                        ddlVoluntaryLifeADDPlanName5.Items.Clear();
                    }
                    if (ddlVoluntaryLifeADDPlanName6 != null)
                    {
                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                    }
                }


                string ch = ddlVoluntaryLifeADDNoOfPlan.SelectedItem.Text;
                List<Plan> VoluntaryLifeADDPlanList = new List<Plan>();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.VoluntaryLifeADDPlanTypeList, cv.VoluntaryLifeADDLOC, ref VoluntaryLifeADDPlanList);

                switch (ch)
                {
                    case "1":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = false;
                        tblVoluntaryLifeADD_3.Visible = false;
                        tblVoluntaryLifeADD_4.Visible = false;
                        tblVoluntaryLifeADD_5.Visible = false;
                        tblVoluntaryLifeADD_6.Visible = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);

                        ddlVoluntaryLifeADDPlanName2.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeEligibility2);

                        ddlVoluntaryLifeADDPlanName3.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary3, ddlVoluntaryLifeEligibility3);

                        ddlVoluntaryLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary4, ddlVoluntaryLifeEligibility4);

                        ddlVoluntaryLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);

                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);

                        break;

                    //case "Offered":
                    //    //trVoluntaryLifeADDSection.Visible = true;
                    //    if (ddlVoluntaryLifeADDPlanName != null && ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
                    //    {
                    //        if (ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("AD&D") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADnD") || ddlVoluntaryLifeADDPlanName.SelectedItem.Text.Contains("ADandD"))
                    //        {
                    //            //trVoluntaryLifeADDSection11.Visible = false;
                    //        }
                    //        else
                    //        {
                    //            //trVoluntaryLifeADDSection11.Visible = true;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        //trVoluntaryLifeADDSection11.Visible = true;
                    //    }
                    //    //trVoluntaryLifeADDSection2.Visible = false;
                    //    //trVoluntaryLifeADDSection12.Visible = false;

                    //    if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                    //    {
                    //        ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                    //        ddlVoluntaryLifeADDPlanName.DataBind();
                    //        ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    //        SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;
                    //        ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                    //        ddlVoluntaryLifeADDRate.Items.Clear();
                    //    }

                    //    ddlVoluntaryLifeADDPlanName2.Items.Clear();
                    //    ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeADDRate2);
                    //    break;

                    case "2":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = true;
                        tblVoluntaryLifeADD_3.Visible = false;
                        tblVoluntaryLifeADD_4.Visible = false;
                        tblVoluntaryLifeADD_5.Visible = false;
                        tblVoluntaryLifeADD_6.Visible = false;

                        //if (ddlVoluntaryLifeADDPlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        //{
                        //    ddlVoluntaryLifeADDPlanName.DataSource = VoluntaryLifeADDPlanList;
                        //    ddlVoluntaryLifeADDPlanName.DataBind();
                        //    ddlVoluntaryLifeADDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    ddlVoluntaryLifeADDBenefitSummary.Items.Clear();
                        //    ddlVoluntaryLifeADDRate.Items.Clear();
                        //}
                        //if (ddlVoluntaryLifeADDPlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForVoluntaryLifeADD == true)
                        //{
                        //    ddlVoluntaryLifeADDPlanName2.DataSource = VoluntaryLifeADDPlanList;
                        //    ddlVoluntaryLifeADDPlanName2.DataBind();
                        //    ddlVoluntaryLifeADDPlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        //    ddlVoluntaryLifeADDBenefitSummary2.Items.Clear();
                        //    ddlVoluntaryLifeADDRate2.Items.Clear();
                        //}
                        //SummaryDetail.isClientChanged_ForVoluntaryLifeADD = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, null);

                        ddlVoluntaryLifeADDPlanName3.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary3, ddlVoluntaryLifeEligibility3);

                        ddlVoluntaryLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary4, ddlVoluntaryLifeEligibility4);

                        ddlVoluntaryLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);

                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);

                        break;

                    case "3":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = true;
                        tblVoluntaryLifeADD_3.Visible = true;
                        tblVoluntaryLifeADD_4.Visible = false;
                        tblVoluntaryLifeADD_5.Visible = false;
                        tblVoluntaryLifeADD_6.Visible = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName3, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary3, null, null, null);

                        ddlVoluntaryLifeADDPlanName4.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary4, ddlVoluntaryLifeEligibility4);

                        ddlVoluntaryLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);

                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);
                        break;

                    case "4":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = true;
                        tblVoluntaryLifeADD_3.Visible = true;
                        tblVoluntaryLifeADD_4.Visible = true;
                        tblVoluntaryLifeADD_5.Visible = false;
                        tblVoluntaryLifeADD_6.Visible = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName3, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary3, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName4, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary4, null, null, null);

                        ddlVoluntaryLifeADDPlanName5.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);

                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);
                        break;

                    case "5":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = true;
                        tblVoluntaryLifeADD_3.Visible = true;
                        tblVoluntaryLifeADD_4.Visible = true;
                        tblVoluntaryLifeADD_5.Visible = true;
                        tblVoluntaryLifeADD_6.Visible = false;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName3, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary3, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName4, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary4, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName5, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary5, null, null, null);

                        ddlVoluntaryLifeADDPlanName6.Items.Clear();
                        ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);
                        break;

                    case "6":

                        tblVoluntaryLifeADD_1.Visible = true;
                        tblVoluntaryLifeADD_2.Visible = true;
                        tblVoluntaryLifeADD_3.Visible = true;
                        tblVoluntaryLifeADD_4.Visible = true;
                        tblVoluntaryLifeADD_5.Visible = true;
                        tblVoluntaryLifeADD_6.Visible = true;

                        FillDropdownList(ddlVoluntaryLifeADDPlanName, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName2, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary2, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName3, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary3, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName4, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary4, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName5, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary5, null, null, null);
                        FillDropdownList(ddlVoluntaryLifeADDPlanName6, VoluntaryLifeADDPlanList, ddlVoluntaryLifeADDBenefitSummary6, null, null, null);
                        break;

                    case "_":

                        tblVoluntaryLifeADD_1.Visible = false;
                        tblVoluntaryLifeADD_2.Visible = false;
                        tblVoluntaryLifeADD_3.Visible = false;
                        tblVoluntaryLifeADD_4.Visible = false;
                        tblVoluntaryLifeADD_5.Visible = false;
                        tblVoluntaryLifeADD_6.Visible = false;
                        break;

                    case "Not Offered":
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlVoluntaryLifeADDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            #region New Code
            try
            {
                VoluntariLifeADDPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            #endregion
        }

        protected void ddlVoluntaryLifeADDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////tdVoluntaryLifeSectionRate_1_Header.Visible = true;
            ////tdVoluntaryLifeSectionRate_1_DDL.Visible = true;
            ////tdVoluntaryLifeSectionRate_1_Header.Visible = true;
            ////tdVoluntaryLifeSectionRate_1_DDL.Visible = true;

            DropDownList ddlVolName1 = (DropDownList)sender;
            ////ddlVoluntaryLifeADDRate.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName.SelectedValue), ddlVoluntaryLifeADDBenefitSummary, null, null, ddlVoluntaryLifeEligibility1);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeEligibility1);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////tdVoluntaryLifeSectionRate_2_Header.Visible = true;
            ////tdVoluntaryLifeSectionRate_2_DDL.Visible = true;
            ////tdVoluntaryLifeSectionRate_2_Header.Visible = true;
            ////tdVoluntaryLifeSectionRate_2_DDL.Visible = true;

            DropDownList ddlVolName2 = (DropDownList)sender;
            //////ddlVoluntaryLifeADDRate2.Items.Clear();

            if (ddlVoluntaryLifeADDPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName2.SelectedValue), ddlVoluntaryLifeADDBenefitSummary2, null, null, ddlVoluntaryLifeEligibility2);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeEligibility2);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVoluntaryLifeADDPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName3.SelectedValue), ddlVoluntaryLifeADDBenefitSummary3, null, null, ddlVoluntaryLifeEligibility3);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary3, ddlVoluntaryLifeEligibility3);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVoluntaryLifeADDPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName4.SelectedValue), ddlVoluntaryLifeADDBenefitSummary4, null, null, ddlVoluntaryLifeEligibility4);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary4, ddlVoluntaryLifeEligibility4);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVoluntaryLifeADDPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName5.SelectedValue), ddlVoluntaryLifeADDBenefitSummary5, null, null, ddlVoluntaryLifeEligibility5);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);
            }
        }

        protected void ddlVoluntaryLifeADDPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlVoluntaryLifeADDPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlVoluntaryLifeADDPlanName6.SelectedValue), ddlVoluntaryLifeADDBenefitSummary6, null, null, ddlVoluntaryLifeEligibility6);
            }
            else
            {
                ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);
            }
        }

        private void EAPPlanSelected()
        {
            try
            {
                List<Plan> EAPPlanList = new List<Plan>();

                if (ddlEAPNoOfPlan.SelectedIndex == 0)
                {
                    ClearEAP();
                    if (ddlEAPPlanName != null)
                    {
                        ddlEAPPlanName.Items.Clear();
                    }
                    if (ddlEAPBenefitSummary2 != null)
                    {
                        ddlEAPBenefitSummary2.Items.Clear();
                    }
                    if (ddlEAPBenefitSummary3 != null)
                    {
                        ddlEAPBenefitSummary3.Items.Clear();
                    }
                    if (ddlEAPBenefitSummary4 != null)
                    {
                        ddlEAPBenefitSummary4.Items.Clear();
                    }
                    if (ddlEAPBenefitSummary5 != null)
                    {
                        ddlEAPBenefitSummary5.Items.Clear();
                    }
                    if (ddlEAPBenefitSummary6 != null)
                    {
                        ddlEAPBenefitSummary6.Items.Clear();
                    }
                }

                string ch = ddlEAPNoOfPlan.SelectedItem.Text;
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.EAPPlanTypeList, cv.EAPPlanType_CommonCriteria, ref EAPPlanList);

                switch (ch)
                {
                    case "1":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = false;
                        tblEAP_3.Visible = false;
                        tblEAP_4.Visible = false;
                        tblEAP_5.Visible = false;
                        tblEAP_6.Visible = false;

                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);

                        ddlEAPPlanName2.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary2, ddlEAPEligibility2);
                        ddlEAPPlanName3.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary3, ddlEAPEligibility3);
                        ddlEAPPlanName4.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary4, ddlEAPEligibility4);
                        ddlEAPPlanName5.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
                        ddlEAPPlanName6.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);

                        break;
                    case "2":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = true;
                        tblEAP_3.Visible = false;
                        tblEAP_4.Visible = false;
                        tblEAP_5.Visible = false;
                        tblEAP_6.Visible = false;


                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                        FillDropdownList(ddlEAPPlanName2, EAPPlanList, ddlEAPBenefitSummary2, null, null);

                        ddlEAPPlanName3.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary3, ddlEAPEligibility3);
                        ddlEAPPlanName4.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary4, ddlEAPEligibility4);
                        ddlEAPPlanName5.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
                        ddlEAPPlanName6.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
                        break;

                    case "3":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = true;
                        tblEAP_3.Visible = true;
                        tblEAP_4.Visible = false;
                        tblEAP_5.Visible = false;
                        tblEAP_6.Visible = false;


                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                        FillDropdownList(ddlEAPPlanName2, EAPPlanList, ddlEAPBenefitSummary2, null, null);
                        FillDropdownList(ddlEAPPlanName3, EAPPlanList, ddlEAPBenefitSummary3, null, null);

                        ddlEAPPlanName4.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary4, ddlEAPEligibility4);
                        ddlEAPPlanName5.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
                        ddlEAPPlanName6.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
                        break;

                    case "4":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = true;
                        tblEAP_3.Visible = true;
                        tblEAP_4.Visible = true;
                        tblEAP_5.Visible = false;
                        tblEAP_6.Visible = false;


                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                        FillDropdownList(ddlEAPPlanName2, EAPPlanList, ddlEAPBenefitSummary2, null, null);
                        FillDropdownList(ddlEAPPlanName3, EAPPlanList, ddlEAPBenefitSummary3, null, null);
                        FillDropdownList(ddlEAPPlanName4, EAPPlanList, ddlEAPBenefitSummary4, null, null);


                        ddlEAPPlanName5.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
                        ddlEAPPlanName6.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
                        break;
                    case "5":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = true;
                        tblEAP_3.Visible = true;
                        tblEAP_4.Visible = true;
                        tblEAP_5.Visible = true;
                        tblEAP_6.Visible = false;


                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                        FillDropdownList(ddlEAPPlanName2, EAPPlanList, ddlEAPBenefitSummary2, null, null);
                        FillDropdownList(ddlEAPPlanName3, EAPPlanList, ddlEAPBenefitSummary3, null, null);
                        FillDropdownList(ddlEAPPlanName4, EAPPlanList, ddlEAPBenefitSummary4, null, null);
                        FillDropdownList(ddlEAPPlanName5, EAPPlanList, ddlEAPBenefitSummary5, null, null);

                        ddlEAPPlanName6.Items.Clear();
                        ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
                        break;

                    case "6":

                        tblEAP_1.Visible = true;
                        tblEAP_2.Visible = true;
                        tblEAP_3.Visible = true;
                        tblEAP_4.Visible = true;
                        tblEAP_5.Visible = true;
                        tblEAP_6.Visible = true;


                        FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                        FillDropdownList(ddlEAPPlanName2, EAPPlanList, ddlEAPBenefitSummary2, null, null);
                        FillDropdownList(ddlEAPPlanName3, EAPPlanList, ddlEAPBenefitSummary3, null, null);
                        FillDropdownList(ddlEAPPlanName4, EAPPlanList, ddlEAPBenefitSummary4, null, null);
                        FillDropdownList(ddlEAPPlanName5, EAPPlanList, ddlEAPBenefitSummary5, null, null);
                        FillDropdownList(ddlEAPPlanName6, EAPPlanList, ddlEAPBenefitSummary6, null, null);
                        break;

                    case "_":

                        tblEAP_1.Visible = false;
                        tblEAP_2.Visible = false;
                        tblEAP_3.Visible = false;
                        tblEAP_4.Visible = false;
                        tblEAP_5.Visible = false;
                        tblEAP_6.Visible = false;
                        break;

                }//SwitchClose


                ////////if (ddlEAPNoOfPlan.SelectedIndex == 1)
                ////////{
                ////////    BPBusiness bp = new BPBusiness();


                ////////    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.EAPPlanTypeList, cv.EAPPlanType_CommonCriteria, ref EAPPlanList);

                ////////    tblEAP_1.Visible = true;

                ////////    //ddlEAPPlanName.DataSource = EAPPlanList;
                ////////    //ddlEAPPlanName.DataBind();
                ////////    //ddlEAPPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                ////////    FillDropdownList(ddlEAPPlanName, EAPPlanList, ddlEAPBenefitSummary, null, null);
                ////////}
                ////////else
                ////////{
                ////////    tblEAP_1.Visible = false;
                ////////}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlEAPNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                EAPPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlEAPPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName.SelectedValue), ddlEAPBenefitSummary, null, null, ddlEAPEligibility1);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary, ddlEAPEligibility1);
            }
        }

        protected void ddlEAPPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName2.SelectedValue), ddlEAPBenefitSummary2, null, null, ddlEAPEligibility2);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary2, ddlEAPEligibility2);
            }
        }
        protected void ddlEAPPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName3.SelectedValue), ddlEAPBenefitSummary3, null, null, ddlEAPEligibility3);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary3, ddlEAPEligibility3);
            }
        }
        protected void ddlEAPPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName4.SelectedValue), ddlEAPBenefitSummary4, null, null, ddlEAPEligibility4);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary4, ddlEAPEligibility4);
            }
        }
        protected void ddlEAPPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName5.SelectedValue), ddlEAPBenefitSummary5, null, null, ddlEAPEligibility5);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
            }
        }
        protected void ddlEAPPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEAPPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlEAPPlanName6.SelectedValue), ddlEAPBenefitSummary6, null, null, ddlEAPEligibility6);
            }
            else
            {
                ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
            }
        }

        private void FSAPlanSelected()
        {
            try
            {
                List<Plan> FSAPlanList = new List<Plan>();
                if (ddlFSANoOfPlan.SelectedIndex == 0)
                {
                    ClearFSA();
                    if (ddlFSAPlanName != null)
                    {
                        ddlFSAPlanName.Items.Clear();
                    }
                    if (ddlFSAPlanName2 != null)
                    {
                        ddlFSAPlanName2.Items.Clear();
                    }
                    if (ddlFSAPlanName3 != null)
                    {
                        ddlFSAPlanName3.Items.Clear();
                    }
                    if (ddlFSAPlanName4 != null)
                    {
                        ddlFSAPlanName4.Items.Clear();
                    }
                    if (ddlFSAPlanName5 != null)
                    {
                        ddlFSAPlanName5.Items.Clear();
                    }
                    if (ddlFSAPlanName6 != null)
                    {
                        ddlFSAPlanName6.Items.Clear();
                    }
                }

                string ch = ddlFSANoOfPlan.SelectedItem.Text;
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.FSAPlanTypeList, cv.FSAPlanType_CommonCriteria, ref FSAPlanList);

                switch (ch)
                {
                    case "1":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = false;
                        tblFSA_3.Visible = false;
                        tblFSA_4.Visible = false;
                        tblFSA_5.Visible = false;
                        tblFSA_6.Visible = false;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);

                        ddlFSAPlanName2.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary2, null);
                        ddlFSAPlanName3.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary3, null);
                        ddlFSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary4, null);
                        ddlFSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary5, null);
                        ddlFSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary6, null);
                        break;

                    case "2":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = true;
                        tblFSA_3.Visible = false;
                        tblFSA_4.Visible = false;
                        tblFSA_5.Visible = false;
                        tblFSA_6.Visible = false;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                        FillDropdownList(ddlFSAPlanName2, FSAPlanList, ddlFSABenefitSummary2, null, null);

                        ddlFSAPlanName3.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary3, null);
                        ddlFSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary4, null);
                        ddlFSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary5, null);
                        ddlFSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary6, null);
                        break;

                    case "3":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = true;
                        tblFSA_3.Visible = true;
                        tblFSA_4.Visible = false;
                        tblFSA_5.Visible = false;
                        tblFSA_6.Visible = false;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                        FillDropdownList(ddlFSAPlanName2, FSAPlanList, ddlFSABenefitSummary2, null, null);
                        FillDropdownList(ddlFSAPlanName3, FSAPlanList, ddlFSABenefitSummary3, null, null);

                        ddlFSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary4, null);
                        ddlFSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary5, null);
                        ddlFSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary6, null);
                        break;

                    case "4":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = true;
                        tblFSA_3.Visible = true;
                        tblFSA_4.Visible = true;
                        tblFSA_5.Visible = false;
                        tblFSA_6.Visible = false;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                        FillDropdownList(ddlFSAPlanName2, FSAPlanList, ddlFSABenefitSummary2, null, null);
                        FillDropdownList(ddlFSAPlanName3, FSAPlanList, ddlFSABenefitSummary3, null, null);
                        FillDropdownList(ddlFSAPlanName4, FSAPlanList, ddlFSABenefitSummary4, null, null);

                        ddlFSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary5, null);
                        ddlFSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary6, null);
                        break;

                    case "5":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = true;
                        tblFSA_3.Visible = true;
                        tblFSA_4.Visible = true;
                        tblFSA_5.Visible = true;
                        tblFSA_6.Visible = false;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                        FillDropdownList(ddlFSAPlanName2, FSAPlanList, ddlFSABenefitSummary2, null, null);
                        FillDropdownList(ddlFSAPlanName3, FSAPlanList, ddlFSABenefitSummary3, null, null);
                        FillDropdownList(ddlFSAPlanName4, FSAPlanList, ddlFSABenefitSummary4, null, null);
                        FillDropdownList(ddlFSAPlanName5, FSAPlanList, ddlFSABenefitSummary5, null, null);

                        ddlFSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlFSABenefitSummary6, null);
                        break;

                    case "6":
                        tblFSA_1.Visible = true;
                        tblFSA_2.Visible = true;
                        tblFSA_3.Visible = true;
                        tblFSA_4.Visible = true;
                        tblFSA_5.Visible = true;
                        tblFSA_6.Visible = true;

                        FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                        FillDropdownList(ddlFSAPlanName2, FSAPlanList, ddlFSABenefitSummary2, null, null);
                        FillDropdownList(ddlFSAPlanName3, FSAPlanList, ddlFSABenefitSummary3, null, null);
                        FillDropdownList(ddlFSAPlanName4, FSAPlanList, ddlFSABenefitSummary4, null, null);
                        FillDropdownList(ddlFSAPlanName5, FSAPlanList, ddlFSABenefitSummary5, null, null);
                        FillDropdownList(ddlFSAPlanName6, FSAPlanList, ddlFSABenefitSummary6, null, null);
                        break;

                    case "_":

                        tblFSA_1.Visible = false;
                        tblFSA_2.Visible = false;
                        tblFSA_3.Visible = false;
                        tblFSA_4.Visible = false;
                        tblFSA_5.Visible = false;
                        tblFSA_6.Visible = false;
                        break;
                }//SwitchClose

                //////if (ddlFSANoOfPlan.SelectedIndex == 1)
                //////{
                //////    tblFSA_1.Visible = true;
                //////    //ddlFSAPlanName.DataSource = FSAPlanList;
                //////    //ddlFSAPlanName.DataBind();
                //////    //ddlFSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                //////    FillDropdownList(ddlFSAPlanName, FSAPlanList, ddlFSABenefitSummary, null, null);
                //////}
                //////else
                //////{
                //////    tblFSA_1.Visible = false;
                //////}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlFSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                FSAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlFSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName.SelectedValue), ddlFSABenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary, null);
            }
        }

        protected void ddlFSAPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName2.SelectedValue), ddlFSABenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary2, null);
            }
        }
        protected void ddlFSAPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName3.SelectedValue), ddlFSABenefitSummary3, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary3, null);
            }
        }
        protected void ddlFSAPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName4.SelectedValue), ddlFSABenefitSummary4, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary4, null);
            }
        }
        protected void ddlFSAPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName5.SelectedValue), ddlFSABenefitSummary5, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary5, null);
            }
        }
        protected void ddlFSAPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlFSAPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlFSAPlanName6.SelectedValue), ddlFSABenefitSummary6, null, null);
            }
            else
            {
                ClearDropDownList(ddlFSABenefitSummary6, null);
            }
        }


        /*------------------STOP LOSS PLAN ---------------------*/

        private void StopLossPlanSelected()
        {
            try
            {
                List<Plan> StopLossPlanList = new List<Plan>();
                if (ddlStopNoOfPlan.SelectedIndex == 0)
                {
                    ClearStopLoss();
                    if (ddlStopPlanName != null)
                    {
                        ddlStopPlanName.Items.Clear();
                    }
                    if (ddlStopPlanName2 != null)
                    {
                        ddlStopPlanName2.Items.Clear();
                    }
                    if (ddlStopPlanName3 != null)
                    {
                        ddlStopPlanName3.Items.Clear();
                    }
                    if (ddlStopPlanName4 != null)
                    {
                        ddlStopPlanName4.Items.Clear();
                    }
                    if (ddlStopPlanName5 != null)
                    {
                        ddlStopPlanName5.Items.Clear();
                    }
                    if (ddlStopPlanName6 != null)
                    {
                        ddlStopPlanName6.Items.Clear();
                    }
                }

                string ch = ddlStopNoOfPlan.SelectedItem.Text;
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.StopLossPlanTypeList, cv.StopLoss, ref StopLossPlanList);

                switch (ch)
                {
                    case "1":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = false;
                        tblStop_3.Visible = false;
                        tblStop_4.Visible = false;
                        tblStop_5.Visible = false;
                        tblStop_6.Visible = false;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);

                        ddlStopPlanName2.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary2, null);
                        ddlStopPlanName3.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary3, null);
                        ddlStopPlanName4.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary4, null);
                        ddlStopPlanName5.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary5, null);
                        ddlStopPlanName6.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary6, null);
                        break;

                    case "2":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = true;
                        tblStop_3.Visible = false;
                        tblStop_4.Visible = false;
                        tblStop_5.Visible = false;
                        tblStop_6.Visible = false;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);
                        FillDropdownList(ddlStopPlanName2, StopLossPlanList, ddlStopBenefitSummary2, null, null);


                        ddlStopPlanName3.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary3, null);
                        ddlStopPlanName4.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary4, null);
                        ddlStopPlanName5.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary5, null);
                        ddlStopPlanName6.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary6, null);
                        break;
                    case "3":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = true;
                        tblStop_3.Visible = true;
                        tblStop_4.Visible = false;
                        tblStop_5.Visible = false;
                        tblStop_6.Visible = false;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);
                        FillDropdownList(ddlStopPlanName2, StopLossPlanList, ddlStopBenefitSummary2, null, null);
                        FillDropdownList(ddlStopPlanName3, StopLossPlanList, ddlStopBenefitSummary3, null, null);


                        ddlStopPlanName4.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary4, null);
                        ddlStopPlanName5.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary5, null);
                        ddlStopPlanName6.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary6, null);
                        break;
                    case "4":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = true;
                        tblStop_3.Visible = true;
                        tblStop_4.Visible = true;
                        tblStop_5.Visible = false;
                        tblStop_6.Visible = false;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);
                        FillDropdownList(ddlStopPlanName2, StopLossPlanList, ddlStopBenefitSummary2, null, null);
                        FillDropdownList(ddlStopPlanName3, StopLossPlanList, ddlStopBenefitSummary3, null, null);
                        FillDropdownList(ddlStopPlanName4, StopLossPlanList, ddlStopBenefitSummary4, null, null);

                        ddlStopPlanName5.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary5, null);
                        ddlStopPlanName6.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary6, null);
                        break;
                    case "5":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = true;
                        tblStop_3.Visible = true;
                        tblStop_4.Visible = true;
                        tblStop_5.Visible = true;
                        tblStop_6.Visible = false;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);
                        FillDropdownList(ddlStopPlanName2, StopLossPlanList, ddlStopBenefitSummary2, null, null);
                        FillDropdownList(ddlStopPlanName3, StopLossPlanList, ddlStopBenefitSummary3, null, null);
                        FillDropdownList(ddlStopPlanName4, StopLossPlanList, ddlStopBenefitSummary4, null, null);
                        FillDropdownList(ddlStopPlanName5, StopLossPlanList, ddlStopBenefitSummary5, null, null);

                        ddlStopPlanName6.Items.Clear();
                        ClearDropDownList(ddlStopBenefitSummary6, null);
                        break;
                    case "6":
                        tblStop_1.Visible = true;
                        tblStop_2.Visible = true;
                        tblStop_3.Visible = true;
                        tblStop_4.Visible = true;
                        tblStop_5.Visible = true;
                        tblStop_6.Visible = true;

                        FillDropdownList(ddlStopPlanName, StopLossPlanList, ddlStopBenefitSummary, null, null);
                        FillDropdownList(ddlStopPlanName2, StopLossPlanList, ddlStopBenefitSummary2, null, null);
                        FillDropdownList(ddlStopPlanName3, StopLossPlanList, ddlStopBenefitSummary3, null, null);
                        FillDropdownList(ddlStopPlanName4, StopLossPlanList, ddlStopBenefitSummary4, null, null);
                        FillDropdownList(ddlStopPlanName5, StopLossPlanList, ddlStopBenefitSummary5, null, null);
                        FillDropdownList(ddlStopPlanName6, StopLossPlanList, ddlStopBenefitSummary6, null, null);
                        break;
                    case "_":

                        tblStop_1.Visible = false;
                        tblStop_2.Visible = false;
                        tblStop_3.Visible = false;
                        tblStop_4.Visible = false;
                        tblStop_5.Visible = false;
                        tblStop_6.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }//MethodClsoe

        protected void ddlStopNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                StopLossPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlStopPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName.SelectedValue), ddlStopBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary, null);
            }
        }

        protected void ddlStopPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName2.SelectedValue), ddlStopBenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary2, null);
            }
        }
        protected void ddlStopPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName3.SelectedValue), ddlStopBenefitSummary3, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary3, null);
            }
        }
        protected void ddlStopPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName4.SelectedValue), ddlStopBenefitSummary4, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary4, null);
            }
        }
        protected void ddlStopPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName5.SelectedValue), ddlStopBenefitSummary5, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary5, null);
            }
        }
        protected void ddlStopPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStopPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlStopPlanName6.SelectedValue), ddlStopBenefitSummary6, null, null);
            }
            else
            {
                ClearDropDownList(ddlStopBenefitSummary6, null);
            }
        }

        /*------------------ Prescription Drug ---------------------*/
        private void PrescriptionPlanPlanSelected()
        {
            try
            {
                List<Plan> PrescriptionDrugPlanList = new List<Plan>();
                if (ddlPrescriptionNoOfPlan.SelectedIndex == 0)
                {
                    ClearPrescriptionDrug();
                    if (ddlPrescriptionPlanName != null)
                    {
                        ddlPrescriptionPlanName.Items.Clear();
                    }
                    if (ddlPrescriptionPlanName2 != null)
                    {
                        ddlPrescriptionPlanName2.Items.Clear();
                    }
                    if (ddlPrescriptionPlanName3 != null)
                    {
                        ddlPrescriptionPlanName3.Items.Clear();
                    }
                    if (ddlPrescriptionPlanName4 != null)
                    {
                        ddlPrescriptionPlanName4.Items.Clear();
                    }
                    if (ddlPrescriptionPlanName5 != null)
                    {
                        ddlPrescriptionPlanName5.Items.Clear();
                    }
                    if (ddlPrescriptionPlanName6 != null)
                    {
                        ddlPrescriptionPlanName6.Items.Clear();
                    }
                }

                string ch = ddlPrescriptionNoOfPlan.SelectedItem.Text;
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.PrescriptionDrugPlanTypeList, cv.PrescriptionDrug, ref PrescriptionDrugPlanList);

                switch (ch)
                {
                    case "1":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = false;
                        tblPrescription_3.Visible = false;
                        tblPrescription_4.Visible = false;
                        tblPrescription_5.Visible = false;
                        tblPrescription_6.Visible = false;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);

                        ddlPrescriptionPlanName2.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary2, null);
                        ddlPrescriptionPlanName3.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary3, null);
                        ddlPrescriptionPlanName4.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary4, null);
                        ddlPrescriptionPlanName5.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
                        ddlPrescriptionPlanName6.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
                        break;
                    case "2":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = true;
                        tblPrescription_3.Visible = false;
                        tblPrescription_4.Visible = false;
                        tblPrescription_5.Visible = false;
                        tblPrescription_6.Visible = false;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);
                        FillDropdownList(ddlPrescriptionPlanName2, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary2, null, null);


                        ddlPrescriptionPlanName3.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary3, null);
                        ddlPrescriptionPlanName4.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary4, null);
                        ddlPrescriptionPlanName5.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
                        ddlPrescriptionPlanName6.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
                        break;
                    case "3":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = true;
                        tblPrescription_3.Visible = true;
                        tblPrescription_4.Visible = false;
                        tblPrescription_5.Visible = false;
                        tblPrescription_6.Visible = false;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);
                        FillDropdownList(ddlPrescriptionPlanName2, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary2, null, null);
                        FillDropdownList(ddlPrescriptionPlanName3, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary3, null, null);

                        ddlPrescriptionPlanName4.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary4, null);
                        ddlPrescriptionPlanName5.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
                        ddlPrescriptionPlanName6.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
                        break;
                    case "4":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = true;
                        tblPrescription_3.Visible = true;
                        tblPrescription_4.Visible = true;
                        tblPrescription_5.Visible = false;
                        tblPrescription_6.Visible = false;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);
                        FillDropdownList(ddlPrescriptionPlanName2, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary2, null, null);
                        FillDropdownList(ddlPrescriptionPlanName3, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary3, null, null);
                        FillDropdownList(ddlPrescriptionPlanName4, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary4, null, null);

                        ddlPrescriptionPlanName5.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
                        ddlPrescriptionPlanName6.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
                        break;
                    case "5":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = true;
                        tblPrescription_3.Visible = true;
                        tblPrescription_4.Visible = true;
                        tblPrescription_5.Visible = true;
                        tblPrescription_6.Visible = false;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);
                        FillDropdownList(ddlPrescriptionPlanName2, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary2, null, null);
                        FillDropdownList(ddlPrescriptionPlanName3, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary3, null, null);
                        FillDropdownList(ddlPrescriptionPlanName4, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary4, null, null);
                        FillDropdownList(ddlPrescriptionPlanName5, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary5, null, null);

                        ddlPrescriptionPlanName6.Items.Clear();
                        ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
                        break;
                    case "6":
                        tblPrescription_1.Visible = true;
                        tblPrescription_2.Visible = true;
                        tblPrescription_3.Visible = true;
                        tblPrescription_4.Visible = true;
                        tblPrescription_5.Visible = true;
                        tblPrescription_6.Visible = true;

                        FillDropdownList(ddlPrescriptionPlanName, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary, null, null);
                        FillDropdownList(ddlPrescriptionPlanName2, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary2, null, null);
                        FillDropdownList(ddlPrescriptionPlanName3, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary3, null, null);
                        FillDropdownList(ddlPrescriptionPlanName4, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary4, null, null);
                        FillDropdownList(ddlPrescriptionPlanName5, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary5, null, null);
                        FillDropdownList(ddlPrescriptionPlanName6, PrescriptionDrugPlanList, ddlPrescriptionBenefitSummary6, null, null);
                        break;
                    case "_":
                        tblPrescription_1.Visible = false;
                        tblPrescription_2.Visible = false;
                        tblPrescription_3.Visible = false;
                        tblPrescription_4.Visible = false;
                        tblPrescription_5.Visible = false;
                        tblPrescription_6.Visible = false;
                        break;
                }//SwitchClose
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlPrescriptionNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PrescriptionPlanPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlPrescriptionPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName.SelectedValue), ddlPrescriptionBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary, null);
            }
        }

        protected void ddlPrescriptionPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName2.SelectedValue), ddlPrescriptionBenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary2, null);
            }
        }
        protected void ddlPrescriptionPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName3.SelectedValue), ddlPrescriptionBenefitSummary3, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary3, null);
            }
        }
        protected void ddlPrescriptionPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName4.SelectedValue), ddlPrescriptionBenefitSummary4, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary4, null);
            }
        }
        protected void ddlPrescriptionPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName5.SelectedValue), ddlPrescriptionBenefitSummary5, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
            }
        }
        protected void ddlPrescriptionPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlPrescriptionPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlPrescriptionPlanName6.SelectedValue), ddlPrescriptionBenefitSummary6, null, null);
            }
            else
            {
                ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
            }
        }


        private void HSAPlanSelected()
        {
            try
            {
                if (ddlHSANoOfPlan.SelectedIndex == 0)
                {
                    ClearHSA();
                    if (ddlHSAPlanName != null)
                    {
                        ddlHSAPlanName.Items.Clear();
                    }
                    if (ddlHSAPlanName2 != null)
                    {
                        ddlHSAPlanName2.Items.Clear();
                    }
                    if (ddlHSAPlanName3 != null)
                    {
                        ddlHSAPlanName3.Items.Clear();
                    }
                    if (ddlHSAPlanName4 != null)
                    {
                        ddlHSAPlanName4.Items.Clear();
                    }
                    if (ddlHSAPlanName5 != null)
                    {
                        ddlHSAPlanName5.Items.Clear();
                    }
                    if (ddlHSAPlanName6 != null)
                    {
                        ddlHSAPlanName6.Items.Clear();
                    }
                }

                List<Plan> HSAPlanList = new List<Plan>();
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HSAPlanTypeList, cv.HSAPlanType_CommonCriteria, ref HSAPlanList);
                string ch = ddlHSANoOfPlan.SelectedItem.Text;

                switch (ch)
                {
                    case "1":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = false;
                        tblHSA_3.Visible = false;
                        tblHSA_4.Visible = false;
                        tblHSA_5.Visible = false;
                        tblHSA_6.Visible = false;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);

                        ddlHSAPlanName2.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary2, null);
                        ddlHSAPlanName3.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary3, null);
                        ddlHSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary4, null);
                        ddlHSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary5, null);
                        ddlHSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary6, null);

                        break;

                    case "2":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = true;
                        tblHSA_3.Visible = false;
                        tblHSA_4.Visible = false;
                        tblHSA_5.Visible = false;
                        tblHSA_6.Visible = false;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                        FillDropdownList(ddlHSAPlanName2, HSAPlanList, ddlHSABenefitSummary2, null, null);

                        ddlHSAPlanName3.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary3, null);
                        ddlHSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary4, null);
                        ddlHSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary5, null);
                        ddlHSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary6, null);

                        break;

                    case "3":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = true;
                        tblHSA_3.Visible = true;
                        tblHSA_4.Visible = false;
                        tblHSA_5.Visible = false;
                        tblHSA_6.Visible = false;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                        FillDropdownList(ddlHSAPlanName2, HSAPlanList, ddlHSABenefitSummary2, null, null);
                        FillDropdownList(ddlHSAPlanName3, HSAPlanList, ddlHSABenefitSummary3, null, null);


                        ddlHSAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary4, null);
                        ddlHSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary5, null);
                        ddlHSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary6, null);

                        break;

                    case "4":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = true;
                        tblHSA_3.Visible = true;
                        tblHSA_4.Visible = true;
                        tblHSA_5.Visible = false;
                        tblHSA_6.Visible = false;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                        FillDropdownList(ddlHSAPlanName2, HSAPlanList, ddlHSABenefitSummary2, null, null);
                        FillDropdownList(ddlHSAPlanName3, HSAPlanList, ddlHSABenefitSummary3, null, null);
                        FillDropdownList(ddlHSAPlanName4, HSAPlanList, ddlHSABenefitSummary4, null, null);

                        ddlHSAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary5, null);
                        ddlHSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary6, null);

                        break;

                    case "5":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = true;
                        tblHSA_3.Visible = true;
                        tblHSA_4.Visible = true;
                        tblHSA_5.Visible = true;
                        tblHSA_6.Visible = false;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                        FillDropdownList(ddlHSAPlanName2, HSAPlanList, ddlHSABenefitSummary2, null, null);
                        FillDropdownList(ddlHSAPlanName3, HSAPlanList, ddlHSABenefitSummary3, null, null);
                        FillDropdownList(ddlHSAPlanName4, HSAPlanList, ddlHSABenefitSummary4, null, null);
                        FillDropdownList(ddlHSAPlanName5, HSAPlanList, ddlHSABenefitSummary5, null, null);

                        ddlHSAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHSABenefitSummary6, null);

                        break;

                    case "6":
                        tblHSA_1.Visible = true;
                        tblHSA_2.Visible = true;
                        tblHSA_3.Visible = true;
                        tblHSA_4.Visible = true;
                        tblHSA_5.Visible = true;
                        tblHSA_6.Visible = true;

                        FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                        FillDropdownList(ddlHSAPlanName2, HSAPlanList, ddlHSABenefitSummary2, null, null);
                        FillDropdownList(ddlHSAPlanName3, HSAPlanList, ddlHSABenefitSummary3, null, null);
                        FillDropdownList(ddlHSAPlanName4, HSAPlanList, ddlHSABenefitSummary4, null, null);
                        FillDropdownList(ddlHSAPlanName5, HSAPlanList, ddlHSABenefitSummary5, null, null);
                        FillDropdownList(ddlHSAPlanName6, HSAPlanList, ddlHSABenefitSummary6, null, null);

                        break;

                    case "_":
                        tblHSA_1.Visible = false;
                        tblHSA_2.Visible = false;
                        tblHSA_3.Visible = false;
                        tblHSA_4.Visible = false;
                        tblHSA_5.Visible = false;
                        tblHSA_6.Visible = false;
                        break;

                }//SwitchClose


                //////if (ddlHSANoOfPlan.SelectedIndex == 1)
                //////{
                //////    List<Plan> HSAPlanList = new List<Plan>();
                //////    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HSAPlanTypeList, cv.HSAPlanType_CommonCriteria, ref HSAPlanList);
                //////    tblHSA_1.Visible = true;
                //////    //ddlHSAPlanName.DataSource = HSAPlanList;
                //////    //ddlHSAPlanName.DataBind();
                //////    //ddlHSAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                //////    FillDropdownList(ddlHSAPlanName, HSAPlanList, ddlHSABenefitSummary, null, null);
                //////}
                //////else
                //////{
                //////    tblHSA_1.Visible = false;
                //////}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHSANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HSAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHSAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName.SelectedValue), ddlHSABenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary, null);
            }
        }

        protected void ddlHSAPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName2.SelectedValue), ddlHSABenefitSummary2, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary2, null);
            }
        }
        protected void ddlHSAPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName3.SelectedValue), ddlHSABenefitSummary3, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary3, null);
            }
        }
        protected void ddlHSAPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName4.SelectedValue), ddlHSABenefitSummary4, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary4, null);
            }
        }
        protected void ddlHSAPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName5.SelectedValue), ddlHSABenefitSummary5, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary5, null);
            }
        }
        protected void ddlHSAPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHSAPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHSAPlanName6.SelectedValue), ddlHSABenefitSummary6, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHSABenefitSummary6, null);
            }
        }

        private void HRAPlanSelected()
        {
            try
            {
                if (ddlHRANoOfPlan.SelectedIndex == 0)
                {
                    ClearHRA();
                    if (ddlHRAPlanName != null)
                    {
                        ddlHRAPlanName.Items.Clear();
                    }
                    if (ddlHRAPlanName2 != null)
                    {
                        ddlHRAPlanName2.Items.Clear();
                    }
                    if (ddlHRAPlanName3 != null)
                    {
                        ddlHRAPlanName3.Items.Clear();
                    }
                    if (ddlHRAPlanName4 != null)
                    {
                        ddlHRAPlanName4.Items.Clear();
                    }
                    if (ddlHRAPlanName5 != null)
                    {
                        ddlHRAPlanName5.Items.Clear();
                    }
                    if (ddlHRAPlanName6 != null)
                    {
                        ddlHRAPlanName6.Items.Clear();
                    }
                }


                List<Plan> HRAPlanList = new List<Plan>();
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HRAPlanTypeList, cv.HRAPlanType_CommonCriteria, ref HRAPlanList);
                string ch = ddlHRANoOfPlan.SelectedItem.Text;

                switch (ch)
                {
                    case "1":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = false;
                        tblHRA_3.Visible = false;
                        tblHRA_4.Visible = false;
                        tblHRA_5.Visible = false;
                        tblHRA_6.Visible = false;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);

                        ddlHRAPlanName2.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary2, null);
                        ddlHRAPlanName3.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary3, null);
                        ddlHRAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary4, null);
                        ddlHRAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);
                        ddlHRAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);

                        break;

                    case "2":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = true;
                        tblHRA_3.Visible = false;
                        tblHRA_4.Visible = false;
                        tblHRA_5.Visible = false;
                        tblHRA_6.Visible = false;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                        FillDropdownList(ddlHRAPlanName2, HRAPlanList, ddlHRABenefitSummary2, null, null);

                        ddlHRAPlanName3.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary3, null);
                        ddlHRAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary4, null);
                        ddlHRAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);
                        ddlHRAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);

                        break;

                    case "3":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = true;
                        tblHRA_3.Visible = true;
                        tblHRA_4.Visible = false;
                        tblHRA_5.Visible = false;
                        tblHRA_6.Visible = false;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                        FillDropdownList(ddlHRAPlanName2, HRAPlanList, ddlHRABenefitSummary2, null, null);
                        FillDropdownList(ddlHRAPlanName3, HRAPlanList, ddlHRABenefitSummary3, null, null);


                        ddlHRAPlanName4.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary4, null);
                        ddlHRAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);
                        ddlHRAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary6, null);

                        break;

                    case "4":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = true;
                        tblHRA_3.Visible = true;
                        tblHRA_4.Visible = true;
                        tblHRA_5.Visible = false;
                        tblHRA_6.Visible = false;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                        FillDropdownList(ddlHRAPlanName2, HRAPlanList, ddlHRABenefitSummary2, null, null);
                        FillDropdownList(ddlHRAPlanName3, HRAPlanList, ddlHRABenefitSummary3, null, null);
                        FillDropdownList(ddlHRAPlanName4, HRAPlanList, ddlHRABenefitSummary4, null, null);

                        ddlHRAPlanName5.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary5, null);
                        ddlHRAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary6, null);

                        break;

                    case "5":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = true;
                        tblHRA_3.Visible = true;
                        tblHRA_4.Visible = true;
                        tblHRA_5.Visible = true;
                        tblHRA_6.Visible = false;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                        FillDropdownList(ddlHRAPlanName2, HRAPlanList, ddlHRABenefitSummary2, null, null);
                        FillDropdownList(ddlHRAPlanName3, HRAPlanList, ddlHRABenefitSummary3, null, null);
                        FillDropdownList(ddlHRAPlanName4, HRAPlanList, ddlHRABenefitSummary4, null, null);
                        FillDropdownList(ddlHRAPlanName5, HRAPlanList, ddlHRABenefitSummary5, null, null);

                        ddlHRAPlanName6.Items.Clear();
                        ClearDropDownList(ddlHRABenefitSummary6, null);

                        break;

                    case "6":
                        tblHRA_1.Visible = true;
                        tblHRA_2.Visible = true;
                        tblHRA_3.Visible = true;
                        tblHRA_4.Visible = true;
                        tblHRA_5.Visible = true;
                        tblHRA_6.Visible = true;

                        FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                        FillDropdownList(ddlHRAPlanName2, HRAPlanList, ddlHRABenefitSummary2, null, null);
                        FillDropdownList(ddlHRAPlanName3, HRAPlanList, ddlHRABenefitSummary3, null, null);
                        FillDropdownList(ddlHRAPlanName4, HRAPlanList, ddlHRABenefitSummary4, null, null);
                        FillDropdownList(ddlHRAPlanName5, HRAPlanList, ddlHRABenefitSummary5, null, null);
                        FillDropdownList(ddlHRAPlanName6, HRAPlanList, ddlHRABenefitSummary6, null, null);

                        break;
                    case "_":
                        tblHRA_1.Visible = false;
                        tblHRA_2.Visible = false;
                        tblHRA_3.Visible = false;
                        tblHRA_4.Visible = false;
                        tblHRA_5.Visible = false;
                        tblHRA_6.Visible = false;
                        break;

                }//SwitchClose


                ////if (ddlHRANoOfPlan.SelectedIndex == 1)
                ////{
                ////    List<Plan> HRAPlanList = new List<Plan>();

                ////    GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.HRAPlanTypeList, cv.HRAPlanType_CommonCriteria, ref HRAPlanList);

                ////    tblHRA_1.Visible = true;

                ////    //    ddlHRAPlanName.DataSource = HRAPlanList;
                ////    //    ddlHRAPlanName.DataBind();
                ////    //    ddlHRAPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                ////    FillDropdownList(ddlHRAPlanName, HRAPlanList, ddlHRABenefitSummary, null, null);
                ////}
                ////else
                ////{
                ////    tblHRA_1.Visible = false;
                ////}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHRANoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HRAPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlHRAPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName.SelectedValue), ddlHRABenefitSummary, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary, null);
            }
        }

        protected void ddlHRAPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName2.SelectedValue), ddlHRABenefitSummary2, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary2, null);
            }
        }
        protected void ddlHRAPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName3.SelectedValue), ddlHRABenefitSummary3, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary3, null);
            }
        }
        protected void ddlHRAPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName4.SelectedValue), ddlHRABenefitSummary4, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary4, null);
            }
        }
        protected void ddlHRAPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName5.SelectedValue), ddlHRABenefitSummary5, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary5, null);
            }
        }
        protected void ddlHRAPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHRAPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlHRAPlanName6.SelectedValue), ddlHRABenefitSummary6, null, null, null);
            }
            else
            {
                ClearDropDownList(ddlHRABenefitSummary6, null);
            }
        }

        private void FillDropdownList(DropDownList ddl, List<Plan> PlanList, DropDownList ddlBenefitSummary, DropDownList ddlContribution1, DropDownList ddlContribution1_2, DropDownList ddlRate = null)
        {
            try
            {
                string selected_Value = string.Empty;
                string BenefitSummary_Selected_Value = string.Empty;
                string Contribution1_Selected_Value = string.Empty;
                string Contribution1_2_Selected_Value = string.Empty;
                string Rate_Selected_Value = string.Empty;

                if (ddl != null)
                {
                    selected_Value = Convert.ToString(ddl.SelectedValue);
                }
                if (ddlBenefitSummary != null)
                {
                    BenefitSummary_Selected_Value = Convert.ToString(ddlBenefitSummary.SelectedValue);
                }
                if (ddlContribution1 != null)
                {
                    Contribution1_Selected_Value = Convert.ToString(ddlContribution1.SelectedValue);
                }
                if (ddlContribution1_2 != null)
                {
                    Contribution1_2_Selected_Value = Convert.ToString(ddlContribution1_2.SelectedValue);
                }
                if (ddlRate != null)
                {
                    Rate_Selected_Value = Convert.ToString(ddlRate.SelectedValue);
                }

                ddl.Items.Clear();
                ddl.DataSource = PlanList;
                ddl.DataBind();
                ddl.Items.Insert(0, new ListItem("Select", "0"));


                if (ddl != null)
                {
                    ddl.SelectedIndex = ddl.Items.IndexOf(ddl.Items.FindByValue(selected_Value));
                }

                if (ddl.SelectedIndex > 0)
                {
                    BindDataToPlan(int.Parse(ddl.SelectedValue), ddlBenefitSummary, ddlContribution1, null, ddlRate, ddlContribution1_2);
                }
                else
                {
                    ClearDropDownList(ddlBenefitSummary, ddlContribution1, ddlContribution1_2);
                }

                if (ddlBenefitSummary != null)
                {
                    ddlBenefitSummary.SelectedIndex = ddlBenefitSummary.Items.IndexOf(ddlBenefitSummary.Items.FindByValue(BenefitSummary_Selected_Value));
                }
                if (ddlContribution1 != null)
                {
                    ddlContribution1.SelectedIndex = ddlContribution1.Items.IndexOf(ddlContribution1.Items.FindByValue(Contribution1_Selected_Value));
                }
                if (ddlContribution1_2 != null)
                {
                    ddlContribution1_2.SelectedIndex = ddlContribution1_2.Items.IndexOf(ddlContribution1_2.Items.FindByValue(Contribution1_2_Selected_Value));
                }
                if (ddlRate != null)
                {
                    ddlRate.SelectedIndex = ddlRate.Items.IndexOf(ddlRate.Items.FindByValue(Rate_Selected_Value));
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void FillAdditionalProduct_DropdownList(DropDownList ddl, List<Plan> PlanList)
        {
            try
            {
                string selected_Value = string.Empty;
                string BenefitSummary_Selected_Value = string.Empty;
                string Contribution1_Selected_Value = string.Empty;
                string Contribution1_2_Selected_Value = string.Empty;
                string Rate_Selected_Value = string.Empty;

                if (ddl != null)
                {
                    selected_Value = Convert.ToString(ddl.SelectedValue);
                }
                //if (ddlBenefitSummary != null)
                //{
                //    BenefitSummary_Selected_Value = Convert.ToString(ddlBenefitSummary.SelectedValue);
                //}
                //if (ddlContribution1 != null)
                //{
                //    Contribution1_Selected_Value = Convert.ToString(ddlContribution1.SelectedValue);
                //}
                //if (ddlContribution1_2 != null)
                //{
                //    Contribution1_2_Selected_Value = Convert.ToString(ddlContribution1_2.SelectedValue);
                //}
                //if (ddlRate != null)
                //{
                //    Rate_Selected_Value = Convert.ToString(ddlRate.SelectedValue);
                //}

                ddl.Items.Clear();
                ddl.DataSource = PlanList;
                ddl.DataBind();
                ddl.Items.Insert(0, new ListItem("Select", "0"));


                if (ddl != null)
                {
                    ddl.SelectedIndex = ddl.Items.IndexOf(ddl.Items.FindByValue(selected_Value));
                }

                //if (ddl.SelectedIndex > 0)
                //{
                //    BindDataToPlan(int.Parse(ddl.SelectedValue), ddlBenefitSummary, ddlContribution1, null, ddlRate, ddlContribution1_2);
                //}
                //else
                //{
                //    ClearDropDownList(ddlBenefitSummary, ddlContribution1, ddlContribution1_2);
                //}

                //if (ddlBenefitSummary != null)
                //{
                //    ddlBenefitSummary.SelectedIndex = ddlBenefitSummary.Items.IndexOf(ddlBenefitSummary.Items.FindByValue(BenefitSummary_Selected_Value));
                //}
                //if (ddlContribution1 != null)
                //{
                //    ddlContribution1.SelectedIndex = ddlContribution1.Items.IndexOf(ddlContribution1.Items.FindByValue(Contribution1_Selected_Value));
                //}
                //if (ddlContribution1_2 != null)
                //{
                //    ddlContribution1_2.SelectedIndex = ddlContribution1_2.Items.IndexOf(ddlContribution1_2.Items.FindByValue(Contribution1_2_Selected_Value));
                //}
                //if (ddlRate != null)
                //{
                //    ddlRate.SelectedIndex = ddlRate.Items.IndexOf(ddlRate.Items.FindByValue(Rate_Selected_Value));
                //}
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PlanTypeId">Select Plan TypeId</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>
        protected void BindDataToPlan(int PlanTypeId, DropDownList Benefit, DropDownList Contribution, DropDownList Eligibility, DropDownList Rate = null, DropDownList Contribution_2 = null)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
                List<Rate> RateList = new List<Rate>();
                List<Contribution> ContributionList = new List<Contribution>();
                List<Eligibility> EligibilityList = new List<Eligibility>();

                SessionId = Session["SessionId"].ToString();

                if (ddlClient.SelectedIndex > 0)
                {
                    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), PlanTypeId, SessionId);
                    Benefit.DataSource = BenefitSummaryList;
                    Benefit.DataBind();
                    Benefit.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Rate != null)
                {
                    RateList = bp.FindRates(PlanTypeId, SessionId);
                    Rate.DataSource = RateList;
                    Rate.DataBind();
                    Rate.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution != null)
                {
                    ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution.DataSource = ContributionList;
                    Contribution.DataBind();
                    Contribution.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution_2 != null)
                {
                    // ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution_2.DataSource = ContributionList;
                    Contribution_2.DataBind();
                    Contribution_2.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Eligibility != null)
                {
                    EligibilityList = bp.FindEligibility(PlanTypeId, SessionId);//(4765506);
                    Eligibility.DataSource = EligibilityList;
                    Eligibility.DataBind();
                    Eligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                }

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void BindDataToPlan(int PlanTypeId, DropDownList Benefit, DropDownList Rate, DropDownList Contribution, DropDownList Eligibility)
        {
            try
            {
                BPBusiness bp = new BPBusiness();

                List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
                List<Rate> RateList = new List<Rate>();
                List<Contribution> ContributionList = new List<Contribution>();
                List<Eligibility> EligibilityList = new List<Eligibility>();

                SessionId = Session["SessionId"].ToString();

                if (ddlClient.SelectedIndex > 0)
                {
                    BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), PlanTypeId, SessionId);
                    Benefit.DataSource = BenefitSummaryList;
                    Benefit.DataBind();
                    Benefit.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Rate != null)
                {
                    RateList = bp.FindRates(PlanTypeId, SessionId);
                    Rate.DataSource = RateList;
                    Rate.DataBind();
                    Rate.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Contribution != null)
                {
                    ContributionList = bp.FindContributions(PlanTypeId, SessionId);//(4765506);
                    Contribution.DataSource = ContributionList;
                    Contribution.DataBind();
                    Contribution.Items.Insert(0, new ListItem("Select", string.Empty));
                }
                if (Eligibility != null)
                {
                    EligibilityList = bp.FindEligibility(PlanTypeId, SessionId);//(4765506);
                    Eligibility.DataSource = EligibilityList;
                    Eligibility.DataBind();
                    Eligibility.Items.Insert(0, new ListItem("Select", string.Empty));
                }


            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        private void GetPlanDetailsForSelectedPlanSections(List<int> planTypeList, string planName, ref List<Plan> planList)
        {
            try
            {
                Plan PlanItem = new Plan();

                foreach (DataRow dr in PlanInfoTable.Rows)
                {
                    if (planTypeList.Contains(Convert.ToInt16(dr["ProductTypeId"])))
                    {
                        PlanItem = new Plan();
                        // PlanItem.CarrierId 
                        // PlanItem.ProductStatus 
                        // PlanItem.ProductStatusCurrent 
                        // PlanItem.ProductStatusPending 
                        // PlanItem.RateList 
                        // PlanItem.SummaryID 
                        // PlanItem.SummaryName 

                        PlanItem.CarrierName = Convert.ToString(dr["Carrier"]);
                        PlanItem.EffectiveDate = Convert.ToDateTime(dr["Effective"]);
                        PlanItem.LOC = planName;
                        PlanItem.PolicyNumber = Convert.ToString(dr["PolicyNumber"]);
                        PlanItem.ProductId = Convert.ToInt32(dr["ProductId"]);
                        PlanItem.ProductName = Convert.ToString(dr["ProductName"].ToString().Replace("&amp;", "&"));
                        PlanItem.ProductTypeDescription = Convert.ToString(dr["Name"]);
                        PlanItem.ProductTypeId = Convert.ToInt16(dr["ProductTypeId"]);
                        PlanItem.RenewalDate = Convert.ToDateTime(dr["Renewal"]);

                        planList.Add(PlanItem);
                    }
                }

                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in planList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = item.LOC;

                    ProductSummaryTable.Rows.Add(dr);

                }
                Session["ProductSummaryTable"] = ProductSummaryTable;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Product Summary Table of selected Plan.
        /// </summary>
        /// <returns> ProductSummaryTable</returns>
        protected DataTable CreateProductSummaryTable()
        {
            DataTable ProductSummaryTable = new DataTable();
            try
            {
                if (Session["ProductSummaryTable"] != null)
                {
                    ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];
                }
                else
                {
                    ProductSummaryTable.Columns.Add("ProductId", typeof(Int32));
                    ProductSummaryTable.Columns.Add("ProductName", typeof(string));
                    ProductSummaryTable.Columns.Add("Carrier", typeof(string));
                    ProductSummaryTable.Columns.Add("Effective", typeof(string));
                    ProductSummaryTable.Columns.Add("Renewal", typeof(string));
                    ProductSummaryTable.Columns.Add("PolicyNumber", typeof(string));
                    ProductSummaryTable.Columns.Add("ProductTypeDescription", typeof(string));
                    ProductSummaryTable.Columns.Add("PlanType", typeof(string));
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return ProductSummaryTable;
        }

        /*-------------------------------------------------------------------------------------------------------------------------------------------
         *This is Link Button which show & hide the Plan control section i.e if user click on Medical Plan on plan page medical section will appers.
         *------------------------------------------------------------------------------------------------------------------------------------------*/
        protected void lnkPlanNames_Click(object sender, EventArgs e)
        {
            // Set the background color for all the links to "#E7EEF4"
            foreach (DataListItem item in dlPlan.Items)
            {
                LinkButton lnkPlanNames = item.FindControl("lnkPlanNames") as LinkButton;
                lnkPlanNames.BackColor = System.Drawing.ColorTranslator.FromHtml("#E7EEF4");
                lnkPlanNames.ForeColor = System.Drawing.Color.Black;
            }

            // Set the background color for selected linkbutton to "#7092BE"
            ((System.Web.UI.WebControls.LinkButton)(sender)).BackColor = System.Drawing.ColorTranslator.FromHtml("#7092BE");
            ((System.Web.UI.WebControls.LinkButton)(sender)).ForeColor = System.Drawing.Color.White;

            if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.MedicalLOC)
            {
                pnlMedical.Visible = true;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.DentalLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = true;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.VisionLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = true;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.LifeADDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = true;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.STDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = true;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.LTDLOC)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = true;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = true;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.EAPPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = true;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.FSAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = true;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlDisability.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.HRAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = true;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.HSAPlanType_CommonCriteria)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = true;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.Wellness)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = true;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.ADD)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = true;
                pnlGroupTermLife.Visible = false;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.GroupTermLifePlanType)
            {
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = true;
                pnlDisability.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.Disability)  /*-----Added by Amogh To show Disablity Section-*/
            {
                pnlDisability.Visible = true;
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.Accident)  /*-----Added by Amogh To show Disablity Section-*/
            {
                pnlDisability.Visible = false;
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = true;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;
            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.AdditionalProducts)  /*-----Added by Amogh To show AdditionalProducts Section-*/
            {
                pnlDisability.Visible = false;
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;   //Changed to false
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = false;

            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.StopLoss)  /*-----Added by Amogh To show Stop Loss Section-*/
            {
                pnlDisability.Visible = false;
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = true;
                pnlPrescriptionLoss.Visible = false;

            }
            else if (((System.Web.UI.WebControls.LinkButton)(sender)).Text == cv.PrescriptionDrug)  /*-----Added by Amogh To show Stop Loss Section-*/
            {
                pnlDisability.Visible = false;
                pnlMedical.Visible = false;
                pnlDental.Visible = false;
                pnlVision.Visible = false;
                pnlLifeADND.Visible = false;
                pnlSTD.Visible = false;
                pnlLTD.Visible = false;
                pnlVoluntaryLife.Visible = false;
                pnlEAP.Visible = false;
                pnlFSA.Visible = false;
                pnlHRA.Visible = false;
                pnlHSA.Visible = false;
                pnlWelness.Visible = false;
                pnlADND.Visible = false;
                pnlGroupTermLife.Visible = false;
                pnlAccidental.Visible = false;
                pnlAdditional.Visible = false;
                pnlStopLoss.Visible = false;
                pnlPrescriptionLoss.Visible = true;

            }
        }

        /// <summary>
        /// Clear Medical BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearMedical()
        {
            ClearDropDownList(ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalContribution1_2);
            ClearDropDownList(ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalContribution2_2);
            ClearDropDownList(ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalContribution3_2);
            ClearDropDownList(ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalContribution4_2);
            ClearDropDownList(ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalContribution5_2);
            ClearDropDownList(ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalContribution6_2);

            //Added by Amogh 
            ClearDropDownList(ddlMedicalRate1, ddlMedicalEligibility1);
            ClearDropDownList(ddlMedicalRate2, ddlMedicalEligibility2);
            ClearDropDownList(ddlMedicalRate3, ddlMedicalEligibility3);
            ClearDropDownList(ddlMedicalRate4, ddlMedicalEligibility4);
            ClearDropDownList(ddlMedicalRate5, ddlMedicalEligibility5);
            ClearDropDownList(ddlMedicalRate6, ddlMedicalEligibility6);

        }
        private void EnabledMedicalDropDown()
        {
            ddlMedicalContribution1.Enabled = true;
            ddlMedicalEligibility1.Enabled = true;
            ddlMedicalContribution1_2.Enabled = true;
            ddlMedicalRate1.Enabled = true;

            ddlMedicalContribution2.Enabled = true;
            ddlMedicalContribution2_2.Enabled = true;
            ddlMedicalRate2.Enabled = true;
            ddlMedicalEligibility2.Enabled = true;

            ddlMedicalContribution3.Enabled = true;
            ddlMedicalEligibility3.Enabled = true;
            ddlMedicalContribution3_2.Enabled = true;
            ddlMedicalRate3.Enabled = true;

            ddlMedicalContribution4.Enabled = true;
            ddlMedicalEligibility4.Enabled = true;
            ddlMedicalContribution4_2.Enabled = true;
            ddlMedicalRate4.Enabled = true;

            ddlMedicalContribution5.Enabled = true;
            ddlMedicalEligibility5.Enabled = true;
            ddlMedicalContribution5_2.Enabled = true;
            ddlMedicalRate5.Enabled = true;

            ddlMedicalContribution6.Enabled = true;
            ddlMedicalEligibility6.Enabled = true;
            ddlMedicalContribution6_2.Enabled = true;
            ddlMedicalRate6.Enabled = true;

        }

        /// <summary>
        /// Clear Dental BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearDental()
        {
            ClearDropDownList(ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalContribution1_2);
            ClearDropDownList(ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalContribution2_2);
            ClearDropDownList(ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalContribution3_2);
            ClearDropDownList(ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalContribution4_2);
            ClearDropDownList(ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalContribution5_2);
            ClearDropDownList(ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalContribution6_2);
            //Added by Amogh which clear Rate dropdown
            ClearDropDownList(ddlDentalRate1, ddlDentalEligibility1);
            ClearDropDownList(ddlDentalRate2, ddlDentalEligibility2);
            ClearDropDownList(ddlDentalRate3, ddlDentalEligibility3);
            ClearDropDownList(ddlDentalRate4, ddlDentalEligibility4);
            ClearDropDownList(ddlDentalRate5, ddlDentalEligibility5);
            ClearDropDownList(ddlDentalRate6, ddlDentalEligibility6);
        }
        /// <summary>
        /// Clear Vision BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVision()
        {
            ClearDropDownList(ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionContribution1_2);
            ClearDropDownList(ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionContribution2_2);
            ClearDropDownList(ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionContribution3_2);
            ClearDropDownList(ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionContribution4_2);
            ClearDropDownList(ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionContribution5_2);
            ClearDropDownList(ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionContribution6_2);

            //Added by Amogh to clear Rate Dropdownbox 
            ClearDropDownList(ddlVisionRate1, ddlVisionEligibility1);
            ClearDropDownList(ddlVisionRate1, ddlVisionEligibility2);
            ClearDropDownList(ddlVisionRate3, ddlVisionEligibility3);
            ClearDropDownList(ddlVisionRate4, ddlVisionEligibility4);
            ClearDropDownList(ddlVisionRate5, ddlVisionEligibility5);
            ClearDropDownList(ddlVisionRate6, ddlVisionEligibility6);
        }
        /// <summary>
        /// Clear LifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLifeADD()
        {
            ClearDropDownList(ddlLifeADDBenefitSummary1, null);
            ClearDropDownList(ddlLifeADDBenefitSummary2, null);
            ClearDropDownList(ddlLifeADDBenefitSummary3, null);
            ClearDropDownList(ddlLifeADDBenefitSummary4, null);
            ClearDropDownList(ddlLifeADDBenefitSummary5, null);
            ClearDropDownList(ddlLifeADDBenefitSummary6, null);
            //Added by Amogh to clear Rate Dropdown
            ClearDropDownList(ddlLifeADDRate1, ddlLifeADDEligibility1);
            ClearDropDownList(ddlLifeADDRate2, ddlLifeADDEligibility2);
            ClearDropDownList(ddlLifeADDRate3, ddlLifeADDEligibility3);
            ClearDropDownList(ddlLifeADDRate4, ddlLifeADDEligibility4);
            ClearDropDownList(ddlLifeADDRate5, ddlLifeADDEligibility5);
            ClearDropDownList(ddlLifeADDRate6, ddlLifeADDEligibility6);
        }
        /// <summary>
        /// Clear GroupTermLife BenefitSummary.
        /// </summary>
        protected void ClearGroupTermLife()
        {
            ClearDropDownList(ddlGroupTermLifeBenefitSummary, null);
            ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
        }
        /// <summary>
        /// Clear STD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearSTD()
        {
            ClearDropDownList(ddlSTDBenefitSummary1, null);
            ClearDropDownList(ddlSTDBenefitSummary2, null);
            ClearDropDownList(ddlSTDBenefitSummary3, null);
            ClearDropDownList(ddlSTDBenefitSummary4, null);
            ClearDropDownList(ddlSTDBenefitSummary5, null);
            ClearDropDownList(ddlSTDBenefitSummary6, null);
            //Added by Amogh to clear Rate Dropdown
            ClearDropDownList(ddlSTDRate1, ddlSTDEligibility1);
            ClearDropDownList(ddlSTDRate2, ddlSTDEligibility2);
            ClearDropDownList(ddlSTDRate3, ddlSTDEligibility3);
            ClearDropDownList(ddlSTDRate4, ddlSTDEligibility4);
            ClearDropDownList(ddlSTDRate5, ddlSTDEligibility5);
            ClearDropDownList(ddlSTDRate6, ddlSTDEligibility6);
        }
        /// <summary>
        /// Clear LTD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearLTD()
        {
            ClearDropDownList(ddlLTDBenefitSummary1, null);
            ClearDropDownList(ddlLTDBenefitSummary2, null);
            ClearDropDownList(ddlLTDBenefitSummary3, null);
            ClearDropDownList(ddlLTDBenefitSummary4, null);
            ClearDropDownList(ddlLTDBenefitSummary5, null);
            ClearDropDownList(ddlLTDBenefitSummary6, null);
            //Added by Amogh to clear Rate Dropdown
            ClearDropDownList(ddlLTDRate1, ddlLTDEligibility1);
            ClearDropDownList(ddlLTDRate2, ddlLTDEligibility2);
            ClearDropDownList(ddlLTDRate3, ddlLTDEligibility3);
            ClearDropDownList(ddlLTDRate4, ddlLTDEligibility4);
            ClearDropDownList(ddlLTDRate5, ddlLTDEligibility5);
            ClearDropDownList(ddlLTDRate6, ddlLTDEligibility6);
        }
        /// <summary>
        /// Clear VoluntaryLifeADD BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearVoluntaryLifeADD()
        {
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary, ddlVoluntaryLifeEligibility1);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary2, ddlVoluntaryLifeEligibility2);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary3, ddlVoluntaryLifeEligibility3);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary4, ddlVoluntaryLifeEligibility4);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary5, ddlVoluntaryLifeEligibility5);
            ClearDropDownList(ddlVoluntaryLifeADDBenefitSummary6, ddlVoluntaryLifeEligibility6);
        }
        /// <summary>
        /// Clear EAP BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearEAP()
        {
            ClearDropDownList(ddlEAPBenefitSummary, ddlEAPEligibility1);
            ClearDropDownList(ddlEAPBenefitSummary2, ddlEAPEligibility2);
            ClearDropDownList(ddlEAPBenefitSummary3, ddlEAPEligibility3);
            ClearDropDownList(ddlEAPBenefitSummary4, ddlEAPEligibility4);
            ClearDropDownList(ddlEAPBenefitSummary5, ddlEAPEligibility5);
            ClearDropDownList(ddlEAPBenefitSummary6, ddlEAPEligibility6);
        }
        /// <summary>
        /// Clear ADD BenefitSummary.
        /// </summary>
        protected void ClearADD()
        {
            ClearDropDownList(ddlADNDBenefitSummary, null);
        }
        /// <summary>
        /// Clear Wellness BenefitSummary.
        /// </summary>
        protected void ClearWellness()
        {
            ClearDropDownList(ddlWellnessProgramBenefitSummary, ddlWellnessEligibility1);
            ClearDropDownList(ddlWellnessProgramBenefitSummary2, ddlWellnessEligibility2);
            ClearDropDownList(ddlWellnessProgramBenefitSummary3, ddlWellnessEligibility3);
            ClearDropDownList(ddlWellnessProgramBenefitSummary4, ddlWellnessEligibility4);
            ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
            ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);
        }
        /// <summary>
        /// Clear FSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearFSA()
        {
            ClearDropDownList(ddlFSABenefitSummary, null);
            ClearDropDownList(ddlFSABenefitSummary2, null);
            ClearDropDownList(ddlFSABenefitSummary3, null);
            ClearDropDownList(ddlFSABenefitSummary4, null);
            ClearDropDownList(ddlFSABenefitSummary5, null);
            ClearDropDownList(ddlFSABenefitSummary6, null);

        }
        /// <summary>
        /// Clear HSA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHSA()
        {
            ClearDropDownList(ddlHSABenefitSummary, null);
            ClearDropDownList(ddlHSABenefitSummary2, null);
            ClearDropDownList(ddlHSABenefitSummary3, null);
            ClearDropDownList(ddlHSABenefitSummary4, null);
            ClearDropDownList(ddlHSABenefitSummary5, null);
            ClearDropDownList(ddlHSABenefitSummary6, null);
        }
        /// <summary>
        /// Clear HRA BenefitSummary, Rate, Contribution.
        /// </summary>
        protected void ClearHRA()
        {
            ClearDropDownList(ddlHRABenefitSummary, null);
            ClearDropDownList(ddlHRABenefitSummary2, null);
            ClearDropDownList(ddlHRABenefitSummary3, null);
            ClearDropDownList(ddlHRABenefitSummary4, null);
            ClearDropDownList(ddlHRABenefitSummary5, null);
            ClearDropDownList(ddlHRABenefitSummary6, null);
        }

        private void ClearStopLoss()
        {
            ClearDropDownList(ddlStopBenefitSummary, null);
            ClearDropDownList(ddlStopBenefitSummary2, null);
            ClearDropDownList(ddlStopBenefitSummary3, null);
            ClearDropDownList(ddlStopBenefitSummary4, null);
            ClearDropDownList(ddlStopBenefitSummary5, null);
            ClearDropDownList(ddlStopBenefitSummary6, null);
        }

        private void ClearPrescriptionDrug()
        {
            ClearDropDownList(ddlPrescriptionBenefitSummary, null);
            ClearDropDownList(ddlPrescriptionBenefitSummary2, null);
            ClearDropDownList(ddlPrescriptionBenefitSummary3, null);
            ClearDropDownList(ddlPrescriptionBenefitSummary4, null);
            ClearDropDownList(ddlPrescriptionBenefitSummary5, null);
            ClearDropDownList(ddlPrescriptionBenefitSummary6, null);
        }

        protected void ddlGroupTermLifeNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlGroupTermLifeNoOfPlan.SelectedIndex == 0)
                {
                    ClearGroupTermLife();
                    if (ddlGroupTermLifePlanName != null)
                    {
                        ddlGroupTermLifePlanName.Items.Clear();
                    }
                    if (ddlGroupTermLifePlanName2 != null)
                    {
                        ddlMedicalPlanName2.Items.Clear();
                    }
                }

                string ch = ddlGroupTermLifeNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> GroupTermLifePlanList = new List<Plan>();
                List<Plan> PlanList = new List<Plan>();
                PlanList = (List<Plan>)Session["PlanList"];
                List<int> GroupTermLifePlanTypeList = new List<int>();

                GroupTermLifePlanTypeList.Add(250);

                ConstantValue cv = new ConstantValue();
                DataTable ProductSummaryTable = CreateProductSummaryTable();

                foreach (var item in GroupTermLifePlanList)
                {
                    DataRow dr = ProductSummaryTable.NewRow();
                    dr["ProductId"] = item.ProductId;
                    dr["ProductName"] = item.ProductName;
                    dr["Carrier"] = item.CarrierName;
                    dr["Effective"] = item.EffectiveDate;
                    dr["Renewal"] = item.RenewalDate;
                    dr["PolicyNumber"] = item.PolicyNumber;
                    dr["ProductTypeDescription"] = item.ProductTypeDescription;
                    dr["PlanType"] = cv.GroupTermLifePlanType;

                    ProductSummaryTable.Rows.Add(dr);
                }

                switch (ch)
                {
                    case "1":
                        //trGroupTermLifeSection1.Visible = true;
                        //trGroupTermLifeSection2.Visible = false;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            //trADNDSection.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trADNDSection.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //trADNDHeading.Attributes.Add("class", "trodd");
                            //trADNDNoOfPlans.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                            SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        }

                        ddlGroupTermLifePlanName2.Items.Clear();
                        ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
                        break;

                    case "2":
                        //trGroupTermLifeSection1.Visible = true;
                        //trGroupTermLifeSection2.Visible = true;

                        if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                        {
                            //trADNDSection.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else if (ddlADNDNoOfPlan.SelectedIndex == 1 && ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trADNDSection.Attributes.Add("class", "treven");
                            //trWellnessHeading.Attributes.Add("class", "trodd");
                            //trWellnessNoOfPlans.Attributes.Add("class", "treven");
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //trADNDHeading.Attributes.Add("class", "treven");
                            //trADNDNoOfPlans.Attributes.Add("class", "trodd");
                            //trWellnessHeading.Attributes.Add("class", "treven");
                            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }

                        if (ddlGroupTermLifePlanName.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName.DataBind();
                            ddlGroupTermLifePlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                        }

                        if (ddlGroupTermLifePlanName2.SelectedIndex == -1 || SummaryDetail.isClientChanged_ForGroupTermLife == true)
                        {
                            ddlGroupTermLifePlanName2.DataSource = GroupTermLifePlanList;
                            ddlGroupTermLifePlanName2.DataBind();
                            ddlGroupTermLifePlanName2.Items.Insert(0, new ListItem("Select", string.Empty));
                        }
                        SummaryDetail.isClientChanged_ForGroupTermLife = false;
                        break;

                    case "None":
                        //trGroupTermLifeSection1.Visible = false;
                        //trGroupTermLifeSection2.Visible = false;

                        //trADNDHeading.Attributes.Add("class", "treven");
                        //trADNDNoOfPlans.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
                        //LineShading_EAP(0);

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void rdlGroupTermLife_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearGroupTermLife();
            SummaryDetail.isClientChanged_ForGroupTermLife = true;
            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            //trGroupTermLifeSection1.Visible = false;
            //trGroupTermLifeSection2.Visible = false;

            //trADNDHeading.Attributes.Add("class", "treven");
            //trADNDNoOfPlans.Attributes.Add("class", "trodd");
            //trWellnessHeading.Attributes.Add("class", "treven");
            //trWellnessNoOfPlans.Attributes.Add("class", "trodd");
            //LineShading_EAP(0);
        }

        protected void ddlGroupTermLifePlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName.SelectedValue), ddlGroupTermLifeBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary, null);
            }
        }

        protected void ddlGroupTermLifePlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlGroupTermLifePlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlGroupTermLifePlanName2.SelectedValue), ddlGroupTermLifeBenefitSummary2, null, null);
            }
            else
            {
                ClearDropDownList(ddlGroupTermLifeBenefitSummary2, null);
            }
        }

        protected void rdlADND_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearADD();
            ddlADNDNoOfPlan.SelectedIndex = 0;
            //trADNDSection.Visible = false;

            if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
            {
                //trADNDSection.Attributes.Add("class", "treven");
                //trWellnessHeading.Attributes.Add("class", "trodd");
                //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    //trWellnessProgramSection.Attributes.Add("class", "trodd");
                    //LineShading_EAP(0);
                }
                else
                {
                    //LineShading_EAP(1);
                }
            }
            else
            {
                //trADNDSection.Attributes.Add("class", "trodd");
                //trWellnessHeading.Attributes.Add("class", "treven");
                //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                {
                    //trWellnessProgramSection.Attributes.Add("class", "treven");
                    //LineShading_EAP(1);
                }
                else
                {
                    //LineShading_EAP(0);
                }
            }
        }

        protected void ddlADNDNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ClearADD();

                if (ddlADNDNoOfPlan.SelectedIndex == 1)
                {
                    BPBusiness bp = new BPBusiness();
                    List<Plan> ADDPlanList = new List<Plan>();
                    List<Plan> PlanList = new List<Plan>();
                    PlanList = (List<Plan>)Session["PlanList"];
                    List<int> ADDPlanTypeList = new List<int>();
                    // ADD - 270
                    // Wellness - 317
                    ADDPlanTypeList.Add(270);

                    //if (rdlADND.SelectedIndex == 0)
                    //{

                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                    //        {
                    //            if (ADDPlanTypeList.Contains(item.ProductTypeId))
                    //            {
                    //                ADDPlanList.Add(item);
                    //            }
                    //        }
                    //    }
                    //}
                    //if (rdlADND.SelectedIndex == 1)
                    //{
                    //    foreach (Plan item in PlanList)
                    //    {
                    //        if (ADDPlanTypeList.Contains(item.ProductTypeId))
                    //        {
                    //            ADDPlanList.Add(item);
                    //        }
                    //    }
                    //}
                    ConstantValue cv = new ConstantValue();

                    //trADNDSection.Visible = true;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        //trADNDSection.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //LineShading_EAP(0);
                        }
                    }
                    else
                    {
                        //trADNDSection.Attributes.Add("class", "treven");
                        //trWellnessHeading.Attributes.Add("class", "trodd");
                        //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //LineShading_EAP(1);
                        }
                    }

                    ddlADNDPlanName.DataSource = ADDPlanList;
                    ddlADNDPlanName.DataBind();
                    ddlADNDPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                    DataTable ProductSummaryTable = CreateProductSummaryTable();

                    foreach (var item in ADDPlanList)
                    {
                        DataRow dr = ProductSummaryTable.NewRow();
                        dr["ProductId"] = item.ProductId;
                        dr["ProductName"] = item.ProductName;
                        dr["Carrier"] = item.CarrierName;
                        dr["Effective"] = item.EffectiveDate;
                        dr["Renewal"] = item.RenewalDate;
                        dr["PolicyNumber"] = item.PolicyNumber;
                        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                        dr["PlanType"] = cv.ADD;

                        ProductSummaryTable.Rows.Add(dr);
                    }
                }
                else
                {
                    //trADNDSection.Visible = false;

                    if ((ddlSTDNoOfPlan.SelectedIndex == 1 && ddlLTDNoOfPlan.SelectedIndex == 0) || (ddlSTDNoOfPlan.SelectedIndex == 0 && ddlLTDNoOfPlan.SelectedIndex == 1))
                    {
                        //trADNDSection.Attributes.Add("class", "treven");
                        //trWellnessHeading.Attributes.Add("class", "trodd");
                        //trWellnessNoOfPlans.Attributes.Add("class", "treven");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "trodd");
                            //LineShading_EAP(0);
                        }
                        else
                        {
                            //LineShading_EAP(1);
                        }
                    }
                    else
                    {
                        //trADNDSection.Attributes.Add("class", "trodd");
                        //trWellnessHeading.Attributes.Add("class", "treven");
                        //trWellnessNoOfPlans.Attributes.Add("class", "trodd");

                        if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                        {
                            //trWellnessProgramSection.Attributes.Add("class", "treven");
                            //LineShading_EAP(1);
                        }
                        else
                        {
                            //LineShading_EAP(0);
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlADNDPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlADNDPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlADNDPlanName.SelectedValue), ddlADNDBenefitSummary, null, null);
            }
            else
            {
                ClearDropDownList(ddlADNDBenefitSummary, null);
            }
        }

        protected void rdlWellnessProgram_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearWellness();
            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            //trWellnessProgramSection.Visible = false;

            if (ddlADNDNoOfPlan.SelectedIndex == 1)
            {
                //trWellnessProgramSection.Attributes.Add("class", "treven");
                //LineShading_EAP(1);
            }
            else
            {
                //trWellnessProgramSection.Attributes.Add("class", "trodd");
                //LineShading_EAP(0);
            }
        }


        /***************************************************************
         ************************* Added by Amogh **********************
         */

        protected void WellNessPlanSelected()
        {
            try
            {
                if (ddlWellnessProgramNoOfPlan.SelectedIndex == 0)
                {
                    ClearWellness();
                    if (ddlWellnessProgramPlanName != null)
                    {
                        ddlWellnessProgramPlanName.Items.Clear();
                    }
                    if (ddlWellnessProgramPlanName2 != null)
                    {
                        ddlWellnessProgramPlanName2.Items.Clear();
                    }
                    if (ddlWellnessProgramPlanName3 != null)
                    {
                        ddlWellnessProgramPlanName3.Items.Clear();
                    }
                    if (ddlWellnessProgramPlanName4 != null)
                    {
                        ddlWellnessProgramPlanName4.Items.Clear();
                    }
                    if (ddlWellnessProgramPlanName5 != null)
                    {
                        ddlWellnessProgramPlanName5.Items.Clear();
                    }
                    if (ddlWellnessProgramPlanName6 != null)
                    {
                        ddlWellnessProgramPlanName6.Items.Clear();
                    }
                }

                List<Plan> WellnessPlanList = new List<Plan>();
                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.WellnessPlanTypeList, cv.Wellness, ref WellnessPlanList);
                string ch = ddlWellnessProgramNoOfPlan.SelectedItem.Text;

                switch (ch)
                {
                    case "1":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = false;
                        tblWell_3.Visible = false;
                        tblWell_4.Visible = false;
                        tblWell_5.Visible = false;
                        tblWell_6.Visible = false;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);

                        ddlWellnessProgramPlanName2.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary2, ddlWellnessEligibility2);
                        ddlWellnessProgramPlanName3.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary3, ddlWellnessEligibility3);
                        ddlWellnessProgramPlanName4.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary4, ddlWellnessEligibility4);
                        ddlWellnessProgramPlanName5.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
                        ddlWellnessProgramPlanName6.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);

                        break;

                    case "2":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = true;
                        tblWell_3.Visible = false;
                        tblWell_4.Visible = false;
                        tblWell_5.Visible = false;
                        tblWell_6.Visible = false;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName2, WellnessPlanList, ddlWellnessProgramBenefitSummary2, null, null);

                        ddlWellnessProgramPlanName3.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary3, ddlWellnessEligibility3);
                        ddlWellnessProgramPlanName4.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary4, ddlWellnessEligibility4);
                        ddlWellnessProgramPlanName5.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
                        ddlWellnessProgramPlanName6.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);

                        break;

                    case "3":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = true;
                        tblWell_3.Visible = true;
                        tblWell_4.Visible = false;
                        tblWell_5.Visible = false;
                        tblWell_6.Visible = false;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName2, WellnessPlanList, ddlWellnessProgramBenefitSummary2, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName3, WellnessPlanList, ddlWellnessProgramBenefitSummary3, null, null);


                        ddlWellnessProgramPlanName4.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary4, ddlWellnessEligibility4);
                        ddlWellnessProgramPlanName5.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
                        ddlWellnessProgramPlanName6.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);

                        break;

                    case "4":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = true;
                        tblWell_3.Visible = true;
                        tblWell_4.Visible = true;
                        tblWell_5.Visible = false;
                        tblWell_6.Visible = false;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName2, WellnessPlanList, ddlWellnessProgramBenefitSummary2, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName3, WellnessPlanList, ddlWellnessProgramBenefitSummary3, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName4, WellnessPlanList, ddlWellnessProgramBenefitSummary4, null, null);


                        ddlWellnessProgramPlanName5.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
                        ddlWellnessProgramPlanName6.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);

                        break;

                    case "5":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = true;
                        tblWell_3.Visible = true;
                        tblWell_4.Visible = true;
                        tblWell_5.Visible = true;
                        tblWell_6.Visible = false;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName2, WellnessPlanList, ddlWellnessProgramBenefitSummary2, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName3, WellnessPlanList, ddlWellnessProgramBenefitSummary3, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName4, WellnessPlanList, ddlWellnessProgramBenefitSummary4, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName5, WellnessPlanList, ddlWellnessProgramBenefitSummary5, null, null);

                        ddlWellnessProgramPlanName6.Items.Clear();
                        ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);

                        break;

                    case "6":
                        tblWell_1.Visible = true;
                        tblWell_2.Visible = true;
                        tblWell_3.Visible = true;
                        tblWell_4.Visible = true;
                        tblWell_5.Visible = true;
                        tblWell_6.Visible = true;

                        FillDropdownList(ddlWellnessProgramPlanName, WellnessPlanList, ddlWellnessProgramBenefitSummary, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName2, WellnessPlanList, ddlWellnessProgramBenefitSummary2, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName3, WellnessPlanList, ddlWellnessProgramBenefitSummary3, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName4, WellnessPlanList, ddlWellnessProgramBenefitSummary4, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName5, WellnessPlanList, ddlWellnessProgramBenefitSummary5, null, null);
                        FillDropdownList(ddlWellnessProgramPlanName6, WellnessPlanList, ddlWellnessProgramBenefitSummary6, null, null);

                        break;

                    case "_":
                        tblWell_1.Visible = false;
                        tblWell_2.Visible = false;
                        tblWell_3.Visible = false;
                        tblWell_4.Visible = false;
                        tblWell_5.Visible = false;
                        tblWell_6.Visible = false;
                        break;

                }//SwitchClose

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void ddlWellnessProgramNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                WellNessPlanSelected();
                #region OLD LOGIC COMMENTED BY AMOGH
                ////if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1)
                ////{
                ////    BPBusiness bp = new BPBusiness();
                ////    List<Plan> WellnessPlanList = new List<Plan>();
                ////    List<Plan> PlanList = new List<Plan>();
                ////    PlanList = (List<Plan>)Session["PlanList"];
                ////    List<int> WellnessPlanTypeList = new List<int>();
                ////    // ADD - 270
                ////    // Wellness - 317
                ////    WellnessPlanTypeList.Add(317);

                ////    //if (rdlWellnessProgram.SelectedIndex == 0)
                ////    //{

                ////    //    foreach (Plan item in PlanList)
                ////    //    {
                ////    //        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                ////    //        {
                ////    //            if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                ////    //            {
                ////    //                WellnessPlanList.Add(item);
                ////    //            }
                ////    //        }
                ////    //    }
                ////    //}
                ////    //if (rdlWellnessProgram.SelectedIndex == 1)
                ////    //{
                ////    //    foreach (Plan item in PlanList)
                ////    //    {
                ////    //        if (WellnessPlanTypeList.Contains(item.ProductTypeId))
                ////    //        {
                ////    //            WellnessPlanList.Add(item);
                ////    //        }
                ////    //    }
                ////    //}
                ////    ConstantValue cv = new ConstantValue();

                ////    //trWellnessProgramSection.Visible = true;

                ////    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                ////    {
                ////        //trWellnessProgramSection.Attributes.Add("class", "trodd");
                ////        //LineShading_EAP(0);
                ////    }
                ////    else
                ////    {
                ////        //trWellnessProgramSection.Attributes.Add("class", "treven");
                ////        //LineShading_EAP(1);
                ////    }

                ////    ddlWellnessProgramPlanName.DataSource = WellnessPlanList;
                ////    ddlWellnessProgramPlanName.DataBind();
                ////    ddlWellnessProgramPlanName.Items.Insert(0, new ListItem("Select", string.Empty));
                ////    DataTable ProductSummaryTable = CreateProductSummaryTable();

                ////    foreach (var item in WellnessPlanList)
                ////    {
                ////        DataRow dr = ProductSummaryTable.NewRow();
                ////        dr["ProductId"] = item.ProductId;
                ////        dr["ProductName"] = item.ProductName;
                ////        dr["Carrier"] = item.CarrierName;
                ////        dr["Effective"] = item.EffectiveDate;
                ////        dr["Renewal"] = item.RenewalDate;
                ////        dr["PolicyNumber"] = item.PolicyNumber;
                ////        dr["ProductTypeDescription"] = item.ProductTypeDescription;
                ////        dr["PlanType"] = cv.Wellness;

                ////        ProductSummaryTable.Rows.Add(dr);
                ////    }
                ////}
                ////else
                ////{
                ////    //trWellnessProgramSection.Visible = false; ;
                ////    if (ddlADNDNoOfPlan.SelectedIndex == 1)
                ////    {
                ////        //trWellnessProgramSection.Attributes.Add("class", "treven");
                ////        //LineShading_EAP(1);
                ////    }
                ////    else
                ////    {
                ////        //trWellnessProgramSection.Attributes.Add("class", "trodd");
                ////        //LineShading_EAP(0);
                ////    }
                ////}
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlWellnessProgramPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName.SelectedValue), ddlWellnessProgramBenefitSummary, null, ddlWellnessEligibility1, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary, ddlWellnessEligibility1);
            }
        }

        protected void ddlWellnessProgramPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName2.SelectedValue), ddlWellnessProgramBenefitSummary2, null, ddlWellnessEligibility2, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary2, ddlWellnessEligibility2);
            }
        }
        protected void ddlWellnessProgramPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName3.SelectedValue), ddlWellnessProgramBenefitSummary3, null, ddlWellnessEligibility3, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary3, ddlWellnessEligibility3);
            }
        }
        protected void ddlWellnessProgramPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName4.SelectedValue), ddlWellnessProgramBenefitSummary4, null, ddlWellnessEligibility4, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary4, ddlWellnessEligibility4);
            }
        }
        protected void ddlWellnessProgramPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName5.SelectedValue), ddlWellnessProgramBenefitSummary5, null, ddlWellnessEligibility5, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary5, ddlWellnessEligibility5);
            }
        }
        protected void ddlWellnessProgramPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlWellnessProgramPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlWellnessProgramPlanName6.SelectedValue), ddlWellnessProgramBenefitSummary6, null, ddlWellnessEligibility6, null, null);
            }
            else
            {
                ClearDropDownList(ddlWellnessProgramBenefitSummary6, ddlWellnessEligibility6);
            }
        }

        //protected string CreateClientIntake(string SessionId)
        //{
        //    DataTable Office = (DataTable)Session["OffieceTable"];

        //    Word.ApplicationClass oWordApp = new Word.ApplicationClass();
        //    Object missing = System.Reflection.Missing.Value;

        //    string strFileName = string.Empty;
        //    string strReportName = string.Empty;

        //    //if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
        //    //{
        //    //    strFileName = "Client Contact Sheet - Basic Landscape";
        //    //    strReportName = "Report5 - Landscape";
        //    //}
        //    strFileName = "ClientIntakeForm_Template";
        //    strReportName = "Report6";

        //    Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/" + strFileName + ".docm");

        //    Object readOnly = true;
        //    Object isVisible = false;
        //    //TimelineDetail timeD = new TimelineDetail();
        //    //DataTable ActivityInfoTable = new DataTable();
        //    //DataSet ActivityDS = new DataSet();
        //    //List<BRC> BRCList = new List<BRC>();
        //    //BRCList = (List<BRC>)Session["BRCList"];
        //    //DataTable dtOfficeAddress = new DataTable();

        //    Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
        //                            ref missing, ref readOnly,
        //                            ref missing, ref missing, ref missing,
        //                            ref missing, ref missing, ref missing,
        //                            ref missing, ref missing, ref isVisible,
        //                            ref missing, ref missing, ref missing, ref missing);

        //    object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName + "/NewDocument" + System.DateTime.Now.Year.ToString() +
        //                         System.DateTime.Now.Month.ToString() +
        //                         System.DateTime.Now.Day.ToString() +
        //                          System.DateTime.Now.Hour.ToString() +
        //                           System.DateTime.Now.Minute.ToString() +
        //                          System.DateTime.Now.Second.ToString() +
        //                          System.DateTime.Now.Millisecond.ToString() +
        //                         ".docm");

        //    try
        //    {
        //        oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
        //        if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName)))
        //        {
        //            Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/" + strReportName));
        //        }
        //        oWordDoc.SaveAs(ref savefilename,
        //            ref missing, ref missing, ref missing, ref missing, ref missing,
        //            ref missing, ref missing, ref missing, ref missing, ref missing,
        //            ref missing, ref missing, ref missing, ref missing, ref missing);

        //        WriteTool6_ClientIntakeForm wt = new WriteTool6_ClientIntakeForm();

        //        wt.WriteFieldToTools6_ClientIntakeForm(oWordDoc, oWordApp, ProductDS);

        //        //dtOfficeAddress = null;
        //        //if (ddlUSI_City.SelectedIndex > 0)
        //        //{
        //        //    string[] office = ddlUSI_City.SelectedValue.Split('~');
        //        //    string City = Convert.ToString(office[0]).Trim();
        //        //    string BPOffice = Convert.ToString(office[1]).Trim();
        //        //    string OfficeStreetAddress = Convert.ToString(office[2]).Trim();
        //        //    dtOfficeAddress = bp.GetOfficeAddress(City, BPOffice, OfficeStreetAddress);
        //        //}


        //        //string RenewalDate = string.Empty;
        //        //if (ddlReportFormat.SelectedItem.Value == "1") // Landscape Format
        //        //{
        //        //    wt.WriteFieldToClientContact_Landscape(oWordDoc, oWordApp, ddlOffice, ddlClient, grdAccountTeam, BRCList, ddlBRC, dtPlanContact, PlanInfoTable, dtOfficeAddress);
        //        //}
        //        //else if (ddlReportFormat.SelectedItem.Value == "2") // Portrait Format
        //        //{
        //        //    wt.WriteFieldToClientContact_Portrait(oWordDoc, oWordApp, ddlOffice, ddlClient, grdAccountTeam, BRCList, ddlBRC, dtPlanContact, PlanInfoTable, dtOfficeAddress);
        //        //}
        //        //RunMacro(oWordApp, new Object[] { "CleanTools1" });
        //        //temperror = temperror + " postmacro";
        //        oWordDoc.Save();
        //        if (oWordApp != null)
        //        {
        //            ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
        //            Marshal.ReleaseComObject(oWordDoc);

        //            oWordDoc = null;
        //            oWordApp.Quit(ref missing, ref missing, ref missing);
        //            Marshal.FinalReleaseComObject(oWordApp);
        //            oWordApp = null;
        //        }

        //        bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, Convert.ToString(ddlClient.SelectedItem.Text), Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //    finally
        //    {
        //        if (oWordApp != null)
        //        {

        //            ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
        //            Marshal.ReleaseComObject(oWordDoc);

        //            oWordDoc = null;
        //            oWordApp.Quit(ref missing, ref missing, ref missing);
        //            Marshal.FinalReleaseComObject(oWordApp);
        //            oWordApp = null;
        //        }
        //    }

        //    return (savefilename.ToString());
        //}

        /// <summary>
        /// To download Report File.
        /// </summary>
        /// <param name="newfilename">Name of file name.</param>
        protected void DownloadFileNew(string newfilename)
        {
            try
            {
                System.IO.FileInfo file = new System.IO.FileInfo(newfilename);
                string filename = System.IO.Path.GetFileName(newfilename);
                if (file.Exists == true)
                {
                    Response.Clear();

                    Response.AddHeader("Content-Disposition", "attachment; filename=" + "\"" + filename + "\"");
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/vnd.ms-word.document.macroEnabled.12";
                    Response.WriteFile(file.FullName);

                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Create Summary Template1
        /// </summary>
        //protected string CreateTools1(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, string SessionId)
        //{
        //    DataTable Office = (DataTable)Session["OffieceTable"];
        //    Word.ApplicationClass oWordApp = new Word.ApplicationClass();
        //    Object missing = System.Reflection.Missing.Value;

        //    Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/Tools_1.docm");

        //    Object readOnly = true;
        //    Object isVisible = false;
        //    TimelineDetail timeD = new TimelineDetail();
        //    DataTable ActivityInfoTable = new DataTable();
        //    DataSet ActivityDS = new DataSet();

        //    Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
        //                            ref missing, ref readOnly,
        //                            ref missing, ref missing, ref missing,
        //                            ref missing, ref missing, ref missing,
        //                            ref missing, ref missing, ref isVisible,
        //                            ref missing, ref missing, ref missing, ref missing);

        //    object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/Report1/NewDocument" + System.DateTime.Now.Year.ToString() +
        //                         System.DateTime.Now.Month.ToString() +
        //                         System.DateTime.Now.Day.ToString() +
        //                          System.DateTime.Now.Hour.ToString() +
        //                           System.DateTime.Now.Minute.ToString() +
        //                          System.DateTime.Now.Second.ToString() +
        //                          System.DateTime.Now.Millisecond.ToString() +
        //                         ".docm");

        //    try
        //    {
        //        oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
        //        if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Report1")))
        //        {
        //            Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Report1"));
        //        }
        //        oWordDoc.SaveAs(ref savefilename,
        //            ref missing, ref missing, ref missing, ref missing, ref missing,
        //            ref missing, ref missing, ref missing, ref missing, ref missing,
        //            ref missing, ref missing, ref missing, ref missing, ref missing);
        //        WriteTools1 wt = new WriteTools1();
        //        ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
        //        ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

        //        wt.WriteFieldToTools1(oWordDoc, oWordApp, ddlClient, ActivityDS, ActivityInfoTable, AccountDS, PlanInfoTable, AccountTeamMemberDS, SessionId);

        //        RunMacro(oWordApp, new Object[] { "CleanTools1" });
        //        temperror = temperror + " postmacro";
        //        oWordDoc.Save();

        //        if (oWordApp != null)
        //        {
        //            ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
        //            Marshal.ReleaseComObject(oWordDoc);

        //            oWordDoc = null;
        //            oWordApp.Quit(ref missing, ref missing, ref missing);
        //            Marshal.FinalReleaseComObject(oWordApp);
        //            oWordApp = null;
        //        }

        //        bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

        //    }
        //    catch (Exception ex)
        //    {
        //        //Response.Write(ex.Message);
        //        bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
        //        Response.Redirect("~/view/ErrorNotification.aspx");
        //    }
        //    finally
        //    {
        //        if (oWordApp != null)
        //        {

        //            ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
        //            Marshal.ReleaseComObject(oWordDoc);

        //            oWordDoc = null;
        //            oWordApp.Quit(ref missing, ref missing, ref missing);
        //            Marshal.FinalReleaseComObject(oWordApp);
        //            oWordApp = null;
        //        }
        //    }

        //    return (savefilename.ToString());
        //}

        /// <summary>
        /// Create Summary Template1
        /// </summary>
        protected string CreateTools2(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/Tools_2.docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Summary/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Summary")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Summary"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                //LoadColumnIdArrayList();
                WriteTools2 wt = new WriteTools2();
                //ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                //ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                ArrayList arrAcctContact = new ArrayList();

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }

                wt.WriteFieldToTools2(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);

                //RunMacro(oWordApp, new Object[] { "CleanTools2" });
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlLayout.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = string.Empty;
                string AdditionalCrtieriaOption_3 = string.Empty;
                string AdditionalCrtieriaOption_4 = string.Empty;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);

            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }

        protected string CreateTools2_AccountProfileDetails(int SubjectID, DataTable PlanInfoTable, DataSet AccountDS, DataSet AccountTeamMemberDS, List<Contact> ContactList, string SessionId, DataTable PlanInfoDetails, DataSet BenefitDS, DataSet ProductDS, DataSet BenefitStructureDS, DataSet RateDS, DataSet ContributionDS, DataTable AdditionalProductTableDetails)
        {
            DataTable Office = (DataTable)Session["OffieceTable"];
            Word.ApplicationClass oWordApp = new Word.ApplicationClass();
            Object missing = System.Reflection.Missing.Value;

            Object fileName = Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile -Detailed.docm");

            Object readOnly = true;
            Object isVisible = false;
            TimelineDetail timeD = new TimelineDetail();
            string Client_id = Convert.ToString(ddlClient.SelectedItem.Value);
            //DataTable ActivityInfoTable = new DataTable();
            //DataSet ActivityDS = new DataSet();

            Word.Document oWordDoc = oWordApp.Documents.Open(ref fileName,
                                    ref missing, ref readOnly,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref missing,
                                    ref missing, ref missing, ref isVisible,
                                    ref missing, ref missing, ref missing, ref missing);

            object savefilename = Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Details/NewDocument" + System.DateTime.Now.Year.ToString() +
                                 System.DateTime.Now.Month.ToString() +
                                 System.DateTime.Now.Day.ToString() +
                                  System.DateTime.Now.Hour.ToString() +
                                   System.DateTime.Now.Minute.ToString() +
                                  System.DateTime.Now.Second.ToString() +
                                  System.DateTime.Now.Millisecond.ToString() +
                                 ".docm");

            try
            {
                oWordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                if (!Directory.Exists(Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Details")))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Files/Tools/Documents/Templates/Account Profile - Details"));
                }
                oWordDoc.SaveAs(ref savefilename,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing);
                LoadColumnIdArrayList();
                WriteTools2_AccountProfileDetails wt = new WriteTools2_AccountProfileDetails();
                //ActivityInfoTable = timeD.GetActivityInformation(Convert.ToInt32(ddlClient.SelectedItem.Value), SessionId, SubjectID);
                //ActivityDS = timeD.Get_Activity_Detail(Convert.ToInt32(ddlActivity.SelectedItem.Value), SessionId);

                ArrayList arrAcctContact = new ArrayList();

                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        arrAcctContact.Add(cblistAccountContact.Items[i].Value);
                    }
                }

                wt.WriteFieldToTools2_AccountProfileDetails(oWordDoc, oWordApp, ddlClient, AccountDS, PlanInfoTable, AccountTeamMemberDS, ContactList, SessionId, arrAcctContact);

                if (ddlMedicalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteMedicalSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, MedicalBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, SessionId, Client_id, AccountDS);
                }

                //StopLoss
                if (ddlStopNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteStopLossSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, StopLossBenefitColumnIdList, MedicalBenefitColumnIdOutNetworkList, SessionId, Client_id);
                }
                //Prescption Drug 
                if (ddlPrescriptionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WritePrescriptionDrugSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, PrescriptionDrugBenefitColumnIdList, Client_id);
                }

                if (ddlLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLifeADDSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, LifeADDBenefitColumnIdList, ADDBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlDentalNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDentalSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, DentalBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlVisionNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVisionSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, VisionBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlHSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHSA(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, HSABenefitColumnIdList, SessionId);
                }
                if (ddlHRANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteHRA(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, HRABenefitColumnIdList, SessionId, PlanInfoTable);
                }
                if (ddlSTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteSTDSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, STDBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlLTDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteLTDSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, LTDBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlEAPNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteEAPSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, EAPBenefitColumnIdList, SessionId, Client_id, AccountDS);
                }
                if (ddlFSANoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteFSASection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, FSABenefitColumnIdList, SessionId);
                }
                if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteVoluntaryLifeADDSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, VoluntaryLifeBenefitColumnIdList, SessionId, ddlClient.SelectedItem.Value, AccountDS);
                }
                if (ddlAccidentNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteAccidentSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, AccidentalBenefitColumnIdList, SessionId, ddlClient.SelectedItem.Value, AccountDS);
                }
                if (ddlDisabilityNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteDisabilitySection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, DisabilityBenefitColumnIdList, SessionId, ddlClient.SelectedItem.Value, AccountDS);
                }
                //if (ddlAdditionalNoOfPlan.SelectedIndex > 0)
                //{
                //    wt.WriteAdditionalProductSection(oWordDoc, oWordApp, AdditionalProductTableDetails, ProductDS, BenefitDS, AdditionalProductsBenefitColumnIdList, SessionId);
                //}
                wt.WriteAdditionalProductSection(oWordDoc, oWordApp, AdditionalProductTableDetails, ProductDS, BenefitDS, AdditionalProductsBenefitColumnIdList, SessionId);
                if (ddlWellnessProgramNoOfPlan.SelectedIndex > 0)
                {
                    wt.WriteWellNessSection(oWordDoc, oWordApp, PlanInfoDetails, ProductDS, BenefitDS, WellnessBenefitColumnIdList, SessionId, ddlClient.SelectedItem.Value, AccountDS);
                }
                wt.WriteMonthlyPremiumSection(oWordDoc, oWordApp, RateDS, ContributionDS, PlanInfoDetails, ProductDS);
                // RunMacro(oWordApp, new Object[] { "CleanAccountProfileDocument" });
                //Added by -Aatrey
                DeleteBookmarkTable(oWordDoc, oWordApp);
                //temperror = temperror + " postmacro";
                oWordDoc.Save();

                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }

                string AdditionalCrtieriaOption_1 = ddlLayout.SelectedItem.Text;
                string AdditionalCrtieriaOption_2 = ddlMedicalPlanName1.SelectedItem.Text;
                string AdditionalCrtieriaOption_3 = ddlMedicalBenefitSummary1.SelectedItem.Text;
                string AdditionalCrtieriaOption_4 = ddlMedicalRate1.SelectedItem.Text;
                DicActivityLog.Clear();
                DicActivityLog = bp.ActivityLogData_V2(AccountDS, AccountTeamMemberDS, DictDepartment, ContactList);
                bp.InsertActivityLog_V2(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office, Convert.ToString(Session["DeliverableCategory"]), Convert.ToString(DicActivityLog["AccountDepartment"]), Convert.ToString(DicActivityLog["FTE_Record"]), Convert.ToString(DicActivityLog["PrimarySales"]), Convert.ToString(DicActivityLog["PrimaryService"]), Convert.ToString(DicActivityLog["PrimaryTeamContact"]), Convert.ToString(AdditionalCrtieriaOption_1), Convert.ToString(AdditionalCrtieriaOption_2), Convert.ToString(AdditionalCrtieriaOption_3), Convert.ToString(AdditionalCrtieriaOption_4));
                
                ////bp.InsertActivityLog(Convert.ToString(Session["UserName"]), Convert.ToString(Session["Office"]), Convert.ToString(Session["Department"]), Convert.ToString(Session["Region"]), Activity, Activity_Group, DateTime.Now, ddlClient.SelectedItem.Text, Convert.ToString(Session["UserLoginName"]), Convert.ToInt64(ddlClient.SelectedItem.Value), Account_Region, Account_Office);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            finally
            {
                if (oWordApp != null)
                {
                    ((Microsoft.Office.Interop.Word._Document)oWordDoc).Close(ref missing, ref missing, ref missing);
                    Marshal.ReleaseComObject(oWordDoc);

                    oWordDoc = null;
                    oWordApp.Quit(ref missing, ref missing, ref missing);
                    Marshal.FinalReleaseComObject(oWordApp);
                    oWordApp = null;
                }
            }

            return (savefilename.ToString());
        }



        protected void btnViewPlans_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                Hashtable htSortedPlanList = new Hashtable();
                if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                {
                    htSortedPlanList = ClientIntake_planList();
                }
                if (Convert.ToString(Session["Summary"]) == "Tools1")
                {
                    if (ddlClient.SelectedIndex == -1)
                    {
                        flag = false;
                        //Page.ClientScript.RegisterStartupScript(GetType(), "alert", "<script>alert('Please select Client.')</script>");
                    }
                }

                if (Convert.ToString(Session["Summary"]) == "Tools2")
                {
                    //int cnt = 0;
                    //for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                    //{
                    //    if (cblistAccountContact.Items[i].Selected == true)
                    //    {
                    //        cnt++;
                    //    }
                    //}

                    //if (cnt > 3)
                    //{
                    //    string script = "alert(\"Please select max 3 Account Contacts.\");";
                    //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    //    flag = false;
                    //}

                    grdPlans.DataSource = null;
                    grdPlans.DataBind();

                    flag = CheckAccountContactsSelected();
                }

                if (flag == true)
                {
                    List<Plan> PlanList = new List<Plan>();
                    List<Plan> commonPlanList = new List<Plan>();
                    Session["PlanList"] = null;
                    SessionId = Session["SessionId"].ToString();
                    if (ddlClient.SelectedIndex > 0)
                    {
                        if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                            PlanList = bp.FindPlans_Tools(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        //PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                        else
                            PlanList = bp.FindPlans(int.Parse(ddlClient.SelectedValue.ToString()), "", "", SessionId);
                    }
                    Session["PlanList"] = PlanList;

                    if (PlanList != null)
                    {
                        if (PlanList.Count > 0)
                        {
                            if (rdlPlan.SelectedIndex == 0)
                            {
                                // -------------- Added by Mandar on 04 Dec 2014 starts here ------------------------
                                if (Convert.ToString(Session["Summary"]) == "Tools1")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else if (Convert.ToString(Session["Summary"]) == "ClientIntakeForm" || Convert.ToString(Session["Summary"]) == "ClientIntakeFormCompliance")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            if (htSortedPlanList.ContainsValue(item.ProductTypeId))
                                            {
                                                commonPlanList.Add(item);
                                            }
                                        }
                                    }
                                }
                                else if (Convert.ToString(Session["Summary"]) == "ClientIntakeFormPHM")
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent || item.ProductStatus == item.ProductStatusPending)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (Plan item in PlanList)
                                    {
                                        if (item.RenewalDate > System.DateTime.Now && item.ProductStatus == item.ProductStatusCurrent)
                                        {
                                            commonPlanList.Add(item);
                                        }
                                    }
                                }
                                // -------------- Added by Mandar on 04 Dec 2014 ends here ------------------------
                            }
                            if (rdlPlan.SelectedIndex == 1)
                            {
                                foreach (Plan item in PlanList)
                                {
                                    commonPlanList.Add(item);
                                }
                            }

                            //  commonPlanList.OrderBy(a => a.ProductTypeId);
                            List<Plan> lstPlanList = new List<Plan>();

                            lstPlanList = (from l in commonPlanList
                                           orderby l.ProductTypeId, l.CarrierName ascending
                                           select l).ToList();

                            grdPlans.DataSource = lstPlanList;
                            grdPlans.DataBind();

                            if (commonPlanList.Count > 0)
                            {
                                pnlPlans.Visible = true;
                                CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");
                                ChkBoxHeader.Checked = true;
                                foreach (GridViewRow row in grdPlans.Rows)
                                {
                                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                                    ChkBoxRows.Checked = true;
                                }
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
                            }
                            else
                            {
                                string script = "alert(\"No active plans.\");";
                                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }


        private Hashtable ClientIntake_planList()
        {
            Hashtable htSortedPlanList = new Hashtable();
            htSortedPlanList.Add(1, 100);   // Medical
            htSortedPlanList.Add(2, 110);   // Medical
            htSortedPlanList.Add(3, 120);   // Medical
            htSortedPlanList.Add(4, 140);   // Medical
            htSortedPlanList.Add(5, 150);   // Medical
            htSortedPlanList.Add(6, 160);   // Medical
            htSortedPlanList.Add(7, 170);   // Medical

            htSortedPlanList.Add(8, 180);   // Dental
            htSortedPlanList.Add(9, 190);   // Dental
            htSortedPlanList.Add(10, 200);   // Dental
            htSortedPlanList.Add(11, 210);   // Dental

            htSortedPlanList.Add(12, 230);   // Vision

            htSortedPlanList.Add(13, 240);   // Life & AD&D
            htSortedPlanList.Add(14, 250);   // Group Term Life

            //htSortedPlanList.Add(15, 260);   // Voluntary Life
            //htSortedPlanList.Add(16, 270);   // AD&D
            //htSortedPlanList.Add(17, 280);   // Voluntary AD&D
            htSortedPlanList.Add(18, 290);   // STD
            htSortedPlanList.Add(19, 300);   // LTD
            //htSortedPlanList.Add(20, 330);   // Section 125


            htSortedPlanList.Add(21, 130);   // Medical
            //htSortedPlanList.Add(22, 310);   // EAP
            htSortedPlanList.Add(23, 178);   // HRA
            htSortedPlanList.Add(24, 179);   // HSA
            //htSortedPlanList.Add(22, 1116);   // Medical Plan Riders

            return htSortedPlanList;
        }

        protected DataTable CreatePlanInfoTable()
        {
            DataTable PlanInfoTable = new DataTable();

            try
            {
                PlanInfoTable.Columns.Add("Carrier", typeof(string));                   // Carrier Name
                PlanInfoTable.Columns.Add("Name", typeof(string));                      // Name
                PlanInfoTable.Columns.Add("Effective", typeof(string));                 // Effective Date
                PlanInfoTable.Columns.Add("Renewal", typeof(string));                   // Renewal Date
                PlanInfoTable.Columns.Add("PolicyNumber", typeof(string));              // Policy Number
                PlanInfoTable.Columns.Add("ProductId", typeof(string));//Plan ID
                PlanInfoTable.Columns.Add("ProductName", typeof(string));// Plan Name
                PlanInfoTable.Columns.Add("ProductTypeId", typeof(string));  // Plan Type ID
                PlanInfoTable.Columns.Add("PlanType", typeof(string));  // Plan Type
                PlanInfoTable.Columns.Add("PlanNumber", typeof(string));
                PlanInfoTable.Columns.Add("SummaryID", typeof(string));
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        /// <summary>
        /// Run macro on created document.
        /// </summary>
        private void RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                temperror = temperror + " rm";

                oApp.GetType().InvokeMember("Run",
                    System.Reflection.BindingFlags.Default |
                    System.Reflection.BindingFlags.InvokeMethod,
                    null, oApp, oRunArgs);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }

        }

        protected void rdlPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdPlans.DataSource = null;
            grdPlans.DataBind();
            Clear(true);
        }

        /*****************************************************************************************
         * Here we load the Plan name which render on LeftHand side of Plan Page.
         *****************************************************************************************/
        public string GetPlanName(int PlanTypeId)
        {
            string _planName = string.Empty;

            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.MedicalLOC;
                    }
                }

                //Stop Loss
                foreach (var item in CommonFunctionsBS.StopLossPlanTypeList)
                {
                    if (CommonFunctionsBS.StopLossPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.StopLoss;
                    }
                }

                //Prescription Drug
                foreach (var item in CommonFunctionsBS.PrescriptionDrugPlanTypeList)
                {
                    if (CommonFunctionsBS.PrescriptionDrugPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.PrescriptionDrug;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.DentalLOC;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VisionLOC;
                    }
                }

                // Life and AD&D
                foreach (var item in CommonFunctionsBS.LifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LifeADDLOC;
                    }
                }

                // STD
                foreach (var item in CommonFunctionsBS.STDPlanTypeList)
                {
                    if (CommonFunctionsBS.STDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.STDLOC;
                    }
                }

                // Voluntary Life and AD&D
                foreach (var item in CommonFunctionsBS.VoluntaryLifeADDPlanTypeList)
                {
                    if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.VoluntaryLifeADDLOC + "/" + cv.ADNDPlanType_CommonCriteria;
                    }
                }

                // LTD
                foreach (var item in CommonFunctionsBS.LTDPlanTypeList)
                {
                    if (CommonFunctionsBS.LTDPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.LTDLOC;
                    }
                }

                // EAP
                foreach (var item in CommonFunctionsBS.EAPPlanTypeList)
                {
                    if (CommonFunctionsBS.EAPPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.EAPPlanType_CommonCriteria;
                    }
                }

                // FSA
                foreach (var item in CommonFunctionsBS.FSAPlanTypeList)
                {
                    if (CommonFunctionsBS.FSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.FSAPlanType_CommonCriteria;
                    }
                }

                // HRA
                foreach (var item in CommonFunctionsBS.HRAPlanTypeList)
                {
                    if (CommonFunctionsBS.HRAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HRAPlanType_CommonCriteria;
                    }
                }

                // HSA
                foreach (var item in CommonFunctionsBS.HSAPlanTypeList)
                {
                    if (CommonFunctionsBS.HSAPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.HSAPlanType_CommonCriteria;
                    }
                }

                // Wellness
                foreach (var item in CommonFunctionsBS.WellnessPlanTypeList)
                {
                    if (CommonFunctionsBS.WellnessPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Wellness;
                    }
                }

                /**********************************************************************************************
                 * ADDED BY AMOGH FOR ADDING 2 NEW SECTION IN ACCOUNT PROFILE DETAILS  
                 ***********************************************************************************************/
                //Disability
                foreach (var item in CommonFunctionsBS.DisabilityPlanTypeList)
                {
                    if (CommonFunctionsBS.DisabilityPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Disability;
                    }
                }


                //***********************************************************************************************/
                //Accident
                foreach (var item in CommonFunctionsBS.AccidentalProductPlanTypeList)
                {
                    if (CommonFunctionsBS.AccidentalProductPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.Accident;
                    }
                }

                //// Group Term Life
                //foreach (var item in GroupTermLifePlanTypeList)
                //{
                //    if (GroupTermLifePlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.GroupTermLifePlanType;
                //    }
                //}

                //// AD&D
                //foreach (var item in LifeADDPlanTypeList)
                //{
                //    if (LifeADDPlanTypeList.Contains(PlanTypeId))
                //    {
                //        return cv.ADD;
                //    }
                //}

                /*---------------------Commented by Amogh -----------------------------*/
                // Additional Products
                foreach (var item in CommonFunctionsBS.AdditionalProductsPlanTypeList)
                {
                    if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(PlanTypeId))
                    {
                        return cv.AdditionalProducts;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _planName;
        }

        public bool Check_PlanIs_Medical_Dental_Vision(int PlanTypeId)
        {
            bool _IsMDV = false;

            try
            {
                // Medical
                foreach (var item in CommonFunctionsBS.MedicalPlanTypeList)
                {
                    if (CommonFunctionsBS.MedicalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Dental
                foreach (var item in CommonFunctionsBS.DentalPlanTypeList)
                {
                    if (CommonFunctionsBS.DentalPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }

                // Vision
                foreach (var item in CommonFunctionsBS.VisionPlanTypeList)
                {
                    if (CommonFunctionsBS.VisionPlanTypeList.Contains(PlanTypeId))
                    {
                        _IsMDV = true;
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return _IsMDV;
        }


        protected void dlPlan_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                LinkButton lnkPlanNames = e.Item.FindControl("lnkPlanNames") as LinkButton;
                lnkPlanNames.Text = e.Item.DataItem.ToString();

                //Added by shravan - to hide additioanl products
                if (lnkPlanNames.Text == "Additional Products")
                {
                    lnkPlanNames.Visible = false;
                }
            }
        }


        private DataTable GetPlanInfoTable_Summary()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();
            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds_AccountDetails();
            //List<int> MedicalPlanTypeList = new List<int>();

            ////List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            //MedicalPlanTypeList.Add(100);
            //MedicalPlanTypeList.Add(110);
            //MedicalPlanTypeList.Add(120);
            //MedicalPlanTypeList.Add(130);
            //MedicalPlanTypeList.Add(140);
            //MedicalPlanTypeList.Add(150);
            //MedicalPlanTypeList.Add(160);
            //MedicalPlanTypeList.Add(170);
            //MedicalPlanTypeList.Add(1116);

            //List<int> DentalPlanTypeList = new List<int>();
            //DentalPlanTypeList.Add(180);
            //DentalPlanTypeList.Add(190);
            //DentalPlanTypeList.Add(200);
            //DentalPlanTypeList.Add(210);

            //List<int> VisionPlanTypeList = new List<int>();
            //VisionPlanTypeList.Add(230);

            //List<int> LifeADDPlanTypeList = new List<int>();
            //LifeADDPlanTypeList.Add(240);
            ////  LifeADDPlanTypeList.Add(250);

            //List<int> GroupTermLifePlanTypeList = new List<int>();
            //GroupTermLifePlanTypeList.Add(250);

            //List<int> VoluntaryLifeList = new List<int>();
            //VoluntaryLifeList.Add(260);

            //List<int> ADD = new List<int>();
            //ADD.Add(270);

            //List<int> VoluntaryLife_ADDList = new List<int>();
            //VoluntaryLife_ADDList.Add(280);

            //List<int> STDPlanTypeList = new List<int>();
            //STDPlanTypeList.Add(290);

            //List<int> LTDPlanTypeList = new List<int>();
            //LTDPlanTypeList.Add(300);

            //List<int> FSAPlanTypeList = new List<int>();
            //FSAPlanTypeList.Add(330);

            ////List<int> EAPPlanTypeList = new List<int>();
            ////EAPPlanTypeList.Add(310);

            ////List<int> HSAPlanTypeList = new List<int>();
            ////HSAPlanTypeList.Add(179);

            ////List<int> HRAPlanTypeList = new List<int>();
            ////HRAPlanTypeList.Add(178);

            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            //foreach (var data in BenefitSummaryList)
                            //{

                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PlanType"] = cv.ADD;
                            }

                            //if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.Wellness;
                            //}

                            //if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["PlanType"] = cv.AdditionalProducts;
                            //}

                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {



                            //foreach (var data in BenefitSummaryList)
                            //{

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;


                        }
                        else
                        {

                        }

                    }


                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanInfoTable.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        private DataTable GetPlanInfoTable_Details()
        {
            DataTable PlanInfoTable = new DataTable();
            PlanInfoTable = CreatePlanInfoTable();

            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();

            try
            {
                int rowCount = 0;
                int rowCount1 = 0;
                System.Web.UI.WebControls.CheckBox chkItemSelect = new System.Web.UI.WebControls.CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((System.Web.UI.WebControls.CheckBox)grRow.FindControl("chkItemSelect"));

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length < 4))
                        {
                            PlanInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductName"] = " ";
                            }

                            // For ProductTypeId
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[7].Text)))
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = Convert.ToString(grRow.Cells[7].Text);
                            }
                            else
                            {
                                PlanInfoTable.Rows[rowCount]["ProductTypeId"] = " ";
                            }

                            rowCount++;
                        }
                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }

                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }
                            rowCount1++;
                        }
                        else
                        {

                        }
                    }

                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    PlanInfoTable.Merge(ProductInfoTable);
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }

        //protected void grdPlans_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        if (e.Row.RowIndex == 0)
        //            e.Row.Style.Add("width", "8px");
        //    }
        //}

        protected void chkHeaderSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)grdPlans.HeaderRow.FindControl("chkHeaderSelect");

            foreach (GridViewRow row in grdPlans.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkItemSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "CreateGridHeader", "<script>CreateGridHeader('grdPlans');</script>", false);
        }

        private bool CheckAccountContactsSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        cnt++;
                    }
                }

                if (cnt > 3)
                {
                    string script = "alert(\"Please select max 3 Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        private bool CheckAccountContactsClientIntakeSelected()
        {
            bool flag = true;
            try
            {
                int cnt = 0;
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        cnt++;
                    }
                }

                if (cnt > 2)
                {
                    string script = "alert(\"Please select max 2 Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
                else if (cnt == 0)
                {
                    string script = "alert(\"Please select Account Contacts.\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return flag;
        }

        protected void cblistAccountContact_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dtAcctContactList = new DataTable();
                dtAcctContactList.Columns.Add("Name", typeof(string));
                dtAcctContactList.Columns.Add("ID", typeof(string));
                for (int i = 0; i < cblistAccountContact.Items.Count; i++)
                {
                    if (cblistAccountContact.Items[i].Selected == true)
                    {
                        dtAcctContactList.Rows.Add(cblistAccountContact.Items[i].Text, cblistAccountContact.Items[i].Value);
                    }
                }
                grdSelectedAccountContact.DataSource = dtAcctContactList;
                grdSelectedAccountContact.DataBind();

                ddlSelectedAccountContact.DataSource = dtAcctContactList;
                ddlSelectedAccountContact.DataBind();
            }

            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void LoadColumnIdArrayList()
        {
            try
            {
                //Medical
                MedicalBenefitColumnIdList.Add("100");
                MedicalBenefitColumnIdList.Add("101");
                MedicalBenefitColumnIdList.Add("103");
                // MedicalBenefitColumnIdList.Add("104");
                // MedicalBenefitColumnIdList.Add("105");
                MedicalBenefitColumnIdList.Add("106");
                MedicalBenefitColumnIdList.Add("108");
                MedicalBenefitColumnIdList.Add("109");
                //MedicalBenefitColumnIdList.Add("110");
                MedicalBenefitColumnIdList.Add("111");
                MedicalBenefitColumnIdList.Add("112");
                MedicalBenefitColumnIdList.Add("114");


                MedicalBenefitColumnIdList.Add("410");       // International Bundled Plan (3-Tier)	410
                //MedicalBenefitColumnIdList.Add("233");       // Limited Benefit 2-Tier	
                MedicalBenefitColumnIdList.Add("148");          //149

                //MedicalBenefitColumnIdList.Add("141");

                //Stop Loss
                StopLossBenefitColumnIdList.Add("141");       // Stop Loss
                PrescriptionDrugBenefitColumnIdList.Add("173");       // Prescription Drug (Carve-Out) -- Amogh

                //Outnetwok medical 
                MedicalBenefitColumnIdOutNetworkList.Add("102");
                MedicalBenefitColumnIdOutNetworkList.Add("104");
                MedicalBenefitColumnIdOutNetworkList.Add("107");
                MedicalBenefitColumnIdOutNetworkList.Add("110");
                MedicalBenefitColumnIdOutNetworkList.Add("113");

                //Tier 3 medical 
                MedicalBenefitColumnId_Tier3.Add("105");
                MedicalBenefitColumnId_Tier3.Add("110");

                //Outnetwok Dental 
                DentalBenefitColumnIdOutNetworkList.Add("117");

                //Dental      
                DentalBenefitColumnIdList.Add("115");
                DentalBenefitColumnIdList.Add("116");
                DentalBenefitColumnIdList.Add("118");
                DentalBenefitColumnIdList.Add("121");

                //EAP
                EAPBenefitColumnIdList.Add("133");

                //HRA
                HRABenefitColumnIdList.Add("143");

                //FSA
                FSABenefitColumnIdList.Add("135");

                //HSA
                HSABenefitColumnIdList.Add("147");

                //LTD
                LTDBenefitColumnIdList.Add("132");

                //STD
                STDBenefitColumnIdList.Add("131");

                //Vision
                VisionBenefitColumnIdList.Add("123");
                VisionBenefitColumnIdOutNetworkList.Add("124");

                //Voluntary Life & Volunatary AD&D Life
                VoluntaryLifeBenefitColumnIdList.Add("128");
                VoluntaryLifeBenefitColumnIdList.Add("130");

                //Life and AD&D
                LifeADDBenefitColumnIdList.Add("127");
                LifeADDBenefitColumnIdList.Add("140");

                // Group Term Life
                GroupTermLifeBenefitColumnIdList.Add("127");

                // ADD
                ADDBenefitColumnIdList.Add("129");
                // Accidental Plan provided by Nicole in New Development request Account Profile Details - Added by Amogh
                AccidentalBenefitColumnIdList.Add("134");        // Business Travel Accident (BTA)

                // Wellness
                WellnessBenefitColumnIdList.Add("162");
                WellnessBenefitColumnIdList.Add("317");
                //WellnessBenefitColumnIdList.Add("1740");



                //Disability Plan provided by Nicole in New Development request Account Profile Details - Added by Amogh
                DisabilityBenefitColumnIdList.Add("151"); //New York DBL
                DisabilityBenefitColumnIdList.Add("152"); //New Jersey TDB
                DisabilityBenefitColumnIdList.Add("153"); //Hawaii TDI

                //Addtional product provided by Nicole in New Development request Account Profile Details - Added by Amogh
                AdditionalProductsBenefitColumnIdList.Add("1790");
                AdditionalProductsBenefitColumnIdList.Add("5460");
                AdditionalProductsBenefitColumnIdList.Add("5500");
                AdditionalProductsBenefitColumnIdList.Add("1400");
                AdditionalProductsBenefitColumnIdList.Add("1160");
                AdditionalProductsBenefitColumnIdList.Add("1740"); // As Per Nicole we added in Additional Product List 
                ////AdditionalProductsBenefitColumnIdList.Add("1109");       // COBRA Administration
                ////AdditionalProductsBenefitColumnIdList.Add("5060");       // Hospitalization

            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }


        protected void CreatePlanTable()
        {
            try
            {
                //Medical
                BindPlanTable(ddlMedicalPlanName1, ddlMedicalBenefitSummary1, ddlMedicalContribution1, ddlMedicalRate1, 1, ddlMedicalContribution1_2, ddlMedicalEligibility1);
                BindPlanTable(ddlMedicalPlanName2, ddlMedicalBenefitSummary2, ddlMedicalContribution2, ddlMedicalRate2, 2, ddlMedicalContribution2_2, ddlMedicalEligibility2);
                BindPlanTable(ddlMedicalPlanName3, ddlMedicalBenefitSummary3, ddlMedicalContribution3, ddlMedicalRate3, 3, ddlMedicalContribution3_2, ddlMedicalEligibility3);
                BindPlanTable(ddlMedicalPlanName4, ddlMedicalBenefitSummary4, ddlMedicalContribution4, ddlMedicalRate4, 4, ddlMedicalContribution4_2, ddlMedicalEligibility4);
                BindPlanTable(ddlMedicalPlanName5, ddlMedicalBenefitSummary5, ddlMedicalContribution5, ddlMedicalRate5, 5, ddlMedicalContribution5_2, ddlMedicalEligibility5);
                BindPlanTable(ddlMedicalPlanName6, ddlMedicalBenefitSummary6, ddlMedicalContribution6, ddlMedicalRate6, 6, ddlMedicalContribution6_2, ddlMedicalEligibility6);
                //Dental
                BindPlanTable(ddlDentalPlanName1, ddlDentalBenefitSummary1, ddlDentalContribution1, ddlDentalRate1, 1, ddlDentalContribution1_2, ddlDentalEligibility1);
                BindPlanTable(ddlDentalPlanName2, ddlDentalBenefitSummary2, ddlDentalContribution2, ddlDentalRate2, 2, ddlDentalContribution2_2, ddlDentalEligibility2);
                BindPlanTable(ddlDentalPlanName3, ddlDentalBenefitSummary3, ddlDentalContribution3, ddlDentalRate3, 3, ddlDentalContribution3_2, ddlDentalEligibility3);
                BindPlanTable(ddlDentalPlanName4, ddlDentalBenefitSummary4, ddlDentalContribution4, ddlDentalRate4, 4, ddlDentalContribution4_2, ddlDentalEligibility4);
                BindPlanTable(ddlDentalPlanName5, ddlDentalBenefitSummary5, ddlDentalContribution5, ddlDentalRate5, 5, ddlDentalContribution5_2, ddlDentalEligibility5);
                BindPlanTable(ddlDentalPlanName6, ddlDentalBenefitSummary6, ddlDentalContribution6, ddlDentalRate6, 6, ddlDentalContribution6_2, ddlDentalEligibility6);

                //Vision
                BindPlanTable(ddlVisionPlanName1, ddlVisionBenefitSummary1, ddlVisionContribution1, ddlVisionRate1, 1, ddlVisionContribution1_2, ddlVisionEligibility1);
                BindPlanTable(ddlVisionPlanName2, ddlVisionBenefitSummary2, ddlVisionContribution2, ddlVisionRate2, 2, ddlVisionContribution2_2, ddlVisionEligibility2);
                BindPlanTable(ddlVisionPlanName3, ddlVisionBenefitSummary3, ddlVisionContribution3, ddlVisionRate3, 3, ddlVisionContribution3_2, ddlVisionEligibility3);
                BindPlanTable(ddlVisionPlanName4, ddlVisionBenefitSummary4, ddlVisionContribution4, ddlVisionRate4, 4, ddlVisionContribution4_2, ddlVisionEligibility4);
                BindPlanTable(ddlVisionPlanName5, ddlVisionBenefitSummary5, ddlVisionContribution5, ddlVisionRate5, 5, ddlVisionContribution5_2, ddlVisionEligibility5);
                BindPlanTable(ddlVisionPlanName6, ddlVisionBenefitSummary6, ddlVisionContribution6, ddlVisionRate6, 6, ddlVisionContribution6_2, ddlVisionEligibility6);

                //Life & ADD 
                BindPlanTable(ddlLifeADDPlanName1, ddlLifeADDBenefitSummary1, null, ddlLifeADDRate1, 1, null, ddlLifeADDEligibility1);
                BindPlanTable(ddlLifeADDPlanName2, ddlLifeADDBenefitSummary2, null, ddlLifeADDRate2, 2, null, ddlLifeADDEligibility2);
                BindPlanTable(ddlLifeADDPlanName3, ddlLifeADDBenefitSummary3, null, ddlLifeADDRate3, 3, null, ddlLifeADDEligibility3);
                BindPlanTable(ddlLifeADDPlanName4, ddlLifeADDBenefitSummary4, null, ddlLifeADDRate4, 4, null, ddlLifeADDEligibility4);
                BindPlanTable(ddlLifeADDPlanName5, ddlLifeADDBenefitSummary5, null, ddlLifeADDRate5, 5, null, ddlLifeADDEligibility5);
                BindPlanTable(ddlLifeADDPlanName6, ddlLifeADDBenefitSummary6, null, ddlLifeADDRate6, 6, null, ddlLifeADDEligibility6);

                #region STD Bind

                if (ddlSTDPlanName1.SelectedItem != null)
                {
                    if (ddlSTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName1, ddlSTDBenefitSummary1, null, ddlSTDRate1, 1, null, ddlSTDEligibility1);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName1, ddlSTDBenefitSummary1, null, ddlSTDRate1, 1, null, ddlSTDEligibility1);
                    }
                }

                if (ddlSTDPlanName2.SelectedItem != null)
                {
                    if (ddlSTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName2, ddlSTDBenefitSummary2, null, ddlSTDRate2, 2, null, ddlSTDEligibility2);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName2, ddlSTDBenefitSummary2, null, ddlSTDRate2, 2, null, ddlSTDEligibility2);
                    }
                }

                if (ddlSTDPlanName3.SelectedItem != null)
                {
                    if (ddlSTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName3, ddlSTDBenefitSummary3, null, ddlSTDRate3, 3, null, ddlSTDEligibility3);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName3, ddlSTDBenefitSummary3, null, ddlSTDRate3, 3, null, ddlSTDEligibility3);
                    }
                }
                if (ddlSTDPlanName4.SelectedItem != null)
                {
                    if (ddlSTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName4, ddlSTDBenefitSummary4, null, ddlSTDRate4, 4, null, ddlSTDEligibility4);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName4, ddlSTDBenefitSummary4, null, ddlSTDRate4, 4, null, ddlSTDEligibility4);
                    }
                }
                if (ddlSTDPlanName5.SelectedItem != null)
                {
                    if (ddlSTDPlanName5.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName5, ddlSTDBenefitSummary5, null, ddlSTDRate5, 5, null, ddlSTDEligibility5);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName5, ddlSTDBenefitSummary5, null, ddlSTDRate5, 5, null, ddlSTDEligibility5);
                    }
                }

                if (ddlSTDPlanName6.SelectedItem != null)
                {
                    if (ddlSTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlSTDPlanName6, ddlSTDBenefitSummary6, null, ddlSTDRate6, 6, null, ddlSTDEligibility6);
                    }
                    else
                    {
                        BindPlanTable(ddlSTDPlanName6, ddlSTDBenefitSummary6, null, ddlSTDRate6, 6, null, ddlSTDEligibility6);
                    }
                }

                #endregion
                #region LTD Bind Plan Table


                if (ddlLTDPlanName1.SelectedItem != null)
                {
                    if (ddlLTDPlanName1.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName1, ddlLTDBenefitSummary1, null, ddlLTDRate1, 1, null, ddlLTDEligibility1);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName1, ddlLTDBenefitSummary1, null, ddlLTDRate1, 1, null, ddlLTDEligibility1);

                    }
                }

                if (ddlLTDPlanName2.SelectedItem != null)
                {
                    if (ddlLTDPlanName2.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName2, ddlLTDBenefitSummary2, null, ddlLTDRate2, 2, null, ddlLTDEligibility2);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName2, ddlLTDBenefitSummary2, null, ddlLTDRate2, 2, null, ddlLTDEligibility2);

                    }
                }


                if (ddlLTDPlanName3.SelectedItem != null)
                {
                    if (ddlLTDPlanName3.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName3, ddlLTDBenefitSummary3, null, ddlLTDRate3, 3, null, ddlLTDEligibility3);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName3, ddlLTDBenefitSummary3, null, ddlLTDRate3, 3, null, ddlLTDEligibility3);

                    }
                }


                if (ddlLTDPlanName4.SelectedItem != null)
                {
                    if (ddlLTDPlanName4.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName4, ddlLTDBenefitSummary4, null, ddlLTDRate4, 4, null, ddlLTDEligibility4);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName4, ddlLTDBenefitSummary4, null, ddlLTDRate4, 4, null, ddlLTDEligibility4);

                    }
                }


                if (ddlLTDPlanName5.SelectedItem != null)
                {
                    if (ddlLTDPlanName5.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName5, ddlLTDBenefitSummary5, null, ddlLTDRate5, 5, null, ddlLTDEligibility5);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName5, ddlLTDBenefitSummary5, null, ddlLTDRate5, 5, null, ddlLTDEligibility5);

                    }
                }


                if (ddlLTDPlanName6.SelectedItem != null)
                {
                    if (ddlLTDPlanName6.SelectedItem.Text.Contains("Voluntary"))
                    {
                        BindPlanTable(ddlLTDPlanName6, ddlLTDBenefitSummary6, null, ddlLTDRate6, 6, null, ddlLTDEligibility6);
                    }
                    else
                    {
                        BindPlanTable(ddlLTDPlanName6, ddlLTDBenefitSummary6, null, ddlLTDRate6, 6, null, ddlLTDEligibility6);

                    }
                }


                #endregion

                //Voluntary Life & Voluntary AD&D
                BindPlanTable(ddlVoluntaryLifeADDPlanName, ddlVoluntaryLifeADDBenefitSummary, null, null, 1, null, ddlVoluntaryLifeEligibility1);
                BindPlanTable(ddlVoluntaryLifeADDPlanName2, ddlVoluntaryLifeADDBenefitSummary2, null, null, 2, null, ddlVoluntaryLifeEligibility2);
                BindPlanTable(ddlVoluntaryLifeADDPlanName3, ddlVoluntaryLifeADDBenefitSummary3, null, null, 3, null, ddlVoluntaryLifeEligibility3);
                BindPlanTable(ddlVoluntaryLifeADDPlanName4, ddlVoluntaryLifeADDBenefitSummary4, null, null, 4, null, ddlVoluntaryLifeEligibility4);
                BindPlanTable(ddlVoluntaryLifeADDPlanName5, ddlVoluntaryLifeADDBenefitSummary5, null, null, 5, null, ddlVoluntaryLifeEligibility5);
                BindPlanTable(ddlVoluntaryLifeADDPlanName6, ddlVoluntaryLifeADDBenefitSummary6, null, null, 6, null, ddlVoluntaryLifeEligibility6);

                //EAP
                BindPlanTable(ddlEAPPlanName, ddlEAPBenefitSummary, null, null, 1, null, ddlEAPEligibility1);
                BindPlanTable(ddlEAPPlanName2, ddlEAPBenefitSummary2, null, null, 2, null, ddlEAPEligibility2);
                BindPlanTable(ddlEAPPlanName3, ddlEAPBenefitSummary3, null, null, 3, null, ddlEAPEligibility3);
                BindPlanTable(ddlEAPPlanName4, ddlEAPBenefitSummary4, null, null, 4, null, ddlEAPEligibility4);
                BindPlanTable(ddlEAPPlanName5, ddlEAPBenefitSummary5, null, null, 5, null, ddlEAPEligibility5);
                BindPlanTable(ddlEAPPlanName6, ddlEAPBenefitSummary6, null, null, 6, null, ddlEAPEligibility6);

                //FSA
                BindPlanTable(ddlFSAPlanName, ddlFSABenefitSummary, null);
                BindPlanTable(ddlFSAPlanName2, ddlFSABenefitSummary2, null);
                BindPlanTable(ddlFSAPlanName3, ddlFSABenefitSummary3, null);
                BindPlanTable(ddlFSAPlanName4, ddlFSABenefitSummary4, null);
                BindPlanTable(ddlFSAPlanName5, ddlFSABenefitSummary5, null);
                BindPlanTable(ddlFSAPlanName6, ddlFSABenefitSummary6, null);

                //Stop Loss
                BindPlanTable(ddlStopPlanName, ddlStopBenefitSummary, null);
                BindPlanTable(ddlStopPlanName2, ddlStopBenefitSummary2, null);
                BindPlanTable(ddlStopPlanName3, ddlStopBenefitSummary3, null);
                BindPlanTable(ddlStopPlanName4, ddlStopBenefitSummary4, null);
                BindPlanTable(ddlStopPlanName5, ddlStopBenefitSummary5, null);
                BindPlanTable(ddlStopPlanName6, ddlStopBenefitSummary6, null);

                //Prescription Drug
                BindPlanTable(ddlPrescriptionPlanName, ddlPrescriptionBenefitSummary, null);
                BindPlanTable(ddlPrescriptionPlanName2, ddlPrescriptionBenefitSummary2, null);
                BindPlanTable(ddlPrescriptionPlanName3, ddlPrescriptionBenefitSummary3, null);
                BindPlanTable(ddlPrescriptionPlanName4, ddlPrescriptionBenefitSummary4, null);
                BindPlanTable(ddlPrescriptionPlanName5, ddlPrescriptionBenefitSummary5, null);
                BindPlanTable(ddlPrescriptionPlanName6, ddlPrescriptionBenefitSummary6, null);

                //HSA
                BindPlanTable(ddlHSAPlanName, ddlHSABenefitSummary, null);
                BindPlanTable(ddlHSAPlanName2, ddlHSABenefitSummary2, null);
                BindPlanTable(ddlHSAPlanName3, ddlHSABenefitSummary3, null);
                BindPlanTable(ddlHSAPlanName4, ddlHSABenefitSummary4, null);
                BindPlanTable(ddlHSAPlanName5, ddlHSABenefitSummary5, null);
                BindPlanTable(ddlHSAPlanName6, ddlHSABenefitSummary6, null);
                //HRA
                BindPlanTable(ddlHRAPlanName, ddlHRABenefitSummary, null);
                BindPlanTable(ddlHRAPlanName2, ddlHRABenefitSummary2, null);
                BindPlanTable(ddlHRAPlanName3, ddlHRABenefitSummary3, null);
                BindPlanTable(ddlHRAPlanName4, ddlHRABenefitSummary4, null);
                BindPlanTable(ddlHRAPlanName5, ddlHRABenefitSummary5, null);
                BindPlanTable(ddlHRAPlanName6, ddlHRABenefitSummary6, null);

                // Added for service calendar highlights
                BindPlanTable(ddlGroupTermLifePlanName, ddlGroupTermLifeBenefitSummary, null);
                BindPlanTable(ddlGroupTermLifePlanName2, ddlGroupTermLifeBenefitSummary2, null);

                BindPlanTable(ddlADNDPlanName, ddlADNDBenefitSummary, null);
                //WellNess
                BindPlanTable(ddlWellnessProgramPlanName, ddlWellnessProgramBenefitSummary, null, null, 1, null, ddlWellnessEligibility1);
                BindPlanTable(ddlWellnessProgramPlanName2, ddlWellnessProgramBenefitSummary2, null, null, 2, null, ddlWellnessEligibility2);
                BindPlanTable(ddlWellnessProgramPlanName3, ddlWellnessProgramBenefitSummary3, null, null, 3, null, ddlWellnessEligibility3);
                BindPlanTable(ddlWellnessProgramPlanName4, ddlWellnessProgramBenefitSummary4, null, null, 4, null, ddlWellnessEligibility4);
                BindPlanTable(ddlWellnessProgramPlanName5, ddlWellnessProgramBenefitSummary5, null, null, 5, null, ddlWellnessEligibility5);
                BindPlanTable(ddlWellnessProgramPlanName6, ddlWellnessProgramBenefitSummary6, null, null, 6, null, ddlWellnessEligibility6);

                //Diability
                BindPlanTable(ddlDisabilityPlanName1, ddLDisblBenefitSummary1, null, ddlDisabilityRate1, 1, null, ddlDisabilityEligibility1);
                BindPlanTable(ddlDisabilityPlanName2, ddLDisblBenefitSummary2, null, ddlDisabilityRate2, 2, null, ddlDisabilityEligibility2);
                BindPlanTable(ddlDisabilityPlanName3, ddLDisblBenefitSummary3, null, ddlDisabilityRate3, 3, null, ddlDisabilityEligibility3);
                BindPlanTable(ddlDisabilityPlanName4, ddLDisblBenefitSummary4, null, ddlDisabilityRate4, 4, null, ddlDisabilityEligibility4);
                BindPlanTable(ddlDisabilityPlanName5, ddLDisblBenefitSummary5, null, ddlDisabilityRate5, 5, null, ddlDisabilityEligibility5);
                BindPlanTable(ddlDisabilityPlanName6, ddLDisblBenefitSummary6, null, ddlDisabilityRate6, 6, null, ddlDisabilityEligibility6);

                //Accidenat
                BindPlanTable(ddlAccidentPlanName1, ddLAccidentBenefitSummary1, null, null, 1, null, ddlAccidentEligibility1);
                BindPlanTable(ddlAccidentPlanName2, ddLAccidentBenefitSummary2, null, null, 2, null, ddlAccidentEligibility2);
                BindPlanTable(ddlAccidentPlanName3, ddLAccidentBenefitSummary3, null, null, 3, null, ddlAccidentEligibility3);
                BindPlanTable(ddlAccidentPlanName4, ddLAccidentBenefitSummary4, null, null, 4, null, ddlAccidentEligibility4);
                BindPlanTable(ddlAccidentPlanName5, ddLAccidentBenefitSummary5, null, null, 5, null, ddlAccidentEligibility5);
                BindPlanTable(ddlAccidentPlanName6, ddLAccidentBenefitSummary6, null, null, 6, null, ddlAccidentEligibility6);

                //Additional Product 
                BindAdditionalProductTable(ddlAdditionalPlanName, 0);
                BindAdditionalProductTable(ddlAdditionalPlanName2, 2);
                BindAdditionalProductTable(ddlAdditionalPlanName3, 3);
                BindAdditionalProductTable(ddlAdditionalPlanName4, 4);
                BindAdditionalProductTable(ddlAdditionalPlanName5, 5);
                BindAdditionalProductTable(ddlAdditionalPlanName6, 6);
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Bind data to Plan Table.
        /// </summary>
        /// <param name="DataTable">dtPlanInfoMaster</param>
        protected DataTable BindPlanTable(DataTable dtPlanInfoMaster)
        {
            DataTable planstable = new DataTable();
            try
            {
                planstable.Columns.Add("ProductId", typeof(Int32));
                planstable.Columns.Add("ProductName", typeof(string));
                planstable.Columns.Add("Carrier", typeof(string));
                planstable.Columns.Add("Effective", typeof(string));
                planstable.Columns.Add("Renewal", typeof(string));
                planstable.Columns.Add("PolicyNumber", typeof(string));
                planstable.Columns.Add("ProductTypeDescription", typeof(string));
                planstable.Columns.Add("PlanType", typeof(string));

                if (dtPlanInfoMaster != null)
                {
                    if (dtPlanInfoMaster.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtPlanInfoMaster.Rows.Count; i++)
                        {
                            DataRow dr = planstable.NewRow();
                            dr["ProductId"] = Convert.ToInt32(dtPlanInfoMaster.Rows[i]["ProductId"]);
                            dr["ProductName"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["ProductName"]);
                            dr["Carrier"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Carrier"]);
                            dr["Effective"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Effective"]);
                            dr["Renewal"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Renewal"]);
                            dr["PolicyNumber"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["PolicyNumber"]);
                            dr["ProductTypeDescription"] = Convert.ToString(dtPlanInfoMaster.Rows[i]["Name"]);
                            dr["PlanType"] = " ";

                            planstable.Rows.Add(dr);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return planstable;
        }

        /// <summary>
        /// Bind data to Plan Table.
        /// </summary>
        /// <param name="PlanTypeId">DropDownList Plan Type</param>
        /// <param name="Benefit">DropDownList Benefit</param>
        /// <param name="Rate">DropDownList Rate</param>
        /// <param name="Contribution">DropDownList Contribution</param>


        protected void BindPlanTable(DropDownList PlanType, DropDownList Benefit, DropDownList Contribution, DropDownList Rate = null, int PlanNumber = 0, DropDownList Contribution_2 = null, DropDownList EligibilityId = null)
        {
            try
            {
                DataTable planstable = new DataTable();
                if (Session["PlanTable"] != null)
                {
                    planstable = (DataTable)Session["PlanTable"];
                }
                else
                {
                    planstable.Columns.Add("ProductId", typeof(Int32));
                    planstable.Columns.Add("ProductName", typeof(string));
                    planstable.Columns.Add("Carrier", typeof(string));
                    planstable.Columns.Add("Effective", typeof(string));
                    planstable.Columns.Add("Renewal", typeof(string));
                    planstable.Columns.Add("PolicyNumber", typeof(string));
                    planstable.Columns.Add("ProductTypeDescription", typeof(string));
                    planstable.Columns.Add("SummaryName", typeof(string));
                    planstable.Columns.Add("SummaryId", typeof(Int32));
                    planstable.Columns.Add("RateName", typeof(string));
                    planstable.Columns.Add("RateId", typeof(Int32));
                    planstable.Columns.Add("ContributionName", typeof(string));
                    planstable.Columns.Add("ContributionId", typeof(Int32));
                    planstable.Columns.Add("ContributionName_2", typeof(string));
                    planstable.Columns.Add("ContributionId_2", typeof(Int32));
                    planstable.Columns.Add("PlanType", typeof(string));
                    planstable.Columns.Add("PlanNumber", typeof(string));
                    planstable.Columns.Add("EligibilityId", typeof(Int32));
                }

                DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

                if (PlanType.SelectedIndex > 0)
                {
                    DataRow[] foundrow = null;
                    foundrow = ProductSummaryTable.Select("ProductId='" + int.Parse(PlanType.SelectedValue.ToString()) + "'");
                    DataRow dr = planstable.NewRow();
                    dr["ProductId"] = PlanType.SelectedValue;
                    dr["ProductName"] = PlanType.SelectedItem.Text;
                    if (foundrow.Count() > 0)
                    {
                        dr["Carrier"] = foundrow[0]["Carrier"];
                        dr["Effective"] = foundrow[0]["Effective"];
                        dr["Renewal"] = foundrow[0]["Renewal"];
                        dr["PolicyNumber"] = foundrow[0]["PolicyNumber"];
                        dr["ProductTypeDescription"] = foundrow[0]["ProductTypeDescription"];
                        dr["PlanType"] = foundrow[0]["PlanType"];
                        dr["PlanNumber"] = foundrow[0]["PlanType"] + " " + Convert.ToString(PlanNumber);
                    }
                    else
                    {
                        dr["Carrier"] = "";
                        dr["Effective"] = "";
                        dr["Renewal"] = "";
                        dr["PolicyNumber"] = "";
                        dr["ProductTypeDescription"] = "";
                        dr["PlanType"] = "";
                        dr["PlanNumber"] = "";
                    }
                    if (Benefit.SelectedIndex > 0)
                    {
                        dr["SummaryName"] = Benefit.SelectedItem.Text;
                        dr["SummaryId"] = Benefit.SelectedValue;
                    }
                    else
                    {
                        dr["SummaryName"] = "";
                        dr["SummaryId"] = -1;
                    }
                    if (Rate != null && Rate.SelectedIndex > 0)
                    {
                        dr["RateName"] = Rate.SelectedItem.Text;
                        dr["RateId"] = Rate.SelectedValue;
                    }
                    else
                    {
                        dr["RateName"] = "";
                        dr["RateId"] = -1;
                    }
                    if (Contribution != null && Contribution.SelectedIndex > 0)
                    {
                        dr["ContributionName"] = Contribution.SelectedItem.Text;
                        dr["ContributionId"] = Contribution.SelectedValue;
                    }
                    else
                    {
                        dr["ContributionName"] = "";
                        dr["ContributionId"] = -1;
                    }

                    if (Contribution_2 != null && Contribution_2.SelectedIndex > 0)
                    {
                        dr["ContributionName_2"] = Contribution_2.SelectedItem.Text;
                        dr["ContributionId_2"] = Contribution_2.SelectedValue;
                    }
                    else
                    {
                        dr["ContributionName_2"] = "";
                        dr["ContributionId_2"] = -1;
                    }

                    /*--------Added by Amogh For Adding EligibilityId */
                    if (EligibilityId != null && EligibilityId.SelectedIndex > 0)
                    {
                        dr["EligibilityId"] = EligibilityId.SelectedValue;
                    }
                    else
                    {
                        dr["EligibilityId"] = -1;
                    }
                    planstable.Rows.Add(dr);
                    Session["PlanTable"] = planstable;
                }
                for (int i = 0; i < planstable.Rows.Count; i++)
                {
                    if (int.Parse(planstable.Rows[i]["SummaryId"].ToString()) == -1)
                    {
                        planstable.Rows[i].Delete();
                    }
                }
                Session["PlanTable"] = planstable;
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        //This Function Is use for Bind Additional Product 
        protected void BindAdditionalProductTable(DropDownList PlanType, int PlanNumber = 0)
        {
            try
            {
                DataTable AdditionalProductTable = new DataTable();
                if (Session["AdditionalProductTable"] != null)
                {
                    AdditionalProductTable = (DataTable)Session["AdditionalProductTable"];
                }
                else
                {
                    AdditionalProductTable.Columns.Add("ProductId", typeof(Int32));
                    AdditionalProductTable.Columns.Add("ProductName", typeof(string));
                    AdditionalProductTable.Columns.Add("Carrier", typeof(string));
                    AdditionalProductTable.Columns.Add("Effective", typeof(string));
                    AdditionalProductTable.Columns.Add("Renewal", typeof(string));
                    AdditionalProductTable.Columns.Add("PolicyNumber", typeof(string));
                    AdditionalProductTable.Columns.Add("ProductTypeDescription", typeof(string));
                    AdditionalProductTable.Columns.Add("SummaryName", typeof(string));
                    AdditionalProductTable.Columns.Add("SummaryId", typeof(Int32));
                    AdditionalProductTable.Columns.Add("RateName", typeof(string));
                    AdditionalProductTable.Columns.Add("RateId", typeof(Int32));
                    AdditionalProductTable.Columns.Add("ContributionName", typeof(string));
                    AdditionalProductTable.Columns.Add("ContributionId", typeof(Int32));
                    AdditionalProductTable.Columns.Add("ContributionName_2", typeof(string));
                    AdditionalProductTable.Columns.Add("ContributionId_2", typeof(Int32));
                    AdditionalProductTable.Columns.Add("PlanType", typeof(string));
                    AdditionalProductTable.Columns.Add("PlanNumber", typeof(string));
                    AdditionalProductTable.Columns.Add("EligibilityId", typeof(Int32));
                }
                DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

                if (PlanType.SelectedIndex > 0)
                {
                    DataRow[] foundrow = null;
                    foundrow = ProductSummaryTable.Select("ProductId='" + int.Parse(PlanType.SelectedValue.ToString()) + "'");
                    DataRow dr = AdditionalProductTable.NewRow();
                    dr["ProductId"] = PlanType.SelectedValue;
                    dr["ProductName"] = PlanType.SelectedItem.Text;
                    if (foundrow.Count() > 0)
                    {
                        dr["Carrier"] = foundrow[0]["Carrier"];
                        dr["Effective"] = foundrow[0]["Effective"];
                        dr["Renewal"] = foundrow[0]["Renewal"];
                        dr["PolicyNumber"] = foundrow[0]["PolicyNumber"];
                        dr["ProductTypeDescription"] = foundrow[0]["ProductTypeDescription"];
                        dr["PlanType"] = foundrow[0]["PlanType"];
                        dr["PlanNumber"] = foundrow[0]["PlanType"] + " " + Convert.ToString(PlanNumber);
                    }
                    else
                    {
                        dr["Carrier"] = "";
                        dr["Effective"] = "";
                        dr["Renewal"] = "";
                        dr["PolicyNumber"] = "";
                        dr["ProductTypeDescription"] = "";
                        dr["PlanType"] = "";
                        dr["PlanNumber"] = "";
                    }
                    AdditionalProductTable.Rows.Add(dr);
                    Session["AdditionalProductTable"] = AdditionalProductTable;
                }
                for (int i = 0; i < AdditionalProductTable.Rows.Count; i++)
                {
                    if (AdditionalProductTable.Rows[i]["SummaryId"].ToString() != "" && AdditionalProductTable.Rows[i]["SummaryId"].ToString() != null)
                    {
                        if (int.Parse(AdditionalProductTable.Rows[i]["SummaryId"].ToString()) == -1)
                        {
                            AdditionalProductTable.Rows[i].Delete();
                        }
                    }
                }
                Session["AdditionalProductTable"] = AdditionalProductTable;
            }//TryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlDisabilityNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DisabilityPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Disability Selection code
        /// </summary>
        protected void DisabilityPlanSelected()
        {
            try
            {
                if (ddlDisabilityNoOfPlan.SelectedIndex == 0)
                {
                    ClearDisability();
                    if (ddlDisabilityPlanName1 != null)
                    {
                        ddlDisabilityPlanName1.Items.Clear();
                    }
                    if (ddlDisabilityPlanName2 != null)
                    {
                        ddlDisabilityPlanName2.Items.Clear();
                    }
                    if (ddlDisabilityPlanName3 != null)
                    {
                        ddlDisabilityPlanName3.Items.Clear();
                    }
                    if (ddlDisabilityPlanName4 != null)
                    {
                        ddlDisabilityPlanName4.Items.Clear();
                    }
                    if (ddlDisabilityPlanName5 != null)
                    {
                        ddlDisabilityPlanName5.Items.Clear();
                    }
                    if (ddlDisabilityPlanName6 != null)
                    {
                        ddlDisabilityPlanName6.Items.Clear();
                    }
                }
                string ch = ddlDisabilityNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> DisabilityPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.DisabilityPlanTypeList, cv.Disability, ref DisabilityPlanList);

                switch (ch)
                {
                    case "1":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = false;
                        tblDisbl_3.Visible = false;
                        tblDisbl_4.Visible = false;
                        tblDisbl_5.Visible = false;
                        tblDisbl_6.Visible = false;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);

                        ddlDisabilityPlanName2.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary2, ddlDisabilityRate2, ddlDisabilityEligibility2);
                        ddlDisabilityPlanName3.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary3, ddlDisabilityRate3, ddlDisabilityEligibility3);
                        ddlDisabilityPlanName4.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary4, ddlDisabilityRate4, ddlDisabilityEligibility4);
                        ddlDisabilityPlanName5.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary5, ddlDisabilityRate5, ddlDisabilityEligibility5);
                        ddlDisabilityPlanName6.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);

                        break;

                    case "2":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = true;
                        tblDisbl_3.Visible = false;
                        tblDisbl_4.Visible = false;
                        tblDisbl_5.Visible = false;
                        tblDisbl_6.Visible = false;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);
                        FillDropdownList(ddlDisabilityPlanName2, DisabilityPlanList, ddLDisblBenefitSummary2, null, null);

                        ddlDisabilityPlanName3.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary3, ddlDisabilityRate3, ddlDisabilityEligibility3);
                        ddlDisabilityPlanName4.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary4, ddlDisabilityRate4, ddlDisabilityEligibility4);
                        ddlDisabilityPlanName5.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary5, ddlDisabilityRate5, ddlDisabilityEligibility5);
                        ddlDisabilityPlanName6.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);

                        break;

                    case "3":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = true;
                        tblDisbl_3.Visible = true;
                        tblDisbl_4.Visible = false;
                        tblDisbl_5.Visible = false;
                        tblDisbl_6.Visible = false;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);
                        FillDropdownList(ddlDisabilityPlanName2, DisabilityPlanList, ddLDisblBenefitSummary2, null, null);
                        FillDropdownList(ddlDisabilityPlanName3, DisabilityPlanList, ddLDisblBenefitSummary3, null, null);

                        ddlDisabilityPlanName4.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary4, ddlDisabilityRate4, ddlDisabilityEligibility4);
                        ddlDisabilityPlanName5.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary5, ddlDisabilityRate5, ddlDisabilityEligibility5);
                        ddlDisabilityPlanName6.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);

                        break;

                    case "4":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = true;
                        tblDisbl_3.Visible = true;
                        tblDisbl_4.Visible = true;
                        tblDisbl_5.Visible = false;
                        tblDisbl_6.Visible = false;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);
                        FillDropdownList(ddlDisabilityPlanName2, DisabilityPlanList, ddLDisblBenefitSummary2, null, null);
                        FillDropdownList(ddlDisabilityPlanName3, DisabilityPlanList, ddLDisblBenefitSummary3, null, null);
                        FillDropdownList(ddlDisabilityPlanName4, DisabilityPlanList, ddLDisblBenefitSummary4, null, null);

                        ddlDisabilityPlanName5.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary5, ddlDisabilityRate5, ddlDisabilityEligibility5);
                        ddlDisabilityPlanName6.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);

                        break;

                    case "5":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = true;
                        tblDisbl_3.Visible = true;
                        tblDisbl_4.Visible = true;
                        tblDisbl_5.Visible = true;
                        tblDisbl_6.Visible = false;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);
                        FillDropdownList(ddlDisabilityPlanName2, DisabilityPlanList, ddLDisblBenefitSummary2, null, null);
                        FillDropdownList(ddlDisabilityPlanName3, DisabilityPlanList, ddLDisblBenefitSummary3, null, null);
                        FillDropdownList(ddlDisabilityPlanName4, DisabilityPlanList, ddLDisblBenefitSummary4, null, null);
                        FillDropdownList(ddlDisabilityPlanName5, DisabilityPlanList, ddLDisblBenefitSummary5, null, null);

                        ddlDisabilityPlanName6.Items.Clear();
                        ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);

                        break;

                    case "6":

                        tblDisbl_1.Visible = true;
                        tblDisbl_2.Visible = true;
                        tblDisbl_3.Visible = true;
                        tblDisbl_4.Visible = true;
                        tblDisbl_5.Visible = true;
                        tblDisbl_6.Visible = true;

                        FillDropdownList(ddlDisabilityPlanName1, DisabilityPlanList, ddLDisblBenefitSummary1, null, null);
                        FillDropdownList(ddlDisabilityPlanName2, DisabilityPlanList, ddLDisblBenefitSummary2, null, null);
                        FillDropdownList(ddlDisabilityPlanName3, DisabilityPlanList, ddLDisblBenefitSummary3, null, null);
                        FillDropdownList(ddlDisabilityPlanName4, DisabilityPlanList, ddLDisblBenefitSummary4, null, null);
                        FillDropdownList(ddlDisabilityPlanName5, DisabilityPlanList, ddLDisblBenefitSummary5, null, null);
                        FillDropdownList(ddlDisabilityPlanName6, DisabilityPlanList, ddLDisblBenefitSummary6, null, null);

                        break;

                    case "_":

                        tblDisbl_1.Visible = false;
                        tblDisbl_2.Visible = false;
                        tblDisbl_3.Visible = false;
                        tblDisbl_4.Visible = false;
                        tblDisbl_5.Visible = false;
                        tblDisbl_6.Visible = false;

                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ClearDisability()
        {
            ClearDropDownList(ddLDisblBenefitSummary1, ddlDisabilityRate1, ddlDisabilityEligibility1);
            ClearDropDownList(ddLDisblBenefitSummary2, ddlDisabilityRate2, ddlDisabilityEligibility2);
            ClearDropDownList(ddLDisblBenefitSummary3, ddlDisabilityRate3, ddlDisabilityEligibility3);
            ClearDropDownList(ddLDisblBenefitSummary4, ddlDisabilityRate4, ddlDisabilityEligibility4);
            ClearDropDownList(ddLDisblBenefitSummary5, ddlDisabilityRate5, ddlDisabilityEligibility5);
            ClearDropDownList(ddLDisblBenefitSummary6, ddlDisabilityRate6, ddlDisabilityEligibility6);
        }

        protected void ddlDisabilityPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName1.SelectedValue), ddLDisblBenefitSummary1, ddlDisabilityRate1, null, ddlDisabilityEligibility1);
            }
            else
            {
                ClearDropDownList(ddLDisblBenefitSummary1, ddlDisabilityRate1, ddlDisabilityEligibility1);
            }
        }

        protected void ddlDisabilityPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName2.SelectedValue), ddLDisblBenefitSummary2, ddlDisabilityRate2, null, ddlDisabilityEligibility2);
            }
            else
            {
                ClearDropDownList(ddlDisabilityPlanName2, ddlDisabilityRate2, ddlDisabilityEligibility2);
            }
        }

        protected void ddlDisabilityPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName3.SelectedValue), ddLDisblBenefitSummary3, ddlDisabilityRate3, null, ddlDisabilityEligibility3);
            }
            else
            {
                ClearDropDownList(ddlDisabilityPlanName3, ddlDisabilityRate3, ddlDisabilityEligibility3);
            }
        }
        protected void ddlDisabilityPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName4.SelectedValue), ddLDisblBenefitSummary4, ddlDisabilityRate4, null, ddlDisabilityEligibility4);
            }
            else
            {
                ClearDropDownList(ddlDisabilityPlanName4, ddlDisabilityRate4, ddlDisabilityEligibility4);
            }
        }

        protected void ddlDisabilityPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName5.SelectedValue), ddLDisblBenefitSummary5, ddlDisabilityRate5, null, ddlDisabilityEligibility5);
            }
            else
            {
                ClearDropDownList(ddlDisabilityPlanName5, ddlDisabilityRate5, ddlDisabilityEligibility5);
            }
        }
        protected void ddlDisabilityPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDisabilityPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlDisabilityPlanName6.SelectedValue), ddLDisblBenefitSummary6, ddlDisabilityRate6, null, ddlDisabilityEligibility6);
            }
            else
            {
                ClearDropDownList(ddlDisabilityPlanName6, ddlDisabilityRate6, ddlDisabilityEligibility6);
            }
        }

        protected void ddlAccidentNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                AccidentalPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void AccidentalPlanSelected()
        {
            try
            {
                if (ddlAccidentNoOfPlan.SelectedIndex == 0)
                {
                    ClearAccident();
                    if (ddlAccidentPlanName1 != null)
                    {
                        ddlAccidentPlanName1.Items.Clear();
                    }
                    if (ddlAccidentPlanName2 != null)
                    {
                        ddlAccidentPlanName2.Items.Clear();
                    }
                    if (ddlAccidentPlanName3 != null)
                    {
                        ddlAccidentPlanName3.Items.Clear();
                    }
                    if (ddlAccidentPlanName4 != null)
                    {
                        ddlAccidentPlanName4.Items.Clear();
                    }
                    if (ddlAccidentPlanName5 != null)
                    {
                        ddlAccidentPlanName5.Items.Clear();
                    }
                    if (ddlAccidentPlanName6 != null)
                    {
                        ddlAccidentPlanName6.Items.Clear();
                    }

                }
                string ch = ddlAccidentNoOfPlan.SelectedItem.Text;
                BPBusiness bp = new BPBusiness();
                List<Plan> AccidentPlanPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.AccidentalProductPlanTypeList, cv.Accident, ref AccidentPlanPlanList);

                switch (ch)
                {
                    case "1":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = false;
                        tblAccident_3.Visible = false;
                        tblAccident_4.Visible = false;
                        tblAccident_5.Visible = false;
                        tblAccident_6.Visible = false;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);

                        ddlAccidentPlanName2.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary2, ddlAccidentEligibility2, null);
                        ddlAccidentPlanName3.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary3, ddlAccidentEligibility3, null);
                        ddlAccidentPlanName4.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary4, ddlAccidentEligibility4, null);
                        ddlAccidentPlanName5.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5, null);
                        ddlAccidentPlanName6.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);

                        break;

                    case "2":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = true;
                        tblAccident_3.Visible = false;
                        tblAccident_4.Visible = false;
                        tblAccident_5.Visible = false;
                        tblAccident_6.Visible = false;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);
                        FillDropdownList(ddlAccidentPlanName2, AccidentPlanPlanList, ddLAccidentBenefitSummary2, null, null);

                        ddlAccidentPlanName3.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary3, ddlAccidentEligibility3, null);
                        ddlAccidentPlanName4.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary4, ddlAccidentEligibility4, null);
                        ddlAccidentPlanName5.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5, null);
                        ddlAccidentPlanName6.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);

                        break;

                    case "3":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = true;
                        tblAccident_3.Visible = true;
                        tblAccident_4.Visible = false;
                        tblAccident_5.Visible = false;
                        tblAccident_6.Visible = false;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);
                        FillDropdownList(ddlAccidentPlanName2, AccidentPlanPlanList, ddLAccidentBenefitSummary2, null, null);
                        FillDropdownList(ddlAccidentPlanName3, AccidentPlanPlanList, ddLAccidentBenefitSummary3, null, null);


                        ddlAccidentPlanName4.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary4, ddlAccidentEligibility4, null);
                        ddlAccidentPlanName5.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5, null);
                        ddlAccidentPlanName6.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);

                        break;
                    case "4":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = true;
                        tblAccident_3.Visible = true;
                        tblAccident_4.Visible = true;
                        tblAccident_5.Visible = false;
                        tblAccident_6.Visible = false;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);
                        FillDropdownList(ddlAccidentPlanName2, AccidentPlanPlanList, ddLAccidentBenefitSummary2, null, null);
                        FillDropdownList(ddlAccidentPlanName3, AccidentPlanPlanList, ddLAccidentBenefitSummary3, null, null);
                        FillDropdownList(ddlAccidentPlanName4, AccidentPlanPlanList, ddLAccidentBenefitSummary4, null, null);

                        ddlAccidentPlanName5.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5, null);
                        ddlAccidentPlanName6.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);
                        break;

                    case "5":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = true;
                        tblAccident_3.Visible = true;
                        tblAccident_4.Visible = true;
                        tblAccident_5.Visible = true;
                        tblAccident_6.Visible = false;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);
                        FillDropdownList(ddlAccidentPlanName2, AccidentPlanPlanList, ddLAccidentBenefitSummary2, null, null);
                        FillDropdownList(ddlAccidentPlanName3, AccidentPlanPlanList, ddLAccidentBenefitSummary3, null, null);
                        FillDropdownList(ddlAccidentPlanName4, AccidentPlanPlanList, ddLAccidentBenefitSummary4, null, null);
                        FillDropdownList(ddlAccidentPlanName5, AccidentPlanPlanList, ddLAccidentBenefitSummary5, null, null);

                        ddlAccidentPlanName6.Items.Clear();
                        ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);

                        break;

                    case "6":
                        tblAccident_1.Visible = true;
                        tblAccident_2.Visible = true;
                        tblAccident_3.Visible = true;
                        tblAccident_4.Visible = true;
                        tblAccident_5.Visible = true;
                        tblAccident_6.Visible = true;

                        FillDropdownList(ddlAccidentPlanName1, AccidentPlanPlanList, ddLAccidentBenefitSummary1, null, null);
                        FillDropdownList(ddlAccidentPlanName2, AccidentPlanPlanList, ddLAccidentBenefitSummary2, null, null);
                        FillDropdownList(ddlAccidentPlanName3, AccidentPlanPlanList, ddLAccidentBenefitSummary3, null, null);
                        FillDropdownList(ddlAccidentPlanName4, AccidentPlanPlanList, ddLAccidentBenefitSummary4, null, null);
                        FillDropdownList(ddlAccidentPlanName5, AccidentPlanPlanList, ddLAccidentBenefitSummary5, null, null);
                        FillDropdownList(ddlAccidentPlanName6, AccidentPlanPlanList, ddLAccidentBenefitSummary6, null, null);
                        break;

                    case "_":
                        tblAccident_1.Visible = false;
                        tblAccident_2.Visible = false;
                        tblAccident_3.Visible = false;
                        tblAccident_4.Visible = false;
                        tblAccident_5.Visible = false;
                        tblAccident_6.Visible = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlAccidentPlanName1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName1.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName1.SelectedValue), ddLAccidentBenefitSummary1, null, null, ddlAccidentEligibility1);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary1, ddlAccidentEligibility1);
            }
        }

        protected void ddlAccidentPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName2.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName2.SelectedValue), ddLAccidentBenefitSummary2, null, null, ddlAccidentEligibility2);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary2, ddlAccidentEligibility2);
            }
        }

        protected void ddlAccidentPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName3.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName3.SelectedValue), ddLAccidentBenefitSummary3, null, null, ddlAccidentEligibility3);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary3, ddlAccidentEligibility3);
            }
        }

        protected void ddlAccidentPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName4.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName4.SelectedValue), ddLAccidentBenefitSummary4, null, null, ddlAccidentEligibility4);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary4, ddlAccidentEligibility4);
            }
        }

        protected void ddlAccidentPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName5.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName5.SelectedValue), ddLAccidentBenefitSummary5, null, null, ddlAccidentEligibility5);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5);
            }
        }

        protected void ddlAccidentPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlAccidentPlanName6.SelectedIndex > 0)
            {
                BindDataToPlan(int.Parse(ddlAccidentPlanName6.SelectedValue), ddLAccidentBenefitSummary6, null, null, ddlAccidentEligibility6);
            }
            else
            {
                ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6);
            }
        }

        protected void ClearAccident()
        {
            ClearDropDownList(ddLAccidentBenefitSummary1, ddlAccidentEligibility1, null);
            ClearDropDownList(ddLAccidentBenefitSummary2, ddlAccidentEligibility2, null);
            ClearDropDownList(ddLAccidentBenefitSummary3, ddlAccidentEligibility3, null);
            ClearDropDownList(ddLAccidentBenefitSummary4, ddlAccidentEligibility4, null);
            ClearDropDownList(ddLAccidentBenefitSummary5, ddlAccidentEligibility5, null);
            ClearDropDownList(ddLAccidentBenefitSummary6, ddlAccidentEligibility6, null);
        }


        /*--------*---------*-------------*--------------------*-------------*--------------------*/
        /*                 Added By Amogh For Additional Product Section                          */
        /*--------*---------*-------------*--------------------*-------------*--------------------*/

        protected void AdditionalProductPlanSelected()
        {
            try
            {
                if (ddlAdditionalNoOfPlan.SelectedIndex == 0)
                {
                    ClearAdditionalProduct();
                    if (ddlAdditionalPlanName != null)
                    {
                        ddlAdditionalPlanName.Items.Clear();
                    }
                    if (ddlAdditionalPlanName2 != null)
                    {
                        ddlAdditionalPlanName2.Items.Clear();
                    }
                    if (ddlAdditionalPlanName3 != null)
                    {
                        ddlAdditionalPlanName3.Items.Clear();
                    }
                    if (ddlAdditionalPlanName4 != null)
                    {
                        ddlAdditionalPlanName4.Items.Clear();
                    }
                    if (ddlAdditionalPlanName5 != null)
                    {
                        ddlAdditionalPlanName5.Items.Clear();
                    }
                    if (ddlAdditionalPlanName6 != null)
                    {
                        ddlAdditionalPlanName6.Items.Clear();
                    }

                }
                string ch = ddlAdditionalNoOfPlan.SelectedItem.Text;

                List<Plan> AdditionalProductPlanList = new List<Plan>();
                Plan PlanItem = new Plan();

                GetPlanDetailsForSelectedPlanSections(CommonFunctionsBS.AdditionalProductsPlanTypeList, cv.AdditionalProducts, ref AdditionalProductPlanList);

                switch (ch)
                {
                    case "1":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = false;
                        tblAdditional_3.Visible = false;
                        tblAdditional_4.Visible = false;
                        tblAdditional_5.Visible = false;
                        tblAdditional_6.Visible = false;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        ddlAdditionalPlanName2.Items.Clear();
                        ddlAdditionalPlanName3.Items.Clear();
                        ddlAdditionalPlanName4.Items.Clear();
                        ddlAdditionalPlanName5.Items.Clear();
                        ddlAdditionalPlanName6.Items.Clear();

                        break;

                    case "2":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = true;
                        tblAdditional_3.Visible = false;
                        tblAdditional_4.Visible = false;
                        tblAdditional_5.Visible = false;
                        tblAdditional_6.Visible = false;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList);
                        //FillDropdownList(ddlAdditionalPlanName, AdditionalProductPlanList, null, null, null);
                        //FillDropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList, null, null, null);
                        ddlAdditionalPlanName3.Items.Clear();
                        ddlAdditionalPlanName4.Items.Clear();
                        ddlAdditionalPlanName5.Items.Clear();
                        ddlAdditionalPlanName6.Items.Clear();

                        break;

                    case "3":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = true;
                        tblAdditional_3.Visible = true;
                        tblAdditional_4.Visible = false;
                        tblAdditional_5.Visible = false;
                        tblAdditional_6.Visible = false;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName3, AdditionalProductPlanList);

                        ddlAdditionalPlanName4.Items.Clear();
                        ddlAdditionalPlanName5.Items.Clear();
                        ddlAdditionalPlanName6.Items.Clear();

                        break;

                    case "4":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = true;
                        tblAdditional_3.Visible = true;
                        tblAdditional_4.Visible = true;
                        tblAdditional_5.Visible = false;
                        tblAdditional_6.Visible = false;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName3, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName4, AdditionalProductPlanList);

                        ddlAdditionalPlanName5.Items.Clear();
                        ddlAdditionalPlanName6.Items.Clear();

                        break;

                    case "5":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = true;
                        tblAdditional_3.Visible = true;
                        tblAdditional_4.Visible = true;
                        tblAdditional_5.Visible = true;
                        tblAdditional_6.Visible = false;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName3, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName4, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName5, AdditionalProductPlanList);

                        ddlAdditionalPlanName6.Items.Clear();


                        break;

                    case "6":

                        tblAdditional_1.Visible = true;
                        tblAdditional_2.Visible = true;
                        tblAdditional_3.Visible = true;
                        tblAdditional_4.Visible = true;
                        tblAdditional_5.Visible = true;
                        tblAdditional_6.Visible = true;

                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName2, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName3, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName4, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName5, AdditionalProductPlanList);
                        FillAdditionalProduct_DropdownList(ddlAdditionalPlanName6, AdditionalProductPlanList);

                        break;

                    case "_":
                        tblAdditional_1.Visible = false;
                        tblAdditional_2.Visible = false;
                        tblAdditional_3.Visible = false;
                        tblAdditional_4.Visible = false;
                        tblAdditional_5.Visible = false;
                        tblAdditional_6.Visible = false;
                        break;

                }//SwitchCloseHere
            }//TryClose
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlAdditionalNoOfPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                AdditionalProductPlanSelected();
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        protected void ddlAdditionalPlanName_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////if (ddlAdditionalPlanName.SelectedIndex > 0)
            ////{
            ////    BindDataToPlan(int.Parse(ddlAdditionalPlanName.SelectedValue), ddlAdditionalBenefitSummary, null, null);
            ////}
            ////else
            ////{
            ////    ClearDropDownList(ddlAdditionalBenefitSummary, null);
            ////}
        }

        protected void ddlAdditionalPlanName2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////if (ddlAdditionalPlanName2.SelectedIndex > 0)
            ////{
            ////    BindDataToPlan(int.Parse(ddlAdditionalPlanName2.SelectedValue), ddlAdditionalBenefitSummary2, null, null);
            ////}
            ////else
            ////{
            ////    ClearDropDownList(ddlAdditionalBenefitSummary2, null);
            ////}
        }

        protected void ddlAdditionalPlanName3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (ddlAdditionalPlanName3.SelectedIndex > 0)
            //{
            //    BindDataToPlan(int.Parse(ddlAdditionalPlanName3.SelectedValue), ddlAdditionalBenefitSummary3, null, null);
            //}
            //else
            //{
            //    ClearDropDownList(ddlAdditionalBenefitSummary3, null);
            //}
        }

        protected void ddlAdditionalPlanName4_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (ddlAdditionalPlanName4.SelectedIndex > 0)
            //{
            //    BindDataToPlan(int.Parse(ddlAdditionalPlanName4.SelectedValue), ddlAdditionalBenefitSummary4, null, null);
            //}
            //else
            //{
            //    ClearDropDownList(ddlAdditionalBenefitSummary4, null);
            //}
        }

        protected void ddlAdditionalPlanName5_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (ddlAdditionalPlanName5.SelectedIndex > 0)
            //{
            //    BindDataToPlan(int.Parse(ddlAdditionalPlanName5.SelectedValue), ddlAdditionalBenefitSummary5, null, null);
            //}
            //else
            //{
            //    ClearDropDownList(ddlAdditionalBenefitSummary5, null);
            //}
        }

        protected void ddlAdditionalPlanName6_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////if (ddlAdditionalPlanName6.SelectedIndex > 0)
            ////{
            ////    BindDataToPlan(int.Parse(ddlAdditionalPlanName6.SelectedValue), ddlAdditionalBenefitSummary6, null, null);
            ////}
            ////else
            ////{
            ////    ClearDropDownList(ddlAdditionalBenefitSummary6, null);
            ////}
        }

        protected void ClearAdditionalProduct()
        {
            //ClearDropDownList(ddlAdditionalBenefitSummary, null);
            //ClearDropDownList(ddlAdditionalBenefitSummary2, null);
            //ClearDropDownList(ddlAdditionalBenefitSummary3, null);
            //ClearDropDownList(ddlAdditionalBenefitSummary4, null);
            //ClearDropDownList(ddlAdditionalBenefitSummary5, null);
            //ClearDropDownList(ddlAdditionalBenefitSummary6, null);
        }



        /*******************************************************************************************
         *************************Created by Amogh for Check Validation of Plan ***********
        *******************************************************************************************/

        #region Check Plan Validation

        private bool MedicalValidation()
        {
            List<int> hideRateContribution = new List<int> { 235, 173 };
            string productTypeID = string.Empty;
            if (ddlMedicalNoOfPlan.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Atleast One Number Of Medical Plan.')</script>", false);
                ddlMedicalNoOfPlan.Focus();
                pnlMedical.Visible = true;
                return false;
            }

            if (ddlMedicalNoOfPlan.SelectedIndex == 1 || ddlMedicalNoOfPlan.SelectedIndex == 2 || ddlMedicalNoOfPlan.SelectedIndex == 3 || ddlMedicalNoOfPlan.SelectedIndex == 4 || ddlMedicalNoOfPlan.SelectedIndex == 5 || ddlMedicalNoOfPlan.SelectedIndex == 6)
            {
                // For Medical Plan 1
                if (ddlMedicalPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName1.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName1.SelectedValue);
                    if (ddlMedicalBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary1.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate1.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate1.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution1.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution1.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility1.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility1.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                }//Plan1 Close

                // For Medical Plan 2
                if (ddlMedicalPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName2.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName2.SelectedValue);
                    if (ddlMedicalBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary2.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate2.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate2.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution2.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution2.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility2.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility2.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                }//Plan2Close

                // For Medical Plan 3
                if (ddlMedicalPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName3.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName3.SelectedValue);
                    if (ddlMedicalBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary3.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate3.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate3.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution3.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution3.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility3.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility3.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}
                }//Plan3Close

                // For Medical Plan 4
                if (ddlMedicalPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName4.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName4.SelectedValue);
                    if (ddlMedicalBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary4.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate4.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate4.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution4.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution4.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility4.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility4.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}
                }//Plan4Close

                // For Medical Plan 5
                if (ddlMedicalPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName5.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName5.SelectedValue);
                    if (ddlMedicalBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary5.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate5.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate5.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution5.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution5.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}
                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility5.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility5.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}
                }//Plan5Close

                // For Medical Plan 6
                if (ddlMedicalPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Plan.')</script>", false);
                    ddlMedicalPlanName6.Focus();
                    pnlMedical.Visible = true;
                    return false;
                }
                else
                {
                    productTypeID = productTypeValue(ddlMedicalPlanName6.SelectedValue);
                    if (ddlMedicalBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Benefit Summary.')</script>", false);
                        ddlMedicalBenefitSummary6.Focus();
                        pnlMedical.Visible = true;
                        return false;
                    }

                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    /********************************** HERE WE CHECK IS PLAN IS NOT EQUAL ==> STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )/ INTERNATIONAL BUNDEL PLAN (3- TIRE) THAN ONLY CHECK RATE/ CONTRIBUTION *********/
                    ////    if (!medicalProductTypeId.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalRate6.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Rate.')</script>", false);
                    ////            ddlMedicalRate6.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////        if (ddlMedicalContribution6.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Contribution.')</script>", false);
                    ////            ddlMedicalContribution6.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}

                    /********************************** HERE WE CHECK IS PLAN NOT EQUAL TO STOP LOSS/ PRESCRIPTION DRUG (CARVE-OUT )THAN ONLY CHECK ELIBIGILITY *********/
                    ////if (productTypeID != null && productTypeID != "")
                    ////{
                    ////    if (!hideRateContribution.Contains(Convert.ToInt32(productTypeID)))
                    ////    {
                    ////        if (ddlMedicalEligibility6.SelectedIndex == 0)
                    ////        {
                    ////            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Medical Eligibility.')</script>", false);
                    ////            ddlMedicalEligibility6.Focus();
                    ////            pnlMedical.Visible = true;
                    ////            return false;
                    ////        }
                    ////    }
                    ////}
                }//Plan6Close
            }
            return true;
        }

        private bool DentalValidation()
        {
            if (ddlDentalNoOfPlan.SelectedIndex == 1 || ddlDentalNoOfPlan.SelectedIndex == 2 || ddlDentalNoOfPlan.SelectedIndex == 3 || ddlDentalNoOfPlan.SelectedIndex == 4 || ddlDentalNoOfPlan.SelectedIndex == 5 || ddlDentalNoOfPlan.SelectedIndex == 6)
            {
                // For Dental Plan 1
                if (ddlDentalPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName1.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary1.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate1.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution1.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility1.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Dental Plan 2
                if (ddlDentalPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName2.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary2.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate2.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution2.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility2.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Dental Plan 3
                if (ddlDentalPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName3.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary3.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate3.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution3.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility3.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Dental Plan 4
                if (ddlDentalPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName4.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary4.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate4.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution4.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility4.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Dental Plan 5
                if (ddlDentalPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName5.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary5.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate5.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution5.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility5.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Dental Plan 6
                if (ddlDentalPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Plan.')</script>", false);
                    ddlDentalPlanName6.Focus();
                    pnlDental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlDentalBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Benefit Summary.')</script>", false);
                        ddlDentalBenefitSummary6.Focus();
                        pnlDental.Visible = true;
                        return false;
                    }
                    ////if (ddlDentalRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Rate.')</script>", false);
                    ////    ddlDentalRate6.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalContribution6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Contribution.')</script>", false);
                    ////    ddlDentalContribution6.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDentalEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Dental Eligibility.')</script>", false);
                    ////    ddlDentalEligibility6.Focus();
                    ////    pnlDental.Visible = true;
                    ////    return false;
                    ////}
                }
            }
            return true;
        }

        private bool VisionValidation()
        {
            if (ddlVisionNoOfPlan.SelectedIndex == 1 || ddlVisionNoOfPlan.SelectedIndex == 2 || ddlVisionNoOfPlan.SelectedIndex == 3 || ddlVisionNoOfPlan.SelectedIndex == 4 || ddlVisionNoOfPlan.SelectedIndex == 5 || ddlVisionNoOfPlan.SelectedIndex == 6)
            {
                // For Vision Plan 1
                if (ddlVisionPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName1.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary1.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate1.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution1.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility1.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Vision Plan 2
                if (ddlVisionPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName2.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary2.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate2.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution2.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility2.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}

                }

                // For Vision Plan 3
                if (ddlVisionPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName3.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary3.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate3.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution3.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility3.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}

                }

                // For Vision Plan 4
                if (ddlVisionPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName4.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary4.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate4.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution4.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility4.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Vision Plan 5
                if (ddlVisionPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName5.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary5.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate5.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution5.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility5.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Vision Plan 6
                if (ddlVisionPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Plan.')</script>", false);
                    ddlVisionPlanName6.Focus();
                    pnlVision.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVisionBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Benefit Summary.')</script>", false);
                        ddlVisionBenefitSummary6.Focus();
                        pnlVision.Visible = true;
                        return false;
                    }
                    ////if (ddlVisionRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Rate.')</script>", false);
                    ////    ddlVisionRate6.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionContribution6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Contribution.')</script>", false);
                    ////    ddlVisionContribution6.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlVisionEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Vision Eligibility.')</script>", false);
                    ////    ddlVisionEligibility6.Focus();
                    ////    pnlVision.Visible = true;
                    ////    return false;
                    ////}
                }
            }
            return true;
        }

        private bool STDValidation()
        {
            if (ddlSTDNoOfPlan.SelectedIndex == 1 || ddlSTDNoOfPlan.SelectedIndex == 2 || ddlSTDNoOfPlan.SelectedIndex == 3 || ddlSTDNoOfPlan.SelectedIndex == 4 || ddlSTDNoOfPlan.SelectedIndex == 5 || ddlSTDNoOfPlan.SelectedIndex == 6)
            {
                // For STD Plan 1
                if (ddlSTDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName1.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary1.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate1.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility1.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For STD Plan 2
                if (ddlSTDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName2.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary2.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate2.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility2.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For STD Plan 3
                if (ddlSTDPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName3.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary3.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate3.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility3.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For STD Plan 4
                if (ddlSTDPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName4.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary4.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate4.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility4.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For STD Plan 5
                if (ddlSTDPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName5.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary5.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate5.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility5.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }
                // For STD Plan 6
                if (ddlSTDPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Plan.')</script>", false);
                    ddlSTDPlanName6.Focus();
                    pnlSTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlSTDBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Benefit Summary.')</script>", false);
                        ddlSTDBenefitSummary6.Focus();
                        pnlSTD.Visible = true;
                        return false;
                    }
                    ////if (ddlSTDRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Rate.')</script>", false);
                    ////    ddlSTDRate6.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlSTDEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select STD Eligibility.')</script>", false);
                    ////    ddlSTDEligibility6.Focus();
                    ////    pnlSTD.Visible = true;
                    ////    return false;
                    ////}
                }

            }
            return true;
        }

        private bool LTDValidation()
        {
            if (ddlLTDNoOfPlan.SelectedIndex == 1 || ddlLTDNoOfPlan.SelectedIndex == 2 || ddlLTDNoOfPlan.SelectedIndex == 3 || ddlLTDNoOfPlan.SelectedIndex == 4 || ddlLTDNoOfPlan.SelectedIndex == 5 || ddlLTDNoOfPlan.SelectedIndex == 6)
            {
                // For LTD Plan 1
                if (ddlLTDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName1.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary1.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate1.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility1.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For LTD Plan 2
                if (ddlLTDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName2.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary2.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate2.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility2.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For LTD Plan 3
                if (ddlLTDPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName3.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary3.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate3.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility3.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For LTD Plan 4
                if (ddlLTDPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName4.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary4.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate4.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility4.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }
                // For LTD Plan 5
                if (ddlLTDPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName5.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary5.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate5.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility5.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }

                // For LTD Plan 6
                if (ddlLTDPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Plan.')</script>", false);
                    ddlLTDPlanName6.Focus();
                    pnlLTD.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLTDBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Benefit Summary.')</script>", false);
                        ddlLTDBenefitSummary6.Focus();
                        pnlLTD.Visible = true;
                        return false;
                    }
                    ////if (ddlLTDRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Rate.')</script>", false);
                    ////    ddlLTDRate6.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLTDEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select LTD Eligibility.')</script>", false);
                    ////    ddlLTDEligibility6.Focus();
                    ////    pnlLTD.Visible = true;
                    ////    return false;
                    ////}
                }

            }//OuterOfClose
            return true;
        }

        private bool LifeADnDValidation()
        {
            if (ddlLifeADDNoOfPlan.SelectedIndex == 1 || ddlLifeADDNoOfPlan.SelectedIndex == 2 || ddlLifeADDNoOfPlan.SelectedIndex == 3 || ddlLifeADDNoOfPlan.SelectedIndex == 4 || ddlLifeADDNoOfPlan.SelectedIndex == 5 || ddlLifeADDNoOfPlan.SelectedIndex == 6)
            {
                // For Life and AD&D Plan 1
                if (ddlLifeADDPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName1.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary1.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate1.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility1.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Life and AD&D Plan 2
                if (ddlLifeADDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName2.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary2.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate2.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility2.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Life and AD&D Plan 3
                if (ddlLifeADDPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName3.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary3.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate3.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility3.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Life and AD&D Plan 4
                if (ddlLifeADDPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName4.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary4.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate4.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility4.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Life and AD&D Plan 5
                if (ddlLifeADDPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName5.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary5.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate5.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility5.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }
                // For Life and AD&D Plan 6
                if (ddlLifeADDPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Plan.')</script>", false);
                    ddlLifeADDPlanName6.Focus();
                    pnlLifeADND.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlLifeADDBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Benefit Summary.')</script>", false);
                        ddlLifeADDBenefitSummary6.Focus();
                        pnlLifeADND.Visible = true;
                        return false;
                    }
                    ////if (ddlLifeADDRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Rate.')</script>", false);
                    ////    ddlLifeADDRate6.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlLifeADDEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Life and AD&D Eligibility.')</script>", false);
                    ////    ddlLifeADDEligibility6.Focus();
                    ////    pnlLifeADND.Visible = true;
                    ////    return false;
                    ////}
                }

            }//OuterIF
            return true;
        }

        private bool EAPValidation()
        {
            if (ddlEAPNoOfPlan.SelectedIndex == 1 || ddlEAPNoOfPlan.SelectedIndex == 2 || ddlEAPNoOfPlan.SelectedIndex == 3 || ddlEAPNoOfPlan.SelectedIndex == 4 || ddlEAPNoOfPlan.SelectedIndex == 5 || ddlEAPNoOfPlan.SelectedIndex == 6)
            {
                // For EAP Plan 1
                if (ddlEAPPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility1.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }

                // For EAP Plan 2
                if (ddlEAPPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName2.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary2.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility2.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }

                // For EAP Plan 3
                if (ddlEAPPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName3.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary3.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility3.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }
                // For EAP Plan 4
                if (ddlEAPPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName4.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary4.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility4.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }
                // For EAP Plan 5
                if (ddlEAPPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName5.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary5.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility5.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }

                // For EAP Plan 6
                if (ddlEAPPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Plan.')</script>", false);
                    ddlEAPPlanName6.Focus();
                    pnlEAP.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlEAPBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Benefit Summary.')</script>", false);
                        ddlEAPBenefitSummary6.Focus();
                        pnlEAP.Visible = true;
                        return false;
                    }
                    ////if (ddlEAPEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select EAP Eligibility.')</script>", false);
                    ////    ddlEAPEligibility6.Focus();
                    ////    pnlEAP.Visible = true;
                    ////    return false;
                    ////}
                }
            }//OuterIf
            return true;
        }

        private bool FSAValidation()
        {
            if (ddlFSANoOfPlan.SelectedIndex == 1 || ddlFSANoOfPlan.SelectedIndex == 2 || ddlFSANoOfPlan.SelectedIndex == 3 || ddlFSANoOfPlan.SelectedIndex == 4 || ddlFSANoOfPlan.SelectedIndex == 5 || ddlFSANoOfPlan.SelectedIndex == 6)
            {
                // For FSA Plan 1
                if (ddlFSAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }

                // For FSA Plan 2
                if (ddlFSAPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName2.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary2.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }

                // For FSA Plan 3
                if (ddlFSAPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName3.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary3.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }

                // For FSA Plan 4
                if (ddlFSAPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName4.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary4.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }

                // For FSA Plan 5
                if (ddlFSAPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName5.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary5.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }
                // For FSA Plan 6
                if (ddlFSAPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Plan.')</script>", false);
                    ddlFSAPlanName6.Focus();
                    pnlFSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlFSABenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select FSA Benefit Summary.')</script>", false);
                        ddlFSABenefitSummary6.Focus();
                        pnlFSA.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool HRAValidation()
        {
            if (ddlHRANoOfPlan.SelectedIndex == 1 || ddlHRANoOfPlan.SelectedIndex == 1 || ddlHRANoOfPlan.SelectedIndex == 3 || ddlHRANoOfPlan.SelectedIndex == 4 || ddlHRANoOfPlan.SelectedIndex == 5 || ddlHRANoOfPlan.SelectedIndex == 6)
            {
                // For HRA Plan 1
                if (ddlHRAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }

                // For HRA Plan 2
                if (ddlHRAPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName2.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary2.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }

                // For HRA Plan 3
                if (ddlHRAPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName3.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary3.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }
                // For HRA Plan 4
                if (ddlHRAPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName4.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary4.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }
                // For HRA Plan 5
                if (ddlHRAPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName5.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary5.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }

                // For HRA Plan 6
                if (ddlHRAPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Plan.')</script>", false);
                    ddlHRAPlanName6.Focus();
                    pnlHRA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHRABenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HRA Benefit Summary.')</script>", false);
                        ddlHRABenefitSummary6.Focus();
                        pnlHRA.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool HSAValidation()
        {
            if (ddlHSANoOfPlan.SelectedIndex == 1 || ddlHSANoOfPlan.SelectedIndex == 2 || ddlHSANoOfPlan.SelectedIndex == 3 || ddlHSANoOfPlan.SelectedIndex == 4 || ddlHSANoOfPlan.SelectedIndex == 5 || ddlHSANoOfPlan.SelectedIndex == 6)
            {
                // For HSA Plan 1
                if (ddlHSAPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

                // For HSA Plan 2
                if (ddlHSAPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName2.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary2.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

                // For HSA Plan 3
                if (ddlHSAPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName3.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary3.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

                // For HSA Plan 4
                if (ddlHSAPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName4.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary4.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

                // For HSA Plan 5
                if (ddlHSAPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName5.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary5.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

                // For HSA Plan 6
                if (ddlHSAPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Plan.')</script>", false);
                    ddlHSAPlanName6.Focus();
                    pnlHSA.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlHSABenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select HSA Benefit Summary.')</script>", false);
                        ddlHSABenefitSummary6.Focus();
                        pnlHSA.Visible = true;
                        return false;
                    }
                }

            }

            return true;
        }

        private bool VoluntaryLifeADnDValidation()
        {
            if (ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 1 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 2 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 3 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 4 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 5 || ddlVoluntaryLifeADDNoOfPlan.SelectedIndex == 6)
            {
                // For Voluntary Life and AD&D Plan 1
                if (ddlVoluntaryLifeADDPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility1.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Voluntary Life and AD&D Plan 2
                if (ddlVoluntaryLifeADDPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName2.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary2.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility2.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Voluntary Life and AD&D Plan 3
                if (ddlVoluntaryLifeADDPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName3.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary3.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility3.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }


                // For Voluntary Life and AD&D Plan 4
                if (ddlVoluntaryLifeADDPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName4.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary4.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility4.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Voluntary Life and AD&D Plan 5
                if (ddlVoluntaryLifeADDPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName5.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary5.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility5.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Voluntary Life and AD&D Plan 6
                if (ddlVoluntaryLifeADDPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Plan.')</script>", false);
                    ddlVoluntaryLifeADDPlanName6.Focus();
                    pnlVoluntaryLife.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlVoluntaryLifeADDBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Benefit Summary.')</script>", false);
                        ddlVoluntaryLifeADDBenefitSummary6.Focus();
                        pnlVoluntaryLife.Visible = true;
                        return false;
                    }
                    ////if (ddlVoluntaryLifeEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Voluntary Life and AD&D Eligibility.')</script>", false);
                    ////    ddlVoluntaryLifeEligibility6.Focus();
                    ////    pnlVoluntaryLife.Visible = true;
                    ////    return false;
                    ////}
                }
            }
            return true;
        }

        private bool DisabilityValidation()
        {
            if (ddlDisabilityNoOfPlan.SelectedIndex == 1 || ddlDisabilityNoOfPlan.SelectedIndex == 2 || ddlDisabilityNoOfPlan.SelectedIndex == 3 || ddlDisabilityNoOfPlan.SelectedIndex == 4 || ddlDisabilityNoOfPlan.SelectedIndex == 5 || ddlDisabilityNoOfPlan.SelectedIndex == 6)
            {
                // For Disability Plan 1
                if (ddlDisabilityPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName1.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddlDisabilityPlanName2.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate1.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility1.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Disability Plan 2
                if (ddlDisabilityPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName2.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddLDisblBenefitSummary2.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate2.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility2.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Disability Plan 3
                if (ddlDisabilityPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName3.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddLDisblBenefitSummary3.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate3.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility3.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Disability Plan 4
                if (ddlDisabilityPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName4.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddLDisblBenefitSummary4.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate4.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility4.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Disability Plan 5
                if (ddlDisabilityPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName5.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddLDisblBenefitSummary5.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate5.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility5.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Disability Plan 6
                if (ddlDisabilityPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Plan.')</script>", false);
                    ddlDisabilityPlanName6.Focus();
                    pnlDisability.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLDisblBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Benefit Summary.')</script>", false);
                        ddLDisblBenefitSummary6.Focus();
                        pnlDisability.Visible = true;
                        return false;
                    }
                    ////if (ddlDisabilityRate6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Rate.')</script>", false);
                    ////    ddlDisabilityRate6.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                    ////if (ddlDisabilityEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Disability Eligibility.')</script>", false);
                    ////    ddlDisabilityEligibility6.Focus();
                    ////    pnlDisability.Visible = true;
                    ////    return false;
                    ////}
                }
            }
            return true;
        }

        private bool AccidentValidation()
        {
            if (ddlAccidentNoOfPlan.SelectedIndex == 1 || ddlAccidentNoOfPlan.SelectedIndex == 2 || ddlAccidentNoOfPlan.SelectedIndex == 3 || ddlAccidentNoOfPlan.SelectedIndex == 4 || ddlAccidentNoOfPlan.SelectedIndex == 5 || ddlAccidentNoOfPlan.SelectedIndex == 6)
            {
                // For Accident Plan 1
                if (ddlAccidentPlanName1.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName1.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary1.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary1.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility1.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }


                // For Accident Plan 2
                if (ddlAccidentPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName2.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary2.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility2.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Accident Plan 1
                if (ddlAccidentPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName3.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary3.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility3.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Accident Plan 4
                if (ddlAccidentPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName4.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary4.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility4.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Accident Plan 5
                if (ddlAccidentPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName5.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary5.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility5.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Accident Plan 6
                if (ddlAccidentPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Plan.')</script>", false);
                    ddlAccidentPlanName6.Focus();
                    pnlAccidental.Visible = true;
                    return false;
                }
                else
                {
                    if (ddLAccidentBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Benefit Summary.')</script>", false);
                        ddLAccidentBenefitSummary6.Focus();
                        pnlAccidental.Visible = true;
                        return false;
                    }
                    ////if (ddlAccidentEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Accident Eligibility.')</script>", false);
                    ////    ddlAccidentEligibility6.Focus();
                    ////    pnlAccidental.Visible = true;
                    ////    return false;
                    ////}
                }

            }
            return true;
        }

        private bool WellNessValidation()
        {
            if (ddlWellnessProgramNoOfPlan.SelectedIndex == 1 || ddlWellnessProgramNoOfPlan.SelectedIndex == 2 || ddlWellnessProgramNoOfPlan.SelectedIndex == 3 || ddlWellnessProgramNoOfPlan.SelectedIndex == 4 || ddlWellnessProgramNoOfPlan.SelectedIndex == 5 || ddlWellnessProgramNoOfPlan.SelectedIndex == 6)
            {
                // For Wellness Plan 1
                if (ddlWellnessProgramPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility1.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility1.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Wellness Plan 2
                if (ddlWellnessProgramPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName2.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary2.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility2.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility2.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Wellness Plan 3
                if (ddlWellnessProgramPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName3.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary3.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility3.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility3.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Wellness Plan 4
                if (ddlWellnessProgramPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName4.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary4.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility4.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility4.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Wellness Plan 5
                if (ddlWellnessProgramPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName5.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary5.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility5.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility5.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }

                // For Wellness Plan 6
                if (ddlWellnessProgramPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Plan.')</script>", false);
                    ddlWellnessProgramPlanName6.Focus();
                    pnlWelness.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlWellnessProgramBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Benefit Summary.')</script>", false);
                        ddlWellnessProgramBenefitSummary6.Focus();
                        pnlWelness.Visible = true;
                        return false;
                    }
                    ////if (ddlWellnessEligibility6.SelectedIndex == 0)
                    ////{
                    ////    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Wellness Eligibility.')</script>", false);
                    ////    ddlWellnessEligibility6.Focus();
                    ////    pnlWelness.Visible = true;
                    ////    return false;
                    ////}
                }
            }
            return true;
        }

        private bool AdditionalValidation()
        {
            if (ddlAdditionalNoOfPlan.SelectedIndex == 1 || ddlAdditionalNoOfPlan.SelectedIndex == 2 || ddlAdditionalNoOfPlan.SelectedIndex == 3 || ddlAdditionalNoOfPlan.SelectedIndex == 4 || ddlAdditionalNoOfPlan.SelectedIndex == 5 || ddlAdditionalNoOfPlan.SelectedIndex == 6)
            {
                // For Additional Plan 1
                if (ddlAdditionalPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }

                // For Additional Plan 2
                if (ddlAdditionalPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName2.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }

                // For Additional Plan 3
                if (ddlAdditionalPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName3.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }

                // For Additional Plan 4
                if (ddlAdditionalPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName4.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }

                // For Additional Plan 5
                if (ddlAdditionalPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName5.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }

                // For Additional Plan 6
                if (ddlAdditionalPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Additional Plan.')</script>", false);
                    ddlAdditionalPlanName6.Focus();
                    pnlAdditional.Visible = true;
                    return false;
                }


            }//OuterIFClose
            return true;
        }

        private bool StopLossValidation()
        {
            if (ddlStopNoOfPlan.SelectedIndex == 1 || ddlStopNoOfPlan.SelectedIndex == 2 || ddlStopNoOfPlan.SelectedIndex == 3 || ddlStopNoOfPlan.SelectedIndex == 4 || ddlStopNoOfPlan.SelectedIndex == 5 || ddlStopNoOfPlan.SelectedIndex == 6)
            {
                // For Stop Loss Plan 1
                if (ddlStopPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }

                // For Stop Loss Plan 2
                if (ddlStopPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName2.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary2.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }

                // For Stop Loss Plan 3
                if (ddlStopPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName3.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary3.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }

                // For Stop Loss Plan 4
                if (ddlStopPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName4.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary4.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }

                // For Stop Loss Plan 5
                if (ddlStopPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName5.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary5.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }

                // For Stop Loss Plan 6
                if (ddlStopPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Plan.')</script>", false);
                    ddlStopPlanName6.Focus();
                    pnlStopLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlStopBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Stop Loss Benefit Summary.')</script>", false);
                        ddlStopBenefitSummary6.Focus();
                        pnlStopLoss.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }

        private bool PrescriptionDrugValidation()
        {
            if (ddlPrescriptionNoOfPlan.SelectedIndex == 1 || ddlPrescriptionNoOfPlan.SelectedIndex == 2 || ddlPrescriptionNoOfPlan.SelectedIndex == 3 || ddlPrescriptionNoOfPlan.SelectedIndex == 4 || ddlPrescriptionNoOfPlan.SelectedIndex == 5 || ddlPrescriptionNoOfPlan.SelectedIndex == 6)
            {
                // For Prescription Drug Plan 1
                if (ddlPrescriptionPlanName.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }

                // For Prescription Drug Plan 2
                if (ddlPrescriptionPlanName2.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName2.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary2.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary2.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }

                // For Prescription Drug Plan 3
                if (ddlPrescriptionPlanName3.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName3.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary3.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary3.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }

                // For Prescription Drug Plan 4
                if (ddlPrescriptionPlanName4.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName4.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary4.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary4.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }

                // For Prescription Drug Plan 5
                if (ddlPrescriptionPlanName5.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName5.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary5.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary5.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }

                // For Prescription Drug Plan 6
                if (ddlPrescriptionPlanName6.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Plan.')</script>", false);
                    ddlPrescriptionPlanName6.Focus();
                    pnlPrescriptionLoss.Visible = true;
                    return false;
                }
                else
                {
                    if (ddlPrescriptionBenefitSummary6.SelectedIndex == 0)
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "<script>alert('Please Select Prescription Drug Benefit Summary.')</script>", false);
                        ddlPrescriptionBenefitSummary6.Focus();
                        pnlPrescriptionLoss.Visible = true;
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion


        /*--------------------------*/
        protected void Clear(bool rdlPlanSelected = false, bool ddlLayoutChange = false)
        {
            // Clear Screen 1 controls
            if (rdlPlanSelected == false)
            {
                ddlLayout.SelectedIndex = 0;
                rdlPlan.SelectedIndex = 0;
            }
            if (ddlLayoutChange == false)
            {
                grdPlans.DataSource = null;
                grdPlans.DataBind();
            }


            // Clear Screen 2 control's

            //***** Medical Control
            ddlMedicalNoOfPlan.SelectedIndex = 0;
            ddlMedicalPlanName1.Items.Clear();
            ddlMedicalPlanName2.Items.Clear();
            ddlMedicalPlanName3.Items.Clear();
            ddlMedicalPlanName4.Items.Clear();
            ddlMedicalPlanName5.Items.Clear();
            ddlMedicalPlanName6.Items.Clear();
            ClearMedical();
            EnabledMedicalDropDown();

            tblMedicalPlan_1.Visible = false;
            tblMedicalPlan_2.Visible = false;
            tblMedicalPlan_3.Visible = false;
            tblMedicalPlan_4.Visible = false;
            tblMedicalPlan_5.Visible = false;
            tblMedicalPlan_6.Visible = false;

            /*******DENTAL */
            ddlDentalNoOfPlan.SelectedIndex = 0;
            ddlDentalPlanName1.Items.Clear();
            ddlDentalPlanName2.Items.Clear();
            ddlDentalPlanName3.Items.Clear();
            ddlDentalPlanName4.Items.Clear();
            ddlDentalPlanName5.Items.Clear();
            ddlDentalPlanName6.Items.Clear();
            ClearDental();

            tblDentalPlan_1.Visible = false;
            tblDentalPlan_2.Visible = false;
            tblDentalPlan_3.Visible = false;
            tblDentalPlan_4.Visible = false;
            tblDentalPlan_5.Visible = false;
            tblDentalPlan_6.Visible = false;

            /*----VISION PLAN--- */
            ddlVisionNoOfPlan.SelectedIndex = 0;
            ddlVisionPlanName1.Items.Clear();
            ddlVisionPlanName2.Items.Clear();
            ddlVisionPlanName3.Items.Clear();
            ddlVisionPlanName4.Items.Clear();
            ddlVisionPlanName5.Items.Clear();
            ddlVisionPlanName6.Items.Clear();
            ClearVision();

            tblVisionPlan_1.Visible = false;
            tblVisionPlan_2.Visible = false;
            tblVisionPlan_3.Visible = false;
            tblVisionPlan_4.Visible = false;
            tblVisionPlan_5.Visible = false;
            tblVisionPlan_6.Visible = false;


            /*----LIFE AD&D PLAN */
            ddlLifeADDNoOfPlan.SelectedIndex = 0;
            ddlLifeADDPlanName1.Items.Clear();
            ddlLifeADDPlanName2.Items.Clear();
            ddlLifeADDPlanName3.Items.Clear();
            ddlLifeADDPlanName4.Items.Clear();
            ddlLifeADDPlanName5.Items.Clear();
            ddlLifeADDPlanName6.Items.Clear();
            ClearLifeADD();

            tblLifeADDPlan_1.Visible = false;
            tblLifeADDPlan_2.Visible = false;
            tblLifeADDPlan_3.Visible = false;
            tblLifeADDPlan_4.Visible = false;
            tblLifeADDPlan_5.Visible = false;
            tblLifeADDPlan_6.Visible = false;


            /*----STD PLAN */
            ddlSTDNoOfPlan.SelectedIndex = 0;
            ddlSTDPlanName1.Items.Clear();
            ddlSTDPlanName2.Items.Clear();
            ddlSTDPlanName3.Items.Clear();
            ddlSTDPlanName4.Items.Clear();
            ddlSTDPlanName5.Items.Clear();
            ddlSTDPlanName6.Items.Clear();
            ClearSTD();

            tblSTD_1.Visible = false;
            tblSTD_2.Visible = false;
            tblSTD_3.Visible = false;
            tblSTD_4.Visible = false;
            tblSTD_5.Visible = false;
            tblSTD_6.Visible = false;

            //LTD PLAN
            ddlLTDNoOfPlan.SelectedIndex = 0;
            ddlLTDPlanName1.Items.Clear();
            ddlLTDPlanName2.Items.Clear();
            ddlLTDPlanName3.Items.Clear();
            ddlLTDPlanName4.Items.Clear();
            ddlLTDPlanName5.Items.Clear();
            ddlLTDPlanName6.Items.Clear();
            ClearLTD();

            tblLTD_1.Visible = false;
            tblLTD_2.Visible = false;
            tblLTD_3.Visible = false;
            tblLTD_4.Visible = false;
            tblLTD_5.Visible = false;
            tblLTD_6.Visible = false;

            //Voluntary Life AND Voluntary AD&D
            ddlVoluntaryLifeADDNoOfPlan.SelectedIndex = 0;
            ddlVoluntaryLifeADDPlanName.Items.Clear();
            ddlVoluntaryLifeADDPlanName2.Items.Clear();
            ddlVoluntaryLifeADDPlanName3.Items.Clear();
            ddlVoluntaryLifeADDPlanName4.Items.Clear();
            ddlVoluntaryLifeADDPlanName5.Items.Clear();
            ddlVoluntaryLifeADDPlanName6.Items.Clear();
            ClearVoluntaryLifeADD();

            tblVoluntaryLifeADD_1.Visible = false;
            tblVoluntaryLifeADD_2.Visible = false;
            tblVoluntaryLifeADD_3.Visible = false;
            tblVoluntaryLifeADD_4.Visible = false;
            tblVoluntaryLifeADD_5.Visible = false;
            tblVoluntaryLifeADD_6.Visible = false;


            ddlEAPNoOfPlan.SelectedIndex = 0;
            ddlEAPPlanName.Items.Clear();
            ddlEAPPlanName2.Items.Clear();
            ddlEAPPlanName3.Items.Clear();
            ddlEAPPlanName4.Items.Clear();
            ddlEAPPlanName5.Items.Clear();
            ddlEAPPlanName6.Items.Clear();
            ClearEAP();

            tblEAP_1.Visible = false;
            tblEAP_2.Visible = false;
            tblEAP_3.Visible = false;
            tblEAP_4.Visible = false;
            tblEAP_5.Visible = false;
            tblEAP_6.Visible = false;

            ddlFSANoOfPlan.SelectedIndex = 0;
            ddlFSAPlanName.Items.Clear();
            ddlFSAPlanName2.Items.Clear();
            ddlFSAPlanName3.Items.Clear();
            ddlFSAPlanName4.Items.Clear();
            ddlFSAPlanName5.Items.Clear();
            ddlFSAPlanName6.Items.Clear();
            ClearFSA();

            tblFSA_1.Visible = false;
            tblFSA_2.Visible = false;
            tblFSA_3.Visible = false;
            tblFSA_4.Visible = false;
            tblFSA_5.Visible = false;
            tblFSA_6.Visible = false;


            ddlHSANoOfPlan.SelectedIndex = 0;
            ddlHSAPlanName.Items.Clear();
            ddlHSAPlanName2.Items.Clear();
            ddlHSAPlanName3.Items.Clear();
            ddlHSAPlanName4.Items.Clear();
            ddlHSAPlanName5.Items.Clear();
            ddlHSAPlanName6.Items.Clear();
            ClearHSA();

            tblHSA_1.Visible = false;
            tblHSA_2.Visible = false;
            tblHSA_3.Visible = false;
            tblHSA_4.Visible = false;
            tblHSA_5.Visible = false;
            tblHSA_6.Visible = false;

            ddlHRANoOfPlan.SelectedIndex = 0;
            ddlHRAPlanName.Items.Clear();
            ddlHRAPlanName2.Items.Clear();
            ddlHRAPlanName3.Items.Clear();
            ddlHRAPlanName4.Items.Clear();
            ddlHRAPlanName5.Items.Clear();
            ddlHRAPlanName6.Items.Clear();
            ClearHRA();

            tblHRA_1.Visible = false;
            tblHRA_2.Visible = false;
            tblHRA_3.Visible = false;
            tblHRA_4.Visible = false;
            tblHRA_5.Visible = false;
            tblHRA_6.Visible = false;


            ddlGroupTermLifeNoOfPlan.SelectedIndex = 0;
            ClearGroupTermLife();

            ddlADNDNoOfPlan.SelectedIndex = 0;
            ClearADD();

            //Wellness 
            ddlWellnessProgramNoOfPlan.SelectedIndex = 0;
            ddlWellnessProgramPlanName.Items.Clear();
            ddlWellnessProgramPlanName2.Items.Clear();
            ddlWellnessProgramPlanName3.Items.Clear();
            ddlWellnessProgramPlanName4.Items.Clear();
            ddlWellnessProgramPlanName5.Items.Clear();
            ddlWellnessProgramPlanName6.Items.Clear();
            ClearWellness();

            tblWell_1.Visible = false;
            tblWell_2.Visible = false;
            tblWell_3.Visible = false;
            tblWell_4.Visible = false;
            tblWell_5.Visible = false;
            tblWell_6.Visible = false;

            //Additional Product
            ddlAdditionalNoOfPlan.SelectedIndex = 0;
            ddlAdditionalPlanName.Items.Clear();
            ddlAdditionalPlanName2.Items.Clear();
            ddlAdditionalPlanName3.Items.Clear();
            ddlAdditionalPlanName4.Items.Clear();
            ddlAdditionalPlanName5.Items.Clear();
            ddlAdditionalPlanName6.Items.Clear();
            ClearAdditionalProduct();

            tblAdditional_1.Visible = false;
            tblAdditional_2.Visible = false;
            tblAdditional_3.Visible = false;
            tblAdditional_4.Visible = false;
            tblAdditional_5.Visible = false;
            tblAdditional_6.Visible = false;

            //Disability 
            ddlDisabilityNoOfPlan.SelectedIndex = 0;
            ddlDisabilityPlanName1.Items.Clear();
            ddlDisabilityPlanName2.Items.Clear();
            ddlDisabilityPlanName3.Items.Clear();
            ddlDisabilityPlanName4.Items.Clear();
            ddlDisabilityPlanName5.Items.Clear();
            ddlDisabilityPlanName6.Items.Clear();
            ClearDisability();

            tblDisbl_1.Visible = false;
            tblDisbl_2.Visible = false;
            tblDisbl_3.Visible = false;
            tblDisbl_4.Visible = false;
            tblDisbl_5.Visible = false;
            tblDisbl_6.Visible = false;

            //Accidental Product
            ddlAccidentNoOfPlan.SelectedIndex = 0;
            ddlAccidentPlanName1.Items.Clear();
            ddlAccidentPlanName2.Items.Clear();
            ddlAccidentPlanName3.Items.Clear();
            ddlAccidentPlanName4.Items.Clear();
            ddlAccidentPlanName5.Items.Clear();
            ddlAccidentPlanName6.Items.Clear();
            ClearAccident();

            tblAccident_1.Visible = false;
            tblAccident_2.Visible = false;
            tblAccident_3.Visible = false;
            tblAccident_4.Visible = false;
            tblAccident_5.Visible = false;
            tblAccident_6.Visible = false;

            //Stop Loss
            ddlStopNoOfPlan.SelectedIndex = 0;
            ddlStopPlanName.Items.Clear();
            ddlStopPlanName2.Items.Clear();
            ddlStopPlanName3.Items.Clear();
            ddlStopPlanName4.Items.Clear();
            ddlStopPlanName5.Items.Clear();
            ddlStopPlanName6.Items.Clear();
            ClearStopLoss();

            tblStop_1.Visible = false;
            tblStop_2.Visible = false;
            tblStop_3.Visible = false;
            tblStop_4.Visible = false;
            tblStop_5.Visible = false;
            tblStop_6.Visible = false;

            //Prescription Drug
            ddlPrescriptionNoOfPlan.SelectedIndex = 0;
            ddlPrescriptionPlanName.Items.Clear();
            ddlPrescriptionPlanName2.Items.Clear();
            ddlPrescriptionPlanName3.Items.Clear();
            ddlPrescriptionPlanName4.Items.Clear();
            ddlPrescriptionPlanName5.Items.Clear();
            ddlPrescriptionPlanName6.Items.Clear();
            ClearPrescriptionDrug();

            tblPrescription_1.Visible = false;
            tblPrescription_2.Visible = false;
            tblPrescription_3.Visible = false;
            tblPrescription_4.Visible = false;
            tblPrescription_5.Visible = false;
            tblPrescription_6.Visible = false;

        }
        //Added by - Aatrey
        private DataTable GetAddtionalProductDetail()
        {

            DataTable ProductInfoTable = new DataTable();
            ProductInfoTable = CreatePlanInfoTable();
            DataTable ProductSummaryTable = (DataTable)Session["ProductSummaryTable"];

            objCommFun.LoadPlanTypeIds_AccountDetails();


            try
            {

                int rowCount1 = 0;
                CheckBox chkItemSelect = new CheckBox();

                if (grdPlans != null)
                {
                    foreach (GridViewRow grRow in grdPlans.Rows)
                    {
                        chkItemSelect = ((CheckBox)grRow.FindControl("chkItemSelect"));
                        // BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), int.Parse(grRow.Cells[5].Text), SessionId);

                        if (chkItemSelect.Checked == true && (Convert.ToString(grRow.Cells[8].Text).Length == 4))
                        {



                            //foreach (var data in BenefitSummaryList)
                            //{

                            ProductInfoTable.Rows.Add();
                            // For Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[0].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = Convert.ToString(grRow.Cells[0].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Name"] = " ";
                            }
                            // For SummaryName
                            //if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = Convert.ToString(grRow.Cells[1].Text);
                            //}
                            //else
                            //{
                            //    PlanInfoTable.Rows[rowCount]["SummaryName"] = " ";
                            //}
                            // For Carrier Name
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[1].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = Convert.ToString(grRow.Cells[1].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Carrier"] = " ";
                            }

                            // For Effective date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[2].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = Convert.ToString(grRow.Cells[2].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Effective"] = " ";
                            }

                            // For Renewal Date
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[3].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = Convert.ToString(grRow.Cells[3].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["Renewal"] = " ";
                            }

                            // For Policy number
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[4].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = Convert.ToString(grRow.Cells[4].Text.Replace("&amp;", "&"));
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["PolicyNumber"] = " ";
                            }

                            // For ProductID
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[5].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = Convert.ToString(grRow.Cells[5].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductId"] = " ";
                            }

                            // For ProductName
                            if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[6].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = Convert.ToString(grRow.Cells[6].Text);
                            }
                            else
                            {
                                ProductInfoTable.Rows[rowCount1]["ProductName"] = " ";
                            }

                            if (Convert.ToString(grRow.Cells[8].Text).Length <= 4)
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(grRow.Cells[8].Text)))
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = Convert.ToString(grRow.Cells[8].Text);
                                }
                                else
                                {
                                    ProductInfoTable.Rows[rowCount1]["ProductTypeId"] = " ";
                                }
                            }

                            if (CommonFunctionsBS.MedicalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.MedicalPlanType;
                            }
                            if (CommonFunctionsBS.DentalPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.DentalPlanType;
                            }
                            if (CommonFunctionsBS.VisionPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VisionPlanType;
                            }
                            if (CommonFunctionsBS.LifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LifeADDPlanType;
                            }
                            if (CommonFunctionsBS.LTDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.LTDPlanType;
                            }

                            if (CommonFunctionsBS.STDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.STDPlanType;
                            }

                            if (CommonFunctionsBS.EAPPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.EAPPlanType;
                            }

                            if (CommonFunctionsBS.FSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.FSAPlanType;
                            }

                            if (CommonFunctionsBS.HSAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HSAPlanType;
                            }
                            if (CommonFunctionsBS.HRAPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.HRAPlanType;
                            }

                            if (CommonFunctionsBS.GroupTermLifePlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.GroupTermLifePlanType;
                            }

                            if (CommonFunctionsBS.VoluntaryLifeADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLife;
                            }

                            if (CommonFunctionsBS.VoluntaryADDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.VoluntaryLifeADD;
                            }

                            if (CommonFunctionsBS.ADNDPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[8].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.ADD;
                            }

                            if (CommonFunctionsBS.WellnessPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.Wellness;
                            }

                            if (CommonFunctionsBS.AdditionalProductsPlanTypeList.Contains(Convert.ToInt32(grRow.Cells[7].Text)))
                            {
                                ProductInfoTable.Rows[rowCount1]["PlanType"] = cv.AdditionalProducts;
                            }

                            rowCount1++;


                        }
                        else
                        {

                        }

                    }


                    var Rows = (from row in PlanInfoTable.AsEnumerable()
                                select row);
                    PlanInfoTable = Rows.AsDataView().ToTable();

                    var Rows1 = (from row1 in ProductInfoTable.AsEnumerable()
                                 orderby row1["Name"] ascending
                                 select row1);
                    ProductInfoTable = Rows1.AsDataView().ToTable();


                    return ProductInfoTable;
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
            return PlanInfoTable;
        }
        //Added by -Aatrey
        void DeleteBookmarkTable(Word.Document oWordDoc, Word.Application oWordApp)
        {
            int total = oWordDoc.Bookmarks.Count;
            for (int i = 1; i <= total; i++)
            {
                object objI = i;

                object bookmarkname = oWordDoc.Bookmarks.get_Item(ref objI).Name;
                Word.Range rang = oWordDoc.Bookmarks.get_Item(ref bookmarkname).Range;
                rang.Select();
                if (oWordApp.Selection.Fields.Count > 0)
                {

                    oWordDoc.Bookmarks.get_Item(ref bookmarkname).Range.Delete();

                    i = i - 1;
                    total = oWordDoc.Bookmarks.Count;
                }

            }
        }
    }// Class Closed here 
}