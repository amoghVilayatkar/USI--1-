﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common
{
    public class ExceptionLog
    {
         private int _exception_Log_ID;
         private string _exception_Message;
         private string _exception_Source;
         private string _exception_MethodName;
         private string _exception_StackTrace;
         private string _exception_DateTime;


        public int Exception_Log_ID
        {
            get
            {
                return _exception_Log_ID;
            }
            set
            {
                _exception_Log_ID = value;
            }
        }

        public string Exception_Message
        {
            get
            {
                return _exception_Message;

            }
            set
            {
                _exception_Message = value;
            }
        }
        public string Exception_Source
        {
            get
            {
                return _exception_Source;

            }
            set
            {
                _exception_Source = value;
            }
        }

        public string Exception_MethodName
        {
            get
            {
                return _exception_MethodName;

            }
            set
            {
                _exception_MethodName = value;
            }
        }
        public string Exception_StackTrace
        {
            get
            {
                return _exception_StackTrace;

            }
            set
            {
                _exception_StackTrace = value;
            }
        }
        public string Exception_DateTime
        {
            get
            {
                return _exception_DateTime;

            }
            set
            {
                _exception_DateTime = value;
            }
        }

       


    }
}