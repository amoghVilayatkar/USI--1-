﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.Text;
using BenefitPointSummaryPortal.Common.BenefitSummary;

using System.Data.SqlClient;
using System.Configuration;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class SummaryDetail
    {
        #region Global Variables
        //account
        DataTable account_table = new DataTable();
        DataTable accountCustomFieldValues_table = new DataTable();
        DataTable account_Team_memeber = new DataTable();

        //Employee Type 
        DataTable accountEmployeeTypesValues_table = new DataTable();

        //Product
        DataTable product_table = new DataTable();
        DataTable customfieldvalue_table = new DataTable();

        //Benefit Summary Structure
        DataTable benefitsummarystructure_table = new DataTable();
        DataTable attributeViewLevels_table = new DataTable();
        DataTable benefitColumns_table = new DataTable();
        DataTable attributeSection_table = new DataTable();
        DataTable attribute_table = new DataTable();

        //Benefits Summary
        DataTable benefitsummary_table = new DataTable();
        DataTable attributevalue_table = new DataTable();
        DataTable attributevaluedetail_table = new DataTable();



        //Eligibility Rule
        DataTable eligibilityrule_table = new DataTable();
        DataTable employeeTypeIDs_table = new DataTable();
        DataTable employeetype_table = new DataTable();


        //Rate Detail    
        DataTable ratesummary_table = new DataTable();
        DataTable associatedBenefitSummaries_table = new DataTable();
        DataTable rate_table = new DataTable();
        DataTable rate_table_revenue = new DataTable();

        DataTable benefitsummaryrate_table = new DataTable();

        DataTable ratefieldvalue_table = new DataTable();
        DataTable rateoptionvalue_table = new DataTable();

        //Contribution	
        DataTable contribution_table = new DataTable();
        DataTable contributionvalue_table = new DataTable();

        int contribution_row_counter = 0;
        int contributionvalue_row_counter = 0;

        #region Variables to check for change in dropdown list
        // static variables to check for the current state of the dropdown list
        public static bool isClientChanged_ForMedical = false;
        public static bool isClientChanged_ForDental = false;
        public static bool isClientChanged_ForVision = false;
        public static bool isClientChanged_ForVoluntaryLifeADD = false;
        public static bool isClientChanged_ForLifeADD = false;
        public static bool isClientChanged_ForGroupTermLife = false;
        public static bool isClientChanged_ForSTD = false;
        public static bool isClientChanged_ForLTD = false;
        #endregion

        DataTable premium_table = new DataTable();



        #endregion

        /// <summary>
        /// Get Office detail from  BP_BrokerConnectV4 web service using getAccount and getOffice webmethod. 
        /// </summary>
        /// <param name="account_id">To get account detail for selected account Id</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Office DataTable</returns>
        /// 
        public DataTable GetOfficeDetail(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();
            BP_BrokerConnectV4.Office offData = new BP_BrokerConnectV4.Office();
            int cnt = 1;
            DataTable OfficeDT = new DataTable();

            try
            {
                OfficeDT.Columns.Add("OfficeID", typeof(Int32));     // Column 0
                OfficeDT.Columns.Add("OfficeName", typeof(String));  // Column 1
                OfficeDT.Columns.Add("RegionName", typeof(String));  // Column 2

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);

                if (new_account != null)
                {
                    if (new_account.officeID > 0)
                    {
                        offData = new_connection.getOffice(new_account.officeID);

                        if (cnt == 1)
                        {
                            if (offData != null)
                            {
                                OfficeDT.Rows.Add();
                                OfficeDT.Rows[0][0] = offData.officeID;
                                OfficeDT.Rows[0][1] = offData.officeName;
                                OfficeDT.Rows[0][2] = offData.regionName;
                                cnt++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return OfficeDT;
        }

        /// <summary>
        /// Get account detail from  BP_BrokerConnectV4 web service using getAccount webmethod. 
        /// </summary>
        /// <param name="account_id">To get account detail for selected account Id</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Account data</returns>

        public DataSet GetAccountDetail(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();

            DataSet AccountDS = new DataSet();
            int account_row_counter = 0;
            int accountCustomFieldValues_row_counter = 0;

            // BP_BrokerConnectV4.Contact cn = new BP_BrokerConnectV4.Contact();
            //new_connection.getplanc


            try
            {

                SIH.sessionId = SessionId;//myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);
                string website = string.Empty;


                if (new_account != null)
                {
                    #region account_table
                    website = new_account.groupAccountInfo.commonGroupAccountInfo.website;
                    account_table.Rows.Add();
                    account_table.Rows[account_row_counter][0] = new_account.accountID;
                    if (new_account.active != null && new_account.active.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][1] = new_account.active.ToString();
                    if (new_account.inactiveAsOf != null && new_account.inactiveAsOf.Year != 1) account_table.Rows[account_row_counter][2] = new_account.inactiveAsOf;
                    if (new_account.inactiveReason != null) account_table.Rows[account_row_counter][3] = new_account.inactiveReason.ToString();
                    if (new_account.accountClassification != null) account_table.Rows[account_row_counter][4] = new_account.accountClassification.ToString();
                    if (new_account.accountType != null) account_table.Rows[account_row_counter][5] = new_account.accountType.ToString();
                    if (new_account.officeID != null) account_table.Rows[account_row_counter][6] = new_account.officeID.ToString();
                    if (new_account.departmentID != null) account_table.Rows[account_row_counter][7] = new_account.departmentID.ToString();
                    if (new_account.administratorUserID != null) account_table.Rows[account_row_counter][8] = new_account.administratorUserID.ToString();
                    if (new_account.primaryContactUserID != null) account_table.Rows[account_row_counter][9] = new_account.primaryContactUserID.ToString();
                    if (new_account.primarySalesLeadUserID != null) account_table.Rows[account_row_counter][10] = new_account.primarySalesLeadUserID.ToString();
                    if (new_account.primaryServiceLeadUserID != null) account_table.Rows[account_row_counter][11] = new_account.primaryServiceLeadUserID.ToString();
                    if (new_account.notes != null) account_table.Rows[account_row_counter][12] = new_account.notes.ToString();
                    if (new_account.lastReviewedByUserID != null) account_table.Rows[account_row_counter][13] = new_account.lastReviewedByUserID.ToString();
                    if (new_account.lastReviewedOn != null && new_account.lastReviewedOn.Year != 1) account_table.Rows[account_row_counter][14] = new_account.lastReviewedOn.ToString();
                    if (new_account.createdOn != null && new_account.createdOn.Year != 1) account_table.Rows[account_row_counter][15] = new_account.createdOn.ToString();
                    if (new_account.lastModifiedOn != null && new_account.lastModifiedOn.Year != 1) account_table.Rows[account_row_counter][16] = new_account.lastModifiedOn.ToString();



                    if (new_account.mainAddress != null)
                    {
                        if (new_account.mainAddress.street1 != null) account_table.Rows[account_row_counter][18] = new_account.mainAddress.street1.ToString();
                        if (new_account.mainAddress.street2 != null) account_table.Rows[account_row_counter][19] = new_account.mainAddress.street2.ToString();
                        if (new_account.mainAddress.city != null) account_table.Rows[account_row_counter][20] = new_account.mainAddress.city.ToString();
                        if (new_account.mainAddress.state != null) account_table.Rows[account_row_counter][21] = new_account.mainAddress.state.ToString();
                        if (new_account.mainAddress.zip != null) account_table.Rows[account_row_counter][22] = new_account.mainAddress.zip.ToString();
                        if (new_account.mainAddress.country != null) account_table.Rows[account_row_counter][23] = new_account.mainAddress.country.ToString().Replace("_", " ");
                    }

                    if (new_account.billingAddress != null)
                    {
                        if (new_account.billingAddress.street1 != null) account_table.Rows[account_row_counter][24] = new_account.billingAddress.street1.ToString();
                        if (new_account.billingAddress.street2 != null) account_table.Rows[account_row_counter][25] = new_account.billingAddress.street2.ToString();
                        if (new_account.billingAddress.city != null) account_table.Rows[account_row_counter][26] = new_account.billingAddress.city.ToString();
                        if (new_account.billingAddress.state != null) account_table.Rows[account_row_counter][27] = new_account.billingAddress.state.ToString();
                        if (new_account.billingAddress.zip != null) account_table.Rows[account_row_counter][28] = new_account.billingAddress.zip.ToString();
                        if (new_account.billingAddress.country != null) account_table.Rows[account_row_counter][29] = new_account.billingAddress.country.ToString().Replace("_", " ");


                    }

                    if (new_account.mailingAddress != null)
                    {
                        if (new_account.mailingAddress.street1 != null) account_table.Rows[account_row_counter][30] = new_account.mailingAddress.street1.ToString();
                        if (new_account.mailingAddress.street2 != null) account_table.Rows[account_row_counter][31] = new_account.mailingAddress.street2.ToString();
                        if (new_account.mailingAddress.city != null) account_table.Rows[account_row_counter][32] = new_account.mailingAddress.city.ToString();
                        if (new_account.mailingAddress.state != null) account_table.Rows[account_row_counter][33] = new_account.mailingAddress.state.ToString();
                        if (new_account.mailingAddress.zip != null) account_table.Rows[account_row_counter][34] = new_account.mailingAddress.zip.ToString();
                        if (new_account.mailingAddress.country != null) account_table.Rows[account_row_counter][35] = new_account.mailingAddress.country.ToString().Replace("_", " ");

                    }

                    if (new_account.groupAccountInfo != null)
                    {

                        if (new_account.groupAccountInfo.accountName != null) account_table.Rows[account_row_counter][36] = new_account.groupAccountInfo.accountName.ToString();
                        if (new_account.groupAccountInfo.DBA != null) account_table.Rows[account_row_counter][37] = new_account.groupAccountInfo.DBA.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][38] = new_account.groupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEsAsOf != null) account_table.Rows[account_row_counter][39] = new_account.groupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.groupAccountInfo.marketSize != null) account_table.Rows[account_row_counter][40] = new_account.groupAccountInfo.marketSize.ToString();
                        if (new_account.groupAccountInfo.businessType != null) account_table.Rows[account_row_counter][41] = new_account.groupAccountInfo.businessType.ToString();
                        if (new_account.groupAccountInfo.SICCode != null) account_table.Rows[account_row_counter][42] = new_account.groupAccountInfo.SICCode.ToString();
                        if (new_account.groupAccountInfo.NAICSCode != null) account_table.Rows[account_row_counter][43] = new_account.groupAccountInfo.NAICSCode.ToString();
                        if (new_account.groupAccountInfo.requires5500 != null && new_account.groupAccountInfo.requires5500.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][44] = new_account.groupAccountInfo.requires5500.ToString();
                        if (new_account.groupAccountInfo.locationsByZip != null) account_table.Rows[account_row_counter][45] = new_account.groupAccountInfo.locationsByZip.ToString();
                        if (new_account.groupAccountInfo.affiliates != null) account_table.Rows[account_row_counter][46] = new_account.groupAccountInfo.affiliates.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][47] = new_account.groupAccountInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][48] = new_account.groupAccountInfo.budgetedTotalAnnualRevenue.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCycles != null && new_account.groupAccountInfo.multiplePayrollCycles.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][49] = new_account.groupAccountInfo.multiplePayrollCycles.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCyclesDifferBy != null) account_table.Rows[account_row_counter][50] = new_account.groupAccountInfo.multiplePayrollCyclesDifferBy.ToString();
                        if (new_account.groupAccountInfo.singlePayrollCycle != null) account_table.Rows[account_row_counter][51] = new_account.groupAccountInfo.singlePayrollCycle.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][52] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][53] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][54] = new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][55] = new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][56] = new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][57] = new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][58] = new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][59] = new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][60] = new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][61] = new_account.groupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][62] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.Year != 1) account_table.Rows[account_row_counter][63] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][64] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][65] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalents != null) account_table.Rows[account_row_counter][145] = new_account.groupAccountInfo.numberOfFullTimeEquivalents.ToString();
                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate != null) account_table.Rows[account_row_counter][146] = new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate.ToString();

                        if (new_account.groupAccountInfo.accountIntegrationInfo != null)
                        {

                            if (new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID != null)
                                account_table.Rows[account_row_counter][140] = new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.sourceCode != null)
                                account_table.Rows[account_row_counter][141] = new_account.groupAccountInfo.accountIntegrationInfo.sourceCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode != null)
                                account_table.Rows[account_row_counter][142] = new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode != null)
                                account_table.Rows[account_row_counter][143] = new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer != null)
                                account_table.Rows[account_row_counter][144] = new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer;


                        }

                    }


                    if (new_account.individualAccountInfo != null)
                    {
                        if (new_account.individualAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][66] = new_account.individualAccountInfo.personInfo.firstName.ToString();
                        if (new_account.individualAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][67] = new_account.individualAccountInfo.personInfo.middleName.ToString();
                        if (new_account.individualAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][68] = new_account.individualAccountInfo.personInfo.lastName.ToString();
                        if (new_account.individualAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][69] = new_account.individualAccountInfo.personInfo.salutation.ToString();
                        if (new_account.individualAccountInfo.personInfo.dateOfBirth != null && new_account.individualAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][70] = new_account.individualAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.individualAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][71] = new_account.individualAccountInfo.personInfo.gender.ToString();
                        if (new_account.individualAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][72] = new_account.individualAccountInfo.personInfo.ssn.ToString();
                        if (new_account.individualAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][73] = new_account.individualAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.individualAccountInfo.email != null) account_table.Rows[account_row_counter][74] = new_account.individualAccountInfo.email.ToString();
                        if (new_account.individualAccountInfo.phone.areaCode != null) account_table.Rows[account_row_counter][75] = new_account.individualAccountInfo.phone.areaCode.ToString();
                        if (new_account.individualAccountInfo.phone.number != null) account_table.Rows[account_row_counter][76] = new_account.individualAccountInfo.phone.number.ToString();
                        if (new_account.individualAccountInfo.phone.type != null) account_table.Rows[account_row_counter][77] = new_account.individualAccountInfo.phone.type.ToString();
                        if (new_account.individualAccountInfo.affiliatedGroupAccountID != null) account_table.Rows[account_row_counter][78] = new_account.individualAccountInfo.affiliatedGroupAccountID.ToString();

                    }



                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.marketingGroupName != null) account_table.Rows[account_row_counter][79] = new_account.marketingGroupAccountInfo.marketingGroupName.ToString();
                        if (new_account.marketingGroupAccountInfo.marketingGroupType != null) account_table.Rows[account_row_counter][80] = new_account.marketingGroupAccountInfo.marketingGroupType.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][81] = new_account.marketingGroupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEsAsOf != null && new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.Year != 1) account_table.Rows[account_row_counter][82] = new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.associatedAccountIDs != null) account_table.Rows[account_row_counter][83] = new_account.marketingGroupAccountInfo.associatedAccountIDs.ToString();

                    }

                    if (new_account.agencyAccountInfo != null)
                    {
                        if (new_account.agencyAccountInfo.agencyName != null) account_table.Rows[account_row_counter][84] = new_account.agencyAccountInfo.agencyName.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.email != null) account_table.Rows[account_row_counter][85] = new_account.agencyAccountInfo.agencyInfo.email.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][86] = new_account.agencyAccountInfo.agencyInfo.phone1.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][87] = new_account.agencyAccountInfo.agencyInfo.phone2.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][88] = new_account.agencyAccountInfo.agencyInfo.phone3.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][89] = new_account.agencyAccountInfo.agencyInfo.phone4.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.number != null) account_table.Rows[account_row_counter][90] = new_account.agencyAccountInfo.agencyInfo.phone1.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.number != null) account_table.Rows[account_row_counter][91] = new_account.agencyAccountInfo.agencyInfo.phone2.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.number != null) account_table.Rows[account_row_counter][92] = new_account.agencyAccountInfo.agencyInfo.phone3.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.number != null) account_table.Rows[account_row_counter][93] = new_account.agencyAccountInfo.agencyInfo.phone4.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.type != null) account_table.Rows[account_row_counter][94] = new_account.agencyAccountInfo.agencyInfo.phone1.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.type != null) account_table.Rows[account_row_counter][95] = new_account.agencyAccountInfo.agencyInfo.phone2.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.type != null) account_table.Rows[account_row_counter][96] = new_account.agencyAccountInfo.agencyInfo.phone3.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.type != null) account_table.Rows[account_row_counter][97] = new_account.agencyAccountInfo.agencyInfo.phone4.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.taxPayerID != null) account_table.Rows[account_row_counter][98] = new_account.agencyAccountInfo.agencyInfo.taxPayerID.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][99] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][100] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.agentAccountInfo != null)
                    {
                        if (new_account.agentAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][101] = new_account.agentAccountInfo.personInfo.firstName.ToString();
                        if (new_account.agentAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][102] = new_account.agentAccountInfo.personInfo.middleName.ToString();
                        if (new_account.agentAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][103] = new_account.agentAccountInfo.personInfo.lastName.ToString();
                        if (new_account.agentAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][104] = new_account.agentAccountInfo.personInfo.salutation.ToString();
                        if (new_account.agentAccountInfo.personInfo.dateOfBirth != null && new_account.agentAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][105] = new_account.agentAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.agentAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][106] = new_account.agentAccountInfo.personInfo.gender.ToString();
                        if (new_account.agentAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][107] = new_account.agentAccountInfo.personInfo.ssn.ToString();
                        if (new_account.agentAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][108] = new_account.agentAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.agentAccountInfo.agencyAccountID != null) account_table.Rows[account_row_counter][109] = new_account.agentAccountInfo.agencyAccountID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.email != null) account_table.Rows[account_row_counter][110] = new_account.agentAccountInfo.agentInfo.email.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][111] = new_account.agentAccountInfo.agentInfo.phone1.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][112] = new_account.agentAccountInfo.agentInfo.phone2.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][113] = new_account.agentAccountInfo.agentInfo.phone3.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][114] = new_account.agentAccountInfo.agentInfo.phone4.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.number != null) account_table.Rows[account_row_counter][115] = new_account.agentAccountInfo.agentInfo.phone1.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.number != null) account_table.Rows[account_row_counter][116] = new_account.agentAccountInfo.agentInfo.phone2.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.number != null) account_table.Rows[account_row_counter][117] = new_account.agentAccountInfo.agentInfo.phone3.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.number != null) account_table.Rows[account_row_counter][118] = new_account.agentAccountInfo.agentInfo.phone4.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.type != null) account_table.Rows[account_row_counter][119] = new_account.agentAccountInfo.agentInfo.phone1.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.type != null) account_table.Rows[account_row_counter][120] = new_account.agentAccountInfo.agentInfo.phone2.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.type != null) account_table.Rows[account_row_counter][121] = new_account.agentAccountInfo.agentInfo.phone3.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.type != null) account_table.Rows[account_row_counter][122] = new_account.agentAccountInfo.agentInfo.phone4.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.taxPayerID != null) account_table.Rows[account_row_counter][123] = new_account.agentAccountInfo.agentInfo.taxPayerID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][124] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][125] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][126] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][127] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][128] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][129] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][130] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][131] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][132] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][133] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][134] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][135] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][136] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null) account_table.Rows[account_row_counter][137] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][138] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][139] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                    }

                    #endregion

                    if (new_account.accountCustomFieldValues != null)
                    {
                        #region accountCustomFieldValues_table

                        foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_account.accountCustomFieldValues)
                        {
                            accountCustomFieldValues_table.Rows.Add();
                            accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][0] = new_account.accountID;
                            if (cfv.customFieldValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][1] = cfv.customFieldValueID;
                            if (cfv.customFieldID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][2] = cfv.customFieldID;
                            if (cfv.optionValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][3] = cfv.optionValueID;
                            if (cfv.valueText != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][4] = cfv.valueText;
                            accountCustomFieldValues_row_counter++;

                        }

                        #endregion

                    }


                    account_row_counter++;

                }



                AccountDS.Tables.Add(accountCustomFieldValues_table);
                AccountDS.Tables[0].TableName = "AccountCustomFieldValuesTable";
                AccountDS.Tables.Add(account_table);
                AccountDS.Tables[1].TableName = "AccountTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountDS;

        }

        //Created by Amogh & Shravan for Account/Plan_View
        public DataTable GetOfficeDetail_AccountPlanView(int account_id, string SessionId, int officePlanID)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();
            BP_BrokerConnectV4.Office offData = new BP_BrokerConnectV4.Office();
            int cnt = 1;
            DataTable OfficeDT = new DataTable();

            try
            {
                OfficeDT.Columns.Add("OfficeID", typeof(Int32));     // Column 0
                OfficeDT.Columns.Add("OfficeName", typeof(String));  // Column 1
                OfficeDT.Columns.Add("RegionName", typeof(String));  // Column 2

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);

                //if (new_account != null)
                //{
                //if (new_account.officeID > 0)
                //{
                offData = new_connection.getOffice(officePlanID);

                if (cnt == 1)
                {
                    if (offData != null)
                    {
                        OfficeDT.Rows.Add();
                        OfficeDT.Rows[0][0] = offData.officeID;
                        OfficeDT.Rows[0][1] = offData.officeName;
                        OfficeDT.Rows[0][2] = offData.regionName;
                        cnt++;
                    }
                }
                //}
                //}//
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return OfficeDT;
        }


       
        /**********************************************************************************************/
        /* THIS IS NEW FUNCTION CREATED FOR ONLY ACCOUNT PROFILE SUMMERY_DETAILS PAGE - AMOGH VILAYATKAR
        /**********************************************************************************************/
        /// <summary>
        /// Build employeeTypes Table.
        /// Added By Amogh As Per Nicole requirement getting Employeetypr from webservice 
        /// [Tuesday, July 24, 2018 12:25 AM :- Are you able to use the web services EmployeeType (see below) instead of this static table]
        /// </summary>
        public void BuildEmployeeTypesTable()
        {
            try
            {
                #region EmployeeTypes Table
                accountEmployeeTypesValues_table.Columns.Add("accountID", typeof(Int32));  // Row 0
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_employeeTypeID", typeof(string));  // Row 1
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_status", typeof(string));  // Row 2
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_type", typeof(string));  // Row 3
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_value", typeof(string));  // Row 4
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_unitOfMeasureSpecified", typeof(string));  // Row 4
                accountEmployeeTypesValues_table.Columns.Add("EmployeeTypes_frequency", typeof(string));  // Row 4
                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }


        /**********************************************************************************************/
        /* THIS IS NEW FUNCTION CREATED FOR ONLY ACCOUNT PROFILE SUMMERY_DETAILS PAGE - AMOGH VILAYATKAR
        /**********************************************************************************************/
        public DataSet GetAccountDetail_AccountProfileSummeryDetails(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();

            DataSet AccountDS = new DataSet();
            int account_row_counter = 0;
            int accountCustomFieldValues_row_counter = 0;
            int accountEmployeeType_row_counter = 0;

            try
            {

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;
                new_account = new_connection.getAccount(account_id);
                string website = string.Empty;

                if (new_account != null)
                {
                    #region account_table
                    website = new_account.groupAccountInfo.commonGroupAccountInfo.website;
                    account_table.Rows.Add();
                    account_table.Rows[account_row_counter][0] = new_account.accountID;
                    if (new_account.active != null && new_account.active.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][1] = new_account.active.ToString();
                    if (new_account.inactiveAsOf != null && new_account.inactiveAsOf.Year != 1) account_table.Rows[account_row_counter][2] = new_account.inactiveAsOf;
                    if (new_account.inactiveReason != null) account_table.Rows[account_row_counter][3] = new_account.inactiveReason.ToString();
                    if (new_account.accountClassification != null) account_table.Rows[account_row_counter][4] = new_account.accountClassification.ToString();
                    if (new_account.accountType != null) account_table.Rows[account_row_counter][5] = new_account.accountType.ToString();
                    if (new_account.officeID != null) account_table.Rows[account_row_counter][6] = new_account.officeID.ToString();
                    if (new_account.departmentID != null) account_table.Rows[account_row_counter][7] = new_account.departmentID.ToString();
                    if (new_account.administratorUserID != null) account_table.Rows[account_row_counter][8] = new_account.administratorUserID.ToString();
                    if (new_account.primaryContactUserID != null) account_table.Rows[account_row_counter][9] = new_account.primaryContactUserID.ToString();
                    if (new_account.primarySalesLeadUserID != null) account_table.Rows[account_row_counter][10] = new_account.primarySalesLeadUserID.ToString();
                    if (new_account.primaryServiceLeadUserID != null) account_table.Rows[account_row_counter][11] = new_account.primaryServiceLeadUserID.ToString();
                    if (new_account.notes != null) account_table.Rows[account_row_counter][12] = new_account.notes.ToString();
                    if (new_account.lastReviewedByUserID != null) account_table.Rows[account_row_counter][13] = new_account.lastReviewedByUserID.ToString();
                    if (new_account.lastReviewedOn != null && new_account.lastReviewedOn.Year != 1) account_table.Rows[account_row_counter][14] = new_account.lastReviewedOn.ToString();
                    if (new_account.createdOn != null && new_account.createdOn.Year != 1) account_table.Rows[account_row_counter][15] = new_account.createdOn.ToString();
                    if (new_account.lastModifiedOn != null && new_account.lastModifiedOn.Year != 1) account_table.Rows[account_row_counter][16] = new_account.lastModifiedOn.ToString();



                    if (new_account.mainAddress != null)
                    {
                        if (new_account.mainAddress.street1 != null) account_table.Rows[account_row_counter][18] = new_account.mainAddress.street1.ToString();
                        if (new_account.mainAddress.street2 != null) account_table.Rows[account_row_counter][19] = new_account.mainAddress.street2.ToString();
                        if (new_account.mainAddress.city != null) account_table.Rows[account_row_counter][20] = new_account.mainAddress.city.ToString();
                        if (new_account.mainAddress.state != null) account_table.Rows[account_row_counter][21] = new_account.mainAddress.state.ToString();
                        if (new_account.mainAddress.zip != null) account_table.Rows[account_row_counter][22] = new_account.mainAddress.zip.ToString();
                        if (new_account.mainAddress.country != null) account_table.Rows[account_row_counter][23] = new_account.mainAddress.country.ToString().Replace("_", " ");
                    }

                    if (new_account.billingAddress != null)
                    {
                        if (new_account.billingAddress.street1 != null) account_table.Rows[account_row_counter][24] = new_account.billingAddress.street1.ToString();
                        if (new_account.billingAddress.street2 != null) account_table.Rows[account_row_counter][25] = new_account.billingAddress.street2.ToString();
                        if (new_account.billingAddress.city != null) account_table.Rows[account_row_counter][26] = new_account.billingAddress.city.ToString();
                        if (new_account.billingAddress.state != null) account_table.Rows[account_row_counter][27] = new_account.billingAddress.state.ToString();
                        if (new_account.billingAddress.zip != null) account_table.Rows[account_row_counter][28] = new_account.billingAddress.zip.ToString();
                        if (new_account.billingAddress.country != null) account_table.Rows[account_row_counter][29] = new_account.billingAddress.country.ToString().Replace("_", " ");


                    }

                    if (new_account.mailingAddress != null)
                    {
                        if (new_account.mailingAddress.street1 != null) account_table.Rows[account_row_counter][30] = new_account.mailingAddress.street1.ToString();
                        if (new_account.mailingAddress.street2 != null) account_table.Rows[account_row_counter][31] = new_account.mailingAddress.street2.ToString();
                        if (new_account.mailingAddress.city != null) account_table.Rows[account_row_counter][32] = new_account.mailingAddress.city.ToString();
                        if (new_account.mailingAddress.state != null) account_table.Rows[account_row_counter][33] = new_account.mailingAddress.state.ToString();
                        if (new_account.mailingAddress.zip != null) account_table.Rows[account_row_counter][34] = new_account.mailingAddress.zip.ToString();
                        if (new_account.mailingAddress.country != null) account_table.Rows[account_row_counter][35] = new_account.mailingAddress.country.ToString().Replace("_", " ");

                    }

                    if (new_account.groupAccountInfo != null)
                    {

                        if (new_account.groupAccountInfo.accountName != null) account_table.Rows[account_row_counter][36] = new_account.groupAccountInfo.accountName.ToString();
                        if (new_account.groupAccountInfo.DBA != null) account_table.Rows[account_row_counter][37] = new_account.groupAccountInfo.DBA.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][38] = new_account.groupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEsAsOf != null) account_table.Rows[account_row_counter][39] = new_account.groupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.groupAccountInfo.marketSize != null) account_table.Rows[account_row_counter][40] = new_account.groupAccountInfo.marketSize.ToString();
                        if (new_account.groupAccountInfo.businessType != null) account_table.Rows[account_row_counter][41] = new_account.groupAccountInfo.businessType.ToString();
                        if (new_account.groupAccountInfo.SICCode != null) account_table.Rows[account_row_counter][42] = new_account.groupAccountInfo.SICCode.ToString();
                        if (new_account.groupAccountInfo.NAICSCode != null) account_table.Rows[account_row_counter][43] = new_account.groupAccountInfo.NAICSCode.ToString();
                        if (new_account.groupAccountInfo.requires5500 != null && new_account.groupAccountInfo.requires5500.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][44] = new_account.groupAccountInfo.requires5500.ToString();
                        if (new_account.groupAccountInfo.locationsByZip != null) account_table.Rows[account_row_counter][45] = new_account.groupAccountInfo.locationsByZip.ToString();
                        if (new_account.groupAccountInfo.affiliates != null) account_table.Rows[account_row_counter][46] = new_account.groupAccountInfo.affiliates.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][47] = new_account.groupAccountInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][48] = new_account.groupAccountInfo.budgetedTotalAnnualRevenue.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCycles != null && new_account.groupAccountInfo.multiplePayrollCycles.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][49] = new_account.groupAccountInfo.multiplePayrollCycles.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCyclesDifferBy != null) account_table.Rows[account_row_counter][50] = new_account.groupAccountInfo.multiplePayrollCyclesDifferBy.ToString();
                        if (new_account.groupAccountInfo.singlePayrollCycle != null) account_table.Rows[account_row_counter][51] = new_account.groupAccountInfo.singlePayrollCycle.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][52] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][53] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][54] = new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][55] = new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][56] = new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][57] = new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][58] = new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][59] = new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][60] = new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][61] = new_account.groupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][62] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.Year != 1) account_table.Rows[account_row_counter][63] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][64] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][65] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalents != null) account_table.Rows[account_row_counter][145] = new_account.groupAccountInfo.numberOfFullTimeEquivalents.ToString();
                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate != null) account_table.Rows[account_row_counter][146] = new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate.ToString();

                        if (new_account.groupAccountInfo.accountIntegrationInfo != null)
                        {

                            if (new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID != null)
                                account_table.Rows[account_row_counter][140] = new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.sourceCode != null)
                                account_table.Rows[account_row_counter][141] = new_account.groupAccountInfo.accountIntegrationInfo.sourceCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode != null)
                                account_table.Rows[account_row_counter][142] = new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode != null)
                                account_table.Rows[account_row_counter][143] = new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer != null)
                                account_table.Rows[account_row_counter][144] = new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer;


                        }

                    }


                    if (new_account.individualAccountInfo != null)
                    {
                        if (new_account.individualAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][66] = new_account.individualAccountInfo.personInfo.firstName.ToString();
                        if (new_account.individualAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][67] = new_account.individualAccountInfo.personInfo.middleName.ToString();
                        if (new_account.individualAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][68] = new_account.individualAccountInfo.personInfo.lastName.ToString();
                        if (new_account.individualAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][69] = new_account.individualAccountInfo.personInfo.salutation.ToString();
                        if (new_account.individualAccountInfo.personInfo.dateOfBirth != null && new_account.individualAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][70] = new_account.individualAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.individualAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][71] = new_account.individualAccountInfo.personInfo.gender.ToString();
                        if (new_account.individualAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][72] = new_account.individualAccountInfo.personInfo.ssn.ToString();
                        if (new_account.individualAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][73] = new_account.individualAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.individualAccountInfo.email != null) account_table.Rows[account_row_counter][74] = new_account.individualAccountInfo.email.ToString();
                        if (new_account.individualAccountInfo.phone.areaCode != null) account_table.Rows[account_row_counter][75] = new_account.individualAccountInfo.phone.areaCode.ToString();
                        if (new_account.individualAccountInfo.phone.number != null) account_table.Rows[account_row_counter][76] = new_account.individualAccountInfo.phone.number.ToString();
                        if (new_account.individualAccountInfo.phone.type != null) account_table.Rows[account_row_counter][77] = new_account.individualAccountInfo.phone.type.ToString();
                        if (new_account.individualAccountInfo.affiliatedGroupAccountID != null) account_table.Rows[account_row_counter][78] = new_account.individualAccountInfo.affiliatedGroupAccountID.ToString();

                    }



                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.marketingGroupName != null) account_table.Rows[account_row_counter][79] = new_account.marketingGroupAccountInfo.marketingGroupName.ToString();
                        if (new_account.marketingGroupAccountInfo.marketingGroupType != null) account_table.Rows[account_row_counter][80] = new_account.marketingGroupAccountInfo.marketingGroupType.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][81] = new_account.marketingGroupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEsAsOf != null && new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.Year != 1) account_table.Rows[account_row_counter][82] = new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.associatedAccountIDs != null) account_table.Rows[account_row_counter][83] = new_account.marketingGroupAccountInfo.associatedAccountIDs.ToString();

                    }

                    if (new_account.agencyAccountInfo != null)
                    {
                        if (new_account.agencyAccountInfo.agencyName != null) account_table.Rows[account_row_counter][84] = new_account.agencyAccountInfo.agencyName.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.email != null) account_table.Rows[account_row_counter][85] = new_account.agencyAccountInfo.agencyInfo.email.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][86] = new_account.agencyAccountInfo.agencyInfo.phone1.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][87] = new_account.agencyAccountInfo.agencyInfo.phone2.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][88] = new_account.agencyAccountInfo.agencyInfo.phone3.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][89] = new_account.agencyAccountInfo.agencyInfo.phone4.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.number != null) account_table.Rows[account_row_counter][90] = new_account.agencyAccountInfo.agencyInfo.phone1.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.number != null) account_table.Rows[account_row_counter][91] = new_account.agencyAccountInfo.agencyInfo.phone2.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.number != null) account_table.Rows[account_row_counter][92] = new_account.agencyAccountInfo.agencyInfo.phone3.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.number != null) account_table.Rows[account_row_counter][93] = new_account.agencyAccountInfo.agencyInfo.phone4.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.type != null) account_table.Rows[account_row_counter][94] = new_account.agencyAccountInfo.agencyInfo.phone1.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.type != null) account_table.Rows[account_row_counter][95] = new_account.agencyAccountInfo.agencyInfo.phone2.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.type != null) account_table.Rows[account_row_counter][96] = new_account.agencyAccountInfo.agencyInfo.phone3.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.type != null) account_table.Rows[account_row_counter][97] = new_account.agencyAccountInfo.agencyInfo.phone4.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.taxPayerID != null) account_table.Rows[account_row_counter][98] = new_account.agencyAccountInfo.agencyInfo.taxPayerID.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][99] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][100] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.agentAccountInfo != null)
                    {
                        if (new_account.agentAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][101] = new_account.agentAccountInfo.personInfo.firstName.ToString();
                        if (new_account.agentAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][102] = new_account.agentAccountInfo.personInfo.middleName.ToString();
                        if (new_account.agentAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][103] = new_account.agentAccountInfo.personInfo.lastName.ToString();
                        if (new_account.agentAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][104] = new_account.agentAccountInfo.personInfo.salutation.ToString();
                        if (new_account.agentAccountInfo.personInfo.dateOfBirth != null && new_account.agentAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][105] = new_account.agentAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.agentAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][106] = new_account.agentAccountInfo.personInfo.gender.ToString();
                        if (new_account.agentAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][107] = new_account.agentAccountInfo.personInfo.ssn.ToString();
                        if (new_account.agentAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][108] = new_account.agentAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.agentAccountInfo.agencyAccountID != null) account_table.Rows[account_row_counter][109] = new_account.agentAccountInfo.agencyAccountID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.email != null) account_table.Rows[account_row_counter][110] = new_account.agentAccountInfo.agentInfo.email.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][111] = new_account.agentAccountInfo.agentInfo.phone1.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][112] = new_account.agentAccountInfo.agentInfo.phone2.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][113] = new_account.agentAccountInfo.agentInfo.phone3.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][114] = new_account.agentAccountInfo.agentInfo.phone4.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.number != null) account_table.Rows[account_row_counter][115] = new_account.agentAccountInfo.agentInfo.phone1.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.number != null) account_table.Rows[account_row_counter][116] = new_account.agentAccountInfo.agentInfo.phone2.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.number != null) account_table.Rows[account_row_counter][117] = new_account.agentAccountInfo.agentInfo.phone3.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.number != null) account_table.Rows[account_row_counter][118] = new_account.agentAccountInfo.agentInfo.phone4.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.type != null) account_table.Rows[account_row_counter][119] = new_account.agentAccountInfo.agentInfo.phone1.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.type != null) account_table.Rows[account_row_counter][120] = new_account.agentAccountInfo.agentInfo.phone2.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.type != null) account_table.Rows[account_row_counter][121] = new_account.agentAccountInfo.agentInfo.phone3.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.type != null) account_table.Rows[account_row_counter][122] = new_account.agentAccountInfo.agentInfo.phone4.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.taxPayerID != null) account_table.Rows[account_row_counter][123] = new_account.agentAccountInfo.agentInfo.taxPayerID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][124] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][125] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][126] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][127] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][128] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][129] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][130] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][131] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][132] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][133] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][134] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][135] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][136] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null) account_table.Rows[account_row_counter][137] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][138] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][139] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                    }

                    #endregion

                    if (new_account.accountCustomFieldValues != null)
                    {
                        #region accountCustomFieldValues_table

                        foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_account.accountCustomFieldValues)
                        {
                            accountCustomFieldValues_table.Rows.Add();
                            accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][0] = new_account.accountID;
                            if (cfv.customFieldValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][1] = cfv.customFieldValueID;
                            if (cfv.customFieldID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][2] = cfv.customFieldID;
                            if (cfv.optionValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][3] = cfv.optionValueID;
                            if (cfv.valueText != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][4] = cfv.valueText;
                            accountCustomFieldValues_row_counter++;

                        }

                        #endregion
                    }

                    #region EmployeeType Table
                    if (new_account.groupAccountInfo.employeeTypes != null)
                    {
                        if (new_account.groupAccountInfo.employeeTypes.Count() > 0)
                        {
                            foreach (BP_BrokerConnectV4.EmployeeType cfv in new_account.groupAccountInfo.employeeTypes)
                            {
                                accountEmployeeTypesValues_table.Rows.Add();
                                accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][0] = new_account.accountID;
                                if (cfv.employeeTypeID != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][1] = cfv.employeeTypeID;
                                if (cfv.status != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][2] = cfv.status;
                                if (cfv.type != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][3] = cfv.type;
                                if (cfv.value != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][4] = cfv.value;
                                if (cfv.unitOfMeasureSpecified != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][5] = cfv.unitOfMeasure;
                                if (cfv.frequency != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][6] = cfv.frequency;
                                accountEmployeeType_row_counter++;
                            }
                        }
                    }
                    #endregion

                    account_row_counter++;
                }

                AccountDS.Tables.Add(accountCustomFieldValues_table);
                AccountDS.Tables[0].TableName = "AccountCustomFieldValuesTable";
                AccountDS.Tables.Add(account_table);
                AccountDS.Tables[1].TableName = "AccountTable";
                AccountDS.Tables.Add(accountEmployeeTypesValues_table);
                AccountDS.Tables[2].TableName = "EmployeeTypeTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountDS;

        }


        /// <summary>
        /// Build Account Table.
        /// </summary>
        public void BuildAccountTable()
        {
            try
            {
                #region accounttables

                #region account_datatable

                account_table.Columns.Add("accountID", typeof(string));  // Row 0
                account_table.Columns.Add("active", typeof(bool));  // Row 1
                account_table.Columns.Add("inactiveAsOf", typeof(DateTime));  // Row 2
                account_table.Columns.Add("inactiveReason", typeof(string));  // Row 3
                account_table.Columns.Add("accountClassification", typeof(string));  // Row 4
                account_table.Columns.Add("accountType", typeof(string));  // Row 5
                account_table.Columns.Add("officeID", typeof(Int32));  // Row 6
                account_table.Columns.Add("departmentID", typeof(Int32));  // Row 7
                account_table.Columns.Add("administratorUserID", typeof(Int32));  // Row 8
                account_table.Columns.Add("primaryContactUserID", typeof(Int32));  // Row 9
                account_table.Columns.Add("primarySalesLeadUserID", typeof(Int32));  // Row 10
                account_table.Columns.Add("primaryServiceLeadUserID", typeof(Int32));  // Row 11
                account_table.Columns.Add("notes", typeof(string));  // Row 12            
                account_table.Columns.Add("lastReviewedByUserID", typeof(Int32));  // Row 13
                account_table.Columns.Add("lastReviewedOn", typeof(DateTime));  // Row 14
                account_table.Columns.Add("createdOn", typeof(DateTime));  // Row 15
                account_table.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 16
                account_table.Columns.Add("Blank", typeof(bool));  // Row 17          
                account_table.Columns.Add("mainAddress_street1", typeof(string));  // Row 18
                account_table.Columns.Add("mainAddress_street2", typeof(string));  // Row 19
                account_table.Columns.Add("mainAddress_city", typeof(string));  // Row 20
                account_table.Columns.Add("mainAddress_state", typeof(string));  // Row 21
                account_table.Columns.Add("mainAddress_zip", typeof(string));  // Row 22
                account_table.Columns.Add("mainAddress_country", typeof(string));  // Row 23
                account_table.Columns.Add("billingAddress_street1", typeof(string));  // Row 24
                account_table.Columns.Add("billingAddress_street2", typeof(string));  // Row 25
                account_table.Columns.Add("billingAddress_city", typeof(string));  // Row 26
                account_table.Columns.Add("billingAddress_state", typeof(string));  // Row 27
                account_table.Columns.Add("billingAddress_zip", typeof(string));  // Row 28
                account_table.Columns.Add("billingAddress_country", typeof(string));  // Row 29
                account_table.Columns.Add("mailingAddress_street1", typeof(string));  // Row 30
                account_table.Columns.Add("mailingAddress_street2", typeof(string));  // Row 31
                account_table.Columns.Add("mailingAddress_city", typeof(string));  // Row 32
                account_table.Columns.Add("mailingAddress_state", typeof(string));  // Row 33
                account_table.Columns.Add("mailingAddress_zip", typeof(string));  // Row 34
                account_table.Columns.Add("mailingAddress_country", typeof(string));  // Row 35
                account_table.Columns.Add("groupAccountInfo_accountName", typeof(string));  // Row 36
                account_table.Columns.Add("groupAccountInfo_DBA", typeof(string));  // Row 37
                account_table.Columns.Add("groupAccountInfo_numberOfFTEs", typeof(Int32));  // Row 38
                account_table.Columns.Add("groupAccountInfo_numberOfFTEsAsOf", typeof(DateTime));  // Row 39
                account_table.Columns.Add("groupAccountInfo_marketSize", typeof(string));  // Row 40
                account_table.Columns.Add("groupAccountInfo_businessType", typeof(string));  // Row 41
                account_table.Columns.Add("groupAccountInfo_SICCode", typeof(string));  // Row 42
                account_table.Columns.Add("groupAccountInfo_NAICSCode", typeof(string));  // Row 43
                account_table.Columns.Add("groupAccountInfo_requires5500", typeof(bool));  // Row 44
                account_table.Columns.Add("groupAccountInfo_locationsByZip", typeof(string));  // Row 45
                account_table.Columns.Add("groupAccountInfo_affiliates", typeof(string));  // Row 46
                account_table.Columns.Add("groupAccountInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 47
                account_table.Columns.Add("groupAccountInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 48
                account_table.Columns.Add("groupAccountInfo_multiplePayrollCycles", typeof(bool));  // Row 49
                account_table.Columns.Add("groupAccountInfo_multiplePayrollCyclesDifferBy", typeof(string));  // Row 50
                account_table.Columns.Add("groupAccountInfo_singlePayrollCycle", typeof(string));  // Row 51
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_numberOfRetirees", typeof(Int32));  // Row 52
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf", typeof(DateTime));  // Row 53
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_yearEstablished", typeof(Int32));  // Row 54
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_accountFundingType", typeof(string));  // Row 55
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_primaryIndustry", typeof(string));  // Row 56
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_secondaryIndustry", typeof(string));  // Row 57
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_otherPrimaryIndustry", typeof(string));  // Row 58
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_otherSecondaryIndustry", typeof(string));  // Row 59
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_taxpayerID", typeof(string));  // Row 60
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_website", typeof(string));  // Row 61
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_accountNumber", typeof(string));  // Row 62
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf", typeof(DateTime));  // Row 63
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAARequired", typeof(bool));  // Row 64
                account_table.Columns.Add("groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn", typeof(DateTime));  // Row 65
                account_table.Columns.Add("individualAccountInfo_personInfo_firstName", typeof(string));  // Row 66
                account_table.Columns.Add("individualAccountInfo_personInfo_middleName", typeof(string));  // Row 67
                account_table.Columns.Add("individualAccountInfo_personInfo_lastName", typeof(string));  // Row 68
                account_table.Columns.Add("individualAccountInfo_personInfo_salutation", typeof(string));  // Row 69
                account_table.Columns.Add("individualAccountInfo_personInfo_dateOfBirth", typeof(DateTime));  // Row 70
                account_table.Columns.Add("individualAccountInfo_personInfo_gender", typeof(string));  // Row 71
                account_table.Columns.Add("individualAccountInfo_personInfo_ssn", typeof(string));  // Row 72
                account_table.Columns.Add("individualAccountInfo_personInfo_maritalStatus", typeof(string));  // Row 73
                account_table.Columns.Add("individualAccountInfo_email", typeof(string));  // Row 74
                account_table.Columns.Add("individualAccountInfo_phone_areaCode", typeof(string));  // Row 75
                account_table.Columns.Add("individualAccountInfo_phone_number", typeof(string));  // Row 76
                account_table.Columns.Add("individualAccountInfo_phone_type", typeof(string));  // Row 77
                account_table.Columns.Add("individualAccountInfo_affiliatedGroupAccountID", typeof(Int32));  // Row 78
                account_table.Columns.Add("marketingGroupAccountInfo_marketingGroupName", typeof(string));  // Row 79
                account_table.Columns.Add("marketingGroupAccountInfo_marketingGroupType", typeof(string));  // Row 80
                account_table.Columns.Add("marketingGroupAccountInfo_numberOfFTEs", typeof(Int32));  // Row 81
                account_table.Columns.Add("marketingGroupAccountInfo_numberOfFTEsAsOf", typeof(DateTime));  // Row 82
                account_table.Columns.Add("marketingGroupAccountInfo_associatedAccountIDs", typeof(Int32));  // Row 83
                account_table.Columns.Add("agencyAccountInfo_agencyName", typeof(string));  // Row 84
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_email", typeof(string));  // Row 85
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_areaCode", typeof(string));  // Row 86
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_areaCode", typeof(string));  // Row 87
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_areaCode", typeof(string));  // Row 88
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_areaCode", typeof(string));  // Row 89
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_number", typeof(string));  // Row 90
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_number", typeof(string));  // Row 91
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_number", typeof(string));  // Row 92
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_number", typeof(string));  // Row 93
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone1_type", typeof(string));  // Row 94
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone2_type", typeof(string));  // Row 95
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone3_type", typeof(string));  // Row 96
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_phone4_type", typeof(string));  // Row 97
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_taxPayerID", typeof(string));  // Row 98
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 99
                account_table.Columns.Add("agencyAccountInfo_agencyInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 100
                account_table.Columns.Add("agentAccountInfo_personInfo_firstName", typeof(string));  // Row 101
                account_table.Columns.Add("agentAccountInfo_personInfo_middleName", typeof(string));  // Row 102
                account_table.Columns.Add("agentAccountInfo_personInfo_lastName", typeof(string));  // Row 103
                account_table.Columns.Add("agentAccountInfo_personInfo_salutation", typeof(string));  // Row 104
                account_table.Columns.Add("agentAccountInfo_personInfo_dateOfBirth", typeof(DateTime));  // Row 105
                account_table.Columns.Add("agentAccountInfo_personInfo_gender", typeof(string));  // Row 106
                account_table.Columns.Add("agentAccountInfo_personInfo_ssn", typeof(string));  // Row 107
                account_table.Columns.Add("agentAccountInfo_personInfo_maritalStatus", typeof(string));  // Row 108
                account_table.Columns.Add("agentAccountInfo_agencyAccountID", typeof(Int32));  // Row 109
                account_table.Columns.Add("agentAccountInfo_agentInfo_email", typeof(string));  // Row 110
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_areaCode", typeof(string));  // Row 111
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_areaCode", typeof(string));  // Row 112
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_areaCode", typeof(string));  // Row 113
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_areaCode", typeof(string));  // Row 114
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_number", typeof(string));  // Row 115
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_number", typeof(string));  // Row 116
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_number", typeof(string));  // Row 117
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_number", typeof(string));  // Row 118
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone1_type", typeof(string));  // Row 119
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone2_type", typeof(string));  // Row 120
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone3_type", typeof(string));  // Row 121
                account_table.Columns.Add("agentAccountInfo_agentInfo_phone4_type", typeof(string));  // Row 122
                account_table.Columns.Add("agentAccountInfo_agentInfo_taxPayerID", typeof(string));  // Row 123
                account_table.Columns.Add("agentAccountInfo_agentInfo_budgetedTotalAnnualPremium", typeof(decimal));  // Row 124
                account_table.Columns.Add("agentAccountInfo_agentInfo_budgetedTotalAnnualRevenue", typeof(decimal));  // Row 125
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_numberOfRetirees", typeof(Int32));  // Row 126
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_numberOfRetireesAsOf", typeof(DateTime));  // Row 127
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_yearEstablished", typeof(Int32));  // Row 128
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_accountFundingType", typeof(string));  // Row 129
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_primaryIndustry", typeof(string));  // Row 130
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_secondaryIndustry", typeof(string));  // Row 131
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_otherPrimaryIndustry", typeof(string));  // Row 132
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_otherSecondaryIndustry", typeof(string));  // Row 133
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_taxpayerID", typeof(string));  // Row 134
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_website", typeof(string));  // Row 135
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_accountNumber", typeof(string));  // Row 136
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf", typeof(DateTime));  // Row 137
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAARequired", typeof(bool));  // Row 138
                account_table.Columns.Add("marketingGroupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_HIPAASignedOn", typeof(DateTime));  // Row 139            
                account_table.Columns.Add("sagittaClientID", typeof(string));// Row 140
                account_table.Columns.Add("sourceCode", typeof(string));// Row 141
                account_table.Columns.Add("primarySalesLeadIntCode", typeof(string));// Row 142
                account_table.Columns.Add("primaryServiceLeadIntCode", typeof(string));// Row 143 
                account_table.Columns.Add("TAMCustomer", typeof(string));// Row 144
                account_table.Columns.Add("groupAccountInfo_numberOfFullTimeEquivalents", typeof(Int32));  // Row 145
                account_table.Columns.Add("groupAccountInfo_numberOfFullTimeEquivalentsAsOfDate", typeof(DateTime));  // Row 146

                #endregion


                accountCustomFieldValues_table.Columns.Add("accountID", typeof(Int32));  // Row 0
                accountCustomFieldValues_table.Columns.Add("customFieldValues_customFieldValueID", typeof(Int32));  // Row 1
                accountCustomFieldValues_table.Columns.Add("customFieldValues_customFieldID", typeof(Int32));  // Row 2
                accountCustomFieldValues_table.Columns.Add("customFieldValues_optionValueID", typeof(Int32));  // Row 3
                accountCustomFieldValues_table.Columns.Add("customFieldValues_valueText", typeof(string));  // Row 4
                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }


        public DataTable GetPlanContactInformation(List<int> lstProductIds, string SessionId)
        {
            DataTable dtPlanContact = new DataTable();
            dtPlanContact.Columns.Add("ProductId", typeof(Int32));
            dtPlanContact.Columns.Add("ContactId", typeof(Int32));
            dtPlanContact.Columns.Add("ContactName", typeof(string));
            dtPlanContact.Columns.Add("ContactEmail", typeof(string));
            dtPlanContact.Columns.Add("ContactWorkPhone", typeof(string));
            dtPlanContact.Columns.Add("Contact_FirstName", typeof(string));
            dtPlanContact.Columns.Add("Contact_LastName", typeof(string));
            dtPlanContact.Columns.Add("Contact_Address", typeof(string));

            int[] prodId = new int[1];
            int[] carrId = new int[1];
            int[] prodTypeId = new int[1];
            int[] officeId = new int[1];
            int[] deptId = new int[1];

            int cnt = 0;

            try
            {
                BP_BrokerConnectV4.CarrierContactSearchCriteria ccSearch = new BP_BrokerConnectV4.CarrierContactSearchCriteria();
                BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.CarrierContact[] ccContact = new BP_BrokerConnectV4.CarrierContact[50];
                BP_BrokerConnectV4.MarketSize[] marketSizes = new BP_BrokerConnectV4.MarketSize[1];
                //BP_BrokerConnectV4.State[] state = new BP_BrokerConnectV4.State[1];

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;

                cnt = 0;
                int product_id = 0;
                foreach (var dr in lstProductIds)
                {
                    product_id = Convert.ToInt32(dr);

                    new_product = new BP_BrokerConnectV4.Product();
                    new_product = new_connection.getProduct(product_id);

                    if (new_product != null)
                    {
                        prodId[0] = product_id;

                        ccSearch.productID = product_id;

                        carrId[0] = new_product.carrierID;
                        ccSearch.carrierIDs = carrId;

                        ////prodTypeId[0] = new_product.productTypeID;
                        ////ccSearch.productTypeIDs = prodTypeId;

                        ////ccSearch.productIDSpecified = new_product.productIDSpecified;

                        //marketSizes[0] = new_product.planInfo.marketSize;
                        //ccSearch.marketSizes = marketSizes;

                        //state[0] = new_product.planInfo.stateList[0];
                        //ccSearch.territories = state;

                        //officeId[0] = new_product.officeID;
                        //ccSearch.officeIDs = officeId;

                        //deptId[0] = new_product.departmentID;
                        //ccSearch.departmentIDs = deptId;

                        ccContact = new BP_BrokerConnectV4.CarrierContact[50];
                        new_connection.Timeout = 14400000; //4hours
                        ccContact = new_connection.findCarrierContacts(ccSearch);

                        if (ccContact != null)
                        {
                            var planContactList = (from n in ccContact.AsEnumerable()
                                                   where n.productIDs != null && n.productIDs.Contains(product_id)
                                                   select n.contact);

                            foreach (var item in planContactList)
                            {
                                dtPlanContact.Rows.Add();
                                dtPlanContact.Rows[cnt]["ProductId"] = product_id;
                                dtPlanContact.Rows[cnt]["ContactId"] = item.contactID;
                                dtPlanContact.Rows[cnt]["ContactName"] = item.lastName + ", " + item.firstName;
                                dtPlanContact.Rows[cnt]["ContactEmail"] = item.email;
                                dtPlanContact.Rows[cnt]["Contact_FirstName"] = item.firstName;
                                dtPlanContact.Rows[cnt]["Contact_LastName"] = item.lastName;
                                dtPlanContact.Rows[cnt]["Contact_Address"] = Convert.ToString(item.address.street1) + ", " + Convert.ToString(item.address.street2) + ", " + Convert.ToString(item.address.city) + ", " + Convert.ToString(item.address.state) + ", " + Convert.ToString(item.address.country) + ", " + Convert.ToString(item.address.zip);

                                if (item.phones != null)
                                {
                                    for (int j = 0; j < item.phones.Length; j++)
                                    {
                                        if (!string.IsNullOrEmpty(item.phones[j].number))
                                        {
                                            if (item.phones[j].type == BP_BrokerConnectV4.PhoneType.Work)
                                            {
                                                dtPlanContact.Rows[cnt]["ContactWorkPhone"] = item.phones[0].areaCode + "-" + item.phones[0].number;
                                                break;
                                            }
                                        }
                                    }
                                }

                                cnt++;
                            }
                        }
                    }
                }

                return dtPlanContact;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public DataTable GetPlanContactInformationUsingProductId(int product_id, string SessionId)
        {
            DataTable dtPlanContact = new DataTable();
            dtPlanContact.Columns.Add("ProductId", typeof(Int32));
            dtPlanContact.Columns.Add("ContactId", typeof(Int32));
            dtPlanContact.Columns.Add("ContactName", typeof(string));
            dtPlanContact.Columns.Add("ContactEmail", typeof(string));
            dtPlanContact.Columns.Add("ContactWorkPhone", typeof(string));

            int[] prodId = new int[1];
            int[] carrId = new int[1];
            int cnt = 0;

            try
            {
                BP_BrokerConnectV4.CarrierContactSearchCriteria ccSearch = new BP_BrokerConnectV4.CarrierContactSearchCriteria();
                BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
                BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                BP_BrokerConnectV4.CarrierContact[] ccContact = new BP_BrokerConnectV4.CarrierContact[20];

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;

                //foreach (DataRow dr in PlanTable.Rows)
                //{
                //    int product_id = Convert.ToInt32(dr["ProductId"].ToString());
                //    string section = dr["PlanType"].ToString();

                new_product = new BP_BrokerConnectV4.Product();
                new_product = new_connection.getProduct(product_id);

                if (new_product != null)
                {
                    prodId[0] = product_id;

                    ccSearch.productID = product_id;

                    carrId[0] = new_product.carrierID;
                    ccSearch.carrierIDs = carrId;

                    ccContact = new BP_BrokerConnectV4.CarrierContact[20];
                    ccContact = new_connection.findCarrierContacts(ccSearch);

                    cnt = 0;
                    if (ccContact != null)
                    {
                        for (int i = 0; i < ccContact.Length; i++)
                        {
                            if (ccContact[i].productIDs != null)
                            {
                                if (ccContact[i].productIDs.Contains(prodId[0]))
                                {
                                    dtPlanContact.Rows.Add();
                                    dtPlanContact.Rows[cnt]["ProductId"] = product_id;
                                    dtPlanContact.Rows[cnt]["ContactId"] = ccContact[i].contact.contactID;
                                    dtPlanContact.Rows[cnt]["ContactName"] = ccContact[i].contact.lastName + ", " + ccContact[i].contact.firstName;
                                    dtPlanContact.Rows[cnt]["ContactEmail"] = ccContact[i].contact.email;

                                    if (ccContact[i].contact.phones != null)
                                    {
                                        for (int j = 0; j < ccContact[i].contact.phones.Length; j++)
                                        {
                                            if (!string.IsNullOrEmpty(ccContact[i].contact.phones[j].number))
                                            {
                                                if (ccContact[i].contact.phones[j].type == BP_BrokerConnectV4.PhoneType.Work)
                                                {
                                                    dtPlanContact.Rows[cnt]["ContactWorkPhone"] = ccContact[i].contact.phones[0].areaCode + "-" + ccContact[i].contact.phones[0].number;
                                                    break;
                                                }
                                            }
                                        }
                                    }

                                    cnt++;
                                }
                            }
                        }
                        //}
                    }
                }

                return dtPlanContact;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Get product detail from  BP_BrokerConnectV4 web service using getProduct webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Product data</returns>

        public DataSet GetProductDetail(DataTable PlanTable, string SessionId)//(int product_id, string section)
        {
            DataSet ProductDS = new DataSet();

            int plan_type_temp = 0;
            int product_row_counter = 0;
            int customfieldvalue_row_counter = 0;

            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            string planNumber = string.Empty;

            try
            {
                foreach (DataRow dr in PlanTable.Rows)
                {
                    int product_id = Convert.ToInt32(dr["ProductId"].ToString());
                    string section = dr["PlanType"].ToString();
                    if (dr["PlanNumber"] != null)
                    {
                        planNumber = dr["PlanNumber"].ToString();
                    }

                    new_product = new BP_BrokerConnectV4.Product();
                    new_product = new_connection.getProduct(product_id);

                    if (new_product != null)
                    {
                        #region product_table

                        product_table.Rows.Add();
                        product_table.Rows[product_row_counter][70] = section;
                        if (new_product.productID != null) product_table.Rows[product_row_counter][0] = new_product.productID.ToString();
                        if (new_product.accountID != null) product_table.Rows[product_row_counter][1] = new_product.accountID.ToString();
                        if (new_product.productTypeID != null)
                        {
                            product_table.Rows[product_row_counter][2] = new_product.productTypeID.ToString();
                            plan_type_temp = new_product.productTypeID;
                        }
                        if (new_product.isAdditionalProduct != null && new_product.isAdditionalProduct.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][3] = new_product.isAdditionalProduct.ToString();
                        if (new_product.productStatus != null) product_table.Rows[product_row_counter][4] = new_product.productStatus.ToString();
                        if (new_product.carrierID != null) product_table.Rows[product_row_counter][5] = new_product.carrierID.ToString();
                        if (new_product.name != null) product_table.Rows[product_row_counter][6] = new_product.name.ToString();
                        if (new_product.brokerOfRecordAccountID != null) product_table.Rows[product_row_counter][7] = new_product.brokerOfRecordAccountID.ToString();
                        if (new_product.brokerOfRecordAsOf != null && new_product.brokerOfRecordAsOf.Year != 1) product_table.Rows[product_row_counter][8] = new_product.brokerOfRecordAsOf.ToString();
                        if (new_product.policyNumber != null) product_table.Rows[product_row_counter][9] = new_product.policyNumber.ToString();
                        if (new_product.policyOriginationReason != null) product_table.Rows[product_row_counter][10] = new_product.policyOriginationReason.ToString();
                        if (new_product.policyOriginationReasonQualifierID != null) product_table.Rows[product_row_counter][11] = new_product.policyOriginationReasonQualifierID.ToString();
                        if (new_product.parentProductID != null) product_table.Rows[product_row_counter][12] = new_product.parentProductID.ToString();
                        if (new_product.effectiveAsOf != null && new_product.effectiveAsOf.Year != 1) product_table.Rows[product_row_counter][13] = new_product.effectiveAsOf.ToString();
                        if (new_product.renewalOn != null && new_product.renewalOn.Year != 1) product_table.Rows[product_row_counter][14] = new_product.renewalOn.ToString();
                        if (new_product.continousPolicy != null && new_product.continousPolicy.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][15] = new_product.continousPolicy.ToString();
                        if (new_product.originalEffectiveAsOf != null && new_product.originalEffectiveAsOf.Year != 1) product_table.Rows[product_row_counter][16] = new_product.originalEffectiveAsOf.ToString();
                        if (new_product.cancellationOn != null && new_product.cancellationOn.Year != 1) product_table.Rows[product_row_counter][17] = new_product.cancellationOn.ToString();
                        if (new_product.cancellationReason != null) product_table.Rows[product_row_counter][18] = new_product.cancellationReason.ToString();
                        if (new_product.cancellationAdditionalInformation != null) product_table.Rows[product_row_counter][19] = new_product.cancellationAdditionalInformation.ToString();
                        if (new_product.reinstatementOn != null && new_product.reinstatementOn.Year != 1) product_table.Rows[product_row_counter][20] = new_product.reinstatementOn.ToString();
                        if (new_product.reinstatementReason != null) product_table.Rows[product_row_counter][21] = new_product.reinstatementReason.ToString();
                        if (new_product.reinstatementAdditionalInformation != null) product_table.Rows[product_row_counter][22] = new_product.reinstatementAdditionalInformation.ToString();
                        if (new_product.voluntaryProduct != null && new_product.voluntaryProduct.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][23] = new_product.voluntaryProduct.ToString();
                        if (new_product.unionProduct != null && new_product.unionProduct.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][24] = new_product.unionProduct.ToString();
                        if (new_product.nonPayable != null && new_product.nonPayable.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][25] = new_product.nonPayable.ToString();
                        if (new_product.nonRevenue != null && new_product.nonRevenue.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][26] = new_product.nonRevenue.ToString();
                        if (new_product.premiumPaymentFrequency != null) product_table.Rows[product_row_counter][27] = new_product.premiumPaymentFrequency.ToString();
                        if (new_product.numberOfEligibleEmployees != null) product_table.Rows[product_row_counter][28] = new_product.numberOfEligibleEmployees.ToString();
                        if (new_product.totalEstimatedMonthlyRevenue != null) product_table.Rows[product_row_counter][29] = new_product.totalEstimatedMonthlyRevenue.ToString();
                        if (new_product.totalEstimatedMonthlyPremium != null) product_table.Rows[product_row_counter][30] = new_product.totalEstimatedMonthlyPremium.ToString();
                        if (new_product.billingType != null) product_table.Rows[product_row_counter][31] = new_product.billingType.ToString();
                        if (new_product.billingCarrierType != null) product_table.Rows[product_row_counter][32] = new_product.billingCarrierType.ToString();
                        if (new_product.billingCarrierID != null) product_table.Rows[product_row_counter][33] = new_product.billingCarrierID.ToString();
                        if (new_product.officeID != null) product_table.Rows[product_row_counter][34] = new_product.officeID.ToString();
                        if (new_product.departmentID != null) product_table.Rows[product_row_counter][35] = new_product.departmentID.ToString();
                        if (new_product.primarySalesLeadUserID != null) product_table.Rows[product_row_counter][36] = new_product.primarySalesLeadUserID.ToString();
                        if (new_product.primaryServiceLeadUserID != null) product_table.Rows[product_row_counter][37] = new_product.primaryServiceLeadUserID.ToString();

                        if (new_product.additionalProductInfo != null)
                        {
                            if (new_product.additionalProductInfo.estimatedCommission != null) product_table.Rows[product_row_counter][38] = new_product.additionalProductInfo.estimatedCommission.ToString();
                            if (new_product.additionalProductInfo.commissionPeriodType != null) product_table.Rows[product_row_counter][39] = new_product.additionalProductInfo.commissionPeriodType.ToString();
                            if (new_product.additionalProductInfo.notes != null) product_table.Rows[product_row_counter][40] = new_product.additionalProductInfo.notes.ToString();

                        }
                        if (new_product.planInfo != null)
                        {
                            if (new_product.planInfo.alternativePlanID != null) product_table.Rows[product_row_counter][41] = new_product.planInfo.alternativePlanID.ToString();
                            if (new_product.planInfo.erisaPlan != null) product_table.Rows[product_row_counter][42] = new_product.planInfo.erisaPlan.ToString();
                            if (new_product.planInfo.erisaPlanYearEndMonth != null) product_table.Rows[product_row_counter][43] = new_product.planInfo.erisaPlanYearEndMonth.ToString();
                            if (new_product.planInfo.erisaPlanYearEndDay != null) product_table.Rows[product_row_counter][44] = new_product.planInfo.erisaPlanYearEndDay.ToString();
                            if (new_product.planInfo.notes != null) product_table.Rows[product_row_counter][45] = new_product.planInfo.notes.ToString();
                            if (new_product.planInfo.frozenEnrollment != null && new_product.planInfo.frozenEnrollment.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][46] = new_product.planInfo.frozenEnrollment.ToString();
                            if (new_product.planInfo.requires5500 != null && new_product.planInfo.requires5500.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][47] = new_product.planInfo.requires5500.ToString();
                            if (new_product.planInfo.frozenEnrollmentEffectiveAsOf != null && new_product.planInfo.frozenEnrollmentEffectiveAsOf.Year != 1) product_table.Rows[product_row_counter][48] = new_product.planInfo.frozenEnrollmentEffectiveAsOf.ToString();
                            if (new_product.planInfo.marketSize != null) product_table.Rows[product_row_counter][49] = new_product.planInfo.marketSize.ToString();
                            if (new_product.planInfo.maximumGroupSize != null) product_table.Rows[product_row_counter][50] = new_product.planInfo.maximumGroupSize.ToString();
                            if (new_product.planInfo.minimumGroupSize != null) product_table.Rows[product_row_counter][51] = new_product.planInfo.minimumGroupSize.ToString();
                            if (new_product.planInfo.exclusionsLimitations != null) product_table.Rows[product_row_counter][52] = new_product.planInfo.exclusionsLimitations.ToString();
                            if (new_product.planInfo.customizations != null) product_table.Rows[product_row_counter][53] = new_product.planInfo.customizations.ToString();
                            if (new_product.planInfo.participationRequirements != null) product_table.Rows[product_row_counter][54] = new_product.planInfo.participationRequirements.ToString();
                            if (new_product.planInfo.participationRequirementsVol != null) product_table.Rows[product_row_counter][55] = new_product.planInfo.participationRequirementsVol.ToString();

                            if (new_product.planInfo.retirementPlanInfo != null)
                            {
                                if (new_product.planInfo.retirementPlanInfo.recordKeeperPlanNumber != null) product_table.Rows[product_row_counter][56] = new_product.planInfo.retirementPlanInfo.recordKeeperPlanNumber.ToString();
                                if (new_product.planInfo.retirementPlanInfo.planAdoptionOn != null && new_product.planInfo.retirementPlanInfo.planAdoptionOn.Year != 1) product_table.Rows[product_row_counter][57] = new_product.planInfo.retirementPlanInfo.planAdoptionOn.ToString();
                                if (new_product.planInfo.retirementPlanInfo.fiscalYearFrom != null) product_table.Rows[product_row_counter][58] = new_product.planInfo.retirementPlanInfo.fiscalYearFrom.ToString();
                                if (new_product.planInfo.retirementPlanInfo.fiscalYearTo != null) product_table.Rows[product_row_counter][59] = new_product.planInfo.retirementPlanInfo.fiscalYearTo.ToString();
                                if (new_product.planInfo.retirementPlanInfo.auditRequired != null && new_product.planInfo.retirementPlanInfo.auditRequired.ToString().ToUpper() != "NONE_SELECTED") product_table.Rows[product_row_counter][60] = new_product.planInfo.retirementPlanInfo.auditRequired.ToString();
                                if (new_product.planInfo.retirementPlanInfo.auditor != null) product_table.Rows[product_row_counter][61] = new_product.planInfo.retirementPlanInfo.auditor.ToString();
                                if (new_product.planInfo.retirementPlanInfo.trustee != null) product_table.Rows[product_row_counter][62] = new_product.planInfo.retirementPlanInfo.trustee.ToString();
                                if (new_product.planInfo.retirementPlanInfo.custodian != null) product_table.Rows[product_row_counter][63] = new_product.planInfo.retirementPlanInfo.custodian.ToString();
                            }
                        }
                        if (new_product.commissionInfo != null)
                        {
                            if (new_product.commissionInfo.alternativePolicyNumber != null) product_table.Rows[product_row_counter][64] = new_product.commissionInfo.alternativePolicyNumber.ToString();
                            if (new_product.commissionInfo.newBusinessUntil != null && new_product.commissionInfo.newBusinessUntil.Year != 1) product_table.Rows[product_row_counter][65] = new_product.commissionInfo.newBusinessUntil.ToString();
                            if (new_product.commissionInfo.commissionStartOn != null && new_product.commissionInfo.commissionStartOn.Year != 1) product_table.Rows[product_row_counter][66] = new_product.commissionInfo.commissionStartOn.ToString();
                            if (new_product.commissionInfo.notes != null) product_table.Rows[product_row_counter][67] = new_product.commissionInfo.notes.ToString();
                        }

                        if (new_product.lastModifiedOn != null && new_product.lastModifiedOn.Year != 1) product_table.Rows[product_row_counter][68] = new_product.lastModifiedOn.ToString();
                        if (new_product.createdOn != null && new_product.createdOn.Year != 1) product_table.Rows[product_row_counter][69] = new_product.createdOn.ToString();
                        product_table.Rows[product_row_counter][71] = planNumber;

                        #endregion

                        if (new_product.customFieldValues != null)
                        {
                            #region customfieldvalue_table

                            foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_product.customFieldValues)
                            {
                                customfieldvalue_table.Rows.Add();
                                customfieldvalue_table.Rows[customfieldvalue_row_counter][0] = section;
                                if (new_product.productID != null) customfieldvalue_table.Rows[customfieldvalue_row_counter][1] = new_product.productID;
                                if (cfv.customFieldValueID != null) customfieldvalue_table.Rows[customfieldvalue_row_counter][2] = cfv.customFieldValueID;
                                if (cfv.customFieldID != null) customfieldvalue_table.Rows[customfieldvalue_row_counter][3] = cfv.customFieldID;
                                if (cfv.optionValueID != null) customfieldvalue_table.Rows[customfieldvalue_row_counter][4] = cfv.optionValueID;
                                if (cfv.valueText != null) customfieldvalue_table.Rows[customfieldvalue_row_counter][5] = cfv.valueText;
                                customfieldvalue_table.Rows[customfieldvalue_row_counter][6] = planNumber;

                                customfieldvalue_row_counter++;
                            }

                            #endregion
                        }

                        product_row_counter++;
                    }
                }

                ProductDS.Tables.Add(customfieldvalue_table);
                ProductDS.Tables[0].TableName = "CustomFieldValueTable";
                ProductDS.Tables.Add(product_table);
                ProductDS.Tables[1].TableName = "ProductTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return ProductDS;
        }

        /// <summary>
        ///  Build Product Table.
        /// </summary>
        public void BuildProductTable()
        {
            try
            {
                #region Product_Tables

                product_table.Columns.Add("productID", typeof(Int32));  // Row 0
                product_table.Columns.Add("accountID", typeof(Int32));  // Row 1
                product_table.Columns.Add("productTypeID", typeof(Int32));  // Row 2
                product_table.Columns.Add("isAdditionalProduct", typeof(bool));  // Row 3
                product_table.Columns.Add("productStatus", typeof(string));  // Row 4
                product_table.Columns.Add("carrierID", typeof(Int32));  // Row 5
                product_table.Columns.Add("name", typeof(string));  // Row 6
                product_table.Columns.Add("brokerOfRecordAccountID", typeof(Int32));  // Row 7
                product_table.Columns.Add("brokerOfRecordAsOf", typeof(DateTime));  // Row 8
                product_table.Columns.Add("policyNumber", typeof(string));  // Row 9
                product_table.Columns.Add("policyOriginationReason", typeof(string));  // Row 10
                product_table.Columns.Add("policyOriginationReasonQualifierID", typeof(Int32));  // Row 11
                product_table.Columns.Add("parentProductID", typeof(Int32));  // Row 12
                product_table.Columns.Add("effectiveAsOf", typeof(DateTime));  // Row 13
                product_table.Columns.Add("renewalOn", typeof(DateTime));  // Row 14
                product_table.Columns.Add("continousPolicy", typeof(bool));  // Row 15
                product_table.Columns.Add("originalEffectiveAsOf", typeof(DateTime));  // Row 16
                product_table.Columns.Add("cancellationOn", typeof(DateTime));  // Row 17
                product_table.Columns.Add("cancellationReason", typeof(string));  // Row 18
                product_table.Columns.Add("cancellationAdditionalInformation", typeof(string));  // Row 19
                product_table.Columns.Add("reinstatementOn", typeof(DateTime));  // Row 20
                product_table.Columns.Add("reinstatementReason", typeof(string));  // Row 21
                product_table.Columns.Add("reinstatementAdditionalInformation", typeof(string));  // Row 22
                product_table.Columns.Add("voluntaryProduct", typeof(bool));  // Row 23
                product_table.Columns.Add("unionProduct", typeof(bool));  // Row 24
                product_table.Columns.Add("nonPayable", typeof(bool));  // Row 25
                product_table.Columns.Add("nonRevenue", typeof(bool));  // Row 26
                product_table.Columns.Add("premiumPaymentFrequency", typeof(string));  // Row 27
                product_table.Columns.Add("numberOfEligibleEmployees", typeof(Int32));  // Row 28
                product_table.Columns.Add("totalEstimatedMonthlyRevenue", typeof(double));  // Row 29
                product_table.Columns.Add("totalEstimatedMonthlyPremium", typeof(double));  // Row 30
                product_table.Columns.Add("billingType", typeof(string));  // Row 31
                product_table.Columns.Add("billingCarrierType", typeof(string));  // Row 32
                product_table.Columns.Add("billingCarrierID", typeof(Int32));  // Row 33
                product_table.Columns.Add("officeID", typeof(Int32));  // Row 34
                product_table.Columns.Add("departmentID", typeof(Int32));  // Row 35
                product_table.Columns.Add("primarySalesLeadUserID", typeof(Int32));  // Row 36
                product_table.Columns.Add("primaryServiceLeadUserID", typeof(Int32));  // Row 37
                product_table.Columns.Add("additionalProductInfo_estimatedCommission ", typeof(double));  // Row 38
                product_table.Columns.Add("additionalProductInfo_commissionPeriodType", typeof(string));  // Row 39
                product_table.Columns.Add("additionalProductInfo_notes ", typeof(string));  // Row 40
                product_table.Columns.Add("planInfo_alternativePlanID", typeof(string));  // Row 41
                product_table.Columns.Add("planInfo_erisaPlan", typeof(string));  // Row 42
                product_table.Columns.Add("planInfo_erisaPlanYearEndMonth", typeof(Int32));  // Row 43
                product_table.Columns.Add("planInfo_erisaPlanYearEndDay", typeof(Int32));  // Row 44
                product_table.Columns.Add("planInfo_notes", typeof(string));  // Row 45
                product_table.Columns.Add("planInfo_frozenEnrollment", typeof(bool));  // Row 46
                product_table.Columns.Add("planInfo_requires5500", typeof(bool));  // Row 47
                product_table.Columns.Add("planInfo_frozenEnrollmentEffectiveAsOf", typeof(DateTime));  // Row 48
                product_table.Columns.Add("planInfo_marketSize", typeof(string));  // Row 49
                product_table.Columns.Add("planInfo_maximumGroupSize", typeof(Int32));  // Row 50
                product_table.Columns.Add("planInfo_minimumGroupSize", typeof(Int32));  // Row 51
                product_table.Columns.Add("planInfo_exclusionsLimitations", typeof(string));  // Row 52
                product_table.Columns.Add("planInfo_customizations", typeof(string));  // Row 53
                product_table.Columns.Add("planInfo_participationRequirements", typeof(string));  // Row 54
                product_table.Columns.Add("planInfo_participationRequirementsVol", typeof(string));  // Row 55
                product_table.Columns.Add("planInfo_retirementPlanInfo_recordKeeperPlanNumber", typeof(string));  // Row 56
                product_table.Columns.Add("planInfo_retirementPlanInfo_planAdoptionOn", typeof(DateTime));  // Row 57
                product_table.Columns.Add("planInfo_retirementPlanInfo_fiscalYearFrom", typeof(string));  // Row 58
                product_table.Columns.Add("planInfo_retirementPlanInfo_fiscalYearTo", typeof(string));  // Row 59
                product_table.Columns.Add("planInfo_retirementPlanInfo_auditRequired", typeof(bool));  // Row 60
                product_table.Columns.Add("planInfo_retirementPlanInfo_auditor", typeof(string));  // Row 61
                product_table.Columns.Add("planInfo_retirementPlanInfo_trustee", typeof(string));  // Row 62
                product_table.Columns.Add("planInfo_retirementPlanInfo_custodian", typeof(string));  // Row 63
                product_table.Columns.Add("commissionInfo_alternativePolicyNumber", typeof(string));  // Row 64
                product_table.Columns.Add("commissionInfo_newBusinessUntil ", typeof(DateTime));  // Row 65
                product_table.Columns.Add("commissionInfo_commissionStartOn", typeof(DateTime));  // Row 66
                product_table.Columns.Add("commissionInfo_notes", typeof(string));  // Row 67
                product_table.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 68
                product_table.Columns.Add("createdOn", typeof(DateTime));  // Row 69
                product_table.Columns.Add("section", typeof(string)); //70
                product_table.Columns.Add("PlanNumber", typeof(string));  // Row 71


                customfieldvalue_table.Columns.Add("section", typeof(string)); //6
                customfieldvalue_table.Columns.Add("productID", typeof(Int32));  // Row 0
                customfieldvalue_table.Columns.Add("customFieldValues_customFieldValueID", typeof(Int32));  // Row 1
                customfieldvalue_table.Columns.Add("customFieldValues_customFieldID", typeof(Int32));  // Row 2
                customfieldvalue_table.Columns.Add("customFieldValues_optionValueID", typeof(Int32));  // Row 3
                customfieldvalue_table.Columns.Add("customFieldValues_valueText", typeof(string));  // Row 4
                customfieldvalue_table.Columns.Add("PlanNumber", typeof(string));  // Row 5
                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// Get benefit summary structure detail from  BP_BrokerConnectV4 web service using getBenefitSummaryStructure webmethod. 
        /// </summary>
        /// <param name="ProductTypeTable">ProductTypeT table contain selected product type</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>enefitSummaryStructure data</returns>
        public DataSet GetBenefitSummaryStructure(DataTable ProductTypeTable, string SessionId)//(int plan_type, string section)
        {



            int benefitsummarystructure_row_counter = 0;
            int attributeViewLevels_table_row_counter = 0;
            int benefitColumns_row_counter = 0;
            int attributeSection_row_counter = 0;
            int attribute_row_counter = 0;



            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            new_connection.Timeout = 14400000; //4hours

            BP_BrokerConnectV4.BenefitSummaryStructure new_bss = new BP_BrokerConnectV4.BenefitSummaryStructure();


            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId;//myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;
            DataSet BenefitDS = new DataSet();
            try
            {
                foreach (DataRow dr in ProductTypeTable.Rows)
                {
                    int plan_type = int.Parse(dr["ProductTypeId"].ToString());
                    string section = dr["ProductTypeDescription"].ToString();
                    string planNumber = dr["PlanNumber"].ToString();
                    int productID = int.Parse(dr["ProductId"].ToString());

                    new_bss = new_connection.getBenefitSummaryStructure(plan_type);


                    if (new_bss != null)
                    {
                        benefitsummarystructure_table.Rows.Add();
                        benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][0] = new_bss.planTypeID;

                        if (new_bss.attributeViewLevels != null)
                        {
                            foreach (BP_BrokerConnectV4.AttributeViewLevel avl in new_bss.attributeViewLevels)
                            {
                                attributeViewLevels_table.Rows.Add();
                                attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][0] = section;
                                attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][1] = new_bss.planTypeID;
                                if (avl.ID != null) attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][2] = avl.ID;
                                if (avl.description != null) attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][3] = avl.description.ToString();
                                attributeViewLevels_table_row_counter++;
                            }

                        }

                        if (new_bss.benefitColumns != null)
                        {
                            foreach (BP_BrokerConnectV4.BenefitColumn bc in new_bss.benefitColumns)
                            {
                                benefitColumns_table.Rows.Add();
                                benefitColumns_table.Rows[benefitColumns_row_counter][0] = section;
                                benefitColumns_table.Rows[benefitColumns_row_counter][1] = new_bss.planTypeID;
                                if (bc.benefitColumnID != null) benefitColumns_table.Rows[benefitColumns_row_counter][2] = bc.benefitColumnID;
                                if (bc.description != null) benefitColumns_table.Rows[benefitColumns_row_counter][3] = bc.description.ToString(); ;
                                benefitColumns_table.Rows[benefitColumns_row_counter][4] = planNumber;
                                benefitColumns_table.Rows[benefitColumns_row_counter][5] = productID;
                                benefitColumns_row_counter++;

                            }

                        }

                        if (new_bss.attributeSection != null)
                        {
                            benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][0] = section;
                            benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][1] = new_bss.attributeSection.attributeSectionID;
                            if (new_bss.attributeSection.name != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][2] = new_bss.attributeSection.name.ToString();
                            if (new_bss.attributeSection.parentID != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][3] = new_bss.attributeSection.parentID;
                            if (new_bss.attributeSection.viewLevelID != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][4] = new_bss.attributeSection.viewLevelID;

                            foreach (BP_BrokerConnectV4.AttributeSection as2 in new_bss.attributeSection.attributeSections)
                            {

                                attributeSection_table.Rows.Add();
                                attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                attributeSection_table.Rows[attributeSection_row_counter][2] = as2.attributeSectionID;
                                if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as2.name.ToString();
                                if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as2.parentID;
                                if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as2.viewLevelID;
                                attributeSection_row_counter++;

                                if (as2.attributes != null)
                                {
                                    foreach (BP_BrokerConnectV4.Attribute at in as2.attributes)
                                    {
                                        attribute_table.Rows.Add();
                                        attribute_table.Rows[attribute_row_counter][0] = section;
                                        attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                        attribute_table.Rows[attribute_row_counter][2] = as2.attributeSectionID;
                                        if (at.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at.attributeID;
                                        if (at.name != null) attribute_table.Rows[attribute_row_counter][4] = at.name.ToString();
                                        if (at.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at.parentID;
                                        if (at.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at.viewLevelID;

                                        attribute_row_counter++;

                                    }

                                }

                                if (as2.attributeSections != null)
                                {

                                    foreach (BP_BrokerConnectV4.AttributeSection as3 in as2.attributeSections)
                                    {
                                        attributeSection_table.Rows.Add();
                                        attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                        attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                        attributeSection_table.Rows[attributeSection_row_counter][2] = as3.attributeSectionID;
                                        if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as3.name.ToString();
                                        if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as3.parentID;
                                        if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as3.viewLevelID;
                                        attributeSection_row_counter++;

                                        if (as3.attributes != null)
                                        {
                                            foreach (BP_BrokerConnectV4.Attribute at2 in as3.attributes)
                                            {
                                                attribute_table.Rows.Add();
                                                attribute_table.Rows[attribute_row_counter][0] = section;
                                                attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                                attribute_table.Rows[attribute_row_counter][2] = as3.attributeSectionID;
                                                if (at2.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at2.attributeID;
                                                if (at2.name != null) attribute_table.Rows[attribute_row_counter][4] = at2.name.ToString();
                                                if (at2.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at2.parentID;
                                                if (at2.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at2.viewLevelID;

                                                attribute_row_counter++;
                                            }

                                        }
                                        //here
                                        if (as3.attributeSections != null)
                                        {
                                            foreach (BP_BrokerConnectV4.AttributeSection as4 in as3.attributeSections)
                                            {
                                                attributeSection_table.Rows.Add();
                                                attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                                attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                                attributeSection_table.Rows[attributeSection_row_counter][2] = as4.attributeSectionID;
                                                if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as4.name.ToString();
                                                if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as4.parentID;
                                                if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as4.viewLevelID;
                                                attributeSection_row_counter++;

                                                if (as4.attributes != null)
                                                {
                                                    foreach (BP_BrokerConnectV4.Attribute at3 in as4.attributes)
                                                    {
                                                        attribute_table.Rows.Add();
                                                        attribute_table.Rows[attribute_row_counter][0] = section;
                                                        attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                                        attribute_table.Rows[attribute_row_counter][2] = as4.attributeSectionID;
                                                        if (at3.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at3.attributeID;
                                                        if (at3.name != null) attribute_table.Rows[attribute_row_counter][4] = at3.name.ToString();
                                                        if (at3.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at3.parentID;
                                                        if (at3.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at3.viewLevelID;

                                                        attribute_row_counter++;

                                                    }

                                                }

                                            }
                                        }

                                    }

                                }
                            }

                        }


                    }





                    benefitsummarystructure_row_counter++;
                }
                BenefitDS.Tables.Add(attributeViewLevels_table);
                BenefitDS.Tables[0].TableName = "AttributeViewLevelsTable";
                BenefitDS.Tables.Add(benefitColumns_table);
                BenefitDS.Tables[1].TableName = "BenefitColumnsTable";
                BenefitDS.Tables.Add(attribute_table);
                BenefitDS.Tables[2].TableName = "AttributeTable";
                BenefitDS.Tables.Add(attributeSection_table);
                BenefitDS.Tables[3].TableName = "AttributeSectionTable";
                BenefitDS.Tables.Add(benefitsummarystructure_table);
                BenefitDS.Tables[4].TableName = "BenefitSummaryStructureTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return BenefitDS;
        }
        /// <summary>
        /// Get benefit summary structure detail from  BP_BrokerConnectV4 web service using getBenefitSummaryStructure webmethod. 
        /// </summary>
        /// <param name="ProductTypeTable">ProductTypeT table contain selected product type</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>enefitSummaryStructure data</returns>
        public DataSet GetBenefitSummaryStructurePilot(DataTable ProductTypeTable, string SessionId)//(int plan_type, string section)
        {



            int benefitsummarystructure_row_counter = 0;
            int attributeViewLevels_table_row_counter = 0;
            int benefitColumns_row_counter = 0;
            int attributeSection_row_counter = 0;
            int attribute_row_counter = 0;



            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            new_connection.Timeout = 14400000; //4hours

            BP_BrokerConnectV4.BenefitSummaryStructure new_bss = new BP_BrokerConnectV4.BenefitSummaryStructure();


            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId;//myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;
            DataSet BenefitDS = new DataSet();
            try
            {
                foreach (DataRow dr in ProductTypeTable.Rows)
                {
                    int plan_type = int.Parse(dr["ProductTypeId"].ToString());
                    string section = dr["ProductTypeDescription"].ToString();
                    string planNumber = dr["PlanNumber"].ToString();
                    int productID = int.Parse(dr["ProductId"].ToString());
                    int ProductTypeId = Convert.ToInt32(dr["ProductTypeId"].ToString());

                    if (Convert.ToString(ProductTypeId).Length < 4)
                    {
                        new_bss = new_connection.getBenefitSummaryStructure(plan_type);


                        if (new_bss != null)
                        {
                            benefitsummarystructure_table.Rows.Add();
                            benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][0] = new_bss.planTypeID;

                            if (new_bss.attributeViewLevels != null)
                            {
                                foreach (BP_BrokerConnectV4.AttributeViewLevel avl in new_bss.attributeViewLevels)
                                {
                                    attributeViewLevels_table.Rows.Add();
                                    attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][0] = section;
                                    attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][1] = new_bss.planTypeID;
                                    if (avl.ID != null) attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][2] = avl.ID;
                                    if (avl.description != null) attributeViewLevels_table.Rows[attributeViewLevels_table_row_counter][3] = avl.description.ToString();
                                    attributeViewLevels_table_row_counter++;
                                }

                            }

                            if (new_bss.benefitColumns != null)
                            {
                                foreach (BP_BrokerConnectV4.BenefitColumn bc in new_bss.benefitColumns)
                                {
                                    benefitColumns_table.Rows.Add();
                                    benefitColumns_table.Rows[benefitColumns_row_counter][0] = section;
                                    benefitColumns_table.Rows[benefitColumns_row_counter][1] = new_bss.planTypeID;
                                    if (bc.benefitColumnID != null) benefitColumns_table.Rows[benefitColumns_row_counter][2] = bc.benefitColumnID;
                                    if (bc.description != null) benefitColumns_table.Rows[benefitColumns_row_counter][3] = bc.description.ToString(); ;
                                    benefitColumns_table.Rows[benefitColumns_row_counter][4] = planNumber;
                                    benefitColumns_table.Rows[benefitColumns_row_counter][5] = productID;
                                    benefitColumns_row_counter++;

                                }

                            }

                            if (new_bss.attributeSection != null)
                            {
                                benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][0] = section;
                                benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][1] = new_bss.attributeSection.attributeSectionID;
                                if (new_bss.attributeSection.name != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][2] = new_bss.attributeSection.name.ToString();
                                if (new_bss.attributeSection.parentID != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][3] = new_bss.attributeSection.parentID;
                                if (new_bss.attributeSection.viewLevelID != null) benefitsummarystructure_table.Rows[benefitsummarystructure_row_counter][4] = new_bss.attributeSection.viewLevelID;

                                foreach (BP_BrokerConnectV4.AttributeSection as2 in new_bss.attributeSection.attributeSections)
                                {

                                    attributeSection_table.Rows.Add();
                                    attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                    attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                    attributeSection_table.Rows[attributeSection_row_counter][2] = as2.attributeSectionID;
                                    if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as2.name.ToString();
                                    if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as2.parentID;
                                    if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as2.viewLevelID;
                                    attributeSection_row_counter++;

                                    if (as2.attributes != null)
                                    {
                                        foreach (BP_BrokerConnectV4.Attribute at in as2.attributes)
                                        {
                                            attribute_table.Rows.Add();
                                            attribute_table.Rows[attribute_row_counter][0] = section;
                                            attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                            attribute_table.Rows[attribute_row_counter][2] = as2.attributeSectionID;
                                            if (at.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at.attributeID;
                                            if (at.name != null) attribute_table.Rows[attribute_row_counter][4] = at.name.ToString();
                                            if (at.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at.parentID;
                                            if (at.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at.viewLevelID;

                                            attribute_row_counter++;

                                        }

                                    }

                                    if (as2.attributeSections != null)
                                    {

                                        foreach (BP_BrokerConnectV4.AttributeSection as3 in as2.attributeSections)
                                        {
                                            attributeSection_table.Rows.Add();
                                            attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                            attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                            attributeSection_table.Rows[attributeSection_row_counter][2] = as3.attributeSectionID;
                                            if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as3.name.ToString();
                                            if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as3.parentID;
                                            if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as3.viewLevelID;
                                            attributeSection_row_counter++;

                                            if (as3.attributes != null)
                                            {
                                                foreach (BP_BrokerConnectV4.Attribute at2 in as3.attributes)
                                                {
                                                    attribute_table.Rows.Add();
                                                    attribute_table.Rows[attribute_row_counter][0] = section;
                                                    attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                                    attribute_table.Rows[attribute_row_counter][2] = as3.attributeSectionID;
                                                    if (at2.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at2.attributeID;
                                                    if (at2.name != null) attribute_table.Rows[attribute_row_counter][4] = at2.name.ToString();
                                                    if (at2.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at2.parentID;
                                                    if (at2.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at2.viewLevelID;

                                                    attribute_row_counter++;
                                                }

                                            }
                                            //here
                                            if (as3.attributeSections != null)
                                            {
                                                foreach (BP_BrokerConnectV4.AttributeSection as4 in as3.attributeSections)
                                                {
                                                    attributeSection_table.Rows.Add();
                                                    attributeSection_table.Rows[attributeSection_row_counter][0] = section;
                                                    attributeSection_table.Rows[attributeSection_row_counter][1] = new_bss.planTypeID;
                                                    attributeSection_table.Rows[attributeSection_row_counter][2] = as4.attributeSectionID;
                                                    if (as2.name != null) attributeSection_table.Rows[attributeSection_row_counter][3] = as4.name.ToString();
                                                    if (as2.parentID != null) attributeSection_table.Rows[attributeSection_row_counter][4] = as4.parentID;
                                                    if (as2.viewLevelID != null) attributeSection_table.Rows[attributeSection_row_counter][5] = as4.viewLevelID;
                                                    attributeSection_row_counter++;

                                                    if (as4.attributes != null)
                                                    {
                                                        foreach (BP_BrokerConnectV4.Attribute at3 in as4.attributes)
                                                        {
                                                            attribute_table.Rows.Add();
                                                            attribute_table.Rows[attribute_row_counter][0] = section;
                                                            attribute_table.Rows[attribute_row_counter][1] = new_bss.planTypeID;
                                                            attribute_table.Rows[attribute_row_counter][2] = as4.attributeSectionID;
                                                            if (at3.attributeID != null) attribute_table.Rows[attribute_row_counter][3] = at3.attributeID;
                                                            if (at3.name != null) attribute_table.Rows[attribute_row_counter][4] = at3.name.ToString();
                                                            if (at3.parentID != null) attribute_table.Rows[attribute_row_counter][5] = at3.parentID;
                                                            if (at3.viewLevelID != null) attribute_table.Rows[attribute_row_counter][6] = at3.viewLevelID;

                                                            attribute_row_counter++;

                                                        }

                                                    }

                                                }
                                            }

                                        }

                                    }
                                }

                            }


                        }

                        benefitsummarystructure_row_counter++;
                    }
                }
                BenefitDS.Tables.Add(attributeViewLevels_table);
                BenefitDS.Tables[0].TableName = "AttributeViewLevelsTable";
                BenefitDS.Tables.Add(benefitColumns_table);
                BenefitDS.Tables[1].TableName = "BenefitColumnsTable";
                BenefitDS.Tables.Add(attribute_table);
                BenefitDS.Tables[2].TableName = "AttributeTable";
                BenefitDS.Tables.Add(attributeSection_table);
                BenefitDS.Tables[3].TableName = "AttributeSectionTable";
                BenefitDS.Tables.Add(benefitsummarystructure_table);
                BenefitDS.Tables[4].TableName = "BenefitSummaryStructureTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return BenefitDS;
        }
        /// <summary>
        ///  Build Benefit Summary Structure Table.
        /// </summary>
        public void BuildBenifitSummaryStructureTable()
        {
            try
            {
                #region benefitsummarystructure
                benefitsummarystructure_table.Columns.Add("section", typeof(string));
                benefitsummarystructure_table.Columns.Add("planTypeID", typeof(Int32));
                benefitsummarystructure_table.Columns.Add("attributeSectionID", typeof(Int32));
                benefitsummarystructure_table.Columns.Add("name", typeof(string));
                benefitsummarystructure_table.Columns.Add("parentID", typeof(Int32));
                benefitsummarystructure_table.Columns.Add("ViewLevel", typeof(string));


                attributeViewLevels_table.Columns.Add("section", typeof(string));
                attributeViewLevels_table.Columns.Add("planTypeID", typeof(Int32));
                attributeViewLevels_table.Columns.Add("attributeViewLevelID", typeof(Int32));
                attributeViewLevels_table.Columns.Add("description ", typeof(string));


                benefitColumns_table.Columns.Add("section", typeof(string));
                benefitColumns_table.Columns.Add("planTypeID", typeof(Int32));
                benefitColumns_table.Columns.Add("benefitColumnID", typeof(Int32));
                benefitColumns_table.Columns.Add("description ", typeof(string));
                benefitColumns_table.Columns.Add("PlanNumber ", typeof(string));
                benefitColumns_table.Columns.Add("ProductId ", typeof(Int32));

                attributeSection_table.Columns.Add("section", typeof(string));
                attributeSection_table.Columns.Add("planTypeID", typeof(Int32));
                attributeSection_table.Columns.Add("attributeSectionID", typeof(Int32));
                attributeSection_table.Columns.Add("name", typeof(string));
                attributeSection_table.Columns.Add("parentID", typeof(Int32));
                attributeSection_table.Columns.Add("ViewLevel", typeof(string));


                attribute_table.Columns.Add("section", typeof(string));
                attribute_table.Columns.Add("planTypeID", typeof(Int32));
                attribute_table.Columns.Add("attributeSectionID", typeof(Int32));
                attribute_table.Columns.Add("attributeID", typeof(string));
                attribute_table.Columns.Add("name", typeof(string));
                attribute_table.Columns.Add("parentID", typeof(Int32));
                attribute_table.Columns.Add("ViewLevel", typeof(string));

                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// Get benefit summary detail from  BP_BrokerConnectV4 web service using getBenefitSummary webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>BenefitSummary data</returns>
        public DataSet GetBenefitSummary(DataTable PlanTable, string SessionId)//int account_id, int product_id, string section, int summary_id)
        {

            bool dollars = false;
            DataSet BenifitSumamryDS = new DataSet();


            int benefitsummary_row_counter = 0;
            int attributevalue_row_counter = 0;
            int attributevaluedetail_row_counter = 0;


            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours
            BP_BrokerConnectV4.BenefitSummarySearchCriteria new_benefits_search = new BP_BrokerConnectV4.BenefitSummarySearchCriteria();
            BP_BrokerConnectV4.BenefitSummaryDescription[] new_benefit_description_summary = new BP_BrokerConnectV4.BenefitSummaryDescription[0];
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            try
            {

                foreach (DataRow dr in PlanTable.Rows)
                {
                    string section = dr["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(dr["SummaryId"].ToString());


                    #region BenefitSummaryDescription

                    BP_BrokerConnectV4.BenefitSummary new_benefitsummary = new BP_BrokerConnectV4.BenefitSummary();

                    new_benefitsummary = new_connection.getBenefitSummary(summary_id);


                    #region benfitsummary_table

                    benefitsummary_table.Rows.Add();

                    benefitsummary_table.Rows[benefitsummary_row_counter][0] = section;
                    benefitsummary_table.Rows[benefitsummary_row_counter][1] = new_benefitsummary.benefitSummaryID;
                    if (new_benefitsummary.productID != null) benefitsummary_table.Rows[benefitsummary_row_counter][2] = new_benefitsummary.productID;
                    if (new_benefitsummary.description != null) benefitsummary_table.Rows[benefitsummary_row_counter][3] = new_benefitsummary.description;
                    if (new_benefitsummary.viewLevelID != null) benefitsummary_table.Rows[benefitsummary_row_counter][4] = new_benefitsummary.viewLevelID;
                    if (new_benefitsummary.lastModifiedOn != null && new_benefitsummary.lastModifiedOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][5] = new_benefitsummary.lastModifiedOn;
                    if (new_benefitsummary.createdOn != null && new_benefitsummary.createdOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][6] = new_benefitsummary.createdOn;

                    benefitsummary_row_counter++;
                    #endregion


                    if (new_benefitsummary.attributeValues != null)
                    {
                        foreach (BP_BrokerConnectV4.AttributeValue AV in new_benefitsummary.attributeValues)
                        {
                            #region attributevalue_table
                            attributevalue_table.Rows.Add();
                            attributevalue_table.Rows[attributevalue_row_counter][0] = section;
                            attributevalue_table.Rows[attributevalue_row_counter][1] = new_benefitsummary.benefitSummaryID;
                            attributevalue_table.Rows[attributevalue_row_counter][2] = AV.attributeID;
                            if (AV.attributeVisibility != null) attributevalue_table.Rows[attributevalue_row_counter][3] = AV.attributeVisibility;
                            if (AV.rider != null && AV.rider.ToString().ToUpper() != "NONE_SELECTED") attributevalue_table.Rows[attributevalue_row_counter][4] = AV.rider;
                            attributevalue_row_counter++;

                            #endregion

                            if (AV.attributeValueDetails != null)
                            {
                                foreach (BP_BrokerConnectV4.AttributeValueDetail AVD in AV.attributeValueDetails)
                                {
                                    #region attributevaluedetail_table
                                    attributevaluedetail_table.Rows.Add();
                                    attributevaluedetail_table.Rows[attributevaluedetail_row_counter][0] = section;
                                    attributevaluedetail_table.Rows[attributevaluedetail_row_counter][1] = new_benefitsummary.benefitSummaryID;
                                    attributevaluedetail_table.Rows[attributevaluedetail_row_counter][2] = AV.attributeID;
                                    if (AVD.ancillaryText != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][3] = AVD.ancillaryText;
                                    if (AVD.exclusionsLimitations != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][4] = AVD.exclusionsLimitations;

                                    attributevaluedetail_table.Rows[attributevaluedetail_row_counter][8] = "";

                                    if (AVD.UOM != null)
                                    {
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][5] = AVD.UOM;



                                        if (AVD.UOM.ToString() == "dollars")
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "$";
                                            dollars = true;
                                        }
                                        else if (AVD.UOM.ToString() == "percent")
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "%";
                                        else if (AVD.UOM.ToString() == "days")
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " days";
                                        else if (AVD.UOM.ToString() == "months")
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " months";
                                        else if (AVD.UOM.ToString() == "X_salary")
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " X salary";

                                        else
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "";
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "";
                                        }
                                    }
                                    if (AVD.value != null)
                                    {


                                        if (dollars == true)
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = String.Format("{0:n}", Convert.ToDouble(AVD.value)).Substring(0, (String.Format("{0:n}", Convert.ToDouble(AVD.value)).Length) - 3);
                                            dollars = false;

                                        }
                                        else if (AVD.value.Contains(".0"))
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.Substring(0, AVD.value.Length - 2).ToString();
                                        }
                                        else
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.ToString();
                                        }



                                    }
                                    if (AVD.benefitColumnID != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][7] = AVD.benefitColumnID;

                                    attributevaluedetail_row_counter++;

                                    #endregion
                                    //break;
                                }
                            }
                        }

                    }


                    #endregion





                }
                BenifitSumamryDS.Tables.Add(benefitsummary_table);
                BenifitSumamryDS.Tables[0].TableName = "BenefitSummaryTable";

                BenifitSumamryDS.Tables.Add(attributevalue_table);
                BenifitSumamryDS.Tables[1].TableName = "AttributeValueTable";
                BenifitSumamryDS.Tables.Add(attributevaluedetail_table);
                BenifitSumamryDS.Tables[2].TableName = "AttributeValueDetailTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return BenifitSumamryDS;
        }

        /// <summary>
        /// Get benefit summary detail from  BP_BrokerConnectV4 web service using getBenefitSummary webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>BenefitSummary data</returns>
        public DataSet GetBenefitSummaryPilot(DataTable PlanTable, string SessionId)//int account_id, int product_id, string section, int summary_id)
        {

            bool dollars = false;
            DataSet BenifitSumamryDS = new DataSet();


            int benefitsummary_row_counter = 0;
            int attributevalue_row_counter = 0;
            int attributevaluedetail_row_counter = 0;


            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours
            BP_BrokerConnectV4.BenefitSummarySearchCriteria new_benefits_search = new BP_BrokerConnectV4.BenefitSummarySearchCriteria();
            BP_BrokerConnectV4.BenefitSummaryDescription[] new_benefit_description_summary = new BP_BrokerConnectV4.BenefitSummaryDescription[0];
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            try
            {

                foreach (DataRow dr in PlanTable.Rows)
                {
                    string section = dr["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(dr["SummaryId"].ToString());
                    int ProductTypeId = Convert.ToInt32(dr["ProductTypeId"].ToString());

                    if (Convert.ToString(ProductTypeId).Length < 4)
                    {

                        #region BenefitSummaryDescription

                        BP_BrokerConnectV4.BenefitSummary new_benefitsummary = new BP_BrokerConnectV4.BenefitSummary();

                        new_benefitsummary = new_connection.getBenefitSummary(summary_id);


                        #region benfitsummary_table

                        benefitsummary_table.Rows.Add();

                        benefitsummary_table.Rows[benefitsummary_row_counter][0] = section;
                        benefitsummary_table.Rows[benefitsummary_row_counter][1] = new_benefitsummary.benefitSummaryID;
                        if (new_benefitsummary.productID != null) benefitsummary_table.Rows[benefitsummary_row_counter][2] = new_benefitsummary.productID;
                        if (new_benefitsummary.description != null) benefitsummary_table.Rows[benefitsummary_row_counter][3] = new_benefitsummary.description;
                        if (new_benefitsummary.viewLevelID != null) benefitsummary_table.Rows[benefitsummary_row_counter][4] = new_benefitsummary.viewLevelID;
                        if (new_benefitsummary.lastModifiedOn != null && new_benefitsummary.lastModifiedOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][5] = new_benefitsummary.lastModifiedOn;
                        if (new_benefitsummary.createdOn != null && new_benefitsummary.createdOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][6] = new_benefitsummary.createdOn;

                        benefitsummary_row_counter++;
                        #endregion


                        if (new_benefitsummary.attributeValues != null)
                        {
                            foreach (BP_BrokerConnectV4.AttributeValue AV in new_benefitsummary.attributeValues)
                            {
                                #region attributevalue_table
                                attributevalue_table.Rows.Add();
                                attributevalue_table.Rows[attributevalue_row_counter][0] = section;
                                attributevalue_table.Rows[attributevalue_row_counter][1] = new_benefitsummary.benefitSummaryID;
                                attributevalue_table.Rows[attributevalue_row_counter][2] = AV.attributeID;
                                if (AV.attributeVisibility != null) attributevalue_table.Rows[attributevalue_row_counter][3] = AV.attributeVisibility;
                                if (AV.rider != null && AV.rider.ToString().ToUpper() != "NONE_SELECTED") attributevalue_table.Rows[attributevalue_row_counter][4] = AV.rider;
                                attributevalue_row_counter++;

                                #endregion

                                if (AV.attributeValueDetails != null)
                                {
                                    foreach (BP_BrokerConnectV4.AttributeValueDetail AVD in AV.attributeValueDetails)
                                    {
                                        #region attributevaluedetail_table
                                        attributevaluedetail_table.Rows.Add();
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][0] = section;
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][1] = new_benefitsummary.benefitSummaryID;
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][2] = AV.attributeID;
                                        if (AVD.ancillaryText != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][3] = AVD.ancillaryText;
                                        if (AVD.exclusionsLimitations != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][4] = AVD.exclusionsLimitations;

                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][8] = "";

                                        if (AVD.UOM != null)
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][5] = AVD.UOM;



                                            if (AVD.UOM.ToString() == "dollars")
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "$";
                                                dollars = true;
                                            }
                                            else if (AVD.UOM.ToString() == "percent")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "%";
                                            else if (AVD.UOM.ToString() == "days")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " days";
                                            else if (AVD.UOM.ToString() == "months")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " months";
                                            else if (AVD.UOM.ToString() == "X_salary")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " X salary";

                                            else
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "";
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "";
                                            }
                                        }
                                        if (AVD.value != null)
                                        {


                                            if (dollars == true)
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = String.Format("{0:n}", Convert.ToDouble(AVD.value)).Substring(0, (String.Format("{0:n}", Convert.ToDouble(AVD.value)).Length) - 3);
                                                dollars = false;

                                            }
                                            else if (AVD.value.Contains(".0"))
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.Substring(0, AVD.value.Length - 2).ToString();
                                            }
                                            else
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.ToString();
                                            }



                                        }
                                        if (AVD.benefitColumnID != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][7] = AVD.benefitColumnID;

                                        attributevaluedetail_row_counter++;

                                        #endregion
                                        //break;
                                    }
                                }
                            }

                        }


                        #endregion

                    }



                }
                BenifitSumamryDS.Tables.Add(benefitsummary_table);
                BenifitSumamryDS.Tables[0].TableName = "BenefitSummaryTable";

                BenifitSumamryDS.Tables.Add(attributevalue_table);
                BenifitSumamryDS.Tables[1].TableName = "AttributeValueTable";
                BenifitSumamryDS.Tables.Add(attributevaluedetail_table);
                BenifitSumamryDS.Tables[2].TableName = "AttributeValueDetailTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return BenifitSumamryDS;
        }


        /// <summary>
        ///  Build Benefit Summary Table.
        /// </summary>
        public void BuildBenefitSummaryTable()
        {
            try
            {
                #region benefits_summary
                benefitsummary_table.Columns.Add("section", typeof(string));
                benefitsummary_table.Columns.Add("benefitSummaryID", typeof(Int32));
                benefitsummary_table.Columns.Add("ProductID", typeof(Int32));
                benefitsummary_table.Columns.Add("description", typeof(string));
                benefitsummary_table.Columns.Add("viewLevelID", typeof(Int32));
                benefitsummary_table.Columns.Add("lastModifiedOn", typeof(DateTime));
                benefitsummary_table.Columns.Add("createdOn", typeof(DateTime));




                attributevalue_table.Columns.Add("section", typeof(string));
                attributevalue_table.Columns.Add("benefitSummaryID", typeof(Int32));
                attributevalue_table.Columns.Add("attributeID", typeof(Int32));
                attributevalue_table.Columns.Add("attributeVisibility", typeof(string));
                attributevalue_table.Columns.Add("rider", typeof(bool));



                attributevaluedetail_table.Columns.Add("section", typeof(string));//0 PlanType
                attributevaluedetail_table.Columns.Add("benefitSummaryID", typeof(Int32));//1
                attributevaluedetail_table.Columns.Add("attributeID", typeof(Int32));//2
                attributevaluedetail_table.Columns.Add("ancillaryText", typeof(string));//3
                attributevaluedetail_table.Columns.Add("exclusionsLimitations", typeof(string));//4
                attributevaluedetail_table.Columns.Add("UOM", typeof(string));//5
                attributevaluedetail_table.Columns.Add("value", typeof(string));//6
                attributevaluedetail_table.Columns.Add("benefitColumnID", typeof(Int32));//7
                attributevaluedetail_table.Columns.Add("USI_AttributeValueDetailID", typeof(string));//8
                attributevaluedetail_table.Columns.Add("prefix", typeof(string));//9
                attributevaluedetail_table.Columns.Add("suffix", typeof(string));//10



                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        ///Get eligibility rule detail from  BP_BrokerConnectV4 web service using findEligibilityRules and getEligibilityRule webmethod. 
        ///</summary>
        ///<param name="PlanTable">Plan table contain selected plan.</param>
        ///<param name="SessionId">Session Id of Login User.</param>
        /// <returns>EligibilityRule Data</returns>
        public DataSet GetEligibilityRule(DataTable PlanTable, string SessionId, int EleigibilityRuleId)//(int product_id, string section, int summary_id)
        {


            int eligibilityrule_row_counter = 0;
            int employeeTypeIDs_row_counter = 0;

            DataSet EligibilityDS = new DataSet();

            try
            {
                if (EleigibilityRuleId != 0)
                {
                    BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                    new_connection.Timeout = 14400000; //4hours
                    BP_BrokerConnectV4.EligibilityRuleSearchCriteria new_eligibilityrule_search = new BP_BrokerConnectV4.EligibilityRuleSearchCriteria();

                    string section = "Medical Plan";

                    BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                    SIH.sessionId = SessionId;// myloginresult.sessionID;
                    new_connection.SessionIdHeaderValue = SIH;

                    BP_BrokerConnectV4.EligibilityRule new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new_connection.getEligibilityRule(EleigibilityRuleId);

                    if (new_eligibilityrule != null)
                    {

                        #region eligibilityrule_table

                        eligibilityrule_table.Rows.Add();
                        eligibilityrule_table.Rows[eligibilityrule_row_counter][0] = section;
                        if (new_eligibilityrule.eligibilityRuleID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                        if (new_eligibilityrule.productID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][2] = new_eligibilityrule.productID;
                        if (new_eligibilityrule.planDesignID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][3] = new_eligibilityrule.planDesignID;
                        if (new_eligibilityrule.description != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][4] = new_eligibilityrule.description;
                        if (new_eligibilityrule.active != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][5] = new_eligibilityrule.active;
                        if (new_eligibilityrule.suffixNum != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][6] = new_eligibilityrule.suffixNum;
                        if (new_eligibilityrule.waiver != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][7] = new_eligibilityrule.waiver;
                        if (new_eligibilityrule.frozenEnrollment != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][8] = new_eligibilityrule.frozenEnrollment;
                        if (new_eligibilityrule.frozenEnrollmentEffectiveAsOf != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][9] = new_eligibilityrule.frozenEnrollmentEffectiveAsOf;
                        if (new_eligibilityrule.coverageEndDate != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][10] = new_eligibilityrule.coverageEndDate;
                        if (new_eligibilityrule.ageAsOf != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][11] = new_eligibilityrule.ageAsOf;
                        if (new_eligibilityrule.notes != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][12] = new_eligibilityrule.notes;
                        if (new_eligibilityrule.benefitSummaryID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][13] = new_eligibilityrule.benefitSummaryID;
                        if (new_eligibilityrule.rateID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][14] = new_eligibilityrule.rateID;
                        if (new_eligibilityrule.contributionID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][15] = new_eligibilityrule.contributionID;
                        if (new_eligibilityrule.Item != null)
                        {
                            //if (new_eligibilityrule.Item.ToString() == "BPBenefitSummary.BP_BrokerConnectV4.CustomWaitingPeriod")
                            if (new_eligibilityrule.Item.ToString() == "BenefitPointSummaryPortal.BP_BrokerConnectV4.CustomWaitingPeriod")
                            {
                                BP_BrokerConnectV4.CustomWaitingPeriod cwp = new BP_BrokerConnectV4.CustomWaitingPeriod();
                                cwp = (BP_BrokerConnectV4.CustomWaitingPeriod)new_eligibilityrule.Item;
                                eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = cwp.timeFrame.ToString().Replace("_", " ") + " " + cwp.value.ToString() + " " + cwp.unitOfMeasure.ToString();
                            }
                            else
                            {
                                eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = new_eligibilityrule.Item.ToString().Replace("_", " ");
                            }
                            eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = eligibilityrule_table.Rows[eligibilityrule_row_counter][23].ToString().Replace("DOH", "");
                        }

                        if (new_eligibilityrule.employeeEligibilityRule != null)
                        {
                            if (new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][16] = new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated;

                        }

                        if (new_eligibilityrule.dependentEligibilityRule != null)
                        {
                            if (new_eligibilityrule.dependentEligibilityRule.childCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][17] = new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit;
                            }

                            if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][18] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType.ToString().Replace("_", " ");
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][19] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified;
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][20] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation;

                            }

                            if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][21] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit;
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][22] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm;

                            }


                        }

                        eligibilityrule_row_counter++;

                        #endregion


                        if (new_eligibilityrule.employeeEligibilityRule != null)
                        {
                            #region employeeEligibilityRule

                            if (new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs != null)
                            {

                                foreach (BP_BrokerConnectV4.EmploymentType et in new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs)
                                {
                                    #region employeeTypeIDs_table
                                    employeeTypeIDs_table.Rows.Add();
                                    employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][0] = section;
                                    if (new_eligibilityrule.eligibilityRuleID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                                    if (new_eligibilityrule.productID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][2] = new_eligibilityrule.productID;
                                    if (et != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][3] = et;

                                    employeeTypeIDs_row_counter++;

                                    #endregion
                                }

                            }

                            #endregion
                        }

                    }


                }
                EligibilityDS.Tables.Add(eligibilityrule_table);
                EligibilityDS.Tables[0].TableName = "EligibilityRuleTable";
                EligibilityDS.Tables.Add(employeeTypeIDs_table);
                EligibilityDS.Tables[1].TableName = "EmployeeTypeIDsTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return EligibilityDS;
        }

        /// <summary>
        ///Get eligibility rule detail from  BP_BrokerConnectV4 web service using findEligibilityRules and getEligibilityRule webmethod. 
        ///</summary>
        ///<param name="PlanTable">Plan table contain selected plan.</param>
        ///<param name="SessionId">Session Id of Login User.</param>
        /// <returns>EligibilityRule Data</returns>
        public DataTable GetEligibilityRule_AccountProfile(DataTable PlanTable, string SessionId, int EleigibilityRuleId)//(int product_id, string section, int summary_id)
        {


            int eligibilityrule_row_counter = 0;
            int employeeTypeIDs_row_counter = 0;

            //Eligibility Rule
            DataTable eligibilityrule_tableAccountProfile = new DataTable();
            DataTable employeeTypeIDs_table = new DataTable();
            DataTable employeetype_table = new DataTable();
            DataSet EligibilityDS = new DataSet();
            eligibilityrule_tableAccountProfile.Columns.Add("section", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("eligibilityRuleID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("productID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("planDesignID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("description", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("active", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("suffixNum", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("waiver", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("frozenEnrollment", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("frozenEnrollmentEffectiveAsOf", typeof(DateTime));
            eligibilityrule_tableAccountProfile.Columns.Add("coverageEndDate", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("ageAsOf", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("notes", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("benefitSummaryID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("rateID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("contributionID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeEligibilityRule_nonHighlyCompensated", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerTypeSpecified", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_lengthOfCohabitation", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_ageLimit", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_minimumNumberOfUnitsPerTerm", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("item", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeTypeIDs", typeof(string));

            try
            {
                if (EleigibilityRuleId != 0)
                {
                    BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                    new_connection.Timeout = 14400000; //4hours
                    BP_BrokerConnectV4.EligibilityRuleSearchCriteria new_eligibilityrule_search = new BP_BrokerConnectV4.EligibilityRuleSearchCriteria();

                    string section = "Medical Plan";

                    BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                    SIH.sessionId = SessionId;// myloginresult.sessionID;
                    new_connection.SessionIdHeaderValue = SIH;

                    BP_BrokerConnectV4.EligibilityRule new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new_connection.getEligibilityRule(EleigibilityRuleId);

                    if (new_eligibilityrule != null)
                    {

                        #region eligibilityrule_tableAccountProfile

                        eligibilityrule_tableAccountProfile.Rows.Add();
                        //eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][0] = section;
                        if (new_eligibilityrule.eligibilityRuleID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                        if (new_eligibilityrule.productID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][2] = new_eligibilityrule.productID;
                        if (new_eligibilityrule.planDesignID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][3] = new_eligibilityrule.planDesignID;
                        if (new_eligibilityrule.description != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][4] = new_eligibilityrule.description;
                        if (new_eligibilityrule.active != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][5] = new_eligibilityrule.active;
                        if (new_eligibilityrule.suffixNum != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][6] = new_eligibilityrule.suffixNum;
                        if (new_eligibilityrule.waiver != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][7] = new_eligibilityrule.waiver;
                        if (new_eligibilityrule.frozenEnrollment != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][8] = new_eligibilityrule.frozenEnrollment;
                        if (new_eligibilityrule.frozenEnrollmentEffectiveAsOf != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][9] = new_eligibilityrule.frozenEnrollmentEffectiveAsOf;
                        if (new_eligibilityrule.coverageEndDate != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][10] = new_eligibilityrule.coverageEndDate;
                        if (new_eligibilityrule.ageAsOf != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][11] = new_eligibilityrule.ageAsOf;
                        if (new_eligibilityrule.notes != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][12] = new_eligibilityrule.notes;
                        if (new_eligibilityrule.benefitSummaryID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][13] = new_eligibilityrule.benefitSummaryID;
                        if (new_eligibilityrule.rateID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][14] = new_eligibilityrule.rateID;
                        if (new_eligibilityrule.contributionID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][15] = new_eligibilityrule.contributionID;
                        if (new_eligibilityrule.Item != null)
                        {
                            //if (new_eligibilityrule.Item.ToString() == "BPBenefitSummary.BP_BrokerConnectV4.CustomWaitingPeriod")
                            if (new_eligibilityrule.Item.ToString() == "BenefitPointSummaryPortal.BP_BrokerConnectV4.CustomWaitingPeriod")
                            {
                                BP_BrokerConnectV4.CustomWaitingPeriod cwp = new BP_BrokerConnectV4.CustomWaitingPeriod();
                                cwp = (BP_BrokerConnectV4.CustomWaitingPeriod)new_eligibilityrule.Item;
                                eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = cwp.timeFrame.ToString().Replace("_", " ") + " " + cwp.value.ToString() + " " + cwp.unitOfMeasure.ToString();
                            }
                            else
                            {
                                eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = new_eligibilityrule.Item.ToString().Replace("_", " ");
                            }
                            // eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23].ToString().Replace("DOH", "");
                        }

                        if (new_eligibilityrule.employeeEligibilityRule != null)
                        {
                            if (new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][16] = new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated;
                            if (new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][24] = new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs[0];


                        }

                        if (new_eligibilityrule.dependentEligibilityRule != null)
                        {
                            if (new_eligibilityrule.dependentEligibilityRule.childCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][17] = new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit;
                            }

                            if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][18] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType.ToString().Replace("_", " ");
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][19] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified;
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][20] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation;

                            }

                            if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][21] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit;
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][22] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm;

                            }


                        }

                        eligibilityrule_row_counter++;

                        #endregion


                        //if (new_eligibilityrule.employeeEligibilityRule != null)
                        //{
                        //    #region employeeEligibilityRule

                        //    if (new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs != null)
                        //    {

                        //        foreach (BP_BrokerConnectV4.EmploymentType et in new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs)
                        //        {
                        //            #region employeeTypeIDs_table
                        //            employeeTypeIDs_table.Rows.Add();
                        //            employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][0] = section;
                        //            if (new_eligibilityrule.eligibilityRuleID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                        //            if (new_eligibilityrule.productID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][2] = new_eligibilityrule.productID;
                        //            if (et != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][3] = et;

                        //            employeeTypeIDs_row_counter++;

                        //            #endregion
                        //        }

                        //    }

                        //    #endregion
                        //}

                    }


                }
                //EligibilityDS.Tables.Add(eligibilityrule_tableAccountProfile);
                //EligibilityDS.Tables[0].TableName = "EligibilityRuleTable";
                //EligibilityDS.Tables.Add(employeeTypeIDs_table);
                //EligibilityDS.Tables[1].TableName = "EmployeeTypeIDsTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return eligibilityrule_tableAccountProfile;
        }

        /// <summary>
        ///Get eligibility rule detail from  BP_BrokerConnectV4 web service using findEligibilityRules and getEligibilityRule webmethod. 
        ///</summary>
        ///<param name="PlanTable">Plan table contain selected plan.</param>
        ///<param name="SessionId">Session Id of Login User.</param>
        /// <returns>EligibilityRule Data</returns>
        public DataSet GetEligibilityRule_ContractReview(string section, string SessionId, int EleigibilityRuleId)//(int product_id, string section, int summary_id)
        {


            int eligibilityrule_row_counter = 0;
            int employeeTypeIDs_row_counter = 0;

            DataSet EligibilityDS = new DataSet();

            try
            {
                if (EleigibilityRuleId != 0)
                {
                    BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                    new_connection.Timeout = 14400000; //4hours
                    BP_BrokerConnectV4.EligibilityRuleSearchCriteria new_eligibilityrule_search = new BP_BrokerConnectV4.EligibilityRuleSearchCriteria();

                    // string section = "Medical Plan";

                    BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                    SIH.sessionId = SessionId;// myloginresult.sessionID;
                    new_connection.SessionIdHeaderValue = SIH;

                    BP_BrokerConnectV4.EligibilityRule new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new_connection.getEligibilityRule(EleigibilityRuleId);
                    if (new_eligibilityrule != null)
                    {

                        #region eligibilityrule_table

                        eligibilityrule_table.Rows.Add();
                        eligibilityrule_table.Rows[eligibilityrule_row_counter][0] = section;
                        if (new_eligibilityrule.eligibilityRuleID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                        if (new_eligibilityrule.productID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][2] = new_eligibilityrule.productID;
                        if (new_eligibilityrule.planDesignID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][3] = new_eligibilityrule.planDesignID;
                        if (new_eligibilityrule.description != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][4] = new_eligibilityrule.description;
                        if (new_eligibilityrule.active != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][5] = new_eligibilityrule.active;
                        if (new_eligibilityrule.suffixNum != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][6] = new_eligibilityrule.suffixNum;
                        if (new_eligibilityrule.waiver != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][7] = new_eligibilityrule.waiver;
                        if (new_eligibilityrule.frozenEnrollment != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][8] = new_eligibilityrule.frozenEnrollment;
                        if (new_eligibilityrule.frozenEnrollmentEffectiveAsOf != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][9] = new_eligibilityrule.frozenEnrollmentEffectiveAsOf;
                        if (new_eligibilityrule.coverageEndDate != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][10] = new_eligibilityrule.coverageEndDate;
                        if (new_eligibilityrule.ageAsOf != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][11] = new_eligibilityrule.ageAsOf;
                        if (new_eligibilityrule.notes != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][12] = new_eligibilityrule.notes;
                        if (new_eligibilityrule.benefitSummaryID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][13] = new_eligibilityrule.benefitSummaryID;
                        if (new_eligibilityrule.rateID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][14] = new_eligibilityrule.rateID;
                        if (new_eligibilityrule.contributionID != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][15] = new_eligibilityrule.contributionID;
                        if (new_eligibilityrule.Item != null)
                        {
                            //if (new_eligibilityrule.Item.ToString() == "BPBenefitSummary.BP_BrokerConnectV4.CustomWaitingPeriod")
                            if (new_eligibilityrule.Item.ToString() == "BenefitPointSummaryPortal.BP_BrokerConnectV4.CustomWaitingPeriod")
                            {
                                BP_BrokerConnectV4.CustomWaitingPeriod cwp = new BP_BrokerConnectV4.CustomWaitingPeriod();
                                cwp = (BP_BrokerConnectV4.CustomWaitingPeriod)new_eligibilityrule.Item;
                                eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = cwp.timeFrame.ToString().Replace("_", " ") + " " + cwp.value.ToString() + " " + cwp.unitOfMeasure.ToString();
                            }
                            else
                            {
                                eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = new_eligibilityrule.Item.ToString().Replace("_", " ");
                            }
                            eligibilityrule_table.Rows[eligibilityrule_row_counter][23] = eligibilityrule_table.Rows[eligibilityrule_row_counter][23].ToString().Replace("DOH", "");
                        }

                        if (new_eligibilityrule.employeeEligibilityRule != null)
                        {
                            if (new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][16] = new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated;

                        }

                        if (new_eligibilityrule.dependentEligibilityRule != null)
                        {
                            if (new_eligibilityrule.dependentEligibilityRule.childCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][17] = new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit;
                            }

                            if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][18] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType.ToString().Replace("_", " ");
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][19] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified;
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][20] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation;

                            }

                            if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][21] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit;
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm != null) eligibilityrule_table.Rows[eligibilityrule_row_counter][22] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm;

                            }


                        }

                        eligibilityrule_row_counter++;

                        #endregion

                        /*
                       if (new_eligibilityrule.employeeEligibilityRule != null)
                       {
                           #region employeeEligibilityRule

                           if (new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs != null)
                           {

                               foreach (BP_BrokerConnectV4.EmploymentType et in new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs)
                               {
                                   #region employeeTypeIDs_table
                                   employeeTypeIDs_table.Rows.Add();
                                   employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][0] = section;
                                   if (new_eligibilityrule.eligibilityRuleID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                                   if (new_eligibilityrule.productID != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][2] = new_eligibilityrule.productID;
                                   if (et != null) employeeTypeIDs_table.Rows[employeeTypeIDs_row_counter][3] = et;

                                   employeeTypeIDs_row_counter++;

                                   #endregion
                               }

                           }

                           #endregion
                       }*/

                    }


                }
                EligibilityDS.Tables.Add(eligibilityrule_table);
                EligibilityDS.Tables[0].TableName = "EligibilityRuleTable";
                //EligibilityDS.Tables.Add(employeeTypeIDs_table);
                //EligibilityDS.Tables[1].TableName = "EmployeeTypeIDsTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return EligibilityDS;
        }

        /// <summary>
        ///  Build Eligibility Rule Table.
        /// </summary>
        public void BuildEligibilityRuleTable()
        {
            try
            {
                #region eligibilityrule
                eligibilityrule_table.Columns.Add("section", typeof(string));
                eligibilityrule_table.Columns.Add("eligibilityRuleID", typeof(Int32));
                eligibilityrule_table.Columns.Add("productID", typeof(Int32));
                eligibilityrule_table.Columns.Add("planDesignID", typeof(Int32));
                eligibilityrule_table.Columns.Add("description", typeof(string));
                eligibilityrule_table.Columns.Add("active", typeof(bool));
                eligibilityrule_table.Columns.Add("suffixNum", typeof(string));
                eligibilityrule_table.Columns.Add("waiver", typeof(bool));
                eligibilityrule_table.Columns.Add("frozenEnrollment", typeof(bool));
                eligibilityrule_table.Columns.Add("frozenEnrollmentEffectiveAsOf", typeof(DateTime));
                eligibilityrule_table.Columns.Add("coverageEndDate", typeof(string));
                eligibilityrule_table.Columns.Add("ageAsOf", typeof(string));
                eligibilityrule_table.Columns.Add("notes", typeof(string));
                eligibilityrule_table.Columns.Add("benefitSummaryID", typeof(Int32));
                eligibilityrule_table.Columns.Add("rateID", typeof(Int32));
                eligibilityrule_table.Columns.Add("contributionID", typeof(Int32));
                eligibilityrule_table.Columns.Add("employeeEligibilityRule_nonHighlyCompensated", typeof(bool));
                eligibilityrule_table.Columns.Add("employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit", typeof(Int32));
                eligibilityrule_table.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType", typeof(string));
                eligibilityrule_table.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerTypeSpecified", typeof(string));
                eligibilityrule_table.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_lengthOfCohabitation", typeof(string));
                eligibilityrule_table.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_ageLimit", typeof(string));
                eligibilityrule_table.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_minimumNumberOfUnitsPerTerm", typeof(string));
                eligibilityrule_table.Columns.Add("item", typeof(string));



                employeeTypeIDs_table.Columns.Add("section", typeof(string));
                employeeTypeIDs_table.Columns.Add("eligibilityRuleID", typeof(Int32));
                employeeTypeIDs_table.Columns.Add("productID", typeof(Int32));
                employeeTypeIDs_table.Columns.Add("employeeEligibilityRule_employeeTypeIDs", typeof(Int32));



                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// Get rate detail from  BP_BrokerConnectV4 web service using getRate webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Rate Data</returns>
        public DataSet GetRate(DataTable PlanTable, string SessionId)
        {

            BP_BrokerConnectV4.Rate new_rate = new BP_BrokerConnectV4.Rate();

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId;// myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;

            DataSet RateDS = new DataSet();
            int rate_row_counter = 0;
            int benefitsummaryrate_row_counter = 0;

            int ratefieldvalue_row_counter = 0;
            int rateoptionvalue_row_counter = 0;

            try
            {
                foreach (DataRow drd in PlanTable.Rows)
                {
                    string section = drd["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(drd["SummaryId"].ToString());
                    int rateid = Convert.ToInt32(drd["RateId"].ToString());


                    new_rate = new BP_BrokerConnectV4.Rate();
                    if (rateid != -1)
                    {
                        new_rate = new_connection.getRate(rateid);
                    }

                    if (new_rate != null)
                    {

                        #region ratetable
                        rate_table.Rows.Add();
                        rate_table.Rows[rate_row_counter][0] = section;
                        if (new_rate.rateID != null) rate_table.Rows[rate_row_counter][1] = new_rate.rateID.ToString();
                        if (new_rate.productID != null) rate_table.Rows[rate_row_counter][2] = new_rate.productID.ToString();
                        if (new_rate.responseID != null) rate_table.Rows[rate_row_counter][3] = new_rate.responseID.ToString();
                        if (new_rate.description != null) rate_table.Rows[rate_row_counter][4] = new_rate.description.ToString();
                        if (new_rate.rateTypeID != null) rate_table.Rows[rate_row_counter][5] = new_rate.rateTypeID.ToString();
                        if (new_rate.rateTypeTierID != null) rate_table.Rows[rate_row_counter][6] = new_rate.rateTypeTierID.ToString();
                        if (new_rate.effectiveAsOf != null) rate_table.Rows[rate_row_counter][7] = new_rate.effectiveAsOf.ToString();
                        if (new_rate.expirationOn != null) rate_table.Rows[rate_row_counter][8] = new_rate.expirationOn.ToString();
                        if (new_rate.includeEE != null) rate_table.Rows[rate_row_counter][9] = new_rate.includeEE.ToString();
                        if (new_rate.ageBanded != null) rate_table.Rows[rate_row_counter][10] = new_rate.ageBanded.ToString();
                        if (new_rate.ageBandedStartOn != null) rate_table.Rows[rate_row_counter][11] = new_rate.ageBandedStartOn.ToString();
                        if (new_rate.ageBandedEndOn != null) rate_table.Rows[rate_row_counter][12] = new_rate.ageBandedEndOn.ToString();
                        if (new_rate.ageBandedInterval != null) rate_table.Rows[rate_row_counter][13] = new_rate.ageBandedInterval.ToString();
                        if (new_rate.ageBandedGenderSpecific != null) rate_table.Rows[rate_row_counter][14] = new_rate.ageBandedGenderSpecific.ToString();
                        if (new_rate.ratingMethod != null) rate_table.Rows[rate_row_counter][15] = new_rate.ratingMethod.ToString();
                        if (new_rate.estimatedMonthlyPremium != null) rate_table.Rows[rate_row_counter][16] = new_rate.estimatedMonthlyPremium.ToString();
                        if (new_rate.estimatedMonthlyRevenue != null) rate_table.Rows[rate_row_counter][17] = new_rate.estimatedMonthlyRevenue.ToString();
                        if (new_rate.additionalInfo != null) rate_table.Rows[rate_row_counter][18] = new_rate.additionalInfo.ToString();
                        if (new_rate.rateGuarantee != null) rate_table.Rows[rate_row_counter][19] = new_rate.rateGuarantee.ToString();
                        if (new_rate.rateGuaranteeUOM != null) rate_table.Rows[rate_row_counter][20] = new_rate.rateGuaranteeUOM.ToString();
                        if (new_rate.numberOfLivesAsOf != null) rate_table.Rows[rate_row_counter][21] = new_rate.numberOfLivesAsOf.ToString();
                        if (new_rate.paymentCycle != null) rate_table.Rows[rate_row_counter][22] = new_rate.paymentCycle.ToString();
                        if (new_rate.renewalPercentageChange != null) rate_table.Rows[rate_row_counter][23] = new_rate.renewalPercentageChange.ToString();
                        if (new_rate.lastModifiedOn != null) rate_table.Rows[rate_row_counter][24] = new_rate.lastModifiedOn.ToString();
                        if (new_rate.createdOn != null) rate_table.Rows[rate_row_counter][25] = new_rate.createdOn.ToString();

                        #endregion

                        #region beniftssummaryratetable
                        if (new_rate.associatedBenefitSummaries != null)
                        {
                            foreach (BP_BrokerConnectV4.BenefitSummaryDescription bsd in new_rate.associatedBenefitSummaries)
                            {
                                if (bsd.benefitSummaryID == summary_id)
                                {
                                    benefitsummaryrate_table.Rows.Add();
                                    benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][0] = section;
                                    if (new_rate.rateID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][1] = new_rate.rateID.ToString();
                                    if (bsd.benefitSummaryID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][2] = bsd.benefitSummaryID.ToString();
                                    if (bsd.description != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][3] = bsd.description.ToString();
                                    benefitsummaryrate_row_counter++;

                                }
                            }

                        }
                        #endregion


                        if (new_rate.rateFieldValues != null)
                        {
                            foreach (BP_BrokerConnectV4.RateFieldValue rfv in new_rate.rateFieldValues)
                            {

                                #region ratefield_table
                                ratefieldvalue_table.Rows.Add();
                                ratefieldvalue_table.Rows[ratefieldvalue_row_counter][0] = section;
                                if (new_rate.rateID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][1] = new_rate.rateID.ToString();
                                if (rfv.rateFieldValueID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][2] = rfv.rateFieldValueID.ToString();
                                if (rfv.rateField.rateFieldID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][3] = rfv.rateField.rateFieldID.ToString();
                                if (rfv.rateField.label != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][4] = rfv.rateField.label.ToString();
                                if (rfv.rateField.fieldType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][5] = rfv.rateField.fieldType.ToString();
                                if (rfv.rateField.fieldValueType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][6] = rfv.rateField.fieldValueType.ToString();

                                if (rfv.multiValueIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][7] = rfv.multiValueIndex.ToString();

                                // Added decimal condition (01 Sept 2016) - Vaibhav Raut: For checking if the value is having only 1 digit after decimal point, if only 1 digit is available then format it upto 2 digits after decimal point
                                if (!string.IsNullOrEmpty(Convert.ToString(rfv.valueNum)))
                                {
                                    if (rfv.valueNum.ToString().Substring(rfv.valueNum.ToString().IndexOf(".") + 1).Length == 1)
                                    {
                                        if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = String.Format("{0:0.00}", Convert.ToDecimal(rfv.valueNum.ToString()));
                                    }
                                    else
                                    {
                                        if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = Convert.ToDecimal(rfv.valueNum.ToString());
                                    }
                                }
                                if (rfv.valueText != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][9] = rfv.valueText.ToString();



                                if (rfv.rateTier != null)
                                {

                                    if (rfv.rateTier.rateTierID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][10] = rfv.rateTier.rateTierID.ToString();
                                    // Replacing "EE" with Employee for all the templates for rate 
                                    if (rfv.rateTier.description.ToString() == "EE")
                                    {
                                        if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString().Replace("EE", "Employee");
                                    }
                                    else
                                    {


                                        if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString();

                                    }
                                    if (rfv.rateTier.allowIncludeEE != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][12] = rfv.rateTier.allowIncludeEE.ToString();
                                }
                                else
                                {
                                    if (rfv.rateField.rateFieldGroup.description.ToString().Trim() == "Dependent Child Life")
                                    {
                                        ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = "Dependent Child Life";
                                    }



                                }

                                if (rfv.ageBandIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][13] = rfv.ageBandIndex.ToString();
                                if (rfv.ageBandGender != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][14] = rfv.ageBandGender.ToString();
                                ratefieldvalue_table.Rows[ratefieldvalue_row_counter][15] = summary_id;

                                #endregion

                                #region ratefieldoption_table
                                if (rfv.rateField.optionValues != null)
                                {
                                    foreach (BP_BrokerConnectV4.RateOptionValue rov in rfv.rateField.optionValues)
                                    {
                                        rateoptionvalue_table.Rows.Add();
                                        rateoptionvalue_table.Rows[rateoptionvalue_row_counter][0] = section;
                                        if (new_rate.rateID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][1] = new_rate.rateID.ToString();
                                        if (rov.rateOptionValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][2] = rov.rateOptionValueID.ToString();
                                        if (rov.description != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][3] = rov.description.ToString();
                                        if (rfv.rateFieldValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][4] = rfv.rateFieldValueID.ToString();
                                        rateoptionvalue_row_counter++;

                                    }
                                }
                                #endregion

                                ratefieldvalue_row_counter++;
                            }

                        }
                        rate_row_counter++;

                    }
                }

                RateDS.Tables.Add(rateoptionvalue_table);
                RateDS.Tables[0].TableName = "RateOptionValueTable";
                RateDS.Tables.Add(ratefieldvalue_table);
                RateDS.Tables[1].TableName = "RateFieldValueTable";
                RateDS.Tables.Add(benefitsummaryrate_table);
                RateDS.Tables[2].TableName = "BenefitSummaryRateTable";
                RateDS.Tables.Add(rate_table);
                RateDS.Tables[3].TableName = "RateTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return RateDS;

        }

        /// <summary>
        /// Get rate detail from  BP_BrokerConnectV4 web service using getRate webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Rate Data</returns>
        public DataSet GetRateForTools(DataTable PlanTable, string SessionId)
        {

            BP_BrokerConnectV4.RateSummary[] new_rate_Summary = new BP_BrokerConnectV4.RateSummary[10];
            BP_BrokerConnectV4.Rate new_rate = null;
            BP_BrokerConnectV4.RateType[] rate_funding = null;

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.RateSearchCriteria rateSearchCritria = new BP_BrokerConnectV4.RateSearchCriteria();

            SIH.sessionId = SessionId;// myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;

            DataSet RateDS = new DataSet();
            int rate_row_counter = 0;
            int benefitsummaryrate_row_counter = 0;

            int ratefieldvalue_row_counter = 0;
            int rateoptionvalue_row_counter = 0;
            int rateid = 0;

            try
            {
                BuildRateTable();

                foreach (DataRow drd in PlanTable.Rows)
                {
                    string section = drd["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(drd["SummaryId"].ToString());
                    //int rateid = Convert.ToInt32(drd["RateId"].ToString());
                    int productId = Convert.ToInt32(drd["ProductId"].ToString());

                    // new_rate = new BP_BrokerConnectV4.RateSummary();
                    //if (rateid != -1)
                    //{

                    rateSearchCritria.productID = productId;
                    rateSearchCritria.productIDSpecified = true;

                    new_rate_Summary = new_connection.findRates(rateSearchCritria);


                    //}
                    if (new_rate_Summary != null)
                    {
                        for (int j = 0; j < new_rate_Summary.Count(); j++)
                        {
                            // Check for the associated benefit summary, because the rates are to be deisplayed based on the associated benefit summary_id
                            if (new_rate_Summary[j].associatedBenefitSummaries != null && new_rate_Summary[j].associatedBenefitSummaries.Count() > 0)
                            {
                                for (int k = 0; k < new_rate_Summary[j].associatedBenefitSummaries.Count(); k++)
                                {
                                    if (summary_id == Convert.ToInt32(new_rate_Summary[j].associatedBenefitSummaries[k].benefitSummaryID))
                                    {

                                        rateid = Convert.ToInt32(new_rate_Summary[j].rateID);

                                        //DataRow[] drRate = rate_table.Select("rateID = '" + rateid + "'");
                                        //if (drRate.Length == 0)
                                        //{
                                        // do something...

                                        new_rate = new BP_BrokerConnectV4.Rate();
                                        try
                                        {
                                            if (rateid != -1)
                                            {
                                                new_rate = new_connection.getRate(rateid);
                                                rate_funding = new_connection.getRateTypes();  //Sanchari rate funding
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                        }

                                        if (new_rate != null)
                                        {

                                            #region ratetable

                                            rate_table.Rows.Add();
                                            rate_table.Rows[rate_row_counter][0] = section;
                                            if (new_rate.rateID != null) rate_table.Rows[rate_row_counter][1] = new_rate.rateID.ToString();
                                            if (new_rate.productID != null) rate_table.Rows[rate_row_counter][2] = new_rate.productID.ToString();
                                            if (new_rate.responseID != null) rate_table.Rows[rate_row_counter][3] = new_rate.responseID.ToString();
                                            if (new_rate.description != null) rate_table.Rows[rate_row_counter][4] = new_rate.description.ToString();
                                            if (new_rate.rateTypeID != null) rate_table.Rows[rate_row_counter][5] = new_rate.rateTypeID.ToString();
                                            if (new_rate.rateTypeTierID != null) rate_table.Rows[rate_row_counter][6] = new_rate.rateTypeTierID.ToString();
                                            if (new_rate.effectiveAsOf != null) rate_table.Rows[rate_row_counter][7] = new_rate.effectiveAsOf.ToString();
                                            if (new_rate.expirationOn != null) rate_table.Rows[rate_row_counter][8] = new_rate.expirationOn.ToString();
                                            if (new_rate.includeEE != null) rate_table.Rows[rate_row_counter][9] = new_rate.includeEE.ToString();
                                            if (new_rate.ageBanded != null) rate_table.Rows[rate_row_counter][10] = new_rate.ageBanded.ToString();
                                            if (new_rate.ageBandedStartOn != null) rate_table.Rows[rate_row_counter][11] = new_rate.ageBandedStartOn.ToString();
                                            if (new_rate.ageBandedEndOn != null) rate_table.Rows[rate_row_counter][12] = new_rate.ageBandedEndOn.ToString();
                                            if (new_rate.ageBandedInterval != null) rate_table.Rows[rate_row_counter][13] = new_rate.ageBandedInterval.ToString();
                                            if (new_rate.ageBandedGenderSpecific != null) rate_table.Rows[rate_row_counter][14] = new_rate.ageBandedGenderSpecific.ToString();
                                            if (new_rate.ratingMethod != null) rate_table.Rows[rate_row_counter][15] = new_rate.ratingMethod.ToString();
                                            if (new_rate.estimatedMonthlyPremium != null) rate_table.Rows[rate_row_counter][16] = new_rate.estimatedMonthlyPremium.ToString();
                                            if (new_rate.estimatedMonthlyRevenue != null) rate_table.Rows[rate_row_counter][17] = new_rate.estimatedMonthlyRevenue.ToString();
                                            if (new_rate.additionalInfo != null) rate_table.Rows[rate_row_counter][18] = new_rate.additionalInfo.ToString();
                                            if (new_rate.rateGuarantee != null) rate_table.Rows[rate_row_counter][19] = new_rate.rateGuarantee.ToString();
                                            if (new_rate.rateGuaranteeUOM != null) rate_table.Rows[rate_row_counter][20] = new_rate.rateGuaranteeUOM.ToString();
                                            if (new_rate.numberOfLivesAsOf != null) rate_table.Rows[rate_row_counter][21] = new_rate.numberOfLivesAsOf.ToString();
                                            if (new_rate.paymentCycle != null) rate_table.Rows[rate_row_counter][22] = new_rate.paymentCycle.ToString();
                                            if (new_rate.renewalPercentageChange != null) rate_table.Rows[rate_row_counter][23] = new_rate.renewalPercentageChange.ToString();
                                            if (new_rate.lastModifiedOn != null) rate_table.Rows[rate_row_counter][24] = new_rate.lastModifiedOn.ToString();
                                            if (new_rate.createdOn != null) rate_table.Rows[rate_row_counter][25] = new_rate.createdOn.ToString();
                                            //rate_table.Rows[rate_row_counter][26] = "";

                                            //Sanchari rate funding
                                            if (rate_funding != null)
                                            {
                                                for (int z = 0; z < rate_funding.Count(); z++)
                                                {
                                                    if (new_rate.rateTypeID != null)
                                                    {
                                                        if (rate_funding[z].rateTypeID.ToString() == new_rate.rateTypeID.ToString())
                                                        {
                                                            rate_table.Rows[rate_row_counter][26] = rate_funding[z].fundingType.ToString();
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            //Sanchari rate funding

                                            #endregion

                                            #region beniftssummaryratetable
                                            if (new_rate.associatedBenefitSummaries != null)
                                            {
                                                foreach (BP_BrokerConnectV4.BenefitSummaryDescription bsd in new_rate.associatedBenefitSummaries)
                                                {
                                                    if (bsd.benefitSummaryID == summary_id)
                                                    {
                                                        benefitsummaryrate_table.Rows.Add();
                                                        benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][0] = section;
                                                        if (new_rate.rateID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][1] = new_rate.rateID.ToString();
                                                        if (bsd.benefitSummaryID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][2] = bsd.benefitSummaryID.ToString();
                                                        if (bsd.description != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][3] = bsd.description.ToString();
                                                        benefitsummaryrate_row_counter++;

                                                    }
                                                }

                                            }
                                            #endregion


                                            if (new_rate.rateFieldValues != null)
                                            {
                                                foreach (BP_BrokerConnectV4.RateFieldValue rfv in new_rate.rateFieldValues)
                                                {

                                                    #region ratefield_table
                                                    ratefieldvalue_table.Rows.Add();
                                                    ratefieldvalue_table.Rows[ratefieldvalue_row_counter][0] = section;
                                                    if (new_rate.rateID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][1] = new_rate.rateID.ToString();
                                                    if (rfv.rateFieldValueID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][2] = rfv.rateFieldValueID.ToString();
                                                    if (rfv.rateField.rateFieldID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][3] = rfv.rateField.rateFieldID.ToString();
                                                    if (rfv.rateField.label != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][4] = rfv.rateField.label.ToString();
                                                    if (rfv.rateField.fieldType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][5] = rfv.rateField.fieldType.ToString();
                                                    if (rfv.rateField.fieldValueType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][6] = rfv.rateField.fieldValueType.ToString();

                                                    if (rfv.multiValueIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][7] = rfv.multiValueIndex.ToString();

                                                    // Added decimal condition (01 Sept 2016) - Vaibhav Raut: For checking if the value is having only 1 digit after decimal point, if only 1 digit is available then format it upto 2 digits after decimal point
                                                    if (!string.IsNullOrEmpty(Convert.ToString(rfv.valueNum)))
                                                    {
                                                        if (rfv.valueNum.ToString().Substring(rfv.valueNum.ToString().IndexOf(".") + 1).Length == 1)
                                                        {
                                                            if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = String.Format("{0:0.00}", Convert.ToDecimal(rfv.valueNum.ToString()));
                                                        }
                                                        else
                                                        {
                                                            if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = Convert.ToDecimal(rfv.valueNum.ToString());
                                                        }
                                                    }
                                                    if (rfv.valueText != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][9] = rfv.valueText.ToString();



                                                    if (rfv.rateTier != null)
                                                    {

                                                        if (rfv.rateTier.rateTierID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][10] = rfv.rateTier.rateTierID.ToString();
                                                        // Replacing "EE" with Employee for all the templates for rate 
                                                        if (rfv.rateTier.description.ToString() == "EE")
                                                        {
                                                            if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString().Replace("EE", "Employee");
                                                        }
                                                        else
                                                        {


                                                            if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString();

                                                        }
                                                        if (rfv.rateTier.allowIncludeEE != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][12] = rfv.rateTier.allowIncludeEE.ToString();
                                                    }
                                                    else
                                                    {
                                                        if (rfv.rateField.rateFieldGroup.description.ToString().Trim() == "Dependent Child Life")
                                                        {
                                                            ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = "Dependent Child Life";
                                                        }



                                                    }

                                                    if (rfv.ageBandIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][13] = rfv.ageBandIndex.ToString();
                                                    if (rfv.ageBandGender != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][14] = rfv.ageBandGender.ToString();
                                                    ratefieldvalue_table.Rows[ratefieldvalue_row_counter][15] = summary_id;

                                                    #endregion

                                                    #region ratefieldoption_table
                                                    if (rfv.rateField.optionValues != null)
                                                    {
                                                        foreach (BP_BrokerConnectV4.RateOptionValue rov in rfv.rateField.optionValues)
                                                        {
                                                            rateoptionvalue_table.Rows.Add();
                                                            rateoptionvalue_table.Rows[rateoptionvalue_row_counter][0] = section;
                                                            if (new_rate.rateID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][1] = new_rate.rateID.ToString();
                                                            if (rov.rateOptionValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][2] = rov.rateOptionValueID.ToString();
                                                            if (rov.description != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][3] = rov.description.ToString();
                                                            if (rfv.rateFieldValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][4] = rfv.rateFieldValueID.ToString();
                                                            rateoptionvalue_row_counter++;

                                                        }
                                                    }
                                                    #endregion

                                                    ratefieldvalue_row_counter++;
                                                }

                                            }
                                            rate_row_counter++;

                                            //}
                                        }


                                    }
                                }
                            }
                        }
                    }
                }

                RateDS.Tables.Add(rateoptionvalue_table);
                RateDS.Tables[0].TableName = "RateOptionValueTable";
                RateDS.Tables.Add(ratefieldvalue_table);
                RateDS.Tables[1].TableName = "RateFieldValueTable";
                RateDS.Tables.Add(benefitsummaryrate_table);
                RateDS.Tables[2].TableName = "BenefitSummaryRateTable";
                RateDS.Tables.Add(rate_table);
                RateDS.Tables[3].TableName = "RateTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return RateDS;

        }

        /// <summary>
        /// Build Rate Table.
        /// </summary>
        public void BuildRateTable()
        {
            try
            {
                #region rate
                ratesummary_table.Columns.Add("section", typeof(string));
                ratesummary_table.Columns.Add("rateID", typeof(Int32));
                ratesummary_table.Columns.Add("description", typeof(string));
                ratesummary_table.Columns.Add("effectiveAsOf", typeof(DateTime));
                ratesummary_table.Columns.Add("expirationOn", typeof(DateTime));
                ratesummary_table.Columns.Add("annualizedPremium", typeof(decimal));
                ratesummary_table.Columns.Add("annualizedRevenue", typeof(decimal));
                ratesummary_table.Columns.Add("productID", typeof(Int32));

                associatedBenefitSummaries_table.Columns.Add("section", typeof(string));
                associatedBenefitSummaries_table.Columns.Add("rateID", typeof(Int32));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_benefitSummaryID", typeof(Int32));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_description", typeof(string));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_productID", typeof(Int32));




                rate_table.Columns.Add("section", typeof(string));
                rate_table.Columns.Add("rateID", typeof(Int32));
                rate_table.Columns.Add("productID", typeof(Int32));
                rate_table.Columns.Add("responseID", typeof(Int32));
                rate_table.Columns.Add("description", typeof(string));
                rate_table.Columns.Add("rateTypeID", typeof(Int32));
                rate_table.Columns.Add("rateTypeTierID", typeof(Int32));
                rate_table.Columns.Add("effectiveAsOf", typeof(DateTime));
                rate_table.Columns.Add("expirationOn", typeof(DateTime));
                rate_table.Columns.Add("includeEE", typeof(bool));
                rate_table.Columns.Add("ageBanded", typeof(bool));
                rate_table.Columns.Add("ageBandedStartOn", typeof(Int32));  // Row 10
                rate_table.Columns.Add("ageBandedEndOn", typeof(Int32));  // Row 11
                rate_table.Columns.Add("ageBandedInterval", typeof(Int32));  // Row 12
                rate_table.Columns.Add("ageBandedGenderSpecific", typeof(bool));  // Row 13
                rate_table.Columns.Add("ratingMethod", typeof(string));  // Row 14
                rate_table.Columns.Add("estimatedMonthlyPremium", typeof(double));  // Row 15
                rate_table.Columns.Add("estimatedMonthlyRevenue", typeof(double));  // Row 16
                rate_table.Columns.Add("additionalInfo", typeof(string));  // Row 17
                rate_table.Columns.Add("rateGuarantee", typeof(Int32));  // Row 18
                rate_table.Columns.Add("rateGuaranteeUOM", typeof(string));  // Row 19
                rate_table.Columns.Add("numberOfLivesAsOf", typeof(DateTime));  // Row 20
                rate_table.Columns.Add("paymentCycle", typeof(Int32));  // Row 21
                rate_table.Columns.Add("renewalPercentageChange", typeof(double));  // Row 22
                rate_table.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 23
                rate_table.Columns.Add("createdOn", typeof(DateTime));  // Row 24
                rate_table.Columns.Add("FundingType", typeof(string));  //Row 25 //Sanchari rate funding

                //Added for Client Revenue Summary
                rate_table_revenue.Columns.Add("section", typeof(string));
                rate_table_revenue.Columns.Add("rateID", typeof(Int32));
                rate_table_revenue.Columns.Add("productID", typeof(Int32));
                rate_table_revenue.Columns.Add("responseID", typeof(Int32));
                rate_table_revenue.Columns.Add("description", typeof(string));
                rate_table_revenue.Columns.Add("rateTypeID", typeof(Int32));
                rate_table_revenue.Columns.Add("rateTypeTierID", typeof(Int32));
                rate_table_revenue.Columns.Add("effectiveAsOf", typeof(DateTime));
                rate_table_revenue.Columns.Add("expirationOn", typeof(DateTime));
                rate_table_revenue.Columns.Add("includeEE", typeof(bool));
                rate_table_revenue.Columns.Add("ageBanded", typeof(bool));
                rate_table_revenue.Columns.Add("ageBandedStartOn", typeof(Int32));  // Row 10
                rate_table_revenue.Columns.Add("ageBandedEndOn", typeof(Int32));  // Row 11
                rate_table_revenue.Columns.Add("ageBandedInterval", typeof(Int32));  // Row 12
                rate_table_revenue.Columns.Add("ageBandedGenderSpecific", typeof(bool));  // Row 13
                rate_table_revenue.Columns.Add("ratingMethod", typeof(string));  // Row 14
                rate_table_revenue.Columns.Add("estimatedMonthlyPremium", typeof(double));  // Row 15
                rate_table_revenue.Columns.Add("estimatedMonthlyRevenue", typeof(double));  // Row 16
                rate_table_revenue.Columns.Add("additionalInfo", typeof(string));  // Row 17
                rate_table_revenue.Columns.Add("rateGuarantee", typeof(Int32));  // Row 18
                rate_table_revenue.Columns.Add("rateGuaranteeUOM", typeof(string));  // Row 19
                rate_table_revenue.Columns.Add("numberOfLivesAsOf", typeof(DateTime));  // Row 20
                rate_table_revenue.Columns.Add("paymentCycle", typeof(Int32));  // Row 21
                rate_table_revenue.Columns.Add("renewalPercentageChange", typeof(double));  // Row 22
                rate_table_revenue.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 23
                rate_table_revenue.Columns.Add("createdOn", typeof(DateTime));  // Row 24
                rate_table_revenue.Columns.Add("FundingType", typeof(string));  //Row 25 
                rate_table_revenue.Columns.Add("CommissionType", typeof(string));  //Row 26 Sanchari commission type

                //End

                benefitsummaryrate_table.Columns.Add("section", typeof(string));
                benefitsummaryrate_table.Columns.Add("rateID", typeof(Int32));
                benefitsummaryrate_table.Columns.Add("associatedBenefitSummaries_benefitSummaryID", typeof(Int32));
                benefitsummaryrate_table.Columns.Add("associatedBenefitSummaries_description", typeof(string));



                ratefieldvalue_table.Columns.Add("section", typeof(string));
                ratefieldvalue_table.Columns.Add("rateID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateFieldValueID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_rateFieldID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_label", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_fieldType", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_fieldValueType", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_multiValueIndex", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_valueNum", typeof(decimal));
                ratefieldvalue_table.Columns.Add("rateFieldValues_valueText", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_rateTierID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_description", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_allowIncludeEE", typeof(bool));
                ratefieldvalue_table.Columns.Add("rateFieldValues_ageBandIndex", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_ageBandGender", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_summaryID", typeof(Int32));


                rateoptionvalue_table.Columns.Add("section", typeof(string));
                rateoptionvalue_table.Columns.Add("rateID", typeof(Int32));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateField_optionValues_rateOptionValueID", typeof(Int32));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateField_optionValues_description", typeof(string));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateFieldValueID", typeof(Int32));


                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// Get Contribution detail from  BP_BrokerConnectV4 web service using getContribution webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Contribution Data/returns>
        public DataSet GetContribution(DataTable PlanTable, string SessionId)
        {
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours


            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.Contribution new_contribution = new BP_BrokerConnectV4.Contribution();
            BP_BrokerConnectV4.ContributionStructure css = new BP_BrokerConnectV4.ContributionStructure();
            BP_BrokerConnectV4.RateTierSchedule[] rts = null;

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            DataSet ContributionDS = new DataSet();
            //int plan_type_temp = 0;
            int contrbution_Number = 1;
            int SummaryID = 0;
            List<Contribution> lstContri = new List<Contribution>();
            Contribution contribution = new Contribution();

            try
            {
                foreach (DataRow dcr in PlanTable.Rows)
                {

                    int product_id = Convert.ToInt32(dcr["ProductId"].ToString());
                    if (string.IsNullOrEmpty(dcr["SummaryID"].ToString()))
                    {
                        SummaryID = Convert.ToInt32(dcr["SummaryID"].ToString());
                    }
                    new_product = new_connection.getProduct(product_id);

                    //if (new_product.productTypeID != null)
                    //{
                    //    plan_type_temp = new_product.productTypeID;
                    //}

                    //string section = dcr["PlanType"].ToString();
                    //int summary_id = Convert.ToInt32(dcr["SummaryId"].ToString());
                    //int ContributionId = Convert.ToInt32(dcr["ContributionId"].ToString());
                    //int ContributionId_2 = Convert.ToInt32(dcr["ContributionId_2"].ToString());
                    //int ratetierid = 0;

                    contribution = new Contribution();
                    contribution.ContributionId = Convert.ToInt32(dcr["ContributionId"].ToString());
                    contribution.ContributionPlanName = dcr["PlanType"].ToString();
                    contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                    if (new_product.productTypeID != null)
                    {
                        contribution.PlanType = new_product.productTypeID;
                    }
                    lstContri.Add(contribution);

                    contribution = new Contribution();
                    if (!string.IsNullOrEmpty(dcr["ContributionId_2"].ToString().Trim()))
                    {
                        contribution.ContributionId = Convert.ToInt32(dcr["ContributionId_2"].ToString());
                    }
                    contribution.ContributionPlanName = dcr["PlanType"].ToString();
                    contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                    if (new_product.productTypeID != null)
                    {
                        contribution.PlanType = new_product.productTypeID;
                    }
                    lstContri.Add(contribution);
                }


                #region contribution_summary
                foreach (var item in lstContri)
                {
                    if (item.ContributionId > 0)
                    {
                        new_contribution = new BP_BrokerConnectV4.Contribution();
                        if (item.ContributionId != -1)
                        {
                            new_contribution = new_connection.getContribution(item.ContributionId);
                            css = new_connection.getContributionStructure(item.PlanType);
                            rts = css.contributionTierSchedules;
                        }

                        #region contribution_table

                        contribution_table.Rows.Add();

                        contribution_table.Rows[contribution_row_counter][0] = item.ContributionPlanName;
                        contribution_table.Rows[contribution_row_counter][1] = new_contribution.contributionID;
                        if (new_contribution.productID != null) contribution_table.Rows[contribution_row_counter][2] = new_contribution.productID;
                        if (new_contribution.planDesignID != null) contribution_table.Rows[contribution_row_counter][3] = new_contribution.planDesignID;
                        if (new_contribution.description != null) contribution_table.Rows[contribution_row_counter][4] = new_contribution.description;
                        if (new_contribution.rateTierScheduleID != null) contribution_table.Rows[contribution_row_counter][5] = new_contribution.rateTierScheduleID;
                        if (new_contribution.includeEE != null && new_contribution.includeEE.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][6] = new_contribution.includeEE;
                        if (new_contribution.partOfDefinedContributionOrFlexCredit != null && new_contribution.partOfDefinedContributionOrFlexCredit.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][7] = new_contribution.partOfDefinedContributionOrFlexCredit;
                        if (new_contribution.employeeContribution != null && new_contribution.employeeContribution.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][8] = new_contribution.employeeContribution;
                        if (new_contribution.contributionFrequency != null) contribution_table.Rows[contribution_row_counter][9] = new_contribution.contributionFrequency;
                        if (new_contribution.preTax != null && new_contribution.preTax.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][10] = new_contribution.preTax;
                        if (new_contribution.applyToMultiplePlans != null && new_contribution.applyToMultiplePlans.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][11] = new_contribution.applyToMultiplePlans;
                        if (new_contribution.eeContributesLesser != null && new_contribution.eeContributesLesser.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][12] = new_contribution.eeContributesLesser;
                        if (new_contribution.percentEligibleCompensation != null) contribution_table.Rows[contribution_row_counter][13] = new_contribution.percentEligibleCompensation;
                        if (new_contribution.additionalInformation != null) contribution_table.Rows[contribution_row_counter][14] = new_contribution.additionalInformation;
                        if (new_contribution.lastModifiedOn != null && new_contribution.lastModifiedOn.Year != 1) contribution_table.Rows[contribution_row_counter][15] = new_contribution.lastModifiedOn;
                        contribution_table.Rows[contribution_row_counter][16] = item.PlanNumber;


                        contribution_row_counter++;


                        #endregion

                        bool isratetierid = false;
                        if (new_contribution.contributionValues != null)
                        {
                            foreach (BP_BrokerConnectV4.ContributionValue cv in new_contribution.contributionValues)
                            {
                                #region contributionvalue_table
                                contributionvalue_table.Rows.Add();
                                contributionvalue_table.Rows[contributionvalue_row_counter][0] = item.ContributionPlanName;
                                contributionvalue_table.Rows[contributionvalue_row_counter][1] = new_contribution.description;
                                contributionvalue_table.Rows[contributionvalue_row_counter][2] = new_contribution.contributionFrequency;
                                contributionvalue_table.Rows[contributionvalue_row_counter][3] = new_contribution.contributionID;
                                contributionvalue_table.Rows[contributionvalue_row_counter][4] = cv.contributionValueID;
                                if (cv.rateTierID != null) contributionvalue_table.Rows[contributionvalue_row_counter][5] = cv.rateTierID;
                                if (cv.dollarAmount != null) contributionvalue_table.Rows[contributionvalue_row_counter][6] = String.Format("{0:0.00}", Convert.ToDecimal(cv.dollarAmount));
                                if (cv.percentOfPremium != null) contributionvalue_table.Rows[contributionvalue_row_counter][7] = cv.percentOfPremium;
                                if (cv.percentOfSalary != null) contributionvalue_table.Rows[contributionvalue_row_counter][8] = cv.percentOfSalary;
                                contributionvalue_table.Rows[contributionvalue_row_counter][10] = item.PlanNumber;
                                contributionvalue_table.Rows[contributionvalue_row_counter][11] = SummaryID;
                                contributionvalue_table.Rows[contributionvalue_row_counter][12] = false;
                                if (rts != null)
                                {
                                    for (int i = 0; i < rts.Count(); i++)
                                    {
                                        if (rts[i].rateTiers != null)
                                        {
                                            for (int j = 0; j < rts[i].rateTiers.Count(); j++)
                                            {
                                                if (cv.rateTierID == rts[i].rateTiers[j].rateTierID)
                                                {
                                                    // Replacing "EE" with Employee for all the templates for contribution 
                                                    if (rts[i].rateTiers[j].description == "EE")
                                                    {
                                                        contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description.Replace("EE", "Employee");
                                                    }
                                                    else
                                                    {
                                                        contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description;
                                                    }

                                                    if (rts[i].rateTiers[j].allowIncludeEE != null)
                                                    {
                                                        contributionvalue_table.Rows[contributionvalue_row_counter][12] = rts[i].rateTiers[j].allowIncludeEE;
                                                        if (rts[i].rateTiers[j].allowIncludeEE == true)
                                                            contributionvalue_table.Rows[contributionvalue_row_counter][13] = "Employee & " + rts[i].rateTiers[j].description;
                                                        else
                                                            contributionvalue_table.Rows[contributionvalue_row_counter][13] = rts[i].rateTiers[j].description;

                                                    }
                                                    else
                                                    {
                                                        contributionvalue_table.Rows[contributionvalue_row_counter][13] = rts[i].rateTiers[j].description;
                                                    }
                                                    isratetierid = true;
                                                    break;
                                                }

                                            }
                                        }
                                        if (isratetierid == true)
                                        {
                                            isratetierid = false;
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    contributionvalue_table.Rows[contributionvalue_row_counter][9] = "";
                                }

                                contributionvalue_row_counter++;

                                #endregion

                            }

                        }
                    }
                #endregion

                }

                ContributionDS.Tables.Add(contribution_table);
                ContributionDS.Tables[0].TableName = "ContributionTable";
                ContributionDS.Tables.Add(contributionvalue_table);
                ContributionDS.Tables[1].TableName = "ContributionValueTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return ContributionDS;

        }

        public DataSet GetContributionForTool(DataTable PlanTable, string SessionId)
        {
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours

            BP_BrokerConnectV4.ContributionSummary[] new_Contribution_Summary = new BP_BrokerConnectV4.ContributionSummary[10];
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();

            BP_BrokerConnectV4.Contribution new_contribution = new BP_BrokerConnectV4.Contribution();
            BP_BrokerConnectV4.ContributionStructure css = new BP_BrokerConnectV4.ContributionStructure();
            BP_BrokerConnectV4.RateTierSchedule[] rts = null;
            BP_BrokerConnectV4.ContributionSearchCriteria ContributionSearchCritria = new BP_BrokerConnectV4.ContributionSearchCriteria();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            DataSet ContributionDS = new DataSet();
            //int plan_type_temp = 0;
            int contrbution_Number = 1;


            int contributionid = 0; int SummaryID = 0;
            try
            {
                foreach (DataRow dcr in PlanTable.Rows)
                {
                    List<Contribution> lstContri = new List<Contribution>();
                    Contribution contribution = new Contribution();
                    int product_id = Convert.ToInt32(dcr["ProductId"].ToString());
                    new_product = new_connection.getProduct(product_id);
                    ContributionSearchCritria.productID = product_id;

                    ContributionSearchCritria.productIDSpecified = true;

                    new_Contribution_Summary = new_connection.findContributions(ContributionSearchCritria);

                    if (new_Contribution_Summary != null)
                    {
                        for (int k = 0; k < new_Contribution_Summary.Count(); k++)
                        {
                            contributionid = Convert.ToInt32(new_Contribution_Summary[k].contributionID);
                            if (!string.IsNullOrEmpty(dcr["SummaryID"].ToString()))
                            {
                                SummaryID = Convert.ToInt32(dcr["SummaryID"].ToString());
                            }
                            new_contribution = new BP_BrokerConnectV4.Contribution();
                            if (contributionid != -1)
                            {
                                new_contribution = new_connection.getContribution(contributionid);
                            }

                            if (new_contribution != null)
                            {


                            }
                            contribution = new Contribution();
                            contribution.ContributionId = contributionid;
                            contribution.ContributionPlanName = dcr["PlanType"].ToString();
                            contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                            if (new_product.productTypeID != null)
                            {
                                contribution.PlanType = new_product.productTypeID;
                            }
                            lstContri.Add(contribution);

                            //contribution = new Contribution();
                            //if (!string.IsNullOrEmpty(dcr["ContributionId_2"].ToString().Trim()))
                            //{
                            //    contribution.ContributionId = Convert.ToInt32(dcr["ContributionId_2"].ToString());
                            //}
                            //contribution.ContributionPlanName = dcr["PlanType"].ToString();
                            //contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                            //if (new_product.productTypeID != null)
                            //{
                            //    contribution.PlanType = new_product.productTypeID;
                            //}
                            //lstContri.Add(contribution);


                            #region contribution_summary
                            foreach (var item in lstContri)
                            {
                                if (item.ContributionId > 0)
                                {
                                    new_contribution = new BP_BrokerConnectV4.Contribution();
                                    if (item.ContributionId != -1)
                                    {
                                        new_contribution = new_connection.getContribution(item.ContributionId);
                                        css = new_connection.getContributionStructure(item.PlanType);
                                        rts = css.contributionTierSchedules;
                                    }

                                    #region contribution_table

                                    contribution_table.Rows.Add();

                                    contribution_table.Rows[contribution_row_counter][0] = item.ContributionPlanName;
                                    contribution_table.Rows[contribution_row_counter][1] = new_contribution.contributionID;
                                    if (new_contribution.productID != null) contribution_table.Rows[contribution_row_counter][2] = new_contribution.productID;
                                    if (new_contribution.planDesignID != null) contribution_table.Rows[contribution_row_counter][3] = new_contribution.planDesignID;
                                    if (new_contribution.description != null) contribution_table.Rows[contribution_row_counter][4] = new_contribution.description;
                                    if (new_contribution.rateTierScheduleID != null) contribution_table.Rows[contribution_row_counter][5] = new_contribution.rateTierScheduleID;
                                    if (new_contribution.includeEE != null && new_contribution.includeEE.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][6] = new_contribution.includeEE;
                                    if (new_contribution.partOfDefinedContributionOrFlexCredit != null && new_contribution.partOfDefinedContributionOrFlexCredit.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][7] = new_contribution.partOfDefinedContributionOrFlexCredit;
                                    if (new_contribution.employeeContribution != null && new_contribution.employeeContribution.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][8] = new_contribution.employeeContribution;
                                    if (new_contribution.contributionFrequency != null) contribution_table.Rows[contribution_row_counter][9] = new_contribution.contributionFrequency;
                                    if (new_contribution.preTax != null && new_contribution.preTax.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][10] = new_contribution.preTax;
                                    if (new_contribution.applyToMultiplePlans != null && new_contribution.applyToMultiplePlans.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][11] = new_contribution.applyToMultiplePlans;
                                    if (new_contribution.eeContributesLesser != null && new_contribution.eeContributesLesser.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][12] = new_contribution.eeContributesLesser;
                                    if (new_contribution.percentEligibleCompensation != null) contribution_table.Rows[contribution_row_counter][13] = new_contribution.percentEligibleCompensation;
                                    if (new_contribution.additionalInformation != null) contribution_table.Rows[contribution_row_counter][14] = new_contribution.additionalInformation;
                                    if (new_contribution.lastModifiedOn != null && new_contribution.lastModifiedOn.Year != 1) contribution_table.Rows[contribution_row_counter][15] = new_contribution.lastModifiedOn;
                                    contribution_table.Rows[contribution_row_counter][16] = item.PlanNumber;


                                    contribution_row_counter++;


                                    #endregion

                                    bool isratetierid = false;
                                    if (new_contribution.contributionValues != null)
                                    {
                                        foreach (BP_BrokerConnectV4.ContributionValue cv in new_contribution.contributionValues)
                                        {
                                            #region contributionvalue_table
                                            contributionvalue_table.Rows.Add();
                                            contributionvalue_table.Rows[contributionvalue_row_counter][0] = item.ContributionPlanName;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][1] = new_contribution.description;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][2] = new_contribution.contributionFrequency;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][3] = new_contribution.contributionID;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][4] = cv.contributionValueID;
                                            if (cv.rateTierID != null) contributionvalue_table.Rows[contributionvalue_row_counter][5] = cv.rateTierID;
                                            if (cv.dollarAmount != null) contributionvalue_table.Rows[contributionvalue_row_counter][6] = String.Format("{0:0.00}", Convert.ToDecimal(cv.dollarAmount));
                                            if (cv.percentOfPremium != null) contributionvalue_table.Rows[contributionvalue_row_counter][7] = cv.percentOfPremium;
                                            if (cv.percentOfSalary != null) contributionvalue_table.Rows[contributionvalue_row_counter][8] = cv.percentOfSalary;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][10] = item.PlanNumber;
                                            contributionvalue_table.Rows[contributionvalue_row_counter][11] = SummaryID;

                                            if (rts != null)
                                            {
                                                for (int i = 0; i < rts.Count(); i++)
                                                {
                                                    if (rts[i].rateTiers != null)
                                                    {
                                                        for (int j = 0; j < rts[i].rateTiers.Count(); j++)
                                                        {
                                                            if (cv.rateTierID == rts[i].rateTiers[j].rateTierID)
                                                            {
                                                                // Replacing "EE" with Employee for all the templates for contribution 
                                                                if (rts[i].rateTiers[j].description == "EE")
                                                                {
                                                                    contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description.Replace("EE", "Employee");
                                                                }
                                                                else
                                                                {
                                                                    contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description;
                                                                }
                                                                isratetierid = true;
                                                                break;
                                                            }

                                                        }
                                                    }
                                                    if (isratetierid == true)
                                                    {
                                                        isratetierid = false;
                                                        break;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                contributionvalue_table.Rows[contributionvalue_row_counter][9] = "";
                                            }
                                            contributionvalue_row_counter++;

                                            #endregion

                                        }

                                    }
                                }
                            }
                            #endregion
                        }



                    }
                }
                ContributionDS.Tables.Add(contribution_table);
                ContributionDS.Tables[0].TableName = "ContributionTable";
                ContributionDS.Tables.Add(contributionvalue_table);
                ContributionDS.Tables[1].TableName = "ContributionValueTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return ContributionDS;

        }

        public DataSet GetContributionForPilot(DataTable PlanTable, string SessionId)
        {
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours

            BP_BrokerConnectV4.ContributionSummary[] new_Contribution_Summary = new BP_BrokerConnectV4.ContributionSummary[10];
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();

            BP_BrokerConnectV4.Contribution new_contribution = new BP_BrokerConnectV4.Contribution();
            BP_BrokerConnectV4.ContributionStructure css = new BP_BrokerConnectV4.ContributionStructure();
            BP_BrokerConnectV4.RateTierSchedule[] rts = null;
            BP_BrokerConnectV4.ContributionSearchCriteria ContributionSearchCritria = new BP_BrokerConnectV4.ContributionSearchCriteria();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            DataSet ContributionDS = new DataSet();
            //int plan_type_temp = 0;
            int contrbution_Number = 1;


            int contributionid = 0; int SummaryID = 0;
            try
            {
                foreach (DataRow dcr in PlanTable.Rows)
                {
                    List<Contribution> lstContri = new List<Contribution>();
                    Contribution contribution = new Contribution();
                    int product_id = Convert.ToInt32(dcr["ProductId"].ToString());
                    new_product = new_connection.getProduct(product_id);

                    int ProductTypeId = Convert.ToInt32(dcr["ProductTypeId"].ToString());

                    if (Convert.ToString(ProductTypeId).Length < 4)
                    {
                        ContributionSearchCritria.productID = product_id;

                        ContributionSearchCritria.productIDSpecified = true;

                        new_Contribution_Summary = new_connection.findContributions(ContributionSearchCritria);

                        if (new_Contribution_Summary != null)
                        {
                            for (int k = 0; k < new_Contribution_Summary.Count(); k++)
                            {
                                contributionid = Convert.ToInt32(new_Contribution_Summary[k].contributionID);
                                if (!string.IsNullOrEmpty(dcr["SummaryID"].ToString()))
                                {
                                    SummaryID = Convert.ToInt32(dcr["SummaryID"].ToString());
                                }
                                new_contribution = new BP_BrokerConnectV4.Contribution();
                                if (contributionid != -1)
                                {
                                    new_contribution = new_connection.getContribution(contributionid);
                                }

                                if (new_contribution != null)
                                {


                                }
                                contribution = new Contribution();
                                contribution.ContributionId = contributionid;
                                contribution.ContributionPlanName = dcr["PlanType"].ToString();
                                contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                                if (new_product.productTypeID != null)
                                {
                                    contribution.PlanType = new_product.productTypeID;
                                }
                                lstContri.Add(contribution);

                                //contribution = new Contribution();
                                //if (!string.IsNullOrEmpty(dcr["ContributionId_2"].ToString().Trim()))
                                //{
                                //    contribution.ContributionId = Convert.ToInt32(dcr["ContributionId_2"].ToString());
                                //}
                                //contribution.ContributionPlanName = dcr["PlanType"].ToString();
                                //contribution.PlanNumber = Convert.ToString(dcr["PlanNumber"]);
                                //if (new_product.productTypeID != null)
                                //{
                                //    contribution.PlanType = new_product.productTypeID;
                                //}
                                //lstContri.Add(contribution);


                                #region contribution_summary
                                foreach (var item in lstContri)
                                {
                                    if (item.ContributionId > 0)
                                    {
                                        new_contribution = new BP_BrokerConnectV4.Contribution();
                                        if (item.ContributionId != -1)
                                        {
                                            new_contribution = new_connection.getContribution(item.ContributionId);
                                            css = new_connection.getContributionStructure(item.PlanType);
                                            rts = css.contributionTierSchedules;
                                        }

                                        #region contribution_table

                                        contribution_table.Rows.Add();

                                        contribution_table.Rows[contribution_row_counter][0] = item.ContributionPlanName;
                                        contribution_table.Rows[contribution_row_counter][1] = new_contribution.contributionID;
                                        if (new_contribution.productID != null) contribution_table.Rows[contribution_row_counter][2] = new_contribution.productID;
                                        if (new_contribution.planDesignID != null) contribution_table.Rows[contribution_row_counter][3] = new_contribution.planDesignID;
                                        if (new_contribution.description != null) contribution_table.Rows[contribution_row_counter][4] = new_contribution.description;
                                        if (new_contribution.rateTierScheduleID != null) contribution_table.Rows[contribution_row_counter][5] = new_contribution.rateTierScheduleID;
                                        if (new_contribution.includeEE != null && new_contribution.includeEE.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][6] = new_contribution.includeEE;
                                        if (new_contribution.partOfDefinedContributionOrFlexCredit != null && new_contribution.partOfDefinedContributionOrFlexCredit.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][7] = new_contribution.partOfDefinedContributionOrFlexCredit;
                                        if (new_contribution.employeeContribution != null && new_contribution.employeeContribution.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][8] = new_contribution.employeeContribution;
                                        if (new_contribution.contributionFrequency != null) contribution_table.Rows[contribution_row_counter][9] = new_contribution.contributionFrequency;
                                        if (new_contribution.preTax != null && new_contribution.preTax.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][10] = new_contribution.preTax;
                                        if (new_contribution.applyToMultiplePlans != null && new_contribution.applyToMultiplePlans.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][11] = new_contribution.applyToMultiplePlans;
                                        if (new_contribution.eeContributesLesser != null && new_contribution.eeContributesLesser.ToString().ToUpper() != "NONE_SELECTED") contribution_table.Rows[contribution_row_counter][12] = new_contribution.eeContributesLesser;
                                        if (new_contribution.percentEligibleCompensation != null) contribution_table.Rows[contribution_row_counter][13] = new_contribution.percentEligibleCompensation;
                                        if (new_contribution.additionalInformation != null) contribution_table.Rows[contribution_row_counter][14] = new_contribution.additionalInformation;
                                        if (new_contribution.lastModifiedOn != null && new_contribution.lastModifiedOn.Year != 1) contribution_table.Rows[contribution_row_counter][15] = new_contribution.lastModifiedOn;
                                        contribution_table.Rows[contribution_row_counter][16] = item.PlanNumber;

                                        //Sanchari contribution type
                                        if (rts != null)
                                        {
                                            for (int z = 0; z < rts.Count(); z++)
                                            {
                                                if (new_contribution.rateTierScheduleID != null)
                                                {
                                                    if (rts[z].rateTierScheduleID.ToString() == new_contribution.rateTierScheduleID.ToString())
                                                    {
                                                        contribution_table.Rows[contribution_row_counter][17] = rts[z].description.ToString();
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        //Sanchari contribution type

                                        contribution_row_counter++;


                                        #endregion

                                        bool isratetierid = false;
                                        if (new_contribution.contributionValues != null)
                                        {
                                            foreach (BP_BrokerConnectV4.ContributionValue cv in new_contribution.contributionValues)
                                            {
                                                #region contributionvalue_table
                                                contributionvalue_table.Rows.Add();
                                                contributionvalue_table.Rows[contributionvalue_row_counter][0] = item.ContributionPlanName;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][1] = new_contribution.description;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][2] = new_contribution.contributionFrequency;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][3] = new_contribution.contributionID;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][4] = cv.contributionValueID;
                                                if (cv.rateTierID != null) contributionvalue_table.Rows[contributionvalue_row_counter][5] = cv.rateTierID;
                                                if (cv.dollarAmount != null) contributionvalue_table.Rows[contributionvalue_row_counter][6] = String.Format("{0:0.00}", Convert.ToDecimal(cv.dollarAmount));
                                                if (cv.percentOfPremium != null) contributionvalue_table.Rows[contributionvalue_row_counter][7] = cv.percentOfPremium;
                                                if (cv.percentOfSalary != null) contributionvalue_table.Rows[contributionvalue_row_counter][8] = cv.percentOfSalary;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][10] = item.PlanNumber;
                                                contributionvalue_table.Rows[contributionvalue_row_counter][11] = SummaryID;

                                                if (rts != null)
                                                {
                                                    for (int i = 0; i < rts.Count(); i++)
                                                    {
                                                        if (rts[i].rateTiers != null)
                                                        {
                                                            for (int j = 0; j < rts[i].rateTiers.Count(); j++)
                                                            {
                                                                if (cv.rateTierID == rts[i].rateTiers[j].rateTierID)
                                                                {
                                                                    // Replacing "EE" with Employee for all the templates for contribution 
                                                                    if (rts[i].rateTiers[j].description == "EE")
                                                                    {
                                                                        contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description.Replace("EE", "Employee");
                                                                    }
                                                                    else
                                                                    {
                                                                        contributionvalue_table.Rows[contributionvalue_row_counter][9] = rts[i].rateTiers[j].description;
                                                                    }
                                                                    isratetierid = true;
                                                                    break;
                                                                }

                                                            }
                                                        }
                                                        if (isratetierid == true)
                                                        {
                                                            isratetierid = false;
                                                            break;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    contributionvalue_table.Rows[contributionvalue_row_counter][9] = "";
                                                }
                                                contributionvalue_row_counter++;

                                                #endregion

                                            }

                                        }
                                    }
                                }
                                #endregion
                            }



                        }
                    }
                }
                ContributionDS.Tables.Add(contribution_table);
                ContributionDS.Tables[0].TableName = "ContributionTable";
                ContributionDS.Tables.Add(contributionvalue_table);
                ContributionDS.Tables[1].TableName = "ContributionValueTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return ContributionDS;

        }
        /// <summary>
        ///Build Contribution Table.
        /// </summary>

        public void BuildContributionTable()
        {

            contribution_table.Columns.Add("section", typeof(string));
            contribution_table.Columns.Add("contributionID", typeof(Int32));
            contribution_table.Columns.Add("productID", typeof(Int32));
            contribution_table.Columns.Add("planDesignID", typeof(Int32));
            contribution_table.Columns.Add("description", typeof(string));
            contribution_table.Columns.Add("rateTierScheduleID", typeof(Int32));
            contribution_table.Columns.Add("includeEE", typeof(bool));
            contribution_table.Columns.Add("partOfDefinedContributionOrFlexCredit", typeof(bool));
            contribution_table.Columns.Add("employeeContribution", typeof(bool));
            contribution_table.Columns.Add("contributionFrequency", typeof(string));
            contribution_table.Columns.Add("preTax", typeof(bool));
            contribution_table.Columns.Add("applyToMultiplePlans", typeof(bool));
            contribution_table.Columns.Add("eeContributesLesser", typeof(bool));
            contribution_table.Columns.Add("percentEligibleCompensation", typeof(double));
            contribution_table.Columns.Add("additionalInformation", typeof(string));
            contribution_table.Columns.Add("lastModifiedOn", typeof(DateTime));
            contribution_table.Columns.Add("contribution_Number", typeof(string));

            contributionvalue_table.Columns.Add("section", typeof(string));
            contributionvalue_table.Columns.Add("description", typeof(string));
            contributionvalue_table.Columns.Add("contributionFrequency", typeof(string));
            contributionvalue_table.Columns.Add("contributionValues_contribution", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_contributionValueID", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_rateTierID", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_amount", typeof(decimal));
            contributionvalue_table.Columns.Add("contributionValues_percentOfPremium", typeof(double));
            contributionvalue_table.Columns.Add("contributionValues_percentOfSalary", typeof(double));
            contributionvalue_table.Columns.Add("contributionValues_contributionDescription", typeof(string));
            contributionvalue_table.Columns.Add("contribution_Number", typeof(string));
            contributionvalue_table.Columns.Add("contributionValues_summaryID", typeof(Int32));
            contributionvalue_table.Columns.Add("allowIncludeEE", typeof(bool));
            contributionvalue_table.Columns.Add("contributionDescriptionWithEEIncluded", typeof(string));

            premium_table.Columns.Add("Plan", typeof(string));
            premium_table.Columns.Add("rateTierID", typeof(string));
            premium_table.Columns.Add("rateTier_description", typeof(string));
            premium_table.Columns.Add("monthlycost", typeof(string));
            premium_table.Columns.Add("contributioncost", typeof(string));
            premium_table.Columns.Add("summaryname", typeof(string));
            premium_table.Columns.Add("contributionFrequency", typeof(string));
            premium_table.Columns.Add("contributionid", typeof(string));
            premium_table.Columns.Add("rateid", typeof(string));
        }

        public DataSet GetTeamMembers(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            BP_BrokerConnectV4.AccountTeamMember[] TeamMember = new BP_BrokerConnectV4.AccountTeamMember[100];

            BP_BrokerConnectV4.AccountTeamRole[] TeamRole = new BP_BrokerConnectV4.AccountTeamRole[100]; // This array is used to get the Role's of team members

            DataSet AccountTeamMemberDS = new DataSet();
            int account_row_counter = 0;

            //BP_BrokerConnectV4.User phn = new BP_BrokerConnectV4.User();
            try
            {
                account_Team_memeber = new DataTable();

                BuildAccountTeamMamberTable();
                SIH.sessionId = SessionId;  //myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                TeamMember = new_connection.getTeamMembers(account_id);

                TeamRole = new_connection.getAccountTeamRoles(); //  Get all the roles of the team members
                //phn = new_connection.getUser(account_id);

                foreach (BP_BrokerConnectV4.AccountTeamMember item in TeamMember)
                {
                    account_Team_memeber.Rows.Add();
                    account_Team_memeber.Rows[account_row_counter][0] = item.userID.ToString();
                    account_Team_memeber.Rows[account_row_counter][1] = item.firstName;
                    account_Team_memeber.Rows[account_row_counter][2] = item.lastName;
                    account_Team_memeber.Rows[account_row_counter][3] = item.email;

                    // Get the exact role from TeamRole array by providing brokerClientRoleID
                    var role = (from n in TeamRole.AsEnumerable()
                                where n.roleID == item.brokerClientRoleID
                                select n.description).FirstOrDefault();

                    account_Team_memeber.Rows[account_row_counter][4] = role;
                    account_row_counter++;

                }
                AccountTeamMemberDS.Tables.Add(account_Team_memeber);
                AccountTeamMemberDS.Tables[0].TableName = "AccountTeamMember";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountTeamMemberDS;

        }


        public void BuildAccountTeamMamberTable()
        {
            try
            {
                account_Team_memeber.Columns.Add("userID", typeof(string));  // Row 0
                account_Team_memeber.Columns.Add("firstName", typeof(string));  // Row 1
                account_Team_memeber.Columns.Add("lastName", typeof(string));  // Row 2
                account_Team_memeber.Columns.Add("email", typeof(string));  // Row 3
                account_Team_memeber.Columns.Add("role", typeof(string));  // Row 4
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public string GetFormattedAddress(DataSet AccountDS, string reportName = "")
        {
            string MainAddress = string.Empty;
            string Street1 = string.Empty;
            string Street2 = string.Empty;
            string City = string.Empty;
            string State = string.Empty;
            string Zip = string.Empty;
            string Country = string.Empty;

            try
            {
                if (AccountDS != null)
                {
                    if (AccountDS.Tables[1].Rows.Count > 0)
                    {
                        for (int m = 0; m < AccountDS.Tables[1].Rows.Count; m++)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street1"])))
                            {
                                Street1 = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street1"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street2"])))
                            {
                                Street2 = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_street2"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_city"])))
                            {
                                City = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_city"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_state"])))
                            {
                                State = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_state"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_zip"])))
                            {
                                Zip = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_zip"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_country"])))
                            {
                                Country = Convert.ToString(AccountDS.Tables[1].Rows[m]["mainAddress_country"]);

                                if (reportName == "Tools1" || reportName == "Tools2")
                                {
                                    Country = "";
                                }
                            }
                        }

                        StringBuilder sb = new StringBuilder();

                        if (!string.IsNullOrEmpty(Street1))
                        {
                            if (Street1.ToString() != "None_Selected")
                            {
                                sb.Append(Street1);
                                if (!string.IsNullOrEmpty(Street2))
                                {
                                    sb.Append(", ");
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(Street1) || !string.IsNullOrEmpty(Street2))
                        {
                            if (!string.IsNullOrEmpty(Street2) && Street2.ToString() != "None_Selected")
                            {
                                sb.Append(Street2);
                            }
                            sb.Append("\n");
                        }

                        if (!string.IsNullOrEmpty(City))
                        {
                            if (City.ToString() != "None_Selected")
                            {
                                sb.Append(City);
                                sb.Append(", ");
                            }
                        }

                        if (!string.IsNullOrEmpty(State))
                        {
                            if (State.ToString() != "None_Selected")
                            {
                                State = State.ToString();
                            }
                        }
                        if (!string.IsNullOrEmpty(Country))
                        {
                            if (Country.ToString() != "None_Selected")
                            {
                                Country = Country.ToString();
                            }
                        }
                        if (!string.IsNullOrEmpty(Zip))
                        {
                            if (Zip.ToString() != "None_Selected")
                            {
                                Zip = Zip.ToString();
                            }
                        }
                        if (string.IsNullOrEmpty(State))
                        {
                            if (!string.IsNullOrEmpty(Country))
                            {
                                sb.Append(Zip + "\n" + Country.ToString().Replace("_", " "));
                            }
                            else
                            {
                                sb.Append(Zip);
                            }
                        }
                        else if (string.IsNullOrEmpty(State) && string.IsNullOrEmpty(Country))
                        {
                            sb.Append(Zip);
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(Country))
                            {
                                sb.Append(State + " " + Zip + "\n" + Country.ToString().Replace("_", " "));
                            }
                            else
                            {
                                sb.Append(State + " " + Zip);
                            }
                        }

                        if (sb != null)
                        {
                            MainAddress = sb.ToString();
                        }
                    }
                }
                return MainAddress;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public string GetUserWorkPhoneNumber(int User_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            BP_BrokerConnectV4.User new_user = new BP_BrokerConnectV4.User();

            string UserWorkPhoneNumber = string.Empty;

            try
            {

                SIH.sessionId = SessionId; //myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                new_user = new_connection.getUser(User_id);

                if (new_user.workPhone != null)///Added condition on 18 Feb 2015
                {
                    if (!string.IsNullOrEmpty(new_user.workPhone.number))
                    {
                        UserWorkPhoneNumber = new_user.workPhone.areaCode + "-" + new_user.workPhone.number;
                    }
                }


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return UserWorkPhoneNumber;
        }

        public int GetProductDetail_numberofeligibleemployee(int ProductID, string SessionId)//(int product_id, string section)
        {
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            int NoofELGEmployee = 0;
            try
            {
                new_product = new BP_BrokerConnectV4.Product();
                new_product = new_connection.getProduct(ProductID);
                if (new_product != null)
                {
                    NoofELGEmployee = new_product.numberOfEligibleEmployees;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return NoofELGEmployee;
        }

        public int GetProductDetail_FundingType_OptionFieldID(int ProductID, string SessionId)//(int product_id, string section)
        {
            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.CustomFieldValue[] arr = null;
            SIH.sessionId = SessionId; //myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            int optionValueID = 0;
            try
            {
                new_product = new BP_BrokerConnectV4.Product();
                new_product = new_connection.getProduct(ProductID);
                arr = new_product.customFieldValues;
                if (new_product != null)
                {
                    if (arr != null)
                    {
                        for (int i = 0; i < new_product.customFieldValues.Count(); i++)
                        {
                            if (new_product.customFieldValues[i].customFieldID == 18111)
                            {
                                optionValueID = new_product.customFieldValues[i].optionValueID;
                                break;
                            }
                        }
                    }
                    else
                    {
                        optionValueID = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return optionValueID;


        }

        // This funtion is used to get the title and  work phone number for the particular user based on the UserId
        public List<string> GetUserDetails(int User_id, string SessionId)
        {
            List<string> lstUser = new List<string>();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            BP_BrokerConnectV4.User new_user = new BP_BrokerConnectV4.User();

            string UserWorkPhoneNumber = string.Empty;

            try
            {

                SIH.sessionId = SessionId; //myloginresult.sessionID;

                new_connection.SessionIdHeaderValue = SIH;

                new_connection.Timeout = 14400000;

                new_user = new_connection.getUser(User_id);

                lstUser.Add(new_user.title);

                if (new_user.workPhone != null)  ///Added condition on 18 Feb 2015
                {
                    if (!string.IsNullOrEmpty(new_user.workPhone.number))
                    {
                        UserWorkPhoneNumber = new_user.workPhone.areaCode + "-" + new_user.workPhone.number;
                    }
                }

                lstUser.Add(UserWorkPhoneNumber);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return lstUser;
        }

        /// <summary>
        /// Build Rate Table.
        /// </summary>
        public void BuildRateTable_Pilot()
        {
            try
            {
                #region rate
                ratesummary_table.Columns.Add("section", typeof(string));
                ratesummary_table.Columns.Add("rateID", typeof(Int32));
                ratesummary_table.Columns.Add("description", typeof(string));
                ratesummary_table.Columns.Add("effectiveAsOf", typeof(DateTime));
                ratesummary_table.Columns.Add("expirationOn", typeof(DateTime));
                ratesummary_table.Columns.Add("annualizedPremium", typeof(decimal));
                ratesummary_table.Columns.Add("annualizedRevenue", typeof(decimal));
                ratesummary_table.Columns.Add("productID", typeof(Int32));

                associatedBenefitSummaries_table.Columns.Add("section", typeof(string));
                associatedBenefitSummaries_table.Columns.Add("rateID", typeof(Int32));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_benefitSummaryID", typeof(Int32));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_description", typeof(string));
                associatedBenefitSummaries_table.Columns.Add("associatedBenefitSummaries_productID", typeof(Int32));




                rate_table.Columns.Add("section", typeof(string));
                rate_table.Columns.Add("rateID", typeof(Int32));
                rate_table.Columns.Add("productID", typeof(Int32));
                rate_table.Columns.Add("responseID", typeof(Int32));
                rate_table.Columns.Add("description", typeof(string));
                rate_table.Columns.Add("rateTypeID", typeof(Int32));
                rate_table.Columns.Add("rateTypeTierID", typeof(Int32));
                rate_table.Columns.Add("effectiveAsOf", typeof(DateTime));
                rate_table.Columns.Add("expirationOn", typeof(DateTime));
                rate_table.Columns.Add("includeEE", typeof(bool));
                rate_table.Columns.Add("ageBanded", typeof(bool));
                rate_table.Columns.Add("ageBandedStartOn", typeof(Int32));  // Row 10
                rate_table.Columns.Add("ageBandedEndOn", typeof(Int32));  // Row 11
                rate_table.Columns.Add("ageBandedInterval", typeof(Int32));  // Row 12
                rate_table.Columns.Add("ageBandedGenderSpecific", typeof(bool));  // Row 13
                rate_table.Columns.Add("ratingMethod", typeof(string));  // Row 14
                rate_table.Columns.Add("estimatedMonthlyPremium", typeof(double));  // Row 15
                rate_table.Columns.Add("estimatedMonthlyRevenue", typeof(double));  // Row 16
                rate_table.Columns.Add("additionalInfo", typeof(string));  // Row 17
                rate_table.Columns.Add("rateGuarantee", typeof(Int32));  // Row 18
                rate_table.Columns.Add("rateGuaranteeUOM", typeof(string));  // Row 19
                rate_table.Columns.Add("numberOfLivesAsOf", typeof(DateTime));  // Row 20
                rate_table.Columns.Add("paymentCycle", typeof(Int32));  // Row 21
                rate_table.Columns.Add("renewalPercentageChange", typeof(double));  // Row 22
                rate_table.Columns.Add("lastModifiedOn", typeof(DateTime));  // Row 23
                rate_table.Columns.Add("createdOn", typeof(DateTime));  // Row 24
                rate_table.Columns.Add("FundingType", typeof(string));  //Row 25 //Sanchari rate funding
                rate_table.Columns.Add("RateType", typeof(string));  //Row 2 //Sanchari rate type

                benefitsummaryrate_table.Columns.Add("section", typeof(string));
                benefitsummaryrate_table.Columns.Add("rateID", typeof(Int32));
                benefitsummaryrate_table.Columns.Add("associatedBenefitSummaries_benefitSummaryID", typeof(Int32));
                benefitsummaryrate_table.Columns.Add("associatedBenefitSummaries_description", typeof(string));



                ratefieldvalue_table.Columns.Add("section", typeof(string));
                ratefieldvalue_table.Columns.Add("rateID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateFieldValueID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_rateFieldID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_label", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_fieldType", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateField_fieldValueType", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_multiValueIndex", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_valueNum", typeof(decimal));
                ratefieldvalue_table.Columns.Add("rateFieldValues_valueText", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_rateTierID", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_description", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_rateTier_allowIncludeEE", typeof(bool));
                ratefieldvalue_table.Columns.Add("rateFieldValues_ageBandIndex", typeof(Int32));
                ratefieldvalue_table.Columns.Add("rateFieldValues_ageBandGender", typeof(string));
                ratefieldvalue_table.Columns.Add("rateFieldValues_summaryID", typeof(Int32));


                rateoptionvalue_table.Columns.Add("section", typeof(string));
                rateoptionvalue_table.Columns.Add("rateID", typeof(Int32));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateField_optionValues_rateOptionValueID", typeof(Int32));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateField_optionValues_description", typeof(string));
                rateoptionvalue_table.Columns.Add("rateFieldValues_rateFieldValueID", typeof(Int32));


                #endregion
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
        }

        public void BuildContributionTable_Pilot()
        {

            contribution_table.Columns.Add("section", typeof(string));
            contribution_table.Columns.Add("contributionID", typeof(Int32));
            contribution_table.Columns.Add("productID", typeof(Int32));
            contribution_table.Columns.Add("planDesignID", typeof(Int32));
            contribution_table.Columns.Add("description", typeof(string));
            contribution_table.Columns.Add("rateTierScheduleID", typeof(Int32));
            contribution_table.Columns.Add("includeEE", typeof(bool));
            contribution_table.Columns.Add("partOfDefinedContributionOrFlexCredit", typeof(bool));
            contribution_table.Columns.Add("employeeContribution", typeof(bool));
            contribution_table.Columns.Add("contributionFrequency", typeof(string));
            contribution_table.Columns.Add("preTax", typeof(bool));
            contribution_table.Columns.Add("applyToMultiplePlans", typeof(bool));
            contribution_table.Columns.Add("eeContributesLesser", typeof(bool));
            contribution_table.Columns.Add("percentEligibleCompensation", typeof(double));
            contribution_table.Columns.Add("additionalInformation", typeof(string));
            contribution_table.Columns.Add("lastModifiedOn", typeof(DateTime));
            contribution_table.Columns.Add("contribution_Number", typeof(string));
            contribution_table.Columns.Add("contributionTier", typeof(string));

            contributionvalue_table.Columns.Add("section", typeof(string));
            contributionvalue_table.Columns.Add("description", typeof(string));
            contributionvalue_table.Columns.Add("contributionFrequency", typeof(string));
            contributionvalue_table.Columns.Add("contributionValues_contribution", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_contributionValueID", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_rateTierID", typeof(Int32));
            contributionvalue_table.Columns.Add("contributionValues_amount", typeof(decimal));
            contributionvalue_table.Columns.Add("contributionValues_percentOfPremium", typeof(double));
            contributionvalue_table.Columns.Add("contributionValues_percentOfSalary", typeof(double));
            contributionvalue_table.Columns.Add("contributionValues_contributionDescription", typeof(string));
            contributionvalue_table.Columns.Add("contribution_Number", typeof(string));
            contributionvalue_table.Columns.Add("contributionValues_summaryID", typeof(Int32));

            premium_table.Columns.Add("Plan", typeof(string));
            premium_table.Columns.Add("rateTierID", typeof(string));
            premium_table.Columns.Add("rateTier_description", typeof(string));
            premium_table.Columns.Add("monthlycost", typeof(string));
            premium_table.Columns.Add("contributioncost", typeof(string));
            premium_table.Columns.Add("summaryname", typeof(string));
            premium_table.Columns.Add("contributionFrequency", typeof(string));
            premium_table.Columns.Add("contributionid", typeof(string));
            premium_table.Columns.Add("rateid", typeof(string));
        }

        /// <summary>
        /// Get rate detail from  BP_BrokerConnectV4 web service using getRate webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Rate Data</returns>
        public DataSet GetRateForTools_Pilot(DataTable PlanTable, string SessionId)
        {

            BP_BrokerConnectV4.RateSummary[] new_rate_Summary = new BP_BrokerConnectV4.RateSummary[10];
            BP_BrokerConnectV4.Rate new_rate = null;
            BP_BrokerConnectV4.RateType[] rate_funding = null;
            BP_BrokerConnectV4.RateStructure rate_type = null;
            BP_BrokerConnectV4.RateTypeTier[] rate_typeTier = null;

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.RateSearchCriteria rateSearchCritria = new BP_BrokerConnectV4.RateSearchCriteria();

            SIH.sessionId = SessionId;// myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;

            DataSet RateDS = new DataSet();
            int rate_row_counter = 0;
            int benefitsummaryrate_row_counter = 0;

            int ratefieldvalue_row_counter = 0;
            int rateoptionvalue_row_counter = 0;
            int rateid = 0;

            try
            {
                BuildRateTable_Pilot();

                foreach (DataRow drd in PlanTable.Rows)
                {
                    string section = drd["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(drd["SummaryId"].ToString());
                    //int rateid = Convert.ToInt32(drd["RateId"].ToString());
                    int productId = Convert.ToInt32(drd["ProductId"].ToString());
                    int productTypeId = Convert.ToInt32(drd["ProductTypeId"].ToString());
                    if (Convert.ToString(productTypeId).Length < 4)
                    {
                        // new_rate = new BP_BrokerConnectV4.RateSummary();
                        //if (rateid != -1)
                        //{

                        rateSearchCritria.productID = productId;
                        rateSearchCritria.productIDSpecified = true;

                        new_rate_Summary = new_connection.findRates(rateSearchCritria);


                        //}
                        if (new_rate_Summary != null)
                        {
                            for (int j = 0; j < new_rate_Summary.Count(); j++)
                            {
                                // Check for the associated benefit summary, because the rates are to be deisplayed based on the associated benefit summary_id
                                if (new_rate_Summary[j].associatedBenefitSummaries != null && new_rate_Summary[j].associatedBenefitSummaries.Count() > 0)
                                {
                                    for (int k = 0; k < new_rate_Summary[j].associatedBenefitSummaries.Count(); k++)
                                    {
                                        if (summary_id == Convert.ToInt32(new_rate_Summary[j].associatedBenefitSummaries[k].benefitSummaryID))
                                        {

                                            rateid = Convert.ToInt32(new_rate_Summary[j].rateID);

                                            //DataRow[] drRate = rate_table.Select("rateID = '" + rateid + "'");
                                            //if (drRate.Length == 0)
                                            //{
                                            // do something...

                                            new_rate = new BP_BrokerConnectV4.Rate();
                                            try
                                            {
                                                if (rateid != -1)
                                                {
                                                    new_rate = new_connection.getRate(rateid);
                                                    rate_funding = new_connection.getRateTypes();  //Sanchari rate funding
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                            }

                                            if (new_rate != null)
                                            {

                                                #region ratetable

                                                rate_table.Rows.Add();
                                                rate_table.Rows[rate_row_counter][0] = section;
                                                if (new_rate.rateID != null) rate_table.Rows[rate_row_counter][1] = new_rate.rateID.ToString();
                                                if (new_rate.productID != null) rate_table.Rows[rate_row_counter][2] = new_rate.productID.ToString();
                                                if (new_rate.responseID != null) rate_table.Rows[rate_row_counter][3] = new_rate.responseID.ToString();
                                                if (new_rate.description != null) rate_table.Rows[rate_row_counter][4] = new_rate.description.ToString();
                                                if (new_rate.rateTypeID != null) rate_table.Rows[rate_row_counter][5] = new_rate.rateTypeID.ToString();
                                                if (new_rate.rateTypeTierID != null) rate_table.Rows[rate_row_counter][6] = new_rate.rateTypeTierID.ToString();
                                                if (new_rate.effectiveAsOf != null) rate_table.Rows[rate_row_counter][7] = new_rate.effectiveAsOf.ToString();
                                                if (new_rate.expirationOn != null) rate_table.Rows[rate_row_counter][8] = new_rate.expirationOn.ToString();
                                                if (new_rate.includeEE != null) rate_table.Rows[rate_row_counter][9] = new_rate.includeEE.ToString();
                                                if (new_rate.ageBanded != null) rate_table.Rows[rate_row_counter][10] = new_rate.ageBanded.ToString();
                                                if (new_rate.ageBandedStartOn != null) rate_table.Rows[rate_row_counter][11] = new_rate.ageBandedStartOn.ToString();
                                                if (new_rate.ageBandedEndOn != null) rate_table.Rows[rate_row_counter][12] = new_rate.ageBandedEndOn.ToString();
                                                if (new_rate.ageBandedInterval != null) rate_table.Rows[rate_row_counter][13] = new_rate.ageBandedInterval.ToString();
                                                if (new_rate.ageBandedGenderSpecific != null) rate_table.Rows[rate_row_counter][14] = new_rate.ageBandedGenderSpecific.ToString();
                                                if (new_rate.ratingMethod != null) rate_table.Rows[rate_row_counter][15] = new_rate.ratingMethod.ToString();
                                                if (new_rate.estimatedMonthlyPremium != null) rate_table.Rows[rate_row_counter][16] = new_rate.estimatedMonthlyPremium.ToString();
                                                if (new_rate.estimatedMonthlyRevenue != null) rate_table.Rows[rate_row_counter][17] = new_rate.estimatedMonthlyRevenue.ToString();
                                                if (new_rate.additionalInfo != null) rate_table.Rows[rate_row_counter][18] = new_rate.additionalInfo.ToString();
                                                if (new_rate.rateGuarantee != null) rate_table.Rows[rate_row_counter][19] = new_rate.rateGuarantee.ToString();
                                                if (new_rate.rateGuaranteeUOM != null) rate_table.Rows[rate_row_counter][20] = new_rate.rateGuaranteeUOM.ToString();
                                                if (new_rate.numberOfLivesAsOf != null) rate_table.Rows[rate_row_counter][21] = new_rate.numberOfLivesAsOf.ToString();
                                                if (new_rate.paymentCycle != null) rate_table.Rows[rate_row_counter][22] = new_rate.paymentCycle.ToString();
                                                if (new_rate.renewalPercentageChange != null) rate_table.Rows[rate_row_counter][23] = new_rate.renewalPercentageChange.ToString();
                                                if (new_rate.lastModifiedOn != null) rate_table.Rows[rate_row_counter][24] = new_rate.lastModifiedOn.ToString();
                                                if (new_rate.createdOn != null) rate_table.Rows[rate_row_counter][25] = new_rate.createdOn.ToString();
                                                //rate_table.Rows[rate_row_counter][26] = "";

                                                //Sanchari rate funding
                                                if (rate_funding != null)
                                                {
                                                    for (int z = 0; z < rate_funding.Count(); z++)
                                                    {
                                                        if (new_rate.rateTypeID != null)
                                                        {
                                                            if (rate_funding[z].rateTypeID.ToString() == new_rate.rateTypeID.ToString())
                                                            {
                                                                rate_table.Rows[rate_row_counter][26] = rate_funding[z].fundingType.ToString();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                //Sanchari rate funding

                                                rate_type = new_connection.getRateStructure(new_rate.rateTypeID);  //Sanchari rate type
                                                rate_typeTier = rate_type.rateTypeTiers;
                                                //Sanchari rate type
                                                if (rate_typeTier != null)
                                                {
                                                    for (int z = 0; z < rate_typeTier.Count(); z++)
                                                    {
                                                        if (new_rate.rateTypeID != null)
                                                        {
                                                            if (rate_typeTier[z].rateTypeTierID.ToString() == new_rate.rateTypeTierID.ToString())
                                                            {
                                                                rate_table.Rows[rate_row_counter][27] = rate_typeTier[z].rateTierSchedule.description.ToString();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                //Sanchari rate type

                                                #endregion

                                                #region beniftssummaryratetable
                                                if (new_rate.associatedBenefitSummaries != null)
                                                {
                                                    foreach (BP_BrokerConnectV4.BenefitSummaryDescription bsd in new_rate.associatedBenefitSummaries)
                                                    {
                                                        if (bsd.benefitSummaryID == summary_id)
                                                        {
                                                            benefitsummaryrate_table.Rows.Add();
                                                            benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][0] = section;
                                                            if (new_rate.rateID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][1] = new_rate.rateID.ToString();
                                                            if (bsd.benefitSummaryID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][2] = bsd.benefitSummaryID.ToString();
                                                            if (bsd.description != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][3] = bsd.description.ToString();
                                                            benefitsummaryrate_row_counter++;

                                                        }
                                                    }

                                                }
                                                #endregion


                                                if (new_rate.rateFieldValues != null)
                                                {
                                                    foreach (BP_BrokerConnectV4.RateFieldValue rfv in new_rate.rateFieldValues)
                                                    {

                                                        #region ratefield_table
                                                        ratefieldvalue_table.Rows.Add();
                                                        ratefieldvalue_table.Rows[ratefieldvalue_row_counter][0] = section;
                                                        if (new_rate.rateID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][1] = new_rate.rateID.ToString();
                                                        if (rfv.rateFieldValueID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][2] = rfv.rateFieldValueID.ToString();
                                                        if (rfv.rateField.rateFieldID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][3] = rfv.rateField.rateFieldID.ToString();
                                                        if (rfv.rateField.label != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][4] = rfv.rateField.label.ToString();
                                                        if (rfv.rateField.fieldType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][5] = rfv.rateField.fieldType.ToString();
                                                        if (rfv.rateField.fieldValueType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][6] = rfv.rateField.fieldValueType.ToString();

                                                        if (rfv.multiValueIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][7] = rfv.multiValueIndex.ToString();

                                                        // Added decimal condition (01 Sept 2016) - Vaibhav Raut: For checking if the value is having only 1 digit after decimal point, if only 1 digit is available then format it upto 2 digits after decimal point
                                                        if (!string.IsNullOrEmpty(Convert.ToString(rfv.valueNum)))
                                                        {
                                                            if (rfv.valueNum.ToString().Substring(rfv.valueNum.ToString().IndexOf(".") + 1).Length == 1)
                                                            {
                                                                if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = String.Format("{0:0.00}", Convert.ToDecimal(rfv.valueNum.ToString()));
                                                            }
                                                            else
                                                            {
                                                                if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = Convert.ToDecimal(rfv.valueNum.ToString());
                                                            }
                                                        }
                                                        if (rfv.valueText != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][9] = rfv.valueText.ToString();



                                                        if (rfv.rateTier != null)
                                                        {

                                                            if (rfv.rateTier.rateTierID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][10] = rfv.rateTier.rateTierID.ToString();
                                                            // Replacing "EE" with Employee for all the templates for rate 
                                                            if (rfv.rateTier.description.ToString() == "EE")
                                                            {
                                                                if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString().Replace("EE", "Employee");
                                                            }
                                                            else
                                                            {


                                                                if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString();

                                                            }
                                                            if (rfv.rateTier.allowIncludeEE != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][12] = rfv.rateTier.allowIncludeEE.ToString();
                                                        }
                                                        else
                                                        {
                                                            if (rfv.rateField.rateFieldGroup.description.ToString().Trim() == "Dependent Child Life")
                                                            {
                                                                ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = "Dependent Child Life";
                                                            }



                                                        }

                                                        if (rfv.ageBandIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][13] = rfv.ageBandIndex.ToString();
                                                        if (rfv.ageBandGender != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][14] = rfv.ageBandGender.ToString();
                                                        ratefieldvalue_table.Rows[ratefieldvalue_row_counter][15] = summary_id;

                                                        #endregion

                                                        #region ratefieldoption_table
                                                        if (rfv.rateField.optionValues != null)
                                                        {
                                                            foreach (BP_BrokerConnectV4.RateOptionValue rov in rfv.rateField.optionValues)
                                                            {
                                                                rateoptionvalue_table.Rows.Add();
                                                                rateoptionvalue_table.Rows[rateoptionvalue_row_counter][0] = section;
                                                                if (new_rate.rateID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][1] = new_rate.rateID.ToString();
                                                                if (rov.rateOptionValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][2] = rov.rateOptionValueID.ToString();
                                                                if (rov.description != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][3] = rov.description.ToString();
                                                                if (rfv.rateFieldValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][4] = rfv.rateFieldValueID.ToString();
                                                                rateoptionvalue_row_counter++;

                                                            }
                                                        }
                                                        #endregion

                                                        ratefieldvalue_row_counter++;
                                                    }

                                                }
                                                rate_row_counter++;

                                                //}
                                            }


                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                RateDS.Tables.Add(rateoptionvalue_table);
                RateDS.Tables[0].TableName = "RateOptionValueTable";
                RateDS.Tables.Add(ratefieldvalue_table);
                RateDS.Tables[1].TableName = "RateFieldValueTable";
                RateDS.Tables.Add(benefitsummaryrate_table);
                RateDS.Tables[2].TableName = "BenefitSummaryRateTable";
                RateDS.Tables.Add(rate_table);
                RateDS.Tables[3].TableName = "RateTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return RateDS;

        }

        /// <summary>
        /// Get rate detail from  BP_BrokerConnectV4 web service using getRate webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>Rate Data</returns>
        public DataSet GetRateForClientRevenue(DataTable PlanTable, string SessionId)
        {

            BP_BrokerConnectV4.RateSummary[] new_rate_Summary = new BP_BrokerConnectV4.RateSummary[10];
            BP_BrokerConnectV4.Rate new_rate = null;
            BP_BrokerConnectV4.RateType[] rate_funding = null;

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();

            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.RateSearchCriteria rateSearchCritria = new BP_BrokerConnectV4.RateSearchCriteria();

            SIH.sessionId = SessionId;// myloginresult.sessionID;

            new_connection.SessionIdHeaderValue = SIH;

            DataSet RateDS = new DataSet();
            int rate_row_counter = 0;
            int benefitsummaryrate_row_counter = 0;

            int ratefieldvalue_row_counter = 0;
            int rateoptionvalue_row_counter = 0;
            int rateid = 0;

            try
            {
                BuildRateTable();

                foreach (DataRow drd in PlanTable.Rows)
                {
                    string section = drd["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(drd["SummaryId"].ToString());
                    //int rateid = Convert.ToInt32(drd["RateId"].ToString());
                    int productId = Convert.ToInt32(drd["ProductId"].ToString());

                    // new_rate = new BP_BrokerConnectV4.RateSummary();
                    //if (rateid != -1)
                    //{

                    rateSearchCritria.productID = productId;
                    rateSearchCritria.productIDSpecified = true;

                    new_rate_Summary = new_connection.findRates(rateSearchCritria);


                    //}
                    if (new_rate_Summary != null)
                    {
                        for (int j = 0; j < new_rate_Summary.Count(); j++)
                        {
                            // Check for the associated benefit summary, because the rates are to be deisplayed based on the associated benefit summary_id
                            if (new_rate_Summary[j].associatedBenefitSummaries != null && new_rate_Summary[j].associatedBenefitSummaries.Count() > 0)
                            {
                                for (int k = 0; k < new_rate_Summary[j].associatedBenefitSummaries.Count(); k++)
                                {
                                    if (summary_id == Convert.ToInt32(new_rate_Summary[j].associatedBenefitSummaries[k].benefitSummaryID))
                                    {

                                        rateid = Convert.ToInt32(new_rate_Summary[j].rateID);

                                        //DataRow[] drRate = rate_table.Select("rateID = '" + rateid + "'");
                                        //if (drRate.Length == 0)
                                        //{
                                        // do something...

                                        new_rate = new BP_BrokerConnectV4.Rate();
                                        try
                                        {
                                            if (rateid != -1)
                                            {
                                                new_rate = new_connection.getRate(rateid);
                                                rate_funding = new_connection.getRateTypes();  //Sanchari rate funding
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                        }

                                        if (new_rate != null)
                                        {

                                            #region rate_table_revenue

                                            rate_table_revenue.Rows.Add();
                                            rate_table_revenue.Rows[rate_row_counter][0] = section;
                                            if (new_rate.rateID != null) rate_table_revenue.Rows[rate_row_counter][1] = new_rate.rateID.ToString();
                                            if (new_rate.productID != null) rate_table_revenue.Rows[rate_row_counter][2] = new_rate.productID.ToString();
                                            if (new_rate.responseID != null) rate_table_revenue.Rows[rate_row_counter][3] = new_rate.responseID.ToString();
                                            if (new_rate.description != null) rate_table_revenue.Rows[rate_row_counter][4] = new_rate.description.ToString();
                                            if (new_rate.rateTypeID != null) rate_table_revenue.Rows[rate_row_counter][5] = new_rate.rateTypeID.ToString();
                                            if (new_rate.rateTypeTierID != null) rate_table_revenue.Rows[rate_row_counter][6] = new_rate.rateTypeTierID.ToString();
                                            if (new_rate.effectiveAsOf != null) rate_table_revenue.Rows[rate_row_counter][7] = new_rate.effectiveAsOf.ToString();
                                            if (new_rate.expirationOn != null) rate_table_revenue.Rows[rate_row_counter][8] = new_rate.expirationOn.ToString();
                                            if (new_rate.includeEE != null) rate_table_revenue.Rows[rate_row_counter][9] = new_rate.includeEE.ToString();
                                            if (new_rate.ageBanded != null) rate_table_revenue.Rows[rate_row_counter][10] = new_rate.ageBanded.ToString();
                                            if (new_rate.ageBandedStartOn != null) rate_table_revenue.Rows[rate_row_counter][11] = new_rate.ageBandedStartOn.ToString();
                                            if (new_rate.ageBandedEndOn != null) rate_table_revenue.Rows[rate_row_counter][12] = new_rate.ageBandedEndOn.ToString();
                                            if (new_rate.ageBandedInterval != null) rate_table_revenue.Rows[rate_row_counter][13] = new_rate.ageBandedInterval.ToString();
                                            if (new_rate.ageBandedGenderSpecific != null) rate_table_revenue.Rows[rate_row_counter][14] = new_rate.ageBandedGenderSpecific.ToString();
                                            if (new_rate.ratingMethod != null) rate_table_revenue.Rows[rate_row_counter][15] = new_rate.ratingMethod.ToString();
                                            //if (new_rate.estimatedMonthlyPremium != null) rate_table.Rows[rate_row_counter][16] = new_rate.estimatedMonthlyPremium.ToString();
                                            if (new_rate.estimatedMonthlyPremium != null) rate_table_revenue.Rows[rate_row_counter][16] = new_rate_Summary[j].annualizedPremium.ToString();
                                            //if (new_rate.estimatedMonthlyRevenue != null) rate_table.Rows[rate_row_counter][17] = new_rate.estimatedMonthlyRevenue.ToString();
                                            if (new_rate.estimatedMonthlyRevenue != null) rate_table_revenue.Rows[rate_row_counter][17] = new_rate_Summary[j].annualizedRevenue.ToString();
                                            if (new_rate.additionalInfo != null) rate_table_revenue.Rows[rate_row_counter][18] = new_rate.additionalInfo.ToString();
                                            if (new_rate.rateGuarantee != null) rate_table_revenue.Rows[rate_row_counter][19] = new_rate.rateGuarantee.ToString();
                                            if (new_rate.rateGuaranteeUOM != null) rate_table_revenue.Rows[rate_row_counter][20] = new_rate.rateGuaranteeUOM.ToString();
                                            if (new_rate.numberOfLivesAsOf != null) rate_table_revenue.Rows[rate_row_counter][21] = new_rate.numberOfLivesAsOf.ToString();
                                            if (new_rate.paymentCycle != null) rate_table_revenue.Rows[rate_row_counter][22] = new_rate.paymentCycle.ToString();
                                            if (new_rate.renewalPercentageChange != null) rate_table_revenue.Rows[rate_row_counter][23] = new_rate.renewalPercentageChange.ToString();
                                            if (new_rate.lastModifiedOn != null) rate_table_revenue.Rows[rate_row_counter][24] = new_rate.lastModifiedOn.ToString();
                                            if (new_rate.createdOn != null) rate_table_revenue.Rows[rate_row_counter][25] = new_rate.createdOn.ToString();
                                            //rate_table.Rows[rate_row_counter][26] = "";
                                            if (new_rate.commissions != null) rate_table_revenue.Rows[rate_row_counter][27] = Convert.ToString(new_rate.commissions[0].commissionType);

                                            //Sanchari rate funding
                                            if (rate_funding != null)
                                            {
                                                for (int z = 0; z < rate_funding.Count(); z++)
                                                {
                                                    if (new_rate.rateTypeID != null)
                                                    {
                                                        if (rate_funding[z].rateTypeID.ToString() == new_rate.rateTypeID.ToString())
                                                        {
                                                            rate_table_revenue.Rows[rate_row_counter][26] = rate_funding[z].fundingType.ToString();
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            //Sanchari rate funding

                                            #endregion

                                            #region beniftssummaryratetable
                                            if (new_rate.associatedBenefitSummaries != null)
                                            {
                                                foreach (BP_BrokerConnectV4.BenefitSummaryDescription bsd in new_rate.associatedBenefitSummaries)
                                                {
                                                    if (bsd.benefitSummaryID == summary_id)
                                                    {
                                                        benefitsummaryrate_table.Rows.Add();
                                                        benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][0] = section;
                                                        if (new_rate.rateID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][1] = new_rate.rateID.ToString();
                                                        if (bsd.benefitSummaryID != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][2] = bsd.benefitSummaryID.ToString();
                                                        if (bsd.description != null) benefitsummaryrate_table.Rows[benefitsummaryrate_row_counter][3] = bsd.description.ToString();
                                                        benefitsummaryrate_row_counter++;

                                                    }
                                                }

                                            }
                                            #endregion


                                            if (new_rate.rateFieldValues != null)
                                            {
                                                foreach (BP_BrokerConnectV4.RateFieldValue rfv in new_rate.rateFieldValues)
                                                {

                                                    #region ratefield_table
                                                    ratefieldvalue_table.Rows.Add();
                                                    ratefieldvalue_table.Rows[ratefieldvalue_row_counter][0] = section;
                                                    if (new_rate.rateID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][1] = new_rate.rateID.ToString();
                                                    if (rfv.rateFieldValueID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][2] = rfv.rateFieldValueID.ToString();
                                                    if (rfv.rateField.rateFieldID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][3] = rfv.rateField.rateFieldID.ToString();
                                                    if (rfv.rateField.label != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][4] = rfv.rateField.label.ToString();
                                                    if (rfv.rateField.fieldType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][5] = rfv.rateField.fieldType.ToString();
                                                    if (rfv.rateField.fieldValueType != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][6] = rfv.rateField.fieldValueType.ToString();

                                                    if (rfv.multiValueIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][7] = rfv.multiValueIndex.ToString();

                                                    // Added decimal condition (01 Sept 2016) - Vaibhav Raut: For checking if the value is having only 1 digit after decimal point, if only 1 digit is available then format it upto 2 digits after decimal point
                                                    if (!string.IsNullOrEmpty(Convert.ToString(rfv.valueNum)))
                                                    {
                                                        if (rfv.valueNum.ToString().Substring(rfv.valueNum.ToString().IndexOf(".") + 1).Length == 1)
                                                        {
                                                            if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = String.Format("{0:0.00}", Convert.ToDecimal(rfv.valueNum.ToString()));
                                                        }
                                                        else
                                                        {
                                                            if (rfv.valueNum != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][8] = Convert.ToDecimal(rfv.valueNum.ToString());
                                                        }
                                                    }
                                                    if (rfv.valueText != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][9] = rfv.valueText.ToString();



                                                    if (rfv.rateTier != null)
                                                    {

                                                        if (rfv.rateTier.rateTierID != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][10] = rfv.rateTier.rateTierID.ToString();
                                                        // Replacing "EE" with Employee for all the templates for rate 
                                                        if (rfv.rateTier.description.ToString() == "EE")
                                                        {
                                                            if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString().Replace("EE", "Employee");
                                                        }
                                                        else
                                                        {


                                                            if (rfv.rateTier.description != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = rfv.rateTier.description.ToString();

                                                        }
                                                        if (rfv.rateTier.allowIncludeEE != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][12] = rfv.rateTier.allowIncludeEE.ToString();
                                                    }
                                                    else
                                                    {
                                                        if (rfv.rateField.rateFieldGroup.description.ToString().Trim() == "Dependent Child Life")
                                                        {
                                                            ratefieldvalue_table.Rows[ratefieldvalue_row_counter][11] = "Dependent Child Life";
                                                        }



                                                    }

                                                    if (rfv.ageBandIndex != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][13] = rfv.ageBandIndex.ToString();
                                                    if (rfv.ageBandGender != null) ratefieldvalue_table.Rows[ratefieldvalue_row_counter][14] = rfv.ageBandGender.ToString();
                                                    ratefieldvalue_table.Rows[ratefieldvalue_row_counter][15] = summary_id;

                                                    #endregion

                                                    #region ratefieldoption_table
                                                    if (rfv.rateField.optionValues != null)
                                                    {
                                                        foreach (BP_BrokerConnectV4.RateOptionValue rov in rfv.rateField.optionValues)
                                                        {
                                                            rateoptionvalue_table.Rows.Add();
                                                            rateoptionvalue_table.Rows[rateoptionvalue_row_counter][0] = section;
                                                            if (new_rate.rateID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][1] = new_rate.rateID.ToString();
                                                            if (rov.rateOptionValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][2] = rov.rateOptionValueID.ToString();
                                                            if (rov.description != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][3] = rov.description.ToString();
                                                            if (rfv.rateFieldValueID != null) rateoptionvalue_table.Rows[rateoptionvalue_row_counter][4] = rfv.rateFieldValueID.ToString();
                                                            rateoptionvalue_row_counter++;

                                                        }
                                                    }
                                                    #endregion

                                                    ratefieldvalue_row_counter++;
                                                }

                                            }
                                            rate_row_counter++;

                                            //}
                                        }


                                    }
                                }
                            }
                        }
                    }
                }

                RateDS.Tables.Add(rateoptionvalue_table);
                RateDS.Tables[0].TableName = "RateOptionValueTable";
                RateDS.Tables.Add(ratefieldvalue_table);
                RateDS.Tables[1].TableName = "RateFieldValueTable";
                RateDS.Tables.Add(benefitsummaryrate_table);
                RateDS.Tables[2].TableName = "BenefitSummaryRateTable";
                RateDS.Tables.Add(rate_table_revenue);
                RateDS.Tables[3].TableName = "RateTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }


            return RateDS;

        }

        public Int32 GetProductDetail_Letters(int product_id, string SessionId)
        {
            int carriedID = 0;

            BP_BrokerConnectV4.Product new_product = new BP_BrokerConnectV4.Product();
            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();

            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            string planNumber = string.Empty;

            try
            {
                new_product = new BP_BrokerConnectV4.Product();
                new_product = new_connection.getProduct(product_id);

                if (new_product != null)
                {
                    if (new_product.carrierID != null) carriedID = Convert.ToInt32(new_product.carrierID);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return carriedID;
        }

        #region Added by vinod for round off value showing as it is

        /// <summary>
        /// Get benefit summary detail from  BP_BrokerConnectV4 web service using getBenefitSummary webmethod. 
        /// </summary>
        /// <param name="PlanTable">Plan table contain selected plan.</param>
        /// <param name="SessionId">Session Id of Login User.</param>
        /// <returns>BenefitSummary data</returns>
        public DataSet GetBenefitSummary_V2(DataTable PlanTable, string SessionId)//int account_id, int product_id, string section, int summary_id)
        {

            bool dollars = false;
            DataSet BenifitSumamryDS = new DataSet();


            int benefitsummary_row_counter = 0;
            int attributevalue_row_counter = 0;
            int attributevaluedetail_row_counter = 0;


            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            new_connection.Timeout = 14400000; //4hours
            BP_BrokerConnectV4.BenefitSummarySearchCriteria new_benefits_search = new BP_BrokerConnectV4.BenefitSummarySearchCriteria();
            BP_BrokerConnectV4.BenefitSummaryDescription[] new_benefit_description_summary = new BP_BrokerConnectV4.BenefitSummaryDescription[0];
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();


            SIH.sessionId = SessionId;//myloginresult.sessionID;
            new_connection.SessionIdHeaderValue = SIH;
            try
            {

                foreach (DataRow dr in PlanTable.Rows)
                {
                    string section = dr["PlanType"].ToString();
                    int summary_id = Convert.ToInt32(dr["SummaryId"].ToString());

                    if (summary_id > 0)
                    {
                        #region BenefitSummaryDescription

                        BP_BrokerConnectV4.BenefitSummary new_benefitsummary = new BP_BrokerConnectV4.BenefitSummary();

                        new_benefitsummary = new_connection.getBenefitSummary(summary_id);


                        #region benfitsummary_table

                        benefitsummary_table.Rows.Add();

                        benefitsummary_table.Rows[benefitsummary_row_counter][0] = section;
                        benefitsummary_table.Rows[benefitsummary_row_counter][1] = new_benefitsummary.benefitSummaryID;
                        if (new_benefitsummary.productID != null) benefitsummary_table.Rows[benefitsummary_row_counter][2] = new_benefitsummary.productID;
                        if (new_benefitsummary.description != null) benefitsummary_table.Rows[benefitsummary_row_counter][3] = new_benefitsummary.description;
                        if (new_benefitsummary.viewLevelID != null) benefitsummary_table.Rows[benefitsummary_row_counter][4] = new_benefitsummary.viewLevelID;
                        if (new_benefitsummary.lastModifiedOn != null && new_benefitsummary.lastModifiedOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][5] = new_benefitsummary.lastModifiedOn;
                        if (new_benefitsummary.createdOn != null && new_benefitsummary.createdOn.Year != 1) benefitsummary_table.Rows[benefitsummary_row_counter][6] = new_benefitsummary.createdOn;

                        benefitsummary_row_counter++;
                        #endregion


                        if (new_benefitsummary.attributeValues != null)
                        {
                            foreach (BP_BrokerConnectV4.AttributeValue AV in new_benefitsummary.attributeValues)
                            {
                                #region attributevalue_table
                                attributevalue_table.Rows.Add();
                                attributevalue_table.Rows[attributevalue_row_counter][0] = section;
                                attributevalue_table.Rows[attributevalue_row_counter][1] = new_benefitsummary.benefitSummaryID;
                                attributevalue_table.Rows[attributevalue_row_counter][2] = AV.attributeID;
                                if (AV.attributeVisibility != null) attributevalue_table.Rows[attributevalue_row_counter][3] = AV.attributeVisibility;
                                if (AV.rider != null && AV.rider.ToString().ToUpper() != "NONE_SELECTED") attributevalue_table.Rows[attributevalue_row_counter][4] = AV.rider;
                                attributevalue_row_counter++;

                                #endregion

                                if (AV.attributeValueDetails != null)
                                {
                                    foreach (BP_BrokerConnectV4.AttributeValueDetail AVD in AV.attributeValueDetails)
                                    {
                                        #region attributevaluedetail_table
                                        attributevaluedetail_table.Rows.Add();
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][0] = section;
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][1] = new_benefitsummary.benefitSummaryID;
                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][2] = AV.attributeID;
                                        if (AVD.ancillaryText != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][3] = AVD.ancillaryText;
                                        if (AVD.exclusionsLimitations != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][4] = AVD.exclusionsLimitations;

                                        attributevaluedetail_table.Rows[attributevaluedetail_row_counter][8] = "";

                                        if (AVD.UOM != null)
                                        {
                                            attributevaluedetail_table.Rows[attributevaluedetail_row_counter][5] = AVD.UOM;



                                            if (AVD.UOM.ToString() == "dollars")
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "$";
                                                dollars = true;
                                            }
                                            else if (AVD.UOM.ToString() == "percent")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "%";
                                            else if (AVD.UOM.ToString() == "days")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " days";
                                            else if (AVD.UOM.ToString() == "months")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " months";
                                            else if (AVD.UOM.ToString() == "X_salary")
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = " X salary";

                                            else
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][9] = "";
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][10] = "";
                                            }
                                        }
                                        if (AVD.value != null)
                                        {
                                            string FinalValue = AVD.value;


                                            if (dollars == true)
                                            {
                                                if (AVD.value.Contains("."))
                                                {
                                                    string[] strADVParts = AVD.value.Split('.');
                                                    if (strADVParts.Length > 1)
                                                    {
                                                        decimal dcDecimalValue = decimal.Parse(strADVParts[1]);
                                                        if (dcDecimalValue <= 0)
                                                        {
                                                            FinalValue = strADVParts[0];
                                                        }
                                                    }

                                                }
                                                //Addde this code to truncate decimal places to 2 decimal only without round up and even after truncate value is x.00
                                                // Requested by Nocole on 23rd June 2018
                                                string AttrDOllarValue = Get2DecimalTruncatedValue(AVD.value);
                                                //Commented by Vinod
                                                //attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = String.Format("{0:n}", Convert.ToDouble(AVD.value)).Substring(0, (String.Format("{0:n}", Convert.ToDouble(AVD.value)).Length) - 3);
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AttrDOllarValue;//String.Format("{0:n}", Convert.ToDouble(FinalValue)).Substring(0, (String.Format("{0:n}", Convert.ToDouble(FinalValue)).Length) - 3);
                                                dollars = false;

                                            }
                                            else if (AVD.value.Contains(".0"))
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.Substring(0, AVD.value.Length - 2).ToString();
                                            }
                                            else
                                            {
                                                attributevaluedetail_table.Rows[attributevaluedetail_row_counter][6] = AVD.value.ToString();
                                            }


                                        }
                                        if (AVD.benefitColumnID != null) attributevaluedetail_table.Rows[attributevaluedetail_row_counter][7] = AVD.benefitColumnID;

                                        attributevaluedetail_row_counter++;

                                        #endregion
                                        //break;
                                    }
                                }
                            }

                        }


                        #endregion
                    }






                }
                BenifitSumamryDS.Tables.Add(benefitsummary_table);
                BenifitSumamryDS.Tables[0].TableName = "BenefitSummaryTable";

                BenifitSumamryDS.Tables.Add(attributevalue_table);
                BenifitSumamryDS.Tables[1].TableName = "AttributeValueTable";
                BenifitSumamryDS.Tables.Add(attributevaluedetail_table);
                BenifitSumamryDS.Tables[2].TableName = "AttributeValueDetailTable";

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return BenifitSumamryDS;
        }

        private string Get2DecimalTruncatedValue(string strValue)
        {
            CommonFunctionsBS comFunObj = new CommonFunctionsBS();
            string FinalValue = strValue;
            if (strValue.Contains("."))
            {
                string[] strADVParts = strValue.Split('.');
                if (strADVParts.Length > 1)
                {
                    decimal dcDecimalValue = decimal.Parse(strADVParts[1]);
                    if (dcDecimalValue <= 0)
                    {
                        FinalValue = strADVParts[0];
                    }
                    else
                    {
                        if (strADVParts[1].Length == 1)
                        {
                            FinalValue = strADVParts[0] + "." + strADVParts[1] + "0";
                        }
                        else if (strADVParts[1].Length > 2)
                        {
                            strADVParts[1] = strADVParts[1].Substring(0, 2);
                            FinalValue = strADVParts[0] + "." + strADVParts[1];
                        }
                    }
                }

            }

            // To format the value to thousand separate
            return comFunObj.GetBenefitFormattedValue(FinalValue);
        }

        #endregion

        #region ADDED NEW METHOD FOR GETTING DEPARTMENT DETAIL
        /// <summary>
        /// This method is added  by Amogh - which return all department id's
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> getDepartmentDetails()
        {
            Dictionary<string, string> DictDepartment = new Dictionary<string, string>();
            try
            {

                string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                DataTable DepartmentTable = new DataTable();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter("GetDepartments", con))
                    {
                        adapter.Fill(DepartmentTable);
                    }
                }
                DictDepartment.Clear();
                foreach (DataRow row in DepartmentTable.Rows)
                {
                    DictDepartment.Add(row["department_id"].ToString(), row["department_name"].ToString());
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return DictDepartment;
        }
        #endregion


        internal void makeboldtabletext(Microsoft.Office.Interop.Word.Document oWordDoc, Microsoft.Office.Interop.Word.Application oWordApp, string[] makeBold, int DentalTableNo)
        {
            foreach (string s in makeBold)
            {
                oWordDoc.Tables[DentalTableNo].Select();
                oWordApp.Selection.Find.Text = s; //changes with each iteration
                oWordApp.Selection.Find.Execute();
                oWordApp.Selection.Font.Bold = 1;
                oWordApp.Selection.Collapse(); //used to 'clear' the selection
                oWordApp.Selection.Find.ClearFormatting();
            }
        }
        public DataSet GetAccountDetail_BenefitSummary(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();

            DataSet AccountDS = new DataSet();
            int account_row_counter = 0;
            int accountCustomFieldValues_row_counter = 0;
            int accountEmployeeType_row_counter = 0;

            BuildAccountTable();
            BuildEmployeeTypesTable();

            try
            {

                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;
                new_account = new_connection.getAccount(account_id);
                string website = string.Empty;

                if (new_account != null)
                {
                    #region account_table
                    website = new_account.groupAccountInfo.commonGroupAccountInfo.website;
                    account_table.Rows.Add();
                    account_table.Rows[account_row_counter][0] = new_account.accountID;
                    if (new_account.active != null && new_account.active.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][1] = new_account.active.ToString();
                    if (new_account.inactiveAsOf != null && new_account.inactiveAsOf.Year != 1) account_table.Rows[account_row_counter][2] = new_account.inactiveAsOf;
                    if (new_account.inactiveReason != null) account_table.Rows[account_row_counter][3] = new_account.inactiveReason.ToString();
                    if (new_account.accountClassification != null) account_table.Rows[account_row_counter][4] = new_account.accountClassification.ToString();
                    if (new_account.accountType != null) account_table.Rows[account_row_counter][5] = new_account.accountType.ToString();
                    if (new_account.officeID != null) account_table.Rows[account_row_counter][6] = new_account.officeID.ToString();
                    if (new_account.departmentID != null) account_table.Rows[account_row_counter][7] = new_account.departmentID.ToString();
                    if (new_account.administratorUserID != null) account_table.Rows[account_row_counter][8] = new_account.administratorUserID.ToString();
                    if (new_account.primaryContactUserID != null) account_table.Rows[account_row_counter][9] = new_account.primaryContactUserID.ToString();
                    if (new_account.primarySalesLeadUserID != null) account_table.Rows[account_row_counter][10] = new_account.primarySalesLeadUserID.ToString();
                    if (new_account.primaryServiceLeadUserID != null) account_table.Rows[account_row_counter][11] = new_account.primaryServiceLeadUserID.ToString();
                    if (new_account.notes != null) account_table.Rows[account_row_counter][12] = new_account.notes.ToString();
                    if (new_account.lastReviewedByUserID != null) account_table.Rows[account_row_counter][13] = new_account.lastReviewedByUserID.ToString();
                    if (new_account.lastReviewedOn != null && new_account.lastReviewedOn.Year != 1) account_table.Rows[account_row_counter][14] = new_account.lastReviewedOn.ToString();
                    if (new_account.createdOn != null && new_account.createdOn.Year != 1) account_table.Rows[account_row_counter][15] = new_account.createdOn.ToString();
                    if (new_account.lastModifiedOn != null && new_account.lastModifiedOn.Year != 1) account_table.Rows[account_row_counter][16] = new_account.lastModifiedOn.ToString();



                    if (new_account.mainAddress != null)
                    {
                        if (new_account.mainAddress.street1 != null) account_table.Rows[account_row_counter][18] = new_account.mainAddress.street1.ToString();
                        if (new_account.mainAddress.street2 != null) account_table.Rows[account_row_counter][19] = new_account.mainAddress.street2.ToString();
                        if (new_account.mainAddress.city != null) account_table.Rows[account_row_counter][20] = new_account.mainAddress.city.ToString();
                        if (new_account.mainAddress.state != null) account_table.Rows[account_row_counter][21] = new_account.mainAddress.state.ToString();
                        if (new_account.mainAddress.zip != null) account_table.Rows[account_row_counter][22] = new_account.mainAddress.zip.ToString();
                        if (new_account.mainAddress.country != null) account_table.Rows[account_row_counter][23] = new_account.mainAddress.country.ToString().Replace("_", " ");
                    }

                    if (new_account.billingAddress != null)
                    {
                        if (new_account.billingAddress.street1 != null) account_table.Rows[account_row_counter][24] = new_account.billingAddress.street1.ToString();
                        if (new_account.billingAddress.street2 != null) account_table.Rows[account_row_counter][25] = new_account.billingAddress.street2.ToString();
                        if (new_account.billingAddress.city != null) account_table.Rows[account_row_counter][26] = new_account.billingAddress.city.ToString();
                        if (new_account.billingAddress.state != null) account_table.Rows[account_row_counter][27] = new_account.billingAddress.state.ToString();
                        if (new_account.billingAddress.zip != null) account_table.Rows[account_row_counter][28] = new_account.billingAddress.zip.ToString();
                        if (new_account.billingAddress.country != null) account_table.Rows[account_row_counter][29] = new_account.billingAddress.country.ToString().Replace("_", " ");


                    }

                    if (new_account.mailingAddress != null)
                    {
                        if (new_account.mailingAddress.street1 != null) account_table.Rows[account_row_counter][30] = new_account.mailingAddress.street1.ToString();
                        if (new_account.mailingAddress.street2 != null) account_table.Rows[account_row_counter][31] = new_account.mailingAddress.street2.ToString();
                        if (new_account.mailingAddress.city != null) account_table.Rows[account_row_counter][32] = new_account.mailingAddress.city.ToString();
                        if (new_account.mailingAddress.state != null) account_table.Rows[account_row_counter][33] = new_account.mailingAddress.state.ToString();
                        if (new_account.mailingAddress.zip != null) account_table.Rows[account_row_counter][34] = new_account.mailingAddress.zip.ToString();
                        if (new_account.mailingAddress.country != null) account_table.Rows[account_row_counter][35] = new_account.mailingAddress.country.ToString().Replace("_", " ");

                    }

                    if (new_account.groupAccountInfo != null)
                    {

                        if (new_account.groupAccountInfo.accountName != null) account_table.Rows[account_row_counter][36] = new_account.groupAccountInfo.accountName.ToString();
                        if (new_account.groupAccountInfo.DBA != null) account_table.Rows[account_row_counter][37] = new_account.groupAccountInfo.DBA.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][38] = new_account.groupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.groupAccountInfo.numberOfFTEsAsOf != null) account_table.Rows[account_row_counter][39] = new_account.groupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.groupAccountInfo.marketSize != null) account_table.Rows[account_row_counter][40] = new_account.groupAccountInfo.marketSize.ToString();
                        if (new_account.groupAccountInfo.businessType != null) account_table.Rows[account_row_counter][41] = new_account.groupAccountInfo.businessType.ToString();
                        if (new_account.groupAccountInfo.SICCode != null) account_table.Rows[account_row_counter][42] = new_account.groupAccountInfo.SICCode.ToString();
                        if (new_account.groupAccountInfo.NAICSCode != null) account_table.Rows[account_row_counter][43] = new_account.groupAccountInfo.NAICSCode.ToString();
                        if (new_account.groupAccountInfo.requires5500 != null && new_account.groupAccountInfo.requires5500.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][44] = new_account.groupAccountInfo.requires5500.ToString();
                        if (new_account.groupAccountInfo.locationsByZip != null) account_table.Rows[account_row_counter][45] = new_account.groupAccountInfo.locationsByZip.ToString();
                        if (new_account.groupAccountInfo.affiliates != null) account_table.Rows[account_row_counter][46] = new_account.groupAccountInfo.affiliates.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][47] = new_account.groupAccountInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.groupAccountInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][48] = new_account.groupAccountInfo.budgetedTotalAnnualRevenue.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCycles != null && new_account.groupAccountInfo.multiplePayrollCycles.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][49] = new_account.groupAccountInfo.multiplePayrollCycles.ToString();
                        if (new_account.groupAccountInfo.multiplePayrollCyclesDifferBy != null) account_table.Rows[account_row_counter][50] = new_account.groupAccountInfo.multiplePayrollCyclesDifferBy.ToString();
                        if (new_account.groupAccountInfo.singlePayrollCycle != null) account_table.Rows[account_row_counter][51] = new_account.groupAccountInfo.singlePayrollCycle.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][52] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][53] = new_account.groupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][54] = new_account.groupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][55] = new_account.groupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][56] = new_account.groupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][57] = new_account.groupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][58] = new_account.groupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][59] = new_account.groupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][60] = new_account.groupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][61] = new_account.groupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][62] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.Year != 1) account_table.Rows[account_row_counter][63] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][64] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][65] = new_account.groupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalents != null) account_table.Rows[account_row_counter][145] = new_account.groupAccountInfo.numberOfFullTimeEquivalents.ToString();
                        if (new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate != null) account_table.Rows[account_row_counter][146] = new_account.groupAccountInfo.numberOfFullTimeEquivalentsAsOfDate.ToString();

                        if (new_account.groupAccountInfo.accountIntegrationInfo != null)
                        {

                            if (new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID != null)
                                account_table.Rows[account_row_counter][140] = new_account.groupAccountInfo.accountIntegrationInfo.sagittaClientID;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.sourceCode != null)
                                account_table.Rows[account_row_counter][141] = new_account.groupAccountInfo.accountIntegrationInfo.sourceCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode != null)
                                account_table.Rows[account_row_counter][142] = new_account.groupAccountInfo.accountIntegrationInfo.primarySalesLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode != null)
                                account_table.Rows[account_row_counter][143] = new_account.groupAccountInfo.accountIntegrationInfo.primaryServiceLeadIntCode;
                            if (new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer != null)
                                account_table.Rows[account_row_counter][144] = new_account.groupAccountInfo.accountIntegrationInfo.TAMCustomer;


                        }

                    }


                    if (new_account.individualAccountInfo != null)
                    {
                        if (new_account.individualAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][66] = new_account.individualAccountInfo.personInfo.firstName.ToString();
                        if (new_account.individualAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][67] = new_account.individualAccountInfo.personInfo.middleName.ToString();
                        if (new_account.individualAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][68] = new_account.individualAccountInfo.personInfo.lastName.ToString();
                        if (new_account.individualAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][69] = new_account.individualAccountInfo.personInfo.salutation.ToString();
                        if (new_account.individualAccountInfo.personInfo.dateOfBirth != null && new_account.individualAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][70] = new_account.individualAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.individualAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][71] = new_account.individualAccountInfo.personInfo.gender.ToString();
                        if (new_account.individualAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][72] = new_account.individualAccountInfo.personInfo.ssn.ToString();
                        if (new_account.individualAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][73] = new_account.individualAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.individualAccountInfo.email != null) account_table.Rows[account_row_counter][74] = new_account.individualAccountInfo.email.ToString();
                        if (new_account.individualAccountInfo.phone.areaCode != null) account_table.Rows[account_row_counter][75] = new_account.individualAccountInfo.phone.areaCode.ToString();
                        if (new_account.individualAccountInfo.phone.number != null) account_table.Rows[account_row_counter][76] = new_account.individualAccountInfo.phone.number.ToString();
                        if (new_account.individualAccountInfo.phone.type != null) account_table.Rows[account_row_counter][77] = new_account.individualAccountInfo.phone.type.ToString();
                        if (new_account.individualAccountInfo.affiliatedGroupAccountID != null) account_table.Rows[account_row_counter][78] = new_account.individualAccountInfo.affiliatedGroupAccountID.ToString();

                    }



                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.marketingGroupName != null) account_table.Rows[account_row_counter][79] = new_account.marketingGroupAccountInfo.marketingGroupName.ToString();
                        if (new_account.marketingGroupAccountInfo.marketingGroupType != null) account_table.Rows[account_row_counter][80] = new_account.marketingGroupAccountInfo.marketingGroupType.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEs != null) account_table.Rows[account_row_counter][81] = new_account.marketingGroupAccountInfo.numberOfFTEs.ToString();
                        if (new_account.marketingGroupAccountInfo.numberOfFTEsAsOf != null && new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.Year != 1) account_table.Rows[account_row_counter][82] = new_account.marketingGroupAccountInfo.numberOfFTEsAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.associatedAccountIDs != null) account_table.Rows[account_row_counter][83] = new_account.marketingGroupAccountInfo.associatedAccountIDs.ToString();

                    }

                    if (new_account.agencyAccountInfo != null)
                    {
                        if (new_account.agencyAccountInfo.agencyName != null) account_table.Rows[account_row_counter][84] = new_account.agencyAccountInfo.agencyName.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.email != null) account_table.Rows[account_row_counter][85] = new_account.agencyAccountInfo.agencyInfo.email.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][86] = new_account.agencyAccountInfo.agencyInfo.phone1.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][87] = new_account.agencyAccountInfo.agencyInfo.phone2.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][88] = new_account.agencyAccountInfo.agencyInfo.phone3.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][89] = new_account.agencyAccountInfo.agencyInfo.phone4.areaCode.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.number != null) account_table.Rows[account_row_counter][90] = new_account.agencyAccountInfo.agencyInfo.phone1.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.number != null) account_table.Rows[account_row_counter][91] = new_account.agencyAccountInfo.agencyInfo.phone2.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.number != null) account_table.Rows[account_row_counter][92] = new_account.agencyAccountInfo.agencyInfo.phone3.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.number != null) account_table.Rows[account_row_counter][93] = new_account.agencyAccountInfo.agencyInfo.phone4.number.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone1.type != null) account_table.Rows[account_row_counter][94] = new_account.agencyAccountInfo.agencyInfo.phone1.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone2.type != null) account_table.Rows[account_row_counter][95] = new_account.agencyAccountInfo.agencyInfo.phone2.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone3.type != null) account_table.Rows[account_row_counter][96] = new_account.agencyAccountInfo.agencyInfo.phone3.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.phone4.type != null) account_table.Rows[account_row_counter][97] = new_account.agencyAccountInfo.agencyInfo.phone4.type.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.taxPayerID != null) account_table.Rows[account_row_counter][98] = new_account.agencyAccountInfo.agencyInfo.taxPayerID.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][99] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][100] = new_account.agencyAccountInfo.agencyInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.agentAccountInfo != null)
                    {
                        if (new_account.agentAccountInfo.personInfo.firstName != null) account_table.Rows[account_row_counter][101] = new_account.agentAccountInfo.personInfo.firstName.ToString();
                        if (new_account.agentAccountInfo.personInfo.middleName != null) account_table.Rows[account_row_counter][102] = new_account.agentAccountInfo.personInfo.middleName.ToString();
                        if (new_account.agentAccountInfo.personInfo.lastName != null) account_table.Rows[account_row_counter][103] = new_account.agentAccountInfo.personInfo.lastName.ToString();
                        if (new_account.agentAccountInfo.personInfo.salutation != null) account_table.Rows[account_row_counter][104] = new_account.agentAccountInfo.personInfo.salutation.ToString();
                        if (new_account.agentAccountInfo.personInfo.dateOfBirth != null && new_account.agentAccountInfo.personInfo.dateOfBirth.Year != 1) account_table.Rows[account_row_counter][105] = new_account.agentAccountInfo.personInfo.dateOfBirth.ToString();
                        if (new_account.agentAccountInfo.personInfo.gender != null) account_table.Rows[account_row_counter][106] = new_account.agentAccountInfo.personInfo.gender.ToString();
                        if (new_account.agentAccountInfo.personInfo.ssn != null) account_table.Rows[account_row_counter][107] = new_account.agentAccountInfo.personInfo.ssn.ToString();
                        if (new_account.agentAccountInfo.personInfo.maritalStatus != null) account_table.Rows[account_row_counter][108] = new_account.agentAccountInfo.personInfo.maritalStatus.ToString();
                        if (new_account.agentAccountInfo.agencyAccountID != null) account_table.Rows[account_row_counter][109] = new_account.agentAccountInfo.agencyAccountID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.email != null) account_table.Rows[account_row_counter][110] = new_account.agentAccountInfo.agentInfo.email.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.areaCode != null) account_table.Rows[account_row_counter][111] = new_account.agentAccountInfo.agentInfo.phone1.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.areaCode != null) account_table.Rows[account_row_counter][112] = new_account.agentAccountInfo.agentInfo.phone2.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.areaCode != null) account_table.Rows[account_row_counter][113] = new_account.agentAccountInfo.agentInfo.phone3.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.areaCode != null) account_table.Rows[account_row_counter][114] = new_account.agentAccountInfo.agentInfo.phone4.areaCode.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.number != null) account_table.Rows[account_row_counter][115] = new_account.agentAccountInfo.agentInfo.phone1.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.number != null) account_table.Rows[account_row_counter][116] = new_account.agentAccountInfo.agentInfo.phone2.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.number != null) account_table.Rows[account_row_counter][117] = new_account.agentAccountInfo.agentInfo.phone3.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.number != null) account_table.Rows[account_row_counter][118] = new_account.agentAccountInfo.agentInfo.phone4.number.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone1.type != null) account_table.Rows[account_row_counter][119] = new_account.agentAccountInfo.agentInfo.phone1.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone2.type != null) account_table.Rows[account_row_counter][120] = new_account.agentAccountInfo.agentInfo.phone2.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone3.type != null) account_table.Rows[account_row_counter][121] = new_account.agentAccountInfo.agentInfo.phone3.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.phone4.type != null) account_table.Rows[account_row_counter][122] = new_account.agentAccountInfo.agentInfo.phone4.type.ToString();
                        if (new_account.agentAccountInfo.agentInfo.taxPayerID != null) account_table.Rows[account_row_counter][123] = new_account.agentAccountInfo.agentInfo.taxPayerID.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium != null) account_table.Rows[account_row_counter][124] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualPremium.ToString();
                        if (new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue != null) account_table.Rows[account_row_counter][125] = new_account.agentAccountInfo.agentInfo.budgetedTotalAnnualRevenue.ToString();

                    }


                    if (new_account.marketingGroupAccountInfo != null)
                    {
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees != null) account_table.Rows[account_row_counter][126] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetirees.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.Year != 1) account_table.Rows[account_row_counter][127] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.numberOfRetireesAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished != null) account_table.Rows[account_row_counter][128] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.yearEstablished.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType != null) account_table.Rows[account_row_counter][129] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.accountFundingType.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry != null) account_table.Rows[account_row_counter][130] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.primaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry != null) account_table.Rows[account_row_counter][131] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.secondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry != null) account_table.Rows[account_row_counter][132] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherPrimaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry != null) account_table.Rows[account_row_counter][133] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.otherSecondaryIndustry.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID != null) account_table.Rows[account_row_counter][134] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.taxpayerID.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website != null) account_table.Rows[account_row_counter][135] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.website.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber != null) account_table.Rows[account_row_counter][136] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.accountNumber.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf != null) account_table.Rows[account_row_counter][137] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.brokerOfRecordAsOf.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString().ToUpper() != "NONE_SELECTED") account_table.Rows[account_row_counter][138] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAARequired.ToString();
                        if (new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn != null && new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.Year != 1) account_table.Rows[account_row_counter][139] = new_account.marketingGroupAccountInfo.commonGroupAccountInfo.brokerageAccountInfo.HIPAASignedOn.ToString();

                    }

                    #endregion

                    if (new_account.accountCustomFieldValues != null)
                    {
                        #region accountCustomFieldValues_table

                        foreach (BP_BrokerConnectV4.CustomFieldValue cfv in new_account.accountCustomFieldValues)
                        {
                            accountCustomFieldValues_table.Rows.Add();
                            accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][0] = new_account.accountID;
                            if (cfv.customFieldValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][1] = cfv.customFieldValueID;
                            if (cfv.customFieldID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][2] = cfv.customFieldID;
                            if (cfv.optionValueID != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][3] = cfv.optionValueID;
                            if (cfv.valueText != null) accountCustomFieldValues_table.Rows[accountCustomFieldValues_row_counter][4] = cfv.valueText;
                            accountCustomFieldValues_row_counter++;

                        }

                        #endregion
                    }

                    #region EmployeeType Table
                    if (new_account.groupAccountInfo.employeeTypes != null)
                    {
                        if (new_account.groupAccountInfo.employeeTypes.Count() > 0)
                        {
                            foreach (BP_BrokerConnectV4.EmployeeType cfv in new_account.groupAccountInfo.employeeTypes)
                            {
                                accountEmployeeTypesValues_table.Rows.Add();
                                accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][0] = new_account.accountID;
                                if (cfv.employeeTypeID != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][1] = cfv.employeeTypeID;
                                if (cfv.status != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][2] = cfv.status;
                                if (cfv.type != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][3] = cfv.type;
                                if (cfv.value != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][4] = cfv.value;
                                if (cfv.unitOfMeasureSpecified != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][5] = cfv.unitOfMeasure;
                                if (cfv.frequency != null) accountEmployeeTypesValues_table.Rows[accountEmployeeType_row_counter][6] = cfv.frequency;
                                accountEmployeeType_row_counter++;
                            }
                        }
                    }
                    #endregion

                    account_row_counter++;
                }

                AccountDS.Tables.Add(accountCustomFieldValues_table);
                AccountDS.Tables[0].TableName = "AccountCustomFieldValuesTable";
                AccountDS.Tables.Add(account_table);
                AccountDS.Tables[1].TableName = "AccountTable";
                AccountDS.Tables.Add(accountEmployeeTypesValues_table);
                AccountDS.Tables[2].TableName = "EmployeeTypeTable";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }

            return AccountDS;
        }

        public DataTable GetEligibilityRule_BenefitSummary(DataTable PlanTable, string SessionId, int EleigibilityRuleId)//(int product_id, string section, int summary_id)
        {


            int eligibilityrule_row_counter = 0;
            int employeeTypeIDs_row_counter = 0;

            //Eligibility Rule
            DataTable eligibilityrule_tableAccountProfile = new DataTable();
            DataTable employeeTypeIDs_table = new DataTable();
            DataTable employeetype_table = new DataTable();
            DataSet EligibilityDS = new DataSet();
            eligibilityrule_tableAccountProfile.Columns.Add("section", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("eligibilityRuleID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("productID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("planDesignID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("description", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("active", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("suffixNum", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("waiver", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("frozenEnrollment", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("frozenEnrollmentEffectiveAsOf", typeof(DateTime));
            eligibilityrule_tableAccountProfile.Columns.Add("coverageEndDate", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("ageAsOf", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("notes", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("benefitSummaryID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("rateID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("contributionID", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeEligibilityRule_nonHighlyCompensated", typeof(bool));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeEligibilityRule_dependentEligibilityRule_childCriteria_ageLimit", typeof(Int32));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerType", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_domesticPartnerTypeSpecified", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_domesticPartnerCriteria_lengthOfCohabitation", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_ageLimit", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("dependentEligibilityRule_fullTimeStudentCriteria_minimumNumberOfUnitsPerTerm", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("item", typeof(string));
            eligibilityrule_tableAccountProfile.Columns.Add("employeeTypeIDs", typeof(string));

            try
            {
                if (EleigibilityRuleId != 0)
                {
                    BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
                    new_connection.Timeout = 14400000; //4hours
                    BP_BrokerConnectV4.EligibilityRuleSearchCriteria new_eligibilityrule_search = new BP_BrokerConnectV4.EligibilityRuleSearchCriteria();

                    string section = "Medical Plan";

                    BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
                    SIH.sessionId = SessionId;// myloginresult.sessionID;
                    new_connection.SessionIdHeaderValue = SIH;

                    BP_BrokerConnectV4.EligibilityRule new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new BP_BrokerConnectV4.EligibilityRule();

                    new_eligibilityrule = new_connection.getEligibilityRule(EleigibilityRuleId);

                    if (new_eligibilityrule != null)
                    {

                        #region eligibilityrule_tableAccountProfile

                        eligibilityrule_tableAccountProfile.Rows.Add();
                        //eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][0] = section;
                        if (new_eligibilityrule.eligibilityRuleID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][1] = new_eligibilityrule.eligibilityRuleID;
                        if (new_eligibilityrule.productID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][2] = new_eligibilityrule.productID;
                        if (new_eligibilityrule.planDesignID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][3] = new_eligibilityrule.planDesignID;
                        if (new_eligibilityrule.description != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][4] = new_eligibilityrule.description;
                        if (new_eligibilityrule.active != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][5] = new_eligibilityrule.active;
                        if (new_eligibilityrule.suffixNum != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][6] = new_eligibilityrule.suffixNum;
                        if (new_eligibilityrule.waiver != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][7] = new_eligibilityrule.waiver;
                        if (new_eligibilityrule.frozenEnrollment != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][8] = new_eligibilityrule.frozenEnrollment;
                        if (new_eligibilityrule.frozenEnrollmentEffectiveAsOf != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][9] = new_eligibilityrule.frozenEnrollmentEffectiveAsOf;
                        if (new_eligibilityrule.coverageEndDate != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][10] = new_eligibilityrule.coverageEndDate;
                        if (new_eligibilityrule.ageAsOf != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][11] = new_eligibilityrule.ageAsOf;
                        if (new_eligibilityrule.notes != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][12] = new_eligibilityrule.notes;
                        if (new_eligibilityrule.benefitSummaryID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][13] = new_eligibilityrule.benefitSummaryID;
                        if (new_eligibilityrule.rateID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][14] = new_eligibilityrule.rateID;
                        if (new_eligibilityrule.contributionID != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][15] = new_eligibilityrule.contributionID;
                        if (new_eligibilityrule.Item != null)
                        {
                            //if (new_eligibilityrule.Item.ToString() == "BPBenefitSummary.BP_BrokerConnectV4.CustomWaitingPeriod")
                            if (new_eligibilityrule.Item.ToString() == "BenefitPointSummaryPortal.BP_BrokerConnectV4.CustomWaitingPeriod")
                            {
                                BP_BrokerConnectV4.CustomWaitingPeriod cwp = new BP_BrokerConnectV4.CustomWaitingPeriod();
                                cwp = (BP_BrokerConnectV4.CustomWaitingPeriod)new_eligibilityrule.Item;
                                eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = cwp.timeFrame.ToString().Replace("_", " ") + " " + cwp.value.ToString() + " " + cwp.unitOfMeasure.ToString();
                            }
                            else
                            {
                                eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = new_eligibilityrule.Item.ToString().Replace("_", " ");
                            }
                            // eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23] = eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][23].ToString().Replace("DOH", "");
                        }

                        if (new_eligibilityrule.employeeEligibilityRule != null)
                        {
                            if (new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][16] = new_eligibilityrule.employeeEligibilityRule.nonHighlyCompensated;
                            if (new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][24] = new_eligibilityrule.employeeEligibilityRule.employeeTypeIDs[0];


                        }

                        if (new_eligibilityrule.dependentEligibilityRule != null)
                        {
                            if (new_eligibilityrule.dependentEligibilityRule.childCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][17] = new_eligibilityrule.dependentEligibilityRule.childCriteria.ageLimit;
                            }

                            if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][18] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerType.ToString().Replace("_", " ");
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][19] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.domesticPartnerTypeSpecified;
                                if (new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][20] = new_eligibilityrule.dependentEligibilityRule.domesticPartnerCriteria.lengthOfCohabitation;

                            }

                            if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria != null)
                            {
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][21] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.ageLimit;
                                if (new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm != null) eligibilityrule_tableAccountProfile.Rows[eligibilityrule_row_counter][22] = new_eligibilityrule.dependentEligibilityRule.fullTimeStudentCriteria.minimumNumberOfUnitsPerTerm;

                            }
                        }

                        eligibilityrule_row_counter++;
                        #endregion

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return eligibilityrule_tableAccountProfile;
        }

        //Added Method by shravan -- 
        //This method will return DataTable with Region, Office and AnalyticLead Details from AccountID. 
        public DataTable GetAnalyticTeamDetail(int account_id, string SessionId)
        {

            BP_BrokerConnectV4.BrokerConnectV4 new_connection = new BP_BrokerConnectV4.BrokerConnectV4();
            BP_BrokerConnectV4.SessionIdHeader SIH = new BP_BrokerConnectV4.SessionIdHeader();
            BP_BrokerConnectV4.Account new_account = new BP_BrokerConnectV4.Account();
            BP_BrokerConnectV4.Office offData = new BP_BrokerConnectV4.Office();
            int OfficeID = 0;
            DataTable AnalyticTeamDT = new DataTable();

            try
            {
                SIH.sessionId = SessionId;//myloginresult.sessionID;
                new_connection.SessionIdHeaderValue = SIH;
                new_connection.Timeout = 14400000;

                new_account = new_connection.getAccount(account_id);

                if (new_account != null)
                {
                    if (new_account.officeID > 0)
                    {
                        OfficeID = new_account.officeID;
                    }
                }

                if (OfficeID > 0)
                {
                    string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            adapter.SelectCommand = new SqlCommand("SP_GetAnalyticTeamDetail", con);
                            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                            adapter.SelectCommand.Parameters.Add("@OFFICE_ID", SqlDbType.Int).Value = OfficeID;
                            adapter.Fill(AnalyticTeamDT);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString() + " " + ex.StackTrace.ToString());
            }
            return AnalyticTeamDT;
        }
    }
}