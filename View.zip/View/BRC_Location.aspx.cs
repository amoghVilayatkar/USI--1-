﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using BenefitPointSummaryPortal.DAL;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.BAL.BRCInformation;

namespace BenefitPointSummaryPortal.View
{
    
    public partial class BRC_Location : System.Web.UI.Page
    {
        BPSummary bp = new BPSummary();
        DBHelper DB_helper = new DBHelper();
        BRCInformationOperation BRCInformationOps;

        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                GetBRCTimeZoneList();
                BindLocation();
                BindBRCCenterDayHours();
                btnSearch_Click(null, null);
                ddlSearchBRCLocation.Focus();
                mvClientContact.ActiveViewIndex = 0;
                hdnID.Value = "0";
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SearchBRCLocation();
        }

        protected void bntSave_Click(object sender, EventArgs e)
        {
            try
            {
                BRCInformationOps = new BRCInformationOperation();

                bool flag = BRCInformationOps.InsertUpdateBRCLocation(int.Parse(hdnID.Value),txtBRCName.Text.Trim(),ddlBRCLocation.SelectedValue.ToString(),ddlCenterDaysHours.SelectedValue.ToString(),txtPhone.Text.Trim(),
                    txtEmailAddress.Text.Trim(),txtFax.Text.Trim(),ddlBRCTimeZone.SelectedValue.ToString());

                if (flag)
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('BRC Location updated successfully.')</script>", false);
                    mvClientContact.ActiveViewIndex = 0;
                    ClearBRCInformationDetailForm();
                    hdnID.Value = "0";
                    btnSearch_Click(null, null);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while insert/updating record, please try again')</script>", false);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void SearchBRCLocation()
        {
            try
            {                
                string strBRCLocation = ddlSearchBRCLocation.SelectedValue;
                string strPhoneNumber = txtSearchPhone.Text.Trim();

                BRCInformationOps = new BRCInformationOperation();

                DataTable dtblBRCLocation = BRCInformationOps.SearchBRCLocation(strBRCLocation, strPhoneNumber);

                grdBRCLocation.DataSource = dtblBRCLocation;
                grdBRCLocation.DataBind();

                ClearBRCInformationDetailForm();

            }
            catch (Exception ex)
            {

            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            hdnID.Value = "0";
            mvClientContact.ActiveViewIndex = 1;
            txtBRCName.Focus();
            ClearBRCInformationDetailForm();
            bntSave.Text = "Save";
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            mvClientContact.ActiveViewIndex = 0;
           // ddlSearchBRCName.Focus();
            hdnID.Value = "0";

        }
        protected void BtnReset_Click(object sender, EventArgs e)
        {
            mvClientContact.ActiveViewIndex = 0;
            ddlSearchBRCLocation.Focus();
            hdnID.Value = "0";

            ddlSearchBRCLocation.SelectedIndex = 0;
            txtSearchPhone.Text = "";

        }


        private void FillBRCInforamtionDetails(int Id)
        {
            hdnID.Value = Id.ToString();
            BRCInformationOps = new BRCInformationOperation();

            DataTable dtblBRCLocDetails = BRCInformationOps.GetBRCLocationById(Id);

            if (dtblBRCLocDetails != null && dtblBRCLocDetails.Rows.Count > 0)
            {

                txtBRCName.Text = dtblBRCLocDetails.Rows[0]["BRCName"].ToString();

                if (ddlBRCLocation.Items.Contains(new ListItem(dtblBRCLocDetails.Rows[0]["Location"].ToString(), dtblBRCLocDetails.Rows[0]["Location"].ToString())))
                {
                    ddlBRCLocation.SelectedValue = dtblBRCLocDetails.Rows[0]["Location"].ToString();
                }
                else
                {
                    ddlBRCLocation.SelectedIndex = 0;
                }

                if (ddlBRCTimeZone.Items.Contains(new ListItem(dtblBRCLocDetails.Rows[0]["TimeZone"].ToString(), dtblBRCLocDetails.Rows[0]["TimeZone"].ToString())))
                    ddlBRCTimeZone.SelectedValue = dtblBRCLocDetails.Rows[0]["TimeZone"].ToString();
                else
                    ddlBRCTimeZone.SelectedIndex = 0;

                if (ddlCenterDaysHours.Items.Contains(new ListItem(dtblBRCLocDetails.Rows[0]["BRCCenterDaysHours"].ToString(), dtblBRCLocDetails.Rows[0]["BRCCenterDaysHours"].ToString())))
                    ddlCenterDaysHours.SelectedValue = dtblBRCLocDetails.Rows[0]["BRCCenterDaysHours"].ToString();
                else
                    ddlCenterDaysHours.SelectedIndex = 0;

                txtEmailAddress.Text = dtblBRCLocDetails.Rows[0]["Email"].ToString();
                txtPhone.Text = dtblBRCLocDetails.Rows[0]["PhoneNumber"].ToString();
                txtFax.Text = dtblBRCLocDetails.Rows[0]["Fax"].ToString();
                
            }
        }

        protected void grdBRCLocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string RowCommand = e.CommandName;
            if (RowCommand == "EditAddress")
            {
                mvClientContact.ActiveViewIndex = 1;
                ClearBRCInformationDetailForm();
                FillBRCInforamtionDetails(int.Parse(e.CommandArgument.ToString()));
                bntSave.Text = "Update";
            }
            else if (RowCommand == "DeleteAddress")
            {
                try
                {
                    BRCInformationOps = new BRCInformationOperation();
                    bool IsSuccess = BRCInformationOps.DeleteBRCLocationDetails(int.Parse(e.CommandArgument.ToString()));
                    if (IsSuccess)
                    {
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('BRC Location deleted successfully.')</script>", false);
                        btnSearch_Click(null, null);
                    }
                    else
                        ScriptManager.RegisterStartupScript(bntSave, this.GetType(), "alert", "<script>alert('Error occured while deleting record, please try again')</script>", false);
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void ClearBRCInformationDetailForm()
        {
           
            ddlBRCLocation.SelectedIndex = 0;
            ddlBRCTimeZone.SelectedIndex = 0;
            txtEmailAddress.Text = "";
            txtPhone.Text = "";
            txtBRCName.Text = "";
            txtFax.Text ="";
           
        }

        private void BindLocation()
        {
            try
            {
                BRCInformationOperation objBRCInfo = new BRCInformationOperation();
                DataTable dtblLocation = objBRCInfo.GetBRCLocation();

                ddlSearchBRCLocation.DataSource = dtblLocation;
                ddlSearchBRCLocation.DataBind();

                ddlBRCLocation.DataSource = dtblLocation;
                ddlBRCLocation.DataBind();

                
            }
            catch (Exception ex)
            {
            }

        }
        private void GetBRCTimeZoneList()
        {
            try
            {
                BRCInformationOperation objBRCInfo = new BRCInformationOperation();
                DataTable dtblTimeZone = objBRCInfo.GetBRCTimeZoneDataList();

                ddlBRCTimeZone.DataSource = dtblTimeZone;
                ddlBRCTimeZone.DataBind();
            }
            catch (Exception ex)
            {
            }
        }
        private void BindBRCCenterDayHours()
        {
            BRCInformationOperation objBRCInfo = new BRCInformationOperation();
            DataTable dtblCenterDayHours = objBRCInfo.GetBRCCenterDayHours();
            ddlCenterDaysHours.DataSource = dtblCenterDayHours;
            ddlCenterDaysHours.DataBind();
        }

    }
}