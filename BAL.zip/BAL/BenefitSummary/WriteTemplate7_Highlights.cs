﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Word = Microsoft.Office.Interop.Word;
using System.Data;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Collections;

namespace BenefitPointSummaryPortal.BAL.BenefitSummary
{
    public class WriteTemplate7_Highlights : System.Web.UI.Page
    {
        BPBusiness bp = new BPBusiness();
        CommonFunctionsBS comFunObj = new CommonFunctionsBS();

        /// <summary>
        /// Write Field to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="OfficeTable">OfficeTable conatain data for selected office</param>
        /// <param name="BRCList">BRCList contain data for selected BRC </param>
        /// <param name="ddlBRC">Dropdownlist ddlBRC Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="EligibilityDS">ataset EligibilityDS contain Eligibility information for selected Plan.</param>
        /// <param name="ddlClient">Dropdownlist ddlClient Object</param>
        /// <param name="ddlOffice">Dropdownlist ddlOffice Object</param>
        public void WriteFieldToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable OfficeTable, List<BRC> BRCList, DropDownList ddlBRC, DataSet ProductDS, DataSet EligibilityDS, DropDownList ddlClient, DropDownList ddlOffice)
        {
            try
            {
                int iTotalFields = 0;
                BPBusiness bp = new BPBusiness();
                DataTable Office = OfficeTable;
                ConstantValue cv = new ConstantValue();
                DataTable Emp = new DataTable();
                int BRCindex = -1;
                if (ddlBRC.SelectedIndex > 1)
                {
                    BRCindex = BRCList.FindIndex(item => item.BRCId == int.Parse(ddlBRC.SelectedValue.ToString()));
                }
                Emp = bp.GetEmployeeData(ddlClient.SelectedItem.Value);

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            string effectivedate = PlanTable.Rows[k]["Effective"].ToString();
                            string effective_year = Convert.ToDateTime(effectivedate.ToString()).Year.ToString().Trim();

                            comFunObj.Write_Field_Header(oWordDoc, oWordApp, effective_year);

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("Client Name1"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlClient.SelectedItem.Text.ToString());
                                    }

                                    if (fieldName.Contains("MedicalEffectiveYear"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(effective_year);
                                    }

                                    if (fieldName.Contains("Medical/Eligibility Rule/Definition of Eligible Employee"))
                                    {
                                        myMergeField.Select();

                                        if (Emp.Rows.Count > 0)
                                        {
                                            oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYMENT_TYPE_DESC"].ToString().Trim() + " " + Emp.Rows[0]["VALUE"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim() + " " + Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (Emp.Rows.Count > 0)
                                    {
                                        if (fieldName.Contains("Employee Status"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_STATUS_DESC"].ToString().Trim());
                                            }
                                        }
                                        if (fieldName.Contains("Working"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["VALUE"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["VALUE"].ToString().Trim());
                                            }
                                        }

                                        if (fieldName.Contains("Frequency"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_FREQUENCY_DESC"].ToString().Trim());
                                            }
                                        }
                                        if (fieldName.Contains("unitofmeasure"))
                                        {
                                            myMergeField.Select();
                                            if (Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(Emp.Rows[0]["EMPLOYEE_UOM_DESC"].ToString().Trim());
                                            }
                                        }
                                    }
                                    if (fieldName.Contains("Medical/Eligibility Rule/Waiting Period"))
                                    {
                                        myMergeField.Select();
                                        if (EligibilityDS.Tables["EligibilityRuleTable"].Rows.Count > 0)
                                        {
                                            if (EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim().Length == 0)
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString());
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(EligibilityDS.Tables["EligibilityRuleTable"].Rows[k]["item"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                    }

                                    if (BRCindex > -1)
                                    {
                                        if (fieldName.Contains("Benefit Resource Center"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText("Benefit Resource Center");
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Hours"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCDayHours.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCDayHours.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Phone"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCPhone.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCPhone.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Email"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCEmail.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCEmail.Trim());
                                            }
                                            continue;
                                        }
                                        if (fieldName.Contains("BRC Fax"))
                                        {
                                            myMergeField.Select();
                                            if (BRCList[BRCindex].BRCFax.Trim().Length == 0)
                                            {
                                                myMergeField.Delete();
                                            }
                                            else
                                            {
                                                oWordApp.Selection.TypeText(BRCList[BRCindex].BRCFax.Trim());
                                            }
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Medical Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ddlMedicalNoOfPlan">Dropdownlist ddlMedicalNoOfPlan Object</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan </param>
        /// <param name="MedicalBenefitColumnIdOutNetworkList">MedicalBenefitColumnIdOutNetworkList contain OutNetwork Benefit ColumnId for Medical Plan</param>
        public void WriteMedicalSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, DropDownList ddlMedicalNoOfPlan, ArrayList MedicalBenefitColumnIdList, ArrayList MedicalBenefitColumnIdOutNetworkList)
        {
            try
            {
                int iTotalFields = 0;

                BPBusiness bp = new BPBusiness();
                ConstantValue cv = new ConstantValue();
                int count = 1;

                ArrayList arrMedical = new ArrayList();
                ArrayList arrMedicalPlanType = new ArrayList();

                #region HashtableMedical
                Hashtable HashtableMedical = new Hashtable();
                Hashtable HashtableMedicalOutNetwork = new Hashtable();
                HashtableMedical.Add(3, "45");             // Annual Deductible [Individual]
                HashtableMedical.Add(33, "44");            // Annual Deductible [Maximum Per Family]
                HashtableMedical.Add(4, "16");             // Preventive Care - Adult Periodic Exams with Preventive Tests
                HashtableMedical.Add(5, "386");            // Professional [Office Visit]
                HashtableMedical.Add(6, "295");            // Hospital / Facility[Inpatient Care]
                HashtableMedical.Add(77, "52");            // Annual Out of Pocket Maximum (Family)
                HashtableMedical.Add(8, "53");             // Annual Out of Pocket Maximum (Individual)
                #endregion

                string Family_Plan1 = string.Empty;
                string Family_Plan2 = string.Empty;
                string Family_Plan3 = string.Empty;
                string Family_Plan4 = string.Empty;

                string OutOfPocket_Family_Plan1 = string.Empty;
                string OutOfPocket_Family_Plan2 = string.Empty;
                string OutOfPocket_Family_Plan3 = string.Empty;
                string OutOfPocket_Family_Plan4 = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            # region MergeField

                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();
                                    if (fieldName.Contains("Number of Medical Plan"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(ddlMedicalNoOfPlan.SelectedItem.Text.Trim());
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }
                                    if (fieldName.Contains("Offers"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("offers a choice between");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("offers");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Med_Plan"))
                                    {
                                        myMergeField.Select();
                                        if (ddlMedicalNoOfPlan.SelectedItem.Text == "2" || ddlMedicalNoOfPlan.SelectedItem.Text == "3")
                                        {
                                            oWordApp.Selection.TypeText("medical plans. You can choose the");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("medical plan, the");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Medical Plan Type" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!arrMedicalPlanType.Contains(PlanTable.Rows[k]["SummaryName"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["SummaryName"].ToString() + " plan ");
                                                arrMedicalPlanType.Add(PlanTable.Rows[k]["SummaryName"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["SummaryName"].ToString() + " plan");
                                            arrMedicalPlanType.Add(PlanTable.Rows[k]["SummaryName"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Medical Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!arrMedical.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                continue;
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            arrMedical.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            continue;
                                        }

                                    }
                                    if (fieldName.Contains("MEDICAL Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("MEDICAL Plans");
                                        continue;
                                    }
                                }
                            }
                            #endregion

                            #region MedicalTable

                            oWordDoc.Tables[1].Cell(2, count + 1).Select();
                            oWordDoc.Tables[1].Cell(2, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            oWordDoc.Tables[6].Cell(1, count + 1).Select();
                            oWordDoc.Tables[6].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableMedical.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableMedical[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 33)
                                            {
                                                Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan1;
                                            }
                                            if (key == 77)
                                            {
                                                OutOfPocket_Family_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan1;
                                            }
                                            else if (key != 33 && key != 3 && key != 77 && key != 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan2;
                                            }
                                            if (key == 77)
                                            {
                                                OutOfPocket_Family_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan2;
                                            }
                                            else if (key != 33 && key != 3 && key != 77 && key != 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan3;
                                            }
                                            if (key == 77)
                                            {
                                                OutOfPocket_Family_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan3;
                                            }
                                            else if (key != 33 && key != 3 && key != 77 && key != 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                        if (count == 4)
                                        {
                                            oWordDoc.Tables[1].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Family_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 3)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + Family_Plan4;
                                            }
                                            if (key == 77)
                                            {
                                                OutOfPocket_Family_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            if (key == 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " / " + OutOfPocket_Family_Plan4;
                                            }
                                            else if (key != 33 && key != 3 && key != 77 && key != 8)
                                            {
                                                oWordDoc.Tables[1].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion
                            count++;
                        }
                    }
                }

                count = count - 1;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (count > 1)
                        {
                            if (fieldName.Contains("multiplemedical"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText(" ");
                                continue;
                            }
                        }
                        else
                        {
                            if (fieldName.Contains("singlemedical"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("  ");
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Dental Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain Plantype data for selected plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="DentalBenefitColumnIdList">DentalBenefitColumnIdList contain InNetwork Benefit ColumnId for Dental Plan </param>
        public void WriteDentalSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataTable CarrierSpecific, DataTable PlanTypeSpecific, DataSet ProductDS, DataSet BenefitDS, ArrayList DentalBenefitColumnIdList)
        {
            try
            {
                ArrayList Dental_Carrier = new ArrayList();
                ArrayList Dental_PlanType = new ArrayList();
                #region HashtableDental
                Hashtable HashtableDental = new Hashtable();
                HashtableDental.Add(33, "45");     // Annual Deductible[Individual]
                HashtableDental.Add(3, "44");      // Annual Deductible[Family]
                HashtableDental.Add(4, "164");     // Dental Categories[Preventive & Diagnostic Care]
                HashtableDental.Add(5, "64");      // Dental Categories[Basic Restorative Care]
                HashtableDental.Add(6, "336");     // Dental Categories[Major Restorative Care]
                HashtableDental.Add(7, "55");      // Benefit Year Maximum 
                #endregion
                int count = 1;

                ConstantValue cv = new ConstantValue();
                string Annual_Deductible_Individual_Plan1 = string.Empty;
                string Annual_Deductible_Individual_Plan2 = string.Empty;
                string Annual_Deductible_Individual_Plan3 = string.Empty;
                string Annual_Deductible_Individual_Plan4 = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("DENTAL Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("DENTAL");
                                    }

                                    if (fieldName.Contains("Dental Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                    }

                                    if (fieldName.Contains("Dental Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!Dental_Carrier.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                Dental_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Dental_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                }
                            }

                            #endregion

                            #region DetalTable

                            oWordDoc.Tables[3].Cell(2, count + 1).Select();
                            oWordDoc.Tables[3].Cell(2, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            oWordDoc.Tables[7].Cell(1, count + 1).Select();
                            oWordDoc.Tables[7].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableDental.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && DentalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableDental[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan1 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 2)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan2 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 3)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan3 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan3 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }

                                        if (count == 4)
                                        {
                                            oWordDoc.Tables[3].Cell(1, count + 1).Range.Text = " ";
                                            if (key == 33)
                                            {
                                                Annual_Deductible_Individual_Plan4 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = Annual_Deductible_Individual_Plan4 + " / " + (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key != 33 && key != 3)
                                            {
                                                oWordDoc.Tables[3].Cell(key, count + 1).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write STD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="STDBenefitColumnIdList">STDBenefitColumnIdList contain InNetwork Benefit ColumnId for STD Plan </param>
        public void WriteSTDSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList STDBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                int count = 1;

                Hashtable HashtableSTD = new Hashtable();
                ConstantValue cv = new ConstantValue();

                #region HashtableSTD
                HashtableSTD.Add(1, "8");       // Elimination Period [Accident]
                HashtableSTD.Add(2, "505");     // Elimination Period [Sickness]
                HashtableSTD.Add(3, "71");      // STD General Plan Information – Benefit Percentage
                HashtableSTD.Add(4, "350");     // STD General Information – Maximum Period of Payment
                #endregion

                string Accident = string.Empty;
                string Sickness = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Maximum_Period_Of_Payment = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region STDTable

                            foreach (int key in HashtableSTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.STDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && STDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableSTD[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            Accident = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 2)
                                        {
                                            Sickness = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 3)
                                        {
                                            Benefit_Percentage = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (key == 4)
                                        {
                                            if (dr["UOM"].ToString() == "text")
                                            {
                                                dr["UOM"] = "";
                                            }

                                            Maximum_Period_Of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim() + " " + dr["UOM"].ToString().Trim();
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("SHORT TERM DISABILITY INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("SHORT TERM DISABILITY INSURANCE");
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Elimination Period Accident"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Accident))
                                        {
                                            oWordApp.Selection.TypeText(Accident);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Elimination Period Sickness"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Sickness))
                                        {
                                            oWordApp.Selection.TypeText(Sickness);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Benefit Percentage"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Benefit_Percentage))
                                        {
                                            oWordApp.Selection.TypeText(Benefit_Percentage);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("STD Maximum Period of Payment"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Maximum_Period_Of_Payment))
                                        {
                                            oWordApp.Selection.TypeText(Maximum_Period_Of_Payment);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion

                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write LTD Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LTDBenefitColumnIdList">LTDBenefitColumnIdList contain InNetwork Benefit ColumnId for LTD Plan</param>
        public void WriteLTDSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LTDBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                int count = 1;
                Hashtable HashtableLTD = new Hashtable();

                #region HashtableLTD
                HashtableLTD.Add(1, "181");     // Benefits [Elimination Period]
                HashtableLTD.Add(2, "71");      // General Plan Information – Benefit Percentage
                HashtableLTD.Add(3, "374");     // Benefits [Maximum Monthly Benefit]
                HashtableLTD.Add(4, "141");     // Benefits [Definition of Disability]
                HashtableLTD.Add(5, "351");     // Benefits [Maximum Period of Payment]
                ConstantValue cv = new ConstantValue();

                string Elimination_Period = string.Empty;
                string Benefit_Percentage = string.Empty;
                string Maximum_Monthly_Benefit = string.Empty;
                string Definition_of_Disability = string.Empty;
                string Maximum_Period_of_Payment = string.Empty;

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region LTDTable
                            foreach (int key in HashtableLTD.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.LTDPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LTDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLTD[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            Elimination_Period = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 2)
                                        {
                                            Benefit_Percentage = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 3)
                                        {
                                            Maximum_Monthly_Benefit = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 4)
                                        {
                                            Definition_of_Disability = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 5)
                                        {
                                            if (dr["UOM"].ToString() != "text")
                                            {
                                                Maximum_Period_of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString() + " " + dr["UOM"].ToString()).Trim();
                                            }
                                            else
                                            {
                                                Maximum_Period_of_Payment = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LONG TERM DISABILITY INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("LONG TERM DISABILITY INSURANCE");
                                        continue;
                                    }
                                    if (fieldName.Contains("LTD Elimination Period"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Elimination_Period))
                                        {
                                            oWordApp.Selection.TypeText(Elimination_Period);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    else if (fieldName.Contains("LTD  Benefit Percentage"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Benefit_Percentage))
                                        {
                                            oWordApp.Selection.TypeText(Benefit_Percentage);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    else if (fieldName.Contains("LTD Maximum Monthly Benefit"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Maximum_Monthly_Benefit))
                                        {
                                            oWordApp.Selection.TypeText(Maximum_Monthly_Benefit);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    else if (fieldName.Contains("LTD Definition of Disability"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Definition_of_Disability))
                                        {
                                            oWordApp.Selection.TypeText(Definition_of_Disability);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    else if (fieldName.Contains("LTD Maximum Period of Payment"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Maximum_Period_of_Payment))
                                        {
                                            oWordApp.Selection.TypeText(Maximum_Period_of_Payment);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Vision Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VisionBenefitColumnIdList">VisionBenefitColumnIdList contain InNetwork Benefit ColumnId for Vision Plan</param>
        public void WriteVisionBenefitsSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VisionBenefitColumnIdList)
        {
            try
            {
                Hashtable HashtableVisionBenefitInNetwork = new Hashtable();
                Hashtable HashtableVisionBenefitInNetwork_Col2 = new Hashtable();

                #region HastableVisionBenefit

                HashtableVisionBenefitInNetwork.Add(2, "195");     // General Plan Information – Copay – Examination Deductible
                HashtableVisionBenefitInNetwork.Add(3, "344");     // General Plan Information – Copay – Material Deductible
                HashtableVisionBenefitInNetwork.Add(4, "507");     // Covered Services – Lenses – Single Vision Lens
                HashtableVisionBenefitInNetwork.Add(5, "208");     // Covered Services – Frames
                HashtableVisionBenefitInNetwork.Add(6, "178");     // Covered Services – Contact Lenses - Elective

                HashtableVisionBenefitInNetwork_Col2.Add(2, "194");     // General Plan Information – Benefit Frequency – Examination
                HashtableVisionBenefitInNetwork_Col2.Add(4, "309");     // General Plan Information – Benefit Frequency – Lenses
                HashtableVisionBenefitInNetwork_Col2.Add(5, "207");     // General Plan Information – Benefit Frequency – Frames
                HashtableVisionBenefitInNetwork_Col2.Add(6, "122");     // General Plan Information – Benefit Frequency – Contacts

                #endregion

                int count = 1;

                ArrayList Vision_Carrier = new ArrayList();
                ConstantValue cv = new ConstantValue();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region MergeField

                            int iTotalFields = 0;
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VISION Plans"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("VISION");
                                        continue;
                                    }
                                    if (count > 2)
                                    {
                                        if (fieldName.Contains("VisionPlan3And4"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                    if (fieldName.Contains("Vision Monthly Contribution"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(" ");
                                        continue;
                                    }

                                    if (fieldName.Contains("Vision Carrier Name" + count.ToString().Trim()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (!Vision_Carrier.Contains(PlanTable.Rows[k]["Carrier"].ToString().Trim()))
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                Vision_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            Vision_Carrier.Add(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion

                            # region VisionBenefitTable
                            if (count == 1)
                            {
                                oWordDoc.Tables[4].Cell(1, 2).Select();
                                oWordDoc.Tables[4].Cell(1, 2).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 2)
                            {
                                oWordDoc.Tables[4].Cell(1, 3).Select();
                                oWordDoc.Tables[4].Cell(1, 3).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 3)
                            {
                                oWordDoc.Tables[5].Cell(1, 2).Select();
                                oWordDoc.Tables[5].Cell(1, 2).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }
                            else if (count == 4)
                            {
                                oWordDoc.Tables[5].Cell(1, 3).Select();
                                oWordDoc.Tables[5].Cell(1, 3).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim() + " \n" + "IN-NETWORK PROVIDERS";
                            }

                            oWordDoc.Tables[8].Cell(1, count + 1).Select();
                            oWordDoc.Tables[8].Cell(1, count + 1).Range.Text = (PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim();

                            foreach (int key in HashtableVisionBenefitInNetwork.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 2)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 3)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 2).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 4)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 4).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            foreach (int key in HashtableVisionBenefitInNetwork_Col2.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && VisionBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableVisionBenefitInNetwork_Col2[key].ToString())
                                    {
                                        if (count == 1)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 2)
                                        {
                                            oWordDoc.Tables[4].Cell(key, 5).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 3)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 3).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        else if (count == 4)
                                        {
                                            oWordDoc.Tables[5].Cell(key, 5).Range.Text = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Life AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="LifeADDBenefitColumnIdList">LifeADDBenefitColumnIdList contain InNetwork Benefit ColumnId for Life AD&D Plan</param>
        public void WriteLifeADDBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList LifeADDBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableLifeADDBenifit = new Hashtable();

                #region HashtableGroupLifeADDBenifit
                HashtableLifeADDBenifit.Add(1, "186");     //Employee [Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(7, "517");     //Spouse[Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(11, "102");    //Child(ren)[Benefit Amount] 

                #endregion

                string Employee_Benefit_Amount = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.LifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region LifeADDBenifitTable
                            foreach (int key in HashtableLifeADDBenifit.Keys)
                            {
                                Employee_Benefit_Amount = "";
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.LifeADDPlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && LifeADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableLifeADDBenifit[key].ToString())
                                    {
                                        Employee_Benefit_Amount = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LIFE/AD&D INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("LIFE/AD&D INSURANCE");
                                        continue;
                                    }

                                    if (fieldName.Contains("Life and AD&D Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Life and AD&D Benefit Amount Employee" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Employee_Benefit_Amount))
                                        {
                                            oWordApp.Selection.TypeText(Employee_Benefit_Amount);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Life and AD&D Benefit Summaries Description" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText((PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim());
                                        continue;
                                    }

                                    if (count > 1)
                                    {
                                        if (fieldName.Contains("Life_Add_2nd_Plan"))
                                        {
                                            myMergeField.Select();
                                            oWordApp.Selection.TypeText(" ");
                                            continue;
                                        }
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Group Term Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="GroupTermLifeBenefitColumnIdList">GroupTermLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Group Term Life Plan</param>
        public void WriteGroupTermLifeBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList GroupTermLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                string OldCarrier = "";
                int count = 1;
                string value = string.Empty;

                Hashtable HashtableGroupTermLifeBenifit = new Hashtable();

                #region HashtableGroupLifeADDBenifit
                HashtableGroupTermLifeBenifit.Add(1, "186");     //Employee [Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(7, "517");     //Spouse[Benefit Amount]
                //HashtableGroupLifeADDBenifit.Add(11, "102");    //Child(ren)[Benefit Amount] 

                #endregion

                string Employee_Benefit_Amount = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupTermLifeBenifitTable
                            foreach (int key in HashtableGroupTermLifeBenifit.Keys)
                            {
                                Employee_Benefit_Amount = "";
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.GroupTermLifePlanType.ToLower() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && GroupTermLifeBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableGroupTermLifeBenifit[key].ToString())
                                    {
                                        Employee_Benefit_Amount = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("LIFE INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("LIFE INSURANCE");
                                        continue;
                                    }

                                    if (fieldName.Contains("Group Term Life Carrier Name" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (count > 1)
                                        {
                                            if (OldCarrier != PlanTable.Rows[k]["Carrier"].ToString())
                                            {
                                                oWordApp.Selection.TypeText(" and " + PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            }
                                        }

                                        else
                                        {
                                            oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                            OldCarrier = PlanTable.Rows[k]["Carrier"].ToString();
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("Group Term Life Benefit Amount Employee" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Employee_Benefit_Amount))
                                        {
                                            oWordApp.Selection.TypeText(Employee_Benefit_Amount);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Group Term Life Benefit Summaries Description" + count.ToString()))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText((PlanTable.Rows[k]["Carrier"].ToString() + " " + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + " " + PlanTable.Rows[k]["PolicyNumber"].ToString() + " " + BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["description"]).Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write AD&D Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="ADDBenefitColumnIdList">ADDBenefitColumnIdList contain InNetwork Benefit ColumnId for AD&D Plan</param>
        public void WriteADDBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList ADDBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;
                string value = string.Empty;

                Hashtable HashtableADDBenifit = new Hashtable();

                #region HashtableADDBenifit
                HashtableADDBenifit.Add(1, "186");     //Employee [Benefit Amount]

                #endregion

                string Employee_Benefit_Amount = string.Empty;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.ADD.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region GroupTermLifeBenifitTable
                            foreach (int key in HashtableADDBenifit.Keys)
                            {
                                Employee_Benefit_Amount = "";
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower() == cv.ADD.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && ADDBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableADDBenifit[key].ToString())
                                    {
                                        Employee_Benefit_Amount = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                    }
                                }
                            }
                            #endregion

                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("ADD INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("AD&D INSURANCE");
                                        continue;
                                    }

                                    if (fieldName.Contains("ADD Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }

                                    if (fieldName.Contains("ADD Benefit Amount Employee"))
                                    {
                                        myMergeField.Select();
                                        if (!string.IsNullOrEmpty(Employee_Benefit_Amount))
                                        {
                                            oWordApp.Selection.TypeText(Employee_Benefit_Amount);
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText(" ");
                                        }
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Wellness Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="WellnessBenefitColumnIdList">WellnessBenefitColumnIdList contain InNetwork Benefit ColumnId for Wellness Plan</param>
        public void WriteWellnessBenifitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList WellnessBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.Wellness.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("WELLNESS PROGRAM"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText("WELLNESS PROGRAM");
                                        continue;
                                    }

                                    if (fieldName.Contains("Wellness Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Voluntary Life Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="VoluntaryLifeBenefitColumnIdList">VoluntaryLifeBenefitColumnIdList contain InNetwork Benefit ColumnId for Voluntary Life Plan </param>
        public void WriteVoluntaryLifeADDBenefitToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList VoluntaryLifeBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue(); int iTotalFields = 0;

                int count = 1;
                string value = string.Empty;

                Hashtable HashtableVoluntaryLifeADDBenifit = new Hashtable();
                #region HashtableVoluntaryLifeADDBenifit
                /*Delete Overall maximum row from all catagory--29/05/2014*/
                //HashtableVoluntaryLifeADDBenifit.Add(3, "186");//Employee [Benefit Amount]


                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower() == cv.VoluntaryLifeADDPlanType.ToLower())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region merge fields
                            foreach (Word.Field myMergeField in oWordDoc.Fields)
                            {
                                iTotalFields++;

                                Word.Range rngFieldCode = myMergeField.Code;

                                String fieldText = rngFieldCode.Text;

                                if (fieldText.StartsWith(" MERGEFIELD"))
                                {
                                    Int32 endMerge = fieldText.IndexOf("\\");
                                    if (endMerge == -1)
                                    {
                                        endMerge = fieldText.Length;
                                    }

                                    Int32 fieldNameLength = fieldText.Length - endMerge;

                                    String fieldName = fieldText.Substring(11, endMerge - 11);

                                    fieldName = fieldName.Trim();

                                    if (fieldName.Contains("VOLUNTARY LIFE / AD&D INSURANCE"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[k]["ProductName"].ToString().Trim().Contains("AD&D"))
                                        {
                                            oWordApp.Selection.TypeText("VOLUNTARY LIFE / AD&D INSURANCE");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("VOLUNTARY LIFE INSURANCE");
                                        }
                                        continue;
                                    }
                                    if (fieldName.Contains("Voluntary Life Details"))
                                    {
                                        myMergeField.Select();
                                        if (PlanTable.Rows[k]["ProductName"].ToString().Trim().Contains("AD&D"))
                                        {
                                            oWordApp.Selection.TypeText("for Voluntary Life and AD&D Insurance");
                                        }
                                        else
                                        {
                                            oWordApp.Selection.TypeText("for Voluntary Life Insurance");
                                        }
                                        continue;
                                    }

                                    if (fieldName.Contains("VOLUNTARY LIFE AD&D Carrier Name"))
                                    {
                                        myMergeField.Select();
                                        oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString());
                                        continue;
                                    }
                                }
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write EAP Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="EAPBenefitColumnIdList">EAPBenefitColumnIdList contain InNetwork Benefit ColumnId for EAP Plan</param>
        public void WriteEAPSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList EAPBenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;

                ConstantValue cv = new ConstantValue();
                int count = 1;

                Hashtable HashtableEAP = new Hashtable();

                #region HashtableEAP
                HashtableEAP.Add(1, "384"); // Number of Visit 

                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foreach (int key in HashtableEAP.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.EAPPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && EAPBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableEAP[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("EAP Number of Visits"))
                                                {
                                                    myMergeField.Select();
                                                    string number_visit_item = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();

                                                    if (number_visit_item.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(number_visit_item.Trim());
                                                    }
                                                    continue;
                                                }

                                                if (fieldName.Contains("EAP Carrier Name"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText(PlanTable.Rows[k]["Carrier"].ToString().Trim());
                                                    continue;
                                                }
                                                if (fieldName.Contains("EMPLOYEE ASSISTANCE PROGRAM (EAP)"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("EMPLOYEE ASSISTANCE PROGRAM (EAP)");
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write FSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTypeSpecific">PlanTypeSpecific contain PlanType data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="FSABenefitColumnIdList">FSABenefitColumnIdList contain InNetwork Benefit ColumnId for FSA Plan</param>
        public void WriteFSASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataTable PlanTypeSpecific, DataSet BenefitDS, ArrayList FSABenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int iTotalFields = 0;

                int count = 1;
                Hashtable HashtableFSA = new Hashtable();

                DataRow[] foundPlanTypeRows = null;

                #region HashtableFSA
                HashtableFSA.Add(1, "354"); // Administration Services - Medical Spending Accounts - Maximum
                #endregion

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            foundPlanTypeRows = PlanTypeSpecific.Select("PlanTypeName='" + PlanTable.Rows[k]["ProductTypeDescription"].ToString() + "'");
                            foreach (int key in HashtableFSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.FSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && FSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableFSA[key].ToString())
                                    {
                                        #region merge fields
                                        foreach (Word.Field myMergeField in oWordDoc.Fields)
                                        {
                                            iTotalFields++;

                                            Word.Range rngFieldCode = myMergeField.Code;

                                            String fieldText = rngFieldCode.Text;

                                            if (fieldText.StartsWith(" MERGEFIELD"))
                                            {
                                                Int32 endMerge = fieldText.IndexOf("\\");
                                                if (endMerge == -1)
                                                {
                                                    endMerge = fieldText.Length;
                                                }

                                                Int32 fieldNameLength = fieldText.Length - endMerge;

                                                String fieldName = fieldText.Substring(11, endMerge - 11);

                                                fieldName = fieldName.Trim();

                                                if (fieldName.Contains("Administration Services – Medical Spending Accounts-Maximum"))
                                                {
                                                    myMergeField.Select();
                                                    string administration_service_medicalspending = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                                    if (administration_service_medicalspending.Trim().Length == 0)
                                                    {
                                                        oWordApp.Selection.TypeText(" ");
                                                    }
                                                    else
                                                    {
                                                        oWordApp.Selection.TypeText(administration_service_medicalspending.Trim());
                                                    }
                                                    continue;
                                                }
                                                if (fieldName.Contains("FLEXIBLE SPENDING ACCOUNTS (FSA)"))
                                                {
                                                    myMergeField.Select();
                                                    oWordApp.Selection.TypeText("FLEXIBLE SPENDING ACCOUNTS (FSA)");
                                                    continue;
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                            }
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HSA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="HSABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HSA Plan</param>
        /// <param name="clientName">clientName contain selected client name</param>
        /// <param name="ddlHSAPlanName">ddlHSAPlanName contain selected HSA plan name</param>
        public void WriteHSASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, DataTable CarrierSpecific, ArrayList HSABenefitColumnIdList, string clientName, DropDownList ddlHSAPlanName)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;

                Hashtable HashtableHSA = new Hashtable();

                #region HashtableHSA
                HashtableHSA.Add(1, "635"); // General Plan Information – Maximum Annual Contribution / Individual
                HashtableHSA.Add(2, "636"); // General Plan Information – Maximum Annual Contribution / Family

                #endregion

                string MaxAnnualContribution = "";
                string MaxAnnualContribution_Family = "";

                // IRC
                BPBusiness bp = new BPBusiness();
                DataTable dt_IRC = new DataTable();

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            // Get the renewal year for taking the IRC table detail
                            string renewalDate = Convert.ToString(Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year);

                            dt_IRC = bp.GetIRCList(renewalDate);

                            foreach (int key in HashtableHSA.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.HSAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HSABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHSA[key].ToString())
                                    {
                                        if (key == 1)
                                        {
                                            MaxAnnualContribution = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                        if (key == 2)
                                        {
                                            MaxAnnualContribution_Family = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        }
                                    }
                                }
                            }

                            oWordDoc.Tables[2].Cell(1, 2).Select();
                            oWordDoc.Tables[2].Cell(1, 2).Range.Text = clientName + " " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year + " PLAN YEAR CONTRIBUTION*";

                            oWordDoc.Tables[2].Cell(1, 3).Select();
                            oWordDoc.Tables[2].Cell(1, 3).Range.Text = "IRS" + " " + Convert.ToDateTime(PlanTable.Rows[k]["Renewal"].ToString()).Year + " CALENDAR YEAR MAXIMUM CONTRIBUTION";

                            oWordDoc.Tables[2].Cell(2, 2).Select();
                            oWordDoc.Tables[2].Cell(2, 2).Range.Text = MaxAnnualContribution;

                            oWordDoc.Tables[2].Cell(3, 2).Select();
                            oWordDoc.Tables[2].Cell(3, 2).Range.Text = MaxAnnualContribution_Family;

                            for (int j = 0; j < dt_IRC.Rows.Count; j++)
                            {
                                oWordDoc.Tables[2].Cell(2, 3).Select();
                                oWordDoc.Tables[2].Cell(2, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["EmployeeOnlyCoverage"].ToString()) + ", including employer contribution";

                                oWordDoc.Tables[2].Cell(3, 3).Select();
                                oWordDoc.Tables[2].Cell(3, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["FamilyCoverage"].ToString()) + ", including employer contribution";

                                oWordDoc.Tables[2].Cell(4, 3).Select();
                                oWordDoc.Tables[2].Cell(4, 3).Range.Text = Convert.ToString(dt_IRC.Rows[j]["EmployeesOver55"].ToString()) + " additional “catch-up” contribution";
                            }

                            count++;
                        }
                    }
                }

                #region merge fields
                int iTotalFields = 0;
                if (ddlHSAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HEALTH SAVINGS ACCOUNT"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("HEALTH SAVINGS ACCOUNT");
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write HRA Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ddlHRAPlanName">DropDownList ddlHRAPlanName Object</param>
        /// /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="HRABenefitColumnIdList">HSABenefitColumnIdList contain InNetwork Benefit ColumnId for HRA Plan</param>
        public void WriteHRASectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DropDownList ddlHRAPlanName, DataTable PlanTable, DataSet ProductDS, DataSet BenefitDS, ArrayList HRABenefitColumnIdList)
        {
            try
            {
                int iTotalFields = 0;
                ConstantValue cv = new ConstantValue();

                Hashtable HashtableHRA = new Hashtable();
                #region HashtableHRA
                HashtableHRA.Add(1, "238"); // Health Reimbursement Account Tier 1 
                HashtableHRA.Add(2, "241"); // Health Reimbursement Account Tier 4 

                #endregion

                string HRA_Tier_1 = string.Empty;
                string HRA_Tier_2 = string.Empty;

                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                    {
                        if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.HRAPlanType.ToLower().Trim())
                        {
                            if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                            {
                                foreach (int key in HashtableHRA.Keys)
                                {
                                    foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                    {
                                        if (dr["section"].ToString().ToLower().Trim() == cv.HRAPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && HRABenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtableHRA[key].ToString())
                                        {
                                            if (key == 1)
                                            {
                                                HRA_Tier_1 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                            else if (key == 2)
                                            {
                                                HRA_Tier_2 = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #region merge fields
                if (ddlHRAPlanName.SelectedIndex > 0)
                {
                    foreach (Word.Field myMergeField in oWordDoc.Fields)
                    {
                        iTotalFields++;

                        Word.Range rngFieldCode = myMergeField.Code;

                        String fieldText = rngFieldCode.Text;

                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");
                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;

                            String fieldName = fieldText.Substring(11, endMerge - 11);

                            fieldName = fieldName.Trim();
                            if (fieldName.Contains("HEALTH REIMBURSEMENT ACCOUNT"))
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("HEALTH REIMBURSEMENT ACCOUNT");
                                continue;
                            }
                            if (fieldName.Contains("General Plan Information/Health Reimbursement Account Tier 1"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_1))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_1);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                            if (fieldName.Contains("General Plan Information/Health Reimbursement Account Tier 4"))
                            {
                                myMergeField.Select();
                                if (!string.IsNullOrEmpty(HRA_Tier_2))
                                {
                                    oWordApp.Selection.TypeText(HRA_Tier_2);
                                }
                                else
                                {
                                    oWordApp.Selection.TypeText(" ");
                                }
                                continue;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Prescription Drugs Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ProductDS">Dataset ProductDS contain Product information for selected Plan.</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="CarrierSpecific">CarrierSpecific contain carrier data for selected plan</param>
        /// <param name="BenefitDS">Dataset BenefitDS contain Benefit summary information for selected Plan.</param>
        /// <param name="MedicalBenefitColumnIdList">MedicalBenefitColumnIdList contain InNetwork Benefit ColumnId for Medical Plan</param>
        public void WritePrescriptionDrugsSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataSet ProductDS, DataTable PlanTable, DataTable CarrierSpecific, DataSet BenefitDS, ArrayList MedicalBenefitColumnIdList)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int count = 1;

                #region HashtablePrescriptionDrugs
                Hashtable HashtablePrescriptionDrugs = new Hashtable();
                HashtablePrescriptionDrugs.Add(1, "213");   //Prescription Categories[Generic]
                HashtablePrescriptionDrugs.Add(2, "78");    //Prescription Categories[Formulary]
                HashtablePrescriptionDrugs.Add(3, "84");    //Prescription Categories[Non Formulary]
                #endregion

                string value = "";
                string Generic = "";
                string Formulary = "";
                string NonFormulary = "";

                for (int k = 0; k < ProductDS.Tables["ProductTable"].Rows.Count; k++)
                {
                    Generic = "";
                    Formulary = "";
                    NonFormulary = "";

                    if (PlanTable.Rows[k]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (PlanTable.Rows[k]["ProductId"].ToString() == ProductDS.Tables["ProductTable"].Rows[k]["productID"].ToString())
                        {
                            #region PrescriptionDrugsTable

                            foreach (int key in HashtablePrescriptionDrugs.Keys)
                            {
                                foreach (DataRow dr in BenefitDS.Tables["AttributeValueDetailTable"].Rows)
                                {
                                    if (dr["section"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim() && dr["benefitSummaryID"].ToString() == BenefitDS.Tables["BenefitSummaryTable"].Rows[k]["benefitSummaryID"].ToString() && MedicalBenefitColumnIdList.Contains(dr["benefitColumnID"].ToString()) && dr["attributeID"].ToString() == HashtablePrescriptionDrugs[key].ToString())
                                    {
                                        value = (dr["prefix"].ToString() + dr["value"].ToString() + dr["suffix"].ToString() + " " + dr["ancillaryText"].ToString() + " " + dr["exclusionsLimitations"].ToString()).Trim();
                                        switch (key)
                                        {
                                            case 1: Generic = value; break;
                                            case 2: Formulary = value; break;
                                            case 3: NonFormulary = value; break;
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrEmpty(Generic))
                            {
                                Generic = Generic + " / ";
                            }
                            if (!string.IsNullOrEmpty(Formulary))
                            {
                                Formulary = Formulary + " / ";
                            }

                            value = Generic + Formulary + NonFormulary;

                            if (count == 1)
                            {
                                oWordDoc.Tables[1].Cell(7, 2).Range.Text = value;
                            }
                            if (count == 2)
                            {
                                oWordDoc.Tables[1].Cell(7, 3).Range.Text = value;
                            }
                            if (count == 3)
                            {
                                oWordDoc.Tables[1].Cell(7, 4).Range.Text = value;
                            }
                            if (count == 4)
                            {
                                oWordDoc.Tables[1].Cell(7, 5).Range.Text = value;
                            }
                            #endregion
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Annual and CHIP Notice Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="ContactList">Contact List Contain data for HR Conatct</param>
        /// <param name="ddlHRContact">DropDownList ddlHRContact Object</param>
        /// <param name="ddlChipNotice">DropDownList ddlChipNotice Object</param>
        /// <param name="ddlAnnualLegalNotice">DropDownList ddlAnnualLegalNotice Object</param>
        /// <param name="chkAnualNotice">CheckBoxList chkAnualNotice Object</param>
        public void WriteNoticeSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, List<Contact> ContactList, DropDownList ddlHRContact, DropDownList ddlChipNotice, DropDownList ddlAnnualLegalNotice, CheckBoxList chkAnualNotice, DropDownList ddlMarketplaceCoverage, DropDownList ddlCreditableCoverage)
        {
            try
            {
                int iTotalFields = 0;
                int index = -1;

                if (ddlHRContact.SelectedIndex > 1 && ContactList.Count > 0)
                {
                    index = ContactList.FindIndex(item => item.ContactId == int.Parse(ddlHRContact.SelectedValue.ToString()));
                }

                # region MergeField
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Equals("CHIPNotice"))
                        {
                            if (ddlChipNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                //For word page break-03 June 2014
                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/CHIPNotice/CHIPNotice.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                        }

                        if (fieldName.Contains("MARKETPLACE COVERAGE"))
                        {
                            if (ddlMarketplaceCoverage.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();

                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);

                                r.InsertBreak(Word.WdBreakType.wdPageBreak);
                                r.InsertFile(Server.MapPath("~/Files/BenefitSummary/Documents/AnnualLegalNotice/13 - Notice of Coverage Options 2.2016.doc"), missing, true, missing, missing);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            continue;
                        }

                        if (fieldName.Equals("AnnualNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Select();
                                oWordApp.Selection.TypeText("\f");
                                oWordApp.Selection.TypeText("Important Legal Notices Affecting Your Health Plan Coverage");
                            }
                        }
                        if (fieldName.Equals("AnnualLeagalNotice"))
                        {
                            if (ddlAnnualLegalNotice.SelectedIndex == 1)
                            {
                                myMergeField.Delete();
                                object missing = System.Type.Missing;
                                Word.Range r = oWordDoc.Range();
                                r.SetRange(rngFieldCode.End + 1, rngFieldCode.End);
                                // Call common function to take notices
                                comFunObj.NoticesFunction_AnnualLegalNoticesOnly(chkAnualNotice, r, 1);
                            }
                            else
                            {
                                myMergeField.Delete();
                            }
                            oWordDoc.Save();
                        }
                    }
                }
                #endregion
                iTotalFields = 0;

                // Call common function to write the contact information page fields
                comFunObj.WriteFieldsForContactInformationNotice(oWordDoc, oWordApp, ContactList, index, Convert.ToInt16(ddlMarketplaceCoverage.SelectedIndex), Convert.ToInt16(ddlCreditableCoverage.SelectedIndex), chkAnualNotice, true);
            }
            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

        /// <summary>
        /// Write Monthly Premium Section to template.
        /// </summary>
        /// <param name="oWordDoc">Word Document Object</param>
        /// <param name="oWordApp">Word Application Object</param>
        /// <param name="PlanTable">PlanTable contain selected Plan</param>
        /// <param name="RateDS">Dataset RateDS contain Rate information for selected Plan.</param>
        /// <param name="ContributionDS">Dataset ContributionDS contain Contribution information for selected Plan.</param>
        public void WriteMonthlyPremiumSectionToTemplate7(Word.Document oWordDoc, Word.Application oWordApp, DataTable PlanTable, DataSet RateDS, DataSet ContributionDS)
        {
            try
            {
                ConstantValue cv = new ConstantValue();
                int Medicalindex = 6;
                int DentalCount = 0;
                int VisionCount = 0;

                DataTable PremiumTableWriteMedical = new DataTable();
                PremiumTableWriteMedical.Columns.Add("RateHeader");
                PremiumTableWriteMedical.Columns.Add("Plan1_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan2_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan3_Rate");
                PremiumTableWriteMedical.Columns.Add("Plan4_Rate");

                DataTable PremiumTableWriteDental = new DataTable();
                PremiumTableWriteDental.Columns.Add("RateHeader");
                PremiumTableWriteDental.Columns.Add("Plan1_Rate");
                PremiumTableWriteDental.Columns.Add("Plan2_Rate");
                PremiumTableWriteDental.Columns.Add("Plan3_Rate");
                PremiumTableWriteDental.Columns.Add("Plan4_Rate");

                DataTable PremiumTableWriteVision = new DataTable();
                PremiumTableWriteVision.Columns.Add("RateHeader");
                PremiumTableWriteVision.Columns.Add("Plan1_Rate");
                PremiumTableWriteVision.Columns.Add("Plan2_Rate");
                PremiumTableWriteVision.Columns.Add("Plan3_Rate");
                PremiumTableWriteVision.Columns.Add("Plan4_Rate");

                for (int index = 0; index < PlanTable.Rows.Count; index++)
                {
                    #region  BuildTable
                    /*
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;

                    PremiumTable.Columns.Add("Plan", typeof(string));
                    //PremiumTable.Columns.Add("rateTierID", typeof(string));
                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    PremiumTable.Columns.Add("rateTier_description", typeof(string));
                    PremiumTable.Columns.Add("monthlycost", typeof(string));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("summaryname", typeof(string));
                    PremiumTable.Columns.Add("contributionFrequency", typeof(string));
                    PremiumTable.Columns.Add("contributionid", typeof(string));
                    PremiumTable.Columns.Add("rateid", typeof(string));
                    PremiumTable.Columns.Add("rateFieldValueID", typeof(string));

                    for (int i = 0; i < RateDS.Tables["RateFieldValueTable"].Rows.Count; i++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == RateDS.Tables["RateFieldValueTable"].Rows[i]["section"])
                        {
                            if (RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateField_label"].ToString().ToLower() == "rate" && int.Parse(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"].ToString()) == int.Parse(PlanTable.Rows[index]["RateId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = RateDS.Tables["RateFieldValueTable"].Rows[i]["section"];
                                //PremiumTable.Rows[premium_row_counter][1] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"];
                                if ((RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]).ToString().Trim() != "")
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = Convert.ToInt16(RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_rateTierID"]);
                                }
                                else
                                {
                                    PremiumTable.Rows[premium_row_counter][1] = 0;
                                }
                                PremiumTable.Rows[premium_row_counter][2] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateTier_description"];
                                PremiumTable.Rows[premium_row_counter][3] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_valueNum"];
                                PremiumTable.Rows[premium_row_counter][8] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateID"];
                                PremiumTable.Rows[premium_row_counter][9] = RateDS.Tables["RateFieldValueTable"].Rows[i]["rateFieldValues_rateFieldValueID"];
                                for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                                {
                                    if (ContributionDS.Tables["ContributionValueTable"].Rows[j][3].ToString() == PlanTable.Rows[index]["ContributionId"].ToString() && RateDS.Tables["RateFieldValueTable"].Rows[i][10].ToString() == ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString() && ContributionDS.Tables["ContributionValueTable"].Rows[j][0].ToString() == PlanTable.Rows[index]["PlanType"].ToString())
                                    {
                                        PremiumTable.Rows[premium_row_counter][4] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                        PremiumTable.Rows[premium_row_counter][5] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["description"].ToString();
                                        PremiumTable.Rows[premium_row_counter][6] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionFrequency"].ToString();
                                        PremiumTable.Rows[premium_row_counter][7] = PlanTable.Rows[index]["ContributionId"].ToString();
                                        break;
                                    }
                                }
                                premium_row_counter++;
                            }
                        }
                    }
                    */
                    #endregion

                    #region Build Contribution Table
                    DataTable PremiumTable = new DataTable();
                    int premium_row_counter = 0;
                    PremiumTable.Columns.Add("rateTierID", typeof(int));
                    PremiumTable.Columns.Add("contributioncost", typeof(string));
                    PremiumTable.Columns.Add("contributionDescription", typeof(string));

                    for (int j = 0; j < ContributionDS.Tables["ContributionValueTable"].Rows.Count; j++)
                    {
                        if (PlanTable.Rows[index]["PlanType"] == ContributionDS.Tables["ContributionValueTable"].Rows[j]["section"])
                        {
                            if (int.Parse(ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionvalues_contribution"].ToString()) == int.Parse(PlanTable.Rows[index]["ContributionId"].ToString()))
                            {
                                PremiumTable.Rows.Add();
                                PremiumTable.Rows[premium_row_counter][0] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_rateTierID"].ToString();
                                PremiumTable.Rows[premium_row_counter][1] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_amount"].ToString();
                                PremiumTable.Rows[premium_row_counter][2] = ContributionDS.Tables["ContributionValueTable"].Rows[j]["contributionValues_contributionDescription"].ToString();
                                premium_row_counter++;
                            }
                        }
                    }
                    #endregion

                    DataTable dt = new DataTable();

                    PremiumTable.DefaultView.Sort = "[rateTierID] asc";
                    dt = PremiumTable.DefaultView.ToTable(true);
                    PremiumTable = dt;

                    # region FillTable Medical

                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.MedicalPlanType.ToLower().Trim())
                    {
                        if (index == 0)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    dr["Plan4_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteMedical.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    dr["Plan4_Rate"] = "";
                                    PremiumTableWriteMedical.Rows.Add(dr);
                                }
                            }
                        }
                        if (index == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (index == 2)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (index == 3)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteMedical.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteMedical.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteMedical.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteMedical.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteMedical.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteMedical.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    # region FillTable Dental
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.DentalPlanType.ToLower().Trim())
                    {
                        if (DentalCount == 0)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteDental.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    PremiumTableWriteDental.Rows.Add(dr);
                                }
                            }
                        }
                        if (DentalCount == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (DentalCount == 2)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (DentalCount == 3)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteDental.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteDental.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteDental.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteDental.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteDental.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        PremiumTableWriteDental.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        DentalCount++;
                    }
                    #endregion

                    #region FillTable Vision
                    if (PlanTable.Rows[index]["PlanType"].ToString().ToLower().Trim() == cv.VisionPlanType.ToLower().Trim())
                    {
                        if (VisionCount == 0)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                if (PremiumTable.Rows[i][0].ToString() == "8")
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    dr["Plan4_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                                else
                                {
                                    DataRow dr = PremiumTableWriteVision.NewRow();
                                    dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                    dr["Plan1_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                    dr["Plan2_Rate"] = "";
                                    dr["Plan3_Rate"] = "";
                                    dr["Plan4_Rate"] = "";

                                    PremiumTableWriteVision.Rows.Add(dr);
                                }
                            }
                        }
                        if (VisionCount == 1)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][2] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan2_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan3_Rate"] = "";
                                        dr["Plan4_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (VisionCount == 2)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan4_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][3] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan3_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan4_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        if (VisionCount == 3)
                        {
                            for (int i = 0; i < PremiumTable.Rows.Count; i++)
                            {
                                int flag = 0;
                                if (PremiumTable.Rows[i][1].ToString() == "8")
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    for (int c = 0; c < PremiumTableWriteVision.Rows.Count; c++)
                                    {
                                        if (PremiumTableWriteVision.Rows[c][0].ToString() == "Employee & " + PremiumTable.Rows[i][2].ToString() || PremiumTableWriteVision.Rows[c][0].ToString() == PremiumTable.Rows[i][2].ToString())
                                        {
                                            PremiumTableWriteVision.Rows[c][4] = "$" + PremiumTable.Rows[i][1].ToString();
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0)
                                    {
                                        DataRow dr = PremiumTableWriteVision.NewRow();
                                        dr["RateHeader"] = "Employee & " + PremiumTable.Rows[i][2].ToString();
                                        dr["Plan4_Rate"] = "$" + PremiumTable.Rows[i][1].ToString();
                                        dr["Plan1_Rate"] = "";
                                        dr["Plan2_Rate"] = "";
                                        dr["Plan3_Rate"] = "";

                                        PremiumTableWriteVision.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                        VisionCount++;
                    }
                    #endregion
                }

                #region Medical Monthly Premium
                int MediCalTableRowCounter = 2;
                int kl = 0;
                for (int d = 0; d < PremiumTableWriteMedical.Rows.Count; d++)
                {
                    if (kl > 0)
                    {
                        oWordDoc.Tables[Medicalindex].Rows.Add();
                    }
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 1).Range.Text = PremiumTableWriteMedical.Rows[d][0].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 2).Range.Text = PremiumTableWriteMedical.Rows[d][1].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 3).Range.Text = PremiumTableWriteMedical.Rows[d][2].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 4).Range.Text = PremiumTableWriteMedical.Rows[d][3].ToString();
                    oWordDoc.Tables[Medicalindex].Cell(MediCalTableRowCounter, 5).Range.Text = PremiumTableWriteMedical.Rows[d][4].ToString();
                    MediCalTableRowCounter++;
                    kl++;
                }
                #endregion

                #region Dental Monthly Premium
                int DentalTableRowCounter = 2;
                int kk = 0;

                for (int d = 0; d < PremiumTableWriteDental.Rows.Count; d++)
                {
                    if (kk > 0)
                    {
                        oWordDoc.Tables[7].Rows.Add();
                    }
                    oWordDoc.Tables[7].Cell(DentalTableRowCounter, 1).Range.Text = PremiumTableWriteDental.Rows[d][0].ToString();
                    oWordDoc.Tables[7].Cell(DentalTableRowCounter, 2).Range.Text = PremiumTableWriteDental.Rows[d][1].ToString();
                    oWordDoc.Tables[7].Cell(DentalTableRowCounter, 3).Range.Text = PremiumTableWriteDental.Rows[d][2].ToString();
                    oWordDoc.Tables[7].Cell(DentalTableRowCounter, 4).Range.Text = PremiumTableWriteDental.Rows[d][3].ToString();
                    oWordDoc.Tables[7].Cell(DentalTableRowCounter, 5).Range.Text = PremiumTableWriteDental.Rows[d][4].ToString();
                    DentalTableRowCounter++;
                    kk++;
                }
                #endregion

                #region Vision Monthly Premium
                int VisionTableRowCounter = 2;
                int km = 0;

                for (int d = 0; d < PremiumTableWriteVision.Rows.Count; d++)
                {
                    if (km > 0)
                    {
                        oWordDoc.Tables[8].Rows.Add();
                    }
                    oWordDoc.Tables[8].Cell(VisionTableRowCounter, 1).Range.Text = PremiumTableWriteVision.Rows[d][0].ToString();
                    oWordDoc.Tables[8].Cell(VisionTableRowCounter, 2).Range.Text = PremiumTableWriteVision.Rows[d][1].ToString();
                    oWordDoc.Tables[8].Cell(VisionTableRowCounter, 3).Range.Text = PremiumTableWriteVision.Rows[d][2].ToString();
                    oWordDoc.Tables[8].Cell(VisionTableRowCounter, 4).Range.Text = PremiumTableWriteVision.Rows[d][3].ToString();
                    oWordDoc.Tables[8].Cell(VisionTableRowCounter, 5).Range.Text = PremiumTableWriteVision.Rows[d][4].ToString();
                    VisionTableRowCounter++;
                    km++;
                }
                #endregion

                #region MergeField

                int iTotalFields = 0;
                foreach (Word.Field myMergeField in oWordDoc.Fields)
                {
                    iTotalFields++;

                    Word.Range rngFieldCode = myMergeField.Code;

                    String fieldText = rngFieldCode.Text;

                    if (fieldText.StartsWith(" MERGEFIELD"))
                    {
                        Int32 endMerge = fieldText.IndexOf("\\");
                        if (endMerge == -1)
                        {
                            endMerge = fieldText.Length;
                        }

                        Int32 fieldNameLength = fieldText.Length - endMerge;

                        String fieldName = fieldText.Substring(11, endMerge - 11);

                        fieldName = fieldName.Trim();

                        if (fieldName.Contains("MedicalCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteMedical.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("DentalCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteDental.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                        if (fieldName.Contains("VisionCount"))
                        {
                            myMergeField.Select();
                            if (PremiumTableWriteVision.Rows.Count > 0)
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            continue;
                        }
                    }
                }

                #endregion
            }

            catch (Exception ex)
            {
                bp.InsertExceptionLog(ex.Message, ex.Source, Convert.ToString(ex.TargetSite), ex.StackTrace, DateTime.Now);
                Response.Redirect("~/view/ErrorNotification.aspx");
            }
        }

    }
}