﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BenefitPointSummaryPortal.BAL.BenefitSummary;
using BenefitPointSummaryPortal.Common.BenefitSummary;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;
using BenefitPointSummaryPortal.Common.ViewModels;
using System.Data;
using System.IO;

namespace BenefitPointSummaryPortal.BAL.AnalysisTemplate
{
    public class WriteAnalystAssignmentRequest
    {
        public static ConstantValue cv = new ConstantValue();
        BPBusiness bp = new BPBusiness();
        SummaryDetail sd = new SummaryDetail();

        #region Plan Lists
        public static List<int> MedicalPlan = new List<int>() { 100, 110, 120, 130, 140, 150, 160, 170, 233 };
        public static List<int> Dental = new List<int>() { 180, 190, 200, 210 };
        public static List<int> Vision = new List<int>() { 230 };
        public static List<int> HealthSavingAccounts = new List<int>() { 179 };
        public static List<int> HealthReimbursementArrangement = new List<int>() { 178 };
        public static List<int> LifeADD = new List<int>() { 240 };
        public static List<int> GroupTermLife = new List<int>() { 250 };
        public static List<int> ADD = new List<int>() { 270 };
        public static List<int> VoluntaryLife = new List<int>() { 260 };
        public static List<int> VoluntaryADD = new List<int>() { 280 };
        public static List<int> ShortTermDisability = new List<int>() { 290, 292, 293, 294 };
        public static List<int> LongTermDisablity = new List<int>() { 300 };
        public static List<int> EmployeeAssistanceProgram = new List<int>() { 310 };
        public static List<int> FlexibleSpendingAccount = new List<int>() { 330 };
        public static List<int> Wellness = new List<int>() { 317 };
        public static List<int> MedicalRxPlan = new List<int>() { 176 };
        public static List<int> Plan_401K = new List<int>() { 340 };
        public static List<int> StopLoss = new List<int>() { 235 };
        public static List<int> InternationalBundledsPlan_3_Tier = new List<int>() { 410 };
        public static List<int> BussinessTravelAccident = new List<int>() { 320 };
        #endregion

        #region Trifold Product Lists
        public static List<int> Telemedicine = new List<int>() { 5460 };
        public static List<int> PatientAdvocacy = new List<int>() { 1790 };
        public static List<int> Hospitalization = new List<int>() { 5060 };
        public static List<int> Accident = new List<int>() { 5500 };
        public static List<int> CriticalIllnesss = new List<int>() { 1160 };
        public static List<int> VoluntaryCancer = new List<int>() { 1400 };
        public static List<int> ProductLifeADD = new List<int>() { 1150, 1230 };
        public static List<int> AbsenseMasnagement = new List<int>() { 5330 };
        public static List<int> PetInsurance = new List<int>() { 1480 };
        public static List<int> CobraAdministration = new List<int>() { 1109 };
        public static List<int> FinancialProduct = new List<int>() { 1107 };
        public static List<int> ExecutiveBenefit = new List<int>() { 1104 };
        public static List<int> Product500Filling = new List<int>() { 1110 };
        public static List<int> TransitParkingAdmin = new List<int>() { 1720 };
        public static List<int> LegalServices = new List<int>() { 1114 };
        public static List<int> IdentifyTheft = new List<int>() { 3090 };
        public static List<int> ShortTermMedical = new List<int>() { 1240 };
        public static List<int> WholeLifeIndividual = new List<int>() { 5070 };
        public static List<int> DiseaseManagement = new List<int>() { 5875 };
        public static List<int> TobaccoPolicy = new List<int>() { 5040 };
        public static List<int> GroupHomeAndAuto = new List<int>() { 4020 };
        public static List<int> MinimumEssentialCoverage = new List<int>() { 5825 };
        public static List<int> IND_INDIV_LONG_TERM_CARE = new List<int>() { 1890 };
        public static List<int> IndividualDisability = new List<int>() { 1460 };
        public static List<int> MedicareSupplement = new List<int>() { 1260 };
        public static List<int> FeeForService_Consulting_Project = new List<int>() { 1108 };
        public static List<int> FeeForService_PBMConsulting = new List<int>() { 5885 };
        public static List<int> FeeForService_HR_Ben_Admin_Services = new List<int>() { 1111 };
        public static List<int> LongTermCare = new List<int>() { 1115 };
        public static List<int> MedicalPlanRiders = new List<int>() { 1116 };
        public static List<int> OnsiteMedicenter = new List<int>() { 5340 };
        #endregion

        public static List<int> LoadAllAnalystAssignmentPlans()
        {
            List<int> AnalystAsignmentAllPlans = new List<int>();
            AnalystAsignmentAllPlans.AddRange(MedicalPlan);
            AnalystAsignmentAllPlans.AddRange(Dental);
            AnalystAsignmentAllPlans.AddRange(Vision);
            AnalystAsignmentAllPlans.AddRange(HealthSavingAccounts);
            AnalystAsignmentAllPlans.AddRange(HealthReimbursementArrangement);
            AnalystAsignmentAllPlans.AddRange(LifeADD);
            AnalystAsignmentAllPlans.AddRange(GroupTermLife);
            AnalystAsignmentAllPlans.AddRange(ADD);
            AnalystAsignmentAllPlans.AddRange(VoluntaryLife);
            AnalystAsignmentAllPlans.AddRange(VoluntaryADD);
            AnalystAsignmentAllPlans.AddRange(ShortTermDisability);
            AnalystAsignmentAllPlans.AddRange(LongTermDisablity);
            AnalystAsignmentAllPlans.AddRange(EmployeeAssistanceProgram);
            AnalystAsignmentAllPlans.AddRange(FlexibleSpendingAccount);
            AnalystAsignmentAllPlans.AddRange(Wellness);
            AnalystAsignmentAllPlans.AddRange(StopLoss);
            AnalystAsignmentAllPlans.AddRange(MedicalRxPlan);
            AnalystAsignmentAllPlans.AddRange(Plan_401K);
            AnalystAsignmentAllPlans.AddRange(InternationalBundledsPlan_3_Tier);
            AnalystAsignmentAllPlans.AddRange(BussinessTravelAccident);
            return AnalystAsignmentAllPlans;

        }
        public static List<int> LoadAllAnalystAssignmentProduct()
        {
            List<int> AnalystAsignmentAllProducts = new List<int>();
            AnalystAsignmentAllProducts = new List<int>();
            AnalystAsignmentAllProducts.AddRange(Telemedicine);
            AnalystAsignmentAllProducts.AddRange(PatientAdvocacy);
            AnalystAsignmentAllProducts.AddRange(Hospitalization);
            AnalystAsignmentAllProducts.AddRange(Accident);
            AnalystAsignmentAllProducts.AddRange(CriticalIllnesss);
            AnalystAsignmentAllProducts.AddRange(VoluntaryCancer);
            AnalystAsignmentAllProducts.AddRange(ProductLifeADD);
            AnalystAsignmentAllProducts.AddRange(AbsenseMasnagement);
            AnalystAsignmentAllProducts.AddRange(PetInsurance);
            AnalystAsignmentAllProducts.AddRange(CobraAdministration);
            AnalystAsignmentAllProducts.AddRange(FinancialProduct);
            AnalystAsignmentAllProducts.AddRange(ExecutiveBenefit);
            AnalystAsignmentAllProducts.AddRange(Product500Filling);
            AnalystAsignmentAllProducts.AddRange(TransitParkingAdmin);
            AnalystAsignmentAllProducts.AddRange(LegalServices);
            AnalystAsignmentAllProducts.AddRange(IdentifyTheft);
            AnalystAsignmentAllProducts.AddRange(ShortTermMedical);
            AnalystAsignmentAllProducts.AddRange(WholeLifeIndividual);
            AnalystAsignmentAllProducts.AddRange(DiseaseManagement);
            AnalystAsignmentAllProducts.AddRange(TobaccoPolicy);
            AnalystAsignmentAllProducts.AddRange(GroupHomeAndAuto);
            AnalystAsignmentAllProducts.AddRange(MinimumEssentialCoverage);
            AnalystAsignmentAllProducts.AddRange(IND_INDIV_LONG_TERM_CARE);
            AnalystAsignmentAllProducts.AddRange(IndividualDisability);
            AnalystAsignmentAllProducts.AddRange(MedicareSupplement);
            AnalystAsignmentAllProducts.AddRange(FeeForService_Consulting_Project);
            AnalystAsignmentAllProducts.AddRange(FeeForService_PBMConsulting);
            AnalystAsignmentAllProducts.AddRange(FeeForService_HR_Ben_Admin_Services);
            AnalystAsignmentAllProducts.AddRange(LongTermCare);
            AnalystAsignmentAllProducts.AddRange(MedicalPlanRiders);
            AnalystAsignmentAllProducts.AddRange(OnsiteMedicenter);


            return AnalystAsignmentAllProducts;
        }
        public static List<BenefitSummaryStructure> BenefitSummarySelectionMap
        {
            get
            {
                List<BenefitSummaryStructure> lstMap = new List<BenefitSummaryStructure>();

                BenefitSummaryStructure Medical = new BenefitSummaryStructure();
                Medical.LOC = cv.MedicalLOC;
                Medical.MaxBenefitSummary = 3;
                Medical.MaxContributionPerSummary = 1;
                Medical.ContributionApplicable = true;
                Medical.BenefitSummaryApplicable = true;
                Medical.RateApplicable = false;
                Medical.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Medical);

                BenefitSummaryStructure Dental = new BenefitSummaryStructure();
                Dental.LOC = cv.DentalLOC;
                Dental.MaxBenefitSummary = 99;
                Dental.MaxContributionPerSummary = 1;
                Dental.ContributionApplicable = true;
                Dental.BenefitSummaryApplicable = true;
                Dental.RateApplicable = false;
                Dental.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Dental);

                BenefitSummaryStructure Vision = new BenefitSummaryStructure();
                Vision.LOC = cv.VisionLOC;
                Vision.MaxBenefitSummary = 99;
                Vision.MaxContributionPerSummary = 1;
                Vision.ContributionApplicable = true;
                Vision.BenefitSummaryApplicable = true;
                Vision.RateApplicable = false;
                Vision.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Vision);

                BenefitSummaryStructure HSA = new BenefitSummaryStructure();
                HSA.LOC = cv.HSALOC;
                HSA.MaxBenefitSummary = 99;
                HSA.MaxContributionPerSummary = 0;
                HSA.ContributionApplicable = false;
                HSA.BenefitSummaryApplicable = false;
                HSA.RateApplicable = false;
                HSA.MaxRatePerBenefitSummary = 0;
                lstMap.Add(HSA);

                BenefitSummaryStructure HRA = new BenefitSummaryStructure();
                HRA.LOC = cv.HRALOC;
                HRA.MaxBenefitSummary = 99;
                HRA.MaxContributionPerSummary = 0;
                HRA.ContributionApplicable = false;
                HRA.BenefitSummaryApplicable = false;
                lstMap.Add(HRA);

                BenefitSummaryStructure LifeADD = new BenefitSummaryStructure();
                LifeADD.LOC = cv.LifeADDLOC;
                LifeADD.MaxBenefitSummary = 99;
                LifeADD.MaxContributionPerSummary = 0;
                LifeADD.ContributionApplicable = false;
                LifeADD.BenefitSummaryApplicable = false;
                LifeADD.RateApplicable = false;
                LifeADD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(LifeADD);

                BenefitSummaryStructure VolLifeADD = new BenefitSummaryStructure();
                VolLifeADD.LOC = cv.VoluntaryLifeADDLOC;
                VolLifeADD.MaxBenefitSummary = 99;
                VolLifeADD.MaxContributionPerSummary = 0;
                VolLifeADD.ContributionApplicable = false;
                VolLifeADD.BenefitSummaryApplicable = false;
                VolLifeADD.RateApplicable = false;
                VolLifeADD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(VolLifeADD);

                BenefitSummaryStructure STD = new BenefitSummaryStructure();
                STD.LOC = cv.STDLOC;
                STD.MaxBenefitSummary = 99;
                STD.MaxContributionPerSummary = 0;
                STD.ContributionApplicable = false;
                STD.BenefitSummaryApplicable = false;
                STD.RateApplicable = false;
                STD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(STD);

                BenefitSummaryStructure LTD = new BenefitSummaryStructure();
                LTD.LOC = cv.LTDLOC;
                LTD.MaxBenefitSummary = 99;
                LTD.MaxContributionPerSummary = 0;
                LTD.ContributionApplicable = false;
                LTD.BenefitSummaryApplicable = false;
                LTD.RateApplicable = false;
                LTD.MaxRatePerBenefitSummary = 0;
                lstMap.Add(LTD);

                BenefitSummaryStructure EAP = new BenefitSummaryStructure();
                EAP.LOC = cv.EAPLOC;
                EAP.MaxBenefitSummary = 1;
                EAP.MaxContributionPerSummary = 0;
                EAP.ContributionApplicable = false;
                EAP.BenefitSummaryApplicable = false;
                EAP.RateApplicable = false;
                EAP.MaxRatePerBenefitSummary = 0;
                lstMap.Add(EAP);

                BenefitSummaryStructure Wllness = new BenefitSummaryStructure();
                Wllness.LOC = cv.Wellness;
                Wllness.MaxBenefitSummary = 99;
                Wllness.MaxContributionPerSummary = 0;
                Wllness.ContributionApplicable = false;
                Wllness.BenefitSummaryApplicable = false;
                Wllness.RateApplicable = false;
                Wllness.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Wllness);

                BenefitSummaryStructure Telemedicine = new BenefitSummaryStructure();
                Telemedicine.LOC = "Telemedicine";
                Telemedicine.MaxBenefitSummary = 99;
                Telemedicine.MaxContributionPerSummary = 0;
                Telemedicine.ContributionApplicable = false;
                Telemedicine.BenefitSummaryApplicable = false;
                Telemedicine.RateApplicable = false;
                Telemedicine.MaxRatePerBenefitSummary = 0;
                lstMap.Add(Telemedicine);

                BenefitSummaryStructure PatientAdvocyProgram = new BenefitSummaryStructure();
                PatientAdvocyProgram.LOC = "Patient Advocacy";
                PatientAdvocyProgram.MaxBenefitSummary = 99;
                PatientAdvocyProgram.MaxContributionPerSummary = 0;
                PatientAdvocyProgram.ContributionApplicable = false;
                PatientAdvocyProgram.BenefitSummaryApplicable = false;
                PatientAdvocyProgram.RateApplicable = false;
                PatientAdvocyProgram.MaxRatePerBenefitSummary = 0;
                lstMap.Add(PatientAdvocyProgram);

                return lstMap;
            }

        }


        #region Methods added by shravan - for template writing

        public void WriteAccountAndContactDetails(Word.Document oWordDoc, Word.Application oWordApp, DataSet AccountDS, DataSet AccountTeamMemberDS, string ClientName, string ClientOffice)
        {
            DateTime dateValue = new DateTime();
            int iTotalFields = 0;
            string SalesLead = string.Empty;
            string ServiceLead = string.Empty;
            string Broker_Of_Record = string.Empty;
            string Num_Of_FTE = string.Empty;
            string Num_Of_FTE_AS_Of = string.Empty;
            string StreetAddress = string.Empty;
            string City = string.Empty;
            string State = string.Empty;
            string ZIP = string.Empty;

            #region For Account Details
            if (AccountDS != null)
            {
                if (AccountDS.Tables[1].Rows.Count > 0)
                {
                    for (int j = 0; j < AccountDS.Tables[1].Rows.Count; j++)
                    {
                        if (AccountTeamMemberDS != null && AccountTeamMemberDS.Tables[0].Rows.Count > 0)
                        {
                            for (int h = 0; h < AccountTeamMemberDS.Tables[0].Rows.Count; h++)
                            {
                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primarySalesLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    SalesLead = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }

                                if (Convert.ToString(AccountDS.Tables[1].Rows[j]["primaryServiceLeadUserID"]) == Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["userID"]))
                                {
                                    ServiceLead = Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["firstName"]) + " " + Convert.ToString(AccountTeamMemberDS.Tables[0].Rows[h]["lastName"]);
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"])))
                        {
                            StreetAddress = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street1"]);
                            if (StreetAddress == "None_Selected")
                            {
                                StreetAddress = "";
                            }
                        }

                        //if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"])))
                        //{
                        //    Street2 = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_street2"]);
                        //if (Street2 != "None_Selected")
                        //{
                        //    Street2 = "";
                        //}
                        //}

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"])))
                        {
                            City = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_city"]);
                            if (City == "None_Selected")
                            {
                                City = "";
                            }
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"])))
                        {
                            State = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_state"]);
                            if (State == "None_Selected")
                            {
                                State = "";
                            }
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"])))
                        {
                            ZIP = Convert.ToString(AccountDS.Tables[1].Rows[j]["mainAddress_zip"]);
                            if (ZIP == "None_Selected")
                            {
                                ZIP = "";
                            }
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])))
                        {
                            if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"]), out dateValue) == true)
                            {
                                Broker_Of_Record = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_commonGroupAccountInfo_brokerageAccountInfo_brokerOfRecordAsOf"])).ToString("MM/dd/yyyy");
                            }
                        }


                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"])))
                        {
                            Num_Of_FTE = Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEs"]);
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])))
                        {
                            if (DateTime.TryParse(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"]), out dateValue) == true)
                            {
                                Num_Of_FTE_AS_Of = Convert.ToDateTime(Convert.ToString(AccountDS.Tables[1].Rows[j]["groupAccountInfo_numberOfFTEsAsOf"])).ToString("MM/dd/yyyy");
                            }
                        }
                    }
                }
            }

            #endregion

            #region MergeField

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {
                iTotalFields++;

                Word.Range rngFieldCode = myMergeField.Code;

                string fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    if (endMerge == -1)
                    {
                        endMerge = fieldText.Length;
                    }

                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    string fieldName = fieldText.Substring(11, endMerge - 11);
                    fieldName = fieldName.Trim();

                    if (fieldName.Contains("Client Name"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientName);
                        continue;
                    }

                    if (fieldName.Contains("ClientOffice"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(ClientOffice);
                        continue;
                    }

                    if (fieldName.Contains("Sysdate"))
                    {
                        myMergeField.Select();
                        oWordApp.Selection.TypeText(DateTime.Today.ToString("MM/dd/yyyy"));
                        continue;
                    }

                    if (fieldName.Contains("Street Address"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(StreetAddress))
                        {
                            oWordApp.Selection.TypeText(StreetAddress);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }
                    if (fieldName.Contains("ZIP"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ZIP))
                        {
                            oWordApp.Selection.TypeText(ZIP);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }
                    if (fieldName.Contains("City"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(City))
                        {
                            oWordApp.Selection.TypeText(City);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }
                    if (fieldName.Contains("State"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(State))
                        {
                            oWordApp.Selection.TypeText(State);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }

                    if (fieldName.Contains("Broker of Record Date"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(Broker_Of_Record) && Broker_Of_Record != "01/01/0001")
                        {
                            oWordApp.Selection.TypeText(Broker_Of_Record);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }

                    if (fieldName.Contains("Number of Full Time Employees"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(Num_Of_FTE) && !(string.IsNullOrEmpty(Num_Of_FTE_AS_Of)) && Num_Of_FTE_AS_Of != "01/01/0001")
                        {
                            decimal Number_Of_FTE = Convert.ToDecimal(Num_Of_FTE);
                            // oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                            oWordApp.Selection.TypeText(Number_Of_FTE.ToString("#,##0") + " as of " + Num_Of_FTE_AS_Of);
                        }
                        else if (!string.IsNullOrEmpty(Num_Of_FTE) && (string.IsNullOrEmpty(Num_Of_FTE_AS_Of)))
                        {
                            if (Num_Of_FTE == "0" && string.IsNullOrEmpty(Num_Of_FTE_AS_Of))
                            {
                                oWordApp.Selection.TypeText(" ");
                            }
                            else
                            {
                                oWordApp.Selection.TypeText(Num_Of_FTE);
                            }
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }

                    if (fieldName.Contains("Primary Sales Lead"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(SalesLead))
                        {
                            oWordApp.Selection.TypeText(SalesLead);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }



                    if (fieldName.Contains("Primary Service Lead"))
                    {
                        myMergeField.Select();
                        if (!string.IsNullOrEmpty(ServiceLead))
                        {
                            oWordApp.Selection.TypeText(ServiceLead);
                        }
                        else
                        {
                            oWordApp.Selection.TypeText(" ");
                        }
                        continue;
                    }
                }
            }
            #endregion

            #region Merge field for footer
            foreach (Microsoft.Office.Interop.Word.Section section in oWordDoc.Sections)
            {
                foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in section.Footers)
                {
                    Word.Fields fields = footer.Range.Fields;

                    foreach (Word.Field field in fields)
                    {
                        Word.Range rngFieldCode = field.Code;
                        string fieldText = rngFieldCode.Text;
                        if (fieldText.StartsWith(" MERGEFIELD"))
                        {
                            Int32 endMerge = fieldText.IndexOf("\\");

                            if (endMerge == -1)
                            {
                                endMerge = fieldText.Length;
                            }

                            Int32 fieldNameLength = fieldText.Length - endMerge;
                            string fieldName = fieldText.Substring(11, endMerge - 11);
                            fieldName = fieldName.Trim();

                            if (fieldName.Contains("CurrentYear"))
                            {
                                field.Select();
                                oWordApp.Selection.TypeText(DateTime.Today.Year.ToString());
                                continue;
                            }
                        }
                    }
                }
            }

            #endregion
        }

        public void WritePlanTable(Word.Document oWordDoc, Word.Application oWordApp, List<SummarySelectionViewModel> SelectedPlanList, DropDownList ddlClient, string SessionId)
        {
            Word.Table table = oWordDoc.Tables[4];
            List<BenefitSummarydata> BenefitSummaryList = new List<BenefitSummarydata>();
            List<Contribution> ContributionList = new List<Contribution>();
            DateTime RenewalDate;
            string FundingType = "";
            string ContributionMethod = string.Empty;

            int row = 1;
            foreach (SummarySelectionViewModel plan in SelectedPlanList)
            {
                row++;
                if (row > 2)
                {
                    table.Rows.Add(Type.Missing);
                }

                BenefitSummaryList = bp.FindBenefitSummarys(int.Parse(ddlClient.SelectedValue), plan.ProductId, SessionId);
                ContributionList = bp.FindContributions(plan.ProductId, SessionId);

                #region Funding Type
                int OptionFieldValueiD = sd.GetProductDetail_FundingType_OptionFieldID(plan.ProductId, SessionId);
                switch (OptionFieldValueiD)
                {
                    case 52403: FundingType = "Self Funded"; break;
                    case 52401: FundingType = "Fully Insured"; break;
                    case 52400: FundingType = ""; break;
                    default: FundingType = ""; break;
                }
                #endregion

                #region Contribution Method
                if (plan.ProductName != null)
                {
                    if (plan.ProductName.Trim().ToLower().Contains("shared"))
                    {
                        ContributionMethod = "Shared";
                    }
                    else if (plan.ProductName.Trim().ToLower().Contains("er paid"))
                    {
                        ContributionMethod = "Employer Paid";
                    }
                    else if (plan.ProductName.Trim().ToLower().Contains("ee paid"))
                    {
                        ContributionMethod = "Employee Paid";
                    }
                    else
                    {
                        ContributionMethod = "Not Listed";
                    }
                }
                else
                {
                    ContributionMethod = "Not Listed";
                }
                #endregion

                table.Cell(row, 1).Range.Text = plan.ProductTypeDescription;
                table.Cell(row, 2).Range.Text = plan.CarrierName;
                table.Cell(row, 3).Range.Text = BenefitSummaryList != null ? BenefitSummaryList.Count.ToString() : "0";
                table.Cell(row, 4).Range.Text = FundingType;

                if (DateTime.TryParse(plan.RenewalDate, out RenewalDate))
                    table.Cell(row, 5).Range.Text = RenewalDate.ToString("MM/yyyy");

                table.Cell(row, 6).Range.Text = ContributionMethod;

            }
        }

        public void WriteProductTable(Word.Document oWordDoc, Word.Application oWordApp, List<SummarySelectionViewModel> SelectedProductList, string SessionId)
        {
            Word.Table table = oWordDoc.Tables[5];
            string ContributionMethod = string.Empty;
            DateTime RenewalDate;

            int row = 1;
            foreach (SummarySelectionViewModel plan in SelectedProductList)
            {
                row++;
                if (row > 2)
                {
                    table.Rows.Add(Type.Missing);
                }

                #region Contribution Method
                if (plan.ProductName != null)
                {
                    if (plan.ProductName.Trim().ToLower().Contains("shared"))
                    {
                        ContributionMethod = "Shared";
                    }
                    else if (plan.ProductName.Trim().ToLower().Contains("er paid"))
                    {
                        ContributionMethod = "Employer Paid";
                    }
                    else if (plan.ProductName.Trim().ToLower().Contains("ee paid"))
                    {
                        ContributionMethod = "Employee Paid";
                    }
                    else
                    {
                        ContributionMethod = "Not Listed";
                    }
                }
                else
                {
                    ContributionMethod = "Not Listed";
                }
                #endregion

                table.Cell(row, 1).Range.Text = plan.ProductTypeDescription;
                table.Cell(row, 2).Range.Text = plan.CarrierName;
                table.Cell(row, 4).Range.Text = ContributionMethod;

                if (DateTime.TryParse(plan.RenewalDate, out RenewalDate))
                    table.Cell(row, 3).Range.Text = RenewalDate.ToString("MM/yyyy");

            }
        }

        public void WritePlanOrProductTable(Word.Document oWordDoc, Word.Application oWordApp, List<SummarySelectionViewModel> SelectedPlanList, List<SummarySelectionViewModel> SelectedProductList)
        {
            Word.Table table = oWordDoc.Tables[7];
            int row = 2;
            table.Rows[3].Range.Copy();
            int totalNoRows = SelectedPlanList.Count + SelectedProductList.Count;
            for (int i = 0; i < totalNoRows; i++)
            {
                if (i > 0)
                    table.Rows[table.Rows.Count].Range.Paste();

            }

            foreach (SummarySelectionViewModel plan in SelectedPlanList)
            {
                row++;
                table.Cell(row, 1).Range.Text = plan.ProductTypeDescription;
                table.Cell(row, 2).Range.Text = plan.CarrierName;
            }
            foreach (SummarySelectionViewModel plan in SelectedProductList)
            {
                row++;
                table.Cell(row, 1).Range.Text = plan.ProductTypeDescription;
                table.Cell(row, 2).Range.Text = plan.CarrierName;
            }

            #region merge cells in table header
            table.Cell(1, 3).Merge(table.Cell(1, 8));
            table.Cell(1, 2).Merge(table.Cell(2, 2));
            table.Cell(1, 1).Merge(table.Cell(2, 1));
            #endregion
        }

        public void DeleteIndivialBookmark(Word.Document oWordDoc, string bookmark)
        {
            if (oWordDoc.Bookmarks.Exists(bookmark))
            {
                oWordDoc.Bookmarks[bookmark].Range.Delete();
            }
        }

        public void WriteAnalystTable(Word.Document oWordDoc, string AccountID, string SessionId)
        {

            Word.Table table = oWordDoc.Tables[1];
            int row = 1;
            DataTable AnalystTable = sd.GetAnalyticTeamDetail(Convert.ToInt32(AccountID), SessionId);

            foreach (DataRow dr in AnalystTable.Rows)
            {
                row++;
                if (row > 2)
                {
                    table.Rows.Add(Type.Missing);
                }

                table.Cell(row, 1).Range.Text = dr["Region_Name"].ToString();
                table.Cell(row, 2).Range.Text = dr["AnalystLeadName"].ToString();
                table.Cell(row, 3).Range.Text = dr["AnalystLeadEmail"].ToString();

            }

        }

        #endregion

    }
}