﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BenefitPointSummaryPortal.Common.BenefitSummary
{

    public class Account
    {
        #region Variable
        private int _accountId;
        private string _accountName;
        private string _officeName;

        private int _primaryContactUserID;
        private string _primaryContactUserName;
        private int _primarySalesLeadUserID;
        private string _primarySalesLeadUserName;
        private int _primaryServiceLeadUserID;
        private string _primaryServiceLeadUserName;
        private int _customFieldValueID;
        private int _customFieldID;
        private int _optionValueID;
        private string _valueText;
        private int _recordID;

        # endregion

        #region Properties
        /// <summary>
        /// Get and Set AccountId
        /// </summary>
        public int AccountId
        {
            get
            {
                return _accountId;
            }
            set
            {
                _accountId = value;
            }
        }
        /// <summary>
        /// Get and Set AccountName
        /// </summary>
        public string AccountName
        {
            get
            {
                return _accountName;

            }
            set
            {
                _accountName = value;
            }
        }

        /// <summary>
        /// Get and Set OfficeName
        /// </summary>
        public string OfficeName
        {
            get
            {
                return _officeName;

            }
            set
            {
                _officeName = value;
            }
        }

        /// <summary>
        /// Get and Set PrimaryContactUserID
        /// </summary>
        public int PrimaryContactUserID
        {
            get
            {
                return _primaryContactUserID;
            }
            set
            {
                _primaryContactUserID = value;
            }
        }

        /// <summary>
        /// Get and Set PrimaryContactUserName
        /// </summary>
        public string PrimaryContactUserName
        {
            get
            {
                return _primaryContactUserName;
            }
            set
            {
                _primaryContactUserName = value;
            }
        }

        /// <summary>
        /// Get and Set PrimarySalesLeadUserID
        /// </summary>
        public int PrimarySalesLeadUserID
        {
            get
            {
                return _primarySalesLeadUserID;
            }
            set
            {
                _primarySalesLeadUserID = value;
            }
        }

        /// <summary>
        /// Get and Set PrimarySalesLeadUserName
        /// </summary>
        public string PrimarySalesLeadUserName
        {
            get
            {
                return _primarySalesLeadUserName;
            }
            set
            {
                _primarySalesLeadUserName = value;
            }
        }

        /// <summary>
        /// Get and Set PrimaryServiceLeadUserID
        /// </summary>
        public int PrimaryServiceLeadUserID
        {
            get
            {
                return _primaryServiceLeadUserID;
            }
            set
            {
                _primaryServiceLeadUserID = value;
            }
        }

        /// <summary>
        /// Get and Set PrimaryServiceLeadUserName
        /// </summary>
        public string PrimaryServiceLeadUserName
        {
            get
            {
                return _primaryServiceLeadUserName;
            }
            set
            {
                _primaryServiceLeadUserName = value;
            }
        }

        /// <summary>
        /// Get and Set CustomFieldValueID
        /// </summary>
        public int CustomFieldValueID
        {
            get
            {
                return _customFieldValueID;
            }
            set
            {
                _customFieldValueID = value;
            }
        }

        /// <summary>
        /// Get and Set CustomFieldID
        /// </summary>
        public int CustomFieldID
        {
            get
            {
                return _customFieldID;
            }
            set
            {
                _customFieldID = value;
            }
        }

        /// <summary>
        /// Get and Set OptionValueID
        /// </summary>
        public int OptionValueID
        {
            get
            {
                return _optionValueID;
            }
            set
            {
                _optionValueID = value;
            }
        }

        /// <summary>
        /// Get and Set ValueText
        /// </summary>
        public string ValueText
        {
            get
            {
                return _valueText;
            }
            set
            {
                _valueText = value;
            }
        }

        /// <summary>
        /// Get and Set RecordId (Activity Information)
        /// </summary>
        public int RecordId
        {
            get
            {
                return _recordID;
            }
            set
            {
                _recordID = value;
            }
        }
        # endregion

    }
}